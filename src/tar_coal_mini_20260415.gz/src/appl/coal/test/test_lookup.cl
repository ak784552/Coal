//
// 0x0001 �����̂Ƃ��A�啶������������Ȃ�
// 0x0800 LIKE��r���s��

//def x 10 = [1,2,3,4,5,6,7,8,9,10];
proc main;

	a = [1,2,3,4,5,6,4,7];
	print a;
	print lookup(a,3);
	print lookup(a,4,,,1);
	print lookup(a,6,1,3,2);
	print lookup(a,6,,6,2);
	print lookup(a,4,,6,-1);
/*
	print *x;
	print lookup(x,5);
*/
	b = ['AbCD123','B�x�yCxyW980','ClkGs65s','D346abcXYZ'];
	print b;
	print lookup(b,'%CD%',0x800);
	print lookup(b,'%XY%',0x801);
	print lookup(b,'%YZ%',0x802);

	c = ['1','2','3','4','5','6','4','7','�R','A','B','a'];
	print c;
	print lookup(c,'A');
	print lookup(c,'a');
	print lookup(c,'a',1);
	print lookup(c,'�R');
	print lookup(c,'�R',2);

	return ERROR;
end proc;
