//
//def aa 10 = [3,5,1,9,4,2];
proc main;
	a = [3,5,1,9,4,2];
	n = sort(1,a);
	print *$();

	print "x = sort(0,a)";
	print /d x;

	print "*(x = sort(0,%()))";

	print "*(x = sort('A',%()))";
	aa = %() + 0;
	print "x = sort(SYSDATE,aa)";

	print "x = sort(TO_BULK(1),aa)";

	return $ERROR;
end proc;
