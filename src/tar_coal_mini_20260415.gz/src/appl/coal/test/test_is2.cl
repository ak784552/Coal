//
//def a 10;
PROC main;
	m = $() + 1;
	$1 = is(' -123 ','N');
	print $1 is($1,'t');
	print "is(' -123 A ','N')";
	print "is(' -123F ','N')";
	print "is(' -0xff ','N')";
	print "is(' -123.45 ','N')";
	print "is(' -123.45A ','N')";
	print "is('XYZ-123.45 ',4,'N')";
	print "is('XYZ-123.45 ',4,6,'N')";
	print "is('XYZ-123.45 ',4..6,'N')";
	print "is(123.45,3,'N')";
	print "chr(is(123.45,3,'I'))";
	print is(123.45,3,'T') is(123.45,3,'TCon');
//	print is(12345U,'TUnsigned') /x is(12345U,'T+');
	print is(1..3,'TRange') /x is(1..3,'T+');
	print is(*(1..3),'TDatamode') /x "is(*(1..3),'T+')";
/*
	print is(1+3i,'TComplex') /x is(1+3i,'T+');
	print /x is((1/3r)..(3/2r),'T+');
//	print (1/3r)..(3/2r);
	print is(1/3r,'TRat') /x is(1/3r,'T+');
	print is(1i,'TImage') /x is(1i,'T+');
	print chr(is(a,'I')) is(a,'IR') is(a,'IA');
*/
	print chr(is(m,'I')) is(m,'IA') is(m,'IR');

	RETURN $ERROR;
END PROC;
