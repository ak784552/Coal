tar cvf tar_lib_dev1 \
	backup.sh \
	src/Makefile src/*.mk \
	src/lib/Makefile src/lib/mdiff* \
	src/lib/include/*.h \
	src/lib/akx/*.c src/lib/akx/makefile src/lib/akx/*.txt \
	src/lib/akb/*.c src/lib/akb/makefile \
	src/lib/aka/*.c src/lib/aka/makefile \
	src/lib/akas/*.c src/lib/akas/makefile
gzip tar_lib_dev1

tar cvf tar_appl_coal_dev1 \
	src/appl/Makefile src/appl/mdiff* \
	src/appl/cmn/*.c src/appl/cmn/makefile \
	src/appl/coal/*.c src/appl/coal/makefile src/appl/coal/*.ctl src/appl/coal/test \
	src/appl/coal/bak \
	src/appl/include/*.h \
	src/appl/tools/*.c src/appl/tools/Makefile src/appl/tools/*.txt src/appl/tools/*.sh \
	src/tools
gzip tar_appl_coal_dev1
