#---------------------------------------------------------------
#			directory
#---------------------------------------------------------------
DEVELOPHOME		= ../../..
DEVELOPBIN		= $(DEVELOPHOME)/bin
DEVELOPINC		= $(DEVELOPHOME)/include
DEVELOPLIB		= $(DEVELOPHOME)/lib
DEVELOPSRC		= $(DEVELOPHOME)/src
DEVELOPTOOLS	= $(DEVELOPHOME)/tools
DEVSRCTOOLS		= $(DEVELOPSRC)/tools
DEVELOPAKB		= $(DEVELOPSRC)/akb
DEVELOPLIB		= $(DEVELOPSRC)/lib
AKBNTMN			= $(DEVELOPAKB)/netm
AKBPROM			= $(DEVELOPAKB)/prom
AKBTRMN			= $(DEVELOPAKB)/trmm
AKBBSMN			= $(DEVELOPAKB)/bsmn
AKBSAMP			= $(DEVELOPAKB)/sample
AKBTLS			= $(DEVELOPAKB)/tools
AKBINC			= $(DEVELOPAKB)/include
LIBINC			= $(DEVELOPLIB)/include
LIBAKX			= $(DEVELOPLIB)/akx
LIBAKB			= $(DEVELOPLIB)/akb
LIBAKA			= $(DEVELOPLIB)/aka
LIBAKAS			= $(DEVELOPLIB)/akas
LIBTLS			= $(DEVELOPLIB)/tools
