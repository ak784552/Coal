/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/*********************************************************/
/*                                                       */
/*     aka.h                                             */
/*                                                       */
/*              coded by A.Kobayashi 2010.3.16           */
/*                                                       */
/*********************************************************/
#ifndef _AKA_H
#define _AKA_H

#include "akaconst.h"
#include "akastruct.h"
#include "akaprot.h"

typedef tdtMSG_COM		AKAMSGCOM;
typedef tdtWAIT_PACKET	tdtWAIT_OBJECT;

#define akaSetComTimeOut	akb_set_com_time_out

#endif	/* _AKA_H */
