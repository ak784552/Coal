#---------------------------------------------------------------
#
#			UNIX commands
#
#---------------------------------------------------------------
SHELL					= /bin/csh
RM						= /bin/rm
CP						= /bin/cp
MV						= /bin/mv
ECHO					= @/bin/echo
SYNC					= /bin/sync
GET						= myget
MAKE					= /usr/bin/make
AR						= /usr/bin/ar
RANLIB					= /usr/bin/ranlib
#RANLIB					= /usr/ccs/bin/ranlib
CC						= /bin/cc
#CC						= gcc
LINK					= /bin/cc
INSTALL					= /bin/install
SCCS					= /usr/ucb/sccs
CONFDIR					= ../../tools

