static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*******************************************************************/
/*        int   col_mn_term()                                      */
/*                                                                 */
/*  ������                                                         */
/*                                                                 */
/*  �߂�l                                                         */
/*        0                  : ��������@�@                        */
/*        -1                 : ���M�p�P�b�g����                    */
/*                                                                 */
/*  �����T�v                                                       */
/*        �p�P�b�g�̏������ݏ���                                   */
/*******************************************************************/
#include "colmn.h"

extern CLPRTBL       *pGLprocTable;
extern tdtLruScrHead *tpLruScrHeadImp;
extern tdtLruScrHead *tpLruScrHead;
extern XHASHB *xhpImportReserve;
extern MCAT2 *pGImplicit;

static void _free_const(scrconst)
ScrConstCt *scrconst;
{
	char *p;

	if (p=scrconst->pId) Free(p);
	Free(scrconst);
}

int col_mn_term()
{
	if (ADDRCHK(pGLprocTable->pha_vnam)) {
		akxs_xhash_free(pGLprocTable->pha_vnam);
		pGLprocTable->pha_vnam = NULL;
	}
/*
	if (ADDRCHK(pGLprocTable->pTBL_vnam)) {
		cl_free_var_ent(pGLprocTable->pTBL_vnam);
		Free(pGLprocTable->pTBL_vnam[0]);
		Free(pGLprocTable->pTBL_vnam);
		pGLprocTable->pTBL_vnam = NULL;
	}
*/
#if 1	/* 2021.7.13 */
	if (ADDRCHK(pGLprocTable->pha_gid)) {
		akxs_xhasl_free(pGLprocTable->pha_gid);
		pGLprocTable->pha_gid = NULL;
	}
#endif
#if 1	/* 2024.3.2 */
	if (ADDRCHK(pGLprocTable->pListImport)) {
		akxs_list_free(pGLprocTable->pListImport,_free_const);
	}
#endif
	cl_lru_scr_free(tpLruScrHeadImp);
	cl_lru_scr_free(tpLruScrHead);
	cl_tmp_const_clear(2);
#if 1	/* 2025.11.30 */
	if (ADDRCHK(xhpImportReserve)) {
		akxs_xhash_free(xhpImportReserve);
		xhpImportReserve = NULL;
	}
#endif
#if 1	/* 2026.10.12 */
/*
printf("cl_ct_clear: Free: pGImplicit=%08x\n",pGImplicit);
*/
	if (ADDRCHK(pGImplicit)) akxs_mseq_free(pGImplicit);
#endif
	return 0;
}
