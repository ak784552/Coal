//

define array char(10) a hash;// 10;
define const array b 10 = [1,,3,4.0D,5.0,'A','B',{'C',,'E'},8];
define const array c 10 = [1,2,,4,5.0D,6,7,8,9,10];
define mappedarray $m 11 10;
define mappedarray %p 1 10;
define mappedarray #s 1 10;
define array aa hash;// 10;
define array a3 hash;// 10;
define array d 10;
//define array b 10 = 1;
//define array BIN c 10 = 10;
proc main;
//	option  5 1;
//	option 13 1;

	print a;
	a['ABC']=10;
	a['XYZ']=20;
	aa['ABC']=30;
	aa['XYZ0']=40;
	print *a *aa;
//	y = *a + *aa;
//	y = *a - *aa;
	y = *a & *aa;
//	y = *a ^ *aa;
	print *y;
	loop each x in y;
		print x *x;
	end loop;

	print b *b;
	print c *c;
	y = *b | *c;
	print '*b | *c=' y *y;
	y = *b - *c;
	print '*b - *c=' y *y;
	y = *b & *c;
	print '*b & *c=' y *y;
	y = *b ^ *c;
	print '*b ^ *c=' y *y;

	print {1,2,3}+*b; 
	print {1,2,3}+3; 
	print {1,2,3}|3; 

	print {1,2,3,4}-{4,1};
	print {1,2,3,4}-4;
	print 3-{4,1};

	print {1,2,3,4}&{4,1,5};
	print {1,2,3,4}&4;
	print 1&{4,1};

	print {1,2,3,4}^{4,1,5};
	print {1,2,3,4}^4;
	print 2^{4,1};
	x1 = {1,2,3,4};
	x2 = {4,1,5};
	print (x1|x2)-(x1&x2);
	print ''-x1 ''&x1 ''^x1;
	print %1-x1;
	print f('') f(,);

	y = a;
	print y *y;
	y = *a;
	a['ABC']=100;
	print y *y;
	print a *a /d a;
	print ''-(*a) *(''-(*a)) /d ''-(*a);
//	y = *b * *c;

//	print "*(*b + *c)";
	x = *b + *c;
	print x *x;
//	print "*(*b - *c)";
	x = *b - *c;
	print x *x;
	print "*(*b & *c)";
	x = *b & *c;
	print x *x;
	print "*(*b | *c)";
	x = *b | *c;
	print x *x;
	return ERROR;
end proc;

func f(a);
	print a-{1,2};
	return ERROR;
end func;
