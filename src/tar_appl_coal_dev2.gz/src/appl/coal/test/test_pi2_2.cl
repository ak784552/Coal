//
//
//
proc main;
	double M,m,r,n,dr,d,dri,drj,drj0;
	int i,j,k,N,j0,mm;

	nn = (INT)%1;
	if nn<=0 thenl nn = 2;
	t0 = gettime();
	pi2 = PI;
	pi12=1.0/pi2;
	N=16000;
	n = N;
	$MAX_LOOP_WHILE = N+1;
	print /nq- "edit('%2d %9.3f %7d %10.9f <-- pi',0,0,0,pi2)";
	for k=1 to nn;
		r=1.0;
		dr=r/n;
		M=(n+1)*(n+1);
//print M;
		m=0.0;
		mm=0;
		drj0=r;
		dri =0.0;
		j0 = N;
		for i=0 to N;
			drj = drj0;
			dri2 = dri*dri;
			for j=j0 to 0 step -1;
				drj2=drj*drj;
				d = sqrt(dri2 + drj2);
				if d <= 1.0 then
					m += j+1;
					j0 = j;
					drj0 = drj;
					mm++;
//print j m;
					break;
				endif;
				drj -= dr;
			next;
			dri += dr;
		next;
//print i m mm;
		t = gettime()-t0;
		tt = 0;
		if t>=60.0 then
			tt = CINT(t/60.0);
			st = edit('%d:%05.3f',tt,t MOD 60.0);
		else
			st = edit('%5.3f',t);
		endif;
		st = lpad(st,9);
		pi = m/M*4;
		e = (pi2-pi)*pi12;
		s = CINT(n/t);
		print /nq- "edit('%2d %s %7d %10.9f %e %6d %d',k,st,N,pi,e,s,getmemused(1,1))";
		N+=N;
		n = N;
		$MAX_LOOP_WHILE = N+1;
	next;
	return ERROR;
end proc;
