//

import 'lib_iconv' as LIB_ICONV;
import 'lib_math';
//import 'test_import3';

//define a;
PROC main;
//	import 'lib_math';
//	print conv_opt repc;
	a='aaa';
//	print a;
//	print /x conv('ABC123',6);
	print /x "conv('ABC' & chr(0xf1) & chr(0xf2) & chr(0xf3),6)";
	print sind(30d);
	print LIB_MATH.sind(30d);
	fun();
	RETURN $ERROR;
END PROC;
//import test_ip;
function fun();
	print 'called fun';
	x = 'A';
	return ERROR;
end func;
