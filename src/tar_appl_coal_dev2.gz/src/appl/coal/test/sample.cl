//
//  sample.cl
//
proc main;
	putline('Hello World!',%1);
	print 'Hello World!' %1;
	echo 'Hello World!' %1;
	print getmemused(1,6) *$();
	return;
end proc;
