//
define array $a 10;
proc main argc ,argv(aa,bb,cc,dd);
	print %argv[0];

	print PROCNAME;
	print %0;
	print $argc %argv[0] %argv[1] %argv[2] %argv[3];
	print $aa $bb $cc $dd;
	exec ip proc1 'A' 'B' 3 "";
	print func1(%1,%2,%3,%4);
//	print func1();

	return $ERROR;
end proc;

proc proc1 argc ,argv(aa,bb,cc,dd);
	print PROCNAME;
	print "local %0";
	print $argc %argv[0] %argv[1] %argv[2] %argv[3] %argv[4];
	print $aa $bb $cc $dd;
//	print %argv[$dd] %argv[$a];
//	print $dd;
//	print nval(%argv[3],'NULL') ndef('%argv[3]','NULL');
	print nval($dd,'NULL') ndef('$dd','NULL');
//	print ndef($a,'NULL') ndef('$a','NULL');
	print argc=0;
	print %argv[0]=0;
	return $ERROR;
end proc;

func func1 argc ,argv(aa,bb,cc,dd);
//func func1 argc ,argv;
	print PROCNAME;
	print $argc %argv[0] %argv[1] %argv[2] %argv[3] %argv[4];
	print $aa $bb $cc $dd;
	print nval($dd,'NULL') ndef('$dd','NULL');
	return $ERROR;
end func;
