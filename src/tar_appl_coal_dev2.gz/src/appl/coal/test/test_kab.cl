//
option 10 1;
proc main;
	$kai_kab_ka = 4080;
	$kai_kab_su = 3000;
	$uri_kab_ka = 3960;
	exec ip sub1;
	$rieki1 = $rieki;

	$kai_kab_ka = 250;
	$kai_kab_su = 20000;
	$uri_kab_ka = 243;
	exec ip sub1;
	$rieki2 = $rieki;

	$rieki_total = $rieki1 + $rieki2;
print $rieki_total;
	return ERROR;
end proc;

proc sub1;
	$kai_ka = $kai_kab_ka * $kai_kab_su;
	$torix = $kai_ka;
	exec ip tesuryou;
	$kai_tesu = $tesu;
print $kai_kab_ka $kai_kab_su $kai_ka $kai_tesu;

	$uri_ka = $uri_kab_ka * $kai_kab_su;
	$torix = $uri_ka;
	exec ip tesuryou;
	$uri_tesu = $tesu;
print $uri_kab_ka $kai_kab_su $uri_ka $uri_tesu;

	$arari = $uri_ka - $kai_ka - ($kai_tesu + $uri_tesu);
	if ($arari > 0);
		$zei = $arari * 0.2;
	else;
		$zei = 0;
	end if;
	$rieki = $arari - $zei;
print $arari $rieki;

	return ERROR;
end proc;

proc tesuryou;
	if ($torix <= 200000);
		$tesu = 2940;
	elseif ($torix <= 300000);
		$tesu = max($torix*0.009555,2940);
	elseif ($torix <= 500000);
		$tesu = max($torix*0.006825,1837);
	elseif ($torix <= 700000);
		$tesu = $torix*0.007350 + 1103;
	elseif ($torix <= 1000000);
		$tesu = $torix*0.006321 + 1823;
	elseif ($torix <= 3000000);
		$tesu = $torix*0.005880 + 2264;
	elseif ($torix <= 5000000);
		$tesu = $torix*0.005660 + 2926;
	elseif ($torix <= 10000000);
		$tesu = $torix*0.004704 + 7703;
	elseif ($torix <= 30000000);
		$tesu = $torix*0.003822 + 16523;
	elseif ($torix <= 50000000);
		$tesu = $torix*0.001764 + 78263;
	else;
		$tesu = $torix*0.000735 + 129713;
	end if;

	$tesu = to_number($tesu,CLBIN);

	return ERROR;
end proc;
