//
proc main;
	for x=0 TO 10 STEP +2;
		echo x;
	endfor;
	for x=10 TO 0 STEP -2;
		echo x;
	endfor;
	for x=0 TO 3;
		echo x;
	endfor;

//	$MAX_LOOP_WHILE = 3;
//	for x=0 TO;
//	for x=0 To 1 n Step;
//	for x=0 TO 1 1;
//	for x=0 TO 10 STEP +2 1;
//	for x=0 TO 10 +2 STEP 1;
	for x=0 TO 10 +2 STE 1;
//	for x=0 TO 1 STEP;
		echo x;
	endfor;

	return ERROR;
end proc;
