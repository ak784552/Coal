#! /bin/coal
//
#*include "common.ch"
#*define yH01	"yh02 + \
	12"
#*define Abc(*)	"x*2 + '1'"
#+define _xxx	'12345'
#+define Xyz(a,b)	"a &+ ',' &+ b &+ _xxx"
#.define MAXDEFINE 1000
define definea[MAXDEFINE];
proc main;

	MAX_LOOP_WHILE=4;
	print space(10
);
	print abc(3);
//	print xyz(,123);
	print xyz('XXX',123);
	print Xyz('XXX',123);
	print YH01"A";
	a=1;
	print AAA;
	loop 3 _L
		print 'AA';
	_J

	if (%1) _LL
		print %1;
	_J
	else _L;
		print 'else';
	_JJ
	x = {1,2,3,4,5} ;
	print x;
	'ZZZ';
	return ERROR;
end proc;
