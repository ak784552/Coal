//
define array $a 100;
define array ah hash 10;
//define array %a 100;
//define array #a 100;
define mappedarray %a 1 10;
define mappedarray #a 1 10;

proc main;
	print %a[0] #a[0];
	print setarray(%a,1,2);
	print setarray(#a,1,2);
	print setarray($a,1,2);
	print setarray(ah,'ABC',11,'XYZ',22,,33,'OPQ',44);
	for each x in ah;
		print x.Index x.Value;
	next;
	return ERROR;
end proc;
