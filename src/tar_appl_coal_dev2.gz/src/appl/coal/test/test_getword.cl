//
define sspl[7];
proc main;
//	a = '  1 ,2, (3) , 4 ''5 6'' =X';
//	a = '  1 ,2, (3) , 4 ''5 6''';
	a = %1;
	print a;
	i = 0;
	sspl[0] = 0;
if %2 then
	while (n=getword(a,sspl)) >= 0 do;
		i++;
		print i n *sspl;
	end do;
else
	$1 = 0;
//	while (n=getword(a,1,' ,',1,1000)) >= 0 do;
	while (n=getword(a,1)) >= 0 do;
		i++;
		print i n $2 $3 $4 $5 $6;
	end do;
endif;
	print n;
	print $() sspl;
	return ERROR;
end proc;
