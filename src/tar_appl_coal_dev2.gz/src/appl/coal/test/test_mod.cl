//
proc main;

	print "10 mod 3";
	print "10.0 mod 3.6";
	x=cdec(10.0/3.6,20,0);
	print x;
	y = 10.0-x*3.6;
//	y = 3.0*3.6 - 10.0;
//	y = 10.0 - 3.0*3.6;
	print y;
	if y<0.0 thenl y += 3.6;
	print y;
	return $ERROR;
end proc;
