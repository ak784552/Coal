//
Class Counter static < s_counter;
	int i=0;
	f = XXX;
	func Counter();
		return 0;
	end func;
	func _count();
		return ++i;
	end func;
	func _count(a);
		return i += a;
	end func;
	func XXX;
		int xx=200;
		func _X;
			print xx;
			return 2000;
		end func;
	end func;
end class;

proc main;
/*
	print Counter._count();
	print Counter._count();
	print Counter._count(10);
*/
	print Counter.XXX._X();
/*
	print Counter.f._X();
	print system.putline('System.putline');
	print Counter._count();
	print Counter.ccc;
	print Counter.s_f(123);
	print Counter.ccc;
*/
	return ERROR;
end proc;

Class s_counter;
	char ccc='ABC';
	function s_f(x);
		ccc = x;
		return 0;
	end func;
end class;
