//
proc main;
	MAX_LOOP_WHILE = 3;
	y = 5;
	z = 2;
/*
	echo 'for x=0 To 5';
	for x=0 To 5;
		echo x /i x;
	endfor;

	echo 'for x=0 TO 5 STEP 1';
	for x=0 TO 5 STEP 1;
		echo x /i x;
	endfor;

	echo 'for x=5 TO 0 STEP -1';
	for x=5 TO 0 STEP -1;
		echo x /i x;
	endfor;

	echo 'for x=0 TO y STEP z;' /in+ y z;
	for x=0 TO y STEP z;
		echo x /i x;
	endfor;
*/
	z = -2;
	echo 'for x=5 TO 0 STEP z;' /in+ z;
	for x=5 TO 0 STEP z;
		echo x /i x;
	endfor;
/*
	n_f = 5;
	n_t = 5;
	n_i = 1;
	echo 'for x=n_f TO n_t STEP n_i' /in+ n_f n_t n_i;
	for x=n_f TO n_t STEP n_i;
		echo x /i x;
	endfor;
*/
	return ERROR;
end proc;
