//
define array $a hash 5;
PROC main;
//	$MAX_LOOP_WHILE = 5;
	print $MAX_LOOP_WHILE;
	int a = '1';
	print a /i a;
//	loop for "$x=0,$i=1;" "$x<3;" "$x++,$i+=2";
//	loop for "$x=0,$i=1" "$x<3" $x++,$i+=2;
	for (local int $x=0,block i=1;$x<10;i++,x++) as lfor;
//		x++;
		print $x $i /i $x $i;
		y = 100;
//		1/0;
	endfor;
	print $x $i y;

//	end do;
//	loop while 1;
	for ($x=0 ;$x<4;x++,x/0) as lfor2;
		print $x $i;
//	end for;
	next;
//	end loop;

	RETURN $ERROR;
END PROC;
