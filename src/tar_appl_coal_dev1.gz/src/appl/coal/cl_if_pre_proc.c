static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �h�e�R�}���h�O����                                     *
*                                                                             *
*      �֐����@�@�@�F�@int cl_if_pre_proc( pLeaf , pProc )                    *
*                                                                             *
*      ������      �F�@(I)Leaf          * pLeaf                               *
*                      (I)ProcCT		* pProc                               *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@D_ERROR                                                *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

int cl_if_pre_proc(pLeaf,pProc)
Leaf    *pLeaf;
ProcCT  *pProc;
{
	int  	rc, id;
/*	IfCB	*pIfCB;	*/
	BlockCB *pBlockCB;

	if (!pLeaf || !pProc) return D_ERROR;
	if ((id=pLeaf->cmd.cid) != C_IF && id != C_SWITCH && id != C_TRY) return D_ERROR;

	/* BlockCB���� */
	if (rc = cl_add_block_cb(pProc)) return rc;
	pBlockCB = pProc->pcrBlockCB;
	pBlockCB->cid = id;

#if 0
	/* IfCB���� */
	if (!(pIfCB = (IfCB *)Malloc(sizeof(IfCB)))) return D_ERROR;
	memset(pIfCB,0,sizeof(IfCB));
	if (!pProc->pTopIfCB) {
		pProc->pTopIfCB = pIfCB;
		pIfCB->preIfCB  = NULL;
	}
	else {
		if (!pProc->pcrIfCB) {	/* 10.26 Add Koba */
			Free(pIfCB);
			Free(pBlockCB);
			return D_ERROR;
		}
		pProc->pcrIfCB->nextIfCB = pIfCB;
		pIfCB->preIfCB = pProc->pcrIfCB;
	}
	pProc->pcrIfCB  = pIfCB;
/*
	pIfCB->nextIfCB = NULL;
	pIfCB->TureFlag = L_OFF;
	pIfCB->ElseFlag = L_OFF;
	pIfCB->EndFlag  = L_OFF;
*/
#endif

	return NORMAL;
}

/********************************/
/*								*/
/********************************/
int cl_add_block_cb(pProc)
ProcCT  *pProc;
{
	BlockCB *pBlockCB;
	BlockCB *WpreBlockCB,*WnextBlockCB;
	tdtINFO_PARM *WpEachParm;
	XHASHB *Wpha_vnam;

	if (!pProc) return D_ERROR;
#if 1
/*
printf("cl_add_block_cb:1: pTopBlockCB=%08x\n",pProc->pTopBlockCB);
*/
	if (pBlockCB=pProc->pTopBlockCB) {
/*
printf("cl_add_block_cb:2: pcrBlockCB=%08x\n",pProc->pcrBlockCB);
*/
		if (pProc->pcrBlockCB) {
			pBlockCB = pProc->pcrBlockCB->nextBlockCB;
/*
printf("cl_add_block_cb:3: pcrBlockCB->nextBlockCB=%08x\n",pBlockCB);
*/
		}
	}
	if (!pBlockCB) {
		/* BlockCB���� */
		if (!(pBlockCB = (BlockCB *)Malloc(sizeof(BlockCB)))) return D_ERROR;
		memset(pBlockCB,0,sizeof(BlockCB));
		if (!pProc->pTopBlockCB) {
			pProc->pTopBlockCB = pBlockCB;
		}
		else {
			pProc->pcrBlockCB->nextBlockCB = pBlockCB;
			pBlockCB->preBlockCB = pProc->pcrBlockCB;
		}
	}
	else {
		WpreBlockCB  = pBlockCB->preBlockCB;
		WnextBlockCB = pBlockCB->nextBlockCB;
		WpEachParm   = pBlockCB->pEachParm;
		Wpha_vnam    = pBlockCB->pha_vnam;	/* add 2026.5.11 */
		memset(pBlockCB,0,sizeof(BlockCB));
		pBlockCB->preBlockCB  = WpreBlockCB;
		pBlockCB->nextBlockCB = WnextBlockCB;
		pBlockCB->pEachParm   = WpEachParm;
		pBlockCB->pha_vnam    = Wpha_vnam;	/* add 2026.5.11 */
	}
	pBlockCB->iUsed = 1;
	pProc->pcrBlockCB = pBlockCB;
/*
printf("cl_add_block_cb:exit: pcrBlockCB=%08x\n",pProc->pcrBlockCB);
*/
#else
	if (pProc->pcrBlockCB && (pBlockCB=pProc->pcrBlockCB->nextBlockCB)) {
		WpreBlockCB  = pBlockCB->preBlockCB;
		WnextBlockCB = pBlockCB->nextBlockCB;
		WpEachParm   = pBlockCB->pEachParm;
		memset(pBlockCB,0,sizeof(BlockCB));
		pBlockCB->preBlockCB  = WpreBlockCB;
		pBlockCB->nextBlockCB = WnextBlockCB;
		pBlockCB->pEachParm   = WpEachParm;
	}
	else {
		/* BlockCB���� */
		if (!(pBlockCB = (BlockCB *)Malloc(sizeof(BlockCB)))) return D_ERROR;
		memset(pBlockCB,0,sizeof(BlockCB));
	}
	pBlockCB->iUsed = 1;

	if (!pProc->pTopBlockCB) {
		pProc->pTopBlockCB = pBlockCB;
	}
	else {
		if (!pProc->pcrBlockCB) {
			Free(pBlockCB);
			return D_ERROR;
		}
		pProc->pcrBlockCB->nextBlockCB = pBlockCB;
		pBlockCB->preBlockCB = pProc->pcrBlockCB;
	}
	pProc->pcrBlockCB  = pBlockCB;
#endif

	return NORMAL;
}

/********************************/
/*								*/
/********************************/
int cl_del_block_cb(pProc)
ProcCT  *pProc;
{
	BlockCB *pBlockCB;

	if (!pProc) return D_ERROR;

DEBUGOUTL1(161,"cl_del_block_cb:Enter pProc->pcrBlockCB=%08x",pProc->pcrBlockCB);

	if (!(pBlockCB=pProc->pcrBlockCB)) return -1;

	if (!pProc->pcrBlockCB->preBlockCB) {
		if (pBlockCB=pProc->pcrBlockCB) {
			if (pBlockCB->BlockName) Free(pBlockCB->BlockName);
			Free(pBlockCB);
		}
		pProc->pTopBlockCB = NULL;
		pProc->pcrBlockCB  = NULL;
	}
	else {
		pProc->pcrBlockCB = pProc->pcrBlockCB->preBlockCB;
		if (pBlockCB=pProc->pcrBlockCB->nextBlockCB) {
			if (pBlockCB->BlockName) Free(pBlockCB->BlockName);
			Free(pBlockCB);
		}
		pProc->pcrBlockCB->nextBlockCB = NULL;
	}

	return NORMAL;
}

/********************************/
/*								*/
/********************************/
BlockCB *cl_search_block_cb(proc,cid,opt)
ProcCT  *proc;
int cid,opt;	/* opt:0=from Top/1=from Cur to Top */
{
	BlockCB *pcrLCB;
	int opt2;

	if (!proc) return NULL;

DEBUGOUTL2(161,"cl_search_block_cb:Enter cid=%08x opt=%08x",cid,opt);
/*
printf("cl_search_block_cb:Enter cid=%08x opt=%08x\n",cid,opt);
*/
	if (opt) {
		opt2 = opt & 0x02;
		pcrLCB = proc->pcrBlockCB;
/*
printf("cl_search_block_cb: pcrLCB=%08x\n",pcrLCB);
*/
		while (pcrLCB) {

DEBUGOUTL1(161,"cl_search_block_cb: pcrLCB->cid=%08x",pcrLCB->cid);
/*
printf("cl_search_block_cb: pcrLCB->cid=%08x\n",pcrLCB->cid);
*/
			if (/*pcrLCB->iUsed && */pcrLCB->cid==cid) break;
			if (opt2) pcrLCB->iUsed = 0;
			pcrLCB = pcrLCB->preBlockCB;
		}
	}
	else {
		pcrLCB = proc->pTopBlockCB;
		while (pcrLCB) {
			if (pcrLCB->iUsed && pcrLCB->cid==cid) break;
			pcrLCB = pcrLCB->nextBlockCB;
		}
	}
	return pcrLCB;
}

/********************************/
/*								*/
/********************************/
int cl_reset_block_cb(pcrLCB)
BlockCB *pcrLCB;
{
	int cmnd;
	BlockCB *pcrLCB_next;

	if (!pcrLCB) return -1;
/*
printf("cl_reset_block_cb:Entry pcrLCB=%08x\n",pcrLCB);
*/
#if 1	/* 2026.5.8 */
	if (pcrLCB_next=pcrLCB->nextBlockCB) {
		cl_reset_block_cb(pcrLCB_next);
/*
printf("cl_reset_block_cb:return pcrLCB_next=%08x\n",pcrLCB_next);
*/
	}
/*
printf("cl_reset_block_cb:iUsed=%d\n",pcrLCB->iUsed);
*/
	if (!pcrLCB->iUsed) return 0;
	cl_block_clear_obj0(pcrLCB);
	cl_pha_vnam_free(pcrLCB->pha_vnam);
#endif
	pcrLCB->iLoopCounter = 0;
	pcrLCB->iLoopMax = 0;
	pcrLCB->iUsed = 0;
	pcrLCB->Blockleaf = NULL;
	/* SWITCH,TRY�ł́AD_OPT_ALC_LEAF�̃G���A�Ȃ̂�Free�ł��Ȃ� */
	if ((cmnd=pcrLCB->cid)!=C_SWITCH && cmnd!=C_TRY) {
/*
printf("cl_reset_block_cb: pcrLCB->cid=%08x\n",pcrLCB->cid);
*/
		if (pcrLCB->pSwParm) {
			Free(pcrLCB->pSwParm);
			pcrLCB->pSwParm = NULL;
		}
	}
	/* pcrLCB->pEachParm �́A�ė��p����̂�Free���Ȃ� */
	if (pcrLCB->pha_vnam) {
		akxs_xhash_reset(pcrLCB->pha_vnam);
	}
	if (pcrLCB->BlockName) {
		Free(pcrLCB->BlockName);
		pcrLCB->BlockName = NULL;
	}
	return 0;
}
