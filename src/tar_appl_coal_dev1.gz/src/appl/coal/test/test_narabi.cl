//
/*
define MAX_SOSU	=100000;
define int gFlag;
*/
def x 3 = 1..3;
proc main();

	print x {*x};

	print [(2..5)];
	b = [*(2..5)];
	print b[0];

	print [*('2'..'5')];

	a = '2'..'5';
	print *a;
	a = 2..5;
	print *a;

	return ERROR;
end proc;
