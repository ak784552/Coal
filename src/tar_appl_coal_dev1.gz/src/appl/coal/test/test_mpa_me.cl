//
//option 17 1;
//option 11 0x40;
option 20 532;
def int m;
proc main;
	if %1 then
		m = max((CBIN)%1,7);
		dec_max_pre(m);
	endif;
	napier = 1.0;
	kaijou = 1.0;
	if is(napier,'T')==3 then
		GOSA = 1.0e-15;
	elseif %1 then
		dec GOSA = 10.0**(4-m);
	else
		GOSA = 1.0E-50;
	endif;
	for i=1 to 50;
		kaijou *= i;
		a = 1.0 / kaijou;
		napier += a;
		print i kaijou /n- leng((CHAR)kaijou);
		print /p+30,2 a;
		print napier;
		if (abs(a) <= GOSA) thenl break;
	end loop;
	print /c- 0 M_E2;
	print /c- 11 PI2;
	return $ERROR;
end proc;
