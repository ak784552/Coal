//
proc main;
	print MAX_LOOP_WHILE;
	MAX_LOOP_WHILE = 10;
	print MAX_LOOP_WHILE;
	$i = 0;
//	loop;
	do;
		print 'do while' $i;
		$i++;
//	end while( $i < 5);
	end while( 1);
//	end until( $i>=5);
	return $ERROR;
end proc;
