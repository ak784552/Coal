//
proc main;
	print lpad('12345',10,'0');
	print rpad('12345',10,'0');
	fpad('12345',10,);

	print lpad('12�`�a�b',10,'X');
	print rpad('12�`�a�b',10,'�w');

	print lpadb('12345',10,'0');
	print rpadb('12345',10,'0');
	print lpadb('12�`�a�b',15,'X');
	print lpadb('123�`�a',15,'XY');
	print rpadb('123�`�a',15,'�w');

	print lpad('12�`�a�b34567890',-5);
	print rpad('12�`�a�b34567890',-5);
	print lpadb('12�`�a�b34567890',-5);
	print rpadb('12�`�a�b34567890',-5);

	return $ERROR;
end proc;

func fpad(vstr,len,pad);
	print lpad(vstr,len,pad);
	print rpad(vstr,len,pad);
	print lpadb(vstr,len,pad);
	print rpadb(vstr,len,pad);
	return 0;
end func;
