//
proc main;
	y = 5;
	z = 2;

	for x=0 To 5;
		echo x;
	endfor;
	for x=0 TO 5 STEP 1;
		echo x;
	endfor;
	for x=5 TO 0 STEP -1;
		echo x;
	endfor;
	for x=0 TO y STEP z;
		echo x;
	endfor;

	z = -2;
	for x=5 TO 0 STEP z;
		echo x;
	endfor;
	return ERROR;
end proc;
