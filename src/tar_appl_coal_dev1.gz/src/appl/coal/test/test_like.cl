//
proc main;
	print "'123' LIKE 123";
	print "123456789 LIKE '%567%'";
	x = '12' LIKE '%2';
	y = 'aBcDeF' iLIKE '%C_E%';
	print x y;
	a = ilike('abcDefg','%Ca%','Ab%');
	print a;
	a = like('abc%D_efg','%c\\%D%');
	b = like('abc%D_efg','%D\\_e%');
	print a b;
	a = like('abcxD.efg','%c\\%D%');
	b = like('abcyD.efg','%D\\_e%');
	print a b;

	print ilike('abcDefghiJk',3,'%Cde%',2);
	print ilike('abcDefghiJk',3,2,'%Cde%');
	print ilike('abcDefghiJk',3..5,'%Cde%');

	print like('abc�cefghiJk','%cDe%',2);

	print ilike('abc�cefghiJk','%cDe%',2);
	print ilike('abc�cefghiJk','%Cde%',2);
	print like('abc�cefghiJk','%Cde%',2);

	print like('abcDefghiJk','%Cde%');
	print ilike('abcDefghiJk',3,2,4);

	return ERROR;
end proc;
