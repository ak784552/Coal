//
def x 10;
def y hash;
PROC main;
	print /x+1 '1234567890';
	print /x+1 to_bulk('1234567890');
	print a;
	print x[0];
	print y['A'];
	print $1;
	print ndef('y[''B'']','ndef');
	print nval(y['B'],'nval');
	print is_null(y['B']);
	RETURN $ERROR;
END PROC;
