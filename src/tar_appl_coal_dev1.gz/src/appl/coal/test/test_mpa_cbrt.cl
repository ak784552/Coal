//
def int m;
proc main;
	if %2 then
		m = max((CBIN)%2,7);
		dec_max_pre(m);
	endif;
	print edit('%.50e',%1+0);
	print cbrt(%1+0);
//	print edit('%.15e',cbrt(%1+0));
	print u_cbrt(%1+0);
//	dec(20,15) x = u_cbrt(%1+0);
//	print x;
	return $ERROR;
end proc;

function u_cbrt(b);
	if is(b,'T')==3 then
		const d0 = 1.0e-15;
		KETA = 0;
	elseif %2 then
		const dec d0 = 10.0**(2-m);
		KETA = m - 4;
print /p+30,2 d0;
	else
		const d0 = 1.0E-50;
		KETA = 50;
	endif;
	s = 0;
	if b < 0.0 then
		b = -b;
		s = 1;
	end if;
	x0=b;
//	(x/3)**3-x>=0	x**3-27x>=0		x(x**2-27)>=0	x>=SQRT(27)
//	if (x0>=6) then x0/=3; endif;
	if (x0>=5.2) then x0/=3.0; endif;
print x0;
	for i=1 to 20 do
		xx=x0*x0;

		dd =((xx*x0)-b)/(3.0*xx);
print /p+20,2 dd;
		x1 = x0 - dd;

//		x1 = (x0+x0+b/xx)/3.0;
		d = abs((x0-x1)/x0);
print i /p+20Z x1  d;
		x0 = x1;
		if d<=d0 thenl break;
	end do;
	if s thenl x0 = -x0;
	x0 = round(x0,KETA,0x10);
	return x0;
end func;
