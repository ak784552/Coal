//
proc main;
	print decode(%1,'A','a','B','b','','NULL','x');
	print decode(%1,'A','a','B','b');
	return $ERROR;
end proc;
