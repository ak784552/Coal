//
//option 1 4;
define array aa 10;
define array hh hash;
define mappedarray %pp 1 10;
proc main;

	print countv(x);
//	print countv(x) abs(x) substr(x,1,1);
//	print countv(abs) abs(abs) substr(abs,1,1);

	print aa[0];
	print countv(aa);
	aa[0] = 2;
	++aa[0];
	print aa[0];
	print countv(aa);

	print hh['A'] *hh countv(hh);

	print countv(hh);
	hh['A'] = 1;
	hh['A']++;
	print hh['A'];
	print countv(hh);
	aa[0] += 1;
	print aa[0];
	hh['A'] += 1;
	print hh['A'];
	aa[0] = aa[0] + 1;
	print aa[0];
	hh['A'] = hh['A'] + 1;
	print hh['A'];
	aa[0] = hh['A'] + 10;
	print aa[0];
//	%pp[0] = 1;

	$1 = 2;
	$2 = 3;
	$$1 = 10;
	print $$1;

	return ERROR;
end proc;
