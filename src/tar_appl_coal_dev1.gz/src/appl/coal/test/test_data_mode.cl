//

//define array char(10) a hash;// 10;
define array b 10 = 1,,3,4.0D,5.0,'A','B',{'C',,'E'},8;
//define const array c 10 = 1,2,11..13,4,5.0D,6,7,8,b,*b;
define array c 10 = (11..13);
define array d 10 = **(2..10..2),'A','B';
define xx = 'A'..'H'..2;
//define x1 5 = **(3.1..5.6);
define x1 = **(3.1..5.6);
define x2 = {**(3.1..5.6..1.1)};
define x3 = *(5..7);
//define array d 10 = 2..10;
define type struct a_t
	a,
	b;
define var ta,tb as a_t;

proc main;
//	print xx;
//	print xx=**(1..3);
	print xx=**(3.1..5.6);
//	print xx;
//	print x1[0] x1[0][1];
//	print x1 x1[0];
	print x1;
	print x2 x2[0] x2[1];
	print x3;

	ta.a = 1;
	ta.b = 'A';
	print ta *ta;
	print "*ta + *tb";
/*
	for each z in ta;
		print z *z;
	next;
*/
	print "(2..5) + (-1.5..2.5)";
	f = *(2..5);
	g = *(-1.5..2.5);
	print f g "f + g";

	z = ('2'..'5') &+ ('A'..'C');
	z = [*('2'..'5')] &+ ['A'..'C'];
	print z;
//	e = *{1,2,3};
//	print e *e;
	print c *c c[0];
/*
	for each z in c;
		print z *z;
		print z.index *z.value;
	next;
*/
	print d *d d[0];
	print **d;
/*
	for each z in d;
		print z *z;
		print z.index z.value;
	next;

	e = {1,2,3};
	print e *e;

	print '----------';
	print b *b;
	print '----------';
	for each z in b;
		print *z;
	next;
	print '----------';
	for each z in *b;
		print *z;
	next;
	print '----------';
	print c *c;
*/
	x = *b;
	b[0] = 10;
	print '----------';
	print x *x;
	y = *c;
	c[0] = 'X';
	print y *y;

	f = *(2..5);
	print f *f countv(f);
	gg = ('2.1'..5.9);
	g = gg;
	print g *g countv(g) countv(*g);
	h = 'AX'..'ZY';
	print h *h countv(h) countv(*h);
	for each z in h;
		print *z;
	next;

	print '----------';
	i = 2..5;
	print i countv(i) countv(*i);
	for each z in i;
		print *z;
	next;
	print '----------';
	for each z in '2.1'..5.9;
	//	print *z;
		echo *z;
	next;
	print 2..5 *(2..5) *('AB'..'DE');
	echo 2..5 *(2..5) *('AB'..'DE');
	print **(2..5) **('AB'..'DE');
	print 2,3,4,5;

	h = *{1,2,3,4,5};
	print h;
	i = *[1,2,3,4,5];
	print i;
	return ERROR;
end proc;
