//
//
//
define MAX_SOSU	=100000;
define int gFlag;
int sosu MAX_SOSU =
	[ 2,  3,  5,  7, 11, 13, 17, 19, 23, 29,
	 31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
	 73, 79, 83, 89, 97,101,103,107,109,113,
	127,131];
proc main;

	char buf[20];
	dim ret,b,i,k,count as int;
	dim max_sosu,msosu,msosu2,i0,last,opt,max as int;

//	max_sosu=32;
//	max_sosu=10;
	max_sosu=countv(sosu);
	putline('initial max_sosu=',max_sosu);
	count_sosu=0;
	for (;;) do;
		elwrite('Entry max sosu number(end <=0) ==> ');
		num=getline();
		if num == 'max' then
			b = INT_MAX - 1000;
		else
			b=(CINT)num;
			if (b<=0) thenl break;
		end if;
		$max=b;
		MAX_LOOP_WHILE = b + 1000;
		msosu = sosu[max_sosu-1];
		//----------------------------------------------------------------
		// b ���Z�o�ςݑf���̌���菬�����Ƃ��́A�Z�o�ςݑf�����o�͂���
		//----------------------------------------------------------------
		if b <= msosu then
			b_so = 0;
			for i=0 to max_sosu;
				so = sosu[i];
				if so > b thenl break;
				if b_so+2 == so then
					printf('(%d %d) ',b_so,so);
				end if;
				b_so = so;
			next;
			echo;
			continue;
		end if;

		if (max9 = $max - 100)<=0 thenl max9 = ($max*9)/10;
		if (msosu>0 && b>msosu) then i0 = msosu + 2;
		elsel i0 = 3;
//print i0 $max;
		count=0;
		b_sosu = 0;
		for (i=i0;i<=$max;i+=2) do;
			if i> max9 || count==0 then gFlag = 1; else gFlag = 0; end if;
			if ((ret=akxg_sosu_chk_by_tbl_opt(sosu,max_sosu,i,opt))>0) then
				count_sosu++;
//				elwrite(' ',(CCHAR)i);
			//	if gFlag thenl print i count_sosu;
				if b_sosu+2 == i then
					printf('(%d %d) ',b_sosu,i);
			//	else
			//		putline(i);
				end if;
				b_sosu = i;
				if (max_sosu<MAX_SOSU && i>msosu) then
					sosu[max_sosu++] = msosu = i;
//					msosu2 = msosu*msosu;
//					elwrite('+');
//					print '+' max_sosu i;
//					print "(max_sosu % 100)";
//					if (max_sosu % 100)==0 thenl print '+' max_sosu;
				endif;
				if (count++ >=100) then
					putline();
					count=0;
				endif;
			elseif (ret < 0) then
				putline('\n*** table over');
				break;
			endif;
		next;
	/*
		putline('\nmax_sosu=',max_sosu);
		putline('max=',$max);
		for (i=0;i<max_sosu;i++) do
			elwrite(sosu[i] &+ ',');
			if !((i+1) % 10) thenl echo;
		next;
	*/
		echo;
		print max_sosu;
	next;
	return 0;
end proc;

func akxg_sosu_chk_by_tbl_opt(sosu,max_size,l,opt);
	dim i,mmax,m as int;
	dim ll,l1,l2 as int;

	mmax=max_size;
//print sosu max_size l opt;
	if (!(sosu)) thenl return -1;
	ll = l;

	if (ll < 2) then return 0;
	elseif (ll == 2) then return 1;
	elseif (ll <= 7) then
		if (ll&0x01) thenl return 1;
		return 0;
	end if;

	l2 = (CINT)sqrt(ll);
//print l2;
	for (i=0;i<mmax;i++) do;
		if (!(ll % (m=sosu[i]))) then
//			if gFlag thenl print ll m ll/m;
			break;
		endif;
		if (m > l2) thenl break;
	next;
	if (i>=mmax) then
//putline('akxg_sosu_chk: ll=',ll,' l2=',l2,' i='.i,' m=',m); 
		return -2;
	elseif (m>l2) thenl return 1;

//putline('akxg_sosu_chk: ll=',ll,' l2=',l2,' i='.i,' m=',m); 

	return 0;
end func;
