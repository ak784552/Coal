//
proc main;
	a=1;
	b=2;
	c=3;
	x1 = a ? b : c;
	x2 = a+1 ? b+2 : c+3;
	x3 = a ? b ? 'A' : 'B' : 'C';
	print x1 x2 x3;
	return ERROR;
end proc;
