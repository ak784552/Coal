//
//option 17 1;
//option 11 0x40;
//option 20 30;
def int m;
def GOSA;
proc main;
	if %2 then
		m = max((CBIN)%2,7);
		dec_max_pre(m);
	endif;
//	logparm /x 1 . 100;
	echo "'u_ln(' &+ %1 &+ ') ='" /p+ u_ln(%1+0.0);
//print "x is 'T'" x;
	echo "'  ln(' &+ %1 &+ ') = '" log(%1);
	return $ERROR;
end proc;

function u_ln(b);
	if b<=0.0 || b==1.0;
print 'b' b;
		return 0.0;
	endif;
	if is(b,'T')==3 then
		GOSA = 1.0e-15;
	elseif %2 then
		dec GOSA = 10.0**(20-m);
	else
		GOSA = 1.0E-21;
	endif;
	sig= 0;
	if b<1.0;
		b = 1.0/b;
		sig = 1;
	endif;
print b;
	n = 2.0;
	if b <= n then
		x = u_ln_sub(b);
	else
		x2 = u_ln_sub(n);
print x2;
		x1 = b;
		x = 0.0;
		while x1 > n;
			x1 = n==2 ? x1*0.5 : x1/n;
print x1;
			x += x2;
print x;
		end while;
		x += u_ln_sub(x1);
	endif;
	if sig; x = -x; endif;
print x;
	return x;
end func;

function u_ln_sub(dec b);
	if b<=0.0 thenl return b;
//�w���i���|�P�j�^�i���{�P�j�Ƃ����
//�Q�o�w�{�i�P�^�R�j�w�O�R�{�i�P�^�T�j�w�O�T�{�c�p;
	X = (b-1.0)/(b+1.0);
print X;
	Y=X;
	x1=Y;
	a=3.0;
	X *= X;
print X;
	for i=1 to 100;
		Y=Y*X;
		y=Y/a;
		x1=x1+y;
print i x1;
print a /p+30,2 y;
		if (abs(y) <= GOSA) thenl break;
		a=a+2.0;
	next;
	return x1+x1;
end func;
