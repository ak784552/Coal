//
proc main;
//	let options "" "" 2;
	let options "" "" 6;
	$1 = putline('1234567890');
	$r = putline('\nABCD');
	$n = putline('');
	$2 = putline('XYZ\n\n RT\n');
	$3 = putline('XYZ\r\n\n RT\n\r');
print $1 $r $n $2 $3;
	putline(0.0001d,',',0.0001);
	print 0.0001 0.0001d;
//	putline(to_bulk(strings(' ',513)));
	putline(SYSDATE);
	print SYSDATE;
	return $ERROR;
end proc;
