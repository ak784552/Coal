//
define array aa[10] ;
proc main;

	x = {-3.3..5f};
	print x;

	print 1..10;
	print *(1..10);
	array aa = 1..10;
	print *aa;

	array aa = (1..10);
	print *aa;

	char(3) c = 12..345;
	print c;

	a = 2.5..5.6;
	print a;
	b = *(2.5..5.6);
	print b;

	int ia = 2..5;
	print ia /d ia;
	int ib = *(2..5);
	print ib /d ib;

	double fa = 2.5f..5.6f;
	print fa /d fa;
	double fb = *(2.5f..5.6f);
	print fb /d fb;

	dec da = 2.5..5.6;
	print da /d da;
	dec db = *(2.5..5.6);
	print db /d db;

	char ca = 'ABC'..'XY';
	print ca /d ca;
	for each x in ca;
		print *x;
	next;
	char cb = *('A'..'D');
	print cb /d cb;

	redef char ca = 1..5;
	print ca /d ca;
	redef char cb = *ca;
	print cb /d cb;

	redef char ca = 3.2..6.4;
	print ca /d ca;
	redef char cb = *ca;
	print cb /d cb;

	redef char ca = 2.5f..7.5f;
	print ca /d ca;
	redef char cb = *ca;
	print cb /d cb;

//	char aa[10];
	aa[0] =  3.2..6.4;
	print aa[0] /d aa[0];

//	dump a 1 'A' b;

//	int i = {2.5..5.5};
	int i = first({2.5..5.5});
	print i;
	print *1 *i *x;
	print /d (1,2,3,4);
	say /d 1 'A' b;

	return $ERROR;
end proc;
