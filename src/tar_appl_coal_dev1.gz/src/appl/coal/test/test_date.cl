//
proc main;
	a = SYSDATE;
	print a;
	print "(CDATE)'2014/05/10'";

	b = SYSDATE + 1;
	print b;
	if a <> b thenl print 'a <> b';
	print "a == b";
	print "a == (CDATE)'2014/05/10'";
	print "a > (CDATE)'2014/05/10'";
	print "a MAX (CDATE)'2014/05/10'";
	print "a MIN (CDATE)'2014/05/10'";

	print "1.2 MAX 2.4";
	print "1.2 MIN 2.4";
	print "MAX(1.2,2.4,0.5)";
	print "MIN(1.2,2.4,0.5)";
	print "MAX('1.2','2.4','0.5')";
	print "MIN('1.2','2.4','0.5')";

	print "MAX(a,(CDATE)'2014/05/12',(CDATE)'2015/05/10')";
	print "MIN(a,(CDATE)'2014/05/08',(CDATE)'2013/05/10')";

	print CBIN(SYSDATE);
	print CDBL(SYSDATE);
	print CDEC(SYSDATE);
	print CBULK(SYSDATE);

	print leng(SYSDATE);
	print leng(1.5);

	return ERROR;
end proc;
