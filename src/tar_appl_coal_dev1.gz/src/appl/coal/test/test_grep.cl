//
def aa 10 = 'ab���`�wacdefg1234ABCDEF','xxYYyzZpQrabcAC','123456ACKUYYHS';
proc main;
	text = 'ab���`�wacdefg1234ABCDEF\nxxYYyzZpQrabcAC\n123456ACKUYYHS';
	print text;

	print glip(text,4,11,'ac','YY');
	print glip(OPT==>'il',text,4,11,'ac','YY');
	print glip(text,2,1,'AC','YY',0x100);
	print glip(`!cat test_agg.cl`,'*y');

	print grep(text,4,11,'ac','YY');
	print grep(text,4,11,'ac','YY',1);
	print grep(text,2,1,'AC','YY',0x100);
	print grep(`!cat test_agg.cl`,'E.*R');
	print grep(`!cat test_agg.cl`,'E.*R',1);
//	a = `shell('cat test_agg.cl')`;
//	print grep(a,'E.*R',1);

	text = {'ab���`�wacdefg1234ABCDEF','xxYYyzZpQrabcAC','123456ACKUYYHS'};
	print glip(text,4,11,'ab','YY');

	print glip(aa,2,1,'ab','YY',0x200);

	return ERROR;
end proc;
