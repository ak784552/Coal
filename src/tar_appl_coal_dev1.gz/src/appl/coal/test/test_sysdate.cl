//
define DATE dd[10]=(SYSDATE);
proc main;

//	print dd *dd;
	dd[1] = SYSDATE;
//	dd[2] = '2015/05/13 10:22:33';
	print *dd;
	a = SYSDATE;
	print a;
	print to_char(SYSDATE);
	print to_date('2014/4/2 13:5:35','%Y/%m/%d %H:%M:%S');
	print to_date('4','%m');
	print to_date('4 10','%m %M');
	print to_date('4','m');
	print to_date('4 10','m mi');
	b = "SYSDATE + 100";
	print b b-a;

	print (CDATE)'2015/01/01 00:00:00';
	print (CDATE)30;
	print CDATE(100);
	print (CDATE)'2015';
	print (CDATE)'151230';
	print CDATE('2015/12 00:00:01');
	print CDATE('20151203');
	print CDATE('2015-12-03');

	yyyy = date_add('yyyy',1,a);
	q = date_add('q',1,a);
	m = date_add('m',11,a);
	ww = date_add('ww',3,a);
	w = date_add('w',3,a);
	d = date_add('d',30,a);
	h = date_add('h',25,a);
	n = date_add('n',5,a);
	s = date_add('s',6,a);
	print yyyy q m ww w d h n s;
	print yyyy date_diff('yyyy',yyyy,a);
	print q date_diff('q',q,a) date_diff('m',q,a) date_diff('q',m,a);
	print m date_diff('m',m,a);
	print ww date_diff('ww',ww,a) date_diff('d',ww,a);
	print w date_diff('w',w,a);
	print d date_diff('d',d,a);
	print h date_diff('h',h,a) h date_diff('h',d,a);
	print n date_diff('n',n,a);
	print s date_diff('s',s,a);
	print add_months(a,7);
	print date_add('year',8,a);
	print date_add('mi',9,a);

	print to_date('2014.04.15 21:46:33','yyyy.mm.dd hh:mi:ss');
//	print to_date('2014.04/15 21:46:33','yyyy.mm.dd hh:mi:ss');

	print to_char(SYSDATE,'"sysdate"=yyyy.mm.dd hh:mi:ss.uuuuuu ddd');
	print to_char(SYSDATE,'hh24 h24 hh12 h12 month mon day dy uuu P');
	print last_day(a);

	print set_date_part(SYSDATE,'01/20','MM/DD');
	print set_date_part(SYSDATE,'5/20','MM/D');
	print set_date_part(SYSDATE,'2015/02','YYYY/M');
	print set_date_part(SYSDATE,'02/15 PM8','M/D PHH');
	print set_date_part(SYSDATE,'10','DDD');

	print to_date('01/20','MM/DD');
	print to_date('5/20','MM/D');
	print to_date('2015/02','YYYY/M');
	print to_date('02/15 PM8','M/D PHH');
	print to_date('10','DDD');
	print CBIN(SYSDATE);
	print CDBL(SYSDATE);
	print CDEC(SYSDATE);
	print CBULK(SYSDATE);

	print abs(SYSDATE);
	print leng(SYSDATE);
	print UNIX_DATE_FORMAT;
	print SQL_DATE_FORMAT;

	return ERROR;
end proc;
