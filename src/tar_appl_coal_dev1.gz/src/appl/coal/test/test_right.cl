//
PROC main;
	$a = '����12345678���l';
	$b = $a rightb 5;
	$c = $a right 5;
	print $a $b $c;
	print rightb($a,5) right($a,5);
	print rightb($a,-5) right($a,-5);
	RETURN $ERROR;
END PROC;
