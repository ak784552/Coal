//
define global gg = 'AA';
proc main;
	$1 = 3;
	print sub1(123) a /i a;
	$1 = 2;
	print sub1(234) a /i a;
	$1 = 1;
	print sub1('XYZ') a /i a;
	return ERROR;
end proc;

func sub1(x);
	private	char($1) a = x;
	return ERROR;
end func;
