//
proc main;
	x = to_bulk('12345');
//	x = '12345';
//	print /x+1 x;
//	print /x+1 100.0;
	SQL "" "" "select * from ERROR where col=$x";
//	SQL "" "" "select * from dual";
	print ERROR ERRMSG;
	return ERROR;
end proc;
