//
def aa 10 = ['�K','Y','X'];
proc main;
	option 18 %1;	// 1
	text = 'abcdefg1234ABCDEFxxYYzZ����%��pQrabcABC';
	w = '123';
	print text w instr(text,w);
	w = 'yy';
	print instr(text,'yy','A');
	print inistr(text,'yy','A');
	print "text instr 'yy'";
	print instr(text,'%');
	print instr(text,'��');
	print inrstr(text,'yy','A');
	print inirstr(text,'yy','A');
	print inrstr(text,10,'yy','A');
	print inirstr(text,10,'yy','A');
	print instr(text,10,10,'yy','A');
	print instr(text,5..10,'yy','A');

	print instr('X��Y��AB','��','�K','Y','X',2);
	print instr('X��Y��AB','�K','Y',2);
	print instr('X��Y��AB','��','B',2);

	print instr('X��Y��AB',aa,2);

	return ERROR;
end proc;
