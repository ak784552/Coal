//
PROC main;
#=if 1
	x = 'aBcD123_XyZ';
	print x;
	print "x to 'C'";
	print "x to 'P'";
	x = '���a���c�P�Q�R�Q�w���y';
	print x;
	print "x to 'P'";
	print "x to 'C'";
#=else
	try;
		loop;
			x = getline();
			print "x to 'C'";
			print "x to 'P'";
		end loop;
	end try;
#=endif
	RETURN $ERROR;
END PROC;
