static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************************************
*																			*
*	�@�\�@�F																*
*																			*
*	���́@�F�@int cl_user_func(pLeaf, name)									*
*	�����@�F�@(IN    ) Leaf	*pLeaf											*
*			�@(IN    ) char	*name											*
*																			*
*	�ߒl�@�F�@ERROR															*
*			�@NORMAL														*
*	�쐬�@�F																*
*	�X�V�@�F																*
*																			*
*****************************************************************************/
/********************************************/
/*	  coded by A.Kobayashi() 2010.XX.XX		*/
/*	  error code : -213220101�`-213229999	*/
/********************************************/
#include <colmn.h>

#define DEBUGP(x)

extern CLPRTBL *pCLprocTable;
extern GlobalCt  *pGlobTable;
extern int giOptions[];
extern M_FILE *m_stdin,*m_stdout,*m_stderr;

static int _print_info();
static int _print_info_data_kako(/*mcat,pInfoParm,varnam0,flgs*/);
static int _print_info_data();
static int _print_list();
static int _ppParm_check_set_flag(/*nparm,ppParm,flgs*/);
static void _set_flag(/*p,len,flgs*/);

#define MAX_FLGS	MAX_PRINT_FLGS

#define PRN_OPT_QUOT	D_PRN_OPT_QUOT	/* 0x0001 "string" */
#define PRN_OPT_DCMA	D_PRN_OPT_DCMA	/* 0x0002 output ',' delimiter */
#define PRN_OPT_NAME	0x0004	/* output 'name=' */
#define PRN_OPT_HEXO	0x0008	/* output hex mode */
#define PRN_OPT_ERRO	0x0010	/* use ERROROUT() to output */
#define PRN_OPT_DUMP	0x0020	/* dump mode */
#define PRN_OPT_MCMA	0x0040	/* output money ',' */
#define PRN_OPT_UMCA	0x0080	/* use PRN_OPT_MCMA */
#define PRN_OPT_INFO	0x0100	/* output info */
#define PRN_OPT_EXPF	0x0200	/* display exp format */
#define PRN_OPT_NEXF	0x0400	/* display not exp format */
#define PRN_OPT_EXPZ	0x0800	/* display exp zero suppress */
#define PRN_OPT_EXPN	0x1000	/* display exp zero not suppress */
#define PRN_OPT_TABS	D_PRN_OPT_TABS	/* 0x2000 output delimiter Tab insted of ' ' */
#define PRN_OPT_NGEN	D_PRN_OPT_NGEN	/* 0x4000 ��ʃf�[�^�ȊO���G���[�ɂ��Ȃ� */
#define PRN_OPT_LTGT	D_PRN_OPT_LTGT	/* 0x8000 enclosed in angle brackets(<>) */
#define PRN_OPT_LIST	D_PRN_OPT_LIST	/* 0x10000 display list [] */
#define PRN_OPT_RECR	0x20000	/* recursive * */
#define PRN_OPT_URED	0x40000	/* un redirect */
#define PRN_OPT_NINT	0x80000	/* not interval */
#define PRN_OPT_AVAL	0x40000000	/* avail print option */
#define PRN_OPT_EDIT	D_PRN_OPT_EDIT	/* 0x80000000 opt_edit�ł��� */

#define q_flg	(flgs[0] & PRN_OPT_QUOT)	/* "string" */
#define c_flg	(flgs[0] & PRN_OPT_DCMA)	/* output ',' */
#define n_flg	(flgs[0] & PRN_OPT_NAME)	/* output 'name=' */
#define x_flg	(flgs[0] & PRN_OPT_HEXO)	/* output hex mode */
#define e_flg	(flgs[0] & PRN_OPT_ERRO)	/* output ERROROUT() */
#define d_flg	(flgs[0] & PRN_OPT_DUMP)	/* dump mode */
/*		m_flg	*/							/* output money ',' */
#define i_flg	(flgs[0] & PRN_OPT_INFO)	/* output info */
#define p_flg	(flgs[0] & PRN_OPT_EXPF)	/* display exp */
#define np_flg	(flgs[0] & PRN_OPT_NEXF)	/* display not exp */
#define pz_flg	(flgs[0] & PRN_OPT_EXPZ)	/* display exp zero suppress */
#define pn_flg	(flgs[0] & PRN_OPT_EXPN)	/* display exp not zero suppress */
#define t_flg	(flgs[0] & PRN_OPT_TABS)	/* output delimiter Tab insted of ' ' */
#define l_flg	(flgs[0] & PRN_OPT_LIST)	/* display list [] */
#define r_flg	(flgs[0] & PRN_OPT_RECR)	/* recursive * */
#define u_flg	(flgs[0] & PRN_OPT_URED)	/* un redirect */
#define g_flg	(flgs[0] & PRN_OPT_LTGT)	/* display <> */

#define exp_pre	flgs[1]
#define exp_inx	flgs[2]
/*				flgs[3]  DEF_ZOK_DATA */
/*				flgs[4]  byte interval in hex mode */
/*				flgs[5]  option No.13 */

static tdtIterate_ctl tIter_ctl;

/********************************************/
/*	01										*/
/********************************************/
int cl_user_func(pLeaf, proc, name )
Leaf *pLeaf;
ProcCT  *proc;
char *name;
{
	int rc;
	parmList  *pparmList;
	tdtINFO_PARM InfoParm;
	char dummy[256];
	ProcCT  *procct;

DEBUGOUTL1(120,"cl_user_func:start.[%s]",name);
	if (!stricmp(name,"UserFunc")) {
		if (pLeaf->cmd.prmnum > 3) {
			pparmList = pLeaf->cmd.prmp[2];
			if (rc=cl_arg_to_char(pparmList,proc->Obj,&InfoParm,"UserFunc proc")) return rc;
			strnzcpy(dummy,InfoParm.pi_data,sizeof(dummy)-1);
		}
		else {
			ERROROUT("cl_user_func:no proc name");
			return (ECL_EX_EXEC);
		}
	}
	else strnzcpy(dummy,name,sizeof(dummy)-1);

DEBUGOUTL1(190,"cl_user_func:dummy=[%s]",dummy);
	if (!stricmp(dummy,"print") || !stricmp(dummy,"DT")) {
		cl_print_text(&pLeaf->cmd.prmp[3],proc->Obj,
		              pLeaf->cmd.prmnum-3,"Print: ");
	}
	else {
		ERROROUT("cl_user_func:undeifinition proc.");
		return (ECL_EX_EXEC);
	}
	if (!strcmp(name,"UserFunc")) {
		if (!(procct = cl_search_proc_ct())) return (ECL_SYSTEM_ERROR);
		cmn_set_stat(RET_PR,&procct->ptype,L_ON);
	}
	return NORMAL;
}

/********************************************/
/*	02										*/
/********************************************/
static int _set_flag_sub(p,flgs)
char *p;
int flgs[];
{
	char c,c1,w[2];
	int i,print_opt,opt,iset;
/*
printf("\n_set_flag_sub: *p=[%s]\n",p);
*/
	p++;
	c = *p++;
	c1 = *p;
	print_opt = flgs[0];
	iset = 0;
	if (c == 'm') {
		i = 7;
		if (c1 == '-') iset = -1;
		else if (c1 == '+') iset = 1;
		if (iset) {
			print_opt |= PRN_OPT_UMCA;
			if (iset > 0)
				print_opt |= PRN_OPT_MCMA;
			else
				print_opt &= ~PRN_OPT_MCMA;
		}
		else
			print_opt &= ~(PRN_OPT_UMCA | PRN_OPT_MCMA);
	}
	else {
		if (c1 == '-') iset = -1;
		else iset = 1;
		w[0] = c;
		w[1] = '\0';
		i = akxs_in_str_opt("qcnxedm,ip   t glru",w,0);
		if (i >0) {
			opt = 1;
			if (i > 1) opt = 1<<(i-1);
			if (iset > 0) print_opt |= opt;
			else print_opt &= ~opt;
		}
	}
/*
printf("_set_flag_sub: i=%d print_opt=%08x\n",i,print_opt);
*/
	flgs[0] = print_opt;
	return i;
}

/********************************************/
/*	03										*/
/*	/p[+|-][pre][Z|N|R][{,|.}[inx[R]]]		*/
/*	/x[+|-][intval[Z]]						*/
/********************************************/
int cl_print_set_flag(p,len,flgs)
char *p;
int len,flgs[];
{
	char c,c1,*pp,w[4],ww[2];
	int i,is,ie,n,pos,nlen,val,iNMPA10,len0,rc;

	if (!p || !flgs || len<0) return -1;
	len0 = len;
	w[0] = '/';
	w[3] = '\0';
	p++;
	len--;
	n = 0;
	pp = p;
	c = 'q';		/* add 2923.10.30 */
	while (len >= 0) {
/*
printf("_set_flag: len=%d p=[%s]\n",len,p);
*/
		c = *p++;
		len--;
/*
printf("_set_flag:1 len=%d c=[%c] n=%d\n",len,c,n);
*/
		/* 2923.10.30 */
		ww[0] = c;
		ww[1] = '\0';
		i = akxs_in_str_opt("+-qcnxedmiptglru",ww,0);
/*
printf("_set_flag:1 i=%d\n",i);
*/
		if (c=='+' || c=='-' || !c || !i) {
			if (!i) len++;
			w[2] = c;
			rc = 0;
			while (n-- > 0) {
				w[1] = *pp++;
				if ((rc=_set_flag_sub(w,flgs)) <= 0) break;
			}
			/* 2923.10.30 */
			if (!c || rc<=0 || !i) break;
			n = 0;
			pp = p;
		}
		else if (c=='p' || c=='x') {
/*
printf("_set_flag:2 len=%d c=[%c]\n",len,*p);
*/
			if (c == 'x') flgs[0] |= PRN_OPT_HEXO;
			c1 = c;
			if ((c=*p)=='+' || c=='-') {
				p++;
				len--;
				if (c1 == 'x') {
					if (c == '+') flgs[0] |= PRN_OPT_HEXO;
					else flgs[0] &= ~PRN_OPT_HEXO;
				}
				else {
					if (c == '+') {
						flgs[0] |= PRN_OPT_EXPF;
						flgs[0] &= ~PRN_OPT_NEXF;
					}
					else {
						flgs[0] |= PRN_OPT_NEXF;
						flgs[0] &= ~PRN_OPT_EXPF;
					}
				}
			}
/*
printf("_set_flag:3 len=%d c=[%c]\n",len,*p);
*/
			c = akxcupper(*p);
			if (c>='0' && c<='9') {
				pos = akxccvn2(10,p,len,&val,&nlen);
/*
printf("_set_flag:akxccvn2 1: pos=%d nlen=%d p=[%s]\n",pos,nlen,p);
*/
				if (pos < 0) break;
				if (c1 == 'x') {
					flgs[4] = val;
					if (!val) flgs[0] |= PRN_OPT_NINT;
				}
				else {
					exp_pre = val;
					iNMPA10 = m_get_nmpa10();
					if (exp_pre > iNMPA10) exp_pre = iNMPA10;
				}
				p += nlen;
				len -= nlen;
				c = akxcupper(*p);
				if (c1=='x' && c=='Z') flgs[4] = -flgs[4];
			}
			if (c1 == 'p') {
				if (c=='Z' || c=='N' || c=='R') {
					if (c == 'Z') {
						flgs[0] |= PRN_OPT_EXPZ;
						flgs[0] &= ~PRN_OPT_EXPN;
					}
					else if (c == 'N') {
						flgs[0] |= PRN_OPT_EXPN;
						flgs[0] &= ~PRN_OPT_EXPZ;
					}
					else exp_pre = -1;
					p++;
					len--;
					c = *p;
				}
				if (c==',' || c=='.') {	/* add '.' 2021.11.29 */
					p++;
					len--;
					c = akxcupper(*p);
					if (c>='0' && c<='9') {
						pos = akxccvn2(10,p,len,&exp_inx,&nlen);
/*
printf("_set_flag:akxccvn2 2: pos=%d nlen=%d p=[%s]\n",pos,nlen,p);
*/
						if (pos < 0) break;
						if (exp_inx > 5) exp_inx = 5;
						p += nlen;
						len -= nlen;
						c = akxcupper(*p);
					}
					if (c == 'R') {
						exp_inx = -1;
						p++;
						len--;
						c = *p;
					}
					if (c && c!=' ') break;
				}
			}
/*
printf("_set_flag: flgs[0]=%08x exp_pre=%d  exp_inx=%d\n",flgs[0],exp_pre,exp_inx);
*/
			pp = p;
		}
		else n++;
	}
/*
printf("_set_flag: flgs=%08x %d %d\n",flgs[0],flgs[1],flgs[2]);
*/
	/* 2923.10.30 */
	if (c=='/') len--;
	return len0-len;
}

/********************************************/
/*	04										*/
/********************************************/
static int _do_print_name(line,line_len)
char *line;
int  line_len;
{
	char buf[256],c;
	int ret,rc,n,iParm[4],n0,iUL;
	SSPL_S ssp;
/*
printf("_do_print_name:Enter line_len=%d line=[%s]\n",line_len,line);
*/
	ssp.sp = 0;
	ssp.wd = buf;
	ssp.wdmax = sizeof(buf);
	n0 = ret = 0;
	while (!ret) {
		n = cmpgwnsl(line,line_len,&ssp,0);
/*
printf("_do_print_name: n0=%d n=%d wd=[%s]\n",n0,n,ssp.wd);
*/
		if (n <= 0) break;
		if (n <= 100) {		/* �L�� */
			if ((n0<=8 || n0==98) && (n==24 || n==25)) ;	/* �P�����Z�q(+-) */
			else ret = 1;
		}
		else if (n==4000 && !strcmp(ssp.wd,D_STR_NAME_NULL)) ;	/* NULL */
		else if (n>=5000 && n<6000) {	/* �萔 */
			if ((c=*ssp.wd)=='\'' || c=='"') ;
			else {
				rc = akxqnumber(ssp.wd,n,0,NULL);
/*
printf("_do_print_name: rc=%d\n",rc);
*/
				if (rc >= 0) {
					iUL= rc & AKX_NUM_UL;
					rc &= ~AKX_NUM_UL;
					if (iUL) ret = 1;
					else if (rc<2 || rc>8) ret = 1;
				}
				else ret = 1;
			}
		}
		else ret = 1;
		n0 = n;
	}
/*
printf("_do_print_name:Exit ret=%d\n",ret);
*/
	return ret;
}

/********************************************/
/*	05										*/
/*	opt : 0x01 :=0 "," or " " or TAB		*/
/*					c_flg���D��				*/
/*				=1 "," + (" " or TAB)		*/
/*		  0x02 :=1 Ignore c_flg				*/
/*		  0x04 :=1 Ignore t_flg				*/
/********************************************/
int cl_print_dlm(dlm,flgs,opt)
char *dlm;
int flgs[],opt;
{
	char *p;
	int ic_flg,it_flg;

	ic_flg = c_flg;
	it_flg = t_flg;
	if (opt & 0x02) ic_flg = 0;
	if (opt & 0x04) it_flg = 0;
	p = dlm;
	if (ic_flg) *p++ = ',';
	if (!ic_flg || (opt & 0x01)) {
		if (!(opt & 0x01)) p = dlm;
		if (it_flg) *p = '\t';
		else *p = ' ';
		p++;
	}
	*p = '\0';
/*
printf("cl_print_dlm:Exit opt=%02x ic_flg=%08x it_flg=%08x dlm=[%s]\n",opt,ic_flg,it_flg,dlm);
*/
	return strlen(dlm);
}

static void _print_dlm(mcat,flgs,opt)
MCAT *mcat;
int flgs[],opt;
{
	char dlm[3],*p;
	/* 2025.6.8 */

	cl_print_dlm(dlm,flgs,opt);
	akxtmcats(mcat,dlm);
}

/************************************/
/*	06 �z�Q�Ɠo�^addr�擾			*/
/************************************/
char *cl_get_circ_addr(pIndex,pTBL)
tdtArrayIndex *pIndex;
tdtINFO_PARM ***pTBL;
{
	char *p;

	if (!(p = (char *)pTBL)) {
		if (pIndex) {
			if (!(p = (char *)pIndex->xhp)) p = (char *)pIndex->pVarIndex;
		}
	}
	return p;
}

/********************************************/
/*	07										*/
/********************************************/
char *cl_get_attr_name_opt(iParm,fixed)
int  iParm[],fixed;
{
	static char *name[]={"variant","char","int","double","dec","bulk","date","variant",""};
	static char *nameF[]={"Variant","Char","Int","Double","Dec","Bulk","Date","Variant",""};
	static char *nameU[]={"uint","ulong","long"};
	static char *nameUF[]={"UInt","ULong","Long"};
	static char dummy[30];
	int attr,size,pre,sca;
	char *p,**nama,**namu;

	attr = iParm[0];
	size = iParm[1];
	pre  = iParm[2];
	sca  = iParm[3];
/*
printf("cl_get_attr_name: attr=%d size=%d pre=%d sca=%04x\n",attr,size,pre,sca);
*/
	if (fixed) nama = nameF;
	else nama = name;
	if (attr>=0 && attr<=7) p = nama[attr];
	else p = "other";
	switch (attr) {
	case DEF_ZOK_CHAR:
	case DEF_ZOK_BULK:
		if (size > 0) {
			sprintf(dummy,"%s(%d)",p,size);
			p = dummy;
		}
		break;
	case DEF_ZOK_BINA:
		if (fixed) namu = nameUF;
		else namu = nameU;
		if (sca & D_DATA_UNSIGNED) p = namu[0];
#if defined(_LP64)	/* 2021.9.6 */
		if (size == sizeof(long)) {
			if (sca & D_DATA_UNSIGNED) p = namu[1];
			else p = namu[2];
		}
#endif
		break;
	case DEF_ZOK_DECI:
		if (pre > 0) {
			sprintf(dummy,"%s(%d,%d)",p,pre,sca);
			p = dummy;
		}
		break;
	}
/*
printf("cl_get_attr_name: p=[%s]\n",p);
*/
	return p;
}

/****************************************/
/*	08									*/
/****************************************/
char *cl_get_scope_name_from_aux1(i)
int i;
{
/*
	static char *scope[]={"",D_STR_NAME_LOCAL,D_STR_NAME_PRIVATE,D_STR_NAME_PUBLIC,D_STR_NAME_GLOBAL};
*/
	char *nam;
/*
	i &= D_AUX1_VAR_SCOPE;
	if (i <= 4) nam = scope[i];
*/
	if (i & D_AUX1_LOCAL_VAR) nam = D_STR_NAME_LOCAL;
	else if (i & D_AUX1_PRIVATE_VAR) nam = D_STR_NAME_PRIVATE;
	else if (i & D_AUX1_PUBLIC_VAR) nam = D_STR_NAME_PUBLIC;
	else if (i & D_AUX1_GLOBAL_VAR) nam = D_STR_NAME_GLOBAL;
	else nam = "";
	return nam;
}

/********************************************/
/*	09										*/
/********************************************/
static int _print_attr(mcat,pInfoParm,iParm)
MCAT *mcat;
tdtINFO_PARM *pInfoParm;
int  iParm[];
{
	char buf[30];

	*buf = '\0';
	cl_print_attr(buf,sizeof(buf),pInfoParm,iParm);
	akxtmcats(mcat,buf);
	return 0;
}

/********************************************/
/*	09-2									*/
/********************************************/
static int _print_attr_range(mcat,alen,pInfoParm,iParm)
MCAT *mcat;
tdtINFO_PARM *pInfoParm;
int alen,iParm[];
{
	tdtINFO_PARM tInfoParm;
	char *p;
	int iCOMPLEX;

	if (alen & D_AULN_RANGE_DATA) {
		iCOMPLEX = alen & D_AULN_COMPLEX_DATA;
		if (iCOMPLEX) {
			p = "+";
			if (pInfoParm) {
				cl_gx_copy_info(&tInfoParm,pInfoParm);
				tInfoParm.pi_scale |= D_DATA_IMAGE;
				pInfoParm = &tInfoParm;
			}
		}
		else if (alen & D_AULN_RATIONAL) p = "/";
		else p = "..";
		akxtmcats(mcat,p);
		_print_attr(mcat,pInfoParm,iParm);
		if (iCOMPLEX && !pInfoParm) akxtmcats(mcat," i");
	}
	return 0;
}

/********************************************/
/*	10										*/
/********************************************/
static int _print_data(mcat,pInfoParm,flgs)
MCAT *mcat;
tdtINFO_PARM *pInfoParm;
int flgs[];
{
	int rc,i,len,opt_conv,pre,m_opt,intval,iVal[2],iIMAGE,pos,code_type,atr;
	int iOpta[MAX_PRINT_FLGS],opt13;
	long Value;
	double dValue,dw;
	char dummy[513],*p,id,*fmt,wrk[10],c,*pp;
	MPA *mpa;
	tdtINFO_PARM tInfoParm,tInfo[3],*ppParm[3];

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_print_data:",pInfoParm,0,0);

	if (cl_check_addr(pInfoParm,dummy,sizeof(dummy))) {
		akxtmcats(mcat,dummy);
		return 0;
	}
	if (cl_is_null_parm(pInfoParm)) return 0;
	/* 2024.4.6 */
	else if (cl_is_null_value(pInfoParm)) {
		akxtmcats(mcat,D_STR_NAME_NULL);
		return 0;
	}
	id = pInfoParm->pi_id;
	len = pInfoParm->pi_dlen;
	p = pInfoParm->pi_data;
	atr = pInfoParm->pi_attr;
/*
printf("_print_data: p=%08x len=%d\n",p,len);
*/
	iIMAGE = pInfoParm->pi_scale & D_DATA_IMAGE;
	/* 2024.5.11 */
	if (flgs[0] & PRN_OPT_UMCA) {
		if (flgs[0] & PRN_OPT_MCMA) m_opt = 1;
		else m_opt = -1;
	}
	else m_opt = pGlobTable->options[12] & 0x20;
	if (atr>=2 && atr<=4 && m_opt>0) {
		cl_edit_sub(&pp,"%m",1,&pInfoParm,flgs);
		akxtmcats(mcat,pp);
		return 0;
	}
	switch (atr) {
	case DEF_ZOK_CHAR:
		/* 2023.7.22 *//* 2024.4.6 1-->0 */
		if (x_flg && id==' ') {
			/* 2026.1.6 *//* �����`�F�b�N�́Aakxcxtocn()�ł���Ă��� */
			intval = flgs[4];
			if (!(flgs[0] & PRN_OPT_NINT)) {
				if (!intval) intval = -16;
			}
			i = akxcxtocn(p,len,dummy,sizeof(dummy),intval);
			akxtmcatz(mcat,dummy,i);
		}
		else {
			if (q_flg) akxtmcats(mcat,"\"");
			if (p) {
				if (id==D_DATA_ID_FUNCTION && (c=*p)>='0' && c<='9') {
					len = akxstrnlen(p,len);
					i = akxnskipto(p,len," ");
					p += i+1;
				}
				len = akxstrnlen(p,len);
				pp = p;
				if (code_type = pInfoParm->pi_code) {
					opt_conv = (code_type<<8) | (cl_get_option(9,0) & 0x10)<<12;
					len = akxc_file_code_conv(&pp,p,len,0,opt_conv);	/* INPUT��stdin�́A0000ff00 */
					if (!pp) pp = p;
				}
				akxtmcatz(mcat,pp,len);
				if (p != pp) Free(pp);
				if (id==D_DATA_ID_FUNCTION || id==D_DATA_ID_CLMETHOD || id==D_DATA_ID_PROC)
					akxtmcats(mcat,"()");
			}
			if (q_flg) akxtmcats(mcat,"\"");
		}
		break;
	case DEF_ZOK_BINA:
		if (len) {
			Value = cl_get_data_long(pInfoParm);
#if defined(_LP64)
			if (len == sizeof(int)) {
				intval = Value;
				if (x_flg) fmt = "0x%08x";
				else if (pInfoParm->pi_scale & D_DATA_UNSIGNED) fmt = "%u";
				else fmt = "%d";
				sprintf(dummy,fmt,intval);
			}
			else {
				if (x_flg) fmt = "0x%016lx";
				else if (pInfoParm->pi_scale & D_DATA_UNSIGNED) fmt = "%lu";
				else fmt = "%ld";
				sprintf(dummy,fmt,Value);
/*
printf("_print_data: Value=%lu\n",Value);
*/
			}
#else
			if (x_flg) fmt = "0x%08x";
			else if (pInfoParm->pi_scale & D_DATA_UNSIGNED) fmt = "%u";
			else fmt = "%d";
			sprintf(dummy,fmt,Value);
#endif
			akxtmcats(mcat,dummy);
			if (iIMAGE) akxtmcats(mcat,"i");
		}
		else akxtmcats(mcat,"null");
		break;
	case DEF_ZOK_FLOA:
		if (len) {
			memcpy((char *)&dValue,p,sizeof(double));
			if (x_flg) {
				akxcxtoc(&dValue,sizeof(double),dummy);
				dummy[len*2] = '\0';
			}
			else {
				/* 2025.6.8 */
				cl_double_to_str(dummy,sizeof(dummy),dValue,flgs);
			}
			akxtmcats(mcat,dummy);
			if (cl_get_option(11,0) & 0x400) akxtmcats(mcat,"D");
			if (iIMAGE) akxtmcats(mcat,"i");
		}
		else akxtmcats(mcat,"null");
		break;
	case DEF_ZOK_DECI:
		if (len > 0) {
			/* 2025.4.1 */
			if ((rc=cl_rational_yakubun(&tInfoParm,pInfoParm)) < 0) return rc;
			else if (rc) {
				pInfoParm = &tInfoParm;
				p = pInfoParm->pi_data;
			}
			mpa = (MPA *)p;
			if (x_flg) {
				/* 2026.1.6 */
				intval = flgs[4];
				if (!(flgs[0] & PRN_OPT_NINT)) {
					if (!intval) intval = -2;
				}
				akxcxtocn(p,len,dummy,sizeof(dummy),intval);
			}
			else {
/*
printf("_print_data: options[10],[19]=%08x %08x\n",pGlobTable->options[10],pGlobTable->options[19]);
*/
				if (flgs[0] & PRN_OPT_UMCA) {
					if (flgs[0] & PRN_OPT_MCMA) m_opt = 1;
					else m_opt = -1;
				}
				else
					m_opt = pGlobTable->options[12] & 0x20;
				/* 2025.6.8 add opt_edit */
				rc = cl_mpa2an(mpa,dummy,sizeof(dummy),m_opt,pInfoParm->pi_hlen,pInfoParm->pi_pos,flgs);
				if (rc < 0) {
					sprintf(dummy,"##ERR rc=%d##",rc);
				}
			}
			akxtmcats(mcat,dummy);
			if (iIMAGE) akxtmcats(mcat,"i");
		}
		else akxtmcats(mcat,"null");
		break;
	case DEF_ZOK_DATE:
		if (len > 0) {
			mpa = (MPA *)p;
			if (x_flg) {
				len = mpa->len;
				akxcxtoc(mpa->num,len,dummy);
				dummy[len*2] = '\0';
				p = dummy;
			}
			else {
				/* 2021.6.1 */
				p = D_SQL_DATE_FORMAT;
				*dummy = '(';
				akxc_date2str(dummy+1,sizeof(dummy)-2,p,strlen(p),mpa);
				p = dummy;
				strcpy(p+strlen(p),")");
/*
printf("_print_data: p=[%s]\n",p);
*/
			}
		}
		else p = "null";
		akxtmcats(mcat,p);
		break;
	case DEF_ZOK_VARI:
		akxtmcats(mcat,"**VARI:no data**");
		break;
	case 0:
		akxtmcats(mcat,"**no data**");
		break;
	case DEF_ZOK_BULK:
		akxtmcats(mcat,"**BULK**");
		if (len > 0) {
			if ((intval=flgs[4]) > 0) {
				if (intval < len) len = intval;
				if (len > 4096) len = 4096;
			}
			else if (len > 512) {
				len = 512;
				PRINTOUTL1(0,"BULK data too long len=%d",pInfoParm->pi_dlen);
			}
			akxtmcats(mcat,"\n");
			akxafxdmp_opt((FILE *)mcat,"BULK",p,len,"-m");
			akxtmcats(mcat,"\n");
		/*	akxaxdump("BULK",p,len);
			printf("\n");	*/
		}
		break;
	default:
		akxtmcats(mcat,"**INVALID**");
		if (len > 0) {
			if (len > 512) {
				len = 512;
			}
			akxaxdump("INVALID",pInfoParm,sizeof(tdtINFO_PARM));
			printf("\n");
		}
		return 0;
	}
	if (id==' ' && (pInfoParm->pi_alen & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA))) {
/*
printf("_print_data: pi_alen=%04x\n",pInfoParm->pi_alen);
*/
		if (pInfoParm->pi_alen & D_AULN_COMPLEX_DATA) p = "+";
		else if (pInfoParm->pi_alen & D_AULN_RATIONAL) p = "/";
		else p = "..";
		pos = akxtmcats(mcat,p);
		for (i=0;i<3;i++) ppParm[i] = &tInfo[i];
		if ((rc=cl_get_range_info(pInfoParm,ppParm,iVal,0)) < 0) return rc;
		_print_data(mcat,ppParm[1],flgs);
		if (*(mcat->mc_bufp+pos) == '-') {
			mcat->mc_ipos = pos;
			akxtmcats(mcat,"(");
			_print_data(mcat,ppParm[1],flgs);
			akxtmcats(mcat,")");
		}
	/*	if (pInfoParm->pi_alen & D_AULN_COMPLEX_DATA) akxtmcats(mcat,"i");	*/
		if (pInfoParm->pi_alen & D_AULN_RANGE_INTVAL) {
			akxtmcats(mcat,"..");
/*
printf("_print_data: term=%d interval=%d\n",ppParm[2]->pi_hlen,ppParm[2]->pi_pos);
*/
			if (pInfoParm->pi_attr==DEF_ZOK_DATE && (i=ppParm[2]->pi_hlen)>0) {
				wrk[0] = akxc_get_term_char(i);
				wrk[1] = '\0';
				sprintf(dummy,"'%s %d'",wrk,ppParm[2]->pi_pos);
				akxtmcats(mcat,dummy);
			}
			else _print_data(mcat,ppParm[2],flgs);
		}
	}
	return 0;
}

/********************************************/
/*	11										*/
/********************************************/
static int _print_info_struct(mcat,pInfoParm,flgs)
MCAT *mcat;
tdtINFO_PARM *pInfoParm;
int flgs[];
{
	tdtDefType *pDeftype;
	parmList  **parmName;
	char *varnam;
	int j,pos;

	if (!(varnam=(char *)pInfoParm->pi_pos)) varnam="NONA";
	pos = cl_get_struct_name_len(varnam);
	akxtmcat(mcat,varnam,pos);
	/* 2021.10.19 */
	if (*(varnam+pos)=='.') {
		akxtmcats(mcat,":");
		akxtmcats(mcat,varnam+pos+1);
	}
 	/* 2025.11.18 */
	if (cl_struct_check_valid(pInfoParm,1)) {
		akxtmcats(mcat," ##ERROR##");
		return 0;
	}
	akxtmcats(mcat,"{");
	pDeftype = (tdtDefType *)pInfoParm->pi_data;
	parmName = pDeftype->vname;
	for (j=0;j<pDeftype->ntype;j++) {
		if (j > 0) akxtmcats(mcat,", ");
		/* �����o���擾 */
		varnam = strtemp(parmName[j]->prp,parmName[j]->prmlen);
/*
printf("_print_info: varnam=[%s]\n",varnam);
*/
		_print_info(mcat,pDeftype->pType[j],varnam,flgs);
	}
	akxtmcats(mcat,"}");
	return 0;
}

/********************************************/
/*	12										*/
/********************************************/
static int _print_info_array(mcat,pInfoParm,flgs)
MCAT *mcat;
tdtINFO_PARM *pInfoParm;
int flgs[];
{
	int i,*index,f,k1,k2,iParm[4],ndim,type;
	char dummy[256],wrk[128],id,*varnam;
	tdtArrayIndex *pIndex,tIndex;
	XHASHB *xhp;
	tdtINFO_PARM *pInfo;

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_print_info_array:",pInfoParm,0,0);

	id = pInfoParm->pi_id;
	/* ��`�� */
	if (!(varnam=(char *)pInfoParm->pi_pos)) varnam=AKX_NULL_PRINT;
#if 0	/* 2023.1.28 */
	if (id=='R' && (pInfo=(tdtINFO_PARM *)pInfoParm->pi_paux)) {
		if (pInfo->pi_id != 'R') {
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_print_info_array:pInfo:",pInfo,0,0);
					/* %s: �R�s�[���̔z��[%s]�������ł��B */
			ERROROUT2(FORMAT(231),"_print_info_array",varnam);
			akxtmcats(mcat,"##ERROR##,");
		}
	}
#endif
	if (pGlobTable->options[12] & 0x01) {
		/* ��`�� */
		akxtmcats(mcat,varnam);
		akxtmcats(mcat,"[]");
		cl_debug_array_info(dummy,0,pInfoParm);
	}
	else {
		if (id == 'A') {
			pIndex = &tIndex;
			cl_get_array_index_tbl(pInfoParm,pIndex,NULL,NULL);
		}
		else pIndex = (tdtArrayIndex *)pInfoParm->pi_data;
		/* �f�[�^�^ */
		if (id=='A' || id=='R') {
			if (pInfo = pIndex->pInfoType) {
				/* 2021.8.28 */
				akxtmcats(mcat,"(");
				_print_info(mcat,pInfo,NULL,flgs);
				akxtmcats(mcat,")");
			}
			else {
				iParm[0] = pIndex->uAttr[0];
				iParm[2] = pIndex->uAttr[2];
				iParm[3] = pIndex->uAttr[3];
				iParm[1] = pIndex->size;
				_print_attr(mcat,NULL,iParm);
				/* 2025,4,16 */
				if (pIndex->uaux1 & D_AULN_RANGE_DATA) {
					_print_attr_range(mcat,pIndex->uaux1,NULL,iParm);
				}
			}
		}
		else
			_print_attr(mcat,pInfoParm,NULL);
		akxtmcats(mcat," ");

		/* ��`�� */
/*
printf("_print_info_array: varnam=[%s]\n",varnam);
*/
		akxtmcats(mcat,varnam);

		/* �z���` */
		index = pIndex->index;
/*
printf("_print_info_array: index=%d %d %d %d %d %d\n",
index[0],index[1],index[2],index[3],index[4],index[5]);
*/
		if ((xhp=pIndex->xhp) || (id=='R' && (index[2] < 0))) {
			sprintf(dummy," hash(%d)",index[4]);
		}
		else {
			if (id=='A') sprintf(dummy,"[(%d),",index[3]-1);
#if 1	/* 2025.9.21 */
			else if (cl_get_array_index_opt(pInfoParm,NULL,1) > 0)
				sprintf(dummy,"[(%d),",index[3]-1);
#endif
			else strcpy(dummy,"[");
			ndim = index[0];
			for (i=0;i<ndim;i++) {
				if (i > 0) strcat(dummy,",");
				k1 = index[i+4];
				k2 = index[i+ndim+4];
				if (k2) {
					sprintf(wrk,"%d..%d",k2,k2+k1-1);
				}
				else sprintf(wrk,"%d",k1);
				strcat(dummy,wrk);
			}
			strcat(dummy,"]");
		}
	}
	akxtmcats(mcat,dummy);
	/* 2023.5.10 */
	if (cl_array_check_valid(pInfoParm,1)) {
		akxtmcats(mcat," ##ERROR##");
	}
	return 0;
}

/********************************************/
/*	13										*/
/********************************************/
/* 2025.9.7 20:00 */
static int _print_list(mcat,pInfoParm,flgs)
MCAT *mcat;
tdtINFO_PARM *pInfoParm;
int flgs[];
{
	tdtRB_CTL *pCt;
	int i,ret,opt_list,alen;
	char *p1,*p2,id,*nam;
/*
printf("_print_list:Enter\n");
*/
/*	opt_list = !(cl_get_option(13,0) & 0x200) | l_flg;	*/
	opt_list = l_flg;
	if ((id=pInfoParm->pi_id) == D_DATA_ID_LIST) {
		p1 = "{";
		p2 = "}";
	}
	else {	/* id====D_DATA_ID_NARABI */
		p1 = "[";
		p2 = "]";
	}

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_print_list: p1=[%s] p2=[%s]",pInfoParm,p1,p2);

	if (opt_list) akxtmcats(mcat,p1);
	i = 0;
	if (pInfoParm->pi_attr==DEF_ZOK_BULK && pInfoParm->pi_dlen==sizeof(tdtRB_CTL)) {
		pCt = (tdtRB_CTL *)pInfoParm->pi_data;

		/* �z�Q�Ƃ��`�F�b�N */
		nam = cl_gx_get_name_from_id(id);
		if ((ret = _iterate_circ_ref(&tIter_ctl,pCt,nam)) == 1) return 0;

		if (akxs_rb_used(pCt)) {
			akxs_rb_read(pCt,0);
			i = 0;
			while (pInfoParm=(tdtINFO_PARM *)akxs_rb_read(pCt,1)) {
				if (i > 0) _print_dlm(mcat,flgs,0);
/*
printf("_print_list: i=%d id=[%c]\n",i,pInfoParm->pi_id);
*/
				/* 2025.8.27 */
				cl_get_storevar(&pInfoParm,0);
				/* 2025.9.7 20:00 */
				if (i_flg && pInfoParm->pi_id==' ') {
					_print_attr(mcat,pInfoParm,NULL);
					alen = pInfoParm->pi_alen;
					if (alen & D_AULN_RANGE_DATA) {
						/* 2025,4,16 */
						_print_attr_range(mcat,alen,pInfoParm,NULL);
					}
				}
				else _print_info_data_kako(mcat,pInfoParm,NULL,flgs);
				i++;
			}
		}
		/* �z�Q�Ɠo�^��POP���� */
		if ((ret=_iterate_circ_pop(&tIter_ctl)) < 0) return ret;
	}
	if (!i) {
		if (cl_get_option(5,0) & 0x02) akxtmcats(mcat,"**NIL**");
	}
	if (opt_list) akxtmcats(mcat,p2);
/*
printf("_print_list:Exit\n");
*/
	return 0;
}

/********************************************/
/*	14										*/
/********************************************/
static int _print_info_data_kako(mcat,pInfoParm,varnam0,flgs)
MCAT *mcat;
tdtINFO_PARM *pInfoParm;
char *varnam0;
int flgs[];
{
	char id;
	int f,ret;
/*
printf("_print_info_data_kako:Enter id=[%c] varnam0=[%s]\n",pInfoParm->pi_id,nval1(varnam0));
*/
	/* 2025.8.27 */
	cl_get_storevar(&pInfoParm,0);
	f = 0;
	id = pInfoParm->pi_id;
	if (id==' ' && (pInfoParm->pi_alen & D_AULN_RANGE_DATA) &&
	              !(pInfoParm->pi_alen & (D_AULN_COMPLEX_DATA | D_AULN_RATIONAL)) &&
	                   ((pInfoParm->pi_aux[0] & DEF_ZOK_DATA) || flgs[3])) {
		akxtmcats(mcat,"*");
		f = 1;
	}
	if (id=='P' || id=='T' || id=='A' || id=='R' || f) {
		akxtmcats(mcat,"(");
		f = 1;
	}
/*
printf("_print_info_data_kako: id=[%c] flgs[3]=%d\n",id,flgs[3]);
*/
	/* 2025.9.7 */
	if (i_flg) {
		if ((flgs[3] || (pInfoParm->pi_aux[0] & DEF_ZOK_DATA)) &&
		    (id=='L' || id=='N' || id=='T' || id=='A' || id=='R'))
			ret = _print_info_data(mcat,pInfoParm,varnam0,flgs);
		else
			ret = _print_info(mcat,pInfoParm,varnam0,flgs);
	}
	else {
		if (id==' ' || id=='L' || id=='N')
			ret = _print_info_data(mcat,pInfoParm,varnam0,flgs);
		else if ((flgs[3] || (pInfoParm->pi_aux[0] & DEF_ZOK_DATA)) &&
		         (id=='T' || id=='A' || id=='R'))
			ret = _print_info_data(mcat,pInfoParm,varnam0,flgs);
		else
			ret = _print_info(mcat,pInfoParm,varnam0,flgs);
	}
	if (f) akxtmcats(mcat,")");
/*
printf("_print_info_data_kako:Exit ret=%d\n",ret);
*/
	return ret;
}

/********************************************/
/*	15										*/
/********************************************/
static int _print_info_data(mcat,pInfoParm,varnam0,flgs)
MCAT *mcat;
tdtINFO_PARM *pInfoParm;
char *varnam0;
int flgs[];
{
	int i,j,iParm[4],ix1,nm1,iRc,iAux1,*index,f,k1,k2,type,m1,ic,iAux0,code_type;
	int interval,iINTVAL,atr1,len,iVal[2],iCOMPLEX;
	char dummy[256],wrk[128],id,*varnam,*scope,*p1,term,*pVal;
	tdtArrayIndex *pIndex,tIndex1;
	XHASHB *xhp;
	parmList  **parmName;
	tdtDefType *pDeftype;
	tdtINFO_PARM *pParmI,***pTBL1,tInfoParm,*pInfo,tInfoParm2,*pInfo2,tInfoParm3,*pInfo3,*ppParm[3];
	tdtINFO_PARM *ppInfo[3],tInfo[3];
/*
printf("_print_info_data:Enter id=[%c] varnam0=[%s]\n",pInfoParm->pi_id,nval1(varnam0));
*/
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_print_info_data: varnam0=[%s]",pInfoParm,varnam0,0);

	if (cl_check_addr(pInfoParm,dummy,sizeof(dummy))) {
		akxtmcats(mcat,dummy);
		return 0;
	}
	/* 2025.8.27 */
	cl_get_storevar(&pInfoParm,0);
	iRc = 0;
	/* 2025.6.8 *//* 2025.6.16 1-->0 cl_double_to_str(),cl_mpa2an()�̒��Ōʂɐݒ肷�� */
	if ((id=pInfoParm->pi_id)==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
/*
printf("_print_info_data: id=[%c] flgs[3]=%d\n",id,flgs[3]);
*/
		/* 2025.9.7 20:00*/
		iRc = _print_list(mcat,pInfoParm,flgs);
	}
	else if (id=='P' || id=='T') {
		if (id == 'P') type = pInfoParm->pi_aux[0] & ~DEF_ZOK_DATA;
		else type = D_AUX0_TYPE_STRUCT;
		if (type == D_AUX0_TYPE_STRUCT) {
			if (cl_struct_check_valid(pInfoParm,1)) {
				akxtmcats(mcat," ##ERROR##");
				return 0;
			}
			akxtmcats(mcat,"{");
			pDeftype = (tdtDefType *)pInfoParm->pi_data;
			if (_iterate_circ_ref(&tIter_ctl,pDeftype,(char *)pInfoParm->pi_pos) == 1) return 0;
			parmName = pDeftype->vname;
			for (j=0;j<pDeftype->ntype;j++) {
				if (j > 0) {
					_print_dlm(mcat,flgs,0);
				}
				akxtmcat(mcat,parmName[j]->prp,parmName[j]->prmlen);
				akxtmcats(mcat,"=");
				if ((iRc=_print_info_data_kako(mcat,pDeftype->pType[j],NULL,flgs)) < 0) break;
			}
			akxtmcats(mcat,"}");
		}
		else {
			if (type == D_AUX0_TYPE_ARRAY) id = 'R';
			else id = 'A';
			pInfoParm->pi_id = id;
			iRc = _print_info_data_kako(mcat,pInfoParm,NULL,flgs);
		}
	}
	else if (id=='A' || id=='R') {
		if (iRc=cl_get_array_info(pInfoParm,&tIndex1,&pTBL1,iParm)) {
			akxtmcats(mcat,"##ERROR##");
			return iRc;
		}

DEBUGOUTL1(120,"_print_info_data: tIndex1.xhp=%08x",tIndex1.xhp);

		/* �z�Q�Ƃ��`�F�b�N */
		pVal = cl_get_circ_addr(&tIndex1,pTBL1);
		if ((iRc = _iterate_circ_ref(&tIter_ctl,pVal,(char *)pInfoParm->pi_pos)) == 1) return 0;

		if (xhp=tIndex1.xhp) {
			nm1 = iParm[1];
			m1  = iParm[3];
			if (!m1) nm1 = 0;
		}
		else {
/*
printf("_print_info_data: iParm[2]=%d iParm[3]=%d\n",iParm[2],iParm[3]);
*/
			nm1 = iParm[3] - iParm[2] + 1;	/* iParm[2],iParm[3]�́AParmNo�ł̒l�ɂȂ��Ă��� */
			m1  = nm1;
		}
		ix1  = iParm[2];

DEBUGOUTL2(120,"_print_info_data: nm1=%d ix1=%d",nm1,ix1);
printf("_print_info_data: nm1=%d ix1=%d\n",nm1,ix1);

		iCOMPLEX = pInfoParm->pi_alen & (D_AULN_COMPLEX_DATA | D_AULN_RANGE_DATA | D_AULN_RATIONAL);
/*
printf("_print_info_data: iCOMPLEX=%08x\n",iCOMPLEX);
*/
		ic = 0;
		for (i=0;i<nm1;i++,ix1++) {
			if ((iRc=cl_array_get_info_parm(&pParmI,&tIndex1,pTBL1,ix1,'r')) < 0) return iRc;

DEBUGOUT_InfoParm(120,"_print_info_data: id=[%c] i=%d",pParmI,id,i);

			if (xhp) {
				if (ic >= m1) break;
				if (pParmI) {
					if (ic > 0) _print_dlm(mcat,flgs,0);
					*dummy = '[';
					strnzcpy(dummy+1,xhp->xha_hashb->ha_key,sizeof(dummy)-4);
					strcat(dummy,"]=");
					akxtmcats(mcat,dummy);
					if ((iRc=_print_info_data_kako(mcat,pParmI,NULL,flgs)) < 0) break;
					ic++;
				}
			}
			else {
				if (i > 0) {
					_print_dlm(mcat,flgs,0);
				}
				if (pParmI && !cl_is_undef_parm(pParmI) && !cl_is_null_parm(pParmI)) {
					pParmI->pi_alen |= iCOMPLEX;
				/*	if (i_flg && !instrchar("ARTLN",pParmI->pi_id)) {
						if ((iRc=_print_info(mcat,pParmI,varnam0,flgs)) < 0) break;
					}
					else */{
						if ((iRc=_print_info_data_kako(mcat,pParmI,NULL,flgs)) < 0) break;
					}
				}
			}
		}
		/* �z�Q�Ɠo�^��POP���� */
		if ((iRc=_iterate_circ_pop(&tIter_ctl)) < 0) return -1;
	}
	else if (id==' ' && (pInfoParm->pi_alen & D_AULN_RANGE_DATA) &&
	                   !(pInfoParm->pi_alen & (D_AULN_COMPLEX_DATA | D_AULN_RATIONAL)) &&
	                    ((pInfoParm->pi_aux[0] & DEF_ZOK_DATA) || flgs[3])) {
		ppParm[0] = &tInfoParm;
		ppParm[1] = &tInfoParm2;
		ppParm[2] = &tInfoParm3;
		if ((iRc=cl_get_range_info(pInfoParm,ppParm,iVal,1)) < 0) return iRc;
		pInfo  = ppParm[0];
		pInfo2 = ppParm[1];
		pInfo3 = ppParm[2];
		nm1      = iVal[0];
		interval = iVal[1];
		atr1 = pInfo->pi_attr;
		len  = pInfo->pi_dlen;
		code_type = pInfo->pi_code;
/*
printf("_print_info_data: atr1=%d len=%d nm1=%d interval=%d\n",atr1,len,nm1,interval);
*/
		iINTVAL = iRc & 0x01;
		if (atr1 != DEF_ZOK_BINA) {
			if (!(p1=cl_tmp_const_malloc(X_MAX(len,5)))) return ECL_MALLOC_ERROR;
			memcpy(p1,pInfo->pi_data,len);
			pInfo->pi_data = p1;
			if (atr1 == DEF_ZOK_CHAR) {
				m1 = akxqmbslen(code_type,p1);
				ic  = akxcmb2ul(p1,m1);
				*(p1+m1) = '\0';
				pInfo->pi_dlen = m1;
			}
			else if (atr1 == DEF_ZOK_DATE) {
				for (i=0;i<3;i++) ppInfo[i] = &tInfo[i];
				cl_set_parm_long(ppInfo[2],interval);
/*
printf("_print_info_data: term=%d interval=%d\n",pInfo3->pi_hlen,interval);
*/
				if (!(i=pInfo3->pi_hlen)) i = 3;
				cl_set_parm_long(ppInfo[1],i);
			}
		}
		for (i=0;i<nm1;i++) {
			if (i > 0) {
				_print_dlm(mcat,flgs,0);
				if (atr1 == DEF_ZOK_CHAR) {
					ic += interval;
					m1 = akxcul2mb(pInfo->pi_data,ic);
					pInfo->pi_dlen = m1;
				}
				else {
					if (iINTVAL) {
						if (atr1 == DEF_ZOK_DATE) {
							ppInfo[0] = pInfo;
							iRc = cl_func_add_to_date(pInfo2,3,ppInfo);
						}
						else {
							iRc = cl_gx_bexp(pInfo2,pInfo,"+",pInfo3,0,0);
						}
						cl_gx_copy_info2(pInfo,pInfo2);
					}
					else iRc = _gx_ppmm(14,pInfo);
					if (iRc < 0) break;
				}
			}
			/* 2025.6.8 */
			_print_data(mcat,pInfo,flgs);
/*
printf("_print_info_data: mc_ipos=%d mc_bufp=[%s]\n",mcat->mc_ipos,mcat->mc_bufp);
*/
		}
	}
	else if (id==D_DATA_ID_PNAME) {
		_print_info(mcat,pInfoParm,varnam0,flgs);
	}
	else if (id==D_DATA_ID_CLASS || id==D_DATA_ID_INSTANCE) {
		_print_info(mcat,pInfoParm,varnam0,flgs);
	}
	else if (id==D_DATA_ID_UNDEFVAR) akxtmcats(mcat,"**undef**");
	/* 2025.6.8 */
	else _print_data(mcat,pInfoParm,flgs);
/*
printf("_print_info_data:Exit iRc=%d\n",iRc);
*/
	return iRc;
}

/********************************************/
/*	16										*/
/********************************************/
static int _print_info(mcat,pInfoParm,varnam0,flgs)
MCAT *mcat;
tdtINFO_PARM *pInfoParm;
char *varnam0;
int flgs[];
{
	int i,j,iParm[4],ix1,nm1,iRc,iAux1,*index,f,k1,k2,type,len,alen;
	int code_type,iPOINTER,code_type0,disp_flg;
	char dummy[256],wrk[128],id,*varnam,*scope,*p,id0;
	tdtArrayIndex *pIndex,tIndex1;
	XHASHB *xhp;
	ScrPrCT *pScCT;
	parmList  **parmName;
	tdtDefType *pDeftype;
	tdtINFO_PARM *pParmI,***pTBL1,*pInfo,tInfoParm;
	Leaf *wkleaf;
/*
printf("_print_info:Enter id=[%c] varnam0=[%s]\n",pInfoParm->pi_id,nval1(varnam0));
*/
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_print_info: varnam0=[%s]",pInfoParm,varnam0,0);

	if (cl_check_addr(pInfoParm,dummy,sizeof(dummy))) {
		akxtmcats(mcat,dummy);
		return 0;
	}
	/* 2025.8.27 */
	id0 = pInfoParm->pi_id;
	cl_get_storevar(&pInfoParm,0);
	iPOINTER = 0;
	id = pInfoParm->pi_id;
#if 0	/* 2025.10.18 */
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		if (flgs[3] || (pInfoParm->pi_aux[0] & DEF_ZOK_DATA)) {
			/* 2025.9.7 20:00 */
			if ((iRc=_print_list(mcat,pInfoParm,flgs)) < 0) return iRc;
		}
		else {
			akxtmcats(mcat,cl_gx_get_name_from_info(pInfoParm));
		}
	}
	else 
#endif
	if (id=='F' || id=='M')
		_print_data(mcat,pInfoParm,flgs);
#if 1	/* 2025.10.18 */
	else if (id=='P' || id=='T' || id=='A' || id=='R' || varnam0 || id==' ' || id=='S' ||
	         id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
#else
	else if (id=='P' || id=='T' || id=='A' || id=='R' || varnam0 || id==' ' || id=='S') {
#endif
		/* 2025.9.6 */
		if (id!=' ' && (flgs[3] || (pInfoParm->pi_aux[0] & DEF_ZOK_DATA)) && (id=='A' || id=='R')) {
			return _print_info_data(mcat,pInfoParm,varnam0,flgs);
		}
		/* �X�R�[�v */
		iAux1 = pInfoParm->pi_aux[1];
		/* 2021.1.22 */
		scope = cl_get_scope_name_from_aux1(iAux1);
		if (*scope) {
			akxclowern(wrk,scope,strlen(scope));
			akxtmcats(mcat,wrk);
			akxtmcats(mcat," ");
		}

		/* 2021.3.9 *//* 2025.8.27 1 ==> 0 */
		/* CONST */
		if (iAux1 & D_AUX1_PROTECTED) akxtmcats(mcat,"const ");
#if 1	/* 2025.10.18 */
		if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
			if (flgs[3] || (pInfoParm->pi_aux[0] & DEF_ZOK_DATA)) {
				/* 2025.9.7 20:00 */
				if ((iRc=_print_list(mcat,pInfoParm,flgs)) < 0) return iRc;
			}
			else {
				akxtmcats(mcat,cl_gx_get_name_from_info(pInfoParm));
			}
			return 0;
		}
#endif
		if (id == 'P') {
			type = pInfoParm->pi_aux[0] & ~DEF_ZOK_DATA;
			/* �^��` */
			akxtmcats(mcat,"type ");
		}
		else if (id == 'T') type = D_AUX0_TYPE_STRUCT;
		else type = 0;
		if (type == D_AUX0_TYPE_STRUCT) {
					/* �\���� */
			flgs[0] |= PRN_OPT_DCMA;
			/* �^��` */
		/*	if (id=='P') akxtmcats(mcat,"type ");	*/

			/* ��`�� */
			/* 2021.1.23 */
			_print_info_struct(mcat,pInfoParm,flgs);
			if (q_flg) flgs[0] |= PRN_OPT_DCMA;
			else flgs[0] &= ~PRN_OPT_DCMA;
		}
		else if (id == D_DATA_ID_STOREVAR) {
			akxtmcats(mcat,"pointer");
			/* ��`�� */
			if (varnam0) {
				if (*varnam0) {
					akxtmcats(mcat," ");
					/*if (varnam0) */akxtmcats(mcat,varnam0);
				}
			}
		}
		else {
			if (type == D_AUX0_TYPE_ARRAY) id = 'R';
			else if (type == D_AUX0_TYPE_MAPPED) id = 'A';
			cl_gx_copy_info(&tInfoParm,pInfoParm);
			pInfoParm = &tInfoParm;
			pInfoParm->pi_id = id;
			/* �z�� */
			if (id=='A' || id=='R')
				_print_info_array(mcat,pInfoParm,flgs);
			else {
				/* �f�[�^�^ */
				_print_attr(mcat,pInfoParm,NULL);
				alen = pInfoParm->pi_alen;
				if (alen & D_AULN_RANGE_DATA) {
					/* 2025,4,16 */
					_print_attr_range(mcat,alen,pInfoParm,NULL);
				}
				/* �����R�[�h */
				code_type = cl_get_char_code_type(pInfoParm,2);
				if (cl_get_option(13,0) & 0x400) disp_flg = 1;
				else {
					disp_flg = 0;
					if (code_type > 0) {
						code_type0 = akxt_get_code_type();
						if (code_type != code_type0) disp_flg = 1;
					}
				}
				if (disp_flg) {
					if (code_type > 0) {
						if (p=akxc_get_code_str(code_type)) {
							akxtmcats(mcat," ");
							akxtmcats(mcat,p);
						}
					}
					else akxtmcats(mcat," no code_type");
				}
				/* ��`�� */
				if (varnam0) {
					if (*varnam0) {
						akxtmcats(mcat," ");
						/*if (varnam0) */akxtmcats(mcat,varnam0);
					}
				}
			}
		}
	/*	if (id0 == D_DATA_ID_STOREVAR) akxtmcats(mcat," pointer");	del 2025.8.27 */
	}
	else if (id==D_DATA_ID_CLASS || id==D_DATA_ID_INSTANCE) {
		*dummy = '\0';
		if (q_flg) strcat(dummy,"\"");
		if (id == D_DATA_ID_CLASS) {
			strcat(dummy,"Class ");
			if (varnam=pInfoParm->pi_data)
				len = akxstrnlen(varnam,pInfoParm->pi_dlen);
		}
		else if (id == D_DATA_ID_INSTANCE) {
			/* 2025.8.27 */
			sprintf(wrk,"Instance(%08x) as ",pInfoParm->pi_len);
			strcat(dummy,wrk);
			if (wkleaf = (Leaf *)pInfoParm->pi_paux) {
				if (varnam=wkleaf->cmd.prmp[0]->prp) len = strlen(varnam);
			}
			else varnam = NULL;
		}
		if (varnam) memcat(dummy,varnam,len);
		else strcat(dummy,AKX_NULL_PRINT);
		if (q_flg) strcat(dummy,"\"");
		akxtmcats(mcat,dummy);
	}
	else if (id==D_DATA_ID_PNAME) {
		if (pInfoParm->pi_attr==2) {
/*
DEBUGOUT_InfoParm(0,"_print_info:",pInfoParm,0,0);
*/
			akxtmcats(mcat,pInfoParm->pi_paux);
			akxtmcats(mcat,"==>");
			pInfoParm = (tdtINFO_PARM *)pInfoParm->pi_pos;
			/* add 2021.8.10 */
			/* add 2021.8.11 */
			if (pInfoParm->pi_id == 'S') pInfoParm = (tdtINFO_PARM *)pInfoParm->pi_pos;
			if (pInfoParm->pi_id == ' ') _print_data(mcat,pInfoParm,flgs);
			else _print_info(mcat,pInfoParm,NULL,flgs);
		}
		else {
			_print_data(mcat,pInfoParm->pi_data,flgs);
			 akxtmcats(mcat,"==>");
		}
	}
	else if (id==D_DATA_ID_UNDEFVAR) akxtmcats(mcat,"**undef**");
	else if (!id) {
		scope = cl_get_scope_name_from_aux1(pInfoParm->pi_aux[1]);
		if (*scope) {
			akxclowern(wrk,scope,strlen(scope));
			akxtmcats(mcat,wrk);
			akxtmcats(mcat," ");
		}
		/* �f�[�^�^ */
		_print_attr(mcat,pInfoParm,NULL);
		akxtmcats(mcat,"(no data)");
	}
	else _print_data(mcat,pInfoParm,flgs);
/*
printf("_print_info:Exit\n");
*/
	return 0;
}

/********************************************/
/*	17										*/
/********************************************/
static int _check_set_flag(ppInfoParm,opt,flgs)
tdtINFO_PARM **ppInfoParm;
int opt,flgs[];
{
	tdtINFO_PARM *pInfoParm,*pInfoParmW;
	int len,ret;
	char *p;

	ret = 0;
	if ((opt & 0x02) || (flgs[0] & PRN_OPT_AVAL)) {
		pInfoParm = *ppInfoParm;
		if (pInfoParm->pi_id==' ' && pInfoParm->pi_attr==DEF_ZOK_CHAR && (len=pInfoParm->pi_dlen)>=2) {
			if (p = pInfoParm->pi_data) {
				if (*p == '/') {
					_set_flag(p,len,flgs);
					ret = 1;
				}
				else if (!memcmp(p,"\\/",2)) {
					if (!(pInfoParmW=(tdtINFO_PARM *)cl_tmp_const_malloc(sizeof(tdtINFO_PARM))))
						return ECL_MALLOC_ERROR;
					cl_set_parm_char(pInfoParmW,p+1,len-1);
					*ppInfoParm = pInfoParmW;
				}
			}
		}
	}
	return ret;
}

/********************************************/
/*	18										*/
/********************************************/
static int _mcat_text_infoparm(mcat,tInfoParm2,k,flgs)
MCAT *mcat;
tdtINFO_PARM tInfoParm2[];
int k,flgs[];
{
	int j,nparm,iPARMINFO2,opt,len,data_flg,opt10,opt19,optw,w_pre,w_inx,iCON,iDLM,rc,flags[2],iPOINTER;
	tdtINFO_PARM *pInfoParm,tInfoParm,*pInfoParm0;
	char name[30],name2[30],*p,id;
/*
printf("_mcat_text_infoparm:Enter\n");
*/
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_mcat_text_infoparm: k=%d",tInfoParm2,k,0);

	nparm = cl_get_InfoParm2(tInfoParm2,&pInfoParm0,flags);	/* 2025.8.27 pInfoParm ==> pInfoParm0 */
	if (iPARMINFO2=flags[0]) {
		if (d_flg) {
			sprintf(name,"DUMP%d",k+1);
			cl_dump_info(&tInfoParm2[0],"%s=",name);
			sprintf(name2,"#%s#->",name);
			akxtmcats(mcat,name2);
		}
	}

DEBUGOUTL2(LVL_GXEXOBJ,"_mcat_text_infoparm: nparm=%d,iPARMINFO2=%d",nparm,iPARMINFO2);

	/* 2024.5.7 */
	if (!(tIter_ctl.itc_circ_ref=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215212104;
	iDLM = iCON = 0;
	opt = cl_get_option(13,0);
	for (j=0;j<nparm;j++,pInfoParm0++) {	/* 2025.8.27 pInfoParm ==> pInfoParm0 */
		pInfoParm = pInfoParm0;				/* 2025.8.27 add */
		/* 2025.8.27 */
		cl_get_storevar(&pInfoParm,0);		/* 2025.8.27 pInfoParm ==> pInfoParm0 */
/*
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_mcat_text_infoparm: j=%d",pInfoParm,j,0);
*/
/*
printf("\n_mcat_text_infoparm: c_flg=%d iDLM=%d\n",c_flg,iDLM);
*/
		akxs_layer_i(tIter_ctl.itc_circ_ref);
		/* 2021.3.11 */
		if (_check_set_flag(&pInfoParm,opt,flgs)) {
			if (!iCON) iCON = 1;
			continue;
		}
		iCON = 2;
		if (iDLM) {
			_print_dlm(mcat,flgs,1);
		}
		if (d_flg) {
			if (iPARMINFO2) sprintf(name,"DUMP%d-%d",k+1,j+1);
			else sprintf(name,"DUMP%d",k+1);
			cl_dump_info(pInfoParm,"%s=",name);
			sprintf(name2,"#%s#",name);
			akxtmcats(mcat,name2);
		}
		else {
		/*	flgs[3] = 0;	*/
			flgs[3] = pInfoParm->pi_aux[0] & DEF_ZOK_DATA;
			id = pInfoParm->pi_id;
			/* 2025.9.7 */
			if (i_flg) {
				rc = _print_info(mcat,pInfoParm,NULL,flgs);
			}
			else {
				if (id==' ' || id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI)
					_mcat_print_info_data(mcat,pInfoParm,flgs);
				else if (flgs[3] && (id=='A' || id=='R' || id=='T'))
					_mcat_print_info_data(mcat,pInfoParm,flgs);
				else
					rc = _print_info(mcat,pInfoParm,NULL,flgs);
			}
		}
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_mcat_text_infoparm: j=%d",pInfoParm,j,0);
		iDLM = 1;
	}
	if (iCON > 1) iCON = 0;
/*
printf("_mcat_text_infoparm:Exit iCON=%d\n",iCON);
*/
	return iCON;
}

/********************************************/
/*	19										*/
/********************************************/
static int _mcat_text(mcat,prmp,Obj,prmnum,flgs)
MCAT *mcat;
parmList *prmp[];
int      *Obj;
int      prmnum,flgs[];
{
	/* 2021.3.12 */
	MCAT mcat2;
	int rc,i,j,nparm,len,k,nn_opt,iPARMINFO2,optW,iDLM,iCON;
	parmList  *pparmList;
	tdtINFO_PARM tInfoParm2[2],*pInfoParm;
	char *p,c,c1,name[30],name2[30];
	SSPL_S sspl;

	memset(&mcat2,0,sizeof(MCAT));
	mcat2.mc_extlen = 256;
	iDLM = 0;
	flgs[0] &= ~PRN_OPT_DUMP;
/*	flgs[0] |= PRN_OPT_AVAL;	*//* 2025.6.15 del */
	exp_pre = -1;
	exp_inx = -1;
	for (i=0,k=0;i<prmnum;i++) {
		pparmList = prmp[i];
		len = pparmList->prmlen;
		len = akxtsapb(0,p=strtemp(pparmList->prp,len),len);	/* 1-->0 2017.11.03 */
		if (*p == '/') {
			_set_flag(p,len,flgs);
			continue;
		}
#if 0	/* 2023.9.17 */
		else if (!memrngcmp_opt(p,len,"DO",0,2,1) ||
		         !memrngcmp_opt(p,len,"FOR",0,3,1) || !memicmp(p,"FOR(",4)))
			break;
#endif
		mcat2.mc_ipos = 0;
		if (mcat2.mc_bufp) *mcat2.mc_bufp = '\0';
		optW = D_GX_OPT_PARMINFO2|D_GX_OPT_GET_RANGE;
		if (i_flg) optW |= D_GX_OPT_INFO_MODE;
		rc=cl_gx_exp_obj_opt(1,&pparmList,Obj,tInfoParm2,optW);

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_mcat_text: i=%d rc=%d",tInfoParm2,i,rc);

		if (rc!=NORMAL/* || InfoParm.pi_data==NULL*/) {
			if (rc == 100) {
				if (q_flg) akxtmcats(&mcat2,"\"\"");
			}
			else akxtmcats(&mcat2,"##ERROR##");
		}
		else {
			iCON = _mcat_text_infoparm(&mcat2,tInfoParm2,k,flgs);
			if (iCON) continue;
		}
		if (iDLM) {
			_print_dlm(mcat,flgs,1);
		}
		nn_opt = n_flg;
		if (nn_opt && !d_flg && !x_flg) {
			if (!_do_print_name(p,len)) nn_opt = 0;
		}
		if (nn_opt) {
			akxtmcat(mcat,p,len);
			akxtmcats(mcat,"=");
		}
		akxtmcats(mcat,mcat2.mc_bufp);
		iDLM = 1;
		k++;
	}
	if (p = mcat2.mc_bufp) Free(p);
/*
printf("_mcat_text:Exit mc_bufp=[%s]\n",mcat->mc_bufp);
*/
	return 0;
}

/********************************************/
/*	20										*/
/********************************************/
static void _option_to_flag(opt,flgs)
int opt,flgs[];
{
/*
printf("_option_to_flag: opt=%08x flgs[0]=%08x\n",opt,flgs[0]);
*/
	if (opt & 0x04) flgs[0] |= PRN_OPT_DCMA;
	if (opt & 0x08) flgs[0] |= PRN_OPT_QUOT;
	if (opt & 0x10) flgs[0] |= PRN_OPT_NAME;
	if (opt & 0x20) flgs[0] |= PRN_OPT_MCMA;
	if (opt & 0x200) flgs[0] &= ~PRN_OPT_LIST;
}

/********************************************/
/*	21										*/
/********************************************/
static int _flag_to_option(flgs)
int flgs[];
{
	int opt;

	opt = 0;
	if (c_flg) opt |= 0x04;
	if (q_flg) opt |= 0x08;
	if (n_flg) opt |= 0x10;
	if (flgs[0] & PRN_OPT_MCMA) opt |= 0x20;
	if (!l_flg) opt |= 0x200;
	return opt;
}

/********************************************/
/*	22										*/
/********************************************/
static void cl_print_echo_text_init(mcat,name,opt,flgs)
MCAT *mcat;
char *name;
int  opt,flgs[];
{
	int qcn_opt;

	/* 2023.10.31 */
	if (mcat) {
		memset(mcat,0,sizeof(MCAT));
		mcat->mc_extlen = 256;
		if (!name) name = "";
		akxtmcats(mcat,name);
	}
	mem_set_int(flgs,0,MAX_FLGS);
	qcn_opt = PRN_OPT_QUOT | PRN_OPT_DCMA | PRN_OPT_NAME | PRN_OPT_LIST | PRN_OPT_RECR;
	if (opt & 0x01) flgs[0] |= qcn_opt;
	_option_to_flag(pGlobTable->options[12],flgs);
}

/********************************************/
/*	23										*/
/********************************************/
/* 2023.10.31 */
static void cl_print_echo_text_out_sub(p0,len,opt,flgs)
char *p0;
int  len,opt,flgs[];
{
	char *p,*pp,*pw,*pAns,*pOpe,*cProcName,buf[3];
	M_FILE *fp;
	int ex_opt,ret,try_lvl,iParm[5],val,fope,iSTDOUT2MEM,log_no,log_flg,n;
	tdtINFO_PARM tParm[2],*ppParm[2];
	tdtREDIRECT *red;
	ProcCT *proc;

	/* 2023.10.31 */
	p = p0;
	/* 2022.11.05 */
	if (!p) p = "";
	ex_opt = cl_get_option(21,0);
/*
printf("cl_print_echo_text_out: opt=%d ex_opt=%08x\n",opt,ex_opt);
*/
	if (e_flg) {
		fp = m_stderr;
		log_no = D_LOG_NO_ERROR;
	}
	else {
		fp = m_stdout;
		log_no = D_LOG_NO_PRINT;
	}
	log_flg = LOGFLG(log_no,-1);
	if (!u_flg && (proc=cl_search_proc_ct())) {
		red = proc->redirect;
		if (log_flg & D_LOG_FLG_STDOUT)
			iSTDOUT2MEM = red->pFlag2 & D_PFLAG2_STDOUT2MEM;
		iParm[0] = 0;
	}
	else {
		red = NULL;
		iSTDOUT2MEM = 0;
		iParm[0] = D_PFLAG2_UNUSE_RED;	/* add 2022.12.13 */
	}
/*
printf("cl_print_echo_text_out: log_no=%d log_flg=%08x iSTDOUT2MEM=%08x red=%08x u_flg=%08x iParm[0]=%08x\n",
log_no,log_flg,iSTDOUT2MEM,red,u_flg,iParm[0]);
*/
	/* 2022.1.20 */
	if (cl_get_option(3,0) & 0x200) {
		len = cl_ank_conv(&pp,p,len);
		if (pp) p = pp;
	}
/*
{char buf[128];
sprintf(buf,"cl_print_echo_text_out:1 opt=%08x len=%d p=[%s]",opt,len,p);
cl_puts(buf);}
*/
	if (opt & 0x02) {
		if (iSTDOUT2MEM) LOGFLG(log_no,log_flg | D_LOG_FLG_STDOUT2MEM);
		/* 2022.12.12 */
		if (e_flg) ERROROUT1("%s",p);
		else PRINTOUT1("%s",p);
		LOGFLG(log_no,log_flg);
	}
	else {
		if (cl_get_option(13,0) & 0x100) {
		/*	if (e_flg) fp = stderr;
			else fp = stdout;	*/
			ppParm[0] = &tParm[0];
			ppParm[1] = &tParm[1];
			cl_set_parm_long(ppParm[0],fp);
			cl_set_parm_char(ppParm[1],p,len);
/*
{char buf[128];
sprintf(buf,"cl_print_echo_text_out:2 opt=%08x len=%d p=[%s]",opt,len,p);
cl_puts(buf);}
*/
			if (opt & 0x80) {
				pOpe = "FELWRITE1";
				fope = D_FUC_FELWRITE1;
			}
			else {
				pOpe = "FPUTLINE";
				fope = D_FUC_FPUTLINE;
			}
/*
printf("cl_print_echo_text_out: pOpe=[%s]\n",pOpe);
*/
			pAns = (char *)&val;
			ret = func_file(&pAns,pOpe,2,ppParm,fope,iParm);
		}
		else {
			if (red) {
				if (e_flg) fp = red->stdio[2];
				else fp = red->stdio[1];
			}
		/*	if (iSTDOUT2MEM) {	*/
			if (fp->m_mcat) {
/*
printf("cl_print_echo_text_out:STDOUT2MEM fp=%08x len=%d p=[%s]\n",fp,len,p);
*/
				akxtmcat(fp->m_mcat,p,len);
				/* 2023.4.18 */
				if (!(opt & 0x80)) {
					if ((n=akxa_log_new_line_str(buf,cl_get_option(3,0))) > 0) {
						akxtmcat(fp->m_mcat,buf,n);
					}
				}
			}
			else {
				pp = p;
/*
{char buf[128];
sprintf(buf,"cl_print_echo_text_out:3 opt=%08x len=%d p=[%s]",opt,len,p);
cl_puts(buf);}
*/
				if (len > 0) {
					if (ex_opt & D_CODE_OUTPUT_MASK) {
						ret = cl_file_code_conv(&pp,p,len,1,0,0);
/*
printf("cl_print_echo_text_out: ret=%d pp=[%s]\n",ret,pp);
*/
					}
					fprintf(fp->m_fp,"%s",pp);
					if (p != pp) Free(pp);
				}
				if (!(opt & 0x80)) akxa_log_new_line(fp->m_fp,cl_get_option(3,0));
			}
		/*	akxa_log_new_line(fp,cl_get_option(3,0) | iSTDOUT2MEM);	*/
		}
	}
	/* 2023.10.31 */
}
/* 2023.10.31 */
/********************************************/
/*	23-2									*/
/********************************************/
static void cl_print_echo_text_out(mcat,opt,flgs)
MCAT *mcat;
int  opt,flgs[];
{
	char *p0;
	int len;

	p0  = mcat->mc_bufp;
	len = mcat->mc_ipos;
/*
printf("cl_print_echo_text_out: len=%d p0=[%s]\n",len,p0);
*/
	cl_print_echo_text_out_sub(p0,len,opt,flgs);
	if (p0) Free(p0);
	mcat->mc_bufp = NULL;
	mcat->mc_ipos = 0;
}

/********************************************************/
/*	24													*/
/*	ECHO/SAY	opt = 0									*/
/*	PRINT		opt = 1									*/
/*	LPRINT		opt = 3									*/
/* 				0x01:c_flg=1,q_flg=1,n_flg=1,l_flg=1	*/
/*				0x02:PRINTOUT							*/
/********************************************************/
int cl_print_echo_text(prmp,Obj,prmnum,name,opt)
parmList *prmp[];
int      *Obj;
int      prmnum;
char     *name;
int      opt;
{
	MCAT mcat;
	int flgs[MAX_FLGS],try_lvl,line_len,rc,i;
	char *line;
	cmdInfo cmd;
	ParList parl;
	parmList *pprmp[6],prmp2[6];
/*
printf("cl_print_echo_text:Enter name=[%s] opt=%08x\n",name,opt);
*/
	if (!prmp) return 0;
/* 2021.7.1 */
	try_lvl = pGlobTable->try_level;
	pGlobTable->try_level = 0;
/* */
	/* 2023.9.17 */
	memset(prmp2,0,sizeof(prmp2));
	for (i=0;i<6;i++) pprmp[i] = &prmp2[i];
	cmd.prmp = pprmp;
	cmd.prmnum = 6;
	cmd.parl = &parl;
	if ((rc=cl_print_check_do(&cmd,prmp,prmnum)) > 0) {
		prmnum = rc - 1;
		cl_print_echo_text_do(prmp,Obj,prmnum,name,opt,flgs,&cmd);
	}
	else if (!rc) {
		cl_print_echo_text_init(&mcat,name,opt,flgs);
		_mcat_text(&mcat,prmp,Obj,prmnum,flgs);
		cl_print_echo_text_out(&mcat,opt,flgs);
	}
	pGlobTable->try_level = try_lvl;	/* 2021.7.1 */
/*
printf("cl_print_echo_text:Exit\n");
*/
	return 0;
}

/********************************************/
/*	25										*/
/********************************************/
int cl_print_text(prmp,Obj,prmnum,name)
parmList *prmp[];
int      *Obj;
int      prmnum;
char     *name;
{
	return cl_print_echo_text(prmp,Obj,prmnum,name,0x03);
}

/****************************************/
/*	26									*/
/****************************************/
int cl_echo_text(prmp,Obj,prmnum,opt)
parmList *prmp[];
int      *Obj;
int      prmnum;
int      opt;
{
	return cl_print_echo_text(prmp,Obj,prmnum,NULL,opt & 0x01);
}

/********************************************/
/*	27										*/
/********************************************/
int cl_dump_info(pInfoParm,fmt,name)
tdtINFO_PARM *pInfoParm;
char *fmt,*name;
{
	char *p;
	int f;

	if (!fmt) fmt = "";
	if (!name) name = "";
	f = LOGFLG(D_LOG_NO_DEBUG,D_LOG_FLG_CHECK);
	LOGFLG(D_LOG_NO_DEBUG,f | D_LOG_FLG_STDOUT);
	if (pInfoParm->pi_id == 'A') cl_update_map_array_max(pInfoParm);
	DEBUGOUT_InfoParm(0,fmt,pInfoParm,name,0);
	LOGFLG(D_LOG_NO_DEBUG,f);
	return 0;
}

/********************************************/
/*	28										*/
/********************************************/
/*int cl_dump(prmp,prmnum,Obj,flgs)*/
int cl_dump(prmp,prmnum,Obj)
parmList *prmp[];
int      prmnum/*,flgs[]*/;
char     *Obj;
{
	int rc,i,len,try_lvl;
	parmList *pparmList;
	tdtINFO_PARM tInfoParm2[2];
	char *p,c;

	try_lvl = pGlobTable->try_level;
	pGlobTable->try_level = 0;
	for (i=0;i<prmnum;i++) {
		pparmList = prmp[i];
		len = pparmList->prmlen;
		len = akxtsapb(0,p=strtemp(pparmList->prp,len),len);	/* 1-->0 2017.11.03 */
		rc = cl_gx_exp_obj_opt(1,&pparmList,Obj,tInfoParm2,D_GX_OPT_PARMINFO2|D_GX_OPT_GET_RANGE);
		if (rc) DEBUGOUT1("%s=##ERROR##",p);
		else cl_dump_info(tInfoParm2,"%s=",p);
	}
	pGlobTable->try_level = try_lvl;
	return 0;
}

/********************************************/
/*	29										*/
/********************************************/
/* 2025.6.13 */
static int _func_print_sub(mcat,pOperator,nparm,ppParm,flgs)
MCAT *mcat;
char *pOperator;
int nparm,flgs[];
tdtINFO_PARM *ppParm[];
{
	int opt,k,rc,iDLM,try_lvl;
	tdtINFO_PARM tParm2[2],*pInfoParm;
	char *p1,buf[3];

	/* 2025.6.13 */
/*	flgs[0] |= PRN_OPT_AVAL;	*//* 2025.6.13 del */
/*
printf("_func_print_sub: flgs[0]=%08x\n",flgs[0]);
*/
	iDLM = 0;
	for (k=0;k<nparm;k++) {
		pInfoParm = ppParm[k];
		/* 2021.3.11 */
		rc = cl_str_print(&p1,pInfoParm,flgs);
		if (rc < 0) {
			if (rc == ECL_EX_CONTINUE) continue;
			break;
		}
		if (iDLM) {
/*
printf("_func_print_sub: flgs[0]=%08x\n",flgs[0]);
*/
			_print_dlm(mcat,flgs,1);
		}
		/* 2021.3.11 */
		akxtmcats(mcat,p1);
		iDLM = 1;
	}
	/* 2025.06.13 */
	return 0;
}

/********************************************/
/*	30										*/
/********************************************/
int cl_str_print(ppAns,pParm,flgs)
char **ppAns;
tdtINFO_PARM *pParm;
int flgs[];
{
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	tdtINFO_PARM tParm2[2];
	int iCON,len,iLTGT;

	if (!ppAns || !pParm) return -1;
	if (flgs[5]) {
		_option_to_flag(flgs[5],flgs);
		flgs[5] = 0;
	}
	mcat.mc_ipos = 0;
	cl_gx_copy_info(tParm2,pParm);
	memset(&tParm2[1],0,sizeof(tdtINFO_PARM));
	iLTGT = tParm2[0].pi_id!=' ' && (flgs[0] & PRN_OPT_LTGT);
	if (iLTGT) akxtmcats(&mcat,"<");
	iCON = _mcat_text_infoparm(&mcat,tParm2,0,flgs);
	if (iLTGT) akxtmcats(&mcat,">");
/*
printf("cl_str_print: flgs[0]=%08x\n",flgs[0]);
*/
	*ppAns = mcat.mc_bufp;
	if (iCON) len = ECL_EX_CONTINUE;
	else len = mcat.mc_ipos;
/*
printf("cl_str_print: len=%d *ppAns=[%s]\n",len,*ppAns);
*/
	return len;
}

/********************************************/
/*	31										*/
/********************************************/
/* 2024.12.16 */
int cl_func_printf(pAns,nparm,ppParm,pot,etc_parm)
char *pAns;
int nparm,etc_parm[];
tdtINFO_PARM *ppParm[];
tdtOpeTable *pot;
{
	int rc,is,fope,iParm[5],try_lvl,i,flgs[MAX_FLGS];
	char *pWork,*pOpe;
	tdtINFO_PARM tInfoParm,*ppParmW[2],*pInfo;
	/* 2024.12.16 */
	char *pOperator;
	int ope,gx_opt;

	pOperator = pot->name;
	ope = pot->ope;
	gx_opt = etc_parm[1];
	if (ope == D_FUC_PRINTF) {
		is = 0;
		fope = D_FUC_ELWRITE1;
		pOpe = "ELWRITE1";
	}
	else if (ope == D_FUC_FPRINTF) {
		is = 1;
		fope = D_FUC_FELWRITE1;
		pOpe = "FELWRITE1";
	}
	else return -1;

	/* 2021.7.21 */
	try_lvl = pGlobTable->try_level;
	pGlobTable->try_level = 0;
#if 0	/* 2025.6.11 */
	i = _ppParm_check_set_flag(nparm,ppParm,flgs);
	nparm -= i;
#else
	i = 0;
#endif
	if (u_flg) iParm[0] = D_PFLAG2_UNUSE_RED;
	else iParm[0] = 0;
	if ((rc=cl_eedit(&pWork,nparm-is,&ppParm[is+i])) < 0) return rc;
/*
printf("cl_func_printf: rc=%d pWork=[%s]\n",rc,pWork);
*/
	cl_set_parm_char(&tInfoParm,pWork,strlen(pWork));

	is = 0;
	if (ope == D_FUC_FPRINTF) ppParmW[is++] = ppParm[0];
	ppParmW[is] = &tInfoParm;
	rc = func_file(&pAns,pOpe,is+1,ppParmW,fope,iParm);
	pGlobTable->try_level = try_lvl;	/* 2021.7.21 */

	return rc;
}

/********************************************/
/*	32										*/
/********************************************/
int cl_printf_text(prmp,Obj,prmnum,name,opt)
parmList *prmp[];
int      *Obj;
int      prmnum;
char     *name;
int      opt;
{
	MCAT mcat;
	FILE *fp;
	int flgs[MAX_FLGS],try_lvl,i,ii,rc,nparm,optW,opt13,len,iDO;
	char *pWork,*p;
	tdtINFO_PARM tInfoParm2[2],**pparm,*parm,*pInfo;
	parmList *pparmList;
	cmdInfo cmd;
	ParList parl;
	parmList *pprmp[6],prmp2[6];
/*
printf("cl_printf_text:Enter prmnum=%d name=[%s] opt=%08x\n",prmnum,nval1(name),opt);
*/
	if (!prmp || prmnum<=0) return 0;

	nparm = prmnum;
	try_lvl = pGlobTable->try_level;
	pGlobTable->try_level = 0;
	cl_print_echo_text_init(&mcat,name,opt,flgs);

	/* 2023.9.17 */
	i = 0;
	/* 2022.12.12 */
	while (prmnum > 0) {
		pparmList = prmp[i];
		len = pparmList->prmlen;
		len = akxtsapb(0,p=strtemp(pparmList->prp,len),len);
		if (*p != '/') break;
		_set_flag(p,len,flgs);
		i++;
		prmnum--;
	}
	/* 2023.9.17 */
	memset(prmp2,0,sizeof(prmp2));
	for (ii=0;ii<6;ii++) pprmp[ii] = &prmp2[ii];
	cmd.prmp = pprmp;
	cmd.prmnum = 6;
	cmd.parl = &parl;
	iDO = cl_print_check_do(&cmd,prmp+i,prmnum);
	if (iDO > 0) prmnum = iDO - 1;
/*
printf("cl_printf_text: iDO=%d prmnum=%d\n",iDO,prmnum);
*/
	optW = D_GX_OPT_PARMINFO2|D_GX_OPT_GET_RANGE;
	/* 2023.9.17 */
	if (iDO) {
		nparm = prmnum;
	/*	i = 0;	*/
	}
	else {
		rc = cl_gx_parm_conv_arg(NULL,0,prmnum,prmp+i,Obj,optW,&pparm,&nparm);
		i = _ppParm_check_set_flag(nparm,pparm,flgs);
/*
printf("cl_printf_text: i=%d nparm=%d\n",i,nparm);
*/
		nparm -= i;
	}
	if (nparm >= 1) {
		opt13 = cl_get_option(13,0);
		if (opt13 & 0x40) flgs[0] &= ~PRN_OPT_NGEN;
		else flgs[0] |= PRN_OPT_NGEN;
		if (opt13 & 0x80) flgs[0] &= ~PRN_OPT_LTGT;
		else flgs[0] |= PRN_OPT_LTGT;
		if (opt13 & 0x200) flgs[0] &= ~D_PRN_OPT_LIST;
		else flgs[0] |= D_PRN_OPT_LIST;
		/* 2023.9.17 */
		if (iDO) {
			rc = cl_printf_text_do(prmp+i,Obj,prmnum,opt,flgs,&cmd,optW);
			pGlobTable->try_level = try_lvl;
			return rc;
		}
		else {
			if ((rc=cl_edit_opta(&pWork,nparm,pparm+i,flgs)) >= 0) {
/*
printf("cl_printf_text: rc=%d pWork=[%s]\n",rc,pWork);
*/
				akxtmcat(&mcat,pWork,rc+1);
				rc = 0;
			}
		}
	}
	cl_print_echo_text_out(&mcat,opt,flgs);
	pGlobTable->try_level = try_lvl;
	return rc;
}

/********************************************/
/*	33										*/
/********************************************/
static void _set_flag(p,len,flgs)
char *p;
int len,flgs[];
{
#if 1	/* 2025.6.15 */
	int pos;
	char c;
/*
printf("_set_flag:Enter len=%d p=%08x flgs=%08x\n",len,p,flgs);
*/
	if (!p || len<=0 || !flgs) return;
/*
printf("_set_flag:p=[%s] flgs[0]=%08x\n",p,flgs[0]);
*/
	if (*p != '/') return;

	while (len>0 && *p) {
		c = *p;
		pos = 1;
		if (c == '/') {
			pos = cl_print_set_flag(p,len,flgs);
/*
printf("_set_flag: len=%d pos=%d p=[%s]\n",len,pos,p);
*/
			if (pos <= 0) break;
			else if (pos>1 && *(p+pos-1)=='/') pos--;
		}
		p += pos;
		len -= pos;
	}
/*
printf("_set_flag:flgs[0]=%08x\n",flgs[0]);
*/
#else
	cl_print_set_flag(p,len,flgs);
#endif
}

/********************************************/
/*	34										*/
/********************************************/
static int _mcat_print_info_data(mcat,pInfoParm,flgs)
MCAT *mcat;
tdtINFO_PARM *pInfoParm;
int flgs[];
{
	int opt10,opt19,optw,w_pre,w_inx,rc,zsap,pre_inx;

	/* 2025.6.8 */
	flgs[3] = pInfoParm->pi_aux[0] & DEF_ZOK_DATA;
/*
printf("_mcat_text_infoparm:1 p_flg=%d options[10],[19]=%08x %08x\n",p_flg,pGlobTable->options[10],pGlobTable->options[19]);
*/
	rc = _print_info_data(mcat,pInfoParm,NULL,flgs);
	/* 2025.6.8 */
	return rc;
}

/********************************************/
/*	35										*/
/********************************************/
int cl_print_info_data(pWork,w_len,pInfoParm,flgs)
char *pWork;
int w_len;
tdtINFO_PARM *pInfoParm;
int flgs[];
{
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	int rc;

	mcat.mc_ipos = 0;
	if (mcat.mc_bufp) *mcat.mc_bufp = '\0';
	rc = _mcat_print_info_data(&mcat,pInfoParm,flgs);
	if (rc >= 0) {
		memnzcpy(pWork,mcat.mc_bufp,mcat.mc_ipos,w_len);
		rc = mcat.mc_ipos;
	}
	return rc;
}

/********************************************/
/*	36										*/
/********************************************/
char *cl_get_attr_name(iParm)
int  iParm[];
{
	return cl_get_attr_name_opt(iParm,0);
}

/********************************************/
/*	37										*/
/*		ope = D_FUC_LPRINT,D_FUC_FPRINT,	*/
/*			  D_FUC_PRINT, D_FUC_ECHO		*/
/********************************************/
/* 2024.12.16 */
int cl_func_print(pAns,nparm,ppParm,pot,etc_parm)
char *pAns;
int nparm,etc_parm[];
tdtINFO_PARM *ppParm[];
tdtOpeTable *pot;
{
	MCAT mcat;
	int rc,fope,iParm[5],try_lvl,is,i,flgs[MAX_FLGS],opt;
	char *pOpe;
	tdtINFO_PARM tParm,*ppParmW[2],*pInfo;
	/* 2024.12.16 */
	char *pOperator,buf[3];
	int ope,gx_opt;

	pOperator = pot->name;
	ope = pot->ope;
	gx_opt = etc_parm[1];
	try_lvl = pGlobTable->try_level;
	pGlobTable->try_level = 0;
	/* 2025.6.13 */
	if (ope == D_FUC_LPRINT) opt = 3;
	else if (ope==D_FUC_PRINT || ope==D_FUC_SPRINT || ope==D_FUC_FPRINT) opt = 1;
	else opt = 0;
	cl_print_echo_text_init(&mcat,NULL,opt,flgs);
	/* 2025.6.13 */
	if (u_flg) iParm[0] = D_PFLAG2_UNUSE_RED;
	else iParm[0] = 0;
	/* 2025.6.13 */
	rc = _func_print_sub(&mcat,pOperator,nparm,ppParm,flgs);
	/* 2025.6.13 */
	if (ope == D_FUC_LPRINT) {
		if (e_flg) ERROROUT1("%s",mcat.mc_bufp);
		else PRINTOUT1("%s",mcat.mc_bufp);
	}
	else {
		if (ope == D_FUC_FPRINT) {
			is = 1;
			fope = D_FUC_FELWRITE1;
			pOpe = "FELWRITE1";
			ppParmW[0] = ppParm[0];
			ppParmW[1] = &tParm;
		}
		else {
			is = 0;
			fope = D_FUC_ELWRITE1;
			pOpe = "ELWRITE1";
			ppParmW[0] = &tParm;
		}
#if 1	/* 2025.06.13 */
		if (akxa_log_new_line_str(buf,cl_get_option(3,0)) > 0) akxtmcats(&mcat,buf);
#endif
		cl_set_parm_char(&tParm,mcat.mc_bufp,mcat.mc_ipos);
		rc = func_file(&pAns,pOpe,is+1,ppParmW,fope,iParm);
	}
	pGlobTable->try_level = try_lvl;
	rc = 0;
	memcpy(pAns,&rc,sizeof(int));
	return 0;
}

/********************************************/
/*	39										*/
/********************************************/
/* 2024.12.16 */
int cl_func_sprint(ppAns,nparm,ppParm,pot,etc_parm)
char **ppAns;
int nparm,etc_parm[];
tdtINFO_PARM *ppParm[];
tdtOpeTable *pot;
{
	MCAT mcat;
	char *p;
	/* 2024.12.16 */
	char *pOperator;
	int ope,gx_opt,opt,flgs[MAX_FLGS];

	pOperator = pot->name;
	/* 2025.6.13 */
	opt = 1;
	cl_print_echo_text_init(&mcat,NULL,opt,flgs);
	_func_print_sub(&mcat,pOperator,nparm,ppParm,flgs);
	p = cl_tmp_const_malloc(mcat.mc_ipos+1);
	memzcpy(p,mcat.mc_bufp,mcat.mc_ipos);
	*ppAns = p;
	return 0;
}

/********************************************/
/*	40										*/
/********************************************/
int cl_print_attr(buf,buf_len,pInfoParm,iParm)
char *buf;
int buf_len;
tdtINFO_PARM *pInfoParm;
int  iParm[];
{
	int attr,size,pre,sca,iPm[4],*ipParm,fixed,len;
	char *p;

	if (!buf || (!pInfoParm && !iParm) || buf_len<30) return -1;
	fixed = 0;
	if (pInfoParm) {
		iPm[0] = pInfoParm->pi_attr;
		if (pInfoParm->pi_aux[0] & 0x0f) {
			size = pInfoParm->pi_len;
			fixed = 1;
		}
		else size = pInfoParm->pi_dlen;
		iPm[1] = size;
		iPm[2] = pInfoParm->pi_hlen;
		if (iPm[0] == DEF_ZOK_BINA) iPm[3] = pInfoParm->pi_scale;
		else iPm[3] = pInfoParm->pi_pos;
		ipParm = iPm;
		if (iParm) mem_cpy_int(iParm,iPm,4);
	}
	else if (iParm) {
		ipParm = iParm;
		if (iParm[0] && iParm[0]!=DEF_ZOK_VARI) fixed = 1;
	}
	p = cl_get_attr_name_opt(ipParm,fixed);
	len = strlen(p);
	len = memnzcpy(buf,p,len,buf_len);
	if (pInfoParm) {
		if (pInfoParm->pi_scale & D_DATA_IMAGE) {
			if (len+2 < buf_len) {
				strcat(buf+len," i");
				len += 2;
			}
		}
	}
	return len;
}

/********************************************/
/*	41										*/
/********************************************/
int cl_check_addr(p,buf,buf_len)
char *p,*buf;
int buf_len;
{
	char *pp,wrk[32];
	int rc,len;

	rc = 0;
	if (!akxm_addrchk(p)) {
		if (p) pp = "invalid addr";
		else pp = AKX_NULL_PRINT;
		sprintf(wrk,"p=%08x %s ",p,pp);
		len = strlen(wrk);
		if (buf && buf_len>22) {
			memnzcpy(buf,wrk,len,buf_len);
		}
#if 1	/* 2024.4.28 */
		if (cl_get_option(7,0) & 0x80000000) {
			printf("cl_check_addr: %s\n",wrk);
			p = NULL;
			*p = 0;
		}
#endif
		rc = -213224101;
	}
	return rc;
}

/********************************************/
/*	42										*/
/********************************************/
static int _ppParm_check_set_flag(nparm,ppParm,flgs)
int nparm,flgs[];
tdtINFO_PARM *ppParm[];
{
	tdtINFO_PARM *pInfo;
	int i;

	i = 0;
	while (nparm > 0) {
		pInfo = ppParm[i];
		if (!_check_set_flag(&pInfo,2,flgs)) break;
		i++;
		nparm--;
	}
	return i;
}

/********************************************/
/*	43										*/
/********************************************/
int cl_print_check_do(cmd,prmp,prmnum)
cmdInfo *cmd;
parmList *prmp[];
int prmnum;
{
	static MCAT mcat2={'M','C',256,0,0,0,NULL,0};
	int iDO,i,len,rc,opt,i0,n,ii,set_prmp,num,pprmpnum;
	char *p;
	parmList *pparmList,**pprmp;
	ParList *parl;

	parl = cmd->parl;
	rc = iDO = set_prmp = 0;
	for (i=0;i<prmnum;i++) {
		pparmList = prmp[i];
		len = pparmList->prmlen;
		len = akxtsapb(0,p=strtemp(pparmList->prp,len),len);
		if (!memrngcmp_opt(p,len,"DO",0,2,1) || !memrngcmp_opt(p,len,"FOR",0,3,1)) {
			iDO = i + 1;
			i0 = iDO;
			break;
		}
		else if (!memicmp(p,"FOR(",4)) {
			iDO = i + 1;
			i0 = iDO - 1;
			break;
		}
	}
	if (iDO) {
		if (!memicmp(p,"DO",2)) {
			opt = C_DO;
			n = 2;
		}
		else {
			opt = C_FOR;
			p = "FOR";
			n = 3;
			set_prmp = 1;
		}
		mcat2.mc_ipos = 0;
		if ((rc=cl_prm_gather(&mcat2,prmp,prmnum,i0)) >= 0) {
			parl->par = mcat2.mc_bufp;
			parl->parlen = mcat2.mc_ipos;
			if (i0 < iDO) {
				parl->par += 3;
				parl->parlen -= 3;
				set_prmp = 0;
			}
			pprmpnum = cmd->prmnum;
			pprmp = cmd->prmp;
			cmd->cid = opt;
			cmd->prmnum = prmnum - iDO + 1;
			pprmp[0]->prp = p;
			pprmp[0]->prmlen = n;
/*
printf("cl_print_check_do: opt=%08x cmd->prmnum=%d parlen=%d par=[%s]\n",opt,cmd->prmnum,parl->parlen,parl->par);
*/
			if (set_prmp) {
				num = X_MIN(pprmpnum,cmd->prmnum);
				for (i=0,ii=1;ii<num;i++,ii++) {
					*(pprmp[ii]) = *prmp[i+iDO];
/*
printf("cl_print_check_do: cmd->prmp[%d]->prp=[%s]\n",ii,pprmp[ii]->prp);
*/
				}
			}
			rc = iDO;
		}
	}
	return rc;
}

/********************************************/
/*	44										*/
/********************************************/
int cl_get_loop_ctl(cmd,pcrLCB,Obj,line,line_len)
cmdInfo *cmd;
BlockCB *pcrLCB;
int *Obj;
char *line;
int line_len;
{
	static char *p0=NULL;
	static char sep[]={" \t\"'();"};
	int rc,nparm,iOpt,i,ii,to_step,n,for_step;
	parmList **pprmp;
	char **argv3,*p;
	ParList parl[6],parl2[6];

	to_step = rc = 0;
/*
printf("cl_get_loop_ctl: line_len=%d line=[%s]\n",line_len,line);
*/
	pprmp = cmd->prmp;
	if (cmd->cid == C_DO) {
		if ((rc=cl_change_from_do(line,line_len,parl,parl2)) < 0) return rc;
		to_step = 1;
	}
	else {
		if ((rc=cl_change_from_for(line,line_len,parl)) < 0) return rc;
		else if (!rc) {
			if ((rc=cl_change_from_to_step(pprmp,cmd->prmnum,parl,parl2)) < 0) return rc;
			to_step = 1;
		}
	}
	for_step = rc;
	if (rc > 0) {
		if (to_step) {
			pprmp[1]->prp = parl[0].par;
			pprmp[1]->prmlen = parl[0].parlen;
			/* 2023.9.23 */
			nparm = rc;
			for (i=0,ii=2;i<nparm;i++,ii++) {
				pprmp[ii]->prp = parl2[i].par;
				pprmp[ii]->prmlen = parl2[i].parlen;
			}
			cmd->prmnum = nparm + 2;
		}
		else {
			for (i=0,ii=1;i<3;i++,ii++) {
/*
printf("cl_get_loop_ctl: parl[%d].parlen=%d par=[%s]\n",i,parl[i].parlen,parl[i].par);
*/
				pprmp[ii]->prp = parl[i].par;
				pprmp[ii]->prmlen = parl[i].parlen;
			}
			cmd->prmnum = 4;
		}
	}
	if (cmd->prmnum > 0) {
/*
printf("cl_get_loop_ctl: cmd->prmnum=%d\n",cmd->prmnum);
*/
		if ((rc=_set_for(cmd,Obj,&iOpt,&argv3)) >= 0) {
			memset(pcrLCB,0,sizeof(BlockCB));
			pcrLCB->cid = cmd->cid;
			pcrLCB->iLoopMax = INT_MAX;
			pcrLCB->iUsed = D_LOOP_FOR;
			pcrLCB->iOpt = iOpt;
			pcrLCB->pSwParm = (char *)argv3;
/*
printf("cl_get_loop_ctl: iOpt=%08x\n",iOpt);
*/
		}
	}
/*
printf("cl_get_loop_ctl:Exit rc=%d\n",rc);
*/
	return rc;
}

/********************************************/
/*	45										*/
/********************************************/
int cl_print_echo_text_do(prmp0,Obj,prmnum0,name,opt,flgs,cmd)
parmList *prmp0[];
int *Obj,prmnum0,opt,flgs[];
char *name;
cmdInfo *cmd;
{
	MCAT mcat;
	BlockCB tLoopCB,*pcrLCB;
	ParList *parl;
	char *line;
	int i,rc,loop_max,count,line_len;

	parl = cmd->parl;
	pcrLCB = &tLoopCB;
	line = parl->par;
	line_len = parl->parlen;
	if ((rc=cl_get_loop_ctl(cmd,pcrLCB,Obj,line,line_len)) >= 0) {
		for (;;) {
			if ((loop_max=cl_get_loop_max(NULL)) < 0) break;
			count = pcrLCB->iLoopCounter;
/*
printf("cl_print_echo_text_do: count=%d loop_max=%d\n",count,loop_max);
*/
			if (count<loop_max && count < pcrLCB->iLoopMax) {
				if ((rc=_exec_for(cmd,Obj,pcrLCB)) <= 0) break;
				cl_print_echo_text_init(&mcat,name,opt,flgs);
				_mcat_text(&mcat,prmp0,Obj,prmnum0,flgs);
				cl_print_echo_text_out(&mcat,opt,flgs);
			}
			else break;
			pcrLCB->iLoopCounter++;
		}
	}
	return rc;
}

/********************************************/
/*	46										*/
/********************************************/
int cl_printf_text_do(prmp0,Obj,prmnum0,opt,flgs,cmd,optW)
parmList *prmp0[];
int *Obj,prmnum0,opt,flgs[],optW;
cmdInfo *cmd;
{
	MCAT mcat;
	BlockCB tLoopCB,*pcrLCB;
	tdtINFO_PARM **pparm;
	ParList *parl;
	char *line,*pWork;
	int i,rc,loop_max,count,line_len,nparm;
/*
printf("cl_printf_text_do:Enter nparm=%d\n",nparm);
*/
	cl_print_echo_text_init(NULL,NULL,opt,flgs);
	parl = cmd->parl;
	pcrLCB = &tLoopCB;
	line = parl->par;
	line_len = parl->parlen;
	if ((rc=cl_get_loop_ctl(cmd,pcrLCB,Obj,line,line_len)) >= 0) {
		for (;;) {
			if ((loop_max=cl_get_loop_max(NULL)) < 0) break;
			count = pcrLCB->iLoopCounter;
/*
printf("cl_printf_text_do: count=%d loop_max=%d\n",count,loop_max);
*/
			if (count<loop_max && count < pcrLCB->iLoopMax) {
				if ((rc=_exec_for(cmd,Obj,pcrLCB)) <= 0) break;
				if ((rc=cl_gx_parm_conv_arg(NULL,0,prmnum0,prmp0,Obj,optW,&pparm,&nparm)) < 0) break;
				i = _ppParm_check_set_flag(nparm,pparm,flgs);
/*
printf("cl_printf_text_do: i=%d nparm=%d\n",i,nparm);
*/
				nparm -= i;
			/*	cl_print_echo_text_init(&mcat,name,opt,flgs);	*/
				if ((rc=cl_edit_opta(&pWork,nparm,pparm+i,flgs)) >= 0) {
/*
printf("cl_printf_text_do: rc=%d pWork=[%s]\n",rc,pWork);
*/
					/* 2023.10.31 */
					cl_print_echo_text_out_sub(pWork,rc,opt,flgs);
				}
				else break;
			}
			else break;
			pcrLCB->iLoopCounter++;
		}
	}
	return rc;
}

/********************************************/
/*	47										*/
/*			opt_edit[0] : flgs[0]			*/
/*				...							*/
/*			opt_edit[4] : flgs[4]			*/
/*			opt_edit[5] : flgs[5] option No.13*/
/*			opt_edit[6] : exp_form			*/
/*			opt_edit[7] : pre				*/
/*			opt_edit[8] : inx				*/
/*			opt_edit[9] : ZSAP				*/
/********************************************/
int cl_print_set_opt_edit(flgs,opt_edit)
int flgs[],opt_edit[];
{
	int opt11,opt20,optw,w_pre,w_inx,rc,zsap,pre_inx;

	if (flgs)
		mem_cpy_int(opt_edit,flgs,MAX_FLGS);
	else
		mem_set_int(opt_edit,0,MAX_FLGS);

	opt11 = pGlobTable->options[10];
	opt20 = pGlobTable->options[19];
	/* 2024.9.28 */
	zsap =  opt20 / 10000;
	pre_inx = opt20 % 10000;
	w_pre = pre_inx % 100;
	w_inx = pre_inx / 100;
	optw = opt11;
	if (zsap) optw |= 0x0100;
	if (flgs) {
		if (p_flg)  optw |= 0x40;
		if (np_flg) optw &= ~0x40;
		if (pz_flg) optw |= 0x0100;
		if (pn_flg) optw &= ~0x0100;
		if (exp_pre >= 0) w_pre = exp_pre;
		if (exp_inx >= 0) w_inx = exp_inx;
	}
	opt_edit[6] = optw & 0x40;
	opt_edit[7] = w_pre;
	opt_edit[8] = w_inx;
	opt_edit[9] = optw & 0x0100;
/*
printf("cl_print_set_opt_edit: optw=%08x w_pre=%d w_inx=%d\n",optw,w_pre,w_inx);
*/
	return 0;
}

/********************************************/
/*	48										*/
/********************************************/
int cl_print_info(mcat,pInfoParm,flgs)
MCAT *mcat;
tdtINFO_PARM *pInfoParm;
int flgs[];
{
	return _print_info(mcat,pInfoParm,NULL,flgs);
}
