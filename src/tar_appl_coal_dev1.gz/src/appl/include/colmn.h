/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/****************************************/
/*										*/
/*	colmn.h								*/
/*										*/
/****************************************/
/*  */
#ifndef _COLMN_H
#define _COLMN_H

#include <math.h>
#include <fenv.h>

#include "akacommon.h"

#include "cmprot.h"
#include "cmmacro.h"
#include "cmconst.h"
#include "cmerror.h"
#include "cmstruct.h"

#define D_FOR_AKB
#define CMDOBJECT
#define CANCEL_WHEN_EOF

#include "clconst.h"
#include "cllocal.h"
#include "clprot.h"

#endif	/* _COLMN_H */
