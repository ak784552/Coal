static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************************************
*																			*
*	  �����ړI�@�@�F  ���Z����												*
*																			*
*	  �֐����@�@�@�F�@int cl_gx_funcBexp(pInfoParmW,pOperator,nparm,pParm)	*
*						tdtInfoParm *pInfoParmW;							*
*						char *pOperator;									*
*						tdtInfoParm *pParm;									*
*						int nparm;											*
*																			*
*	  �߂�l�@�@�@�F�@ERROR									�@				*
*					  NORMAL												*
*																			*
*	  �����T�v�@�@�F�@														*
*	21522XXYY																*
*****************************************************************************/
#include <colmn.h>

extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];
extern tdtIterate_ctl gtIter_ctl[];

int replace();
int condas();
int cl_func_conv_parm();
int cl_func_f();
int cl_func_list();
int cl_set_list();
int cl_ope_list();
int cl_cons_list();
int cl_set_array();
int cl_array_ope();
/*int cl_array_map();*/
int cl_func_set_struct();
int cl_func_count();
int cl_func_index();
int cl_cmpt_is();
int cl_cmpt_to_number();
int cl_cmpt_math();
int cl_cmpt_to_bulk();
int cl_cmpt_to_bulks();
int cl_func_to_char();
int cl_func_to_date();
int cl_func_date_add();
int cl_func_date_diff();
int cl_func_add_months();
int cl_func_last_day();
int cl_func_add_to_date();
int cl_func_set_date_part();
int cl_cmpt_to();
int rep_condas();
int substrm();
/*int concat();*/
int cl_get_args();
int cl_get_word();
int cl_split();
int cl_trim();
int cl_strings();
int cl_leftm();
int cl_rightm();
int cl_rlpad();
int cl_chr();
int cl_asc();
int cl_shsbs();
int cl_replace();
int cl_repchar();
int cl_repstrs();
int cl_rep_like();
int cl_in_like();
int cl_in_regex();
int cl_rep_regex();
int cl_glip();
int cl_grep();
int cl_ex_shell();
int cl_ex_no_free();
int cl_ex_shut_ctl();
int cl_ex_exit();
int cl_edit();
int cl_eedit();
int cl_lenm();
int cl_lenw();
int cl_func_env();
int cl_func_get_time();
int cl_ex_eval();
int cl_ex_ecmd();
int cl_ex_nval();
int cl_ex_nsval();
int cl_ex_ndef();
int cl_ex_is_null();
int cl_ex_is_undef();
int cl_ex_decode();
int cl_ex_iif();
int cl_ex_sort();
int cl_ex_round();
int cl_ex_xhash();
int cl_ex_channel();
int cl_func_mem_used();
int cl_func_print();
/*int cl_func_fprint();*/
int cl_func_sprint();
int cl_func_printf();
int cl_func_new();
int cl_func_times();
int cl_func_getval();
int cl_func_str_add();
int cl_func_str_exp();
int cl_func_str_conv();
int cl_func_range();
int cl_func_complex();
int cl_func_redirect();
int cl_func_dec_max_pre();
int cl_func_jisho();
int cl_func_to_dnara();
int cl_func_beep();
int cl_func_msgbox();
/*int cl_func_append();*/
int cl_func_sscanf();
int cl_func_rational();
int cl_func_reduction();
int cl_func_upper();
int cl_func_lower();
int cl_func_pop();
int cl_func_random();
int cl_func_adjust();
int cl_func_insert();
/*int cl_func_unique();*/
int cl_func_var_list();

static int _rep_condas(/*pAns,nparm,ppParm,func*/);
static int _func_count_exf(/*pWork,nparm,ppParm*/);
static int _ope_list_exf(/*pInfoParmW,nparm,ppParm,pot,etc_parm*/);
static int _lenm_exf(/*pAns,nparm,ppParm,pot,etc_parm*/);
static int _lenw_exf(/*pAns,nparm,ppParm,pot,etc_parm*/);
static int _substrm_concat(/*pAns,nparm,ppParm,pot,etc_parm*/);
static int _leftm_exf(/*pAns,nparm,ppParm,pot,etc_parm*/);
static int _rightm_exf(/*pAns,nparm,ppParm,pot,etc_parm*/);
static int _rlpad_exf(/*pAns,nparm,ppParm,pot,etc_parm*/);
static int _asc_exf(/*pWork,nparm,ppParm,pot,etc_parm*/);
static int _in_like_exf(/*pWork,nparm,ppParm,pot,etc_parm*/);
static int _in_regex_exf(/*pWork,nparm,ppParm,pot,etc_parm*/);
static int _mid(/*pInfoParmW,nparm,ppParm,pot,etc_parm*/);
static int _agg(/*pInfoParmW,nparm,ppParm*/);
static int _leftm_rightm_exf(/*pInfoParmW,nparm,ppParm,pot,etc_parm,rl*/);

/*	name		nparm ope					kubun		reta    arg_kbn ret_kbn option resv[2] */
static qOpeTable tOpeTbl[]=
	{"IS"			,2,D_FUC_IS				,IS			,DEF_ZOK_BINA,2,3,cl_cmpt_is		,0,0,0	/* 2-->3*/
	,"MOD"			,2,D_FUC_MOD			,MATH		,DEF_ZOK_BINA,0,4,cl_cmpt_math		,0,0,0
	,"TO_NUMBER"	,1,D_FUC_TO_NUMBER		,TO			,DEF_ZOK_BINA,0,4,cl_cmpt_to_number	,0,0,0
	,"TO_BULK"		,1,D_FUC_TO_BULK		,TO			,DEF_ZOK_BULK,9,2,cl_cmpt_to_bulk	,0,0,0
	,"TO_BULKS"		,1,D_FUC_TO_BULKS		,TO			,DEF_ZOK_BULK,9,2,cl_cmpt_to_bulks	,0,0,0
	,"TO_CHAR"		,1,D_FUC_TO_CHAR		,TO			,DEF_ZOK_CHAR,0,1,cl_func_to_char	,0,0,0
	,"TO_DATE"		,1,D_FUC_TO_DATE		,TO			,DEF_ZOK_DATE,0,1,cl_func_to_date	,0,0,0
	,"TO_DNARA"		,1,D_FUC_TO_DNARA		,TO			,DEF_ZOK_BULK,0,1,cl_func_to_dnara	,D_FUC_NO_CHK_NULL,0,0
	,"DATE_ADD"		,3,D_FUC_DATE_ADD		,TO			,DEF_ZOK_DATE,0,1,cl_func_date_add	,0,0,0
	,"DATE_DIFF"	,3,D_FUC_DATE_DIFF		,TO			,DEF_ZOK_DATE,0,1,cl_func_date_diff	,0,0,0
	,"ADD_MONTHS"	,2,D_FUC_ADD_MONTHS		,TO			,DEF_ZOK_DATE,0,1,cl_func_add_months,0,0,0
	,"LAST_DAY"		,1,D_FUC_LAST_DAY		,TO			,DEF_ZOK_DATE,0,1,cl_func_last_day	,0,0,0
	,"ADD_TO_DATE"	,3,D_FUC_ADD_TO_DATE	,TO			,DEF_ZOK_DATE,0,1,cl_func_add_to_date,0,0,0
	,"SET_DATE_PART",3,D_FUC_SET_DATE_PART	,TO			,DEF_ZOK_DATE,0,1,cl_func_set_date_part,0,0,0
	,"TO"			,2,D_FUC_TO				,TO			,DEF_ZOK_CHAR,1,6,cl_cmpt_to		,0,0,0
	,"UPPER"		,1,D_FUC_UPPER			,TO			,DEF_ZOK_CHAR,1,2,cl_func_upper	,0,0,0
	,"LOWER"		,1,D_FUC_LOWER			,TO			,DEF_ZOK_CHAR,1,2,cl_func_lower	,0,0,0
	,"LIKE"			,2,D_FUC_LIKE			,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"iLIKE"		,2,D_FUC_ILIKE			,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"REGEX"		,2,D_FUC_REGEX			,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"iREGEX"		,2,D_FUC_IREGEX			,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"MAX"			,1,D_FUC_MAX			,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"MIN"			,1,D_FUC_MIN			,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"SUM"			,1,D_FUC_SUM			,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"AVG"			,1,D_FUC_AVG			,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"PRODUCT"		,1,D_FUC_PRODUCT		,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"ABS"			,1,D_FUC_ABS			,MATH		,DEF_ZOK_BINA,0,5,cl_cmpt_math	,0,0,0
	,"LENG"			,1,D_FUC_LEN			,FUNCTION	,DEF_ZOK_BINA,0x14,3,_lenm_exf	,0,0,0	/* 2-->3*/
	,"LENGTH"		,1,D_FUC_LEN			,FUNCTION	,DEF_ZOK_BINA,0x14,3,_lenm_exf	,0,0,0	/* 2-->3*/
	,"LENB"			,1,D_FUC_LENB			,FUNCTION	,DEF_ZOK_BINA,0x94,3,_lenm_exf	,0,0,0	/* 2-->3*/
	,"LENW"			,1,D_FUC_LENW			,FUNCTION	,DEF_ZOK_BINA,0x14,3,_lenw_exf	,0,0,0	/* 2-->3*/
	,"REP"			,2,D_FUC_REP			,STRING		,DEF_ZOK_CHAR,20,2,_rep_condas	,0,0,0
	,"CONDAS"		,2,D_FUC_CONDAS			,STRING		,DEF_ZOK_CHAR,20,2,_rep_condas	,0,0,0
	,"SUBSTR"		,2,D_FUC_SUBSTR			,STRING		,DEF_ZOK_CHAR,0x14,2,_substrm_concat	,0,0,0
	,"SUBSTRB"		,2,D_FUC_SUBSTRB		,STRING		,DEF_ZOK_CHAR,0x94,2,_substrm_concat	,0,0,0
#if 1	/* 2025.9.4 */
	,"MID"			,2,D_FUC_SUBSTR			,STRING		,DEF_ZOK_CHAR,0x14,1,_mid	,0,0,0
#else
	,"MID"			,2,D_FUC_SUBSTR			,STRING		,DEF_ZOK_CHAR,0x14,2,_substrm_concat	,0,0,0
#endif
	,"MIDB"			,2,D_FUC_SUBSTRB		,STRING		,DEF_ZOK_CHAR,0x94,2,_substrm_concat	,0,0,0
	,"CONCAT"		,1,D_FUC_CONCAT			,STRING		,DEF_ZOK_CHAR,20,2,_substrm_concat		,0,0,0
	,"&+"			,2,D_FUC_CONCAT			,STRING		,DEF_ZOK_CHAR,20,2,_substrm_concat		,0,0,0
	,"|+"			,2,D_FUC_CONCAT			,STRING		,DEF_ZOK_CHAR,20,2,_substrm_concat		,0,0,0
	,"GETARGS"		,2,D_FUC_GETARGS		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_get_args	,0,0,0	/* 2-->3*/
	,"GETWORD"		,2,D_FUC_GETWORD		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_get_word	,0,0,0	/* 2-->3*/
	,"SPLIT"		,2,D_FUC_SPLIT			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_split		,0,0,0
	,"AND"			,1,D_FUC_AND			,LOGICAL	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"OR"			,1,D_FUC_OR				,LOGICAL	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"EQ"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"NE"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"GT"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"GE"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"LT"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"LE"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"iEQ"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"iNE"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"iGT"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"iGE"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"iLT"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"iLE"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"IN"			,2,D_FUC_IN				,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"iIN"			,2,D_FUC_IIN			,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"INSTR"		,2,D_FUC_INSTR			,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"INiSTR"		,2,D_FUC_INISTR			,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"INrSTR"		,2,D_FUC_INRSTR			,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"INirSTR"		,2,D_FUC_INIRSTR		,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"INSTRCHARS"	,2,D_FUC_INSTRCHARS		,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,6
	,"SKIP_OPT"		,2,D_FUC_SKIP_OPT		,COMP		,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"TRIM"			,1,D_FUC_TRIM			,STRING		,DEF_ZOK_CHAR,1,2,cl_trim		,0,0,0
	,"STRINGS"		,2,D_FUC_STRINGS		,STRING		,DEF_ZOK_CHAR,1,2,cl_strings	,0,0,0
#if 1	/* 2025.10.8 */
	,"LEFT"			,2,D_FUC_LEFT			,STRING		,DEF_ZOK_CHAR,0x14,1,_leftm_exf	,0,0,0
	,"LEFTB"		,2,D_FUC_LEFTB			,STRING		,DEF_ZOK_CHAR,0x94,1,_leftm_exf	,0,0,0
	,"RIGHT"		,2,D_FUC_RIGHT			,STRING		,DEF_ZOK_CHAR,0x14,1,_rightm_exf,0,0,0
	,"RIGHTB"		,2,D_FUC_RIGHTB			,STRING		,DEF_ZOK_CHAR,0x94,1,_rightm_exf,0,0,0
#else
	,"LEFT"			,2,D_FUC_LEFT			,STRING		,DEF_ZOK_CHAR,0x14,2,_leftm_exf	,0,0,0
	,"LEFTB"		,2,D_FUC_LEFTB			,STRING		,DEF_ZOK_CHAR,0x94,2,_leftm_exf	,0,0,0
	,"RIGHT"		,2,D_FUC_RIGHT			,STRING		,DEF_ZOK_CHAR,0x14,2,_rightm_exf,0,0,0
	,"RIGHTB"		,2,D_FUC_RIGHTB			,STRING		,DEF_ZOK_CHAR,0x94,2,_rightm_exf,0,0,0
#endif
	,"RPAD"			,2,D_FUC_RPAD			,STRING		,DEF_ZOK_CHAR,0x14,2,_rlpad_exf	,0,0,0
	,"LPAD"			,2,D_FUC_LPAD			,STRING		,DEF_ZOK_CHAR,0x14,2,_rlpad_exf	,0,0,0
	,"RPADB"		,2,D_FUC_RPADB			,STRING		,DEF_ZOK_CHAR,0x94,2,_rlpad_exf	,0,0,0
	,"LPADB"		,2,D_FUC_LPADB			,STRING		,DEF_ZOK_CHAR,0x94,2,_rlpad_exf	,0,0,0
	,"CHR"			,1,D_FUC_CHR			,STRING		,DEF_ZOK_CHAR,1,2,cl_chr		,0,0,0
	,"ASC"			,1,D_FUC_ASC			,STRING		,DEF_ZOK_BINA,0x14,3,_asc_exf	,0,0,0	/* 2-->3 */
	,"ASCB"			,1,D_FUC_ASCB			,STRING		,DEF_ZOK_BINA,0x94,3,_asc_exf	,0,0,0	/* 2-->3 */
	,"EDIT"			,2,D_FUC_EDIT			,STRING		,DEF_ZOK_CHAR,1,2,cl_edit		,0,0,0
	,"EEDIT"		,2,D_FUC_EEDIT			,STRING		,DEF_ZOK_CHAR,1,2,cl_eedit		,0,0,0
	,"REPLACE"		,3,D_FUC_REPLACE		,STRING		,DEF_ZOK_CHAR,1,2,cl_replace	,0,0,0
	,"REPCHAR"		,3,D_FUC_REPCHAR		,STRING		,DEF_ZOK_CHAR,1,2,cl_repchar	,0,0,0
	,"REPSTRS"		,4,D_FUC_REPSTRS		,STRING		,DEF_ZOK_CHAR,1,2,cl_repstrs	,0,0,0
	,"REPLIKE"		,3,D_FUC_REPLIKE		,STRING		,DEF_ZOK_CHAR,1,2,cl_rep_like	,0,0,0
	,"REPREGEX"		,3,D_FUC_REPREGEX		,STRING		,DEF_ZOK_CHAR,1,2,cl_rep_regex	,0,0,0
	,"SHSBS"		,2,D_FUC_SHSBS			,STRING		,DEF_ZOK_CHAR,0,1,cl_shsbs		,0,0,0
	,"GLIP"			,2,D_FUC_GLIP			,STRING		,DEF_ZOK_CHAR,0,1,cl_glip		,0,0,0
	,"GREP"			,2,D_FUC_GREP			,STRING		,DEF_ZOK_CHAR,0,1,cl_grep		,0,0,0
	,"INLIKE"		,4,D_FUC_INLIKE			,FUNCTION	,DEF_ZOK_BINA,20,3,_in_like_exf	,0,0,0	/* 2-->3 */
	,"INREGEX"		,4,D_FUC_INREGEX		,FUNCTION	,DEF_ZOK_BINA,20,3,_in_regex_exf,0,0,0
	,"STR_ADD"		,2,D_FUC_STR_ADD		,STRING		,DEF_ZOK_CHAR,0,1,cl_func_str_add,0,0,0
	,"STR_EXP"		,3,D_FUC_STR_EXP		,STRING		,DEF_ZOK_CHAR,0,1,cl_func_str_exp,0,0,0
	,"STR_CONV"		,1,D_FUC_STR_CONV		,STRING		,DEF_ZOK_CHAR,0,1,cl_func_str_conv,0,0,0	/* 1,2-->0,1 */
	,"STRADD"		,2,D_FUC_STR_ADD		,STRING		,DEF_ZOK_CHAR,0,1,cl_func_str_add,0,0,0
	,"STREXP"		,3,D_FUC_STR_EXP		,STRING		,DEF_ZOK_CHAR,0,1,cl_func_str_exp,0,0,0
	,"STRCONV"		,1,D_FUC_STR_CONV		,STRING		,DEF_ZOK_CHAR,0,1,cl_func_str_conv,0,0,0	/* 1,2-->0,1 */
	,"SSCANF"		,2,D_FUC_SSCANF			,STRING		,DEF_ZOK_BINA,20,3,cl_func_sscanf,0,0x03,0
	,"FOPEN"		,1,D_FUC_FOPEN			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_RET_CODE,0,0
	,"FCLOSE"		,1,D_FUC_FCLOSE			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_RET_CODE,0,0
	,"FGETLINE"		,1,D_FUC_FGETLINE		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL,0,0,0
	,"FPUTLINE"		,1,D_FUC_FPUTLINE		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_1st_CHK_NULL|D_FUC_RET_CODE,0,0
	,"FELREAD1"		,2,D_FUC_FELREAD1		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL,0,0,0
	,"FELWRITE"		,2,D_FUC_FELWRITE		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"FELWRITE1"	,2,D_FUC_FELWRITE1		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_1st_CHK_NULL|D_FUC_RET_CODE,0,0
	,"UNLINK"		,1,D_FUC_UNLINK			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_RET_CODE,0,0
	,"POPEN"		,1,D_FUC_POPEN			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_RET_CODE,0,0
	,"PCLOSE"		,1,D_FUC_PCLOSE			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_RET_CODE,0,0
	,"GETLINE"		,0,D_FUC_GETLINE		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL,0,0,0
	,"PUTLINE"		,0,D_FUC_PUTLINE		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_NO_CHK_NULL,0,0
	,"ELREAD1"		,1,D_FUC_ELREAD1		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL,0,0,0
	,"ELWRITE"		,1,D_FUC_ELWRITE		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_NO_CHK_NULL,0,0
	,"ELWRITE1"		,1,D_FUC_ELWRITE1		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_NO_CHK_NULL,0,0
	,"OPENDIR"		,1,D_FUC_OPENDIR		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_RET_CODE,0,0
	,"READDIR"		,1,D_FUC_READDIR		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL,0,0,0
	,"CLOSEDIR"		,1,D_FUC_CLOSEDIR		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_RET_CODE,0,0
	,"STAT"			,1,D_FUC_STAT			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_RET_CODE,0,0
	,"FPSTAT"		,1,D_FUC_FPSTAT			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"GETCHAR"		,0,D_FUC_GETCHAR		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL,0,0,0
	,"PUTCHAR"		,1,D_FUC_PUTCHAR		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_NO_CHK_NULL,0,0
	,"GETC"			,1,D_FUC_GETC			,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL,0,0,0
	,"PUTC"			,2,D_FUC_PUTC			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,D_FUC_1st_CHK_NULL|D_FUC_RET_CODE,0,0
	,"RENAME"		,2,D_FUC_RENAME			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"SYSLOG"		,2,D_FUC_SYSLOG			,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL,D_FUC_NO_CHK_NULL,0,0
	,"LOGOUT"		,2,D_FUC_LOGOUT			,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL,D_FUC_NO_CHK_NULL,0,0
	,"GETLOGPARM"	,2,D_FUC_GETLOGPARM		,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"SETLOGPARM"	,2,D_FUC_SETLOGPARM		,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"RESLOGPARM"	,1,D_FUC_RESLOGPARM		,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"SHELL"		,1,D_FUC_SHELL			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_ex_shell	,0,0,0	/* 2-->3*/
	,"NOFREE"		,0,D_FUC_NOFREE			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_ex_no_free	,0,0,0	/* 2-->3*/
	,"SHUTCTL"		,0,D_FUC_SHUTCTL		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_ex_shut_ctl,0,0,0	/* 2-->3*/
	,"EXIT"			,0,D_FUC_EXIT			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_ex_exit	,0,0,0	/* 2-->3*/
	,"BYE"			,0,D_FUC_EXIT			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_ex_exit	,0,0,0	/* 2-->3*/
	,"QUIT"			,0,D_FUC_EXIT			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_ex_exit	,0,0,0	/* 2-->3*/
	,"SETENV"		,2,D_FUC_SETENV			,FUNCTION	,DEF_ZOK_BINA,20,2,cl_func_env	,0,0,0
	,"UNSETENV"		,1,D_FUC_UNSETENV		,FUNCTION	,DEF_ZOK_BINA,20,2,cl_func_env	,0,0,0
	,"PUTENV"		,1,D_FUC_PUTENV			,FUNCTION	,DEF_ZOK_BINA,20,2,cl_func_env	,0,0,0
	,"GETENV"		,1,D_FUC_GETENV			,FUNCTION	,DEF_ZOK_CHAR,20,2,cl_func_env	,0,0,0
	,"GETTIME"		,0,D_FUC_GETTIME		,FUNCTION	,DEF_ZOK_DECI,0,1,cl_func_get_time,0,0,0
	,"EVAL"			,1,D_FUC_EVAL			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_eval	,0,0,0
	,"ECMD"			,1,D_FUC_ECMD			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_ex_ecmd	,0,0,0
	,"NVAL"			,2,D_FUC_NVAL			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_nval	,D_FUC_NO_CHK_NULL,0,0
	,"NULLIF"		,2,D_FUC_NVAL			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_nval	,D_FUC_NO_CHK_NULL,0,0
	,"NSVAL"		,2,D_FUC_NSVAL			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_nsval	,D_FUC_NO_CHK_NULL,0,0
	,"NDEF"			,1,D_FUC_NDEF			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_ndef	,D_FUC_NO_CHK_NULL,0,0
	,"IS_NULL"		,1,D_FUC_IS_NULL		,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_is_null	,D_FUC_NO_CHK_NULL,0,0
	,"IS_UNDEF"		,1,D_FUC_IS_UNDEF		,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_is_undef,D_FUC_NO_CHK_NULL,0,0
	,"DECODE"		,3,D_FUC_DECODE			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_decode	,0,0,0
	,"IIF"			,3,D_FUC_IIF			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_iif		,0,0,0
	,"XHASH"		,2,D_FUC_XHASH			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_ex_xhash	,0,0,0	/* 2-->3*/
	,"CHANNEL"		,2,D_FUC_CHANNEL		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_ex_channel	,0,0,0	/* 2-->3*/
	,"GETMEMUSED"	,0,D_FUC_GETMEMUSED		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_mem_used,0,0,0	/* 2-->3 */
	,"LPRINT"		,0,D_FUC_LPRINT			,FUNCTION	,DEF_ZOK_BINA,20,3,cl_func_print	,D_FUC_NO_CHK_NULL,0,0	/* 2-->3*/
	,"PRINT"		,0,D_FUC_PRINT			,FUNCTION	,DEF_ZOK_BINA,20,3,cl_func_print	,D_FUC_NO_CHK_NULL,0,0	/* 2-->3*/
	,"ECHO"			,0,D_FUC_ECHO			,FUNCTION	,DEF_ZOK_BINA,20,3,cl_func_print	,D_FUC_NO_CHK_NULL,0,0	/* 2-->3*/
	,"SAY"			,0,D_FUC_ECHO			,FUNCTION	,DEF_ZOK_BINA,20,3,cl_func_print	,D_FUC_NO_CHK_NULL,0,0	/* 2-->3*/
	,"FPRINT"		,0,D_FUC_FPRINT			,FUNCTION	,DEF_ZOK_BINA,20,3,cl_func_print	,D_FUC_1st_CHK_NULL|D_FUC_RET_CODE,0,0
	,"SPRINT"		,0,D_FUC_SPRINT			,FUNCTION	,DEF_ZOK_CHAR,20,2,cl_func_sprint,D_FUC_1st_CHK_NULL|D_FUC_RET_CODE,0,0
	,"PRINTF"		,0,D_FUC_PRINTF			,FUNCTION	,DEF_ZOK_BINA,20,3,cl_func_printf,D_FUC_NO_CHK_NULL,0,0
	,"FPRINTF"		,0,D_FUC_FPRINTF		,FUNCTION	,DEF_ZOK_BINA,20,3,cl_func_printf,D_FUC_1st_CHK_NULL|D_FUC_RET_CODE,0,0

	,"$"			,0,D_FUC_DOL			,FUNCTION	,DEF_ZOK_CHAR,21,1,cl_func_conv_parm	,0,0,0
	,"#"			,0,D_FUC_IGE			,FUNCTION	,DEF_ZOK_CHAR,21,1,cl_func_conv_parm	,0,0,0
	,"%"			,0,D_FUC_PAS			,FUNCTION	,DEF_ZOK_CHAR,21,1,cl_func_conv_parm	,0,0,0
	,"FF"			,1,D_FUC_TO_FUNC		,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_func_f			,0,0,0
	,"ARRAYCLR"		,1,D_FUC_ARRAY_CLR		,FUNCTION	,DEF_ZOK_BINA,20,3,cl_array_ope		,D_FUC_1st_CHK_NULL|D_FUC_RET_CODE,0,4	/* 2-->3*/
	,"ARRAYCPY"		,2,D_FUC_ARRAY_CPY		,FUNCTION	,DEF_ZOK_BINA,20,3,cl_array_ope		,D_FUC_RET_CODE,0,4	/* 2-->3*/
	,"ARRAYCMP"		,2,D_FUC_ARRAY_CMP		,FUNCTION	,DEF_ZOK_BINA,20,3,cl_array_ope		,D_FUC_RET_CODE,0,5	/* 2-->3*/
	,"ARRAYBXP"		,3,D_FUC_ARRAY_BXP		,FUNCTION	,DEF_ZOK_BINA,20,3,cl_array_ope		,D_FUC_RET_CODE,0,6	/* 2-->3*/
	,"ARRAYMAP"		,2,D_FUC_ARRAY_MAP		,FUNCTION	,DEF_ZOK_BULK,0,1,cl_array_map		,0,0,0
	,"MATRIXBXP"	,3,D_FUC_MATRIX_BXP		,FUNCTION	,DEF_ZOK_BINA,20,3,cl_array_ope		,D_FUC_RET_CODE,0,0
	,"SETARRAY"		,2,D_FUC_SET_ARRAY		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_set_array		,D_FUC_1st_CHK_NULL|D_FUC_RET_CODE,0,0		/* 2-->3*/
	,"SETSTRUCT"	,2,D_FUC_SET_STRUCT		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_set_struct,D_FUC_1st_CHK_NULL|D_FUC_RET_CODE,0,0
	,"SET_ARRAY"	,2,D_FUC_SET_ARRAY		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_set_array		,D_FUC_1st_CHK_NULL|D_FUC_RET_CODE,0,0	/* 2-->3*/
	,"SET_STRUCT"	,2,D_FUC_SET_STRUCT		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_set_struct,D_FUC_1st_CHK_NULL|D_FUC_RET_CODE,0,0
	,"COUNTV"		,1,D_FUC_COUNT			,FUNCTION	,DEF_ZOK_BINA,2,3,_func_count_exf	,0,0,0
	,"FL"			,1,D_FUC_LIST			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_func_list		,D_FUC_1st_CHK_NULL,0,0
	,"LIST"			,0,D_FUC_SET_LIST		,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_set_list		,D_FUC_NO_CHK_NULL,0,0
	,"APPEND"		,2,D_FUC_APPEND			,FUNC_OPE	,DEF_ZOK_BINA,2,3,cl_func_append	,D_FUC_1st_CHK_NULL,0,0
	,"POP"			,1,D_FUC_POP			,FUNC_OPE	,DEF_ZOK_VARI,0,1,cl_func_pop		,0,0,0
	,"INSERT"		,2,D_FUC_INSERT			,FUNC_OPE	,DEF_ZOK_VARI,0,1,cl_func_insert	,0,0,0
	,"RANDOM"		,1,D_FUC_RANDOM			,FUNC_OPE	,DEF_ZOK_VARI,0,1,cl_func_random	,0,0,0
	,"UNIQUE"		,1,D_FUC_UNIQUE			,FUNC_OPE	,DEF_ZOK_VARI,0,1,cl_func_unique	,0,0,0
	,"ADJUST"		,0,D_FUC_ADJUST			,FUNC_OPE	,DEF_ZOK_BINA,2,3,cl_func_adjust	,0,0,0
	,"AGG"			,3,D_FUC_AGG			,FUNCTION	,DEF_ZOK_VARI,0,1,_agg				,0,0,0
	,"FIRST"		,1,D_FUC_FIRST			,FUNCTION	,DEF_ZOK_CHAR,20,1,_ope_list_exf	,0,0,0
	,"REST"			,1,D_FUC_REST			,FUNCTION	,DEF_ZOK_CHAR,20,1,_ope_list_exf	,0,0,0
	,"CONS"			,0,D_FUC_CONS			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_cons_list		,D_FUC_NO_CHK_NULL,0,0
	,"LIST_REF"		,1,D_FUC_LIST_REF		,FUNCTION	,DEF_ZOK_CHAR,20,1,_ope_list_exf	,0,0,0
	,"INDEXA"		,2,D_FUC_INDEX			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_index		,0,0,0	/* 2-->3*/
	,"SORT"			,2,D_FUC_SORT			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_ex_sort		,0,0,0	/* 2-->3*/
	,"ROUND"		,1,D_FUC_ROUND			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_ex_round		,0,0,0
	,"NEW"			,1,D_FUC_NEW			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_new		,0,0,0
	,"TIMES"		,0,D_FUC_TIMES			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_times		,0,0,0
	,"GETVAL"		,1,D_FUC_GETVAL			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_getval	,0,0,0
	,"RANGE"		,2,D_FUC_RANGE			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_range		,0,0,0
	,"COMPLEX"		,2,D_FUC_COMPLEX		,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_complex	,0,0,0
	,"RATIONAL"		,1,D_FUC_RATIONAL		,FUNCTION	,DEF_ZOK_DECI,0,1,cl_func_rational	,0,0,0
	,"REDUCTION"	,1,D_FUC_REDUCTION		,FUNCTION	,DEF_ZOK_BINA,0,1,cl_func_reduction	,0,0,0
	,"REDIRECT"		,1,D_FUC_REDIRECT		,FUNCTION	,DEF_ZOK_BINA,0,1,cl_func_redirect	,0,0,0
	,"DEC_MAX_PRE"	,0,D_FUC_DEC_PRE		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_dec_max_pre,0,0,0
	,"JISHO"		,0,D_FUC_JISHO			,FUNCTION	,DEF_ZOK_BINA,0,1,cl_func_jisho		,0,0,0
	,"VAR_LIST"		,0,D_FUC_VARLIST		,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_var_list	,0,0,0

	,"SQRT"			,1,D_FUC_SQRT			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"SIN"			,1,D_FUC_SIN			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"COS"			,1,D_FUC_COS			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"TAN"			,1,D_FUC_TAN			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"ASIN"			,1,D_FUC_ASIN			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"ACOS"			,1,D_FUC_ACOS			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"ATAN"			,1,D_FUC_ATAN			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"ATAN2"		,2,D_FUC_ATAN2			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"LN"			,1,D_FUC_LOG			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"LOG"			,1,D_FUC_LOG			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"LOG10"		,1,D_FUC_LOG10			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"EXP"			,1,D_FUC_EXP			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"POWER"		,2,D_FUC_POWER			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"RAND1"		,0,D_FUC_RAND1			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"SRAND1"		,1,D_FUC_SRAND1			,FUNCMATH	,0			 ,0,0,NULL,0,0,0
	,"DRAND48"		,0,D_FUC_RAND1			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"SRAND48"		,1,D_FUC_SRAND1			,FUNCMATH	,0			 ,0,0,NULL,0,0,0
	,"CBRT"			,1,D_FUC_CBRT			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"SINH"			,1,D_FUC_SINH			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"COSH"			,1,D_FUC_COSH			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"TANH"			,1,D_FUC_TANH			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"ATANH"		,1,D_FUC_ATANH			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"RINT"			,1,D_FUC_RINT			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"FLOOR"		,1,D_FUC_FLOOR			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"CEIL"			,1,D_FUC_CEIL			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL,0,0,0

	,"CCHAR"		,1,D_FUC_CCHAR			,FUNCCAST	,DEF_ZOK_CHAR,0,0,NULL,0,0,0
	,"CSTRING"		,1,D_FUC_CCHAR			,FUNCCAST	,DEF_ZOK_CHAR,0,0,NULL,0,0,0
	,"CSTR"			,1,D_FUC_CCHAR			,FUNCCAST	,DEF_ZOK_CHAR,0,0,NULL,0,0,0
	,"CINT"			,1,D_FUC_CINT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"CBIN"			,1,D_FUC_CINT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"CLONG"		,1,D_FUC_CINT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"CLNG"			,1,D_FUC_CINT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"CSHORT"		,1,D_FUC_CSHORT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL,0,0,0
	,"CUSHORT"		,1,D_FUC_CUSHORT		,FUNCCAST	,DEF_ZOK_UINT,0,0,NULL,0,0,0
	,"CUCHAR"		,1,D_FUC_CBYTE			,FUNCCAST	,DEF_ZOK_UINT,0,0,NULL,0,0,0
	,"CBYTE"		,1,D_FUC_CBYTE			,FUNCCAST	,DEF_ZOK_UINT,0,0,NULL,0,0,0
	,"CFLOAT"		,1,D_FUC_CFLOAT			,FUNCCAST	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"CFLT"			,1,D_FUC_CFLOAT			,FUNCCAST	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"CDOUBLE"		,1,D_FUC_CFLOAT			,FUNCCAST	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"CDBL"			,1,D_FUC_CFLOAT			,FUNCCAST	,DEF_ZOK_FLOA,0,0,NULL,0,0,0
	,"CDEC"			,1,D_FUC_CDEC			,FUNCCAST	,DEF_ZOK_DECI,0,0,NULL,0,0,0
	,"CDECIMAL"		,1,D_FUC_CDEC			,FUNCCAST	,DEF_ZOK_DECI,0,0,NULL,0,0,0
	,"CBULK"		,1,D_FUC_CBULK			,FUNCCAST	,DEF_ZOK_BULK,0,0,NULL,0,0,0
	,"CDATE"		,1,D_FUC_CDATE			,FUNCCAST	,DEF_ZOK_DATE,0,0,NULL,0,0,0
	,"CVARI"		,1,D_FUC_CVARIANT		,FUNCCAST	,DEF_ZOK_VARI,0,0,NULL,0,0,0
	,"CVARIANT"		,1,D_FUC_CVARIANT		,FUNCCAST	,DEF_ZOK_VARI,0,0,NULL,0,0,0
	,"CIMG"			,1,D_FUC_CIMG			,FUNCCAST	,DEF_ZOK_IMGE,0,0,NULL,0,0,0
	,"CIMAGE"		,1,D_FUC_CIMG			,FUNCCAST	,DEF_ZOK_IMGE,0,0,NULL,0,0,0

	,"BEEP"			,0,D_FUC_BEEP			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_beep,0,0,0
	,"MSGBOX"		,1,D_FUC_MSGBOX			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_msgbox,0,0,0

	,NULL,0,0,0,0,0,0,NULL,0,0,0
	};
static int max_tOpeTbl=0;

/****************************************/
/*	01									*/
/****************************************/
static tdtInfoParm **_mv_pnam_parm(nparm,ppParm0)
int nparm;
tdtInfoParm *ppParm0[];
{
	int i,j,i1;
	tdtInfoParm *pInfoParm,*pInfo,**ppParm;

	ppParm = ppParm0;
	if (nparm > 1) {
		j = 0;
		for (i=0;i<nparm;i++) {
			pInfoParm = ppParm0[i];
			if (pInfoParm->pi_id == D_DATA_ID_PNAME) j++;
		}
/*
printf("_mv_pnam_parm: nparm=%d j=%d\n",nparm,j);
*/
		if (!j || j==nparm) return ppParm0;
		if (!(ppParm=(tdtInfoParm **)cl_tmp_const_malloc(sizeof(tdtInfoParm *)*nparm))) return NULL;
		i1 = 0;
		j = nparm - j;
		for (i=0;i<nparm;i++) {
/*
printf("_mv_pnam_parm: i1=%d j=%d\n",i1,j);
*/
			pInfoParm = ppParm0[i];
			if (pInfoParm->pi_id == D_DATA_ID_PNAME)
				ppParm[j++] = pInfoParm;
			else
				ppParm[i1++] = pInfoParm;
		}
	}
	return ppParm;
}

/****************************************/
/*	02									*/
/****************************************/
static int _null_check(pInfoParmW,flg,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int flg,nparm;
tdtInfoParm *ppParm[];
{
	int i,rc;

	rc = 0;
	if (flg & D_FUC_1st_CHK_NULL) {
#if 1	/* 2025.7.19 */
		if (cl_is_null(ppParm[0])) {
#else
		if (cl_is_null_value(ppParm[0])) {
#endif
			cl_null_value(pInfoParmW);
			if (flg & D_FUC_RET_CODE) rc = -1;
			else rc = 1;
		}
		if (!rc && nparm>1) {
			/* �R�}���h���ƂɃ`�F�b�N���� */
		}
	}
	else {
		for (i=0;i<nparm;i++) {
#if 1	/* 2025.7.19 */
			if (cl_is_null(ppParm[i])) {
#else
			if (cl_is_null_value(ppParm[i])) {
#endif
				cl_null_value(pInfoParmW);
				if (flg & D_FUC_RET_CODE) rc = -(i+1);	/* 2025.7.15 -1 ==> -(i+1) */
				else rc = 1;
				break;
			}
		}
	}
/*
printf("_null_check: flg=%08x rc=%d\n",flg,rc);
*/
	return rc;
}

/****************************************/
/*	03									*/
/****************************************/
char *cl_get_func_name(no,parm)
int no,parm[];
{
	qOpeTable *pot;
	char *p;

	if (!max_tOpeTbl) cl_get_func_info("X",NULL);
	if (no>=0 && no<max_tOpeTbl) {
		pot = &tOpeTbl[no];
		p = pot->name;
		if (parm) {
			parm[0] = pot->mpara;
			parm[1] = pot->ope;
			parm[2] = pot->kubun;
			parm[3] = pot->reta;
			parm[4] = no;
			parm[5] = pot->option;
		}
	}
	else p = "";
	return p;
}

/****************************************/
/*	04									*/
/****************************************/
qOpeTable *cl_get_func_info(pName,parm)
char *pName;
int  parm[];
{
	static XHASHB *xhp=NULL;
	static int iTry=1;
	qOpeTable *pot,**ppot;
	char *p,w[2];
	int i,len,ii,*pii;

	if (iTry && !xhp) {
		if (xhp=akxs_xhashm_new2(0,200,199,sizeof(qOpeTable *),AKX_HASX_OPT_CASE_KEY,NULL,NULL)) {
			for (ii=0,pot=&tOpeTbl[0];p=pot->name;ii++,pot++) {
				if ((i=akxs_xhash2(xhp,'S',p,&ii)) <= 0) {	/* �ۑ��������f�[�^��(ii)�ւ̃|�C���^��ݒ肷�� */
					akxs_xhash_free(xhp);
					xhp = NULL;
					break;
				}
			}
			max_tOpeTbl = ii;
		}
		iTry = 0;
	}
	mem_set_int(parm,0,5);
	if (xhp) {
		if ((i=akxs_xhash2(xhp,'R',pName,&pii)) > 0) {	/* �ۑ����ꂽ�f�[�^��ւ̃|�C���^��Ԃ��G���A(pii)�̃|�C���^��ݒ肷�� */
			ii = *pii;
			pot = &tOpeTbl[ii];
			if (parm) {
				parm[0] = pot->mpara;
				parm[1] = pot->ope;
				parm[2] = pot->kubun;
				parm[3] = pot->reta;
				parm[4] = ii;
				parm[5] = pot->option;
			}
/*
printf("cl_get_func_info: pName=[%s] i=%d\n",pName,i);
*/
			return pot;
		}
	}
	if ((len=strlen(pName)) > 1) {
		if (akxnskipin(pName,len,"$%#") >= len) {
			w[0] = *pName;
			w[1] = '\0';
			return cl_get_func_info(w,parm);
		}
	}

	return NULL;
}

/****************************************/
/*	05									*/
/****************************************/
char *cl_get_func_info_ope(func_ope,parm)
int func_ope;
int parm[];
{
	qOpeTable *pot;
	char *p;
	int ii,ope;

	ope = func_ope;
	for (ii=0,pot=&tOpeTbl[0];p=pot->name;ii++,pot++) {
		if (pot->ope == ope) {
			if (parm) {
				parm[0] = pot->mpara;
				parm[1] = ope;
				parm[2] = pot->kubun;
				parm[3] = pot->reta;
				parm[4] = ii;
				parm[5] = pot->option;
			}
			break;
		}
	}
	if (!p) p = "";
	return p;
}

/****************************************/
/*	2152211YY							*/
/****************************************/
/* arg_kbn
	0	exfunc(pInfoParmW,nparm,ppParm);
	1	exfunc(&pWork,nparm,ppParm);
	2	exfunc(pWork,nparm,ppParm);
	9	exfunc(&pWork,nparm,ppParm,iParm);
   10	rep_condas(&pWork,nparm,ppParm,exfunc);
   11	substrm(&pWork,mflg,pInfoParm1,pInfoParm2,pInfoParm3);
   12	concat(&pWork,pInfoParm1,pInfoParm2,nparm-2,NULL,pParm+2);
   13	exfunc(&pWork,mflg,nparm,ppParm);
   14	exfunc(&pWork,mflg,nparm,ppParm,ope,pOperator);
   16	cl_gx_copy_info(pInfoParmW, pInfoParm1);
	9	cl_cmpt_to_number(iMPA,nparm,ppParm,iParm);
   18	cl_cmpt_math(iMPA,pOperator,pInfoParm1,pInfoParm2,iParm);
   20(0x14)	exfunc(pInfoParmW,nparm,ppParm,pot,etc_parm);
   21(0x15)	exfunc(&pWork,nparm,ppParm,pot,etc_parm,pOperator);
*/
/* ret_kbn
	0
	1	exfunc(pInfoParmW,nparm,ppParm);
	2	exfunc(&pWork,nparm,ppParm);
	3	exfunc(pWork,nparm,ppParm);
	4	cl_cmpt_to_number(iMPA,nparm,ppParm,iParm);
	5	ABS()
	6	if ((rc=cl_cmpt_to(&pWork,pOperator,nparm,ppParm,ope,opt)) > 0)
*/
int cl_gx_func_bexp(pInfoParmW,pOperator,nparm,ppParm,opt,pParm)
tdtInfoParm *pInfoParmW;
char *pOperator;
tdtInfoParm *pParm,*ppParm[];
int nparm,opt;
{
	tdtInfoParm *pInfoParm1;
	tdtInfoParm *pInfoParm2;
	tdtInfoParm *pInfoParm3;
	int rc,kubun,mflg,arg_kbn,ret_kbn,mpr,flg,op,ope,maxpr,ex_opt8,rc_ex_func;
	int dtlen,dtatr,scale,len,iParm[6],iVal,iAULN,chage_mask,etc_parm[10];
	long lValz[NMPA_LONG],*lVal;
	char *pWork,*p,c,wrk[16];
	qOpeTable *pot;
	ScrPrCT	  *pScCT;
	int  (*exfunc)();
/*
printf("cl_gx_func_bexp:func=[%s] nparm=%d\n",pOperator,nparm);
*/
	flg = ope = 0;
	ex_opt8 = cl_get_option(8,0);
	rc_ex_func = 0;
	if (!(ex_opt8 & 0x01)) {
		rc = cl_exec_function(pOperator,pInfoParmW,nparm,ppParm);
		if (rc != ECL_NOT_FOUND_FUNC) return rc;
		rc_ex_func = rc;
	}
	if ((c=*pOperator)>='0' && c<='9') {
		if (pot = &tOpeTbl[atoi(pOperator)])
			pOperator = pot->name;
	}
	else pot = cl_get_func_info(pOperator,iParm);
	if (pot) {
		mpr = pot->mpara;
/*
printf("cl_gx_func_bexp:func=[%s] nparm=%d mpr=%d\n",pOperator,nparm,mpr);
*/
		if (nparm < mpr/*iParm[0]*/) {
			/* �֐�(%s)�̈���������܂���B */
			ERROROUT1(FORMAT(211),pOperator);
			return ECL_SCRIPT_ERROR;
		}
		maxpr = pot->resv;
		if (maxpr > 0) {
			if (nparm > maxpr-1) {
				ERROROUT2(FORMAT(267),pOperator,nparm);	/* %s: �]���ȃp�����[�^(nparm=%d)������܂��B*/
				return ECL_SCRIPT_ERROR;
			}
		}
		ope = pot->ope;	/*iParm[1];*/
		flg = pot->option;
		/* 2023.7.23 */
		if (nparm>0 && !(flg & D_FUC_NO_CHK_NULL)) {
/*
printf("cl_gx_func_bexp:func=[%s] nparm=%d\n",pOperator,nparm);
*/
			if ((rc=_null_check(pInfoParmW,flg,nparm,ppParm)) > 0) return 0;
#if 1	/* 2025.7.15 */
			else if (rc < 0) {
				rc = -rc;
				p = wrk;
				if (rc == 1) p = FORMAT(248);
				else if (rc == 2) p = FORMAT(249);
				else if (rc == 3) p = FORMAT(677);
				else sprintf(wrk,"%dth ",rc);
				ERROROUT1(FORMAT(243),p);	/* %s�p�����[�^��NULL�ł��B*/
				return ECL_SCRIPT_ERROR;
			}
#else
			else if (rc < 0) return rc;
#endif
		}
		kubun = pot->kubun;	/*iParm[2];*/
		dtatr = pot->reta;	/*iParm[3];*/
		arg_kbn = pot->arg_kbn;
		ret_kbn = pot->ret_kbn;
		exfunc = pot->func;
	}

DEBUGOUTL5(161,"cl_gx_func_bexp: func=[%s] nparm=%d ope=%d kubun=%d dtatr=%d",
pOperator,nparm,ope,kubun,dtatr);
DEBUGOUTL3(161,"cl_gx_func_bexp: arg_kbn=%02x ret_kbn=%d flg=%04x",arg_kbn,ret_kbn,flg);

#if 0	/* 2024.12.21 */
	/* 2024.7.6 */
	if (!(chage_mask=pot->chg_svar)) chage_mask = -1;
	if ((rc=cl_change_storevar(nparm,&ppParm,0x02,chage_mask)) < 0) return rc;
	if (!ope) {
#else
	if (!pot) {
#endif
#if 1	/* 2025.11.28 */
		if (rc_ex_func) {
			if (!(rc = cl_sel_import(pOperator,1))) {
				rc = cl_exec_function(pOperator,pInfoParmW,nparm,ppParm);
				if (rc != ECL_NOT_FOUND_FUNC) return rc;
			}
		}
#endif
		if (ex_opt8 & 0x01) {
			rc = cl_exec_function(pOperator,pInfoParmW,nparm,ppParm);
			if (rc != ECL_NOT_FOUND_FUNC) return rc;
		}
		/* [%s]�͊֐��ł͂���܂���B */
		ERROROUT1(FORMAT(212),pOperator);
		return ECL_SCRIPT_ERROR;
	}
#if 1	/* 2024.12.21 */
	/* 2024.7.6 */
	if (!(chage_mask=pot->chg_svar)) chage_mask = -1;
	if ((rc=cl_change_storevar(nparm,&ppParm,0x02,chage_mask)) < 0) return rc;
#endif
	pInfoParm1 = ppParm[0];
	if (nparm >= 2) pInfoParm2 = ppParm[1];
	else pInfoParm2 = NULL;
	scale = 0x40;
	pInfoParmW->pi_pos = 0;
	pWork = (char *)&(pInfoParmW->pi_pos);
	mem_set_int(iParm,0,5);
	dtlen = 0;
	mflg = pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX;
	if (arg_kbn & 0x80) mflg = 0;
	arg_kbn &= 0x7f;
	iAULN = 0;	/* add 2022.7.2 */
	etc_parm[0] = mflg;
	etc_parm[1] = opt;
	cl_parm_set0(pInfoParmW);	/* add 2021.9.14 */

	gtIter_ctl[0].itc_circ_ref = NULL;
	gtIter_ctl[1].itc_circ_ref = NULL;
/*
printf("cl_gx_func_bexp:func=[%s] kubun=%d arg_kbn=%d ret_kbn=%d\n",pOperator,kubun,arg_kbn,ret_kbn);
*/
	/* 2022.10.19 */
	/* ���O�t���p�����[�^�𖖔��Ɉړ����� */
	ppParm = _mv_pnam_parm(nparm,ppParm);
if (exfunc == NULL) {
	if (kubun == FUNCFILE) {
		pGlobTable->err_no = 0;
		iParm[0] = 0;
		if ((rc = func_file(&pWork,pOperator,nparm,ppParm,ope,iParm)) > 0)
			dtatr = rc;

DEBUGOUTL5(161,"cl_gx_func_bexp: rc=%d iParm[1]..[4]=%d %d %d %d",rc,iParm[1],iParm[2],iParm[3],iParm[4]);

		if (rc==ECL_END_OF_FILE || rc==ECL_IN_ERROR) cl_null_char(pInfoParmW);
		/* add 2022.7.2 */
		if (ope==D_FUC_FOPEN || ope==D_FUC_POPEN || ope==D_FUC_OPENDIR)
			iAULN = iParm[D_IPARM_FLAG] & D_AULN_FILE_POINTER;	/* D_AULN_FILE_POINTER�������Ă��� */
	}
	else if (kubun == COMP) {
#if 1	/* 2025.3.28 */
		if (ope==D_FUC_MAX || ope==D_FUC_MIN || ope==D_FUC_SUM || ope==D_FUC_AVG || ope==D_FUC_PRODUCT) {
			if ((rc=cl_func_agg(pInfoParmW,nparm,ppParm,ope)) > 0) return 0;
			else if (!rc) rc = ECL_SYSTEM_ERROR;
		}
		else
#endif
		if ((rc = cl_func_comp(&pWork,pOperator,nparm,ppParm,ope)) > 0)
			dtatr = rc;
	}
	else if (kubun == FUNCMATH) {
		return func_math2(pInfoParmW,pOperator,nparm,ppParm,ope);
	}
	else if (kubun == FUNCLOG) {
		pGlobTable->err_no = 0;
		if (ope == D_FUC_GETLOGPARM)
			rc = func_get_log_parm(pWork,nparm,ppParm);
		else if (ope == D_FUC_SETLOGPARM)
			rc = func_set_log_parm(pWork,nparm,ppParm);
		else if (ope == D_FUC_RESLOGPARM)
			rc = func_res_log_parm(pWork,nparm,ppParm);
		else
			rc = func_log(pWork,pOperator,nparm,ppParm,ope);
	}
	else if (kubun == FUNCCAST) {
		return cl_func_conv(pInfoParmW,ope,pOperator,nparm,ppParm);
	}
	else if (kubun == LOGICAL) {
		if ((rc = cl_func_logic(&pWork,pOperator,nparm,ppParm,ope)) > 0)
			dtatr = rc;
	}
	else
		rc = -215221101;
}
else if (ret_kbn <= 3) {
	if (arg_kbn < 20) {
		if (arg_kbn == 0)
			return exfunc(pInfoParmW,nparm,ppParm);
		else if (arg_kbn == 1) {
			rc = exfunc(&pWork,nparm,ppParm);
			if (!pWork) dtatr = 0;
		}
		else if (arg_kbn == 2) {
			rc = exfunc(pWork,nparm,ppParm);
			if (ope==D_FUC_IS && rc==-101) {
				cl_null_value(pInfoParmW);
				return 0;
			}
		}
		else if (arg_kbn == 9)
			rc = exfunc(&pWork,nparm,ppParm,iParm);
		else
			rc = -215221101;
	}
	else {
		if (arg_kbn == 20) {
			/* 2025.11.24 */
			if (ret_kbn == 1) {
				return exfunc(pInfoParmW,nparm,ppParm,pot,etc_parm);
			}
			else if (ret_kbn == 2) {
				rc = exfunc(&pWork,nparm,ppParm,pot,etc_parm);
				if (!pWork) dtatr = 0;
			}
			else if (ret_kbn == 3) {
				rc = exfunc(pWork,nparm,ppParm,pot,etc_parm);
			}
			else
				rc = -215221101;
		}
		else if (arg_kbn == 21) {	/* add 2025.11.24 */
			/* ret_kbn == 1 */
			return exfunc(pInfoParmW,nparm,ppParm,pot,etc_parm,pOperator);
		}
		else
			rc = -215221101;
	}
}
else {
	if (ret_kbn==4 || ret_kbn==5) {
		if (ret_kbn==5) {
	/*	case D_FUC_ABS:	*/
			if (nparm > 1) {
					/* %s: �]���ȃp�����[�^(nparm=%d)������܂��B*/
				ERROROUT2(FORMAT(267),"cl_gx_func_bexp",nparm);
				return ECL_SCRIPT_ERROR;
			}
			if (pInfoParm1->pi_attr == DEF_ZOK_DATE) {
				cl_gx_copy_info(pInfoParmW, pInfoParm1);
				return 0;
			}
			else pInfoParm2 = pInfoParm1;
		}
/*	case D_FUC_MOD:
	case D_FUC_TO_NUMBER:	*/
			lVal = cl_get_tmpMPA(lValz);
			if (ope == D_FUC_TO_NUMBER)
				rc = cl_cmpt_to_number(lVal,nparm,ppParm,iParm);
			else
				return cl_cmpt_math_info(pInfoParmW,pOperator,pInfoParm1,pInfoParm2);
			/* 2022.7.17 */
			pWork = (char *)lVal;
	}
	else if (ret_kbn == 6) {
		if ((rc=exfunc(&pWork,nparm,ppParm)) > 0) {
			dtatr = rc;
			iParm[0] = dtatr;
		}
	}
	else
		rc = -215221101;
}
	if (rc == -215221101) {
		/* [%s]�͎�������Ă��܂���B */
		ERROROUT1(FORMAT(213),pOperator);
	/*	return ECL_SCRIPT_ERROR;	*/
	}
	if (rc < 0) return rc;
	if (pGlobTable->exception && pGlobTable->try_level>0) {
		if ((rc=pGlobTable->exception) > 0) rc = -rc;
		return rc;
	}
/*
printf("cl_gx_func_bexp: iParm=%d %d %d %d %d\n",iParm[0],iParm[1],iParm[2],iParm[3],iParm[4]);
*/
	/* 2022.7.17 */
	rc = cl_set_parm(pInfoParmW,pWork,dtatr,iParm);
DEBUGOUT_InfoParm(194,"cl_gx_func_bexp: dtatr=%d",pInfoParmW,dtatr,0);
	return rc;
}

/****************************************/
/*	12									*/
/****************************************/
int cl_set_parm(pInfoParmW,pWork,dtatr,iParm)
tdtInfoParm *pInfoParmW;
char *pWork;
int dtatr,iParm[];
{
	int ret,iVal,dtlen,scale,precision,dec_scale,iSCA,iFLAG,iAULN,code_type;
	long lValue;
	double dValue;
	ParList2 par2;

	/* cl_gx_func_bexp()����Ă΂ꂽ�Ƃ��́ApWork �� pInfoParmW->pi_pos ���w���Ă���̂ŁA
	   �ŏ��� pInfoParmW �̓N���A�ł��Ȃ� */
	ret = iAULN = precision = dec_scale = scale = dtlen = code_type = 0;
	if (iParm[D_IPARM_ATTR] > 0) {
		dtatr = iParm[D_IPARM_ATTR];
		dtlen = iParm[D_IPARM_SIZE];
		iSCA  = iParm[D_IPARM_SCA];
		iFLAG = iParm[D_IPARM_FLAG] | (dtatr & DEF_ZOK_USMASK);
		dtatr &= DEF_ZOK_MASK;
		if (iFLAG & AKX_NUM_I) scale |= D_DATA_IMAGE;
		iAULN = iFLAG & (D_AULN_OVERFLOW | D_AULN_FILE_POINTER);
		if (dtatr == DEF_ZOK_BINA) {
			if (iFLAG & DEF_ZOK_USMASK) scale |= D_DATA_UNSIGNED;
		}
		else if (dtatr == DEF_ZOK_DECI) {
			precision = iParm[D_IPARM_PRE];	/* precision */
			dec_scale = iSCA;				/* scale */
		}
		else code_type = iParm[D_IPARM_PRE];
		if (dtlen < 0) dtlen = -dtlen;	/* ����͕s�v�Ǝv���邪�O�̂��ߎc�� */
	}
	else {
		dtatr &= DEF_ZOK_MASK;
		if (dtatr == DEF_ZOK_CHAR) {
			if (pWork) dtlen = strlen(pWork);
		}
		else if (dtatr == DEF_ZOK_BINA) dtlen = sizeof(long);
		else if (dtatr == DEF_ZOK_FLOA) dtlen = sizeof(double);
		else if (dtatr==DEF_ZOK_DECI || dtatr==DEF_ZOK_DATE) dtlen = sizeofMPA();
	}
/*
printf("cl_set_parm: dtatr=%d dtlen=%d code_type=%d\n",dtatr,dtlen,code_type);
*/
	if (dtatr == DEF_ZOK_CHAR) {
		if ((ret=cl_sep_string_with_type(&par2,pWork,dtlen)) > 0) {
			code_type = par2.option;
			pWork = par2.par;
			dtlen = par2.parlen;
		}
/*
printf("cl_set_parm: dtlen=%d code_type=%d\n",dtlen,code_type);
*/
		ret = cl_set_parm_char2(pInfoParmW,pWork,dtlen,code_type);
	}
	else if (dtatr == DEF_ZOK_BINA) {
#if defined(_LP64)
		if (dtlen == sizeof(long)) {
			memcpy(&lValue,pWork,sizeof(long));
			cl_set_parm_long(pInfoParmW,lValue);
		}
		else {
			memcpy(&iVal,pWork,sizeof(int));
			cl_set_parm_int(pInfoParmW,iVal);
		}
#else
		memcpy(&lValue,pWork,sizeof(long));
		cl_set_parm_long(pInfoParmW,lValue);
#endif
	}
	else if (dtatr == DEF_ZOK_FLOA) {
		memcpy(&dValue,pWork,sizeof(double));
		ret = cl_set_parm_double(pInfoParmW,dValue);
	}
	else if (dtatr == DEF_ZOK_DECI) {
		ret = cl_set_parm_mpa(pInfoParmW,pWork);
		pInfoParmW->pi_hlen = precision;
		pInfoParmW->pi_pos  = dec_scale;
	}
	else if (dtatr == DEF_ZOK_DATE) {
		ret = cl_set_parm_date(pInfoParmW,pWork);
	}
	else if (dtatr) {
		pInfoParmW->pi_id = ' ';
		pInfoParmW->pi_attr = dtatr;
		pInfoParmW->pi_code = CLcommon.cDataCode;
		pInfoParmW->pi_dlen = dtlen;
		pInfoParmW->pi_data = pWork;
	}
	if (dtatr) {
		pInfoParmW->pi_scale|= scale;
		pInfoParmW->pi_alen |= iAULN;
	}
	else cl_null_parm(pInfoParmW);

DEBUGOUT_InfoParm(194,"cl_set_parm: dtatr=%d ret=%d",pInfoParmW,dtatr,ret);

	return ret;
}

/****************************************/
/*	13									*/
/****************************************/
int cl_ex_method(pInfoParmW,pInfoParm1,optW,p2,len2)
tdtInfoParm *pInfoParmW,*pInfoParm1;
int optW;
char *p2;
int len2;
{
	tdtInfoParm *ppParm[2];

	ppParm[0] = pInfoParm1;
	return cl_gx_func_bexp(pInfoParmW,p2,1,ppParm,optW,pInfoParm1);
}

/****************************************/
/*	14									*/
/****************************************/
int cl_set_system_method(pInfoParmW,pInfoParm1,pInfoParm2,optW,p2,len2)
tdtInfoParm *pInfoParmW,*pInfoParm1,*pInfoParm2;
int optW;
char *p2;
int len2;
{
	tdtInfoParm *pInfoParm;

	cl_gx_copy_info(pInfoParmW,pInfoParm2);
	if (!(pInfoParm=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return -1;
	cl_gx_rep_info_set_ign(pInfoParm,pInfoParm1,1|D_REP_OPT_DEF_ONLY|D_REP_OPT_AR_NCOPY);
	pInfoParmW->pi_hlen = (long)pInfoParm;
	return 0;
}

/****************************************/
/*	15									*/
/****************************************/
int cl_gx_func_mk_retval(ppInfoParmW,name)
tdtInfoParm **ppInfoParmW;
char *name;
{
	static long count=0;
	ScrPrCT *pScCT;
	tdtInfoParm *pInfoParmW;
	int rc;
	char *p,wrk[Var_NM_MAX+2];

	if (ppInfoParmW && name) {
		pInfoParmW = *ppInfoParmW;
/*
printf("cl_gx_func_mk_retval: pInfoParmW=%08x pi_id=[%c] name=[%s]\n",pInfoParmW,pInfoParmW->pi_id,name);
*/
		pScCT = cl_search_src_ct();
		p = pInfoParmW->pi_paux;
		/* $�t���œo�^����邽�߁A�ϐ��Ƃ��Ă͎Q�Ƃł��Ȃ� */
#if 0	/* 2025.4.25 */
		*wrk = '$';
		strcpy(wrk+1,name);
#else
		sprintf(wrk,"$%s%d",name,count++);
#endif
/*
printf("cl_gx_func_mk_retval: wrk=[%s]\n",wrk);
*/
		rc = cl_gx_get_lg_var_ent(pScCT,'s',"",&pInfoParmW,wrk,D_GX_OPT_SET_LOCAL);
		if (rc >= 0) {
			cl_parm_set0(pInfoParmW);	/* add 2022.3.28 */
			pInfoParmW->pi_paux = p;	/* 2021.2.22 */
			*ppInfoParmW = pInfoParmW;
			rc = 0;
		}
	}
	else rc = -1;
	return rc;
}

/****************************************/
/*	16									*/
/****************************************/
int cl_gx_func_method(pInfoParmW,pInfoParmM,nparm,ppParm,opt,pParm)
tdtInfoParm *pInfoParmW,*pInfoParmM;
tdtInfoParm *pParm,*ppParm[];
int nparm,opt;
{
	tdtInfoParm *pParmW,**ppParmW,*pInfoParm,*ppParm0[1];
	int i,len,rc;
	Leaf *wkleaf,*nodeleaf;
	char *name,*p,id,c;
	ProcCT *cur_procct;
	ScrPrCT *pScCT;

DEBUGOUT_InfoParm(161,"cl_gx_func_method:pInfoParmM: nparm=%d opt=%08x",pInfoParmM,nparm,opt);
DEBUGOUT_InfoParm(161,"cl_gx_func_method:pInfoParmW:",pInfoParmW,0,0);

	p = pInfoParmW->pi_paux;	/* �\����.�֐��̂Ƃ��A�\���̂�InfoParm�ւ̃|�C���^ */
	memset(pInfoParmW,0,sizeof(tdtInfoParm));
	pInfoParmW->pi_paux = p;
	if (pInfoParmM->pi_hlen) {
		/* 2021.4.27 */
/*
printf("cl_gx_func_method: nparm=%d pInfoParmM->pi_hlen=%08x\n",nparm,pInfoParmM->pi_hlen);
*/
		ppParm0[0] = pParm;
		ppParmW = ppParm0;
		if (rc=cl_gx_parm_conv_arg(NULL,1,nparm,NULL,NULL,0,&ppParmW,NULL)) return rc;
		ppParm = ppParmW;
		pParm = ppParm[0];
		cl_gx_copy_info_opt(pParm,pInfoParmM->pi_hlen,1);
		nparm++;
	}
/*
printf("cl_gx_func_method: pInfoParmM->pi_pos=%08x\n",pInfoParmM->pi_pos);
*/
	wkleaf = NULL;
	pInfoParm = NULL;
	name = pInfoParmM->pi_data;
	if (pInfoParmM->pi_pos & ~0x0f) {
		wkleaf = (Leaf *)pInfoParmM->pi_pos;
		nodeleaf = (Leaf *)pInfoParmM->pi_paux;
/*
if (wkleaf) {
printf("cl_gx_func_method: name=[%s] wkleaf=%08x nodeleaf=%08x pi_alen=%04x\n",
name,wkleaf,nodeleaf,pInfoParmM->pi_alen);
}
*/
	}
	if ((c=*name)=='$' || c=='%' || c=='#') {
		opt |= cl_gx_get_opt_from_aux1(pInfoParmM->pi_aux[1]);
	}
#if 1	/* 2025.4.23 */
	else {
#else
	else if (pInfoParmM->pi_pos != 1) {	/* '{}'�łȂ��֐��̂Ƃ��́A�֐����̃��[�J���ϐ����쐬���� */
#endif
#if 1	/* 2025.4.24 */
		pInfoParmW->pi_id = 'F';
#else
		pInfoParm = pInfoParmW;
		pScCT = cl_search_src_ct();
		/* $�t���œo�^����邽�߁A�ϐ��Ƃ��Ă͎Q�Ƃł��Ȃ� */
		cl_gx_get_lg_var_ent(pScCT,'s',"",&pInfoParmW,stradd("$",name),D_GX_OPT_SET_LOCAL);
		cl_parm_set0(pInfoParmW);	/* add 2022.3.28 */
		pInfoParmW->pi_paux = p;	/* 2021.2.22 */
#endif
	}
#if 1	/* 2024.12.27 */
	cur_procct = cl_search_proc_ct();
	if (cur_procct) pInfoParmW->pi_hlen = cur_procct->ProcGid;
/*
printf("cl_gx_func_method: pInfoParmW=%08x cur_procct->ProcGid=%d\n",pInfoParmW,cur_procct->ProcGid);
*/
#endif
	if (wkleaf && pInfoParmM->pi_alen==D_AULN_SET_POS_LEAF) {
#if 1	/* 2024.12.27 */
		pInfoParm = pInfoParmW;
		if ((rc=cl_gx_func_mk_retval(&pInfoParmW,name)) < 0) return rc;
		pInfoParmW->pi_hlen = pInfoParm->pi_hlen;
#endif
		cur_procct = cl_search_proc_ct();
		rc = cl_exec_func_setup_proc(name,pInfoParmW,nparm,ppParm,wkleaf,nodeleaf,0,NULL);
		if (!rc) {
			rc = cl_exec_func_execute(cur_procct);
		}
#if 1	/* 2024.12.27 */
		cl_gx_copy_info_opt(pInfoParm,pInfoParmW,1);
#endif
#if 0	/* 2024.12.27 */
		if ((id=pInfoParmW->pi_id)=='R' || id=='A') pInfoParmW->pi_hlen = cur_procct->ProcGid;
#endif
	}
	else {
		rc = cl_gx_func_bexp(pInfoParmW,pInfoParmM->pi_data,nparm,ppParm,opt,pParm);
	}
#if 0	/* 2024.12.27 */
	if (pInfoParm) cl_gx_copy_info_opt(pInfoParm,pInfoParmW,1);
#endif
/*
printf("cl_gx_func_method:Exit rc=%d\n",rc);
*/
DEBUGOUTL1(161,"cl_gx_func_method:Exit rc=%d",rc);
	return rc;
}
/****************************************/
/*	21									*/
/****************************************/
#if 1	/* 2024.12.17 */
static int _rep_condas(pAns,nparm,ppParm,pot,etc_parm)
char **pAns;
int nparm,etc_parm[];
tdtInfoParm	*ppParm[];
qOpeTable *pot;
#else
static int _rep_condas(pAns,nparm,ppParm,func)
char **pAns;
int nparm;
tdtInfoParm	*ppParm[];
int (*func)();
#endif
{
	tdtInfoParm *pInfoParm1,tInfoParm;
	tdtInfoParm *pInfoParm2;
	int  rc,len1,code_type;
	char *p1;
	ParList3 par3;
#if 1	/* 2024.12.17 */
	int (*func)();
	int ope;

	ope = pot->ope;
#endif
	pInfoParm1 = ppParm[0];
	pInfoParm2 = ppParm[1];
	if (nparm > 2) {
		if (pInfoParm2->pi_id==' ' && pInfoParm2->pi_attr==DEF_ZOK_BINA) {
			code_type = cl_get_char_code_type(pInfoParm1,1);
		/*	p1   = pInfoParm1->pi_data;
			len  = pInfoParm1->pi_dlen;	*/
			if ((rc=cl_get_str_pos(nparm,ppParm,0,&par3,NULL,"")) < 0) return rc;
			p1 = par3.par;
			len1 = par3.parlen;
			pInfoParm1 = &tInfoParm;
			cl_set_parm_char2(pInfoParm1,p1,len1,code_type);
			pInfoParm2 = ppParm[rc];
		}
	}
#if 1	/* 2024.12.17 */
	if (ope == D_FUC_REP) func = replace;
	else func = condas;
#endif
	return func(pAns,pInfoParm1,pInfoParm2);
}
#if 1	/* 2024.12.16 */
/****************************************/
/*	22									*/
/****************************************/
static int _func_count_exf(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm **ppParm;
{
	return cl_func_count(pWork,nparm,ppParm,-1);
}

/****************************************/
/*	23									*/
/****************************************/
static int _ope_list_exf(pInfoParmW,nparm,ppParm,pot,etc_parm)
tdtInfoParm *pInfoParmW;
int nparm,etc_parm[];
tdtInfoParm *ppParm[];
qOpeTable *pot;
{
	char *pOperator;
	int ope,gx_opt;

	pOperator = pot->name;
	ope = pot->ope;
	gx_opt = etc_parm[1];
	return cl_ope_list(pInfoParmW,pOperator,nparm,ppParm,ope,gx_opt);
}
#endif
#if 1	/* 2024.12.18 */
/****************************************/
/*	24									*/
/****************************************/
static int _lenm_exf(pAns,nparm,ppParm,pot,etc_parm)
long *pAns;
int  nparm,etc_parm[];
tdtInfoParm *ppParm[];
qOpeTable *pot;
{
	return cl_lenm(pAns,etc_parm[0],nparm,ppParm);
}

/****************************************/
/*	25									*/
/****************************************/
static int _lenw_exf(pAns,nparm,ppParm,pot,etc_parm)
long *pAns;
int  nparm,etc_parm[];
tdtInfoParm *ppParm[];
qOpeTable *pot;
{
	return cl_lenw(pAns,etc_parm[0],nparm,ppParm);
}

/****************************************/
/*	26									*/
/****************************************/
static int _substrm_concat(pAns,nparm,ppParm,pot,etc_parm)
char **pAns;
int nparm,etc_parm[];
tdtInfoParm	*ppParm[];
qOpeTable *pot;
{
	tdtInfoParm	*pInfoParm1,*pInfoParm2,*pInfoParm3;
	int rc;
/*
printf("_substrm_concat: nparm=%d pot->ope=%d etc_parm[0]=%d\n",nparm,pot->ope,etc_parm[0]);
*/
	pInfoParm1 = ppParm[0];
	if (nparm >= 2) pInfoParm2 = ppParm[1];
	else pInfoParm2 = NULL;
	if (nparm >= 3) pInfoParm3 = ppParm[2];
	else pInfoParm3 = NULL;
#if 1	/* 2025.8.22 */
	if (pot->ope == D_FUC_CONCAT) rc = concat2(pAns,nparm,ppParm);
#else
	if (pot->ope == D_FUC_CONCAT) rc = concat(pAns,pInfoParm1,pInfoParm2,nparm-2,NULL,ppParm+2);
#endif
	else rc = substrm(pAns,etc_parm[0],pInfoParm1,pInfoParm2,pInfoParm3);
	return rc;
}

#if 1	/* 2025.10.8 */
/****************************************/
/*	27									*/
/****************************************/
static int _get_num_info(pInfoParm1)
tdtInfoParm	*pInfoParm1;
{
	tdtInfoParm	***pTBL;
	tdtArrayIndex tIndex,*pIndex;
	tdtRbCtl *pCt;
	char id,*p1;
	int rc,nn,iParm[6];

	id = pInfoParm1->pi_id;
	if (id=='L' || id=='N') {
		pCt = (tdtRbCtl *)pInfoParm1->pi_data;
		nn =  akxs_rb_used(pCt);
	}
	else {
		pIndex = &tIndex;
		if ((rc=cl_get_array_info(pInfoParm1,pIndex,&pTBL,iParm)) < 0) return rc;
		if (pIndex->xhp) {
			if (!(p1 = (char *)pInfoParm1->pi_pos)) p1 = "";
					/* "%s: �A�z�z��(%s)�͎w��ł��܂���B*/
			ERROROUT2(FORMAT(239),"_mid",p1);
			return ECL_SCRIPT_ERROR;
		}
		nn = iParm[3]-iParm[2]+1;
	}
	return nn;
}

/****************************************/
/*	28									*/
/****************************************/
static int _leftm_rightm_exf(pInfoParmW,nparm,ppParm,pot,etc_parm,rl)
tdtInfoParm	*pInfoParmW;
int nparm,etc_parm[];
tdtInfoParm	*ppParm[];
qOpeTable *pot;
int rl;
{
	char **pAns,id,*p;
	int rc,num,i1,nn,iParm[6];
	tdtInfoParm *ppParmW[3],tInfoParm1,tInfoParm2;

	cl_null_parm(pInfoParmW);
	if ((id=ppParm[0]->pi_id)=='A' || id=='R' || id=='L' || id=='N') {
		if (rc = cl_get_parm_bin(ppParm[1],&num,"Right/Left.num:")) return rc;
		if (num) {
			if ((nn=_get_num_info(ppParm[0])) < 0) return nn;
			if (num < 0) {
				if ((num += nn) <= 0) return 0;
			}
			if (rl) {	/* left */
				cl_set_parm_bin(&tInfoParm1,1);
				cl_set_parm_bin(&tInfoParm2,num);
				ppParmW[2] = &tInfoParm2;
				nparm = 3;
			}
			else {		/* right */
				if ((i1 = nn - num + 1) <= 0) i1 = 1;
				cl_set_parm_bin(&tInfoParm1,i1);
				ppParmW[2] = NULL;
				nparm = 2;
			}
			ppParmW[0] = ppParm[0];
			ppParmW[1] = &tInfoParm1;
			rc = _mid(pInfoParmW,nparm,ppParmW,pot,etc_parm);
		}
	}
	else {
		pAns = &p;
		if (rl)	/* left */
			rc = cl_leftm(pAns,etc_parm[0],nparm,ppParm);
		else	/* right */
			rc = cl_rightm(pAns,etc_parm[0],nparm,ppParm);
		if (!rc) {
			p = *pAns;
			if (p) nn = strlen(p);
			else nn = 0;
			mem_set_int(iParm,0,6);
			rc = cl_set_parm(pInfoParmW,p,DEF_ZOK_CHAR,iParm);
		}
	}
	return rc;
}
#endif
/****************************************/
/*	29									*/
/****************************************/
#if 1	/* 2025.10.8 */
static int _leftm_exf(pInfoParmW,nparm,ppParm,pot,etc_parm)
tdtInfoParm	*pInfoParmW;
#else
static int _leftm_exf(pAns,nparm,ppParm,pot,etc_parm)
char **pAns;
#endif
int nparm,etc_parm[];
tdtInfoParm	*ppParm[];
qOpeTable *pot;
{
	return _leftm_rightm_exf(pInfoParmW,nparm,ppParm,pot,etc_parm,1);
/*	return cl_leftm(pAns,etc_parm[0],nparm,ppParm);	*/
}

/****************************************/
/*	30									*/
/****************************************/
#if 1	/* 2025.10.8 */
static int _rightm_exf(pInfoParmW,nparm,ppParm,pot,etc_parm)
tdtInfoParm	*pInfoParmW;
#else
static int _rightm_exf(pAns,nparm,ppParm,pot,etc_parm)
char **pAns;
#endif
int nparm,etc_parm[];
tdtInfoParm	*ppParm[];
qOpeTable *pot;
{
	return _leftm_rightm_exf(pInfoParmW,nparm,ppParm,pot,etc_parm,0);
/*	return cl_righttm(pAns,etc_parm[0],nparm,ppParm);	*/
}

/****************************************/
/*	31									*/
/****************************************/
static int _rlpad_exf(pAns,nparm,ppParm,pot,etc_parm)
char **pAns;
int nparm,etc_parm[];
tdtInfoParm	*ppParm[];
qOpeTable *pot;
{
	return cl_rlpad(pAns,etc_parm[0],nparm,ppParm,pot->ope,pot->name);
}


/****************************************/
/*	32									*/
/****************************************/
static int _asc_exf(pWork,nparm,ppParm,pot,etc_parm)
char *pWork;
int nparm,etc_parm[];
tdtInfoParm	*ppParm[];
qOpeTable *pot;
{
	return cl_asc(pWork,etc_parm[0],nparm,ppParm);

}

/****************************************/
/*	33									*/
/****************************************/
static int _in_like_exf(pWork,nparm,ppParm,pot,etc_parm)
char *pWork;
int nparm,etc_parm[];
tdtInfoParm	*ppParm[];
qOpeTable *pot;
{
	return cl_in_like(pWork,etc_parm[0],nparm,ppParm);
}

/****************************************/
/*	34									*/
/****************************************/
static int _in_regex_exf(pWork,nparm,ppParm,pot,etc_parm)
char *pWork;
int nparm,etc_parm[];
tdtInfoParm	*ppParm[];
qOpeTable *pot;
{
	return cl_in_regex(pWork,etc_parm[0],nparm,ppParm);
}
#endif
#if 1	/* 2025.9.4 */
/****************************************/
/*	35									*/
/****************************************/
static int _mid(pInfoParmW,nparm,ppParm,pot,etc_parm)
tdtInfoParm *pInfoParmW;
int nparm,etc_parm[];
tdtInfoParm	*ppParm[];
qOpeTable *pot;
{
	tdtInfoParm	*pInfoParm1,*pInfoParm2,*pInfoParm3;
	tdtInfoParm ***pTBL,*pm[5],tInfoParm,tInfoParm1,tInfoParm2;
	tdtArrayIndex tIndex,*pIndex;
	tdtRbCtl *pCt;
	tdtRangeInt range[MAX_ARRAY_DIM];
	char *pAns,id,*p1,*name;
	int rc,i,iParm[6],i1,i2,nn,nm;
	long val[2];
/*
printf("_mid: nparm=%d pot->ope=%d etc_parm[0]=%d\n",nparm,pot->ope,etc_parm[0]);
*/
	cl_null_parm(pInfoParmW);
	pInfoParm1 = ppParm[0];
	id = pInfoParm1->pi_id;
	if (id=='L' || id=='N' || id=='A' || id=='R') {
		if (nparm > 3) nparm = 3;
		val[0] = val[1] = -1;
		for (i=0;i<nparm-1;i++) {
			if ((rc=cl_get_parm_bin(ppParm[i+1],&val[i],"val: ")) < 0) return rc;
		}
		i1 = val[0];
		nn = val[1];
		if (!nn) return 0;
		else if (nn < 0) {
			if (i1 <= 0) i1 = 1;
#if 1
			if ((nn=_get_num_info(pInfoParm1)) < 0) return nn;
#else
			if (id=='L' || id=='N') {
				pCt = (tdtRbCtl *)pInfoParm1->pi_data;
				nn =  akxs_rb_used(pCt);
			}
			else {
				pIndex = &tIndex;
				if ((rc=cl_get_array_info(pInfoParm1,pIndex,&pTBL,iParm)) < 0) return rc;
				if (pIndex->xhp) {
					if (!(p1 = (char *)pInfoParm1->pi_pos)) p1 = "";
							/* "%s: �A�z�z��(%s)�͎w��ł��܂���B*/
					ERROROUT2(FORMAT(239),"_mid",p1);
					return ECL_SCRIPT_ERROR;
				}
				nn = iParm[3]-iParm[2]+1;
			}
#endif
			i2 = nn;
		}
		else {
			if (i1 <= 0) {
				if (i1+nn <= 1) return 0;
				i2 = nn + i1 - 1;
				i1 = 1;
			}
			else i2 = nn + i1 - 1;
		}
		i1--;
		i2--;
/*
printf("_mid: i1=%d nn=%d\n",i1,i2,nn);
*/
		if (id=='L' || id=='N') {
			rc = cl_gx_list_bexp_sub(pInfoParmW,pInfoParm1,i1,i2,1);
		/*	rc = cl_gx_list_bexp(pInfoParmW,3,pm,0);	*/
		}
		else if (id=='A' || id=='R') {
#if 1
			cl_set_parm_int(&tInfoParm1,i1);
			cl_set_parm_int(&tInfoParm2,i2);
			pm[0] = pInfoParm1;
			pm[2] = &tInfoParm;
			pm[3] = &tInfoParm1;
			pm[4] = &tInfoParm2;
			rc = cl_gx_range_set(pm[2],2,pm+3,0);
DEBUGOUT_InfoParm(198,"_mid: i1=%d i2=%d",pm[2],i1,i2);
			rc = cl_gx_array_bexp(pInfoParmW,3,pm,0);
#else
			*pInfoParmW = *pInfoParm1;
			if (!(name=(char *)pInfoParm1->pi_pos)) name = "";
			range[0].ri_start = i1
			range[0].ri_end = i2;
			range[0].ri_num = nn;
			intval = range[0].ri_interval;
			rc = cl_get_array_range(pInfoParmW,pIndex,pTBL,range,name,0);
#endif
		}
	}
	else {
		if (nparm >= 2) pInfoParm2 = ppParm[1];
		else pInfoParm2 = NULL;
		if (nparm >= 3) pInfoParm3 = ppParm[2];
		else pInfoParm3 = NULL;
		rc = substrm(&pAns,etc_parm[0],pInfoParm1,pInfoParm2,pInfoParm3);
		mem_set_int(iParm,0,6);
		rc = cl_set_parm(pInfoParmW,pAns,DEF_ZOK_CHAR,iParm);
	}
	return rc;
}
#endif
/****************************************/
/*	36									*/
/****************************************/
static int _agg(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int nparm;
tdtInfoParm	*ppParm[];
{
	tdtInfoParm	tInfoParm;
	int rc,i;
	char *pOprtr;

	if ((rc=parm_to_char_tmp(ppParm[1],&pOprtr,0)) >= 0) {
/*
printf("_agg: pOprtr=[%s]\n",pOprtr);
*/
		if ((rc=cl_cmpt_agg(pInfoParmW,pOprtr,ppParm[0],ppParm[2])) >= 0) {
			for (i=3;i<nparm;i++) {
				cl_gx_copy_info(&tInfoParm,pInfoParmW);
				if ((rc=cl_cmpt_agg(pInfoParmW,pOprtr,&tInfoParm,ppParm[i])) < 0) break;
				rc = 0;
			}
		}
	}
	return rc;
}
