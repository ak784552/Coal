//
proc main;
	$1 = 'XYZ'//
		&+ 123;
	print $1//
 'ABC';//
	return ERROR;
end proc;
