//
/*
define global const double $PI_180=PI/180.0D;
define global const double $D180_PI=180.0D/PI;
//define const public double $PI_180=PI/180.0D;
//define const public double $D180_PI=180.0D/PI;
define $_d=srand1(TIME);
*/
class Math static;
	const PI_180=PI/180.0D;
//	local PI_180=PI/180.0D;
//	PI_180=PI/180.0D;
	_d=srand1(to_char(SYSDATE,'HHMMSS'));
//print PI_180 /i PI_180;
	func Math();
		const PI_90=PI/90.0D;
		return 0;
	end func;

func radians(doo);
	return $doo*$PI_180;
end func;

func sind(doo);
	return sin($doo*$PI_180);
end func;

func cosd(doo);
	return cos($doo*$PI_180);
end func;

func tand(doo);
	return tan($doo*$PI_180);
end func;

func asind(x);
	return asin(x)*D180_PI;
end func;

func acosd(x);
	return acos(x)*D180_PI;
end func;

func atand(x);
	return atan(x)*D180_PI;
end func;

func fact(x);
	return product(*((x+0)..1..-1));
end func;

func randint(int a,int b) as int;
	x = rand1();
	return (x-a)*(b-a)+0.5;
end func;

end class;
