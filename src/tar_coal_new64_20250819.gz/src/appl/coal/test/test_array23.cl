//
//def array a 10 = [11,12,13,14,15,16,17,18,19,20];
def mappedarray %c [2,10];
proc main;
	p = %();
//	q = %c;
//	print p q %c;
	p[1] = 10;
	q[1] = 20;
	print p[1] *%();
	print /d p %c %() %1;
	%1 = 1;

	return ERROR;
end proc;
