//
proc main;
	print (DEC(%1,%2))%3;
	print (DEC)%3;
	print (%4)(%3);
	$1 = 'abs';
	print ff($1)(%3);
	print ff(%4)(%3);
	a = (CINT)'123';
	print a;
	return ERROR;
end proc;
