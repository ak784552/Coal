//
def a 20 = {1,2,3,4,5,6,7,8,9,10};
def b 10 = {11,2,13,4,15,6,17,8,19,10};
def c 10 = {100,200,300};
proc main;
/*
	a = $() + [0,20];
	b = $() + [20,10];
	setarray(a,2,1,2,3,4,5);
//	setarray(a,0,1,2,3,4,5,6,7,8,9);
//	$7 = 7;
	print a *a;
	a[8] = 9;
//	print a;
	print *$();
	setarray(b,0,11,2,13,4,15,6,17,8,19,10);
	print $() *$();
*/
/*
	print a *a;
	print b *b;
	print c *c;
*/
//	print () (c[3]);
//	print /d x=();

	print *(*a+*b);
	print *(*a|*b);
	print *(*a-*b);
	print *(*a&*b);
	print *(*a&*c);

	print *a+*b;
	print *a-*b;
	print *a&*b;
	print *a|*b;
//	*a += *b;
//	*a -= *b;
//	*a &= *b;
//	*a |= *b;
//	print *a /d a;

	ab = *a|*b;
	print ab *ab /d ab;
	dab = *(*a&*b);
	print dab *dab /d dab;
//	print ab *ab /d ab;

	x = {1,2,3,4,5,6};
	y = {11,2,13,4,15,6};
	x += y;
	print x;

	xx = [1,2,3,4,5,6];
	yy = [11,2,13,4,15,6];
	xx &= yy;
	print xx;

	return ERROR;
end proc;
