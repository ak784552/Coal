//
//def x 10;
proc main;
/*
//	option 8 2;
//	x = abs mod;
	xx = aaa;
//	print aaa abs;
//	x = new xx(1,2);
*/
//	x = new aaa;
//	print x.a;
	x = new aaa(2);
	print x.a;

	x = new aaa(1,2);
//	x = new aaa(x,2);
//	x = aaa new 1;
	print x.a x.b;
	x = new aaa('XXX','YYYY');
	print x.ca x.cb;

	print x.bbb('A','B');
//	print x.bbb('A',x);
	print x.ca x.cb;

	print x.bbb(100,200);
	print x.a x.b;

//	print x /d x;
	print x.fun(10,20,30);
	print x.a x.b x.ca x.cb;

	y = new(aaa,3,4);
//	y = new(aaa);
	print y /d y;
	print *y y.a y.b;
	print y.fun(11,22,33);

	$1 = 'aaa';
	z = new($1,10,20);
	print z /d z;
	print *z z.a z.b;
	print z.fun(100,200,300);

	xx = new(abs,10,20);

	return ERROR;
end proc;

class aaa;
//	int a;
//	char b;
//	local a,b;
//	let def local a;
//	scalar local b;
//	var local a;
//	var local b;
	variant a,b;
	var ca,cb;
//	local ca,cb;
//	variant ca,cb;
	func aaa;
		return 0;
	end func;
//	func aaa(x,);
	func aaa(x);
		print 'aaa' x;
		My.a = x;
		return 0;
	end func;
	func aaa(char(5) x,y as char(10));
		print 'aaa char' x y;
		My.ca = x;
		My.cb = y;
		return 0;
	end func;
	func aaa(int x,y as int);
		print 'aaa int' x y;
		My.a = x;
		My.b = y;
		return 0;
	end func;
	func bbb(int x,y as int);
		print 'bbb int' x y;
		My.a = x;
		My.b = y;
		return 0;
	end func;
	func bbb(char(5) x,y as char(10));
		print 'bbb char' x y;
		My.ca = x;
		My.cb = y;
		return 0;
	end func;
	func fun(x,y,z);
		print 'fun' x y z;
		print 'fun' My.a My.b My.ca My.cb;
		return My.a*My.b;
	end func;
end class;
