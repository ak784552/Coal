
#=define _L	do
#=define _J	end do;
#=define _LL	then do
#=define _JJ	enddo; endif;

#*define Space(n)	Strings(' ',n)
#*define SkipIn(a,b)	Skip_opt(a,b,0)
#*define SkipRIn(a,b)	Skip_opt(a,b,0x02)
#*define SkipiIn(a,b)	Skip_opt(a,b,0x01)
#*define SkipiRIn(a,b)	Skip_opt(a,b,0x01|0x02)
#*define SkipTo(a,b)	Skip_opt(a,b,0x08)
#*define SkipRTo(a,b)	Skip_opt(a,b,0x08|0x02)
#*define SkipiTo(a,b)	Skip_opt(a,b,0x01|0x08)
#*define SkipiRTo(a,b)	Skip_opt(a,b,0x01|0x08|0x02)

#*include class_math.cl
