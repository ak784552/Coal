//
def a 10;
proc main;
	print %() *%();
	setarray(1,'A','B','C');
	print $() *$();
	i = 1;
	loop %0;
		print $i $(i) %$i %(i);
		i++;
	end loop;
	print %()[2];
	p = %()+0;
	print p *p p[1];
	b = a + 1;
	print a b;

	return ERROR;
end proc;
