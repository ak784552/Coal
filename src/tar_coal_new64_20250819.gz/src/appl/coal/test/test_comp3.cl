//
def mappedarray %ma 1 10;
def mappedarray ma 1 10;
proc main;
//	print () [] {};
//	int ($())=1,2,3;
	setarray(1,0,1,2,3);
	print $() *$();
	print /i %ma %();
	print  *%ma *%() *ma;
	print arraycmp(ma,%());
	ma[5] = 'AA';
	$10 = 1;
//	print arraycmp('1','1') *$();
	print $(65) ma[11];
	print $(1);
	return ERROR;
end proc;
