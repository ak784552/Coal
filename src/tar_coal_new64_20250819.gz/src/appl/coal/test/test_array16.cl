//
define array $a 10 = [1,2,3,4,5];
define array x 5;
def c;
proc main;

	b = a;
	print b;
	b[5] = 6;
	a[6] = 7;
	print *a *b b[6] b[7] b[-1] b[10];

	print x *x;
	x[0] = 1;
	print *x;

	print *(a+1);

	print %()[3];

	redef a 20;
	print b *b;

	fn();
	print c;
	print *c;

	return ERROR;
end proc;

func fn();
	array x 10 = [1,2,3,4,5];
	c = x;
	print x c;
	return 0;
end func;
