static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  													      *
*                                                                             *
*      �֐����@�@�@�F�@int cl_ex_get_proc_name( pparmList , pBuff , plen )    *
*                      (I)prmList	*pparmList                                *
*                      (O)char		*pBuff		                              *
*                      (O)int		*plen		                              *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;

/********************************************************/
/*														*/
/********************************************************/
int cl_trim_proc_name(p0,len0,pr_nam)
char *p0;
int  len0;
ParList *pr_nam;
{
	static char *PAT=" \t\n\r";
	int len;

	len = akxtstrim2(0,p0,len0,pr_nam,PAT);
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
static int _check_variable(p,len)
char *p;
int len;
{
	static char *_fn_="_check_variable";
	static char *C_SEP=" \t.@'";
	SSPL_S ssp;
	int n,i,pos;
	char c,cb;

	memset(&ssp,0,sizeof(SSPL_S));
	i = 0;
	cb = '.';
	pos = 1;
	while ((n=akxtgwnsl(p,len,&ssp,C_SEP,0x41)) >= 0) {
		c = *ssp.wd;
DEBUGOUTL5(120,"%s: n=%d atr=%d sp=%d c=[%c]",_fn_,n,ssp.attr[0],ssp.sp,c);
		if (cb == '.') {
			if (instrchar("$#%'(",c) > 0) {
				i = ssp.sp;
				break;
			}
		}
		cb = c;
		pos = ssp.sp;
	}
DEBUGOUTL2(120,"%s,:Exit i=%d",_fn_,i);
	return i;
}

/********************************************************/
/*	ret = 0 : �J�b�R�Ȃ�								*/
/*		= 1 : �J�b�R�ň͂܂�Ă���						*/
/*		= 2 : �J�b�R�̏I��肪�r���ɂ���				*/
/*		=-1 : �J�b�R���΂ɂȂ��Ă��Ȃ�					*/
/********************************************************/
static int _check_kakko(p,len)
char *p;
int len;
{
	static char *C_SEP=" \t()'";
	SSPL_S ssp;
	int ret,n,kk;
	char c;

	ret = 0;
	if (*p=='(' && p[len-1]==')') {
		ret = 1;
		ssp.sp = 0;
		ssp.wd = 0;
		ssp.wdmax = 0;
		kk = 0;
		while ((n=akxtgwnsl(p,len,&ssp,C_SEP,0x41)) >= 0) {
			c = *ssp.wd;
			if (c == '(') kk++;
			else if (c == ')') {
				kk--;
				if (kk >= 0) {
					if (!kk && ssp.sp<len) {
						ret = 2;
/*
printf("_check_kakko: len=%d ssp.sp=%d\n",len,ssp.sp);
*/
						break;
					}
				}
				else {
					break;
				}
			}
		}
	}
	if (kk) ret = -1;
/*
printf("_check_kakko: ret=%d\n",ret);
*/
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int cl_ex_get_proc_name(pparmList, Obj, pr_nam)
parmList *pparmList;
int  *Obj;
ParList *pr_nam;
{
	static char *_fn_="cl_ex_get_proc_name";
	int  rc,len,pos,n;
	char *p,*pn;
	tdtInfoParm InfoParm;

	p   = pparmList->prp;
	len = pparmList->prmlen;
DEBUGOUTL3(110,"%s:Enter len=%d p=[%s]",_fn_,len,p);
	if (cl_trim_proc_name(p,len,pr_nam) < len) {
		p   = pr_nam->par;
		len = pr_nam->parlen;
	}
	if (*p=='{' && p[len-1]=='}') ;
#if 1	/* 2024.08.26 */
#if 1	/* 2024.10.21 */
	else if (_check_variable(p,len) > 0) {
#else
	else if (instrchar("$#%'(",*p) > 0) {	/* main.$x��������̂ŁA����ł͂m�f */
#endif
#else
	else if (!cl_is_proc_scr_name(p,len)) {
#endif
		pparmList->prp    = p;
		pparmList->prmlen = len;
		if (rc=cl_arg_to_char_opt(pparmList,Obj,&InfoParm,FORMAT(326),D_GX_OPT_PROC_NAME)) return rc;	/* "�葱����" */
		p   = InfoParm.pi_data;
		len = InfoParm.pi_dlen;
		if (cl_trim_proc_name(p,len,pr_nam) < len) {
			p   = pr_nam->par;
			len = pr_nam->parlen;
		}
	}
DEBUGOUTL3(120,"%s: len=%d p=[%s]",_fn_,len,p);
	n = len;
	if (n <= 0) {
		ERROROUT2(FORMAT(327),_fn_,FORMAT(114));	/* %s: %s����NULL�ł��B */
		rc = ECL_SCRIPT_ERROR;
	}

DEBUGOUTL2(110,"%s:Exit rc=%d",_fn_,rc);
	return rc;
}

/********************************************************/
/*	int cl_exe_proc_name_check(pr_nam)					*/
/*	opt = 0x0001 : Ok '.' in name						*/
/*        0x0002 : OK '-' in name						*/
/*        0x0010 : Check sysvar_name					*/
/*        0x0020 : Check yoyakugo						*/
/*        0x1000 : for var name							*/
/********************************************************/
int cl_dot_name_check_opt(func,pr_nam,opt)
char *func;
ParList *pr_nam;
int opt;
{
	static char *_fn_="cl_dot_name_check_opt";
	int  rc,len,pos,n,opt10,opt20,iVAR,m;
	char *p,*pn,*nam;

	opt10 = opt & 0x10;
	opt20 = opt & 0x20;
	iVAR = opt & 0x1000;
	rc = 0;
	p   = pr_nam->par;
	len = pr_nam->parlen;
DEBUGOUTL3(110,"%s:Enter len=%d p=[%s]",_fn_,len,p);
	n = len;
	if (iVAR) {
		pn = FORMAT(329);	/* �ϐ� */
		m = Var_NM_MAX;
	}
	else {
		pn = FORMAT(114);	/* �葱�� */
		m = PR_NM_DEF;
	}
	while (len > 0) {
		n = akxnskipto(p,len,".");
DEBUGOUTL2(120,"%s: n=%d",_fn_,n);
		nam = strtemp(p,n);
		if (n > m) {
						/* %s: %s��[%s]���������܂�(len=%d > %d)�B*/
			if (func) ERROROUT5(FORMAT(112),func,pn,nam,n,m);
			rc = ECL_SCRIPT_ERROR;
		}
		else if (n<=0 || n==len-1) {
			rc = ECL_SCRIPT_ERROR;
			n = 0;
		}
		else if (cl_chk_name_opt(p,n,opt)) {
						/* %s: %s��[%s]���s���ł��B */
			if (func) ERROROUT3(FORMAT(113),func,pn,nam);
			rc = ECL_SCRIPT_ERROR;
		}
		if (!rc && opt10) {
			if (cl_chk_sysvar_name(p,n)) {
				if (func) ERROROUT2(FORMAT(453),func,nam);
				rc = ECL_EX_DEFINE;
			}
		}
		if (!rc && opt20) {
			if (cl_is_yoyakugo(strtemp(p,n))) {
				if (func) ERROROUT2(FORMAT(121),func,nam);
				rc = ECL_EX_DEFINE;
			}
		}
		if (rc) break;
		len -= ++n;
		p += n;
	}
	if (n <= 0) {
		if (func) ERROROUT2(FORMAT(327),func,pn);	/* %s: %s����NULL�ł��B */
		rc = ECL_SCRIPT_ERROR;
	}
DEBUGOUTL2(110,"%s:Exit rc=%d",_fn_,rc);
	return rc;
}

/********************************************************/
/*														*/
/********************************************************/
int cl_dot_name_check(pr_nam)
ParList *pr_nam;
{
	static char *_fn_="cl_dot_name_check";

	return cl_dot_name_check_opt(_fn_,pr_nam,0);
}

/********************************************************/
/*														*/
/********************************************************/
int cl_exe_proc_name_check(pr_nam)
ParList *pr_nam;
{
	static char *_fn_="cl_exe_proc_name_check";

	return cl_dot_name_check_opt(_fn_,pr_nam,0x32);
}

/********************************************************/
/*														*/
/********************************************************/
int cl_ex_get_proc_scr_name_sub(pparmList,Obj,pr_nam,sc_nam,opt)
parmList *pparmList;
int  *Obj;
ParList *pr_nam,*sc_nam;
int opt;
{
	static char *_fn_="cl_ex_get_proc_scr_name_sub";
	static char *C_SEP=" \t@'";
	int  ret,len,n,i,pos,len0;
	char *p,*da[2],na[2],*pp,c,*p0;
	SSPL_S ssp;
	int atr;
	char wrk[4096];
	parmList *pparm,parm;
	ParList par[2];
	tdtInfoParm InfoParm;

	ret = 0;
	p0 = p = pparmList->prp;
	len0 = len = pparmList->prmlen;
DEBUGOUTL3(110,"%s:Enter len=%d p=[%s]",_fn_,len,p);
	if (cl_trim_proc_name(p,len,pr_nam) < len) {
		p   = pr_nam->par;
		len = pr_nam->parlen;
	}
	if (*p=='{' && p[len-1]=='}') {
		sc_nam->par = p;
		sc_nam->parlen = len;
		pr_nam->par = NULL;
		pr_nam->parlen = 0;
		return 0;
	}
	else {
		if ((ret=_check_kakko(p,len)) < 0) return ret;
		else if (ret == 1) {
			pparmList->prp = p + 1;
			pparmList->prmlen = len - 2;
			ret = cl_ex_get_proc_scr_name_sub(pparmList,Obj,pr_nam,sc_nam,opt);
			pparmList->prp = p0;
			pparmList->prmlen = len0;
			return ret;
		}
	}
	ssp.sp = 0;
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk)-1;
	i = 0;
	while ((n=akxtgwnsl(p,len,&ssp,C_SEP,0x41)) >= 0) {
DEBUGOUTL5(120,"%s: n=%d atr=%d sp=%d wd=[%s]",_fn_,n,ssp.attr[0],ssp.sp,ssp.wd);
		c = *ssp.wd;
		if (c == '@') {
			i = ssp.sp - 1;
DEBUGOUTL2(120,"%s: i=%d",_fn_,i);
			break;
		}
	}
	if (i > 0) {
		par[0].par = p;
		par[0].parlen = i;
		par[1].par = p + i + 1;
		par[1].parlen = len - (i+1);
		pp = wrk;
		len = 2;
		for (i=0;i<2;i++) {
			parm.prp    = pp;
			parm.prmlen = par[i].parlen;
			parm.opt    = 0;
			parm.bxobj  = NULL;
			memzcpy(parm.prp,par[i].par,parm.prmlen);
DEBUGOUTL4(120,"%s: i=%d parm.prmlen=%d parm.prp=[%s]",_fn_,i,parm.prmlen,parm.prp);
			if (ret = cl_ex_get_proc_name(&parm,Obj,&par[i])) return ret;
DEBUGOUTL3(120,"%s: na=%d da=[%s]",_fn_,par[i].parlen,par[i].par);
			pp += parm.prmlen+1;
			len += par[i].parlen;
		}
		i = 1;
	}
	else {
		sc_nam->par = NULL;
		sc_nam->parlen = 0;
		/* 2024.3.20 */
#if 1	/* 2024.8.26 */
#if 1	/* 2024.10.21 */
		if (_check_variable(p,len) > 0) {
#else
	/*	if ((c==*p)=='$' || c=='#' || c=='%' || c=='\'' || c=='(') {	*/
		if (instrchar("$#%'(",*p) > 0) {
#endif
#else
		if (!cl_is_proc_scr_name(p,len)) {
#endif
			if (ret=cl_arg_to_char_opt(pparmList,Obj,&InfoParm,FORMAT(326),D_GX_OPT_PROC_NAME)) return ret;	/* "�葱����" */
			p   = InfoParm.pi_data;
			len = InfoParm.pi_dlen;
			if (cl_trim_proc_name(p,len,pr_nam) < len) {
				p   = pr_nam->par;
				len = pr_nam->parlen;
			}
			parm.prp    = p;
			parm.prmlen = len;
			parm.opt    = D_GX_OPT_NO_USE_OBJ;
			parm.bxobj  = NULL;
			pparm = &parm;
			if (opt) return cl_ex_get_proc_scr_name_sub(pparm,Obj,pr_nam,sc_nam,0);
		}
		else {
			pparm = pparmList;
		}
		if (ret = cl_ex_get_proc_name(pparm,Obj,pr_nam)) return ret;
		p = pr_nam->par;
		if ((i=instrchar(p,'@',0)) > 0) {
			len = pr_nam->parlen;
			par[0].par = p;
			par[0].parlen = i - 1;
			par[1].par = p + i;
			par[1].parlen = len - i;
			len++;
		}
		else {
		}
	}
	if (i > 0) {
		pp = cl_tmp_const_malloc(len);
		memzcpy(pp,par[0].par,par[0].parlen);
		pr_nam->par = pp;
		pr_nam->parlen = par[0].parlen;
		pp += par[0].parlen + 1;
		memzcpy(pp,par[1].par,par[1].parlen);
		sc_nam->par = pp;
		sc_nam->parlen = par[1].parlen;
	}
DEBUGOUTL2(110,"%s,:Exit ret=%d",_fn_,ret);
	return 0;
}

/********************************************************/
/*														*/
/********************************************************/
int cl_ex_get_proc_scr_name(pparmList,Obj,pr_nam,sc_nam)
parmList *pparmList;
int  *Obj;
ParList *pr_nam,*sc_nam;
{
	return cl_ex_get_proc_scr_name_sub(pparmList,Obj,pr_nam,sc_nam,1);
}
