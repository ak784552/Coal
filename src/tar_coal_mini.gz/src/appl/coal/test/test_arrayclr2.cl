//
//define array a hash;// 10; 
//define array b 20 = 1,2,3,4,5,'A','B','C','D','E';
//define array BIN c 20 = 1,2,3,4,5,6,7,8,9,10;
//define mappedarray $m 11 10;
//define mappedarray %p 1 10;
//define mappedarray #s 1 10;
proc main;
	set_array(1,1,2,3,4,5,6,7,8,9,10);
	print *$();
//	print *b;
//	print *c;
//	print *m;
/*
	print arrayclr(1,5);
	print arrayclr(b,5);
	print arrayclr(c,5);
*/
	print arrayclr(1);
//	print arrayclr(b);
//	print arrayclr(c);

	print *$() $5;
//	print *b b[4];
//	print *c c[4];
//	print *m m[4];

	return ERROR;
end proc;
