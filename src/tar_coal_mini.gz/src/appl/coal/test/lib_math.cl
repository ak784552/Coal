//
//define global const double $PI_180=PI/180.0D;
//define global const double $D180_PI=180.0D/PI;
//define const public double $PI_180=PI/180.0D;
//define const public double $D180_PI=180.0D/PI;
define const double $PI_180=PI/180.0D;
define const double $D180_PI=180.0D/PI;
define $_d=srand1(1234567);

func sind(doo);
	return sin($doo*$PI_180);
end func;

func cosd(doo);
	return cos($doo*$PI_180);
end func;

func tand(doo);
	return tan($doo*$PI_180);
end func;

func asind(x);
	return asin(x)*D180_PI;
end func;

func acosd(x);
	return acos(x)*D180_PI;
end func;

func atand(x);
	return atan(x)*D180_PI;
end func;
