//
import 'lib_math' as LIB_MATH;
//import 'lib_iconv' as LIB_ICONV;
//import 'test_import3';
//import 'lib_iconv';
import 'lib_math';
define sa;
PROC main;
	print aa;
	sa='aaa';
	print a;
//	print /x conv('ABC123',6);
//	print /x "conv('ABC' & chr(0xf1) & chr(0xf2) & chr(0xf3),6)";
	print sind(30d);
//	print /x LIB_ICONV.conv('ABC123',6);
	print LIB_MATH.sind(30d);
	print sa;
	RETURN $ERROR;
END PROC;
