//
//def h hash 10 = ['A',11,'B',22,'C',33,'D',44,'E',55];
//def char x 10 = [10,20,30,40,,60];
//def y 10 = [21,22,23,24,,26];
//def xx 10;
proc main;

	a = [1,2,3,4,5,,7];
	print element(a,'+',10);
	print a;
/*
	print element(x,'-',5);
	print *x;
	print *element(y,'-',5,,1);
	print *y;
	print element(a,'CONCAT',10);
	print a;
*/
//	print /i {1,2,3};
	print element({1,2,3},'*',2);
	print element({1,2,3},'*',2,,1);
	b = [11,22,33,44,55];
	print element(b,'=+',10);
//	print *element(x,'=-',5,3);
	print element(a,'=',10);
	print a;
	b = [1,2,3,4,5];
	print element(b,'+',100,,1);
/*
	print *element(h,'*',2,,1);
	print *h;
	print element(h,'*',2);
	print *h;
*/
	set_array(1,10,11,12,13,14,15);
//	print *element(1,'/',2.0,,1);
	print element(1,'/',2.0);
	print *$();
	$100 = 0;
	print /i element(100,'+',100,,1);
//	print /i element(100,'+',100);
	print $100;
	c = $() + 99;
	print c c[0];
/*
	print element(xx,'+',5);
	print *xx;
	print element(xx,'+',5,,1);
	print *xx;
*/
	d = {};
	print element(d,'+',5);
	print d;
	print element(d,'+',5,,1);
	print d;
	e = [1,2,NULL,,7];
	print element(e,'+',10,,1);

	print *element(0,'+',20,,1);

	print element([-1,-2],abs,0);
	print element([PI/2,M_E],sin,0);
	print element(['1.25',3],to_number,2);

	return ERROR;
end proc;
