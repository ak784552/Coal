//
//(1)�R�}���h
//	../coal exec_all_test list_test.txt [-pqsnl] [test_case ...]
//	�I�v�V����
//	"-p test_case ... ":test_case�ȍ~�����s�̗L�����m�F���Ȃ�����s����
//	"-q" : �X�N���v�g�̎��s�̗L�����m�F����
//	"-s" : ���s�̗L�����m�F���Ȃ�
//	"-n" : �P�[�X���݂̂��o�͂���
//	"-l" : ���s���C�����o�͂���
//
//(2)���X�g�t�@�C���d�l
//	"@[�C�ӕ���] �P�[�X��" : �P�[�X�̊J�n�B����"@"�܂�
//	"@[�C�ӕ���]: �P�[�X�̏I���
//	"//": ���s�I��
//	"##": �P�[�X���ňȍ~���X�L�b�v�B"@[�C�ӕ���]"�݂̂Ɠ���
//	"#" : 1�s�X�L�b�v
//	"-o �I�v�V�����ݒ�": �ݒ�t�@�C����OPTION�Ɠ����B"//"�ȍ~�̓R�����g
//	"--d2,200"
//	"/*": "*/"�܂ŃR�����g
//	�X�N���v�g�� �p�����[�^-1 �p�����[�^-2 �E�E�E: ���s����X�N���v�g
//		���s����X�N���v�g�̃p�����[�^����"//": �ȍ~�R�����g
//
def opt = $() + [20,31];
def a   = $() + [51,20];
def int max_loop_while;
def here_doc = '';
def list_file = '';
def line;
def end_flg = 0;
def p_mode = 0;
def q_mode = 0;
def s_mode = 0;
def l_mode = 0;
def to_read = 1;
def opt15;
option 7 0x400;
//***************************
//*	main					*
//***************************
proc main;
	if !%0 ;
		echo 'usage:' SCRIPTNAME 'test_file [-psnl] [test_case ...]';
		echo '  -p test_case ... : test_case�ȍ~�����s�̗L�����m�F���Ȃ�����s����';
		echo '  -q : �X�N���v�g�̎��s�̗L�����m�F����';
		echo '  -s : ���s�̗L�����m�F���Ȃ�';
		echo '  -n : �P�[�X���݂̂��o�͂���';
		echo '  -l : ���s���C�����o�͂���';
		return 1;
	else
//		exec >& rusult.txt;
		list_file = %1;
		shift;
		loop %0;
			arg = %1 to 'U';
			if left(arg,1) == '-' ;
				if instr(arg,'S') > 0 then s_mode = 1;endif;
				if instr(arg,'P') > 0 then p_mode = 1;endif;
				if instr(arg,'Q') > 0 then q_mode = 1;endif;
				if instr(arg,'N') > 0 then s_mode = 2;endif;
				if instr(arg,'L') > 0 then l_mode = 1;endif;
				shift;
			else;
				break;
			end if;
		end loop;
//print %0 s_mode p_mode %1;
		if s_mode == 2 ;
			exec ip list_case;
		elseif %0==0 ;
			p_mode = 0;
			exec ip normal_exec;
		else
			if p_mode ;
				exec ip normal_exec;
			else
				exec ip find_exec_case;
			end if;
		end if;
	end if;
	return ERROR;
end proc;

//***************************
//*	find_exec_case			*
//***************************
proc find_exec_case;
	loop;
	  if %0;
//		try (fp = fopen(list_file)) ;
		if fp = fopen(list_file);
			get_option();
			i = 0;
			loop ;//for i=0 to 5;
				line = fgetline(fp);
				if ERROR; break; end if;
				if !line ;
					continue;
				end if;
				n = split(line,a,23);
				f = a[0];
				if ret=if_other(n,fp,f,'') ;
					if ret == 100 ;
						break;
					end if;
				elseif left(f,1)=='@' && n>=2 ;
					if %1 == a[1] ;
						exec ip exec_case fp a[1];
						break;
					end if;
				end if;
			end loop;
			fclose(fp);
		else
			break;
		end if;
//		catch FILE_READ_END_EXCEPTION;
//			;
//		catch;
//			print ERRMSG;
//		end try;
		shift;
	  else
		break;
	  end if;
	end loop;
	return ERROR;
end proc;

//***************************
//*	normal_exec				*
//***************************
proc normal_exec();
//print 'Enter normal_exec' list_file %1;
//	try (fp = fopen(list_file)) ;
	if fp = fopen(list_file);
		get_option();
		i = 0;
		line = '';
		loop ;//for i=0 to 5;
			if to_read ;
				line = fgetline(fp);
//print line;
				if ERROR; break; end if;
				if !line ;
					continue;
				end if;
			end if;
			n = split(line,a,23);
			f = a[0];
//print f;
//print f /x getval('OPTION',21);
			if ret=if_other(n,fp,f,'') ;
				if ret == 100 ;
					break;
				end if;
			elseif left(f,1)=='@' && n>=2 ;
//print line;
				if p_mode ;
					if %1 <> a[1] ;
						continue;
					end if;
					p_mode = 0;
				end if;
				if !s_mode ;
				//	printf /u '%s ��������܂����B���s���܂����H(n/c/[y|etc])' line;
					printf('%/u%s ��������܂����B���s���܂����H(n/c/[y|etc])',line);
					yn=left(getline(),1) to 'U';
					if yn=='N' ;
						continue;
					elseif yn=='C' ;
						break;
					end if;
				end if;
				exec ip exec_case fp a[1];
//				if ERROR; break; end if;
				if end_flg ;
					break;
				end if;
			end if;
		end loop;
//	else
//		print ERROR ERRMSG;
	end if;
	if ERROR == CLEOF;
//	catch FILE_READ_END_EXCEPTION;
//		;
//	catch;
	elseif ERROR;
//		print ERRMSG;
//	end try;
	end if;
	return ERROR;
end proc;

//***************************
//*	exec_case				*
//***************************
proc exec_case(fp,case_nam0);
	case_nam = case_nam0;
	putline('@@@@@@@@@@ start ',case_nam);
	ret = 0;
	to_read = 1;
	loop ;//for i=0 to 5;
		line = fgetline(fp);
		if ERROR; break; end if;
//print line;
		if !line ;
			continue;
		end if;
//		arrayclr(a);
		n = split(line,a,23);
//print n *a;
		f = a[0];
		if left(f,1)=='@' ;
			if n > 1 ;
				to_read = 0;;
			end if;
			break;
		end if;
		f = a[0];
		if ret=if_other(n,fp,f,case_nam,1,1) ;
			if ret == 100 ;
				break;
			end if;
		else
			if q_mode then
			//	printf('/u','%s �����s���܂����H(n/c/[y|etc])',$f);
				printf('%/u%s �����s���܂����H(n/c/[y|etc])',$line);
				yn=left(getline(),1) to 'U';
				if yn=='N' then
					continue;
				elseif yn=='C' then
					break;
				end if;
			end if;
			echo '*** start' f '***';
//			try;
				nparm = chk_heredoc(n,fp);
//print *$();
			//	exec sc:trypass $f $*;
			//	exec sc:notrypass $f $*;
			//	exec sc $f $*;
			//	exec sc $f $1,20*;
				exec sc $f $(1,nparm)*;
print ERROR;
			if CLEOF;
//			catch FILE_READ_END_EXCEPTION;
//				;
//			catch;
			elseif ERROR;
				print ERRMSG;
//			end try;
			end if;
			undef const like public % not global ei_to_u eb_to_u PI_180;
			reset_option();
			echo '*** end  ' f '***';
		endif;
	end loop;
	reset_option();
	if ret<>100 ;
		putline('@@@@@@@@@@ end ',case_nam);
	end if;
	return ERROR;;
end proc;

//***************************
//*	if_other				*
//***************************
func if_other(n,fp,f,nam,mode=0,ex_opt=0);
	to_read = 1;
	f2 = left(f,2);
	if f2=='//' ;
//print '//';
		ret = 100;
		end_flg = 1;
	elseif left(f,2)=='##' ;
		if mode ;
			echo '*** skip ' nam '***';
		end if;
		ret = 100;
	elseif ex_opt && f2=='-o' ;
//print '-o';
		a[0] = substr(f,3);
		set_option(n);
		ret = 1;
	elseif f2=='/*' ;
//print '/*';
		skip_comment(fp);
		ret = 1;
	elseif left(f,1)=='#' ;
//print '#';
		if mode ;
			echo '*** skip ' f '***';
		end if;
		chk_heredoc(n,fp,0);
		if $1 ;
			t = '';
			if ($2 & 0x02) ;
				t &+= '\\t';
			end if;
			if ($2 & 0x04) ;
				t &+= ' ';
			end if;
			loop;
				line = fgetline(fp);
//print line;
				if trim(line,t) == $1 ;
					break;
				end if;
			end loop;
			to_read = 0;
		end if;
		ret = 1;
	else
		ret = 0;
	end if;
	return ret;
end func;

//***************************
//*	get_option				*
//***************************
func get_option();
	max_loop_while = MAX_LOOP_WHILE;
//	for i=1 to 30;
	i=1;
	loop 30;
		opt[i] = getval('OPTION',i);
//print opt[i];
//	next;
		i++;
	end loop;
	opt15 = opt[15];
//print 'get_option' opt opt15;
	return ERROR;
end func;

//***************************
//*	reset_option			*
//***************************
func reset_option();
	option 15 opt15;
//print 'reset_option' opt;
//print 1 /x opt[1];
	option 1 opt[1];
	MAX_LOOP_WHILE = max_loop_while;
//	for i=1 to 30;
	i=1;
	loop 30;
//print i opt[i];
		option i opt[i];
//	next;
		i++;
	end loop;
	return ERROR;
end func;

//***************************
//*	set_option				*
//***************************
func set_option(n);
	max_loop_while = MAX_LOOP_WHILE;
//	for i=0 to n-1;
	i=0;
	loop;
		if i > n-1; break; end if;
		ii = i;
		val = a[i];
		if left(val,2) == '//' ;
			break;
		elseif (pos=instr(val,'='))>0 ;
			ii = left(val,pos-1);
			val = substr(val,pos+1);
		end if;
//print ii /x val;
		option ii val;
//	next;
		i++;
	end loop;
	return ERROR;
end func;

//***************************
//*	chk_heredoc				*
//***************************
func chk_heredoc(n,fp,mode=1);
//print n;
	arrayclr(1,0,20);
	here_doc = '';
	nparm = 0;
	if !mode ;
		$1 = '';
		$2 = 0;
		nparm = 2;
	end if;
	ii = 1;
//	for i=1 to n-1;
	i=1;
	loop;
		if i> n-1; break; end if;
		x = a[i];
		if left(x,2)=='<<' ;
			nam = substr(x,3);
			pos = skip_opt(nam,'-=!',8);
			hd_opt  = 0x10;
			if pos > 0 ;
			//	if instr(nam,1,pos,'!') ; hd_opt  = 0x10; endif;
				if instr(nam,1,pos,'-') ; hd_opt |= 0x20; endif;
				if instr(nam,1,pos,'=') ; hd_opt |= 0x60; endif;
				nam = substr(nam,pos+1);
			end if;
			if nam=='' ;
				if i < n-1;
					nam = x = a[i+1];
				end if;
			endif;
//			if nam<>'' ;
			if mode ;
//print /x fp;
				here_doc = redirect(fp,nam,hd_opt);
//print to_bulks(fp,nam);
//				here_doc = to_bulks(fp,hd_opt,nam)<=='STDIN';
//print here_doc;
				nparm = ii;
				$(ii++) = here_doc;
			else
				$1 = nam;
				$2 = hd_opt;
			endif;
			break;
		elseif left(x,2)=='//' ;
			break;
		else
			if mode ;
				$(ii) = x;
			end if;
//print ii $(ii) $0;
			nparm = ii;
			ii++;
		endif;
//	next;
		i++;
	end loop;
	return nparm;
end func;

//***************************
//*	skip_comment			*
//***************************
func skip_comment(fp);
	loop;
		line = fgetline(fp);
		if ERROR; break; end if;
//print line;
		if !line ;
			continue;
		end if;
		n = split(line,a,2);
		f = a[0];
		if left(f,2)=='*/' ;
			break;
		end if;
	end loop;
	return ERROR;
end func;

//***************************
//*	list_case				*
//***************************
proc list_case;
//	try (fp = fopen(list_file)) ;
	if fp = fopen(list_file) ;
		i = 0;
		loop;
			line = fgetline(fp);
			if ERROR; break; end if;
			if line ;
				if left(line,2)=='/*' ;
					skip_comment(fp);
				elseif left(line,1)=='@' ;
					n = split(line,a,2);
					if n>=2 ;
						putline(a[1]);
					end if;
				end if;
			end if;
		end loop;
	end if;
//	catch FILE_READ_END_EXCEPTION;
//		;
//	catch;
//		print ERRMSG;
//	end try;
	return ERROR;
end proc;
