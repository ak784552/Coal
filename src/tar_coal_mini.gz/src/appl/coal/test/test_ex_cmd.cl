//
proc main;
/*
	a = `!cat test.cl`;
	print a;
	print `print 'aa''a'`;
	x = 'ls -l test.*';
//	a = `shell(x)`;
	a = `!$x`;
//	split(a,1,,'\n');
//	print *$();
	print grep(a,'.Sh',1);
	print `print(x)`;
	print `print('aaaaaa');
print 'bbbbbb'`;
	print /nq- `print /nq- ``print /q- 'xxx'``&``print /q- 'yyy'```;
	x = to_bulk('1234567890');
	a = `!cat ``$x`;
	print a;
*/
	x = `print a`;
	print x;
	return ERROR;
end proc;
