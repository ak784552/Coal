//
// �X�N���v�g�t�@�C���́A�ǂݍ��܂��Ƃ���UTF-8�ɕϊ������̂ŁA
// �����Ŏw�肵���ϊ��\�̕����R�[�h��UTF-8�ɂȂ�
//
define const global array char(3) ei_to_u 128 =
		{' ','�','�','�','�','�','�','�','�','�','' ,'.','<','(','+',''
		,'&','�','�','�','�','�','�','' ,'�','' ,'!','\\','*',')',';',''
		,'-','/','a','b','c','d','e','f','g','h','|',',','%','_','>','?'
		,'[','i','j','k','l','m','n','o','p','`',':','#','@','''','=','"'
		,']','�','�','�','�','�','�','�','�','�','�','q','�','�','�','�'
		,'�','�','�','�','�','�','�','�','�','�','�','r','' ,'�','�','�'
		,'~','' ,'�','�','�','�','�','�','�','�','�','s','�','�','�','�'
		,'^','' ,'\\','t','u','v','w','x','y','z','�','�','�','�','�','�'
		};
define const global array char(1) eb_to_u 64 =
		{'{','A','B','C','D','E','F','G','H','I','' ,'' ,'' ,'' ,'' ,''
		,'}','J','K','L','M','N','O','P','Q','R','' ,'' ,'' ,'' ,'' ,''
		,'\\','0','S','T','U','V','W','X','Y','Z','' ,'' ,'' ,'' ,'' ,''
		,'0','1','2','3','4','5','6','7','8','9','' ,'' ,'' ,'' ,'' ,''
		};
define const int conv_opt = 2;
define const char repc = 'X';
/*
proc main;
	option 11 4;
	try;
		fp = fopen(%1,'rb');
		try;
			loop do
				a1 = felread1(fp,1,2);
				a = conv(a1,leng(a1));
				d1 = felread1(fp,4,3,0);
				d2 = felread1(fp,4,9,0);
				d3 = felread1(fp,4,3,0);
				d4 = felread1(fp,4,9,0);
				d5 = felread1(fp,4,3,0);
				d6 = felread1(fp,4,9,0);
				d7 = felread1(fp,4,11,0);
			//	print a d1 d2 d3 d4 d5 d6 d7;
				putline(edit('%2s %3d %9d %3d %9d %3d %9d %9d',a,d1,d2,d3,d4,d5,d6,d7));
			end do;
		finally
			fclose(fp);
		end try;
	catch;
		print ERROR ERRMSG;
	end try;
	return ERROR;
end proc;
*/
function conv (buf,len);
	ret='';
//	for (i=1;i<=len;i++) do
	i = 1;
	loop len;
		uf = substrb(buf,i,1);
//print edit('%02x',asc(uf));
//print /x uf;
		if ((iuf=asc(uf)) < 0x40) then ut = '';
		elseif (iuf < 0xc0) then
			ut = ei_to_u[iuf-0x40];
//print ut /x ut;
		//	ut = STR_CONV(ut,0,2);	// UTF-8�ɕϊ�����Ă���̂ŕs�v
		else ut = eb_to_u[iuf-0xc0];
		end if;
		if (!ut) then
			if (conv_opt) then
				ut = uf;
				if (conv_opt == 2) then ut = repc; endif;
			else return i+1;endif;
		end if;
//print /x ut;
//print edit('%02x',asc(ut));
		ret &+= ut;
		i++;
//	end do;
	end loop;
//print /x ret;
	return ret;
end func;

function conv_zone (buf,len);
	ret='';
//	for (i=1;i<=len;i++) do
	i = 1;
	loop len;
		wt = substrb(buf,i,1) to 'X';
//print wt;
		sg = substrb(wt,1,1) to 'u';
		ut = substrb(wt,2,1);
		if (sg == 'C') then
			ut &= '+';
		elseif (sg == 'D') then
			ut &= '-';
		elseif (sg == 'F') then
		else
			ut = repc;
		end if;
		ret &+= ut;
		i++;
//	end do;
	end loop;
	return ret;
end func;

proc pconv(x,a,len);
	x[0] = conv(a,len);
	return 0;
end proc;
