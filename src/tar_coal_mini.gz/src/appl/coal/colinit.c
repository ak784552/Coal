static char sccsid[]="%Z% %M% %I% %E% %U%";
/**************************************************/
/*                                                */
/*                   col_mn_init                  */
/*------------------------------------------------*/
/*                                                */
/*                 CLPRTBL�̏�����                */
/*------------------------------------------------*/
/*                                                */
/**************************************************/
/*  */

#include "colmn.h"

extern tdtLruScrHead *tpLruScrHeadImp;
extern tdtLruScrHead *tpLruScrHead;

extern CLPRTBL GLprocTable,*pGLprocTable;
extern ScrPrCT GScript,*pGScript;
/* extern VarTBL  GVarTBL,*pGVarTbl;	*/

extern CLPRTBL CLprocTable,*pCLprocTable;
extern GlobalCt GlobTable,*pGlobTable;
extern CLCOMMON CLcommon;
extern condList CLcList;		/* ��񃊃X�g */
extern condList *pCLcList;		/* ��񃊃X�g */
extern cmdInfo CLcmd;
extern tableRoot CLtbl;			/* ��͂���^�O�y�ѕ������i�[�����̈�*/
extern CLNCB CLSTCB;			/* �^�O�̍\����͂��s�����߂̗̈� */
extern MCAT CLMcat[];
extern int giOptions[];
extern tdtIterate_ctl gtIter_ctl[];
extern M_FILE *stdios[];
extern M_FILE *m_stdin,*m_stdout,*m_stderr;
extern GXObjectExpand CLobjExp;	/* add 20231203 */

int col_mn_init()
{
	int i,vlen,len,*pSize;
	tdtInfoParm ***pDummy;
	char *p,*env;

	pGLprocTable = &GLprocTable;
	pGScript = &GScript;
	memset(pGLprocTable,0,sizeof(CLPRTBL));
	memset(pGScript,0,sizeof(ScrPrCT));
	GLprocTable.PrCTp = pGScript;
	GLprocTable.CurScr = GLprocTable.PrCTp;
	GScript.pId = "";
#if 0
	pGVarTbl = &GVarTBL;
	memset(pGVarTbl,0,sizeof(VarTBL));
	GScript.Vary = pGVarTbl;
#endif
#if 1
/*
	if (!(pGVarTbl->pha_vnam=akxs_xhash_new(0,MAX_VAR_IY,0))) return -1;

	pSize = (int *)Malloc(cl_var_size_len(0)*4);
	if (!pSize) goto Err;

	len = sizeof(tdtInfoParm **)*(MAX_VAR_IX+1);
	pDummy = (tdtInfoParm ***)Malloc(len);
	if (!pDummy) goto Err;
	memset(pDummy,0,len);
	pGVarTbl->pTBL_vnam = pDummy;
	pGVarTbl->pTBL_vnam[0] = (tdtInfoParm **)pSize;
	cl_var_set_size(pSize,MAX_VAR_IX,MAX_VAR_IY,"VNA");
*/
	if (!(pGLprocTable->pha_vnam=akxs_xhash_new2(0,MAX_VAR_IY,0,sizeof(tdtInfoParm)))) goto Err;
/*
	len = sizeof(tdtInfoParm **)*(MAX_VAR_IX+1);
	if (!(pGLprocTable->pTBL_vnam=(tdtInfoParm ***)Malloc(len))) goto Err;
	memset(pGLprocTable->pTBL_vnam,0,len);
	if (!(pSize=(int *)Malloc(cl_var_size_len(0)))) goto Err;
	pGLprocTable->pTBL_vnam[0] = (tdtInfoParm **)pSize;
	cl_var_set_size(pSize,MAX_VAR_IX,MAX_VAR_IY,"GVN");
*/
#endif
#if 0	/* 2024.12.22 */
	if (!(pGLprocTable->imp_pha_vnam=akxs_xhash_new2(0,MAX_VAR_IY,0,sizeof(tdtInfoParm)))) goto Err;
#endif
#if 1	/* 2021.7.13 */
	pGLprocTable->pha_gid = akxs_xhasl_new(sizeof(long),20,19,0);
	pGLprocTable->myGid = ++pGLprocTable->gid;
	akxs_xhasl(pGLprocTable->pha_gid,'S',pGLprocTable->myGid,0);
#endif

	pCLprocTable = &CLprocTable;
	pGlobTable   = &GlobTable;
	memset(pCLprocTable,0,sizeof(CLPRTBL));
	memset(pGlobTable,0,sizeof(GlobalCt));
	memset(&CLcommon,0,sizeof(CLCOMMON));
	memset(&CLcList,0,sizeof(condList));
	memset(&CLcmd,0,sizeof(cmdInfo));
	memset(&CLSTCB,0,sizeof(CLNCB));
	memset(&CLtbl,0,sizeof(tableRoot));
	pCLprocTable->GlobCt = pGlobTable;
	CLcList.cmd    = &CLcmd;
	if (!(CLcList.cmd->prmp=(parmList **)Malloc(sizeof(parmList *)*PM_MAX))) {
	 	ERROROUT("Malloc CLcList_prmp");
		goto Err;
	}
	pCLcList = &CLcList;
	CLcList.clstcb = &CLSTCB;
	CLcList.cltbl  = &CLtbl;
	CLcList.max_prmnum = PM_MAX;
#if 0	/* 20231209 */
	CLcList.mcat_obj = &CLMcat[0];
	CLcList.mcat_da  = &CLMcat[1];
#endif
	CLcList.mcat     = &CLMcat[2];
	memset(CLcList.mcat,0,sizeof(MCAT));
	CLcList.mcat->mc_id[0] = 'M';
	CLcList.mcat->mc_id[1] = 'C';
	CLcList.mcat->mc_extlen = 512;
#if 1	/* 20231203 */
	CLobjExp.ms_obj = &CLMcat[0];
	CLobjExp.ms_da  = &CLMcat[1];
#endif
	cl_im_init_expand(&CLMcat[0],"BJ",sizeof(int),MAX_CMD_OBJ,D_OPT_ALC_MALLOC);
	cl_im_init_expand(&CLMcat[1],"DA",sizeof(char *),MAX_CMD_DA,D_OPT_ALC_MALLOC);
	cl_im_expand(&CLMcat[0],0,NULL);
	cl_im_expand(&CLMcat[1],0,NULL);
	mem_cpy_int(pGlobTable->options,giOptions,MAX_OPTIONS);
#if 1
	cl_mod_option(1,1);
	cl_mod_option(9,1);
	cl_mod_option(3,1);
#else
	if (giOptions[8] & 0x04) {
		CLcommon.Quot[0] = M_QUOTE2;
		CLcommon.Quot[1] = M_QUOTE1;
	}
	else  {
		CLcommon.Quot[0] = M_QUOTE1;
		CLcommon.Quot[1] = M_QUOTE2;
	}
#endif
	memset(gtIter_ctl,0,sizeof(tdtIterate_ctl)*2);
	stdios[0] = m_stdin;
	stdios[1] = m_stdout;
	stdios[2] = m_stderr;
	stdios[3] = NULL;

	env = getenv(D_ENV_NAM_SHELL);
	if (inistr(env,D_ENV_VAL_SHELL_CSH) > 0) {
		CLcommon.pSTDERR2STDOUT[0] = D_CSH_STDERR2STDOUT1;
		CLcommon.pSTDERR2STDOUT[1] = D_CSH_STDERR2STDOUT2;
	}
	else {
		CLcommon.pSTDERR2STDOUT[0] = D_BASH_STDERR2STDOUT1;
		CLcommon.pSTDERR2STDOUT[1] = D_BASH_STDERR2STDOUT2;
	}

	env = getenv(D_ENV_NAM_TERM);
/*
printf("col_mn_init: env=[%s]\n",env);
*/
	if (!strcmp(env,D_ENV_VAL_TERM_CYGWIN))
		CLcommon.Flags[0] = 1;
	else
		CLcommon.Flags[0] = 0;

	env = getenv(D_ENV_NAM_MACHTYPE);
/*
printf("col_mn_init: env=[%s]\n",env);
*/
	if (!strcmp(env,D_ENV_VAL_MACHTYPE_X86_32))
		CLcommon.Flags[1] = 1;
	else
		CLcommon.Flags[1] = 0;

	return 0;
 Err:
/*
	if (p=(char *)pGVarTbl->pTBL_vnam[0]) Free(p);
	if (p=(char *)pGVarTbl->pTBL_vnam) Free(p);
	if (p=(char *)pGVarTbl->pha_vnam) akxs_xhash_free(p);

	if (p=(char *)pGLprocTable->pTBL_vnam[0]) Free(p);
	if (p=(char *)pGLprocTable->pTBL_vnam) Free(p);
*/
	if (p=(char *)pGLprocTable->pha_vnam) akxs_xhash_free(p);
	return -1;
}
