#---------------------------------------------------------------
#
#			Configuration
#
#---------------------------------------------------------------
#OSDEPEND	= -qdbcs -DAIX
#OSDEPEND	= -DSUNOS 
#OSDEPEND	= -DSUNOS5
OSDEPEND	= -DLINUX -DWIN
#OSDEPEND	= -Y -DHPUX
