static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_in_mem_str.c libakx_no_iconv.a -o test_in_mem_str
*/
#include "akxcommon.h"
int main()
{
	int n,i,rc,ltar,lstr,code_type,opt;
	char buf[256],str[256];

	code_type = akxt_get_code_type();
for (;;) {
	printf("Enter opt: ");
	gets(buf);
	akxcgcvl(buf,strlen(buf),&opt);
	if (opt < 0) break;
/*	strcpy(buf,"abcあ和eホghijkウｱｼﾞXyZ");	*/
	strcpy(buf,"abcあ和eホghijkウｱｼXyZ");
	ltar = strlen(buf);
	printf("opt=%08x ltar=%d buf=[%s]\n",opt,ltar,buf);

	strcpy(str,"cあ");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_opt(buf,ltar,str,lstr,opt));

	strcpy(str,"ホgh");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_opt(buf,ltar,str,lstr,opt));

	strcpy(str,"Cあ");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_opt(buf,ltar,str,lstr,opt));
/*
	strcpy(str,"Ｃあ");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_opt(buf,ltar,str,lstr,opt));
*/
	strcpy(str,"ｱジx");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_opt(buf,ltar,str,lstr,opt));
/*
	strcpy(buf,"abcd和eホghijkｱｼXyZ");
	ltar = strlen(buf);
	printf("ltar=%d buf=[%s]\n",ltar,buf);
	strcpy(str,"abcあ和eホghijkウｱｼXyZ");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_opt(buf,ltar,str,lstr,opt));
*/
}
	exit(0);
}
