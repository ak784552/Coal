#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
main()
{
	int a[10];
	char *p,*pn;

	printf("sizeof(a[10])=%d\n",sizeof(a));
	printf("sizeof(ushort)=%d\n",sizeof(ushort));
	printf("sizeof(unsigned short)=%d\n",sizeof(unsigned short));
	printf("sizeof(int)=%d\n",sizeof(int));
	printf("sizeof(long)=%d\n",sizeof(long));
	printf("sizeof(float)=%d\n",sizeof(float));
	printf("sizeof(double)=%d\n",sizeof(double));

	pn = NULL;
	p = malloc(1);
	printf("a=%016lx p=%016lx pn=%016lx\n",a,p,pn);
}
