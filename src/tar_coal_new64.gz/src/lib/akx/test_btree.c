/*
	cc -DLINUX -O -I../include test_btree.c akxcom.a -o test_btree
*/
#include "akxcommon.h"

int main()
{
	HASHB *has;
	char  buf[128],key[128],data[128],cmd,*p;
	int   ret;

	has = akxsbtree_new(0,0,0);
	for (;;) {
		printf("Enter command(s/r/d/e) ==> ");
		gets(buf);
		switch (cmd=*buf) {
			case 's':
			case 'r':
			case 'd':
				printf("Enter key ==> ");
				gets(key);
				has->ha_key = key;
				if (cmd=='s') {
					printf("Enter data ==> ");
					gets(data);
					if (*data) has->ha_nextp = (int *)data;
					else has->ha_nextp = NULL;
					ret = _btree_proc('S',has);
					printf("S ret=%d\n",ret);
				}
				else if (cmd=='r') {
					ret = _btree_proc('R',has);
					printf("R ret=%d\n",ret);
					if (ret > 0) {
						if (!(p=(char *)has->ha_nextp)) p = "(null)";
						printf("  data=[%s]\n",p);
					}
				}
				else {
					ret = _btree_proc('D',has);
					printf("D ret=%d\n",ret);
				}
				break;
			case 'e':
				akxsbtree_free(has);
				exit(0);
		}
	}
}
