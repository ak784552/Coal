static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testelist.c akxcom.a -o testelist
*/
#include "akxcommon.h"
main()
{
	tdtRbCtl *pRbCtl;
	char c,buf[128],*p;
	int n,ret,cmd,opt;

	pRbCtl = akxs_elist_new(0,0);
	for(;;) {
		printf("Enter End/Set n/Get/srCh n/Read cmd:");
		gets(buf);
		if ((c=*buf) == 'E') break;
		else if (c == 'S') {
			n = atoi(buf+1);
			ret = akxs_elist_set(pRbCtl,n);
			printf("Set ret=%d n=%d\n",ret,n);
		}
		else if (c == 'G') {
			ret = akxs_elist_get(pRbCtl,&n);
			printf("Get ret=%d n=%d\n",ret,n);
		}
		else if (c == 'C') {
			n = atoi(buf+1);
			printf("Enter opt :");
			gets(buf);
			opt = atoi(buf);
			ret = akxs_elist_srch(pRbCtl,n,NULL,opt);
			printf("Srch ret=%d n=%d\n",ret,n);
		}
		else if (c == 'R') {
			cmd = atoi(buf+1);
			ret = akxs_elist_read(pRbCtl,cmd,&n);
			printf("Read ret=%d n=%d\n",ret,n);
		}
		sub1(pRbCtl); sub2(pRbCtl);
	}
	ret = akxs_elist_free(pRbCtl,0);
}

sub1(pCt)
tdtRbCtl *pCt;
{
	printf("pCt->rb_num = %d\n",pCt->rb_num);
	printf("pCt->rb_used = %d\n",pCt->rb_used);
	printf("pCt->rb_pos = %d\n",pCt->rb_pos);
	printf("pCt->rb_raddr = %08x\n",pCt->rb_raddr);
	printf("pCt->rb_waddr = %08x\n",pCt->rb_waddr);
	printf("pCt->rb_wpriv = %08x\n",pCt->rb_wpriv);
	printf("pCt->rb_cur   = %08x\n",pCt->rb_cur);
}

sub2(pCt)
tdtRbCtl *pCt;
{
	tdtRbChain *pr;

	pr = pCt->rb_raddr;
	while (pr) {
		printf("self = %08x, cpBuff = %08x, next = %08x\n",
		       pr,pr->rbc_buf,pr->rbc_next);
		pr = pr->rbc_next;
	}
}
