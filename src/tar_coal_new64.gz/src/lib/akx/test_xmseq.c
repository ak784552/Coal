static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include test_xmseq.c libakx_no_iconv.a -o test_xmseq
*/
#include <akxcommon.h>
int main()
{
	int n,i,a[20],rc,imax0,imax;
	char buf[256];
	MCAT2 *mcat2;

	for (;;) {
		printf("Enter xmseq.imax:");
		gets(buf);
		if (*buf == 'e') break;
		imax = atoi(buf);
		mcat2 = akxs_xmseq2_new(16,imax,4,NULL,NULL);
	}

	mem_set_int(a,0,4);
	for (i=0;i<80;i++) {
		mem_set_int(a,i+1,4);
		rc = akxs_xmseq_set(mcat2,0,a);
printf("rc=%d\n",rc);
		if (rc < 0) break;
	}
	for (i=0;i<140;i++) {
		mem_set_int(a,i+1,3);
		rc = akxs_xmseq_r2(mcat2,a,0);
printf("rc=%d a[0]=%d a[3]=%d\n",rc,a[0],a[3]);
		if (rc <= 0) break;
	}
	mem_set_int(a,100,4);
	rc = akxs_xmseq_set(mcat2,0,a);
printf("rc=%d\n",rc);
	a[3]=0;
	rc = akxs_xmseq_r2(mcat2,a,0);
printf("rc=%d a[0]=%d a[3]=%d\n",rc,a[0],a[3]);

	exit(0);
}
