static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include test_in_mem_chars.c libakx_no_iconv.a -o test_in_mem_chars
*/
#include <akxcommon.h>
int main()
{
	int n,i,rc,ltar,lstr,code_type,opt;
	char buf[256],str[20];

	code_type = akxt_get_code_type();
	printf("Enter opt: ");
	gets(buf);
	akxcgcvl(buf,strlen(buf),&opt);
	if (opt & 0x40) strcpy(buf,"eHCｂあｱｳ");
	else strcpy(buf,"abcあ和eホghijkウｱ");
	ltar = strlen(buf);
	printf("opt=%08x ltar=%d bud=[%s]\n",opt,ltar,buf);
/*
	for (;;) {
		printf("enter char :");
		gets(str);
		strcpy(str,"あ");
		if (!*str) break;
		lstr = strlen(str);
		printf("rc=%d\n",akxs_in_mem_type(buf,ltar,str,lstr,code_type));
	}
*/
	strcpy(str,"eHC");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_chars(buf,ltar,str,opt));

	if (opt & 0x40) {
		strcpy(buf,"ｂあｱｳ");
		ltar = strlen(buf);
		printf("ltar=%d bud=[%s]\n",ltar,buf);
	}
	strcpy(str,"ｂあ");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_chars(buf,ltar,str,opt));

	if (opt & 0x40) {
		strcpy(buf,"ｱｳABC");
		ltar = strlen(buf);
		printf("ltar=%d bud=[%s]\n",ltar,buf);
	}
	strcpy(str,"ｱｳ");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_chars(buf,ltar,str,opt));
	exit(0);
}
