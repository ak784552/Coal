static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************/
/*											*/
/*	  coded by A.Kobayashi 2010.05.10		*/
/*											*/
/********************************************/
#include "akxcommon.h"

/********************************************************/
/*														*/
/********************************************************/
int memicmp(sa,sb,len)
uchar *sa,*sb;
int len;
{
	uchar ca,cb;
	int i,dif;

	if (!sa || !sb) return -1;
	dif = 0;
	for (i=0;i<len;i++) {
		ca = *sa++;
		cb = *sb++;
		if (dif=akxcupper(ca)-akxcupper(cb)) break;
	}

	return dif;
}

/********************************************************/
/*	n_min<=0 �̂Ƃ��́Alen=n_max �̂Ƃ��ȊO�́A			*/
/*						��v���Ȃ��Ȃ�					*/
/*	n_max<0 or n_min>n_max �̂Ƃ��́A					*/
/*						�͈̓`�F�b�N���s��Ȃ�			*/
/*						mem[i]cmp(sa,sb,len)�Ɠ����ɂȂ�*/
/*	opt : 0x01 : �啶������������Ȃ�					*/
/********************************************************/
int memrngcmp_opt(sa,len,sb,n_min,n_max,opt)
uchar *sa,*sb;
int len,n_min,n_max,opt;
{
	int ret;

	if (!n_min) n_min = n_max;
	if (n_max>=0 && n_min<=n_max) {
		if (len < n_min) return -1;
		if (len > n_max) return 1;
	}
	if (opt & 0x01) ret = memicmp(sa,sb,len);
	else ret = memcmp(sa,sb,len);
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int memrngcmp(sa,len,sb,n_min,n_max)
uchar *sa,*sb;
int len,n_min,n_max;
{
	return memrngcmp_opt(sa,len,sb,n_min,n_max,0);
}

/********************************************************/
/*														*/
/********************************************************/
int memirngcmp(sa,len,sb,n_min,n_max)
uchar *sa,*sb;
int len,n_min,n_max;
{
	return  memrngcmp_opt(sa,len,sb,n_min,n_max,1);
}

/********************************************************/
/*														*/
/********************************************************/
int memncmp(sa,len,sb,n)
uchar *sa,*sb;
int len,n;
{
	return  memrngcmp_opt(sa,len,sb,0,n,0);
}

/********************************************************/
/*														*/
/********************************************************/
int memincmp(sa,len,sb,n)
uchar *sa,*sb;
int len,n;
{
	return  memrngcmp_opt(sa,len,sb,0,n,1);
}

/********************************************************/
/*														*/
/********************************************************/
int memrcpy(d0, s0, len0)
char *d0,*s0;
int len0;
{
	int i,len;
	char *d,*s;

	if (!d0) return -1;
	if ((len=len0)>0 && s0) {
		s = s0 + len -1;
		d = d0 + len -1;
		while (len-- > 0) *d-- = *s--;
	}
	return len0;
}

/********************************************************/
/*														*/
/********************************************************/
int memncpy(d, s, len, n)
char *d,*s;
int len,n;
{
	if (!d) return -1;
	if (n < len) len = n;
	if (len < 0) len = 0;
	if (len>0 && s) memcpy(d,s,len);
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int memzcpy(d, s, len)
char *d,*s;
int len;
{
	if (!d) return -1;
	if (len < 0) len = 0;
	if (len>0 && s) memcpy(d,s,len);
	*(d+len) = '\0';
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int memrzcpy(d, s, len)
char *d,*s;
int len;
{
	int rc;

	rc = memrcpy(d,s,len);
	if (len >= 0) *(d+len) = '\0';
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int memnzcpy(d, s, len, n)
char *d,*s;
int len,n;
{
	if (!d) return -1;
	n--;	/* 2021.8.22 n�͏I�[null�������܂ޒ��� */
	if (n < len) len = n;
	if (len < 0) len = 0;
	memzcpy(d,s,len);
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int memcat(d, s, len)
char *d,*s;
int len;
{
	if (!d) return -1;
	memzcpy(d+strlen(d),s,len);
	return len;
}

#if !defined(SUNOS5) && !defined(SUNOS) && !defined(LINUX)
/********************************************************/
/*														*/
/********************************************************/
int stricmp(sa,sb)
uchar *sa,*sb;
{
	uchar ca,cb;
	int d=0;

	if (!sa || !sb) return -1;
	for (;;) {
		ca = *sa++;
		cb = *sb++;
		if (!ca && !cb) break;
		if (d=akxcupper(ca)-akxcupper(cb)) break;
	}

	return d;
}
#endif

#if defined(SUNOS) || defined(AIX)
/********************************************************/
/*														*/
/********************************************************/
char *strerror(err)
int err;
{
	char *p;
	extern char *sys_errlist[];
	extern int  sys_nerr;

	if (err>=0 && err<sys_nerr) p = sys_errlist[err];
	else p = AKX_NULL_PRINT;
	return p;
}
#endif

/********************************************************/
/*	len: �I�[null���܂܂Ȃ�								*/
/********************************************************/
char *strnzcpy(d, s, len)
char *d,*s;
int len;
{
	if (!d || !s) return NULL;
	if (len < 0) len = 0;
	*(d+len) = '\0';
	return strncpy(d,s,len);
}

/********************************************************/
/* �@�\ : target����str�Ɉ�v����ʒu��Ԃ�				*/
/*		  (0x02�̂Ƃ��A�J�i���_�Ɣ����_���Ȃ�����)		*/
/* ���� : target  : �Ώە�����							*/
/*		  ltar	  : �Ώە����� (�o�C�g)				*/
/*		  str	  : ��v���镶����						*/
/*		  lstr	  : str�� (�o�C�g)						*/
/*		  occurs  : �J��Ԃ���	0�ȉ��́A1�ƌ��Ȃ�		*/
/*		  opt	  : �I�v�V����							*/
/*					0x01 : ignore case					*/
/*			0x20->	0x02 : �S�p���p�𖳎�����			*/
/*					0x08 : �擪�݂̂��r����			*/
/*			0x04->	0x10 : �ԋp�l�̒P�� 0/1:�o�C�g/����	*/
/*			0x02->	0x20 : reverse						*/
/*						   occurs�́C��������			*/
/*					0x40 : ���S�Ɉ�v���Ȃ��ʒu��Ԃ�	*/
/*			  0x7f000000 : �����R�[�h					*/
/* �ԋp : >=1 ��v�����ʒu�̐擪����̃o�C�g���܂���	*/
/*			  ������									*/
/********************************************************/
int akxs_ino_mem_opt_no_kanad(target,ltar,str,lstr,occurs,opt)
char *target,*str;
int  ltar,lstr,occurs,opt;
{
	char *pt,*ps,z1[5],*ptw,*psw,*ptt,*pt2,*ptt2;
	int  i,k,n,opt01,opt02,opt04,opt08,opt10,opt20,opt40,pos,unmatch,occur,rc,lena;
	int  m,optw,nn[3],mtar,mstr,len,kk,mm,opt_type,code_type,out_tar,out_str,byt,nn0,nn1,lent2;

	if ((pt=target) && (ps=str)) {
		if (!ltar || !lstr) return 0;
/*
printf("akxs_ino_mem_opt_no_kanad:Enter ltar=%d lstr=%d occurs=%d opt=%08x\n",ltar,lstr,occurs,opt);
*/
/*
printf("akxs_ino_mem_opt: pt=[%s]\n",pt);
*/
/*
printf("                 lstr=%d ps=[%s]\n",lstr,ps);
*/
		opt01 = opt & 0x01;	/* ignore case */
		opt02 = opt & 0x02;	/* ignore zenkaku hankaku */
		code_type = GET_TYPE_OPT(opt);
		if (!(code_type = GET_TYPE_OPT(opt))) code_type = akxt_get_code_type();

		/* target���S�Ĕ��p��0x02�̂Ƃ��ł��A�ϊ���̒�����lstr��菬������΁A��v���Ȃ� */
		if (opt02) {
			lena = ltar + ltar;
			if (code_type == CD_TYPE_UTF8) lena += ltar;
		}
		else lena = ltar;
		if (lena < lstr) return 0;

		opt08 = opt & 0x08;	/* compare top only */
		opt10 = opt & 0x10;	/* return moji position */
		opt20 = opt & 0x20;	/* reverse */
		opt40 = opt & 0x40;	/* compare except */
		optw = 0x04 | opt10 | opt40;
		opt_type = opt & CD_TYPE_OPT_MASK;
		optw |= opt_type;
		out_str = lstr;
		ptt = pt;
		ptw = psw = NULL;
		nn0 = nn1 = akxqm2len_type(pt,ltar,mstr,code_type);
		mtar = akxqmlen_type(pt,ltar,code_type);
		if (opt01 || opt02) {
			if (!(ptw = Malloc(lena+1))) return -1;
			if (opt02) {
				lena = lstr + lstr;
				if (code_type == CD_TYPE_UTF8) lena += lstr;
			}
			else lena = lstr;
			if (!(psw = Malloc(lena+1))) {
				Free(ptw);
				return -1;
			}
			if (opt02) {
				out_str = akxctozen_nn_type_opt(lstr,ps,psw,nn,code_type,0);
				mstr = nn[2];
/*
printf("akxs_ino_mem_opt_no_kanad: out_str=%d mstr=%d psw=[%s]\n",out_str,mstr,psw);
*/
				ps = psw;
				out_tar = akxctozenm_nn_type_opt(ltar,mstr,pt,ptw,nn,code_type,0);
/*
printf("akxs_ino_mem_opt_no_kanad: ptw=[%s] nn[0]=%d nn[1]=%d out_tar=%d\n",ptw,nn[0],nn[1],out_tar);
*/
				ptt = ptw;
				nn0 = nn[0];		/* �ϊ����o�C�g�� */
				nn1 = nn[1];		/* �ϊ���o�C�g�� */
				if (opt08 && (out_tar != out_str)) return 0;
			}
		}
		if (!opt02) {
			if (opt08 && (ltar != lstr)) return 0;
			mtar = akxqmlen_type(pt,ltar,code_type);
			mstr = akxqmlen_type(ps,lstr,code_type);
			out_str = lstr;
			nn0 = nn1 = akxqm2len(ptt,ltar,mstr);
/*
printf("akxs_ino_mem_opt_no_kanad: nn0=%d nn1=%d out_tar=%d\n",nn0,nn1,out_str);
*/
		}
		n = mtar - mstr + 1;
/*
printf("akxs_ino_mem_opt_no_kanad: mtar=%d mstr=%d n=%d nn0=%d nn1=%d\n",mtar,mstr,n,nn0,nn1);
*/
		if (n > 0) {
			if (opt01) {
				akxcuppern_type(ptw,ptt,nn1,code_type);
				ptt = ptw;
				akxcuppern_type(psw,ps,out_str,code_type);
/*
printf("akxs_ino_mem_opt_no_kanad:opt01 psw=[%s] ptw=[%s]\n",psw,ptw);
*/
				ps = psw;
			}
			pt2 = pt + nn0;		/* �ϊ��� */
			ptt2 = ptt + nn1;	/* �ϊ��� */
		/*	optw &= ~(opt01 | opt02);	*/
			lent2 = ltar - nn0;
			if (opt08 && n>1) n = 1;
/*
printf("akxs_ino_mem_opt_no_kanad: mtar=%d mstr=%d n=%d opt=%04x optw=%04x lent2=%d\n",mtar,mstr,n,opt,optw,lent2);
*/
			if (occurs <= 0) occurs = 1;
			len = ltar;
			i = 1;
		}
		rc = pos = occur = 0;
		for (k=1;k<=n;k++) {
/*
if (!(k % 1000)) printf("akxs_ino_mem_opt: k=%d i=%d kk=%d len=%d\n",k,i,kk,len);
*/
#if 1
			/* 2025.7.4 */
			unmatch = akxmbncmp_type_opt(ptt,len,ps,out_str,code_type,optw);
#else
			unmatch = akxmemcmp(ptt,ps,out_str);
#endif
/*
printf("akxs_ino_mem_opt_no_kanad: k=%d unmatch=%d\n",k,unmatch);
*/
			if (!unmatch) {
				occur++;
				if (opt10) {
					if (opt20) pos = k;	/* reverse */
					else if (occur >= occurs) {
						rc = k;
						break;
					}
				}
				else {
					if (opt20) pos = i;	/* reverse */
					else if (occur >= occurs) {
						rc = i;
						break;
					}
				}
			}
			mm = 1;
			m = akxqmbsnlen(code_type,pt,len);
/*
printf("akxs_ino_mem_opt: m=%d\n",m);
*/
			len -= m;
			i  += m;
			pt += m;
			/* 2025.7.4 */
			if (lent2>0 && (opt02 || opt01)) {
				if (opt02) {
					akxctozen1_type_opt(len,pt2,ptt2,nn,code_type,0);
					nn0 = nn[0];
					nn1 = nn[1];
					pt2 += nn0;
/*
printf("akxs_ino_mem_opt_no_kanad:pt2: k=%d nn[0]=%d nn[1]=%d\n",k,nn0,nn1);
*/
				}
				else {
					nn1 = nn0 = akxqmbsnlen(code_type,pt2,lent2);
					memzcpy(ptt2,pt2,nn0);
					pt2 += nn0;
				}
				if (opt01) {
					akxcuppern_type(ptt2,ptt2,nn0,code_type);
				}
				lent2 -= nn0;
/*
printf("akxs_ino_mem_opt_no_kanad: ptt2=[%s] lent2=%d\n",ptt2,lent2);
*/
				ptt2 += nn1;
/*
printf("akxs_ino_mem_opt_no_kanad: ptt=[%s]\n",ptt);
*/
				byt = akxqmbsnlen(code_type,ptt,len);
				ptt += byt;
/*
printf("akxs_ino_mem_opt_no_kanad:ptt: k=%d byt=%d\n",k,byt);
*/
			}
			else ptt = pt;
		}
		if (!rc) rc = pos;
	}
	else rc = -1;
/*
printf("akxs_ino_mem_opt_no_kanad:Exit k=%d rc=%d\n",k,rc);
*/
	if (ptw) Free(ptw);
	if (psw) Free(psw);
	return rc;
}

/********************************************************/
/* �@�\ : target����str�Ɉ�v����ʒu��Ԃ�				*/
/********************************************************/
int akxs_ino_mem_opt(target,ltar,str,lstr,occurs,opt)
char *target,*str;
int  ltar,lstr,occurs,opt;
{
	char *pt,*ps,z1[5],*ptw,*psw,*ptt,*pt2,*ptt2,*inba,*p;
	int  i,k,n,opt01,opt02,opt04,opt08,opt10,opt20,opt40,pos,unmatch,occur,rc,iDAKUTEN,iNO_DAKUTEN;
	int  m,optw,nn[3],mtar,mstr,len,kk,mm,opt_type,code_type,out_tar,out_str,lena;

	if ((pt=target) && (ps=str)) {
		if (!ltar || !lstr) return 0;
/*
printf("akxs_ino_mem_opt:Enter ltar=%d lstr=%d occurs=%d opt=%08x\n",ltar,lstr,occurs,opt);
*/
/*
printf("akxs_ino_mem_opt: pt=[%s]\n",pt);
*/
/*
printf("                 lstr=%d ps=[%s]\n",lstr,ps);
*/
		opt01 = opt & 0x01;	/* ignore case */
		opt02 = opt & 0x02;	/* ignore zenkaku hankaku */
		if (!(code_type = GET_TYPE_OPT(opt))) code_type = akxt_get_code_type();

		/* target���S�Ĕ��p��0x02�̂Ƃ��ł��A�ϊ���̒�����lstr��菬������΁A��v���Ȃ� */
		if (opt02) {
			if (!code_type) code_type = akxt_get_code_type();
			lena = ltar + ltar;
			if (code_type == CD_TYPE_UTF8) lena += ltar;
		}
		else lena = ltar;
		if (lena < lstr) return 0;

		iDAKUTEN = 0;
		/* 0x01��ltar>AKX_INSTR_IGNOR_MAX�A�܂��́A
		   0x02�ŃJ�i���_�Ɣ����_���Ȃ���΁A���������ω����Ȃ��p��
		   akxs_ino_mem_opt_no_kanad()���ĂԁB
		   0x01��ltar<=AKX_INSTR_IGNOR_MAX�A�܂��́A
		   0x02�ŃJ�i���_�Ɣ����_������΁A���̊֐��Ŏ��s����(�\�ߕϊ����Ă���) */
		if ((opt01 && ltar>AKX_INSTR_IGNOR_MAX) || opt02) {
			iNO_DAKUTEN = 1;
			if (opt02) {
				if (akxs_in_mem_chars(target,ltar,"��",0) > 0) iNO_DAKUTEN = 0;
			}
			if (iNO_DAKUTEN) return akxs_ino_mem_opt_no_kanad(target,ltar,str,lstr,occurs,opt);
		}
		opt08 = opt & 0x08;	/* compare top only */
		opt10 = opt & 0x10;	/* return moji position */
		opt20 = opt & 0x20;	/* reverse */
		opt40 = opt & 0x40;	/* compare except */
		optw = 0x04 | opt10 | opt40;
		opt_type = opt & CD_TYPE_OPT_MASK;
		optw |= opt_type;
		out_str = lstr;

		p = inba = ptw = psw = NULL;
		len = ltar;
		if (opt02 || opt01) {
			if (opt02) lena += ltar;
			if (!(p=Malloc(lena+1))) return -1;
			if (opt02) {
				inba = p;
				ptw = p + ltar;
			}
			else ptw = p;
			lena = lstr + lstr;
			if (code_type == CD_TYPE_UTF8) lena += lstr;
			if (!(psw=Malloc(lena+1))) {
				Free(inba);
				return -1;
			}
			if (opt02) {
				out_str = akxctozen_nn_type_opt(lstr,ps,psw,nn,code_type,0);
				mstr = nn[2];
/*
printf("akxs_ino_mem_opt: out_str=%d psw=[%s]\n",out_str,psw);
*/
				ps = psw;
				out_tar = akxctozen2_nn_type_opt(ltar,pt,ptw,inba,nn,code_type,0);
				mtar = nn[2];
/*
printf("akxs_ino_mem_opt: out_tar=%d ptw=[%s]\n",out_tar,ptw);
*/
				pt = ptw;
				if (opt08 && (out_tar != out_str)) return 0;
				len = out_tar;
			}
			if (opt01) {
				akxcuppern_type(ptw,pt,len,code_type);
				pt = ptw;
				akxcuppern_type(psw,ps,out_str,code_type);
/*
printf("akxs_ino_mem_opt:opt01 psw=[%s] ptw=[%s]\n",psw,ptw);
*/
				ps = psw;
			}
		}
		if (!opt02) {
			if (opt08 && (ltar != lstr)) return 0;
			mtar = akxqmlen_type(pt,ltar,code_type);
			mstr = akxqmlen_type(ps,lstr,code_type);
		}
		n = mtar - mstr + 1;
/*
printf("akxs_ino_mem_opt: mtar=%d mstr=%d n=%d\n",mtar,mstr,n);
*/
		if (opt08 && n>1) n = 1;
/*
printf("akxs_ino_mem_opt: n=%d opt=%04x optw=%04x\n",n,opt,optw);
*/
		if (occurs <= 0) occurs = 1;
		rc = pos = occur = 0;
		kk = i = 1;
		for (k=1;k<=n;k++) {
/*
if (!(k % 1000)) printf("akxs_ino_mem_opt: k=%d i=%d kk=%d len=%d\n",k,i,kk,len);
*/
#if 1
			unmatch = akxmbncmp_type_opt(pt,len,ps,out_str,code_type,optw);
#else
			unmatch = akxmemcmp(pt,ps,out_str);
#endif
/*
printf("akxs_ino_mem_opt: k=%d unmatch=%d\n",k,unmatch);
*/
			if (!unmatch) {
				occur++;
				if (opt10) {
					if (opt20) pos = kk;	/* reverse */
					else if (occur >= occurs) {
						rc = kk;
						break;
					}
				}
				else {
					if (opt20) pos = i;	/* reverse */
					else if (occur >= occurs) {
						rc = i;
						break;
					}
				}
			}
			mm = 1;
			m = akxqmbsnlen(code_type,pt,len);
			if (inba) {


				if (inba[k-1] < 0) {
					mm++;
/*
printf("akxs_ino_mem_opt: inba[k-1]=%d mm=%d\n",inba[k-1],mm);
*/				}
			}
			len -= m;
			i  += m;
			kk += mm;
			pt += m;
		}
		if (!rc) rc = pos;
	}
	else rc = -1;
/*
printf("akxs_ino_mem_opt:Exit k=%d rc=%d\n",k,rc);
*/
	if (p) Free(p);
	if (psw) Free(psw);
	return rc;
}

/********************************************************/
/*														*/
/********************************************************/
int akxs_in_mem_opt(target,ltar,str,lstr,opt)
char *target,*str;
int  ltar,lstr,opt;
{
	return akxs_ino_mem_opt(target,ltar,str,lstr,1,opt);
}

/********************************************************/
/* �@�\ : str���̂ǂꂩ�̕����Ɉ�v����ʒu��Ԃ�		*/
/*		  str���O���ŉ�								*/
/*					0x01 : ignore case					*/
/*					0x02 : �S�p���p�𖳎�����			*/
/*					0x10 : �ԋp�l�̒P�� 0/1:�o�C�g/����	*/
/*					0x20 : reverse						*/
/*					0x40 : �ǂ�ł��Ȃ��ʒu��Ԃ�		*/
/*					0x80 : str������ŉ�				*/
/*			  0x7f000000 : code_type					*/
/********************************************************/
int akxs_in_mem_chars_outer(target,ltar,str,opt)
char *target,*str;
int  ltar,opt;
{
/* opt=0x02�𐶂�������akxs_in_mem_opt()���g�� */
	char w[5],*p;
	int lstr,m,code_type,pos,mpos,opt20,rpos,rmpos,ret,optw;
/*
printf("akxs_in_mem_chars:Enter ltar=%d opt=%08x str=[%s]\n",ltar,opt,str);
*/
	if (!target || !str) return -1;
#if 1	/* 2025.6.30 */
	if (opt & (0x40 | 0x80)) {
		opt &= ~0x80;
		return akxs_in_mem_chars(target,ltar,str,opt);
	}
#endif
/*	pos  = mpos  = 1;	*/
	rpos = rmpos = 0;
	code_type = GET_TYPE_OPT(opt);
	optw = opt & ~CD_TYPE_OPT_MASK;
	opt20 = opt & 0x20;
	opt = opt & (0x01 | 0x02 | 0x10 | 0x20);
	p = str;
	lstr = strlen(str);
	while (lstr > 0) {
		m = akxqmbsnlen(code_type,p,lstr);
/*
printf("akxs_in_mem_chars: m=%d\n",m);
*/
		memzcpy(w,p,m);
			if (ret = akxs_in_mem_opt(target,ltar,w,m,opt)) {
				rpos = ret;
			/*	rpos = pos;
				rmpos = mpos ;	*/
				if (!opt20) break;
			}
		lstr -= m;
		p += m;
		pos += m;
		mpos++;
/*
printf("akxs_in_mem_chars: lstr=%d\n",lstr);
*/
	}
/*	if (opt & 0x10) rpos = rmpos;	*/
/*
printf("akxs_in_mem_chars:Exit rpos=%d\n",rpos);
*/
	return rpos;
}
/********************************************************/
/*														*/
/********************************************************/
int akxs_ino_str_opt(target,str,occurs,opt)
char *target,*str;
int occurs,opt;
{
	char *pt,*ps;

	if ((pt=target) && (ps=str))
		return akxs_ino_mem_opt(pt,strlen(pt),ps,strlen(ps),occurs,opt);
	else
		return -1;
}

/********************************************************/
/*														*/
/********************************************************/
int akxs_in_str_opt(target,str,opt)
char *target,*str;
int opt;
{
	return akxs_ino_str_opt(target,str,1,opt);
}

/********************************************************/
/*														*/
/********************************************************/
int instr(target,str)
char *target,*str;
{
	return akxs_in_str_opt(target,str,0);
}

/********************************************************/
/*														*/
/********************************************************/
int inistr(target,str)
char *target,*str;
{
	return akxs_in_str_opt(target,str,1);
}

/********************************************************/
/*														*/
/********************************************************/
char *stristr(target,str)
char *target,*str;
{
	int i;

	if ((i=akxs_in_str_opt(target,str,1)) > 0) return target+i-1;
	return NULL;
}

/********************************************************/
/*														*/
/********************************************************/
int inmemstr(target,lt,str)
char *target,*str;
int lt;
{
	if (str)
		return akxs_in_mem_opt(target,lt,str,strlen(str),0);
	else
		return -1;
}

/********************************************************/
/*														*/
/********************************************************/
int instrchar_opt(target,c,opt)
char *target,c;
int opt;
{
	char str[2];
	int pos;

	if (!target) pos = -1;
	else if (*target && c) {
		str[0] = c;
		str[1] = '\0';
		pos = akxs_in_str_opt(target,str,opt & 0x01);
	}
	else pos = 0;
	return pos;
}

/********************************************************/
/*														*/
/********************************************************/
int instrchar(target,c)
char *target,c;
{
	return instrchar_opt(target,c,0);
}

/********************************************************/
/*														*/
/********************************************************/
int instrichar(target,c)
char *target,c;
{
	return instrchar_opt(target,c,1);
}

/********************************************************/
/*														*/
/********************************************************/
int inmemchar(buf,len,c)
char *buf,c;
int  len;
{
	char str[2];

	str[0] = c;
	str[1] = '\0';

	return akxs_in_mem_chars(buf,len,str,0);
}

/********************************************************/
/*														*/
/********************************************************/
int inmemchars(buf,len,ptn)
char *buf,*ptn;
int  len;
{
#if 1
	return akxs_in_mem_chars(buf,len,ptn,0);
#else
	int pos;

	pos = akx_skip_opt(buf,len,ptn,0x08) + 1;
	if (pos > len) pos = 0;
	return pos;
#endif
}

/********************************************************/
/*														*/
/********************************************************/
int inmemichars(buf,len,ptn)
char *buf,*ptn;
int  len;
{
#if 1
	return akxs_in_mem_chars(buf,len,ptn,0x01);
#else
	int pos;

	pos = akx_skip_opt(buf,len,ptn,0x01 | 0x08) + 1;
	if (pos > len) pos = 0;
	return pos;
#endif
}

/********************************************************/
/*														*/
/********************************************************/
int instrchars(buf,ptn)
char *buf,*ptn;
{
	return inmemchars(buf,strlen(buf),ptn);
}

/********************************************************/
/*														*/
/********************************************************/
int instrichars(buf,ptn)
char *buf,*ptn;
{
	return inmemichars(buf,strlen(buf),ptn);
}

/********************************************************/
/* �@�\ : str���̂ǂꂩ�̕����Ɉ�v����ʒu��Ԃ�		*/
/*		  str������ŉ�								*/
/*					0x01 : ignore case					*/
/*					0x02 : �S�p���p�𖳎�����			*/
/*					0x10 : �ԋp�l�̒P�� 0/1:�o�C�g/����	*/
/*					0x20 : reverse						*/
/*					0x40 : �ǂ�ł��Ȃ��ʒu��Ԃ�		*/
/*					0x80 : str���O���ŉ�				*/
/*			  0x7f000000 : code_type					*/
/********************************************************/
int akxs_in_mem_chars(target,ltar,str,opt)
char *target,*str;
int  ltar,opt;
{
	char *pt,*ps,z1[5],*pp,*u2,u1[5],*psa,*ptp;
	int  i,k,n,opt01,opt02,opt08,opt10,opt20,pos,unmatch,opt40,len2,rc,ret,lstr;
	int  m,nn[3],mtar,mstr,len,kk,mm,opt_type,code_type,out_tar,out_str,m2,byt1;

	if ((pt=target) && (ps=str)) {
		lstr = strlen(str);
		if (!ltar || !lstr) return 0;
/*
printf("akxs_in_mem_chars_inner:Enter ltar=%d lstr=%d opt=%08x\n",ltar,lstr,opt);
printf("akxs_in_mem_chars_inner: pt=[%s]\n",pt);
printf("                    ps=[%s]\n",ps);
*/
		opt01 = opt & 0x01;	/* ignore case */
		opt02 = opt & 0x02;	/* ignore zenkaku hankaku */
		opt08 = opt & 0x08;	/* compare top only */
		opt10 = opt & 0x10;	/* return moji position */
		opt20 = opt & 0x20;	/* reverse */
		opt40 = opt & 0x40;	/* �ǂ�ł��Ȃ��ʒu��Ԃ� */
#if 1	/* 2025.7.4 */
		if (!opt40 && (opt & 0x80)) {
			opt &= ~0x80;
			return akxs_in_mem_chars_outer(target,ltar,str,opt);
		}
#endif
		opt_type = opt & CD_TYPE_OPT_MASK;
		code_type = GET_TYPE_OPT(opt);
		psa = u2 = NULL;
		out_tar = ltar;
		out_str = lstr;
		if (opt02) {
			out_tar = akxctozen_nn_type_opt(ltar,pt,0,nn,code_type,0);
			mtar = nn[2];
			if (!(psa=Malloc(lstr*3+1))) return -1;
			ps = psa;
			out_str = akxctozen_nn_type_opt(lstr,str,ps,nn,code_type,0);
			if (opt08 && (out_tar != out_str)) {
				Free(psa);
				return 0;
			}
			mstr = nn[2];
/*
printf("akxs_in_mem_chars_inner: mstr=%d out_str=%d ps=[%s]\n",mstr,out_str,ps);
*/
		}
		else {
			if (opt08 && (ltar != lstr)) return 0;
			mtar = akxqmlen_type(pt,ltar,code_type);
			mstr = akxqmlen_type(ps,lstr,code_type);
		}
		if (opt01) {
			if (!(u2=Malloc(out_str+1))) {
				Free(psa);
				return 0;
			}
			akxcuppern(u2,ps,out_str);
			ps = u2;
/*
printf("akxs_in_mem_chars_inner: mstr=%d ps=[%s]\n",mstr,ps);
*/
		}
	/*	n = mtar - mstr + 1;	2025.10.31 */
		n = mtar;
		if (opt08 && n>1) n = 1;
/*
printf("akxs_in_mem_chars_inner: mtar=%d mstr=%d n=%d opt=%04x\n",mtar,mstr,n,opt);
*/
		rc = pos = 0;
		len = ltar;
		i = kk = 1;
		for (k=1;k<=n;k++) {
/*
if (!(k % 1000)) printf("akxs_in_mem_opt: k=%d i=%d kk=%d len=%d\n",k,i,kk,len);
*/
			mm = m = 1;
			ptp = pt;
			if (opt02) {
				byt1 = akxctozen1_type_opt(len,pt,z1,nn,code_type,0);
				m = nn[0];
				mm = nn[2];
				ptp = z1;
/*
printf("akxs_in_mem_chars_inner:opt20: m=%d mm=%d byt1=%d ptp=[%s]\n",m,mm,byt1,ptp);
*/
			}
			else {
				m = byt1 = akxqmbsnlen(code_type,ptp,len);
				memzcpy(z1,ptp,m);
/*
printf("akxs_in_mem_chars_inner: m=%d pt=[%s]\n",m,z1);
*/
			}
			if (opt01) {
				akxcuppern(u1,ptp,byt1);
				ptp = u1;
/*
printf("akxs_in_mem_chars_inner:upper ptp=[%s]\n",ptp);
*/
			}
			len2 = out_str;
			if (opt40) unmatch = 0;
			else unmatch = 1;
			pp = ps;
			while (len2 > 0) {
				m2 = akxqmbsnlen(code_type,pp,len2);
				ret = akxmemcmplen(ptp,byt1,pp,m2,0);
/*
printf("akxs_in_mem_chars_inner: pp=[%s] m2=%d ret=%d len2=%d\n",pp,m2,ret,len2);
*/
				if (!ret) {
					if (opt40) unmatch = 1;
					else unmatch = 0;
					break;
				}
				pp += m2;
				len2 -= m2;
			}
			if (!unmatch) {
				if (opt10) {
					if (opt20) pos = kk;	/* reverse */
					else {
						rc = kk;
						break;
					}
				}
				else {
					if (opt20) pos = i;	/* reverse */
					else {
						rc = i;
						break;
					}
				}
			}
			len -= m;
			kk += mm;
			i  += m;
			pt += m;
		}
		if (!rc) rc = pos;
	}
	else rc = -1;
/*
printf("akxs_in_mem_chars_inner:Exit k=%d rc=%d\n",k,rc);
*/
	if (psa) Free(psa);
	if (u2) Free(u2);
	return rc;
}

/********************************************************/
/*														*/
/********************************************************/
UINT4 akxcmb2ul(s,len)
uchar *s;
int  len;	/* >=1, <=4 */
{
	uchar *p=s;
	int n=len;
	UINT4 ul;

#if 1
	if (n <= 0) ul = 0;
	else {
		ul = *p++;
		if (n == 2) ul = ul<<8 | *p;
		else if (n == 3) ul = (ul<<8 | *p)<<8 | *(p+1);
		else if (n == 1) ;
		else ul = ((ul<<8 | *p)<<8 | *(p+1))<<8 | *(p+2);
	}
#else	/* ���[�v�̕����x�� */
	ul = 0;
	while (n-- > 0) {
		ul = ul<<8 | *p++;
	}
#endif
	return ul;
}

/********************************************************/
/*														*/
/********************************************************/
int akxcul2mb(s,ul)
uchar *s;
UINT4 ul;
{
	uchar *p=s,uc;
	int i,len;

	if (!s) return -1;
	len = 0;
	p = s + 4;
	for (i=0;i<4;i++) {
		uc = ul & 0x000000ff;
		if (uc) {
			*(--p) = uc;
			len++;
		}
		ul >>= 8;
	}
	if (len < 4) memcpy(s,p,len);
	*(s+len) = '\0';
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int akxmbcmp(s1,m1,s2,m2)
uchar *s1,*s2;
int m1,m2;
{
	return akxcmb2ul(s1,m1) - akxcmb2ul(s2,m2);
}

/********1*********2*********3*********4*********5*********6*********/
/*	�@�\ : ������ƕ�������r����									*/
/*	���� :	pstr1,nstr1,mj1,pstr2,nstr2,mj2							*/
/*			type  : �����R�[�h										*/
/*			opt   : 0x01 : ignore case								*/
/*					0x02 : ignore zenkaku hankaku					*/
/*					0x04 : �O����v(pstr2��pstr1�̑O���Ɉ�v���邩)	*/
/*					0x10 : ���g�p									*/
/*					0x20 : ���g�p									*/
/*					0x40 : compare except(�S�Ă���v���Ȃ��Ƃ��^)	*/
/*					0x80 : '\0'�������ƌ��Ȃ�						*/
/*				  0x0100 : �ǂ��炩�Z�����̑O����v					*/
/*	�ԋp :	> 0 : ��ꍀ > ���									*/
/*			= 0 : ��ꍀ = ���									*/
/*			< 0 : ��ꍀ < ���									*/
/********************************************************************/
int akxmbncmp_type_opt_m(pstr1,nstr1,mj1,pstr2,nstr2,mj2,type,opt)
uchar *pstr1,*pstr2;
int nstr1,mj1,nstr2,mj2,type,opt;
{
	uchar *s1,*s2,c1,c2;
	int len1,len2,m1,m2,opt01,opt02,opt04,opt10,dif,opt40,d,opt80,opt100;
	uchar u1[5],u2[5],z1[5],z2[5],uc,*p1,*p2;
	int n1,n2,nn[3];

	if (!(s1=pstr1) || !(s2=pstr2)) return -1;
/*
printtx("akxmbncmp_opt_m",pstr1,nstr1);
printtx("               ",pstr2,nstr2);
printf("               : type=%d opt=%04x mj1=%d mj2=%d\n",type,opt,mj1,mj2);
*/
	if (type <= 0) type = akxt_get_code_type();
	opt01 = opt & 0x01;	/* ignore case */
	opt02 = opt & 0x02;	/* ignore zenkaku hankaku */
	opt04 = opt & 0x04;	/* �O����v 0x04 <- 0x08 *//* pstr2��pstr1�̑O���Ɉ�v���邩 */
	opt40 = opt & 0x40;	/* compare except */
	opt80 = opt & 0x80;	/* '\0'�������ƌ��Ȃ� */
	opt100 = opt & 0x100;
	len1 = nstr1;
	len2 = nstr2;
	if (!len1 || !len2) {
		if (!len1 && !len2) dif = 0;
		else if (!len1) dif = -1;
		else if (!len2) dif =  1;
		if (opt40) {
			if (dif) dif = 0;
			else dif = 1;
		}
		return dif;
	}
#if 1	/* 2023.3.31 */
	if (opt04) {
#if 1	/* 2025.6.27 */
		if (opt02) {
			if (mj1 > 0) m1 = mj1;
			else {
				akxctozen_nn_type_opt(nstr1,pstr1,0,nn,type,0);
				m1 = nn[2];
			}
			if (mj2 > 0) m2 = mj2;
			else {
				akxctozen_nn_type_opt(nstr2,pstr2,0,nn,type,0);
				m2 = nn[2];
			}
			if (m1 < m2) return -1;
		}
		else {
			if (len1 < len2) return -1;
		}
#else
		m1 = akxqmlen_type(pstr1,nstr1,type);
		m2 = akxqmlen_type(pstr2,nstr2,type);
		if (m1 < m2) return -1;
#endif
	}
#endif
	dif = 0;
	if (opt02) {
		nstr1 = nstr2 = 0;
	}
/*	for (;;) {	*/
#if 1	/* 2025.6.27 */
	while (len1>0 && len2>0) {
#else
	while (len1>0 || len2>0) {
#endif
		c1 = c2 = '\0';
		if (len1 > 0) c1 = *s1;
		if (len2 > 0) c2 = *s2;
		if (!opt80) {
			if (!c1) len1 = 0;
			if (!c2) len2 = 0;
		}
		m1 = m2 = 1;
	/*	if (len1 >= 2) m1 = akxqkanjilen(s1);
		if (len2 >= 2) m2 = akxqkanjilen(s2);	*/
		if (len1 >= 2) m1 = akxqmbsnlen(type,s1,len1);
		if (len2 >= 2) m2 = akxqmbsnlen(type,s2,len2);
/*
printf("akxmbncmp_opt_m: m1=%d m2=%d\n",m1,m2);
*/
		if (m1==1 && m2==1) {
			if (opt01) {
				c1 = akxcupper(c1);
				c2 = akxcupper(c2);
			}
/*
printf("akxmbncmp_opt_m: c1=[%c] c2=[%c]\n",c1,c2);
*/
#if 1
			d = c1 - c2;
			if (opt40) {
				if (!d) {
					dif = 1;
					break;
				}
			}
			else if (dif=d) break;
#else
			if (dif=c1-c2) break;
#endif
			len1--;
			len2--;
			s1++;
			s2++;
		}
		else {
			n1 =m1;
			n2 =m2;
			if (opt02) {
				p1 = s1;
				p2 = s2;
				if (m1==1 || type==CD_TYPE_UTF8) {
					m1 = akxctozen1_type_opt(len1,s1,z1,nn,type,0);
					n1 = nn[0];
					p1 = z1;
/*
printtx("akxmbncmp_opt_m: zen1:1",p1,m1);
*/
				}
				if (m2==1 || type==CD_TYPE_UTF8) {
					m2 = akxctozen1_type_opt(len2,s2,z2,nn,type,0);
					n2 = nn[0];
					p2 = z2;
/*
printtx("akxmbncmp_opt_m: zen1:2",p2,m2);
*/
				}
				nstr1 += m1;
				nstr2 += m2;
#if 0	/* 2025.7.1 */
				if (opt & 0x01) {
					akxcuplw(u1,z1,0);
					akxcuplw(u2,z2,0);
					p1 = u1;
					p2 = u2;
/*
printtx("akxmbncmp_opt_m:up:1",p1,m1);
printtx("               :up:2",p2,m2);
*/
				}
#endif
			}
			else {
				if (m1 > len1) m1 = len1;
				if (m2 > len2) m2 = len2;
				p1 = s1;
				p2 = s2;
			}
/*
printf("akxmbncmp_opt_m: p1=[%s] m1=%d p2=[%s] m2=%d\n",p1,m1,p2,m2);
*/
#if 1	/* 2025.7.1 */
			if (opt01) {
				akxcuplw(u1,p1,0);
				akxcuplw(u2,p2,0);
				p1 = u1;
				p2 = u2;
/*
printf("akxmbncmp_opt_m: p1=[%s] p2=[%s]\n",p1,p2);
*/
			}
#endif
#if 1
			d = akxmbcmp(p1,m1,p2,m2);
			if (opt40) {
				if (!d) {
					dif = 1;
					break;
				}
			}
			else if (dif=d) break;
#else
			if (dif=akxmbcmp(p1,m1,p2,m2)) break;
#endif
/*
printf("akxmbncmp_opt_m: n1=%d n2=%d\n",n1,n2);
*/
			s1 += n1;
			s2 += n2;
			len1 -= n1;
			len2 -= n2;
/*
printf("akxmbncmp_opt_m: len1=%d len2=%d\n",len1,len2);
*/
		}
#if 0	/* 2025.6.27 */
#if 1	/* 2023.3.31 */
		if (opt100 && (len1<=0 || len2<=0)) break;
		if (opt04 && len2<=0) break;
#else
		if (opt04 && (len1<=0 || len2<=0)) break;
#endif
#endif
	}
/*
printf("akxmbncmp_opt_m: dif=%d\n",dif);
*/
#if 0	/* 2023.3.31 */
	if (dif && opt04) {
		if (len1<nstr1 || len2 < nstr2) dif = 0;
	}
#endif
#if 1	/* 2025.6.30 */
	if (!opt100 && !dif) {
		if (opt02) {
			/* ��r���Ă��Ȃ����������� */
			nstr1 += len1;
			nstr2 += len2;
		}
		/* compare except�̂Ƃ��́Adif�̐����ɈӖ��͂Ȃ����A�ȉ��̂悤�ɒ�`���� */
		if (opt04) {
			if (nstr1 < nstr2) dif = -1;
		}
		else {
			if (nstr1 > nstr2) dif = 1;
			else if (nstr1 < nstr2) dif = -1;
		}
	}
#endif
/*
printf("akxmbncmp_opt_m: len1=%d len2=%d dif=%d\n",len1,len2,dif);
*/
	return dif;
}

/********************************************************/
/*														*/
/********************************************************/
int akxmbncmp_type_opt(pstr1,nstr1,pstr2,nstr2,type,opt)
uchar *pstr1,*pstr2;
int nstr1,nstr2,type,opt;
{
	return akxmbncmp_type_opt_m(pstr1,nstr1,0,pstr2,nstr2,0,type,opt);
}

/********************************************************/
/*	������ƕ�������r����							*/
/********************************************************/
int akxmbncmp_opt(pstr1,nstr1,pstr2,nstr2,opt)
uchar *pstr1,*pstr2;
int nstr1,nstr2,opt;
{
	akxmbncmp_type_opt(pstr1,nstr1,pstr2,nstr2,akxt_get_code_type(),opt);
}

/********************************************************/
/*														*/
/********************************************************/
int akxstrcmp(s1,s2)
uchar *s1,*s2;
{
	return akxmbncmp_opt(s1,strlen(s1),s2,strlen(s2),0);
}

/********************************************************/
/*														*/
/********************************************************/
int akxstricmp(s1,s2)
uchar *s1,*s2;
{
	return akxmbncmp_opt(s1,strlen(s1),s2,strlen(s2),0x01);
}

/********************************************************/
/*														*/
/********************************************************/
int akxmemcmp(s1,s2,len)
uchar *s1,*s2;
int len;
{
	if (len <= 0) return 0;
	else return akxmbncmp_opt(s1,len,s2,len,0x10);
}

/********************************************************/
/*														*/
/********************************************************/
int akxmemicmp(s1,s2,len)
uchar *s1,*s2;
int len;
{
	if (len <= 0) return 0;
	else return akxmbncmp_opt(s1,len,s2,len,0x11);
}

/********************************************************/
/*														*/
/********************************************************/
int akxmemcmp2(s1,len1,s2,len2)
char *s1,*s2;
int  len1,len2;
{
/*
if (*s2=='%') {
int ret;
printf("len1=%d s1=[%s] len2=%d s2=[%s]\n",len1,s1,len2,s2);
	ret = akxmbncmp_opt(s1,len1,s2,len2,0x10);
printf("ret=%d\n",ret);
	return ret;
}
else
*/
	return akxmbncmp_opt(s1,len1,s2,len2,0x10);
}

/********************************************************/
/*														*/
/********************************************************/
int akxmemicmp2(s1,len1,s2,len2)
char *s1,*s2;
int  len1,len2;
{
	return akxmbncmp_opt(s1,len1,s2,len2,0x11);
}

/****************************************/
/*	opt : 0x0001 : ignore case			*/
/*	      0x4000 : comp string			*/
/****************************************/
int akxmemcmplen(p1,len1,p2,len2,opt)
char *p1,*p2;
int  len1,len2,opt;
{
	int result;

	if (opt & 0x4000)
		return akxmbncmp_opt(p1,len1,p2,len2,opt & ~0x4000);
	else if (!len1 && !len2) result = 0;
	else if (opt & 0x01) {
		if(len1 < len2) {
			if (!(result = memicmp(p1,p2,len1))) result = -1;
		}
		else if(len1 > len2) {
			if (!(result = memicmp(p1,p2,len2))) result = 1;
		}
		else
			result = memicmp(p1,p2,len1);
	}
	else if(len1 < len2) {
		if (!(result = memcmp(p1,p2,len1))) result = -1;
	}
	else if(len1 > len2) {
		if (!(result = memcmp(p1,p2,len2))) result = 1;
	}
	else
		result = memcmp(p1,p2,len1);
	return result;
}

/********************************************************/
/*														*/
/********************************************************/
int akxstrcmp2(s1,len1,s2,len2)
char *s1,*s2;
int  len1,len2;
{
	return akxmbncmp_opt(s1,len1,s2,len2,0);
}

/********************************************************/
/*														*/
/********************************************************/
int akxstricmp2(s1,len1,s2,len2)
char *s1,*s2;
int  len1,len2;
{
	return akxmbncmp_opt(s1,len1,s2,len2,0x01);
}

/********************************************************/
/*	������(pm1,len)����1����(pm2)������ʒu��Ԃ�		*/
/********************************************************/
int akx_mem_chr_opt(pm1,pm2,len,opt)
uchar *pm1,*pm2;
int len,opt;
{
	uchar *s1,*s2,c1,c2;
	int pos,opt01,n,m1,m2,dif,code_type;

	if (!(s1=pm1) || !(s2=pm2)) return -1;
	opt01 = opt & 0x01;	/* ignore case */
	code_type = GET_TYPE_OPT(opt);
/*	if (!(m2=akxqiskanji(s2))) {	*/
	if (!(m2=akxqismbs(code_type,s2))) {
		c2 = *s2;
		 if (opt01) c2 = akxcupper(c2);
	}
	pos=0;
	n = len;
	while (n > 0) {
	/*	if (n >= 2) m1=akxqiskanji(s1);	*/
		if (n >= 2) m1=akxqismbs(code_type,s1);
		else m1=0;
		if (m1 && m2) {
			if (m1==m2 && n>=m1) {
				if (!memcmp(s1,s2,m1)) {
					pos=len-n+1;
					break;
				}
			}
		}
		else if (m1==m2) {
			c1 = *s1;
			if (opt01) dif=akxcupper(c1)-c2;
			else dif=c1-c2;
			if (!dif) {
				pos=len-n+1;
				break;
			}
		}
		if (m1) {
			s1+=m1;
			n -=m1;
		}
		else {
			s1++;
			n--;
		}
	}

	return pos;
}

/********************************************************/
/* �@�\ : buf����ptn�̂ǂꂩ�̕����Ɉ�v����ʒu��Ԃ�	*/
/* ���� : buf	  : �Ώە�����							*/
/*		  len	  : �Ώە����� (�o�C�g)				*/
/*		  ptn	  : �ǂꂩ�̕�������v���镶����		*/
/*					'\0'������Ƃ��́A'\0'�������ƌ��Ȃ�*/
/*		  ptn_len : ptn�� (�o�C�g)						*/
/*		  opt	  : �I�v�V����							*/
/*					0x01 : ignore case					*/
/*					0x08 : 0/1:in/to					*/
/*			0x04->	0x10 : �ԋp�l�̒P�� 0/1:�o�C�g/����	*/
/*			0x02->	0x20 : reverse						*/
/*					0x80 : '\0'�������ƌ��Ȃ�			*/
/*					0x7f000000 : code_type				*/
/* �ԋp : >=0 											*/
/*		IN or TO  :�X�L�b�v�����o�C�g���܂��͕�����		*/
/*				   �p�^�[���Ɉ�v���镶�����Ȃ��Ƃ��́A	*/
/*					IN : 0								*/
/*					TO : len or �Ώە�����				*/
/*		RIN or RTO:�X�L�b�v�����ʒu�̐擪����̃o�C�g��	*/
/*				   �܂��͕�����							*/
/*				   �p�^�[���Ɉ�v���镶�����Ȃ��Ƃ��́A	*/
/*					RIN : len or �Ώە�����				*/
/*					RTO : 0								*/
/*		�y��zbuf="12345678", ptn="78"					*/
/*					IN : 0								*/
/*					TO : 6								*/
/*					RIN : 6								*/
/*					RTO : 8								*/
/*		�y��zbuf="12345678", ptn="12"					*/
/*					IN : 2								*/
/*					TO : 0								*/
/*					RIN : 8								*/
/*					RTO : 2								*/
/********************************************************/
int akxn_skip_opt(buf,len,ptn,ptn_len,opt)
char *buf,*ptn;
int  len,ptn_len,opt;
{
	int  i,lptn,m,k,flg,flgb,code_type;
	char *p;
	int  n,opt01,opt02,opt04,opt08,pos,match,iCHECK_NULL;
/*
printf("akx_skip_opt:Enter len=%d ptn_len=%d opt=%08x ptn=[%s]\n",len,ptn_len,opt,ptn);
*/
	if (!buf || !ptn) return -1;
	if (len<=0 || (lptn=ptn_len)<=0) return 0;
	if (opt & 0x80) iCHECK_NULL = 0;
	else {
		iCHECK_NULL = 1;
		p = ptn;
		for (i=0;i<lptn;i++) {
			if (!*p++) {
				iCHECK_NULL = 0;
				break;
			}
		}
	}
	opt04 = opt & 0x10;	/* return moji position */
/*
	if (!*ptn) {
		if (opt04) pos = akxqmlen(buf,len);
		else pos = len;
		return pos;
	}
*/
	code_type = GET_TYPE_OPT(opt);
	opt01 = opt & (CD_TYPE_OPT_MASK | 0x01);	/* opt_type | ignore case */
	opt02 = opt & 0x20;	/* reverse */
	opt08 = opt & 0x08;	/* 0/1=in/to */
	if (opt02) opt08 = opt08 ? 0 : 1;
	pos = 0;
	p = buf;
	m = 1;
	flgb = 0;
	for (i=k=0;i<len;k++) {
		if (iCHECK_NULL && !(*p)) break;
		match = akx_mem_chr_opt(ptn,p,lptn,opt01);
/*
printf("akx_skip_opt: i=%d match=%d lptn=%d ptn=[%c] p=[%c]\n",i,match,lptn,*ptn,*p);
*/
		flg = (opt08 && match) || (!opt08 && !match);
		if (opt02) {
			if (!flgb && flg) {
				if (opt04) pos = k;
				else pos = i;
			}
			flgb = flg;
		}
		else {
			if (flg) {
				if (opt04) i = k;
				return i;
			}
		}
	/*	m=akxqkanjilen(p);	*/
		m=akxqmbslen(code_type,p);
		p += m;
		i += m;
	}
	if (opt02) {
		if (!flgb) {
			if (opt04) pos = k;
			else pos = i;
		}
	}
	else {
		if (opt04) pos = k;
		else pos = i;
	}
	return pos;
}

/********************************************************/
/*														*/
/********************************************************/
int akx_skip_opt(buf,len,ptn,opt)
char *buf,*ptn;
int  len,opt;
{
	if (!ptn) return -1;
	return akxn_skip_opt(buf,len,ptn,strlen(ptn),opt);
}

/********************************************************/
/*														*/
/********************************************************/
int akxnskipin(buf,len,ptn)
char *buf,*ptn;
int  len;
{
	return akx_skip_opt(buf,len,ptn,0);
}

/********************************************************/
/*														*/
/********************************************************/
int akxnrskipin(buf,len,ptn)
char *buf,*ptn;
int  len;
{
	return akx_skip_opt(buf,len,ptn,0x20);	/* 0x02 -> 0x20 */
}

/********************************************************/
/*														*/
/********************************************************/
int akxnskipto(buf,len,ptn)
char *buf,*ptn;
int  len;
{
	return akx_skip_opt(buf,len,ptn,0x08);
}

/********************************************************/
/*														*/
/********************************************************/
int akxnrskipto(buf,len,ptn)
char *buf,*ptn;
int  len;
{
	return akx_skip_opt(buf,len,ptn,0x08|0x20);	/* 0x02 -> 0x20 */
}

/********************************************************/
/*														*/
/********************************************************/
int akxnskipin2(buf,len,ptn,lptn)
char *buf,*ptn;
int  len,lptn;
{
	return akxn_skip_opt(buf,len,ptn,lptn,0);
}

/********************************************************/
/*														*/
/********************************************************/
int akxnskipto2(buf,len,ptn,lptn)
char *buf,*ptn;
int  len,lptn;
{
	return akxn_skip_opt(buf,len,ptn,lptn,0x08);
}

/********1*********2*********3*********4*********5*********6*********/
/*	�@�\ : �G�X�P�[�v�����ł̒u���������s��							*/
/*		   �G�X�P�[�v�����Ŏn�܂�Ȃ��Ƃ��́A���̕�����Ԃ�			*/
/*	���� : IN  : s    : ������										*/
/*				 len  : ������ (�o�C�g)							*/
/*				 ssp  : ssp.sp		: �Ώۈʒu (�擪��0�o�C�g)		*/
/*						ssp.attr[0] : �G�X�P�[�v����				*/
/*							attr[3] : code_type						*/
/*		   OUT : ssp  : ssp.sp		:								*/
/*						ssp.wd		: <>null �̂Ƃ��Aret=1 or 2 ��	*/
/*										�Ƃ��A�}���`�o�C�g������Ԃ�*/
/*							attr[1] : <>'\0' : �u�������A�܂��́A�擪����	*/
/*									  = '\0' : ret=1 or 2			*/
/*							attr[2] : ret=1 or 2 �̂Ƃ��A�}���`�o�C�g��	*/
/*	�ԋp : = 0 : �G�X�P�[�v�����Œu�����ꂽ�A�܂��́A				*/
/*				 �擪��1�o�C�g�����ŃG�X�P�[�v�����łȂ��Ƃ�		*/
/*			 1 : �擪���}���`�o�C�g�����̂Ƃ�						*/
/*			 2 : �G�X�P�[�v�����̎����}���`�o�C�g�����̂Ƃ�			*/
/********************************************************************/
int akx_conv_yen1(s,len,ssp)
uchar *s;
int    len;
SSP_S *ssp;
{
	uchar *p,c,uc,escape,cc;
	char *pp;
	int i,h,n,max,rad,d,code_type,m,ret;

	i = ssp->sp;
	code_type = ssp->attr[3];
	ssp->attr[1] = '\0';
	if (i >= len) return -1;
#if 1	/* 2022.12.06 */
	p = s + i;
	m = akxqmbsnlen(code_type,p,len);
	i += m;
	if (m > 1) {
		ssp->sp = i;
		ssp->attr[2] = m;
		if (pp=ssp->wd) memzcpy(pp,p,m);
		return 1;
	}
#else
	p = s + i++;
#endif
	ret = 0;
	escape = ssp->attr[0];
	c = *p++;
	if (escape && c==escape && i<len) {
	  m = akxqmbsnlen(code_type,p,len);
	  if (m == 1) {
		c = *p;
		if ((c>='0' && c<='9') || c=='x') {
			if (c == 'x') {
				max = 2;
				rad = 16;
				i++;
				p++;
			}
			else {
				max = 3;
				rad = 8;
			}
			max = X_MIN(i+max,len);
			n=0;
			uc = '\0';
			for (;i<max;i++,p++) {
				c = *p;
				if (c>='0' && c<='7') d = c - '0';
				else d = -1;
				if (rad == 16) {
					if (c>='a' && c<='f') d = c - 'a' + 10;
					else if (c>='A' && c<='F') d = c - 'A' + 10;
				}
				if (d>=0 && d<rad) {
					uc = uc*rad + d;
					n++;
				}
				else {
					break;
				}
			}
			c = uc;
		}
		else {
			switch (c) {
				case 'a': c = '\a'; break;
				case 'b': c = '\b'; break;
				case 'f': c = '\f'; break;
				case 'n': c = '\n'; break;
				case 'r': c = '\r'; break;
				case 't': c = '\t'; break;
				case 'v': c = '\v'; break;
			}
			i++;
		}
	  }
	  else {
		ssp->attr[2] = m;
		if (pp=ssp->wd) memzcpy(pp,p,m);
		c = '\0';
		i += m;
		ret = 2;
	  }
	}
	ssp->sp = i;
	ssp->attr[1] = c;
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtstrim(opt,pData,len,ptn)
int opt;	/* 0:�O��, 0x02:�O, 0x01:��, 0x04:NULL�N���A���Ȃ� */
char *pData,*ptn;
int len;
{
	int  ol;
	char *p;
	ParList pa_dat;

	ol = akxtstrim2(opt,pData,len,&pa_dat,ptn);
	if (ol>0 && pData != (p=pa_dat.par)) {
		memcpy(pData,p,ol);
		if (!(opt & 0x04)) pData[ol] = '\0';
	}
	return ol;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtstrim2(opt,pData,len,pa_dat,ptn)
int opt;	/* 0:�O��, 0x02:�O, 0x01:��, 0x04:NULL�N���A���Ȃ�, 0x80:'\0'�������ƌ��Ȃ� */
char *pData,*ptn;
int len;
ParList *pa_dat;
{
	int i,ol,opt1,opt2,opt4,lptn,opt_type;
	char *p;
/*
printf("akxtstrim2:Enter opt=%02x len=%d pDat=[%s]\n",opt,len,pData);
*/
	pa_dat->par    = pData;
	pa_dat->parlen = len;
	if (!(p=pData)) return -1;
	else if ((ol=len) <= 0) return ol;
	if (!ptn) ptn = " \t";
	else if (!(lptn = strlen(ptn))) return ol;

	opt_type = opt & CD_TYPE_OPT_MASK;
	opt4 = opt & 0x04;
	opt &= 0x03;
	if (!opt) opt = 0x03;
	opt1 = opt & 0x01;
	opt2 = opt & 0x02;
	if (opt2) {	/* �O  */
		i = akx_skip_opt(pData,len,ptn,opt_type);	/* akxnskipin(pData,len,ptn); */
		ol = len - i;
		p = pData + i;
/*
printf("akxtstrim2:front i=%d ol=%d\n",i,ol);
*/
	}
	if (!(opt & 0x80)) ol = akxstrnlen(p,ol);	/* add 2024.5.12 *//* mod 2024.5.24 */
	if (opt1 && ol>0) {	/* �� */
		ol = akx_skip_opt(p,ol,ptn,0x20 | opt_type);	/* 0x02 -> 0x20 */ /* akxnrskipin(p,ol,ptn); */
/*
printf("akxtstrim2:rear ol=%d\n",ol);
*/
	}
/*
	if (opt>=1 && i>0) memcpy(pData,p,ol);
*/
	if (!opt4 && ol<len) p[ol] = '\0';

	pa_dat->par    = p;
	pa_dat->parlen = ol;

	return ol;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtsapb(opt,pData,len)
	/* 2017.11.03 */
int opt;	/* 0:�O��, 0x02:�O, 0x01:��, 0x04:NULL�t�����Ȃ� */
char *pData;
int len;
{
#if 1	/* 2019.10.03 */
	int ol;

	ol = akxtstrim(opt,pData,len,NULL);
#else
	int i,ol,opt1,opt2;
	char *p, *pb, c;

	if (!(p = pData)) return -1;
	else if (len <= 0) return len;

	for (ol=0;ol<len;ol++) {
		if (!*p) break;
		p++;
	}
	p = pData;
	/* 2017.11.03 */
	if (!opt) opt = 0x03;
	opt1 = opt & 0x01;
	opt2 = opt & 0x02;
	if (opt2) {	/* �O  */
		while (ol>0 && ((c = *p) == ' ') || (c == '\t')) {
			p++;
			ol--;
		}
		if (ol <= 0) {
			*pData = '\0';
			return (0);
		}
	}
	/* 2017.11.03 */
	if (opt1) {	/* �� */
		pb = p + ol - 1;
		while (ol>0) {
			if (((c = *pb--) != ' ') && (c != '\t')) break;
			ol--;
		}
	}
	/* 2017.11.03 */
	if (opt2
	    && pData != p) memcpy(pData,p,ol);

	if (ol<len) pData[ol] = '\0';
#endif	/* 2019.10.03 */
	return ol;
}

/********************************************************/
/*														*/
/********************************************************/
char *akxttrim2(opt,pData,plen)
int opt;	/* 0:�O��, 0x02:�O, 0x01:��, 0x10:NULL�t������ */
char *pData;
int *plen;
{
#if 0	/* 2019.10.03 */ /* 1-->0 2021.10.2 */
	int ol;
	ParList pa_dat;

	ol = akxtstrim2(opt,pData,len,&pa_dat,NULL);
	pp = pa_dat.par;
#else
	int i,ol,ib,len,opt_fb,opt_ts,opt_f,opt_b,opt_t,opt_s,trim_ts;
	char *p, c, *pp;

	if (!(p=pData)) return NULL;
	if (!plen) return p;
	len = *plen;
	if ((ol=len) <= 0) return p;
/*
printf("akxttrim2: len=%d p=[%s]\n",len,p);
*/
	opt_fb = opt & (AKX_TRIM_BACKWARD | AKX_TRIM_FORWARD);
	opt_ts = opt & (AKX_TRIM_DEL_TAB  | AKX_TRIM_DEL_SPACE);
	if (!opt_fb) opt_fb = AKX_TRIM_BACKWARD | AKX_TRIM_FORWARD;
	if (!opt_ts) opt_ts = AKX_TRIM_DEL_TAB  | AKX_TRIM_DEL_SPACE;
	opt_f = opt_fb & AKX_TRIM_FORWARD;
	opt_b = opt_fb & AKX_TRIM_BACKWARD;
	opt_t = opt_ts & AKX_TRIM_DEL_TAB;
	opt_s = opt_ts & AKX_TRIM_DEL_SPACE;
	if (opt_f) {	/* �O  */
#if 1
		while (ol > 0) {
			if (!(c = *p)) break;
			else if (!(opt_s && c==' ' || (opt_t && c=='\t'))) break;
#else
		while (ol>0 && ((opt_s && (c=*p)==' ') || (opt_t && c=='\t'))) {
#endif
			p++;
			ol--;
		}
		if (!c || ol<=0) {
			if (opt & 0x10) *pData = '\0';
			*plen = 0;
			return pData;
		}
	}
	pp = p;
	if (opt_b) {	/* �� */
#if 1	/* 2021.10.2 */
		ib = -1;
		for (i=0;i<ol;i++,p++) {
			if (!(c = *p)) {
				ol = i;
				break;
			}
			trim_ts = (opt_s && c==' ') || (opt_t && c=='\t');
/*
printf("akxttrim2: i=%d ib=%d c=[%c] trim_ts=%d\n",i,ib,c,trim_ts);
*/
			if (ib < 0) {
				if (trim_ts) ib = i;
			}
			else {
				if (trim_ts) ;
				else ib = -1;
			}
		}
		if (ib >= 0) ol = ib;
#else
		ib = -1;
		for (i=0;i<ol;i++,p++) {
			if (((c = *p)==' ') || (c=='\t')) {
				ib = i;
				for (;i<ol;i++,p++) {
					if (((c = *p)==' ') || (c=='\t')) ;
					else {
						if (c) ib = -1;
						break;
					}
				}
			}
			if (!c) {
				ol = i;
				break;
			}
		}
		if (ib >= 0) ol = ib;
#endif
	}
#endif	/* 2019.10.03 */
	if ((opt & 0x10) && ol<len) pp[ol] = '\0';
	*plen = ol;
	return pp;
}

/********************************************************/
/*														*/
/********************************************************/
int akxttrim(opt,pData,len0)
int opt;	/* 0:�O�� 0x02:�O 0x01:�� */
char *pData;
int len0;
{
	int len;
	char *p;

	len = len0;
	if (!opt) opt = 3;
	p = akxttrim2(opt,pData,&len);
	if ((opt & 0x02) && pData!=p) memcpy(pData,p,len);
	if (len<len0) pData[len] = '\0';
	return len;
}

/************************************************/
/* �@�\ : �Ώە����񂪎w�肳�ꂽ��������		*/
/*		  �����݂̂��ǂ����𒲂ׂ�				*/
/* ���� : p1  : �Ώە�����						*/
/*		  len : p1�̃o�C�g��					*/
/*		  str : ���ׂ邢�����̕���(NULL�I�[)	*/
/*				NULL�̂Ƃ��́A" \t\r\n"			*/
/* �ԋp : =0 : str�ȊO������					*/
/*			   �܂��́Ap1=NULL					*/
/*		  =1 : str�݂̂ł���					*/
/*			   �܂��́Ap1��str���󕶎�			*/
/************************************************/
int akxqn_is_str(p1,len,str)
char *p1,*str;
int len;
{
	int ret,pos;

	pos = ret = 0;
	if (p1 && len>0) {
		if (!str) str = " \t\r\n";
		if (!*str) {
			if (!*p1) ret = 1;
		}
		else if ((pos=akxnskipin(p1,len,str)) >= len) ret = 1;
	}
/*
printf("akxqn_is_str: pos=%d ret=%d str=[%s]\n",pos,ret,str);
*/
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int akxs_mleft(s,s_len,m_len,opt)
char *s;
int s_len,m_len,opt;
{
	int code_type;

	if (!s || s_len<0) return -1;
	code_type = GET_TYPE_OPT(opt);
	return akxqm2len_type(s,s_len,m_len,code_type);
}

/********************************************************/
/*														*/
/********************************************************/
int akxs_mright(s,s_len,m_len,opt)
char *s;
int s_len,m_len,opt;
{
	int i,mlen,pos,code_type,m;

	if (!s || s_len<0) return -1;
/*
printf("akxs_mright: s_len=%d m_len=%d opt=%08x s=[%s]\n",s_len,m_len,opt,s);
*/
	code_type = GET_TYPE_OPT(opt);
	/* slen�o�C�g�̕����������߂� */
	mlen = akxqmlen_type(s,s_len,code_type);
/*
printf("akxs_mright: mlen=%d\n",mlen);
*/
	m = mlen - m_len;	/* �擪����̕����� */
	if (m > 0) {
		/* �擪����̃o�C�g�� */
		m = akxqm2len_type(s,s_len,m,code_type);
/*
printf("akxs_mright: m=%d\n",m);
*/
	}
	else m = 0;
	return m;
}

/********1*********2*********3*********4*********5*********6*/
/* �@�\ : ��������3�����ƂɃJ���}(,)��t����				*/
/*		  �r����NULL����������Ƃ��́A���̑O�܂łɂȂ�		*/
/*		  �O��̃X�y�[�X�A�^�u�͍폜����					*/
/*		  �J���}�͈�x�폜����								*/
/*		  �`���́A�ȉ����T�|�[�g����						*/
/*			[�C�ӕ�����]������[.|d|e|f|D|E|F][�C�ӕ�����}	*/
/* ���� : IN    : d			: �o�͈�ւ̃|�C���^			*/
/*				  d_len		: �o�͈�̒���(�o�C�g)			*/
/*							  NULL�I�[���܂ޒ���			*/
/*				  s			: ���͈�ւ̃|�C���^			*/
/*				  s_len		: ���͈�̒���(�o�C�g)			*/
/*		  OUT   : d			: �J���}�t�^������(NULL�I�[)	*/
/* �ԋp : �o�͒�(�o�C�g)NULL�I�[���܂܂Ȃ�					*/
/************************************************************/
int akxtncomma2(d,d_len,s,s_len)
char *d,*s;
int d_len,s_len;
{
	int i,len,ret,cnt,pos;
	char *ps,*pd,c;
	ParList pa_dat;

	if (!d || !s || d_len<=1) return -1;
	else if (s_len <= 0) {
		*d = '\0';
		return 0;
	}
	d_len--;
	ret = 0;
	s_len = akxtstrim2(0,s,s_len,&pa_dat," \t\r\n");
	s = pa_dat.par;
/*
printf("akxtcomma: d_len=%d s_len=%d s=[%s]\n",d_len,s_len,s);
*/
	pd = d;
	ps = s + s_len - 1;
	pos = inmemichars(s,s_len,".DEF");
	if (pos > 0) {
		pos--;
		len = s_len - pos;
		s_len -= len;
		for (i=0;i<len;i++) {
			if (ret >= d_len) break;
			*pd++ = *ps--;
			ret++;
		}
	}
/*
*pd='\0';
printf("akxtcomma: pos=%d ret=%d d=[%s] s_len=%d\n",pos,ret,d,s_len);
*/
	cnt = 0;
	for (i=0;i<s_len;i++) {
		if (ret >= d_len) break;
		c = *ps;
		if (c == '\0') break;
		else if (c == ',') ps--;
		else {
			if (c<'0' || c>'9') break;
			ps--;
			if (cnt >= 3) {
				*pd++ = ',';
				ret++;
				cnt = 0;
			}
			*pd++ = c;
			ret++;
			cnt++;
/*
printf("akxtcomma: i=%d c=[%c] ret=%d\n",i,c,ret);
*/
		}
	}
	for (;i<s_len;i++) {
/*
printf("akxtcomma: i=%d *pc=[%c] ret=%d\n",i,*ps,ret);
*/
		if (ret >= d_len) break;
		c = *ps--;
		if (c == '\0') break;
		*pd++ = c;
		ret++;
	}
	akxtreverse(d,ret);
	*(d+ret) = '\0';
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtncomma(d,d_len,s)
char *d,*s;
int d_len;
{
	return akxtncomma2(d,d_len,s,strlen(s));
}

/********************************************************/
/*														*/
/********************************************************/
int akxtcomma(d,s)
char *d,*s;
{
	return akxtncomma2(d,INT_MAX,s,strlen(s));
}

/****************************/
/* opt = 0 : instr			*/
/*     = 1 : �O����v		*/
/*     = 2 : �����v		*/
/*     = 3 : ���S��v		*/
/****************************/
int cmpstr_opt(text,pat,opt)
char *text,*pat;
int opt;
{
	int len_text,len_pat,pos;

	pos = 0;
	opt = opt & 0x03;
	len_text = strlen(text);
	len_pat = strlen(pat);
	if (len_pat<=0 || len_text<=0 || len_pat>len_text)
		pos = 0;
	else {
		if (!opt)
			pos = instr(text,pat);
		else if (opt == 3) {
			if (!strcmp(text,pat)) pos = 1;
		}
		else {
			if (opt == 1) {
				if (!memcmp(text,pat,len_pat)) pos = 1;
			}
			else {
				if (!memcmp(text+(len_text-len_pat),pat,len_pat)) pos = len_text - len_pat + 1;
			}
		}
	}
	return pos;
}

/********1*********2*********3*********4*********5*********6*********7**
'*  ���� : cmp_mstr_posa_opt                                           *
'*  �@�\ : �w��̋�؂蕶����̂ǂꂩ���ŋ�؂�ꂽ������̂ǂꂩ���A  *
'*         �Ώە�����Ɉ�v���邩�A�Ώە����񒆂ɂ��邩�ǂ����𒲂ׂ�  *
'*         (��)���p�S�p����ʂ��Ȃ��I�v�V�����ŁAtext0 ���ɑ��_�t��    *
'*             ���p�J�i������Ƃ��A��v�����񒷂��Z���Ȃ�ꍇ������    *
'*  ���� : IN  : text0  : �Ώە�����                                   *
'*               mstr0  : ��؂蕶����̂ǂꂩ���ŋ�؂�ꂽ������     *
'*               opt0   : �I�v�V����                                   *
'*                        0x01 : 0=INSTR / 1=STRCMP                    *
'*                        0x02 : 1=�啶������������ʂ��Ȃ�            *
'*                        0x04 : 1=���p�S�p����ʂ��Ȃ�                *
'*                        0x08 : 1=INSTR�̂Ƃ���������Ώۂɂ���       *
'*                        0x10 : 1=INSTR�̂Ƃ��O����v                 *
'*                        0x20 : 1=INSTR�̂Ƃ������v                 *
'*                        0x40 : 1=LIKE�g�p�����"_"������           *
'*                        0x80 : 1=LIKE�g�p���Ȃ�                      *
'*               dlm    : ��؂蕶����                                 *
'*               posa() : ��v�ʒu(�擪��1)��Ԃ��z��                  *
'*                        posa(0):text0���̈�v�擪�ʒu                *
'*                        posa(1):nstr0���̕�����̔ԍ�(�擪��1�Ԗ�)   *
'*                          �z��̌��ɂ���Ĉȉ���Ԃ�               *
'*                        posa(2):start pos by byte                    *
'*                        posa(3):matching string length by byte       *
'*                        posa(4):start pos by char                    *
'*                        posa(5):matching string length by char       *
'*               max_posa: posa�̌�                                  *
'*  �ԋp : �������� = 0 : text���ɂȂ�                                 *
'*                  > 0 : text���̈�v�擪�ʒu(�擪��1)                *
'*  �쐬 : 20XX/XX/XX Akito Kobayashi                                  *
'*  �X�V :															   *
'**********************************************************************/
int cmp_mstr_posa_opt(text0,mstr0,opt0,dlm,posa,max_posa)
char *text0,*mstr0;
int opt0;
char *dlm;
int posa[],max_posa;
{
	int i,k,m,n,nn,pos,ret,iLIKE,npat,text_len,wwd_len;
	int opt,opt1,opt2,opt4,opt8,opt10,opt20,cmp_opt;
	char *sep,*text,*mstr,*wwd,*wwd0,*text2,*wwd2,*pata[99],*pt1,*pm1,*pt2,*pm2,parm[256];

	if (!text0 || !mstr0) return -1;
	text = text0;
	mstr = mstr0;
	opt1 = opt0 & 0x01;
	opt2 = opt0 & 0x02;
	opt4 = opt0 & 0x04;
	opt8 = opt0 & 0x08;
	opt10 = opt0 & 0x10;
	opt20 = opt0 & 0x020;
	if (opt10 && opt20) {
		opt10 = 0;
		opt20 = 0;
		opt1 = 1;
	}
	if (opt1 == 1)
		cmp_opt = 3;
	else
		cmp_opt = (opt0/16) & 0x03;

	ret = -2;
	pt1 = pm1 = pt2 = pm2 = NULL;
	if (opt2 || opt4) {
		text_len = strlen(text);
		if (!(pt1=Malloc(text_len+1))) return -1;
		m = strlen(mstr);
		if (!(pm1=Malloc(m+1))) goto Err;
		if (opt2) {
			akxcuppern(pt1,text,text_len);
			akxcuppern(pm1,mstr,m);
			text = pt1;
			mstr = pm1;
		}
		if (opt4) {
			if (!(pt2 = Malloc(text_len*3+1))) goto Err;
			akxctozen(text_len,text,pt2);
			text = pt2;
			if (!(pm2=Malloc(2))) goto Err;
		}
	}

	opt = 0x01 + 0x04 + 0x08 + 0x2000;

	n = akxtgetargvns2(mstr,strlen(mstr),pata,99,parm,sizeof(parm),dlm,0);
	pos = 0;
	nn = n;
	if (nn > 5) nn = 5;
	mem_set_int(posa,0,nn+1);
	text_len = strlen(text);
	for (i=0;i<n;i++) {
		wwd0 = pata[i];
		wwd = wwd0;
		if (opt4) {
			wwd_len = strlen(wwd0);
			pm2 = Realloc(pm2,wwd_len*3+1);
			akxctozen(wwd_len,wwd,pm2);
			wwd = pm2;
		}
		if (opt8 && text_len<strlen(wwd)) {
			text2 = wwd;
			wwd2 = text;
		}
		else {
			text2 = text;
			wwd2 = wwd;
		}
		pos = cmpstr_opt(text2,wwd2,cmp_opt);
		if (pos > 0) {
			posa[0] = akxqmlen(text,pos);
			posa[1] = i + 1;
			if (nn >= 2) posa[2] = pos;
			if (nn >= 3) posa[3] = strlen(wwd0);
			if (nn >= 4) posa[4] = posa[0];
			if (nn >= 5) posa[5] =akxqmlen(wwd0);
			break;
		}
	}
	ret = pos;
 Err:
	if (pt1) Free(pt1);
	if (pt2) Free(pt2);
	if (pm1) Free(pm1);
	if (pm2) Free(pm2);
	return ret;
}


/********************************************************/
/*														*/
/********************************************************/
int akxs_count_mem_opt(target,ltar,str,lstr,opt)
char *target,*str;
int  ltar,lstr,opt;
{
	char *pt,*ps;
	int count,lpt,pos;

	if (!(pt=target) || !(ps=str)) return -1;
	count = 0;
	lpt = ltar;
	while (lpt >= lstr) {
		if ((pos=akxs_in_mem_opt(pt,lpt,ps,lstr,1,opt)) <= 0) {
			if (pos < 0) count = pos;
			break;
		}
		count++;
		pos += lstr - 1;
		pt += pos;
		lpt -= pos;
/*
printf("akxs_count_mem_opt: pos=%d lpt=%d pt=[%s]\n",pos,lpt,pt);
*/
	}
	return count;
}

/********************************************************/
/*	���p�����l������instr								*/
/********************************************************/
int akx_instr_word(s0,slen0,str0,str_len0,sep0,opt)
char *s0,*str0,*sep0;
int  slen0,str_len0,opt;
{
	char c,*wd,*p,wrk[256],*s,*str,*sep;
	int slen,str_len,len,atr,rem_len,pos,sp;
	SSPL_S ssp;

	if (!(s=s0) || !(str=str0)) return -1;
	if ((slen=slen0)<=0 || (str_len=str_len0)<=0) return 0;
	if (!(sep=sep0)) sep = " \t";
	ssp.sp = 0;
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk);
	ssp.code = 0;
	pos = 0;
	wd = ssp.wd;
	p = s;
	sp = 1;
	rem_len = slen;
	while ((len=akxtgwnsl(s,slen,&ssp,sep,0x41)) > 0) {
/*
printf("akx_instr_word: len=%d wd=[%s]\n",len,wd);
*/
		atr = ssp.attr[0];
		if (atr == 1) {
			if (!strcmp(wd,str)) {
				pos = sp;
				break;
			}
		}
		else if (atr > 10) {
			c = *wd;
/*
printf("cl_skip_to_delm: sp=%d c=[%c]\n",ssp->sp,c);
*/
			if (c==*str && rem_len>=str_len) {
				if (!akxmemcmplen(str,str_len,p,str_len,opt)) {
					pos = sp;
					break;
				}
			}
		}
		p += len;
		rem_len -= len;
		sp += len;
	}
	return pos;
}

/********************************************************/
/*	�s�v�ȋ󔒂��폜����								*/
/********************************************************/
int akxtidyngup(s0,slen0)
char *s0;
int slen0;
{
	static char *sep=" \t,;()[]{}<>='\"!^*/+-`";
	char *s,*p,c,*p1;
	int slen,i,rc,len,atr1,atr2,dlen;
	SSPL_S ssp;

	if (!(s=s0)) return -1;
	if ((slen=slen0) < 0) return 0;
	memset(&ssp,0,sizeof(SSPL_S));
	p = s;
	dlen = 0;
	if ((len=akxtgwnsl(s,slen,&ssp,sep,0x841)) > 0) {
		atr1 = ssp.attr[0];
		memcpy(p,ssp.wd,len);
		p += len;
		dlen += len;
		while ((len=akxtgwnsl(s,slen,&ssp,sep,0x841)) > 0) {
			atr2 = ssp.attr[0];
			if (atr1<10 && atr2<10) {
				*p++ = ' ';
				dlen++;
			}
			memcpy(p,ssp.wd,len);
			p += len;
			dlen += len;
			atr1 = atr2;
		}
	}
	if (dlen < slen) *p = '\0';
	return dlen;
}
