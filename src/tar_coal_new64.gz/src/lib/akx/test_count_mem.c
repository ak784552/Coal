static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_count_mem.c libakx_no_iconv.a -o test_count_mem
*/
#include "akxcommon.h"

int main()
{
	char buf[256],wd[256],*p;
	int n,opt,len,ret;

	printf("Enter target text ==>");
	gets(buf);
	for (;;) {
		printf("Enter opt ==>");
		gets(wd);
		opt=atoi(wd);
		printf("Enter search string ==>");
		gets(wd);
		if (!*wd) break;
		printf("akxs_count_mem_opt: ret=%d\n",akxs_count_mem_opt(buf,strlen(buf),wd,strlen(wd),opt));
	}
}
