#---------------------------------------------------------------
#
#		other rules
#
#---------------------------------------------------------------
clean :
	$(RM) -f $(TARGETFILE)

cleansrc :
	$(SCCS) clean

new : clean all

depend : 
	makedepend -I$(INCLUDES) *.c

info :
	$(SCCS) info
