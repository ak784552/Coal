static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/* <clprret.c>                                                      */
/********************************************************************/

#include "colmn.h"

#define NEWRET 1
#define NEORET 1

extern CLPRTBL  CLprocTable;	/* ��񃊃X�g */
extern GlobalCt *pGlobTable;

/************************************/
/*									*/
/************************************/
static void _set_max_loop_count(proc)
ProcCT  *proc;
{
	BlockCB *next;

	next = proc->pTopBlockCB;
	while (next && next->iUsed) {
		if (next->cid == C_LOOP) next->iLoopCounter = 0x7ffffffe;
		next = next->nextBlockCB;
	}
}

/************************************/
/*									*/
/************************************/
static int _push_return(leaf,proc)
Leaf   *leaf;
ProcCT *proc;
{
	static Leaf	Retleaf;
	Leaf	*retleaf;

	retleaf = &Retleaf;
	memcpy(retleaf,leaf,sizeof(Leaf));
	retleaf->rightleaf = NULL;
	retleaf->leftleaf  = NULL;
	cl_copy_cmd(&(retleaf->cmd),&(leaf->cmd));
	retleaf->cmd.cid    = C_RETURN;
	retleaf->cmd.prmnum = -1;
	cl_ret_leaf_push(proc,retleaf);
	return 0;
}

/************************************/
/* cl_process_return                 */
/* function; check command of this  */
/*          leaf then call functions*/
/************************************/
int cl_process_return(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	int rc,n,val[2],nparm,i;
	long iGid;
	char *p,id;
	uchar aux1;
	tdtInfoParm InfoParm[2],*pInfoParmW,*pInfoParm,*pInfoParm2,*pInfoParm1,*pInfo;

	if (!leaf || !proc) return ECL_SYSTEM_ERROR;

	rc = 0;
	/* check specification of return value */
	pInfoParm2 = InfoParm;
	if (leaf->cmd.prmnum > 0) {
		rc = cl_gx_exp_obj_opt(leaf->cmd.prmnum,&(leaf->cmd.prmp[0]),
		              proc->Obj,pInfoParm2,D_GX_OPT_GET_ADDR);
DEBUGOUT_InfoParm(110,"cl_process_return: pInfoParm2=",pInfoParm2,0,0);
		if (rc) {
			ERROROUT2(FORMAT(48),"clprret",rc);	/* %s: ��������Ă��܁B(rc=%d) */
			rc = ECL_EX_RETURN;
		}
		else {
			if (cmn_chk_stat(UFN_PR,&proc->ptype) == L_OFF) {
				if (rc=_ex_conv_parm_opt(&pInfoParm2,0,"NOT UFN_PR")) return ECL_EX_RETURN;
				rc = cl_get_parm_bin(pInfoParm2,val,FORMAT(511));	/* ���^�[���l: */
				if (!rc) {
					n = val[0];
					if (n < 0) PRINTOUT3("clprret: proc = %s, ret = %d %s",
					                     proc->ProcNM,n,akb_str_error(n));
					pGlobTable->error = n;
					pGlobTable->Return = n;
				/*	pGlobTable->exception = n;	*/
				}
			}
			else {
				if (pInfoParmW=proc->Retval) {
					aux1 = pInfoParmW->pi_aux[1];	/* add 2025.12.30 */
					/* 2024.12.27 */
					iGid = pInfoParmW->pi_hlen;
/*
printf("cl_process_return: proc=%016lx pInfoParmW=%016lx iGid=%ld pi_id=[%c]\n",proc,pInfoParmW,iGid,pInfoParmW->pi_id);
*/
					/* 2024.5.6 */
					pInfoParm = pInfoParm2;
					if (rc=_ex_conv_parm_opt(&pInfoParm,0,"RETURN")) return ECL_EX_RETURN;
DEBUGOUT_InfoParm(120,"cl_process_return:",pInfoParm,0,0);
					/* 2026.3.11 */
					/* AS VOID�̎��s�ł́AD_PR_PFLAG2_RET_VOID��ON�ɂȂ� */
					if (proc->pr_pFlag2 & D_PR_PFLAG2_RET_VOID) {
						;
					}
					else
					/* 2024.12.25 */
					/* 2026.3.11 ����proc�ɂ́AD_PFLAG_DEF_CLASS��ON�ɂȂ��Ă��Ȃ����A���̂܂܂ɂ��� */
					if (!(proc->pr_pFlag & D_PFLAG_DEF_CLASS)
						/* 2024.5.6 */
					    && ((id=pInfoParm->pi_id)==D_DATA_ID_MAPEDARY ||
						    id==D_DATA_ID_ARRAY || id==D_DATA_ID_STRUCT)
					   ) {
						/* 2025.11.18 */
						rc = 0;
						if (id==D_DATA_ID_ARRAY || id==D_DATA_ID_MAPEDARY)
							rc = cl_get_array_index_opt(pInfoParm,NULL,1);
						else if (id == D_DATA_ID_STRUCT)
							rc = cl_get_struct_member_opt(pInfoParm,NULL,1);
						if (rc) {
							pInfo = (tdtInfoParm *)pInfoParm->pi_paux;
							if (pInfo->pi_aux[1] & D_AUX1_LOCAL_VAR)
								pInfoParm->pi_aux[0] |= DEF_ZOK_DATA;
/*
printf("cl_process_return: pi_aux[0]=%08x\n",pInfoParm->pi_aux[0]);
*/
						}
						if ((pInfoParm->pi_aux[1] & D_AUX1_LOCAL_VAR) || 
						    (pInfoParm->pi_aux[0] & DEF_ZOK_DATA)) {	/* add 2025.11.18 */
							pInfoParm->pi_aux[0] |= DEF_ZOK_DATA;
							if (rc = cl_gx_rep_info_als(pInfoParmW,pInfoParm,1)) return rc;
						}
						else {
							/* 2024.12.27 */
							if (rc = cl_gx_rep_info_als(pInfoParmW,pInfoParm,1)) return rc;
						}
					}
					/* 2024.5.6 */
					else if (rc = cl_gx_rep_info_als(pInfoParmW,pInfoParm,1)) {
					/*	cl_parm_set0(pInfoParmW);	*//* add 2022.7.8 */
						return rc;
					}
					/* 2024.12.27 */
					if ((id=pInfoParmW->pi_id)=='R' || id=='A' || id=='T') pInfoParmW->pi_hlen = iGid;
					/* add 2025.12.30 */
					pInfoParmW->pi_aux[1] &= ~D_AUX1_VAR_SCOPE;
					pInfoParmW->pi_aux[1] |= aux1;
DEBUGOUT_InfoParm(120,"cl_process_return: proc=%s pFlag=%02x",pInfoParmW,proc->ProcNM,proc->pr_pFlag);
				}
			}
		}
	}
	else if (!leaf->cmd.prmnum) {
		pGlobTable->error = 0;
		pGlobTable->Return = 0;
	}
	cmn_set_stat(RET_PR,&proc->ptype,L_ON);
	proc->Nextleaf = NULL;
	if (proc->ucExcept > 0) {
		rc = cl_back_with_finally(leaf,proc,_push_return);
	}
/*
printf("cl_process_return: rc=%d\n",rc);
*/
DEBUGOUTL2(110,"cl_process_return:Exit: rc=%d exception=%08x",rc,pGlobTable->exception);
	return rc;
}

/************************************/
/* cl_process_throw                   */
/************************************/
int cl_process_throw(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	int rc,n,val[2];
	tdtInfoParm InfoParm;

	rc = cl_gx_exp_obj(leaf->cmd.prmnum,&(leaf->cmd.prmp[0]),proc->Obj,&InfoParm);
	if (rc) {
		ERROROUT2(FORMAT(48),"cl_process_throw",rc);	/* %s: ��������Ă��܁B(rc=%d) */
		rc = ECL_EX_RETURN;
	}
	else {
		rc = cl_get_parm_bin(&InfoParm,val,FORMAT(512));	/* ��O�l: */
		if (!rc) {
			if (n = val[0]) {
				PRINTOUT2("Throw exception: proc = %s, exception = %d",proc->ProcNM,n);
				n = X_ABS(n);
				if (!(n & 0x7f000000)) n |= USER_EXCEPTION;
				pGlobTable->exception = ALL_EXCEPTION | n;
			}
			else {
				PRINTOUT1("Throw exception: proc = %s, clear exception",proc->ProcNM);
				pGlobTable->exception = 0;
				proc->ucExcept = 0;
			}
		}
	}
	return rc;
}

/************************************/
/*									*/
/************************************/
int cl_back_with_finally(leaf,proc,_push_return)
Leaf    *leaf;
ProcCT  *proc;
int (*_push_return)();
{
	int rc,cid;
	BlockCB *pcrLCB;

	if (!proc) return -1;

	pcrLCB = proc->pcrBlockCB;
	while (pcrLCB) {
/*
printf("cl_back_with_finally: cid=%08x\n",pcrLCB->cid);
*/
		if ((cid=pcrLCB->cid)==C_TRY) {
			rc = cl_pop_finally(proc,pcrLCB);
			if (rc) {
				if (rc == C_FINALLY) {
					_push_return(leaf,proc);
					rc= 0;
				}
				break;
			}
		}
		pcrLCB->iUsed = 0;
		pcrLCB = pcrLCB->preBlockCB;
	}
	proc->pcrBlockCB = pcrLCB;
	return rc;
}
