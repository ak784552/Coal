#afhash: 500
#afdump: debug_log #off
#afdump: coal_memory.log #off
#nfdump: coal_nofree.log off
