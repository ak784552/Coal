static char sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_output              */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Paragraph �^�O�̏������s���B              */
/* --------------------------------------------- */
/*  Version                    1.00  2010/05/28  */
/*************************************************/
/* */
#include "colmn.h"

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_output(y)
condList *y;
{
	int rc;

	if (y->cmd->prmnum < 1) {
		ERROROUT1(FORMAT(42),"col_mn_tr_output");
		return ECL_TR_OUTPUT;
	}

	if (!(rc = cl_make_leaf(y))) rc = cl_push(y);

	return rc;
}
