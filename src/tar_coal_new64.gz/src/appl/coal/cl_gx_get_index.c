static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �ϐ���INDEX�����߂�                                    *
*                                                                             *
*      �֐����@�@�@�F�@int cl_gx_get_index( pparmList )                       *
*                      parmList  *pparmList                                   *
*                                                                             *
*      �߂�l�@�@�@�F�@ <0 : ERROR                              �@            *
*                      >=0 : NORMAL                                           *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
/********************************************/
/*	  coded by A.Kobayashi() 2010.XX.XX		*/
/*	  error code : -215210101�`-215219999	*/
/********************************************/
#include <colmn.h>

extern GlobalCt  *pGlobTable;
extern int giOptions[];
extern tdtIterate_ctl gtIter_ctl[];
extern MCAT2 *pgItr_circ_ref;
extern int igItr_circ_ix;

/****************************************/
/*	01									*/
/****************************************/
static int _check_index(vname,vnlen,varnam)
char *vname,*varnam;
int  vnlen;
{
	char tmp[Var_NM_MAX*2+1],c,*p;
	int index=0;

DEBUGOUTL1(250,"--->_check_index: vname=[%s]",vname);

/*	if ((c=*vname)=='.' || c=='+' || c=='-' || (c>='0' && c<='9')) {	*/
	if ((c=*vname)=='+' || c=='-' || (c>='0' && c<='9')) {
		if (akxccvn(10,vname,vnlen,&index)) {
		/*	if (!(pGlobTable->options[1] & 0x02)) {	*/
				memnzcpy(tmp,vname,vnlen,sizeof(tmp));
				ERROROUT2(FORMAT(216),tmp,"no digit");	/* Index(%s) %s */
				return -215210101;
		/*	}	*/
		}
		else return index;
	}
	index = 0;
	if (vnlen > Var_NM_MAX) {
		p = "name is longer";
		index = -215210102;
	}
	else if (cl_chk_name(vname,vnlen)) {
		p = "not name char";
		index = -215210103;
	}
	else {
		memnzcpy(varnam,vname,vnlen,Var_NM_MAX+1);
	}
	if (index < 0) {
		memnzcpy(tmp,vname,vnlen,sizeof(tmp));
		ERROROUT2(FORMAT(216),tmp,p);	/* Index(%s) %s */
	}
	return index;
}

/****************************************/
/*	02									*/
/****************************************/
int cl_gx_get_index(pparmList, varnam)
parmList  *pparmList;
char *varnam;
{
	return cl_gx_get_index_array(pparmList,varnam,NULL,0);
}

/****************************************/
/*	03									*/
/****************************************/
int cl_gx_get_index_array(pparmList,varnam,ppArrayInfo,iOpt)
parmList  *pparmList;
char *varnam;
tdtInfoParm **ppArrayInfo;
int  iOpt;
{
	static char *_fn_="cl_gx_get_index_array";
	int		rc,index,vnlen,iParm[4];
	char	*vname,c;
	tdtInfoParm InfoParm,*pInfo;
	parmList plw;

	if (ppArrayInfo) *ppArrayInfo = NULL;
#if 1
	vname = pparmList->prp;
	vnlen = pparmList->prmlen;
#if 1	/* 2022.6.11 */
	if (!(rc=cl_skip_scope_mark(vname,vnlen,NULL))) ;
	else if (rc > 0) {
		vnlen -= rc;
		vname += rc;
	}
	else  return rc;
#endif

DEBUGOUTL3(250,"--->%spparmList->prp=[%s] ppArrayInfo=%016lx",_fn_,vname,ppArrayInfo);

	if ((c=vname[0])=='$' || c=='%' || c=='#') ;
	else {
		if (cl_chk_name_opt(vname,vnlen,1)) {
			ERROROUT3(FORMAT(113),_fn_,FORMAT(329),vname);	/* %s: %s��[%s]���s���ł��B*//* �ϐ� */
			rc = -215210303;
		}
		else {
			memnzcpy(varnam,vname,vnlen,Var_NM_MAX+1);
			rc = 0;
		}
		return rc;
	}
	vnlen--;
	vname++;
#else
	vnlen = pparmList->prmlen-1;
	vname = pparmList->prp+1;
#endif
	if (vnlen>2 && vname[0]=='{' && vname[vnlen-1]=='}') {
		vnlen -= 2;
		vname++;
	}
	*varnam = '\0';
	if ((c=vname[0])=='$' || c=='%' || c=='#') {
		plw.prmlen = vnlen;
		plw.prp    = vname;
		rc=cl_conv_parm_opt(&plw,&InfoParm,iOpt & D_GX_OPT_NOEROUT_NDEF);

DEBUGOUT_InfoParm5(194,"%scl_conv_parm rc=%d ppArrayInfo=%016lx",
&InfoParm,_fn_,rc,ppArrayInfo,0,0);

		if (rc) {
			if (ppArrayInfo && rc==ECL_DEFINED_ARRAY) {
				if (pInfo=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))) {
					memcpy(pInfo,&InfoParm,sizeof(tdtInfoParm));
					pInfo->pi_scale |= D_DATA_ARRAY_INDEX;	/* 0x10 */
					*ppArrayInfo = pInfo;
				}
				else {
					ERROROUT1(FORMAT(217),_fn_);	/* %s: ArrayInfo area malloc. */
					rc = -215210301;
				}
			}
			return rc;
		}
		pInfo = &InfoParm;
		if (rc=cl_check_data_id(pInfo,0)) return rc+ECL_CHK_VAR_ERROR;
		if (pInfo->pi_id == D_DATA_ID_STOREVAR) {
			pInfo = (tdtInfoParm *)pInfo->pi_pos;
			if (rc=cl_check_data_id(pInfo,0)) return rc+ECL_CHK_VAR_ERROR;
		}
		if (pInfo->pi_attr == DEF_ZOK_CHAR) {
			index = _check_index(pInfo->pi_data,pInfo->pi_dlen,varnam);
		}
		else if (rc = cl_get_parm_bin(pInfo,&index,"cl_gx_get_index_array: ")) {
			iParm[0] = pInfo->pi_attr;
			iParm[1] = iParm[2] = iParm[3] = 0;
			ERROROUT2(FORMAT(218),_fn_,cl_get_attr_name(iParm));	/* %s: INDEX�̌^[%s]�������Ă��܂���B */
			return -215210302;
		}
	/* 2001.1.4 Koba
	*	if (InfoParm.pi_scale & 0x80) Free(InfoParm.pi_data);
	*/
	}
	else {
		index = _check_index(vname,vnlen,varnam);
	}
	return index;
}

/************************************/
/*	11	215211101					*/
/************************************/
static int _iterate_push(stack,pIter,m_alloc)
tdtRbCtl *stack;
tdtIterate *pIter;
char *(*m_alloc)();
{
	tdtIterate *pIter1;
	int ret;
/*
printf("_iterate_push:Enter\n");
*/
	if (!stack || !pIter) ret = -215211101;
	else {
		if (!(pIter1 = (tdtIterate *)akxm_malloc_constct(m_alloc,NULL,sizeof(tdtIterate)))) ret = -215211102;
		else {
			*pIter1 = *pIter;
			if (!akxs_rb_set_t(stack,pIter1)) ret = -215211103;
/*
printf("_iterate_push:Exit pIter1=%016lx\n",pIter1);
*/
		}
	}
	return ret;
}

/************************************/
/*	12	215211201					*/
/************************************/
static tdtIterate *_iterate_pop(stack)
tdtRbCtl *stack;
{
	tdtIterate *iterate;
/*
printf("_iterate_pop:Enter\n");
*/
	if (stack) iterate = (tdtIterate *)akxs_rb_get_n(stack);
	else iterate = NULL;
/*
printf("_iterate_pop:Exit iterate=%016lx\n",iterate);
*/
	return iterate;
}

/************************************/
/*	13	�z�Q�Ɠo�^addr�擾		*/
/************************************/
static char *_iterate_get_circ_addr(pIter)
tdtIterate *pIter;
{
	tdtArrayIndex *pIndex;
	char *p,id;
#if 1
	id = pIter->it_id;
	if (id=='R' || id=='A') {
		if (!(p = (char *)pIter->it_pTBL)) {
			if (pIndex = pIter->it_pIndex) {
				if (!(p = (char *)pIndex->xhp)) p = (char *)pIndex->pVarIndex;
			}
		}
	}
	else if (id=='L' || id=='N') {
		p = (char *)pIter->it_pCt;
	}
	else p = (char *)pIter;
#else
	if (!(p=(char *)pIter->it_xhp)) {
		if (!(p = (char *)pIter->it_pTBL)) {
			if (pIndex=pIter->it_pIndex) p = (char *)pIndex->pVarIndex;
		}
	}
#endif
/*
printf("_iterate_get_circ_addr: pIter=%016lx p=%016lx it_pTBL=%016lx xhp=%016lx pVarIndex=%016lx\n",pIter,p,pIter->it_pTBL,pIndex->xhp,pIndex->pVarIndex);
*/
	return p;
}

/************************************/
/*	14	�z�Q�ƃ`�F�b�N			*/
/************************************/
int _iterate_circ_ref2(pIter_circ_ref,pVal,msg)
MCAT2 *pIter_circ_ref;
char *pVal,*msg;
{
	static char *_fn_ = "_iterate_circ_ref2";
	int ret,i;
#if 1
	MCAT2 *hp;
#else
	HASHB *hp;
#endif
	char *p1,*p2;

DEBUGOUTL3(180,"%s:Enter pVal=%016lx msg=[%s]",_fn_,pVal,nvalid(msg,""));
/*
printf("%s:Enter pIter_circ_ref=%016lx pVal=%016lx msg=[%s]\n",_fn_,pIter_circ_ref,pVal,nvalid(msg,""));
*/

	ret = 0;
	if (!(hp=pIter_circ_ref)) ret = -215211401;
	else if (!pVal) ret = -215211402;
#if 1
	else if ((i=akxs_layer_r(hp,(long)pVal)) < 0) ret = -215211403;
#else
	else if ((i=akxs_seql_r(hp,(long)pVal)) < 0) ret = -215211403;
#endif
	else if (i > 0) {
		ERROROUT1(FORMAT(626),nvalid(msg,""));	/* %s �ŏz�Q�Ƃ��������܂����B*/
		ret = 1;
	}
	else {
#if 1
		if ((i=akxs_layer_s(hp,(long)pVal)) < 0) ret = i;
#else
		if ((i=akxs_seql_s(hp,(long)pVal)) < 0) ret = i;
#endif

DEBUGOUTL3(180,"%s: i=%d pVal=%016lx",_fn_,i,pVal);
/*
printf("%s: i=%d pVal=%016lx\n",_fn_,i,pVal);
*/

	}
DEBUGOUTL2(180,"%s:Exit ret=%d",_fn_,ret);
/*
printf("%s:Exit ret=%d\n",_fn_,ret);
*/
	return ret;
}

/************************************/
/*	15	�z�Q�ƃ`�F�b�N			*/
/************************************/
int _iterate_circ_ref(pIter_ctl,pVal,msg)
tdtIterate_ctl *pIter_ctl;
char *pVal,*msg;
{
	return _iterate_circ_ref2(pIter_ctl->itc_circ_ref,pVal,msg);
}

/************************************/
/*	16								*/
/************************************/
static int _iterate_set(pIter,pInfoParmW,m_alloc)
tdtIterate *pIter;
tdtInfoParm *pInfoParmW;
char *(*m_alloc)();
{
	static char *_fn_ = "_iterate_set";
	int ret,iParm[4],ix1,nm1,iVal[2],i,atr1,len,m1;
	char id,*p1;
	tdtInfoParm ***pTBL1,*ppParm[3],*p,*pInfo,tInfoParm;
	tdtArrayIndex tIndex1,*pIndex1;
	tdtRbCtl *pCt;
	XHASHB *xhp;

	ret = 0;
	memset(pIter,0,sizeof(tdtIterate));
	id = pInfoParmW->pi_id;

DEBUGOUTL2(180,"%s:Enter id=[%c]",_fn_,id);

	if (id=='A' || id=='R') {
		if (id=='R' && (pInfoParmW->pi_scale & D_DATA_INDEX_TMP)) {
/*
printf("_iterate_set: D_DATA_INDEX_TMP<>0 id=[%c]\n",id);
*/
			if (!(pInfo=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
			pIter->it_pInfoW = pInfo;
			cl_gx_copy_info(&tInfoParm,pInfoParmW);
			tInfoParm.pi_aux[0] |= DEF_ZOK_DATA;
			if ((ret=cl_gx_rep_info_set_ign(pInfo,&tInfoParm,1)) < 0) return ret;
DEBUGOUT_InfoParm(190,"_iterate_set: id=[%c] ret=%d pInfo=",pInfo,id,ret);
		}
		else pInfo = pInfoParmW;
		pIndex1 = &tIndex1;
		if ((ret=cl_get_array_info_ref(pInfo,&pIndex1,&pTBL1,iParm)) >= 0) {
			pIter->it_pIndex = pIndex1;
			pIter->it_pTBL = pTBL1;
			xhp = pIndex1->xhp;
		/*	pIter->it_xhp = xhp;	*/
			pIter->it_ix = iParm[2];
			if (xhp) {
				nm1 = iParm[1];
				if (!iParm[3]) nm1 = 0;
				pIter->it_nm = nm1;
#if 1	/* 2026.4.28 */
				if (akxs_xhash(xhp,'T',NULL) > 0) {
					if (!xhp->xha_xhix) pIter->it_interval = 1;
				}
			/*	pIter->it_ix = 0;	*/
#endif
			}
			else {
				nm1 = iParm[3] - iParm[2] + 1;
				pIter->it_nm = nm1;
			}

DEBUGOUTL3(180,"%s: nm1=%d ix1=%d",_fn_,pIter->it_nm,pIter->it_ix);

			ret = 0;
			pIter->it_id = 'R';
		}
	}
	else if (id=='L' || id=='N') {
		if (pInfoParmW->pi_scale & D_DATA_INDEX_TMP) {
/*
printf("_iterate_set: D_DATA_INDEX_TMP<>0 id=[%c]\n",id);
*/
			if (!(pInfo=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
			pIter->it_pInfoW = pInfo;
			if ((ret=cl_gx_rep_info_set_ign(pInfo,pInfoParmW,1)) < 0) return ret;
DEBUGOUT_InfoParm(190,"_iterate_set: id=[%c] ret=%d pInfo=",pInfo,id,ret);
		}
		else pInfo = pInfoParmW;
		pCt = (tdtRbCtl *)pInfo->pi_data;
		pIter->it_pCt = pCt;
		pIter->it_id = 'L';
		pIter->it_ix = 1;
		if ((nm1=akxs_rb_used(pCt)) >= 0) {
			akxs_rb_read(pCt,0);
			pIter->it_nm = nm1;
		}
		else return nm1;

	}
	else if (id == ' ') {
		if ((pInfoParmW->pi_alen & D_AULN_RANGE_DATA) &&
		    (pInfoParmW->pi_aux[0] & DEF_ZOK_DATA)) {
			if (p = (tdtInfoParm *)akxm_malloc_constct(m_alloc,NULL,sizeof(tdtInfoParm)*4)) {
				ppParm[0] = p++;
				ppParm[1] = p++;
				ppParm[2] = p++;
				ppParm[3] = p;
				if ((ret=cl_get_range_info(pInfoParmW,ppParm,iVal,1)) >= 0) {
					pInfo = ppParm[0];								/* �J�n */

DEBUGOUT_InfoParm(180,"%s:pInfo",pInfo,_fn_,0);

					pIter->it_cur    = pInfo;
					pIter->it_pTBL   = (tdtInfoParm ***)ppParm[1];	/* 3:���Ԃ̓� */
					pIter->it_pIndex = (tdtArrayIndex *)ppParm[2];	/* ���� */
					pIter->it_pCt    = (tdtRbCtl *)ppParm[3];		/* ���t�pinterval */
					pIter->it_nm       = iVal[0];
					pIter->it_interval = iVal[1];
					pIter->it_attr =  pInfoParmW->pi_attr;
					pIter->it_id   = 'G';
					atr1 = pInfo->pi_attr;
					len  = pInfo->pi_dlen;
					pIter->it_rsv[0] = ret & 0x01;	/* iINTVAL */
					pIter->it_rsv[1] = 0;

DEBUGOUTL5(180,"%s: atr1=%d len=%d nm1=%d interval=%d",_fn_,atr1,len,iVal[0],iVal[1]);

					if (atr1 == DEF_ZOK_BINA)
					/*	cl_gx_copy_info(p,pInfo)*/;
					else  {
						len = X_MAX(len+1,5);
						if (!(p1=akxm_malloc_constct(m_alloc,NULL,len))) return ECL_MALLOC_ERROR;
						memcpy(p1,pInfo->pi_data,len);
						pInfo->pi_data = p1;
						if (atr1 == DEF_ZOK_CHAR) {
							m1 = akxqkanjilen(p1);
							pIter->it_ix = akxcmb2ul(p1,m1);
							*(p1+m1) = '\0';

DEBUGOUTL3(180,"%s: m1=%d p1=[%s]",_fn_,m1,p1);

							pInfo->pi_dlen = m1;
						}
						else if (atr1 == DEF_ZOK_DATE) {
							cl_set_parm_long(ppParm[3],iVal[1]);
							if (!(i=ppParm[2]->pi_hlen)) i = 3;
							cl_set_parm_long(ppParm[1],i);
						}
					}

DEBUGOUT_InfoParm(180,"%s:pInfo atr1=%d",pInfo,_fn_,atr1);
DEBUGOUT_InfoParm(180,"%s:p     atr1=%d",p,_fn_,atr1);

					ret = 0;
				}
			}
			else ret = ECL_MALLOC_ERROR;
		}
	}
	else ret = -215211501;
DEBUGOUTL2(180,"%s:Exit ret=%d",_fn_,ret);
	return ret;
}

/****************************************/
/*	21	215212101						*/
/****************************************/
int cl_iterate_info_init2(pIter_ctl,pParm,max_layer,m_alloc)
tdtIterate_ctl *pIter_ctl;
tdtInfoParm	*pParm;
int max_layer;
char *(*m_alloc)();
{
	static char *_fn_ = "cl_iterate_info_init2";
	int  ret,ex_opt;
	char id,wk[2],id0,*nam,*p;
	tdtInfoParm *pInfoParmW,tInfoParmW,*pInfoParm;
	tdtIterate *pIter;
	MCAT *pM;

DEBUGOUTL5(180,"%s:Enter pIter_ctl=%016lx pParm=%016lx max_layer=%d m_alloc=%016lx",_fn_,pIter_ctl,pParm,max_layer,m_alloc);

	if (!pIter_ctl) return -215212101;
	memset(pIter_ctl,0,sizeof(tdtIterate_ctl));
	if (!pParm) return -215212103;

	pInfoParm = NULL;
	if (!(pIter = (tdtIterate *)akxm_malloc_constct(m_alloc,NULL,sizeof(tdtIterate)))) return ECL_MALLOC_ERROR;
	memset(pIter,0,sizeof(tdtIterate));
	pIter_ctl->itc_pIter = pIter;

	/* �K�w�Ǘ��p�X�^�b�N�̒�` */
	if (!(pIter_ctl->itc_stack = akxs_rb_new2(0,0,m_alloc,NULL))) {
		ret = -215212102;
		goto Err;
	}
	/* �W�J�K�w���̍ő�񐔂̐ݒ� */
	if (max_layer < 0) max_layer = INT_MAX;
	ex_opt = cl_get_option(2,0);
	if (!(ex_opt & 0x20)) {
		if (max_layer > MAX_ITERATE_LAYER) max_layer = MAX_ITERATE_LAYER;
	}
	pIter_ctl->itc_max_layer = max_layer;
	pIter_ctl->itc_layer = 0;
	pIter_ctl->itc_malloc = m_alloc;

	/* �z�Q�ƃ`�F�b�N�p�T�[�`��` */
	if (!(pIter_ctl->itc_circ_ref=akxs_layer_new(10,m_alloc,NULL))) {
		ret = -215212104;
		goto Err;
	}

#if 1
	pInfoParmW = pParm;
#else
	if (!prmp && !pParm) {
		return 0;
	}
	if (pParm) pInfoParmW = pParm;
	else {
		pInfoParmW = &tInfoParmW;
		if (ret=cl_gx_exp_obj_opt(1,prmp,NULL,pInfoParmW,D_GX_OPT_GET_ADDR)) return ret;
	}
#endif
	ret = 0;
	id0 = id = pInfoParmW->pi_id;

DEBUGOUTL2(180,"%s: id0=[%c]",_fn_,id0);

	if (id == 'S') {
		pInfoParmW = (tdtInfoParm *)pInfoParmW->pi_pos;
		id = pInfoParmW->pi_id;

DEBUGOUTL2(180,"%s: id=[%c]",_fn_,id);

	}
	if (cl_is_undef_parm(pInfoParmW) || cl_is_null_parm(pInfoParmW) || id == ' ') {
		if (id0 != 'S') {
			if (pInfoParm = (tdtInfoParm *)akxm_malloc_constct(m_alloc,NULL,sizeof(tdtInfoParm)))
				pInfoParmW = cl_gx_copy_info(pInfoParm, pInfoParmW);
			else ret = ECL_MALLOC_ERROR;
		}
		if (!ret) {
			if ((pInfoParmW->pi_alen & D_AULN_RANGE_DATA) &&
			    (pInfoParmW->pi_aux[0] & DEF_ZOK_DATA)) {
				ret = _iterate_set(pIter,pInfoParmW,m_alloc);
			}
			else {
				pIter->it_id = ' ';
				pIter->it_pInfo = pInfoParmW;
				pIter->it_nm = 1;
			}

DEBUGOUTL2(180,"%s: it_nm=%d",_fn_,pIter->it_nm);

		}
	}
	else if (id=='A' || id=='R') {
		if (!(ret = _iterate_set(pIter,pInfoParmW,m_alloc))) {
			p = _iterate_get_circ_addr(pIter);
			nam = (char *)pInfoParmW->pi_pos;
		}
	}
	else if (id=='L' || id=='N') {
		if (!(ret = _iterate_set(pIter,pInfoParmW,m_alloc))) {
			p = (char *)pIter->it_pCt;
			nam = cl_gx_get_name_from_id(id);
		}
	}
	else ret = -200;
	if (ret < 0) {
		if (ret == -200) {
			nam = cl_gx_get_name_from_id(id);
			wk[0] = id;
			wk[1] = '\0';
			ERROROUT2(FORMAT(155),wk,nam);	/* %s(%s)�͎w��ł��܂���B*/
			ret = -215212105;
		}
	}
	else if ((id=pIter->it_id)=='R' || id=='L') {
		if ((ret=_iterate_circ_ref(pIter_ctl,p,nam)) == 1) ret = -215210706;
	}
DEBUGOUTL2(180,"%s:Exit ret=%d",_fn_,ret);
	if (!ret) return ret;
Err:
	if (!m_alloc) {
		if (pInfoParm) Free(pInfoParm);
		cl_iterate_info_free(pIter_ctl);
	}
	return ret;
}

/****************************************/
/*	22	215212201						*/
/****************************************/
int cl_iterate_info(pIter_ctl)
tdtIterate_ctl *pIter_ctl;
{
	static char *_fn_ = "cl_iterate_info";
	tdtIterate *pIter,*pIter1;
	tdtInfoParm *pInfoParm;
	char id;
	int ret;
	tdtRbCtl *stack;

	if (!pIter_ctl) return -215212201;

	pIter = pIter_ctl->itc_pIter;
	if (!pIter) return -215212202;

DEBUGOUTL2(180,"%s:Enter it_nm=%d",_fn_,pIter->it_nm);

	stack = pIter_ctl->itc_stack;
	if (!stack) return -215212203;

	ret = 0;
	while (!ret) {

DEBUGOUTL2(180,"%s: it_nm=%d",_fn_,pIter->it_nm);

		if (pIter->it_nm <= 0) {
			if (pIter1 = _iterate_pop(stack)) {
				if (pIter_ctl->itc_layer > 0) pIter_ctl->itc_layer--;
				if (pIter_ctl->itc_malloc) *pIter = *pIter1;
				else {
					Free(pIter);
					pIter_ctl->itc_pIter = pIter = pIter1;
				}

DEBUGOUTL2(180,"%s: itc_layer=%d",_fn_,pIter_ctl->itc_layer);

			}
			else {
				pIter->it_pInfo = NULL;
				break;
			}
		}
		ret = cl_iterate_info_sub(pIter_ctl);
		if (ret == 1) ret = 0;
		else if (pIter->it_pInfo) break;
	}
DEBUGOUTL2(180,"%s:Exit ret=%d",_fn_,ret);
	return ret;
}

/****************************************/
/*	23	215212301						*/
/****************************************/
int cl_iterate_info_sub(pIter_ctl)
tdtIterate_ctl *pIter_ctl;
{
	static char *_fn_ = "cl_iterate_info_sub";
	tdtIterate *pIter,*pIter1;
	tdtInfoParm *pInfoParm;
	char id,*cpDat,wrk[5];
	int ret,i,ix,nm,atr1,ic,m1,iNEXT_I;
	tdtRbCtl *stack;
	XHASHB *xhp;
	tdtInfoParm ***pTBL,*pInfo,*pInfo2,*pInfo3,tInfo2,*ppInfo[3];
	tdtArrayIndex *pIndex;

	if (!pIter_ctl) return -215212301;

	pIter = pIter_ctl->itc_pIter;
	if (!pIter) return -215212302;

DEBUGOUTL2(180,"%s:Enter it_nm=%d",_fn_,pIter->it_nm);

	stack = pIter_ctl->itc_stack;
	if (!stack) return -215212303;

	ret = 0;
	id = pIter->it_id;

DEBUGOUTL2(180,"%s: id=[%c]",_fn_,id);

	if (id == ' ') {
		pIter->it_nm = 0;
	}
	else if (id == 'R') {
		if (pIter->it_nm > 0) {
			pInfoParm = NULL;
			pIndex = pIter->it_pIndex;
			pTBL   = pIter->it_pTBL;
			ix     = pIter->it_ix;
			pIter->it_pCt = NULL;
			xhp = pIndex->xhp;
			nm = pIter->it_nm;
			iNEXT_I = pIter->it_interval;
/*
printf("%s: xhp=%08x nm=%d ix=%d iNEXT_I=%d\n",_fn_,xhp,nm,ix,iNEXT_I);
*/
			while (nm > 0) {
#if 1	/* 2026.4.28 */
				if (iNEXT_I) {
					ix = akxs_xhash_next_i(0,xhp,0);
					if (ix == AKX_HASH_NEXT_BREAK) {
						ix = nm + 1;
						nm = 0;
						break;
					}
				}
#endif
/*
printf("%s: nm=%d ix=%d\n",_fn_,nm,ix);
*/
				ret = cl_array_get_info_parm(&pInfoParm,pIndex,pTBL,ix,'r');
#if 1	/* 2026.4.28 */
				ix++;
				nm--;
#endif
/*
printf("%s: ret=%d\n",_fn_,ret);
*/
				if (!akxm_addrchk(pInfoParm)) {
					pInfoParm = NULL;
				/*	ret = -215212305;	*/
				}
				if (pInfoParm) {
					if (xhp) {
#if 1	/* 2026.9.14 */
						pIter->it_xh_pkey = xhp->xha_hashb->ha_key;

DEBUGOUTL2(180,"%s: it_xh_pkey=[%s]",_fn_,pIter->it_xh_pkey);

#else
						pIter->it_pCt = (tdtRbCtl *)xhp->xha_hashb->ha_key;

DEBUGOUTL2(180,"%s: it_pCt=[%s]",_fn_,pIter->it_pCt);

#endif
					}
					if (pIter->it_rsv[0] & 0x04) break;
					else {
#if 1	/* 2026.3.13 */
						if (!cl_is_undef_parm(pInfoParm) && !cl_is_null_parm(pInfoParm)) break;
#else
						if (!cl_is_undef_parm(pInfoParm)) break;
#endif
					}
				}
				else if (ret < 0) break;
#if 0	/* 2026.4.28 */
				ix++;
				nm--;
#endif
			}
/*
printf("%s: nm=%d ix=%d pInfoParm=%08x\n",_fn_,nm,ix,pInfoParm);
*/
			pIter->it_ix = ix;
			pIter->it_nm = nm;
			if (pInfoParm) {
				if (pInfoParm->pi_id == 'S') pInfoParm = (tdtInfoParm *)pInfoParm->pi_pos;
			}
			pIter->it_pInfo = pInfoParm;
			if (ret >= 0) {
#if 1	/* 2026.4.28 */
				if (pInfoParm) {
#else
				if (pIter->it_nm > 0) {
					pIter->it_ix++;
					pIter->it_nm--;
#endif
					ret = cl_iterate_info_check(pIter_ctl,pInfoParm);
				}
			}
		}
		else {
			pIter->it_pInfo = NULL;
			pIter->it_nm = 0;
			/* �z�Q�Ɠo�^��POP���� */
			if ((ret=_iterate_circ_pop(pIter_ctl)) < 0) return ret;
		}
	}
	else if (id == 'L') {
#if 1	/* 2026.3.13 */
		for (;;) {
			pInfoParm = (tdtInfoParm *)akxs_rb_read(pIter->it_pCt,1);
			if (pInfoParm) {
				if (pInfoParm->pi_id == 'S') pInfoParm = (tdtInfoParm *)pInfoParm->pi_pos;
			}
			if (pInfoParm) {
				if (pIter->it_rsv[0] & 0x04) break;
				else {
					if (!cl_is_undef_parm(pInfoParm) && !cl_is_null_parm(pInfoParm)) break;
				}
			}
			else break;
		}
#else
		pInfoParm = (tdtInfoParm *)akxs_rb_read(pIter->it_pCt,1);
		if (pInfoParm) {
			if (pInfoParm->pi_id == 'S') pInfoParm = (tdtInfoParm *)pInfoParm->pi_pos;
		}
#endif
		if (pIter->it_pInfo = pInfoParm) {
			pIter->it_ix++;
			ret = cl_iterate_info_check(pIter_ctl,pInfoParm);
		}
		else {
			pIter->it_nm = 0;
			/* �z�Q�Ɠo�^��POP���� */
			if ((ret=_iterate_circ_pop(pIter_ctl)) < 0) return ret;
		}
	}
	else if (id == 'G') {
		if (pIter->it_rsv[1]) {
			pInfo = pIter->it_cur;
			atr1 = pIter->it_attr;

DEBUGOUT_InfoParm(180,"%s: atr1=%d",pInfo,_fn_,atr1);

			if (atr1 == DEF_ZOK_CHAR) {
				ic = pIter->it_ix + pIter->it_interval;
				m1 = akxcul2mb(pInfo->pi_data,ic);
				pInfo->pi_dlen = m1;
				pIter->it_ix = ic;
			}
			else {
				if (pIter->it_rsv[0] & 0x01) {	/* INTVAL���� */
					pInfo2 = &tInfo2;
					pInfo3 = (tdtInfoParm *)pIter->it_pIndex;
					if (atr1 == DEF_ZOK_DATE) {
						ppInfo[0] = pInfo;
						ppInfo[1] = (tdtInfoParm *)pIter->it_pTBL;
						ppInfo[2] = (tdtInfoParm *)pIter->it_pCt;
						ret = cl_func_add_to_date(pInfo2,3,ppInfo);
					}
					else ret = cl_gx_bexp(pInfo2,pInfo,"+",pInfo3,0,0);
					cl_gx_copy_info2(pInfo,pInfo2);
				}
				else ret = _gx_ppmm(14,pInfo);
			}
		}
		pIter->it_pInfo = pIter->it_cur;
		pIter->it_rsv[1] = 1;
		pIter->it_nm--;

DEBUGOUTL2(180,"%s: it_nm=%d",_fn_,pIter->it_nm);

	}
/*	else ret = -215212304;	*/
	else pIter->it_nm = 0;
DEBUGOUTL2(180,"%s:Exit ret=%d",_fn_,ret);
/*
if (ret) printf("%s: ret=%d\n",_fn_,ret);
*/
	return ret;
}

/****************************************/
/*	24	215212401						*/
/****************************************/
int cl_iterate_info_check(pIter_ctl,pInfoParmW)
tdtIterate_ctl *pIter_ctl;
tdtInfoParm *pInfoParmW;
{
	static char *_fn_ = "cl_iterate_info_check";
	tdtIterate *pIter;
	tdtRbCtl *stack;
	tdtArrayIndex *pIndex;
	int ret,iTENKAI,alen,iRANGE;
	char id,wk[2],*nam,*nam1,*nam2,*p;

	ret = 0;
	pIter = pIter_ctl->itc_pIter;
	stack = pIter_ctl->itc_stack;
	id = pInfoParmW->pi_id;

DEBUGOUTL2(180,"%s:Enter id=[%c]",_fn_,id);
/*printf("%s:Enter id=[%c]\n",_fn_,id);*/
DEBUGOUT_InfoParm(180,"%s:",pInfoParmW,_fn_,0);

#if 1	/* 2025.5.21 */
	iRANGE = 0;
	if (id == ' ') {
		alen = pInfoParmW->pi_alen;
		if (iRANGE = (alen & D_AULN_RANGE_DATA)) {
			if (alen & (D_AULN_COMPLEX_DATA | D_AULN_RATIONAL)) iRANGE = 0;
		}
	}
	if (id=='A' || id=='R' || id=='L' || id=='N' || (id==' ' && iRANGE)) {
#else
	if (id=='A' || id=='R' || id=='L' || id=='N' ||
	    (id==' ' && (pInfoParmW->pi_alen & D_AULN_RANGE_DATA))) {
#endif
		iTENKAI = 1;
/*
printf("%s: itc_max_layer=%d itc_layer=%d\n",_fn_,pIter_ctl->itc_max_layer,pIter_ctl->itc_layer);
*/
		if (pIter_ctl->itc_max_layer >= 0) {
			if (pIter_ctl->itc_layer >= pIter_ctl->itc_max_layer) iTENKAI = 0;
		}
		if (iTENKAI) {
/*
printf("%s: TENKAI id=[%c]\n",_fn_,id);
*/
			if (id == ' ') pInfoParmW->pi_aux[0] |= DEF_ZOK_DATA;
			pIter_ctl->itc_layer++;
			_iterate_push(stack,pIter,pIter_ctl->itc_malloc);
			if (!(ret = _iterate_set(pIter,pInfoParmW,pIter_ctl->itc_malloc))) {
				if (id != ' ') {
					/* �z�Q�ƃ`�F�b�N */
					nam1 = cl_gx_get_name_from_id(id);
					if ((id=pIter->it_id) == 'R') {
						p = _iterate_get_circ_addr(pIter);
						nam2 = (char *)pInfoParmW->pi_pos;
						nam = stradd5(nam1,"(",nam2,")","");
					}
					else {
						p = (char *)pIter->it_pCt;
						nam = nam1;
					}
					if ((ret=_iterate_circ_ref(pIter_ctl,p,nam)) == 1) {
						pIter->it_nm = 0;
					}
					else if (!ret) ret = 1;
				}
			}

DEBUGOUTL3(180,"%s: ret=%d itc_layer=%d",_fn_,ret,pIter_ctl->itc_layer);

		}
	}
#if 0
	else if (cl_is_undef_parm(pInfoParmW) || cl_is_null_parm(pInfoParmW) || id == ' ') {
		;
	}
	else {
		nam = cl_gx_get_name_from_id(id);
		wk[0] = id;
		wk[1] = '\0';
		ERROROUT2(FORMAT(155),wk,nam);	/* %s(%s)�͎w��ł��܂���B*/
		ret = -215212401;
	}
#endif
DEBUGOUTL2(180,"%s:Exit ret=%d",_fn_,ret);
	return ret;
}

/****************************************/
/*	25	215212501						*/
/****************************************/
int cl_iterate_info_init(pIter_ctl,prmp,pParm,max_layer)
tdtIterate_ctl *pIter_ctl;
parmList *prmp[];
tdtInfoParm	*pParm;
int max_layer;
{
	tdtInfoParm	*pInfoParmW,tInfoParmW;
	int ret;

DEBUGOUTL4(180,"cl_iterate_info_init:Enter pIter_ctl=%016lx prmp=%016lx pParm=%016lx max_layer=%d",pIter_ctl,prmp,pParm,max_layer);

	if (!prmp && !pParm) {
		return 0;
	}
	if (pParm) pInfoParmW = pParm;
	else {
		pInfoParmW = &tInfoParmW;
		if (ret=cl_gx_exp_obj_opt(1,prmp,NULL,pInfoParmW,D_GX_OPT_GET_ADDR)) return ret;
	}
	return cl_iterate_info_init2(pIter_ctl,pInfoParmW,max_layer,cl_tmp_const_malloc);
}

/****************************************/
/*	26	215212601						*/
/****************************************/
int cl_iterate_info_free(pIter_ctl)
tdtIterate_ctl *pIter_ctl;
{
	int ret;
	char *p;
	tdtIterate *pIter;
	MCAT2 *pM;
/*
printf("cl_iterate_info_free: pIter_ctl=%016lx\n",pIter_ctl);
*/
	if (pIter_ctl) {
		if (!(pIter_ctl->itc_malloc)) {
			if (pIter=pIter_ctl->itc_pIter) {
/*
printf("cl_iterate_info_free: pIter=%016lx\n",pIter);
*/
				Free(pIter);
			}
			if (p=(char *)pIter_ctl->itc_stack) {
/*
printf("cl_iterate_info_free: itc_stack p=%016lx\n",p);
*/
				akxs_rb_free(p);
			}
			if (pM=pIter_ctl->itc_circ_ref) {
/*
printf("cl_iterate_info_free: pM=%016lx mc_malloc=%016lx\n",pM,pM->mc_malloc);
*/
				if (!pM->mc_malloc) {
					if (p=pM->mc_bufp) {
/*
printf("cl_iterate_info_free: mc_bufp p=%016lx\n",p);
*/
						Free(p);
					}
					Free(pM);
				}
			}
		}
		ret = 0;
	}
	else ret = -215212601;
	return ret;
}

/****************************************/
/*	27	215212701						*/
/****************************************/
int _iterate_circ_pop(pIter_ctl)
tdtIterate_ctl *pIter_ctl;
{
	static char *_fn_ = "_iterate_circ_pop";
	int ret;
	long Val;
	MCAT2 *mcat2;

DEBUGOUTL1(180,"%s:Enter",_fn_);

	if (!(mcat2=pIter_ctl->itc_circ_ref)) ret = -215212701;
	ret = akxs_mseq_del(mcat2,0,&Val);

DEBUGOUTL2(180,"%s: ret=%d",_fn_,ret);

	if (ret > 0) ret = 0;
	return ret;
}

/****************************************/
/*	28	215212801						*/
/****************************************/
int cl_iterate_info_init2_opt(pIter_ctl,pInfoParm,max_layer,opt,m_alloc)
tdtIterate_ctl *pIter_ctl;
tdtInfoParm *pInfoParm;
int max_layer,opt;
char *(*m_alloc)();
{
	tdtInfoParm tInfoW;
	int rc;

DEBUGOUTL4(180,"cl_iterate_info_init2_opt:Enter pIter_ctl=%08x pInfoParm=%08x max_layer=%d opt=%08x",pIter_ctl,pInfoParm,max_layer,opt);

	if ((rc=cl_info2maparray(&tInfoW,pInfoParm,NULL,opt)) >= 0) {
		if (rc) pInfoParm = &tInfoW;
		rc = cl_iterate_info_init2(pIter_ctl,pInfoParm,max_layer,m_alloc);
	}
	return rc;
}

/****************************************/
/*	29	215212901						*/
/****************************************/
int cl_iterate_info_init_opt(pIter_ctl,prmp,pParm,max_layer,opt)
tdtIterate_ctl *pIter_ctl;
parmList *prmp[];
tdtInfoParm *pParm;
int max_layer,opt;
{
	tdtInfoParm *pInfoParmW,tInfoParmW;
	int rc;

DEBUGOUTL5(180,"cl_iterate_info_init_opt:Enter pIter_ctl=%08x prmp=%08x pParm=%08x max_layer=%d opt=%08x",pIter_ctl,prmp,pParm,max_layer,opt);

	if (!prmp && !pParm) {
		return 0;
	}
	if (pParm) pInfoParmW = pParm;
	else {
		pInfoParmW = &tInfoParmW;
		if ((rc=cl_gx_exp_obj_opt(1,prmp,NULL,pInfoParmW,D_GX_OPT_GET_ADDR)) < 0) return rc;
	}

	return cl_iterate_info_init2_opt(pIter_ctl,pInfoParmW,max_layer,opt,cl_tmp_const_malloc);
}

/****************************************/
/*	31	215213101						*/
/****************************************/
int cl_new_array_or_list(pInfoParmW,pIter)
tdtInfoParm *pInfoParmW;
tdtIterate *pIter;
{
	char id;
	tdtArrayIndex *pIndex,*pIndexW;
	tdtInfoParm *pInfoW;
	tdtRbCtl *pCt;
	int rc,ary_opt,nm,*index;

	rc = 0;
	id = pIter->it_id;
	nm = pIter->it_nm;
DEBUGOUTL2(140,"cl_new_array_or_list: id=[%c] nm=%d",id,nm);
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		if (!(pCt = cl_tmp_rb_new(0,0,NULL))) return ECL_MALLOC_ERROR;
		pIter->it_pCt = pCt;
		if (pInfoParmW) {
			memset(pInfoParmW,0,sizeof(tdtInfoParm));
			pInfoParmW->pi_id   = id;
			pInfoParmW->pi_attr = DEF_ZOK_BULK;
			pInfoParmW->pi_dlen = sizeof(tdtRbCtl);
			pInfoParmW->pi_data = (char *)pCt;
		}
	}
	else if (id=='A' || id=='R') {
		if (nm <= 0) {
			cl_null_value(pInfoParmW);
		}
		else {
			pIndex = pIter->it_pIndex;
			if (pIndex->xhp) ary_opt = 1;
			else ary_opt = 0;
			if ((rc=cl_def_array_tmp_opt(&pInfoW,nm,NULL,ary_opt)) < 0) return rc;
			if (pInfoParmW) cl_gx_copy_info(pInfoParmW,pInfoW);
			pIndex = (tdtArrayIndex *)pInfoW->pi_data;
			pIter->it_pIndex = pIndex;
			index = pIndex->index;
			index[2] = 0;
		}
	}
	else if (id == ' ') {
		cl_null_value(pInfoParmW);
	}
	else rc = -1;
/*
printf("cl_new_array_or_list:Exit rc=%d\n",rc);
*/
	return rc;
}

/****************************************/
/*	32	215213201						*/
/****************************************/
int cl_set_array_or_list(pIter,pInfo,pIterI)
tdtIterate *pIter,*pIterI;
tdtInfoParm *pInfo;
{
	char id,*cpKey;
	tdtArrayIndex *pIndex,*pIndexW;
	tdtInfoParm *pInfoW,***pTBL;
	tdtRbCtl *pCt;
	int rc,ary_opt;
/*
printf("cl_set_array_or_list:Enter pIter=%08x pInfo=%08x pIterI=%08x\n",pIter,pInfo,pIterI);
*/
	rc = 0;
	id = pIter->it_id;
/*
printf("cl_set_array_or_list:Enter id=[%c]\n",id);
*/
DEBUGOUTL2(140,"cl_set_array_or_list: id=[%c] ix=%d",id,pIter->it_ix);
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		pCt = pIter->it_pCt;
		if (pIter->it_rsv[0] & 0x80 && (!pCt->rb_malloc || pCt->rb_malloc==malloc)) {
			if (!(pInfoW=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm))))
				return ECL_MALLOC_ERROR;
		}
		else {
			if (!(pInfoW=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))))
				return ECL_MALLOC_ERROR;
		}
		cl_gx_rep_info_set_ign(pInfoW,pInfo,1);
		if (!akxs_rb_set_n(pCt,pInfoW)) return ECL_MALLOC_ERROR;
	}
	else {
		pIndex = pIter->it_pIndex;
		if (pIndex->xhp) {
#if 1	/* 2026.9.14 */
			if (pIterI) cpKey = pIterI->it_xh_pkey;
			else cpKey = pIter->it_xh_pkey;
#else
			if (pIterI) cpKey = (char *)pIterI->it_pCt;
			else cpKey = (char *)pIter->it_xhp;
#endif
			rc = cl_gx_chk_vnam_info('s',pIndex->xhp,cpKey,strlen(cpKey),&pInfoW);
			if (rc <= 0) {
				if (!rc) rc = -215213201;
				return rc;
			}
			rc = 0;
		}
		else {
			pTBL = pIter->it_pTBL;
			rc = cl_array_get_info_parm(&pInfoW,pIndex,pTBL,pIter->it_ix,'s');
			if (rc <= 0) {
				if (!rc) rc = -215213202;
				return rc;
			}
			rc = 0;
		}
		cl_gx_rep_info_set(pInfoW,pInfo,1);
	}
	pIter->it_ix++;
/*
printf("cl_set_array_or_list:Exit rc=%d\n",rc);
*/
	return rc;
}

/****************************************/
/*	41	215214101						*/
/* igtIter_circ_ref_ix = 0,1,2 : �]���ʂ� */
/*					   < 0 : pgItr_circ_ref ���g�� */
/*	�z��ȊO�̂Ƃ��́A�ȉ��Ƃ���			*/
/*		pIndex : NULL					*/
/*		pTBL   : �����Ɏg�p����			*/
/****************************************/
int cl_gitr_circ_ref(pIndex,pTBL,nam)
tdtArrayIndex *pIndex;
tdtInfoParm ***pTBL;
char *nam;
{
	static char *_fn_="cl_gitr_circ_ref";
	int rc,ix;
	char *pVal;
	MCAT2 *p;

	rc = 0;
	p = NULL;
	/* �z�Q�Ə������`�F�b�N */

DEBUGOUTL4(120,"%s:Enter pIndex=%08x pTBL=%08x nam=[%s]",_fn_,pIndex,pTBL,nam);
/*
printf("%s:Enter pIndex=%08x pTBL=%08x pCtl=%08x nam=[%s]\n",_fn_,pIndex,pTBL,pCtl,nam);
*/
DEBUGOUTL2(120,"%s: igItr_circ_ref_ix=%d",_fn_,igItr_circ_ix);
/*
printf("%s: igtIter_circ_ref_ix=%d\n",_fn_,igItr_circ_ix);
*/
	if ((ix=igItr_circ_ix)>=0 || ix<=2) {
		if (ix > 0) ix--;
		p = gtIter_ctl[ix].itc_circ_ref;

DEBUGOUTL2(120,"%s: p=%08x",_fn_,p);
/*
printf("%s: p=%08x\n",_fn_,p);
*/
		if (!p) {
			if (!(p=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215214101;
			gtIter_ctl[ix].itc_circ_ref = p;
			pgItr_circ_ref = p;
		}
	}
	else if (igItr_circ_ix < 0) p = pgItr_circ_ref;
	if (p) {
		/* �z�Q�Ƃ��`�F�b�N */
		pVal = cl_get_circ_addr(pIndex,pTBL);

DEBUGOUTL3(120,"%s: p=%08x pVal=%08x",_fn_,p,pVal);

		if (pVal) rc = _iterate_circ_ref2(p,pVal,nam);
/*
printf("%s: p=%08x pVal=%08x\n",_fn_,p,pVal);
if (!((int)pVal & 0xffff0000)) akxaxdump("pIndex",pIndex,sizeof(tdtArrayIndex));
*/
	}

DEBUGOUTL2(120,"%s: rc=%d",_fn_,rc);
/*
printf("%s: rc=%d\n",_fn_,rc);
*/
	return rc;
}

/****************************************/
/*	42	215214201						*/
/****************************************/
int cl_gitr_circ_set(ix)
int ix;
{
	int rc;
/*
printf("cl_gitr_circ_set: ix=%d\n",ix);
*/
	rc = 0;
	if (ix>=0 && ix<=2) igItr_circ_ix = ix;
	else rc = -215214201;
	return rc;
}

/****************************************/
/*	43	215214301						*/
/****************************************/
int cl_gitr_circ_ref_clr(ix,opt)
int ix,opt;
{
	MCAT2 *p;
	int i,ii;
/*
printf("cl_gitr_circ_ref_clr: ix=%d opt=%d\n",ix,opt);
*/
	if (ix>=0 && ix<=3) {
		if (!ix) ix = 1;
		for (i=1;i<=2;i++) {
			if (ix & i) {
				ii = i - 1;
				gtIter_ctl[ii].itc_circ_ref = NULL;
				if (opt) {
					if (!(p=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215214301;
					gtIter_ctl[ii].itc_circ_ref = p;
				}
			}
		}
	}
	igItr_circ_ix = 0;
	return 0;
}

/****************************************/
/*	44	215214401						*/
/*	�z��ȊO�̂Ƃ��́A�ȉ��Ƃ���		*/
/*		pIndex : NULL					*/
/*		pTBL   : �����Ɏg�p����			*/
/****************************************/
int cl_gitr_circ_ref_ix(pIndex,pTBL,nam,ix)
tdtArrayIndex *pIndex;
tdtInfoParm ***pTBL;
char *nam;
int ix;
{
	int rc;

	if ((rc=cl_gitr_circ_set(ix)) >= 0)
		rc = cl_gitr_circ_ref(pIndex,pTBL,nam);
	return rc;
}
