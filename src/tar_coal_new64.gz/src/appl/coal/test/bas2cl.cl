//

proc main;
	try;
		loop;
			line = getline();
			if line=='' || is(line,'b') then
				putline('');
			else
				line = detab(line,4);
				line = replike(line,'''','//');
				line = replike(line,'"','''','g');
				line = replike(line,'Call','exec IP');
				line = replike(line,'Private S','S');
				line = replike(line,'Private F','F');
				putline(line & ';');
			end if;
		end loop;
	catch FILE_READ_END_EXCEPTION;
	catch;
		print errmsg;
	end try;
	return ERROR;
end proc;

func detab(line,nt);
	return line;
end func;
