//
proc main;
	print 'Hellow world!!';
	output tn 'Hellow world!!';
//	fpr = fopen('rrr','r');
	fpr = fopen('rr','r');
	print ERROR ERRMSG;
	fpw = fopen('www','w');
	loop while ERROR >= 0;
		line = fgetline(fpr,500);
		if ERROR < 0; 
			print ERROR ERRMSG;
			break;
		end if;
		print line;
		r = fputline(fpw,line);
	end loop;
	if fpr; r = fclose(fpr); end if;
	if fpw; r = fclose(fpw); end if;

	r = fputline(STDOUT,concat('Enter :','BBB'));
	line = fgetline(STDIN);
	r = fputline(STDOUT,line);
	return ERROR;
end proc;
