//
def a[2,3,4] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];
def b hash = ['AA',100,'BB',200];
def mappedarray aa 1 5 = [101,102,103];
def cc 10;
proc main;
	print a *a;
	print b *b;
	print aa *aa;

//opt15 = 0x00;
	for i=0 to 1;
		print i;
		for j=0 to 2;
			print j a[i,j,0] a[i,j,1] a[i,j,2] a[i,j,3];
		next;
	next;

//opt15 = 0x02;
	for k=0 to 3;
		print i;
		for j=0 to 2;
			print j a[0,j,k] a[1,j,k];
		next;
	next;

	c = a + 12;
//	print c /d c;
	print *c;
//	print c[14] c[15];

	return ERROR;
end proc;
