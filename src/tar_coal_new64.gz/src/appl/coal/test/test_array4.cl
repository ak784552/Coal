//
define array $a 10 8 6 4 2;
define array $b 3 2;
proc main;
	$a[0] = 111;
	$a[1] = 222;
	$a[1]++ ;
	print $a[0] $a[1] a;
//	exec ip 'sub1';
	return ERROR;
end proc;

proc sub1;
	$i = 0;
	loop 3;
		$j = 0;
		loop 2;
			$b[$i,$j] = $i + $j;
			print $i $j $b[$i,$j];
			$j++;
		end loop;
		$i++;
	end loop;
	return ERROR;
end proc;
