//
define array a 10 = [4,2,1,5,3,'E','D','A','C','B'];
define mappedarray $m 2 10;
define mappedarray $x 21 10;
proc main;
	print arraycpy(1,a);
//	print arraycpy(1,a,7);
	loop each x in $();
		print *x;
	end loop;
	print m *m;
	print countv(m);
//	sort(21,1,10);
	sort(21,1,countv(m));
	print x *x;
	return ERROR;
end proc;
