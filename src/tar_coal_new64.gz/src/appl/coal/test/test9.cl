//
Class TEST static;
	int a=1;
	f = XX;
	func XX;
		print a;
		return 0;
	end func;
end class;

proc main;
	print TEST.a;
	print TEST.f;
	print TEST.f();
	return ERROR;
end proc;
