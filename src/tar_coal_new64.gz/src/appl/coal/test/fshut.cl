//
PROC main;
	exit(254);
END PROC;
