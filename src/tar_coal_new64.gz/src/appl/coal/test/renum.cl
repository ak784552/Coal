//
//
//
proc main;
	if (%0 < 1);
		putline('usage: ',SCRIPTNAME,' [-n] in_file');
		return -1;
	end if;
	if (%1 == '-n') then
		ns = -1;
		shift;
		if (%0 < 1);
			putline('usage: ',SCRIPTNAME,' [-n] in_file');
			return -1;
		end if;
	else
		ns = 10;
	end if;
	if (fpi = fopen(%1));
		if (fpo = fopen(%1&+'.new','w'));
			option 3 2;
			i = 10;
			loop while (1);
				line = fgetline(fpi);if ERROR;break;endif;
				if (ns > 0) then
					fputline(fpo,edit('%06d',i),substr($line,7));
				else
					if (line == '') then
						fputline(fpo,'');
					else
						fputline(fpo,'      ',substr($line,7));
					end if;
				end if;
				i += 10;
			end loop;
			fclose(fpo);
		else;
			putline('output file(',%1&+'.new',') open error.',ERRMSG);
		end if;
		fclose(fpi);
	else;
		putline('input file(',%1,') open error.',ERRMSG);
	end if;
	return ERROR;
end proc;
