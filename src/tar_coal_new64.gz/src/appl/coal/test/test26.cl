//
proc main;
	a = '123'\
'67';
//	print a;
	c = b.x;
	ffff('sdadsdas',a,
	     b.x);
	return ERROR;
end proc;

func ffff(a,x);
print a x;
//a = '123'\
//'67';
	return a;
end func;
