//
proc main;
	try(fp = fopen('a','r'));
	catch;
		print ERROR ERRMSG;
	end try;
	return ERROR;
end proc;
