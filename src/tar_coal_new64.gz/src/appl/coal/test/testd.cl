//
PROC main;
	$d = 1.5f + 10;
	print $d;
	$fp = fopen('wwww','wb');
	$r = felwrite($fp,'AAAAA',$d,1234.0,10);
//	$r = felwrite($fp);
	$r = fclose($fp);
	$fp = fopen('wwww','rb');
	$r1 = felread1($fp,CHAR,5);
	$r2 = felread1($fp,FLOAT);
	$r3 = felread1($fp,DECI,4);
	$r4 = felread1($fp,BIN);
	print $r1 $r2 $r3 $r4;
	$r = fclose($fp);
	RETURN $ERROR;
END PROC;
