//# Code-gs2d-vtk.py

#include <stdio.h>



#define T (10000.0)

#define M (20000)

#define N (100)

#define Du (1.0e-5)

#define Dv (2.0e-5)

#define F (0.02)

#define kappa (0.059)

#define L (1.0)

#define Lc (L/2)



#define h (L/(double)N)

#define tau (T/(double)M)

#define alphau (Du*tau/(h*h))

#define alphav (Dv*tau/(h*h))

#define INTV (50)



int cc = 0;



double u[N+2][N+2];

double new_u[N+2][N+2];

double v[N+2][N+2];

double new_v[N+2][N+2];



void writeVtk(int count) {

	FILE *fp;

	char fname[256];

	sprintf(fname, "data_%d.vtk", count);

	fp = fopen(fname, "w");

	fprintf(fp, "# vtk DataFile Version 4.1 \n");

	fprintf(fp, "COMMENT\n");

	fprintf(fp, "ASCII\n");

	fprintf(fp, "DATASET STRUCTURED_POINTS \n");

	fprintf(fp, "DIMENSIONS %d %d 1\n", N, N);

	fprintf(fp, "ORIGIN 0 0 0\n");

	fprintf(fp, "SPACING %f %f 0 \n", h, h);

	fprintf(fp, "POINT_DATA %d\n", N*N);

	fprintf(fp, "SCALARS U double 1\n");

	fprintf(fp, "LOOKUP_TABLE default\n");

	

	for(int i = 1; i < N + 1; i++) {

		for(int j = 1; j < N + 1; j++) {

			fprintf(fp, "%f\n", u[i][j]);

		}

	}

	fclose(fp);

}



double u0(double x, double y) {

	if (x > Lc-0.1  && x < Lc+0.1 && y > Lc-0.1  && y < Lc+0.1) {

		return 1/4.0;

	}

	else {	

		return 0.0;

	}

}



double v0(double x, double y) {

	if (x > Lc-0.1  && x < Lc+0.1 && y > Lc-0.1  && y < Lc+0.1) {

		return 0.5;

	}

	else {

		return 1.0;

	}

}



double fu(double U, double V){

	return (U*U*V - (F + kappa)*U);

}



double fv(double U, double V){

	return (-U*U*V + F*(1.0 - V));

}





void setBC(){

	for(int i = 1; i < N + 1; i++) {

		u[i][0] = u[i][1];

		u[i][N+1] = u[i][N];

		v[i][0] = v[i][1];

		v[i][N+1] = v[i][N];

	}



	for(int j = 1; j < N + 1; j++) {

		u[0][j] = u[1][j];

		u[N+1][j] = u[N][j];	

		v[0][j] = v[1][j];

		v[N+1][j] = v[N][j];

	}

}



int main() {

	double x, y, t;



	for(int i = 1; i < N + 1; i++) {

		x = (i - 0.5)*h;

		for(int j = 1; j < N + 1; j++) {

			y = (j - 0.5)*h;

			u[i][j] = u0(x,y);

			v[i][j] = v0(x,y);

		}

	}

		

	setBC();



	for(int k = 1; k < M + 1; k++) {

		t = k*tau;

		setBC();

	

		for(int i = 1; i < N + 1; i++) {

			for(int j = 1; j < N + 1; j++) {

				new_u[i][j] = u[i][j] + alphau*(u[i-1][j] + u[i+1][j] + u[i][j-1] + u[i][j+1] - 4*u[i][j]) + fu(u[i][j], v[i][j])*tau;

				new_v[i][j] = v[i][j] + alphav*(v[i-1][j] + v[i+1][j] + v[i][j-1] + v[i][j+1] - 4*v[i][j]) + fv(u[i][j], v[i][j])*tau;

			}

		}



		for(int i = 1; i < N + 1; i++) {

			for(int j = 1; j < N + 1; j++) {

				u[i][j] = new_u[i][j];

				v[i][j] = new_v[i][j];

			}

		}



		if((k + 1)%INTV == 0) {

			printf("%d\n", cc);

			writeVtk(cc);

			cc = cc + 1;

		}

	}

}