//
//option 22 1;
def type struct ST_STACK
	int a,
	int b;
var x as ST_STACK = 1,2;
/*
def type struct ST_STACK2
	int c,
	int d;
var y as ST_STACK2 = 3,4;
*/
int ix 10 = [1,2,3];
//char ix;
//public int a = 100;
public a 2 3;
public dec a 2 4= 10;

proc main;
	print a /i a;
	public dec a 2 4= [1,2,3];
	print a /i a;
	print *a;
	public array char a = 'AAA';
//	public char a = 'AAA';
	print a /i a;
	print *a;
/*
	print x y;
	print *x *y;
	z = *x;
	print z *z;
//	undef z;
	z = *y;
	print z *z;
//	x = y;
*/
	print ix *ix;
	char ix = 10;
	print ix *ix /i ix;

	int i;
	print *i;
//	i = ix;
//	ST_STACK = ix;
	aa = 100;
	print aa /i aa;
	return ERROR;
end proc;
