//
// ackermann
//
proc main;
	RECURSION_LIMIT = 300;
//	int m = 3;
//	int n = 11;
	int m = 3;
	int n = 5;
	int result;

	t0 = gettime();
	result = ackermann(m, n);
//	call proc_ackermann m n &result;
	t1 = gettime();

	printf('ackermann(%d, %d)=%d\n',m,n,result);
	printf('t0=%r\n',t0);
	printf('t1=%r\n',t1);
	printf('elapsed time: %d ms\n',(t1-t0)*1000);
	print MAX_RECURSION_COUNT;
	return ERROR;
endproc;

func ackermann(m, n);
print m n;
	if m == 0;
		result = n + 1;
	elseif n == 0;
		result = ackermann(m - 1, 1);
	else
		result = ackermann(m - 1, ackermann(m, n - 1));
	endif;
print result;
	return result;
end func;

proc proc_ackermann(m, n, presult);
	int result;
print m n;
	if m == 0;
		result = n + 1;
	elseif n == 0;
		call proc_ackermann m-1 1 &result;
	else
		call proc_ackermann m n-1 &result;
		call proc_ackermann m-1 result &result;
	endif;
	*presult = result;
print result;
	return 0;
end proc;
