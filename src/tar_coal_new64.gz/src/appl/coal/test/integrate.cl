//
proc main;
	int nn = %1;
	int n = 2**nn;
	int i,k[1..nn];
	double y[0..n], y1[1..nn], y2[1..nn-1];
	double h, x0, x1, w, dn, s;

	MAX_LOOP_WHILE = INT_MAX;
//print n y y1 y2;
	x0 = -1.0d;
	x1 =  1.0d;
	h = (x1 - x0) / n;
	for i=0 to n;
		y[i] = f(x0 + i * h);
	next;
//print y[65536] y[n-1] y[n] *y;
	w = 2.0d;
	dn = n;
	for i=1 to nn;
		k[i] = dn / w;
//		w *= 2.0d;
		w += w;
	next;
//print *k;

	for i=1 to nn;
		s = 0.0d;
		for j=k[i] to n-1 step k[i];
			s += y[j];
		next;
//		y1[i] = h * k[i] * ( y[0] / 2.0d + s + y[n] / 2.0d );
		y1[i] = h * k[i] * ( y[0] * 0.5d + s + y[n] * 0.5d );
	next;
//print *y1;
	for i=2 to nn;
		y2[i-1] = (4*y1[i] - y1[i-1])/3.0d;
	next;
//print *y2;

	printf('%7d %.15f %.15f\n',2,k[1]*h,y1[1]);
	for i=2 to nn;
		printf('%7d %.15f %.15f %.15f\n',2**i,k[i]*h,y1[i],y2[i-1]);
	next;
	return ERROR;
end proc;

function f(x);
	return 2.0 / (1.0 + x*x);
end function;
