//
// Code-gs2d-vtk.cl
//

##define T (10000.0)
##define M (20000)
##define N (100)
##define Du (1.0e-5)
##define Dv (2.0e-5)
##define F (0.02)
##define kappa (0.059)
##define L (1.0)
##define Lc (L/2)

##define h (L/(double)N)
##define tau (T/(double)M)
##define alphau (Du*tau/(h*h))
##define alphav (Dv*tau/(h*h))
##define INTV (50)

int cc = 0;
double u[N+2,N+2];
double new_u[N+2,N+2];
double v[N+2,N+2];
double new_v[N+2,N+2];

func writeVtk(int count);
	int fp;
	char fname;

	sprintf(fname, 'data_%d.vtk', count);
	try (fp = fopen(fname, 'w'));
		fprintf(fp, '# vtk DataFile Version 4.1 \n');
		fprintf(fp, 'COMMENT\n');
		fprintf(fp, 'ASCII\n');
		fprintf(fp, 'DATASET STRUCTURED_POINTS \n');
		fprintf(fp, 'DIMENSIONS %d %d 1\n', N, N);
		fprintf(fp, 'ORIGIN 0 0 0\n');
		fprintf(fp, 'SPACING %f %f 0 \n', h, h);
		fprintf(fp, 'POINT_DATA %d\n', N*N);
		fprintf(fp, 'SCALARS U double 1\n');
		fprintf(fp, 'LOOKUP_TABLE default\n');

		for (i = 1; i < N + 1; i++);
			for (j = 1; j < N + 1; j++);
				fprintf(fp, '%f\n', u[i,j]);
			next;
		next;
	catch;
	end try;
	return ERROR;
end func;

func u0(double x, double y) as double;
	if (x > Lc-0.1  && x < Lc+0.1 && y > Lc-0.1  && y < Lc+0.1) then
		return 1/4.0;
	else	
		return 0.0;
	end if;
end func;

func v0(double x, double y) as double;
	if (x > Lc-0.1  && x < Lc+0.1 && y > Lc-0.1  && y < Lc+0.1) then
		return 0.5;
	else
		return 1.0;
	end if;
end func;

func fu(double U, double V) as double;
	return (U*U*V - (F + kappa)*U);
end func;

func fv(double U, double V) as double;
	return (-U*U*V + F*(1.0 - V));
end func;

func setBC();
	for (i = 1; i < N + 1; i++);
		u[i,0] = u[i,1];
		u[i,N+1] = u[i,N];
		v[i,0] = v[i,1];
		v[i,N+1] = v[i,N];
	next;
	for (j = 1; j < N + 1; j++);
		u[0,j] = u[1,j];
		u[N+1,j] = u[N,j];	
		v[0,j] = v[1,j];
		v[N+1,j] = v[N,j];
	next;
	return 0;
end func;

proc main();
	double x, y, t;
//return 0;
	for (i = 1; i < N + 1; i++);
		x = (i - 0.5)*h;
		for (j = 1; j < N + 1; j++);
			y = (j - 0.5)*h;
			u[i,j] = u0(x,y);
			v[i,j] = v0(x,y);
		next;
	next;

	setBC();

	for (k = 1; k < M + 1; k++);
		t = k*tau;
		setBC();
		for (i = 1; i < N + 1; i++);
			for (j = 1; j < N + 1; j++);
				new_u[i,j] = u[i,j] + alphau*(u[i-1,j] + u[i+1,j] + u[i,j-1] + u[i,j+1] - 4*u[i,j]) + fu(u[i,j], v[i,j])*tau;
				new_v[i,j] = v[i,j] + alphav*(v[i-1,j] + v[i+1,j] + v[i,j-1] + v[i,j+1] - 4*v[i,j]) + fv(u[i,j], v[i,j])*tau;
			next;
		next;

		for (i = 1; i < N + 1; i++);
			for (j = 1; j < N + 1; j++);
				u[i,j] = new_u[i,j];
				v[i,j] = new_v[i,j];
			next;
		next;

		if ((k + 1) % INTV == 0) then
			printf('%d\n', cc);
			writeVtk(cc);
			cc = cc + 1;
		end if;
	next;
	return ERROR;
end proc;
