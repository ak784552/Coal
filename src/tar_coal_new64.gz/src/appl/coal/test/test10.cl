//
public pa='QWE';
global ga=100;
define $proc=1;
define a;
proc main;
	public pa='X';
	global ga=200;
	print pa ga $proc;
	local a = 10;
	local = 1;
	return ERROR;
end proc;
