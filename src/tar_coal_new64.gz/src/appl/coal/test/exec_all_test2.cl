//
def a 50;
def opt 30;
def int max_loop_while;
def here_doc = '';
proc main;
	try (fp = fopen(%1)) ;
		get_option();
		i = 0;
		loop ;//for i=0 to 5;
			line = fgetline(fp);
//print line;
			if !line then
				continue;
			end if;
//			arrayclr(a);
			n = split(line,a,23);
//print n *a;
			f = a[0];
			if left(f,2)=='//' then
				break;
			elseif left(f,2)=='-o' then
				a[0] = substr(f,3);
				set_option(n);
			elseif left(f,2)=='/*' then
				loop;
					line = fgetline(fp);
					if !line then
						continue;
					end if;
					n = split(line,a,2);
					f = a[0];
					if left(f,2)=='*/' then
						break;
					end if;
				end loop;
			elseif left(f,1)=='#' then
				echo '*** skip ' f '***';
			else
				echo '*** start' f '***';
				try;
					chk_heredoc(n,fp);
//print *$();
				//	exec sc:trypass $f $*;
				//	exec sc:notrypass $f $*;
					exec sc $f $*;	// here_doc;
				catch FILE_READ_END_EXCEPTION;
					;
				catch;
					print ERRMSG;
				end try;
				undef const like public % not global ei_to_s eb_to_s PI_180;
				reset_option();
				echo '*** end  ' f '***';
			endif;
		end loop;
	catch FILE_READ_END_EXCEPTION;
		;
	catch;
		print ERRMSG;
	end try;
	return ERROR;
end proc;

func get_option();
	max_loop_while = MAX_LOOP_WHILE;
	for i=1 to 23;
		opt[i] = getval('OPTION',i);
	next;
	return ERROR;
end func;

func reset_option();
	MAX_LOOP_WHILE = max_loop_while;
	for i=1 to 23;
		option i opt[i];
	next;
	return ERROR;
end func;

func set_option(n);
	max_loop_while = MAX_LOOP_WHILE;
	for i=0 to n-1;
		ii = i;
		val = a[i];
		if (pos=instr(val,'='))>0 then
			ii = left(val,pos-1);
			val = substr(val,pos+1);
		end if;
//print ii val;
		option ii val;
	next;
	return ERROR;
end func;

func chk_heredoc(n,fp);
	arrayclr(1);
	here_doc = '';
//	$1 = '';
	ii = 1;
	for i=1 to n-1;
		x = a[i];
		if left(x,2)=='<<' then
			nam = substr(x,3);
			if nam=='' then
				if i < n-1;
					nam = x = a[i+1];
				end if;
			endif;
//			if nam<>'' then
//print /x fp;
				here_doc = heredoc(fp,nam);
//print to_bulks(fp,nam);
//				here_doc = to_bulks(fp,nam)<=='STDIN';
//print here_doc;
				$(ii++) = here_doc;
				break;
//			endif;
		else
			$(ii) = x;
//			$$ii = x;
//print ii $(ii) $0;
			ii++;
		endif;
	next;
	return ERROR;
end func;
