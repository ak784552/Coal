//
//  min_maisu.cl
//
var Kouka = [1, 5, 10, 50, 100];
proc main;
//	�񓚂P
	Kingaku = 46;
	print f_maisu(Kingaku);

//	�񓚂Q
	kakaku = 46;
	min_maisu = 100;
	for tsuri=0 to 99;
		shiharai = kakaku + tsuri;
		maisu = f_maisu(shiharai) + f_maisu(tsuri);
//print maisu;
		if maisu < min_maisu then
			min_maisu = maisu;
		end if;
	next;
	print min_maisu;
	return;
end proc;

func f_maisu(Kingaku);
	maisu = 0, nokori = Kingaku;
	for i=4 to 0 step -1;
		maisu = maisu + nokori / Kouka[i];
		nokori = nokori % Kouka[i];
//print i Kouka[i] maisu nokori;
	next;
//print Kingaku maisu;
	return maisu;
end func;
