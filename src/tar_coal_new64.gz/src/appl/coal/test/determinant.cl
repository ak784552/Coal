//
//
//
proc main();
	int N;

	printf('N = ');
	N=(int)(getline());
//	decimal m(N*N);
	double m(N*N);

	inputMatrix(m, N, N, 'm');

//	say 'det = ' "determinant(m, N)";
	printf('det = %6.4f\n', determinant(m, N));
	return 0;
end proc;

func SWAP(m, a, b);
	if m[a] <> m[b] then
		c = m[a];
		m[a] = m[b];
		m[b] = c;
	end if;
	return 0;
end func;

func determinant(m, N);
	defvar x, y, i as int;
//	decimal det = 1.0;
//	decimal r;
	double det = 1.0D;
	double r;

	// ��O�p�s��ɕϊ����A�Ίp�����̐ς��v�Z����B
	for(y = 0; y < N - 1; y++);
		printMatrix(m, N);
		if(m[y * N + y] == 0) then
			// �Ίp������0�������ꍇ�́A���̗�̒l��0�łȂ��s�ƌ�������
			for(i = y + 1; i < N; i++);
				if(m[i * N + y] != 0) then
					break;
				endif;
			next;
			if(i < N) then
				for(x = 0; x < N; x++);
					SWAP(m,i * N + x, y * N + x);
				next;
				// ������������̂ōs�񎮂̒l�̕����͔��]����B
				det = -det;
			end if;
		end if;
		for(i = y + 1; i < N; i++);
			r = m[i * N + y] / m[y * N + y];
			for(x = y; x < N; x++);
				m[i * N + x] -= r * m[y * N + x];
			next;
		next;
		det *= m[y * N + y];
	next;
	det *= m[y * N + y];

	return det;
end func;

func inputMatrix(mat, cols, rows, mNameStr);
	defvar x, y as int;

	for(y = 0; y < rows; y++);
		for(x = 0; x < cols; x++);
			if(rows != 1) then
				printf('%s[%d][%d] = ', mNameStr, y, x);
			else	
				printf('%s[%d] = ', mNameStr, x);
			end if;
			mat[y * cols + x] = getline();
		next;
	next;
	return 0;
end func;

func printMatrix(a, N);
	defvar i, k as int;

	for(i = 0; i < N; i++);
		for(k = 0; k < N; k++);
//			ELWRITE(a[i * N + k] &+ ' ');
			printf('%+6.2f ', a[i * N + k]);
		next;
		echo;
	next;
	echo;
	return ERROR;

end func;

func printf(f,a1,a2,a3,a4);
	ELWRITE1(edit(f,a1,a2,a3,a4));
	return ERROR;
end func;
