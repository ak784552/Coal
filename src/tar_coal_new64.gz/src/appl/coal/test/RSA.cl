//
// RSA
// 'e' N n
// 'd' p q m
//def E = 17;
def E = 79;
def M = 10;
proc main;
	if %1 == 'd' then
		print decode(%2,%3,%4);
	else
		print encode(%2,%3);
	end if;
	return ERROR;
end proc;

function decode(p,q,m);
	d = ((p-1)*(q-1)*M+1)/E;
//	m**d % N;
	return fun(m,d,p*q);
end func;

function encode(N,n);
//	n**17 mod N;
	return fun(n,E,N);
end func;

function fun(m,d,N);
//	m**d % N;
	a = m % N;
	loop d-1;
		a = a*m % N;
	end loop;
	return a;
end func;
