//
define array global $ab 2 3 4;
define global array $xx 10;
proc main;
	$ab[0,0,0] = 1;
	print $ab[0,0,0];
	exec sc 'test_array_global1';
	print $ab[0,0,0] $xx[1];
	return $ERROR;
end proc;
