//
def a[2,3,4] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];
def b hash = ['AA',100,'BB',200];
def mappedarray aa 1 5 = [101,102,103];
def cc 10;
proc main;
/* opt15 = 0x00
	for i=0 to 1;
		print i;
		for j=0 to 2;
			print j a[i,j,0] a[i,j,1] a[i,j,3] a[i,j,3];
		next;
	next;
*/
/* opt15 = 0x02
	for k=0 to 3;
		print i;
		for j=0 to 2;
			print j a[0,j,k] a[1,j,k];
		next;
	next;
*/

	print *a;
	print a.append(13,14);
	print a;
	print *a;

//	print "bx = b + 1";
	print *b;
	print b.append('CC',300);
	print b;
	print *b;

	print aa;
	print aa.append(104,105,106);
	print aa;
	print *aa;

//	print /d a;
	c = a + 12;
//	print c /d c;
	print *a;
	print *c;
	c.append(100,101,102,103,104,105,106,107,108,109,110);
//	print c.append(100);
//	print "c append 100";
//	print c /d c;
	print *c;
//	print c[14] c[15];
	print *a;
//	print a /d a;

	print "c append 102";
	print c /d c;
	print *c;
	print *a;
	print a /d a;

	print cc.append(**[10,20,30]);
	print cc *cc;

	dd = [1,2,b,3];
	print dd;
	print *dd;
	print /i *dd;

	return ERROR;
end proc;
