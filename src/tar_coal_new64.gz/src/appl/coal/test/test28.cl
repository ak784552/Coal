//
//define mappedarray %m 1 10;
define mappedarray %m "" 10;
define array bb[-1..0,1..3,4] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];
proc main;
	print %() *%() %m *%m;
	bbm0 = arraymap(bb,-1,1,0);
	print bb bbm0 /d bb bbm0;
	return ERROR;
end proc;
