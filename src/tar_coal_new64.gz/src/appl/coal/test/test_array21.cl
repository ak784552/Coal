//
def array complex dec a 10 = [1+2i,2+1i,3,4,5];
def array uint ua 10 = [10, -1, -10, 4000000000];
def uint ux = 4000000000;
def complex c = 1.2+3.5i;
proc main;

	print a *a;
	print ua *ua;
	print ux /i ux;
	print c;
	$1 = 1;
	$2 = 2;
	print *$();
	b = ua + [1,3];
	print b *b;
	return ERROR;
end proc;
