//
proc main;
	try;
		loop;
			line=getline();
			x=substr(line,9);
			putline('#define mv',x,'\tm',x);
		end loop;
	catch;
		echo ERRMSG;
	end try;
	return ERROR;
end proc;
