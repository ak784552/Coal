//
def fa[100];
proc main;
	i = 0;
	try (dp = OPENDIR(%1));
		try;
			while $f = readdir($dp);
				if f=='.' or f=='..' then
				else
					putline('*** ',$f,' ***');
					fa[i++] = %1 & '/' & f;
				end if;
			end while;
		catch FILE_READ_EXCEPTION;
//			print ERRMSG /x EXCEPTION ;
		catch;
			print ERRMSG /x EXCEPTION ;
		end try;
		print i;
		file_cat(3,i);
	catch;
		print ERRMSG /x EXCEPTION ;
	end try;
	return ERROR;
end proc;

func file_cat(max_file,n);
	i1=max_file;
	loop as AAA;
		for (i=0;i<max_file;i++);
			if i1 >= n;
				break AAA;
			endif;
			result = `!cat $fa[i] $fa[i1] > %1/tmp`;
			print result;
			ret = rename(%1 & '/tmp',fa[i]);
			print ret;
			ret = unlink(fa[i1]);
			print ret;
			i1++;
		next;
	end loop;
	return ERROR;
end func;
