//
def x   = $() + 1;
def opt = $() + [20,31];
def a   = $() + 51;

proc main;
print x;
print opt;
print a;

print '\n----- arrayclr(opt,10,5)';
	arrayclr(opt,10,5);
print *opt;
print $0 *$();
print countv($());

print '\n----- arrayclr(a,''A'',10)';
	arrayclr(a,'A',10);
print *a;
print $0 *$();
print countv($());

print '\n----- arrayclr(opt,,5)';
	arrayclr(opt,,5);
print *opt;
print $0 *$();
print countv($());

print '\n----- arrayclr(a,,10)';
	arrayclr(a,,10);
print *a;
print $0 *$();
print countv($());

	return ERROR;
end proc;
