//
proc main;
	a = {10,3,1,5,7,8,1,3,5};
	b = {1,3};
	print a-b;
	print a+b;
	print a&b;
	print a|b;
	print a*b;
	print a/b;
	return $ERROR;
end proc;
