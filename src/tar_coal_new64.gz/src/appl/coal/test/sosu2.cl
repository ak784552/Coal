//
//define MAX_SOSU	=100000;
define MAX_SOSU	=50;
define int gFlag;
int sosu MAX_SOSU =
	  2,  3,  5,  7, 11, 13, 17, 19, 23, 29,
	 31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
	 73, 79, 83, 89, 97,101,103,107,109,113,
	127,131;
proc main;

	char buf[20];
	dim ret,b,i,k,count as int;
	dim max_sosu,msosu,msosu2,i0,i1,last,opt,max as int;

//	max_sosu=32;
	max_sosu=10;
	count_sosu=0;
	last = 0;
	i1=0;
/*
	for (;;) do;
		elwrite('Entry number ==> ');
		b=(CINT)getline();
		if (b<=0) thenl break;
*/
	for (b=2000;1;b+=2000) do;
		$max=b;
		MAX_LOOP_WHILE = b + 1000;
		msosu = sosu[max_sosu-1];
		msosu2 = msosu*msosu;
		if (last>0 && b>last) then i0 = last + 2;
		elsel i0 = 3;
//print i0 $max;
//		max9 = ($max*95)/100;
		if (max9 = $max - 100)<=0 thenl max9 = ($max*9)/10;
		count=0;
		ret=0;
		for (i=i0;i<=$max;i+=2) do;
			if i> max9 || count==0 then gFlag = 1; else gFlag = 0; end if;
			if ((ret=akxg_sosu_chk_by_tbl_opt(sosu,max_sosu,i,opt))>0) then
				count_sosu++;
//				elwrite(' ',(CCHAR)i);
				if gFlag thenl print i count_sosu;
				if (max_sosu<MAX_SOSU && i>msosu) then
					elwrite(i &+ ',');
					if !((i+1) % 10) thenl echo;
					sosu[max_sosu++] = msosu = i;
					msosu2 = msosu*msosu;
//					elwrite('+');
//					print '+' max_sosu i;
//					print "(max_sosu % 100)";
//					if (max_sosu % 100)==0 thenl print '+' max_sosu;
				endif;
				last = i;
				if (count++ >=100) then
					putline();
					count=0;
				endif;
			elseif (ret < 0) then
				putline('\n*** table over');
				break ;
			endif;
		next;
		putline('\nmax_sosu=',max_sosu);
		putline('max=',$max);
		for (i=i1;i<max_sosu;i++) do
			elwrite(sosu[i] &+ ',');
			if !((i+1) % 10) thenl echo;
		next;
		echo;
		if (ret < 0) thenl break;
//		x=getline();
		sleep 1;
		i1=max_sosu+1;
	next;
	return 0;
end proc;

func akxg_sosu_chk_by_tbl_opt(sosu,max_size,l,opt);
	dim i,mmax,m as int;
	dim ll,l1,l2 as int;

	mmax=max_size;
//print sosu max_size l opt;
	if (!(sosu)) thenl return -1;
	ll = l;

	if (ll < 2) then return 0;
	elseif (ll == 2) then return 1;
	elseif (ll <= 7) then
		if (ll&0x01) thenl return 1;
		return 0;
	end if;

	l2 = (CINT)sqrt(ll);
//print l2;
	for (i=0;i<mmax;i++) do;
		if (!(ll % (m=sosu[i]))) then
//			if gFlag thenl print ll m ll/m;
			break;
		endif;
		if (m > l2) thenl break;
	next;
	if (i>=mmax) then
//putline('akxg_sosu_chk: ll=',ll,' l2=',l2,' i='.i,' m=',m); 
		return -2;
	elseif (m>l2) thenl return 1;

//putline('akxg_sosu_chk: ll=',ll,' l2=',l2,' i='.i,' m=',m); 

	return 0;
end func;
