//
define aa[10];
proc main;
	f2(10,2);
	f2(5,3);
	return ERROR;
end proc;

func f2(a,b);
	dec(a,b) d1 = 13.4567;
print a b d1;
/*
	dec(10,3) d2 = 13.4567;
print d2;
//	dec(aa,1) d3 = 13.4567;
	dec(10,abs) d4 = 13.4567;
*/
	return 0;
end func;
