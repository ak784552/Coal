//
def a hash = ['A',1,'B',2,'C',3];
def b hash = ['X',11,'Y',12,'Z',13];
proc main;
//	print a *a;
//	print b *b;
	print a.leng();
	print 'asdd'.leng;
	print abs /i abs;
	print chr(is(abs,'I'));
	return ERROR;
end proc;
