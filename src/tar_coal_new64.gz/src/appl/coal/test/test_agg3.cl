//
def a 10 = {1,2,3,,4,5,[4,1]};
def b 10 = {[4,1],3,,2};
proc main;

	print {1,2,,3,4}-{4,1};
	print {1,2,3,4}-4;
	print 3-{4,1};
	print a|b;
	print *(*a+*b);
	print *(*a|*b);
	print *(*a-*b);
	print *(*a&*b);
	print {1,2,3,4,[5,6]}-{{5,6},4,1};
	print *(*a&[2,3]);
	print *([2,3]&*a);
	x = {'A','B','C','D','E'};
	y = ['A','E'];
	print x+y;
	print x-y;
	return ERROR;
end proc;
