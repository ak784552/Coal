//
// ���^�[���l
//		0x01: �ύX�f�[�^����B
//		0x02: ����J�������́A�L���B
//
func keiyaku_check_and_update(count,yakc,shain_inf,psai,ip_index);

	const int IP_SHIGYO	= ip_index[0];//13;
	const int IP_SHUGYO	= ip_index[1];//14;
	const int IP_DAYWRK	= ip_index[2];//22;	//��������J��
	const int IP_WEEKWK	= ip_index[3];//23;	//�T������J��
	const int IP_MONWRK	= ip_index[4];//24;	//��������J��
	const int IP_WDAYS	= ip_index[5];//25;	//����J������

	local iUPDATE = 0;
	ret = 0;
	local what = '';
//print IP_SHIGYO psai[IP_SHIGYO];
	shhmm = psai[IP_SHIGYO];
	ehhmm = psai[IP_SHUGYO];
	ji = jikan100(shhmm, ehhmm);
	If ji == -1 Then
		yak = (CINT)yakc;
		if yak >= 800 then ERROROUT('E', what & '�o�^�`(��E�R�[�h=' & yakc & ') �n�Ǝ��� NULL,' &+ count & ',' & shain_inf);
		elsel ji = 0;
	ElseIf ji == -2 Then
		ERROROUT('E', what & '�n�Ǝ���[' & shhmm & '] Invalid,' &+ count & ',' & shain_inf);
	ElseIf ji == -3 Then
		ERROROUT('E', what & '�I�Ǝ��� NULL,' &+ count & ',' & shain_inf);
	ElseIf ji == -4 Then
		ERROROUT('E', what & '�I�Ǝ���[' & ehhmm & '] Invalid,' &+ count & ',' & shain_inf);
	ElseIf ji == -10 Then
		ERROROUT("E", what & "�n�Ǝ���=�I�Ǝ���[" & ehhmm & "]," &+ count & ',' & shain_inf);
	End If;
	rc = ji;
	wday = (CBIN)psai[IP_WDAYS];
//	ERROROUT('I', what & '����J������=' & psai[IP_WDAYS] & ',' &+ count & ',' & shain_inf);
	If ji > 0 Then
		If ji >= 800 Then
			ji = ji - 100;
		ElseIf ji > 600 Then
			ji = ji - 75;
		End If;
		sji = strjikan(ji);
		ji0  = psai[IP_DAYWRK] * 100;
		wji0 = psai[IP_WEEKWK] * 100;
		swji = strjikan(wji0);
		If ji0 <> ji Then
			ERROROUT('W', '"' & what & '��������J�� �s��v(' & strjikan(ji0) & ',' &+ sji & '(C))",' &+ count & ',' & shain_inf);
			rc = -5;
			iUPDATE = 1;
		end if;
		if wday > 7 then
			ERROROUT('W', what & '����J������Invalid(>7),' &+ count & ',' & shain_inf);
			If wji0 > 0 Then
				wday = (CINT)(wji0/ji);
				iUPDATE = 1;
			end if;
			rc = -8;
		elseif !wday then
			If wji0 > 0 Then
				wday = (CINT)(wji0/ji);
				sLwday = '(�v)=' &+ wday;
				iUPDATE = 1;
			else
				sLwday = '=0';
				rc = -7;
			end if;
			ERROROUT('W', what & '����J������' & sLwday & ',' &+ count & ',' & shain_inf);
		else
			wji = ji * wday;
			swji = strjikan(wji);
			If wji0 <> wji Then
				ERROROUT('W', '"' & what & '�T������J�� �s��v(' & strjikan(wji0) & ',' &+ swji & '(C))",' &+ count & ',' & shain_inf);
				rc = -6;
				iUPDATE = 1;
			End If;
		End If;

		if iUPDATE then
			ret = 1;
//		elseif rc<0 then
//			ret = rc;
		end if;
		if wday>0 then
			psai[IP_DAYWRK] = sji;
			psai[IP_WEEKWK] = swji;
			psai[IP_MONWRK] = '0';
			psai[IP_WDAYS] = (CCHAR)wday;
			ret += 2;
		end if;
	else
		ret = rc;
	end if;

	return ret;
end func;

Function hhmm2fun(hhmm);
	Dim i As Integer;
	Dim fun As Integer;
	i = InStr(hhmm, ':');
	If i==2 || i==3 Then
		fun = Left(hhmm,i-1)*60 + Mid(hhmm,i+1);
	Else
		fun = -1;
	End If;
	return fun;
End Function;

Function jikan100(shhmm, ehhmm);
	Dim s As Integer;
	Dim e As Integer;
	Dim f As Long;
	If shhmm == '' Then
		return -1;
	Else
		s = hhmm2fun(shhmm);
		If s == -1 Then
			return -2;
		End If;
	End If;
	If ehhmm == '' Then
		return -3;
	Else
		e = hhmm2fun(ehhmm);
		If e == -1 Then
			return -4;
		End If;
	End If;
	f = e - s;
	If f == 0 Then
		return -10;
	ElseIf f < 0 Then
		f = f + 24 * 60;
	end if;
	return f * 100 / 60;
End Function;

Function strjikan(ji100) as char;
	return ji100 / 100.0;
End Function;
