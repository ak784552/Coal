//
define array char(5) $args 10;
proc main;
//	$a = '1 2 3 4 5 6';
	$a = '1 2 |3 4| 5 6';
	$n = getargs($a,$args,,,'|');
//	$n = getargs($a,$args,10);
//	$n = getargs($a,$arg);
//	$args[0] = 'asdfgh';
//	print $n $args[0];
//	$x = $args[0];
//	print $x;
	$i = 0;
	loop $n;
		print $i $args[$i];
		$i++;
	end loop;
	return $ERROR;
end proc;
