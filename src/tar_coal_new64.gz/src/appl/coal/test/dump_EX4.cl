//
//
//
import lib_iconv;
import lib_util;
define ninzu[3];
define sikyu[3];
proc main;
	if (%0 < 1);
		putline('usage: ',SCRIPTNAME,' in_file');
		return -1;
	end if;
	fpi = fopen(%1);
	if (fpi) then
		try;
			loop;
				buka = conv(felread1(fpi,1,2),2);
				for i=0 to 2;
					ninzu[i] = edit('%3s',comma(felread1(fpi,4,3,0)));
					sikyu[i] = edit('%9s',comma(felread1(fpi,4,9,0)));
				end loop;
					total = edit('%11s',comma(felread1(fpi,4,11,0)));
				say buka ninzu[0] sikyu[0] ninzu[1] sikyu[1] ninzu[2] sikyu[2] total;
			end loop;
		catch;
//			print EXCEPTION ERROR ERRNO ERRMSG;
		end try;
		fclose(fpi);
	else
		putline('input file(',%1,') open error.',ERRMSG);
	end if;
	print comma('   -12345.67    ');
	return ERROR;
end proc;
