//
//define mappedarray $a "" 10;
define mappedarray $a 0 10 = ['A','B','C','D','E'];
define mappedarray $b 1 10;
//define mappedarray %a 1 "" 5;
//define mappedarray $a '' 5 '';
define mappedarray %a 0 10;
define mappedarray #a 0 10;
proc main;

	print %() %a;
	print $a $b;
	print *%() *%a;
	print *$a *$b;
	print %()[1];
	print (%a)[0];

	a[2] = %a;

	print (a[2])[0] a[2];

	print %() $() #();
	$1 = 1;
	$11 = 11;
	print $0 $a[0];
//let	%1 = 'B';
	print "%a[0] = 'C'";
	print %0 %a[0] %a[10];
	print #0 #a[0];
	for each x in %a;
		print *x;
	end for;
	for each x in %();
		print *x;
	end for;
	print *%a;
	print *(%());
	for each x in $a;
		print *x;
	end for;
	for each x in $();
		print *x;
	end for;
	print *$a;
//	print *$();
	print %()[1];
	print %() $() #();

	y = *%() + *$();

	print y;
	print *y;
	print %a=1;
	print %()=2;
	print %(1)=2;
	print w=%()+1 *w *%w;
	print w[0]='X';
	print %ww=%()+1 *%ww;

	return ERROR;
end proc;
