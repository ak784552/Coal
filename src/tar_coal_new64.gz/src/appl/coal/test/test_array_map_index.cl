//
def a 10 = [1,2,3,4,5,6,7,8,9,10];
proc main;
	b = a + [0,5,2];
	print a b;
	print *a *b;
	fn(a+1);
	return ERROR;
end proc;

func fn(x);
	y = x + [0,2,5];
	print x y;
	print *x *y;
	print /d x y;
	print indexa(y,1,3) y[1,3];
	return 0;
end func;
