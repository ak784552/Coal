//
//def array a 10 = [11,12,13,14,15,16,17,18,19,20];
proc main;

	a = $() + [0,10];
	setarray(1,11,12,13,14,15,16,17,18,19,20);
	print a *a;
	print a[2..5];

	print a[2..5..2];
	print *a[2..5];
	print *a[2..5..2];

	array b 10 = a[2..5];
	print b b[0] *b;
	array bb 10 = *a[2..5];
	print bb bb[0] *bb;

	c = a[2..5];
	print c *c;
	d = *a[2..5];
	print d *d;

	return ERROR;
end proc;
