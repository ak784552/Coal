//
//  heihousu.cl
//
def na=100;
def a[na],b[na],c[na];
def max_num=0;
proc main;
	m=1000;
	n=1000;
	int k;
	for i=1 to m;
		for j=i to n;
			k2=i*i+j*j;
			k=sqrt(k2);
			if k2 == k*k;
				if chk_not_same(i,j,k);
					print i j k i*i j*j k2;
					if max_num>=na;
						na+=100;
						redef a[na],b[na],c[na];
					//	print a b c;
					endif;
					a[max_num]=i;
					b[max_num]=j;
					c[max_num]=k;
					max_num++;
				endif;
			endif;
		next;
	next;
	print max_num;
	return ERROR;
end proc;

function chk_not_same(a1,b1,c1);
	not_same=1;
	i=0;
	loop max_num;
		b2=b1/b[i];
		if a1/a[i]==b2 && b2==c1/c[i];
			if !(a1 % a[i]) && !(b1 % b[i]) && !(c1 % c[i]);
				not_same=0;
				break;
			endif;
		endif;
		i++;
	endloop;
	return not_same;
endfunc;
