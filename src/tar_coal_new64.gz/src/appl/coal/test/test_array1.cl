//
define private mappedarray variant %parm 2 10;
define array ha 10;
//define global mappedarray int %pa 0 10; 
define mappedarray %pa 0 10;
def a 10;
proc main;

	print %parm;
	print ha a;
	print %pa %pa[0];

	print /d %parm ha;
	print *%parm *ha;
//	loop for (i=0;i<%0;i++);
	
	print countv(%parm) m=countv(%parm,1);
	loop for (i=0;i<m;i++);
		print %parm[i];
//		ha[%parm[i]] = %parm[i];
	end loop;

//	n = sort(1,%parm,m);
	n = sort(1,%parm,m,'F',1,0,'N');
	loop for (i=1;i<=n;i++);
		print $$i;
	end loop;
	print *$();

	return $ERROR;
end proc;
