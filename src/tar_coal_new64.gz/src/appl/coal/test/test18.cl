//
def a[10] = (1,2,3,4);
def b[10] = {1,2,3,4};
def c[10] = [1,2,3,4];
proc main;
	print *a;
	print *b;
	print *c;
	return ERROR;
end proc;
