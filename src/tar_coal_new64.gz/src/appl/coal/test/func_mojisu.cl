//
function mojisu (str);
	n = 0;
	while str do
		str = substrb(str,(str is 'M')+1);
		n++;
	end do;
	return n;
end function;
