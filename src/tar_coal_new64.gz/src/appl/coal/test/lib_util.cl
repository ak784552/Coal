//
//
//
func comma(s as char);
	s = trim(s,1);
	if ((c=left(s,1))=='+' || c=='-') then
	//	s = substr(s,2);
		s = s.2;
//print s;
	else
		c='';
	end if;
	pos = instr(s,'.');
	if (pos) then
		ss = left(s,pos-1);
	//	s = substr(s,pos);
		s = s.pos;
	else
		ss = s;
		s = '';
	end if;
	x = '';
	len = leng(ss);
#>if 1
	m = (len % 3) + 1;
	i1 = (len/3-1)*3 + m;
	x = ss;
	if i1 > 1 then
		if m == 1 thenl m = 4;
		for i=i1 to m step -3;
			x = replike(x,i,'^',',');
//print i x;
		next;
	end if;
#>else
	for i=1 to len step 3;
		if x then
			x = ',' & x;
		end if;
		l=leng(ss);
//print i l;
		if (l > 3) then
			x = right(ss,3) & x;
			ss = substr(ss,1,l-3);
		else
			x = ss & x;
		end if;
	next;
#>endif
	return c & x & s;
end func;

func ERROROUT(status, mesg);
	log_path = nval(ndef('LOG_PATH',''),'/cygdrive/c/temp/');
	if right(log_path,1) != '/' thenl log_path &= '/';
	fp = fopen(log_path & 'error_log_' & DATE & '.txt', 'a');
	fputline(fp,DATETIME & ',' & status & ',' & mesg);
	fclose(fp);
	return ERROR;
End func;

function fcto0s(char x,pad,n,m);
// m>0: x=NULL�̂Ƃ��Apad��m�ݒ肷��B
	if x then
		if leng(x)<n then
			x = right(strings(pad,n) & x,n);
		end if;
	elseif m > 0 then
		x = strings(pad,m);
	end if;
	return x;
end func;

function set_hatsurei_kubun();
	private hatsurei_kubun hash 60;
	try;
		fp = fopen('hatsurei_kubun.csv');
		loop;
			line = fgetline(fp);
			getargs(line,1,2,,',');
			hatsurei_kubun[fcto0s($1,'0',4,0)] = $2;
		end loop;
	catch FILE_READ_END_EXCEPTION;
	catch;
		print ERRMSG;
	end try;
	if (fp) thenl fclose(fp);
	return ERROR;
end func;

function get_hatsurei_name(kubun);
	option  1 1;
	return hatsurei_kubun[fcto0s(kubun,'0',4,0)];
end func;
