//
define array $args 10;
proc main;
	$a = '1 2 3 4 5 6';
	$n = getargs($a,$args,10);
	print $n *args;
	$i = 0;
//	loop $n;
	loop 10;
		print $i $args[$i];
		$i++;
	end loop;
	return $ERROR;
end proc;
