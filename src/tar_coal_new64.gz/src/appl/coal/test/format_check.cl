//
proc main;
	try;
		loop;
			line = getline();
			if k=instr(line,'"') then
				len = leng(line);
				if j=instr(line,'/*') then
					if j < k thenl continue;
					len = j - 1;
				end if;
				for i=k+1 to len;
					if is(substr(line,i,1),'M') > 1 then
						echo line;
						break;
					end if;
				next;
			end if;
		end loop;
	catch FILE_READ_END_EXCEPTION;
	catch;
		print errmsg;
	end try;
	return ERROR;
end proc;
