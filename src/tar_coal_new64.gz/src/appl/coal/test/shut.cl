//
PROC main;
	print a;
	exit(254);
END PROC;
