//
proc main;

	ymd = set_date_part(SYSDATE,1,'d');		// ����1�����擾

	print get_date_num(1,ymd,'W');
	print *$();
	print get_date_num(1,ymd,'Y');
	print get_date_num(1,ymd,'M');
	print get_date_num(1,ymd,'D');
	print get_date_num(1,ymd,'H');
	print get_date_num(1,ymd,'MI');
	print get_date_num(1,ymd,'S');
	print get_date_num(1,ymd,'MS');
	print get_date_num(1,ymd,'DY');
	print get_date_num(1,ymd,'W');
	print get_date_num(1,ymd,'Q');
	print get_date_num(1,ymd,'DDD');
	print get_date_num(11,6,ymd,'T');
	print *$();
	a = [];
	print get_date_num(a,ymd,'T');
	print a;
	return ERROR;
end proc;
