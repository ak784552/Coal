//
define option 8 2;
define array $a 10;
define type struct z
	int a 10
	,char(5) b
	,c;
define var xz as z;
proc main;

	function mf;
		return 'func mf';
	end func;
//	print %1.#a;
//	xz.#abs='ABC';
	m=mf;
//	print m m();
	print main.(m)();
//	print []();
	m = 3;
	n = 'c';
	xz.c = 123;
	print xz.(n);
	print '12345'.(m+1);

	xz.b = 'A1234';
	xz.c = -123.45e+12;
	print $xz.$b $xz.$c;
	print $xz.b $xz.c;
//	xz.a[0] = 10;
	print $xz.a[0];
//	print xz.#abs;

	$1 = 2;
	$2 = 'A';
	print $$1;
	$3 = 'B';
//	$a = 3;
//	print $$a;


	$1 = 'AA';
	a[1] = 1;
//	$$a[1] = 0;
//	$$x[1] = 0;
//	$a[1] = 2;
//	$2 = 10;
	print $$a[1];


	$i = 1;
	$1 = FF('abs');
	print $$i(-2);

	print %$i;
	$i++;
	print %$i;
	i=1;
	loop %0;
		$$i = %$i;
//		print %$i;
//		$i++;
		print $($i++);
	end loop;

/*
	for each x in %,$;
		print x;
	end for;
*/
	return ERROR;
end proc;

function f;
	return 'func f';
end func;
