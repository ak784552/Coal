//
class Math static;
	const PI_180=PI/180.0D;
//	local PI_180=PI/180.0D;
//	PI_180=PI/180.0D;
	_d=srand1(TIME);
//print PI_180 /i PI_180;
	func Math();
		const PI_90=PI/90.0D;
		return 0;
	end func;

func radians(doo);
	return $doo*My.$PI_180;
end func;

func sind(doo);
//	x=0;
	return sin(doo*PI_180);
end func;

func cosd(doo);
//	a;
	return cos(doo*PI_180);
end func;

func tand(doo);
	return tan(doo*PI_180);
end func;

func fact(x);
	return product(*(x..1..-1));
end func;

func randint(int a,int b) as int;
	x = rand1()+0.000005;
//print x;
	return x*(b-a)+a;
end func;

end class;
