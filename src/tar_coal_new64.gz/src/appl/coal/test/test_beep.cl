//
def a 10 = [262,294,330,349,392,440,494,525];
proc main;
	for each x in a;
		beep(x.value,1000);
	next;
	sleep 1;
/*
            case  99: Hz= 262; break;    /* c �h	*/
            case 118: Hz= 294; break;    /* v ��	*/
            case  98: Hz= 330; break;    /* b �~	*/
            case 110: Hz= 349; break;    /* n �t�@	*/
            case 109: Hz= 392; break;    /* m �\	*/
            case  44: Hz= 440; break;    /* , ��	*/
            case  46: Hz= 494; break;    /* . �V	*/
            case  47: Hz= 523; break;    /* / �h	*/
*/
	print msgbox('test','testtest',3+0x20);
	return ERROR;
end proc;
