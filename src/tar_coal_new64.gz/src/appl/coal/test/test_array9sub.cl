//
define array $b 10;
proc main;
	$b[0]=10;
	$b[1]=20;
	$ga = $b;
	print $ga[0] $ga[1];
	return ERROR;
end proc;
