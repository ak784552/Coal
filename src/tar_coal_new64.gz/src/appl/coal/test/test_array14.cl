//
option 15 1;
define array aa[10] = [1,2,3,4,5,6,7,8,9,10];
//define array ah hash[10];
define mappedarray %am [2,1..10];
define array bb[-2..2] = [11,12,13,14,15];

proc main;
	print aa *aa;
	cc = aa + 5;
	print cc *cc cc[1] cc[5];
	print aa[1];
	print %am *%am;
	print %am[1];
	print bb *bb;
	print bb[0];

	aa[1] = 100;
	redefine array clear aa;
//	arrayclr(aa);
	print aa *aa;
	return ERROR;
end proc;
