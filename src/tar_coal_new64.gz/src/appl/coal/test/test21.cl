//
// �z��̃f�[�^�z�u
//
define array aa[4,3,2] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];
proc main;
	print aa *aa;
	for (k=0;k<2;k++);
		print k;
		printf('    i=');
		for (i=0;i<4;i++);
			printf(' %2d',i);
		next;
		print;
		for (j=0;j<3;j++);
			printf('j=%d : ',j);
			for (i=0;i<4;i++);
				printf(' %2d',aa[i,j,k]);
			next;
			print;
		next;
	next;
	return ERROR;
end proc;
