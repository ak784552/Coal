//
//
//
public URL = 'https://example.com';

func add(a, b);
	return a + b;
end func;

class Card ;
	char suit;
	int  number;
	func Card(suit,number);
		My.suit = suit;
		My.number = number;
		return 0;
	end func;
end class;
