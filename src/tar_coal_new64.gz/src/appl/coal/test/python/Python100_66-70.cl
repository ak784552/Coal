//
//
//
func print_string(text);
	print text;
	return ERROR;
end func;

func add(a,b);
	return a + b;
end func;

func sum_and_avg(x);
	return [sum(x),avg(x)];
end func;

func is_even(n);
	return n % 2 == 0;
end func;

function drink_price(drink_size, has_whip=FALSE);
	if drink_size == 'S' then
		price = 100;
	elseif drink_size == 'M' then
		price = 200;
	elseif drink_size == 'L' then
		price = 300;
	end if;

	if has_whip then
		price += 100;
	end if;
	return price;
end func;

proc main;
// 66
echo '66���';
	print_string('Hello, Python!');

// 67
echo '67���';
	a = 10;
	b = 20;
	print add(a,b);
// 68
echo '68���';
	numbers = [14,32,80,1,9];
	[s,a] = sum_and_avg(numbers);
	print s a;
	print sum_and_avg(numbers);
//69
echo '69���';
	for each number in numbers;
		if is_even(number.value) then
			putline(number.value,'�͋����ł�');
		else
			putline(number.value,'�͊�ł�');
		end if;
	next;
//70
echo '70���';
	print drink_price('M',TRUE);
	print drink_price('L');
	return;
end proc;
