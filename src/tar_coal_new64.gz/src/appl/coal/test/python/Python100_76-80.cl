//
//
//
class Student ;
	char name;
	int  grace;
	char section;
	array scores hash;

	func Student();
		My.name = '';
		My.grace = 1;
		My.section = 'A';
		return 0;
	end func;

	func Student(name,grace,section);
		My.name = name;
		My.grace = grace;
		My.section = section;
		return 0;
	end func;

	func Student(name,grace,section,score);
		My.name = name;
		My.grace = grace;
		My.section = section;
		array My.scores = *score;
		return 0;
	end func;

	func add_score(subject,score);
	//	print My.scores;
		My.scores[subject] = score;
		return 0;
	end func;

	func total_score();
		sum_score = 0;
		for each score in My.scores;
			sum_score += score.value;
		next;
		return sum_score;
	end func;
end class;

class Card ;
	char suit;
	int  number;
	func Card(suit,number);
		My.suit = suit;
		My.number = number;
		return 0;
	end func;
end class;

class Deck;
	cards = '';
	func Deck();
		cards = [];
//		for each suit in ['�n�[�g','�_�C��','�X�y�[�h','�N���u'];
		for each suit in ['�n�[�g','�_�C��'];
//			for each number in 1..13;
			for each number in 1..2;
				card = new Card(suit.value,number.value);
print card.suit card.number;
				append(My.cards,card);
			next;
		next;
	end func;
	func shuffle();
		return 0;
	end func;
	func draw_card();
		return pop(My.cards);
	end func;
end class;

proc main;
// 76
echo '76���';
	student = new Student('���',2,'B');
	student.add_score('���w',80);
	student.add_score('�p��',70);
	student.add_score('����',90);
	print student.total_score();

// 77
echo '77���';
	student.grace = 3;
	student.section = 'C';
	print student.grace student.section;
// 78
echo '78���';
	student1 = new Student('���',2,'B',{'���w',80,'�p��',70,'����',90});
	student2 = new Student('�c��',2,'B',{'���w',70,'�p��',80,'����',75});
	student3 = new Student('�ē�',2,'B',{'���w',90,'�p��',85,'����',80});
	for each student in student1,student2,student3;
		putline(student.value.name,'����̍��v�_����',student.value.total_score(),'�_�ł�');
	next;

//79
echo '79���';
	option 5 +0x01;

//80
echo '80���';
	deck = new Deck();
	deck.shuffle();
	card = deck.cards[3];
	print card.suit card.number;
/*
	for each card in deck.cards;
//		print card.value;
		print card.value.suit card.value.number;
	next;
*/
	return;
end proc;
