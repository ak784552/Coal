//
//
//
proc main;
// 36
echo '36���';
	a = {1,2,3,4,5};
	b = {4,5,6,7,8};
	c = a & b;
	print c;
// 37
echo '37���';
	c = a - b;
	print c;
// 38
echo '38���';
	c = a | b;
	print c;
//39
echo '39���';
	array nums[10]=[1,12,5,10,13,7,90];
	sort(1,nums,,'C',1,'N D');
	x = $2;
	print x *$();
//40
echo '40���';
	screen_size = [1920, 1080];
	print screen_size;
	return;
end proc;
