//
//
//
proc main;
// 61
echo '61���';
	text = '����������-�͂܂���';
	print text;
	for i=1 to length(text);
		c = substr(text,i,1);
		if c == '-' thenl break;
		echo c;
	next;
// 62
echo '62���';
	ng_numbers = [4,9,13];
	for each x in 1..20;
		if x.value in ng_numbers thenl continue;
		print x.value;
	next;
// 63
echo '63���';
	for each x in 1..20;
		if x.value % 3 then
			echo x.value;
		else
			putline(x.value,'��3�̔{���ł�');
		end if;
	next;
//64
echo '64���';
	array address hash = {
		'���','suzuki@example.com',
		'�c��','tanaka@example.com',
		'�R�c','yamada@example.com',
		'�T�v�[','python.supu@gmail.com'
	};
	array gmail_address hash;

	for each x in address;
		if x.value like '%gmail.com' thenl gmail_address[x.index]=x.value;
	next;
	print *gmail_address;
//65
echo '65���';
	echo '     1  2  3  4  5  6  7  8  9';
	echo '   ----------------------------';
	for each x in 1..9;
		printf('%d :',x.value);
		for each y in 1..9;
			printf('%3d',x.value*y.value);
		next;
		print;
	next;
	return;
end proc;
