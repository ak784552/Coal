//
//
//
proc main;
// 21
echo '21���';
	array numbers[5] = [3,1,4,2,5];
	n = sort(1,numbers);
	print *$()[1..3];
// 22
echo '22���';
//	array numbers[5] = [3,1,4,2,5];
	n = sort(1,numbers,,'C',1,'Desc');
	print *$();
// 23
echo '23���';
	nums = [3,1,4,2,5];
	print sum(nums);
	print max(nums);
	print min(nums);
//24
echo '24���';
	nums = [3,1,4,2,5];
	x = pop(nums,1);
	print x nums;
//25
echo '25���';
	array odd_numbers[5] = [1,3,5,7];
	array even_numbers[5] = [2,4,6,8];
	x = *odd_numbers + *even_numbers;
	n = sort(1,x);
	print *$();
	return;
end proc;
