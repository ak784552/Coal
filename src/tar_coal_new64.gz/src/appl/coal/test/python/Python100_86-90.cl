//
//
//
proc main;
// 86
echo '86���';
	fp = fopen('doc.txt','w');
	fputline(fp,'����ɂ��́I');
	fclose(fp);

// 87
echo '87���';
	fp = fopen('doc.txt','wa');
	fputline(fp,'���悤�Ȃ�I');
	fclose(fp);

// 88
echo '88���';
	fp = fopen('doc.txt','w');
	fputline(fp,'����ɂ��́I');
	fputline(fp,'���悤�Ȃ�I');
	fclose(fp);
	fp = fopen('doc.txt','r');
	loop;
		line = fgetline(fp);
		if ERROR thenl break;
		print line;
	end loop;
	fclose(fp);
//89
echo '89���';
	option 5 +0x01;
	lines = [];
	fp = fopen('doc.txt','r');
	loop;
		line = fgetline(fp);
		if ERROR thenl break;
		append(lines,line);
	end loop;
	fclose(fp);
	print lines;

//90
echo '90���';
	option 7 2;
	x = 10;
	result = 10 / 0;
	print result;
	return;
end proc;
