//
//
//
proc main;
// 1
echo '1���';
	x = 100;
	y = 'abc';
	z = 123.45f;
	print x y z;
// 2
echo '2���';
	x = TO_CHAR(100);
	y = TO_NUMBER('100.1',CLFLOAT);
	z = TO_NUMBER(100.0f,CLINT);

	x = (CHAR)100;
	y = (FLOAT)'100.1';
	z = (INT)100.0f;

	char x = 100;
	float y = '100.1';
	int z = 100.0f;

	print x /i x;
	print y /i y;
	print z /i z;
// 3
echo '3���';
	x = 10;
	y = 2;
	print "x*y + x/y";
	print "x**y - x % y";
//4
echo '4���';
	x = 10;
	y = 20;
	print x+y;
	print to_char(x)&to_char(y);
//5
echo '5���';
	x = 10;
	y = 20;
//	x��y�𑫂������ʂ��o��
	print x+y;

	return;
end proc;
