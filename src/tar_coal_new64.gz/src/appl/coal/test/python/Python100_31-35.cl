//
//
//
proc main;
// 31
echo '31���';
	array months hash = [1,'�r��',2,'�@��',3,'�퐶'];
	array del hash = [3,'�퐶'];
	x = *months - *del;
//	*months -= *del;
	print *x *months;
// 32
echo '32���';
	value = *months - '';
	print *value;
// 33
echo '33���';
	numbers = {1,2,3,4,5};
	print numbers;
//34
echo '34���';
	append(numbers,6);
	pop(numbers,0);
	print numbers;
//35
echo '35���';
	numbers = [1,1,5,2,5,3,3];


	return;
end proc;
