//
define char a[5] = 'abc','xy','',123,'ABCDE';
proc main;
	char c = 12345;
	char(10) c10 = 1234567890;
	print c;// /d c;
	print c10 ;///d c10;
	print a *a;// /d a;
	redefine char a[10];
	print a *a;// /d a;
	redefine char(3) a[10];
	print a *a;// /d a;
	redefine char a[5];
	print a *a;// /d a;
	return ERROR;
end proc;
