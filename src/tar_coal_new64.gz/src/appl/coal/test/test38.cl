//
##define LOGLEVEL(i,level) akb_log_level(i,level)
proc main;
//ptree;
	log_no = 0;
	level = 100;
	if (LOGLEVEL(log_no,-1) < level) thenl return 0;	/* add 2023.5.21 */
//	endif;
	return ERROR;
end proc;
