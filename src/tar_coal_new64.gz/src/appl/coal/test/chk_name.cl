//
// Check Name
//
define array col_attr hash 30;
define array col_err  hash 30;
proc main;
	options 1 "" 2;
	if (%0 < 1);
		putline('usage: ',SCRIPTNAME,' in_file ...');
		return -1;
	end if;
	loop %0 do
		try;
			fpi = fopen(%1);
			fgetline(fpi);
			fgetline(fpi);
			loop do
				line = fgetline(fpi);
//print line;
				n = getargs(line,1,,,',');
//print n 11;
				i = inistr(11,'_');
				if (i > 0) then
					a = substr(11,i+1);
					j = inistr(a,'_');
					if (j > 0) then
						col_err['_' & a]++;
						b = substr(a,1,j);
						col_attr[b]++;
					else
						if (substr(a,4) is 'Number') then
							col_err['_' & a]++;
							a = left(a,3) & '*';
						end if;
						col_attr[a]++;
					end if;
				else
					col_err[11]++;
				end if;
			end do;
		catch FILE_READ_END_EXCEPTION;
		catch;
			print /e ERRMSG;
		finally
			if (fpi) then
				fclose(fpi);
				fpi = 0;
			end if;
			shift;
		end try;
	end do;
	putline('-attr-');
	i = 1;
	for each a in col_attr;
		putline(edit('%5d %5d %s',i,a,a.Index));
		i++;
	netx;
	putline('-error-');
	i = 1;
	for each a in col_err;
		putline(edit('%5d %5d %s',i,a,a.Index));
		i++;
	next;
	return ERROR;
end proc;
