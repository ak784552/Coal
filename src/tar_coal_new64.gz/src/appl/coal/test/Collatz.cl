//
// Collatz
//
proc main;
	if (%0 < 1);
		fputline(STDERR,'usage: ',SCRIPTNAME,' number(from) [(To) [(Incr)]]');
		return -1;
	end if;
	n_f = (long)%1;
	n_t = n_f;
	n_i = 1;
	if %0 >= 2 Then
		n_t = (long)%2;
		if n_t < n_f thenl n_i = -1;
	end if;
	if %0 >= 3 Thenl n_i = (long)%3;
//print n_f n_t n_i;
//getchar();
//	N = (int)%1;
//	while N > 0;
	for i=n_f to n_t step n_i;
		n=i;
//		n = N--;
		fmt = '(%d) --> ';
		loop;
			if n<=1 then
				print /n- n;
				break;
			endif;
			printf fmt n;
			if (n % 2) then
				n = n*3 + 1;
			else
				n /= 2;
			end if;
			fmt = '%d --> ';
		end loop;
//	end while;
	endfor;
	return ERROR;
end proc;
