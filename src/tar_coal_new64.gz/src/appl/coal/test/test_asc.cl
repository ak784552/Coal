//
PROC main;
	print ' ' asc(' ');
	for each x in 'A'..'Z';
		print x.value asc(x.value);
	next;
	for each x in 0..255;
		a = chr(x.value);
		print /nq- edit('%03d',x.value) /q+ iif(is(a,'A'),a,'not ascii');
	next;
	RETURN $ERROR;
END PROC;
