proc main;
	print /e %1 %2 %3 %4 %5 %6 %7;
	return 0;
end proc;
