//
define mappedarray %parm[1,5];
define mappedarray aa[2,15] = [1,2,3,4,5];
def ax[3,5];
proc main;
	print aa *aa ax;
	$1 = 100;
	$7 = 200;
	print $() *$();
	print aa *aa;
	aa[5] = 'X';
	aa[6] = 'Y';
	aa[7] = 'Z';
	print *$();
	print %parm *%parm;
	return ERROR;
end proc;
