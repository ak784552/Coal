//
def ar 10;
proc main;
	aa = ar + 2;
	print aa;

//	print $() /d $();
	setarray(1,11,12,13,14,15);
	print x=$();
	print *x x[0] /d x;
	print y=*$();
	print *y /d y;
	print $() /d $();
	print *$();
	print y[5]=16 *y;
	print $()+1;
	x[5]=26;
	print  *x *$();
	print 3-$();
	yy = $();
	print yy[0] /d yy;
	zz = $() + [0,10];
	print zz *zz /d zz;
	print "xx = $() + [-1,5]";
	print xx /d xx;
	print "xx = $() - [1,5]";
	print "$() - 1";
	print "$() + 65536";

	print pop([1,2,3,4,5],3);
	print [1,2,3,4,5].pop(3);

	print [1,2,3,4,5].3;
	print {1,2,3,4,5}.3;
	print (1,2,3,4,5).3;
	print [].3;
	print {}.3;
	print ().3;

	return $ERROR;
end proc;
