//
proc main;
//	print $() /d $();
	setarray(1,11,12,13,14,15);
	print x=$();
	print *x x[0] /d x;
	print y=*$();
	print *y /d y;
	print $() /d $();
	print *$();
	print y[5]=16 *y;
	print $()+1;
	x[5]=26;
	print  *x *$();
	print 3-$();

	print pop([1,2,3,4,5],3);
	print [1,2,3,4,5].pop(3);

	print [1,2,3,4,5].3;
	print {1,2,3,4,5}.3;
	print (1,2,3,4,5).3;
	print [].3;
	print {}.3;
	print ().3;
	return $ERROR;
end proc;
