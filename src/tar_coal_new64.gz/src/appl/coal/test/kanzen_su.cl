//
##include class_sosu_chk.cl

proc main;
	int n = %1;
	if !n thenl n = 100;
	MAX_LOOP_WHILE = 100000;
	sch = new SosuCheck(100000);
//	sch = new SosuCheck();
//return 0;
	n0=2;
  try;
	for i=0 to n;
		s = sch.get_sosu(i);
		if s < 0 thenl break;
		m = 1.0;
		loop s;
			m *= 2.0;
		endloop;
		m--;
print s m;
		loop;
			if ((ret=sch.sosu_chk_by_tbl_opt(m))>0) then
				kanzen = m*(m+1)/2.0;
				print kanzen;
			elseif ret<0;
				ret = sch.add_next_sosu(m);
				if ret<0;
					putline('*** few sosu table!!');
					break 2;
				endif;
//print sosu[max_sosu-1];
				continue;
			endif;
			break;
		endloop;
	next;
  catch;
	print ERRMSG;
  end try;
	return ERROR;
end proc;
