//
//define array a[10];
proc main;
//	print a[0];
//	x = 'A';
//	print x;
	dec(10,2) d0 = 0.0;
	dec(10,2) d1 = 1.0;
	dec(10,2) d2 = 2.0;
	print d0 d1 d0+d1 d0-d1 d0*d1 d0/d1 d1/d2;
	print d0 d1 d1+d0 d1-d0 d1*d0 d1/d0;
	dec(10,2) d3 = 5.24;
	dec(10,4) d4 = 3.4567;
	d5 = d3 + d4;
	print d5;
	print (dec(4,3))d5;
	print to_number(d5,$CLDEC,4,3);
	return ERROR;
end proc;
