//
// ���͂����P��̐����q�X�g�O����(�x�����z�})�ɂ��ďo�͂���
// �q�X�g�O�����͉��ɏ��������ȒP�����A�c�����ɒ��킵�Ă݂�̂��悢
//
##define YES	1
##define NO		0

option 1 1;

def reg hash 20;
def max_len;

proc main;
	int  nl, nw, nc, inword;
	char c,word;

	call << EOF1;
abc 2234 ff abc ff
xyz	sd234 sssss d ff
EOF1
	inword = NO;
	nl = nw = nc = 0;
	max_reg = 0;
	max_len = 0;
	word = '';
	while c = getchar();
//putchar(c);
		nc++;
		if c == '\n';
			nl++;
		end if;
		if c == ' ' || c == '\n' || c == '\t' || c == '�@';
			inword = NO;
			print word;
			regist(word);
			word = '';
		elseif inword == NO;
			inword = YES;
			nw++;
			word = c;
		else
			word &= c;
		end if;
	end while;
	if word then
		print word;
		regist(word);
	end if;
	print nl nw nc;
	print *reg;
	hist();
	print;
	hist_tate();
	return ERROR;
end proc;

func regist(word);
	reg[word]++;
	len = lenw(word);
	if len>max_len then
		max_len = len;
	end if;
	return ERROR;
end func;

func hist();
	for each x in reg;
		printf('%s %s\n',lpad(x.index,max_len),strings('*',x.value));
	end for;
	return ERROR;
end func;

func hist_tate();
	maxh = max(reg);
//print maxh;
	for (h=maxh;h>0;h--);
		hh = '';
		for each x in reg;
			c = ' ';
			if x.value >= h then
				c = 'H';
			end if;
			hh &= c & ' ';
		end for;
		printf('%s\n',hh);
	end for;
	print;
	for (h=1;h<=max_len;h++);
		hh = '';
		for each x in reg;
			c = substr(x.index,h,1);
			if c == '' then
				c = ' ';
			end if;
			hh &= c & ' ';
		end for;
		printf('%s\n',hh);
	end for;
	return ERROR;
end func;
