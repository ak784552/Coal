//
//
//
##define MAXLINE	100
proc main;
	char line[MAXLINE];
	char pat[4] = {'t','h','e',''};

	while getline(line, MAXLINE) > 0;
		if index(line, pat) > 0 thenl printf('%s\n',concat(line));
	end while;
	return ERROR;
end proc;

function getline(s, lim);
	int i;
	char c;

	i = 0;
	while --lim > 0 && (c=getchar()) != '' && c != '\n' ;
		s[i++] = c;
	end while;
	if c == '\n' thenl s[i++] = c;
	s[i] = '\0';
	return i;
end func;

function index(s, pat);
	int i, j, k;

	for (i = 0; s[i] != ''; i++);
		for (j=i, k=0; pat[k]!='' && s[j]==pat[k]; j++,k++);
		next;
		if pat[k] == '' thenl return i+1;
	next;
	return 0;
end func;
