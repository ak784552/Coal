//
// echo
//
proc main argc argv;
	for (i=0; i < argc; i++);
		printf('%s%c', %argv[i], (i==argc-1) ? '\n' : ' ');
	end for;
	return ERROR;
end proc;
/*
proc main;
	BEXP $1 = 1;
	bexp $2 = %0 - 0;
	loop %0;
		printf '%s' %$1;
		if $1 == $2;
			printf '\n';
		else
			printf ' ';
		endif;
		BEXP $1 = $1 + 1;
	end loop;
	return ERROR;
end proc;
*/
