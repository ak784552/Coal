//
// �e������󔒕����⑼�̕����̏o���p�x�𐔂���
//
proc main;
	int i, nwhite, nother, ndigit[10];
	char c;

	nwhite = nother = 0;
	for (i = 0; i < 10; i++);
		ndigit[i] = 0;
	next;

	while c = getchar();
	//	switch c ;
		switch 1 ;
	//	case '0','1','2','3','4,','5','6','7','8','9';
		case (c>='0' && c<='9');
			ndigit[c]++;
			break;
	//	case ' ','\n','t';
	//	case (c==' '||c=='\n'||c=='t');
		case (in(c,' ','\n','t')>0);
			nwhite++;
			break;
		default;
			nother++;
			break;
		end switch;
	end while;

	printf('digits =');
	for (i = 0; i < 10; i++);
		printf(' %d', ndigit[i]);
	end for;
	printf('\nwhite space = %d, other = %d\n',nwhite, nother);
	return ERROR;
end proc;
