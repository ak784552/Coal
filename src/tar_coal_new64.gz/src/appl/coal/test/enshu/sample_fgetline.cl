//
##define MAXLINE	1000

proc main;
	try (fp=fopen(%1));
		loop;
			line = fgetline(fp);
			print line;
		end loop;
	catch FILE_READ_END_EXCEPTION;
	catch;
		print ERRMSG;
	end try;
	return ERROR;
end proc;

function fgetline(fp);
	char c;

	line = '';
	for (i=0; (i<MAXLINE-1 && (c=getc(fp))<>'' && c<>'\n'); i++);
		line &= c;
	next;
	if c == '\n' then
		line &= c;
		i++;
	end if;
	return line;
end func;
