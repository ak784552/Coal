//
//	sample_swap.cl
//
define c 10={1,2,3};
define d 5={'A','B','C'};
proc main;
	private a = 1;
	b = 2;
	print a b /i a b;
	print swap(&a,&b);
	print a b;
	print '---------------';
	print swap(&a,c);
	c[1] = 'X';
	print a c;
	print *a *c;
	print '---------------';
	a = 1;
	print f(&a,d);
	d[1] = 'X';
	print a d;
	print *a *d;
	return ERROR;
end proc;

function swap(pa,pb);
print 'Enter' pa pb;
print 'Enter' *pa *pb;
	tmp = *pa;
print tmp;
	*pa = *pb;
print *(*pa) pa;
	*pb = tmp;
print 'Exit' *pb pb;
	return 0;
end func;

function f(pa,b);
print b;
	*pa = b;
	return 0;
end func;
