//
//  sample_shell_sort.cl
//
//option 24 1;	// �`�m�c�A�n�q�ŁA�S�Ă̎��̕]�����s��
def v 10 = {10,2,4,3,7,9,8,6,5,1};
proc main;
	shell_sort(v,10);
	print *v;
	return ERROR;
end proc;

function shell_sort(v, n);
	int gap, i, j;

	for (gap = n/2; gap > 0; gap /= 2);
		for (i = gap; i < n; i++);
			for (j=i-gap; j>=0 && v[j]>v[j+gap]; j-=gap);
				temp = v[j];
				v[j] = v[j+gap];
				v[j+gap] = temp;
			end for;
		end for;
	end for;
	return ERROR;
end func;
