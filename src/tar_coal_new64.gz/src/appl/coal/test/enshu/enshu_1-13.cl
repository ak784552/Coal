//
// power�֐��̃e�X�g
//
proc main;
	int i;

	for (i = 0; i < 10; i++);
		print i power_int(2,i) power(-3,i);
	next;
	print;
	for (ii = 0.0; ii < 8.0; ii+=1.5);
		print ii power(2.5,ii) power(-3.5,ii);
	next;
	return ERROR;
end proc;

func power_int(int x, int n) as int;
	p = 1;
	loop n;
		p *= x;
	end loop;
	return p;
end func;

func power(x, n);
	p = 1;
	loop n;
		p *= x;
	end loop;
	return p;
end func;
