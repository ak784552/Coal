//
//  sample_warizan.cl
//
proc main;
	if %0 < 2 then
		printf 'usage: coal %s a b (for a/b)\n' SCRIPTNAME;
	else
		int a = %1;
		int b = %2;
		n = a/b;
		amari = a % b;
		printf '%d / %d = %d ���܂� %d\n' a b n amari;
	endif;
	return ERROR;
end proc;
