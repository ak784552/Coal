//
//	sample_array.cl
//
proc main;
	int arr[10];
	print arr;
	arr[0] = 10;
	arr[1] = 20;
	print *arr;

	x = arr;
	print x;
	x[2] = 30;
	print *arr;
	print *x;
	arr[3] = 40;
	print *arr;
	print *x;

	y = *arr;
	print y *y;

	z = arr + 1;
	print z *z;
	print (arr+1)[0];
	print z[0];
	return ERROR;
end proc;
