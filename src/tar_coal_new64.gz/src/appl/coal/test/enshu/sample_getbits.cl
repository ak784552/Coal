//
proc main;
	print /x getbits(0b00111111,4,3);
	return ERROR;
end proc;

function getbits(x, p, n);
	return (x >>> (p+1-n)) & ~(~0 << n);
end func;
