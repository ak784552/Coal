//
// ���͒��̍s�A�P��A�����̃J�E���g
// �ł��傫���P����o�͂���
//
##define YES	1
##define NO		0

proc main;
	int  nl, nw, nc, inword;
	char c,word,mxa_word;

	call << EOF1;
asd 2234 ff
wwwwwwww
jsdg	sd234 d
ssssss
EOF1
	inword = NO;
	nl = nw = nc = 0;
	word = '';
	max_word = '';
	while c = getchar();
//putchar(c);
		nc++;
		if c == '\n';
			nl++;
		end if;
		if c == ' ' || c == '\n' || c == '\t' || c == '�@';
			inword = NO;
			print word;
			if word > max_word then
				max_word = word;
			end if;
			word = '';
		elseif inword == NO;
			inword = YES;
			nw++;
			word = c;
		else
			word &= c;
		end if;
	end while;
	if word then
		print word;
		if word > max_word then
			max_word = word;
		end if;
	end if;
	print nl nw nc max_word;
	return ERROR;
end proc;
