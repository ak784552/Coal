//
//  sample_printf.cl
//
/*
    [%10s]        [hello, world]
    [%-10s]       [hello, world]
    [%20s]        [        hello, world]
    [%-20s]       [hello, world        ]
    [%20.10s]     [          hello, wor]
    [%-20.10s]    [hello, wor          ]
    [%.10s]       [hello, wor]
*/
proc main;
	a = 'hello, world';
	printf('[%10s]\n',a);
	printf('[%-10s]\n',a);
	printf('[%20s]\n',a);
	printf('[%-20s]\n',a);
	printf('[%20.10s]\n',a);
	printf('[%-20.10s]\n',a);
	printf('[%.10s]\n',a);

	printf('[%s]\n',a);
	printf('%/q[%20s]\n',a);

	return ERROR;
end proc;
