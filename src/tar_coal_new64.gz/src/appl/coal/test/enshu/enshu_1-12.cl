//
// ���͂����P��̐����q�X�g�O����(�x�����z�})�ɂ��ďo�͂���
// �q�X�g�O�����͉��ɏ��������ȒP�����A�c�����ɒ��킵�Ă݂�̂��悢
//
##define YES	1
##define NO		0

option 1 1;

def reg[100];
def num[100];
def max_reg;
def max_len;

proc main;
	int  nl, nw, nc, inword;
	char c,word;

	call << EOF1;
abc 2234 ff abc ff
xyz	sd234 sssss d ff
EOF1
	inword = NO;
	nl = nw = nc = 0;
	max_reg = 0;
	max_len = 0;
	word = '';
	while c = getchar();
//putchar(c);
		nc++;
		if c == '\n';
			nl++;
		end if;
		if c == ' ' || c == '\n' || c == '\t' || c == '�@';
			inword = NO;
			print word;
			regist(word);
			word = '';
		elseif inword == NO;
			inword = YES;
			nw++;
			word = c;
		else
			word &= c;
		end if;
	end while;
	if word then
		print word;
		regist(word);
	end if;
	print nl nw nc;
	print max_reg *reg *num;
	hist();
	print;
	hist_tate();
	return ERROR;
end proc;

func regist(word);
	if w=in(word,reg) then
		split(w,1);
//print w $1 $2;
		num[$2-1]++;
	else
		reg[max_reg] = word;
		num[max_reg] = 1;
		max_reg++;
		len = lenw(word);
		if len>max_len then
			max_len = len;
		end if;
	end if;
	return ERROR;
end func;

func hist();
	for (i=0;i<max_reg;i++);
		printf('%s %s\n',lpad(reg[i],max_len),strings('*',num[i]));
	end for;
	return ERROR;
end func;

func hist_tate();
	maxh = max(num);
	for (h=maxh;h>0;h--);
		hh = '';
		for (i=0;i<max_reg;i++);
			c = ' ';
			if num[i] >= h then
				c = 'H';
			end if;
			hh &= c & ' ';
		end for;
		printf('%s\n',hh);
	end for;
	print;
	for (h=1;h<=max_len;h++);
		hh = '';
		for (i=0;i<max_reg;i++);
			c = substr(reg[i],h,1);
			if c == '' then
				c = ' ';
			end if;
			hh &= c & ' ';
		end for;
		printf('%s\n',hh);
	end for;
	return ERROR;
end func;
