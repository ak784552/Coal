//
//
//
##define EOF	-1

proc main;
	int n;

	loop;
		if getint(&n) == EOF thenl break;
		print n;
	end loop;
	return ERROR;
end proc;

function getint(pn);	/* ���͂�莟�̐��������o�� */
	int rc, sign;
	char c;

	while (c=getch())==' ' || c=='\n' || c=='\t';	/* �󔒕������X�L�b�v */
	end while;

	sign = 1;
	if c=='+' || c=='-' then
		sign = (c=='+') ? 1 : -1;	/* �����Z�b�g */
		c = getch();
	end if;
	for (*pn=0; c>='0' && c<='9'; c=getch());
print c;
		*pn = 10 * *pn + c;	 /* �����ϊ� */
	end for;
	*pn *= sign;
print *pn c;
	if c<> '' then
		rc = 0;
	else
		rc = EOF;
	end if;
print rc EOF;
	return rc;
end func;

function getch();
	static char buf = '\0';
	static int  pos = 1;

	while (c = substr(buf, pos, 1)) == '' || c == '\n';
		buf = getline();
		if ERROR thenl return '';
		pos = 1;
		c = substr(buf, pos++, 1);
print buf c;
	end while;
print pos c;
	pos++;
	return c;
end func;
