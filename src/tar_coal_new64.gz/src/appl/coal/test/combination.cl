//
// �g�ݍ��킹   nCr
//
func combination(n, r);
	dec(54) m;

	if (r > n-r) then
		r = n-r;
	end if;
	if (r == 0.0 || r == n) ;
		m = 1.0;
	elseif (r == 1.0);
		m = n;
	else
		m = 1.0;
		mr = 1.0;
		for (i = 0 ; i < r ; i++);
			m = m * (n - i);
			mr = mr * (r - i);
		next;
print m;
print mr;
		m = m/mr;
	end if;
	return m;
end func;

proc main();

	print %1 %2 combination((dec)%1,(dec)%2);

	return ERROR;
end proc;
