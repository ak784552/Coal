//
proc main;
	print "1 and 0";
	print "'A' and 'B'";
	print "1 OR 0";
	print "'X' OR 'C'";
	K = 5;
	print K "K GT 0 AND K LT 10";
	print K "K GT 0 && K LT 10";
	print K "K GT 0 OR K LT 10";
	print K "K GT 0 || K LT 10";
	K=0;
	print K "K GT 0 AND K LT 10";
	print K "K GT (0 AND K) LT 10";
	return ERROR;
end proc;
