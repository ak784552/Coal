//
//define array $a 10 3 5;
//define array dec(10,2) $a [10,3,5] =[1,2,3,4,5];
define array dec(10,2) $a [10] =[1,2,3,4,5];
proc main;
//	print a *a;
	print a[4];
/*
	$x = 'a';
//	$x = $a;
//	$1 = $a[0];
//	$x[0] = 100;
//	print $a[0];
	$($x)[0] = 100;
	print $($x)[0];
//	$($x) = 100;
//	$('a') = 100;
//	$y = $a[0];
//	$a[0] = 100;
//	$a[0] = 200;
*/
	return ERROR;
end proc;
