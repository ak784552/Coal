//
// log_seikei.cl
//
define array $list 200;
define array $timelog hash 100;
proc main;
	$i = 1;
	loop 4;
		$file = 'hon' &+ $i &+ '/touka.log';
		$fpi = fopen($file);
		if (!$fpi);
			putline('file(',$file,') open error.',ERRMSG);
			return ERROR;
		end if;
		loop while (1);
			$line = fgetline($fpi);
			if (ERROR < 0); break; endif;
//putline('read: line = ',$line);
			$n = getargs($line,1);
			if ($3=='touka_all_dir.sh:');
				$timelog[$5,$i,$4] = substr($1 &+ ' ' &+ $2,3,14);
putline('table=',$5,' i=',$i,' ',$4,' =',$timelog[$5,$i,$4]);
			end if;
		end loop;
		$i++;
	end loop;
	fclose($fpi);
	return ERROR;
end proc;
