//
define mappedarray ma 1 10;
proc main;
	setarray($(),100,3/5r,'X','Y','Z');

	print ma ma[0];
	print $() *$();
	print append($(),'A');

	print append(1,'C');
	print $() *$();

	xx = $() + 2;
	print xx *xx;
	print append(xx,'B');
	print xx *xx;
	print $() *$();

	return ERROR;
end proc;
