//
define mappedarray ma 1 10;
proc main;
	setarray($(),100,3/5r,'X','Y','Z');
	print ma ma[0];
	print $() *$();
	print append($(),'A');
	print $() *$();
	xx = $() + 2;
	print xx *xx;
	print append(xx,'B');
	print xx *xx;
	print $() *$();
	print $()[1] xx[0];
	print /d xx $();
	yy = $();
	print yy[0] /d yy;
	zz = $() + 0;

	return ERROR;
end proc;
