//
def onew hash 10;
proc main;
	onew['AAA'] = '';
	const x = 'XXX';
	loop each $x in {1,'A'};
		print *x;
	end loop;
	print x;
	return ERROR;
end proc;
