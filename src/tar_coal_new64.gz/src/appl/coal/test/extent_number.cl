// test_mpa_log10
//
// log10((S/M+A0)/A0 = n*log10(R)
//
proc main;
	double S = %1;
	double M = %2;
	double A0= %3;
	double R = %4;
	A = log10((S/M+A0)/A0);
	B = log10(R);
	N = A/B;
	print A B N R**N;
	print SQRT(S/(65535.0D*2.0D));
	print 32.0D*32.0D*65535.0D*2.0D;
	return $ERROR;
end proc;
