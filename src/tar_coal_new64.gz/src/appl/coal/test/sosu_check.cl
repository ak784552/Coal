//
define MAX_SOSU	=100000;
define int gFlag;
int sosu MAX_SOSU =
	{ 2,  3,  5,  7, 11, 13, 17, 19, 23, 29,
	 31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
	 73, 79, 83, 89, 97,101,103,107,109,113,
	127,131};
proc main;
	dim ret,b,i,k,count as int;
	dim max_sosu,msosu,msosu2,i0,last,opt,max as int;

	max_sosu=countv(sosu);
	putline('initial sosu table size=',max_sosu);
	count_sosu=0;
	for (;;) do;
		elwrite('Entry check number(end <=0) ==> ');
		nums = getline();
		if nums == 'max' then
			num = LONG_MAX - 1000;
		else
			num = (CLONG)nums;
			if (num <= 0) thenl break;
		end if;
		print num;
		MAX_LOOP_WHILE = num + 1000;
		msosu = sosu[max_sosu-1];
		if ((ret=akxg_sosu_chk_by_tbl_opt(sosu,max_sosu,num,1))>0) then
			printf('%d is sosu\n',num);
			if gFlag thenl print count_sosu;
		elseif (ret == -1) then
			putline('\n*** table null');
			break;
		elseif (ret == -2) then
break;
			putline('expand sosu table.');
			l2 = (CLONG)sqrt(num);
			while max_sosu<MAX_SOSU;
				msosu += 2;
				if ((ret=akxg_sosu_chk_by_tbl_opt(sosu,max_sosu,msosu,0))>0) then
					if !(max_sosu % 100) thenl printf('sosu table size = %d\n',max_sosu);
					sosu[max_sosu++] = msosu;
					if num % msosu then
						if msosu > l2 then
							printf('%d is sosu\n',num);
							break;
						end if;
					else
						printf('%d = %d * %d\n',num,msosu,num/msosu);
						break;
					end if;
				endif;
			end while;
			if max_sosu >= MAX_SOSU then
				putline('\n*** sosu table over(%d >= %d)',max_sosu,MAX_SOSU);
			else
				printf('sosu table size = %d\n',max_sosu-1);
			endif;
		endif;
	next;
	return 0;
end proc;

//*************************
// �ԋp : = 1 : �f��
//*************************
func akxg_sosu_chk_by_tbl_opt(sosu,max_size,l,opt);
	dim i,mmax,m as long;
	dim ll,l1,l2 as long;

	mmax=max_size;
//print sosu max_size l opt;
	if (!(sosu)) thenl return -1;
	ll = l;

	if (ll < 2) then return 0;
	elseif (ll == 2) then return 1;
	elseif (ll <= 7) then
		if (ll&0x01) thenl return 1;
		return 0;
	end if;

	l2 = (CINT)sqrt(ll);
//print l2;
	for (i=0;i<mmax;i++) do;
		if (!(ll % (m=sosu[i]))) then
			if opt thenl printf('%ld = %d * %d\n',ll,m,ll/m);
			break;
		endif;
		if (m > l2) thenl break;
	next;
	if (i>=mmax) then
//putline('akxg_sosu_chk: ll=',ll,' l2=',l2,' i='.i,' m=',m); 
		return -2;
	elseif (m>l2) thenl return 1;

//putline('akxg_sosu_chk: ll=',ll,' l2=',l2,' i='.i,' m=',m); 

	return 0;
end func;
