//
func fun(x);
	return x**3 - 2*x**2 + 1;
end func;

func derivative(f, x, h);
	return (f(x+h) - f(x)) / h;
end func;

proc main;
	h = 0.001;
	for each x in range(0, 2.0, h);
		print derivative(fun,x.value,h);
	next;
	return ERROR;
end proc;
