//
option 17 1;
proc main;
	double x,y,k1,k2,h;
	N=20;
	//�����l
	x=0.0;
	y=1.0;
	h=(1.0-0.0)/N; //���ݕ�

	print 'x       y       y_true';
	print /n- x y y_true(x);
	for(i=0; i<N; i++);
		k1 = h*f(x,y);
		k2 = h*f(x+h,y+k1);
		y = y + (k1+k2)/2.0;
		x = x + h;
		print /n- x y y_true(x);
	next;
	return ERROR;
end proc;

func f(double x,double y) as double;
  return x*y;
end func;

func y_true(double x) as double;
  return exp(x*x/2.0);
end func;
