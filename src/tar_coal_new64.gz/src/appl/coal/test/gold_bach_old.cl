//
define const MAX_SOSU =100000;
dec sosu MAX_SOSU =
	{ 2,  3,  5,  7, 11, 13, 17, 19, 23, 29,
	 31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
	 73, 79, 83, 89, 97,101,103,107,109,113,
	127,131};
proc main;
	MAX_LOOP_WHILE = 100000;
//print *sosu;
	max_sosu=32;
	n0=2;
  try;
	for k=6 to 100 step 2;
		i=1;
		k2 = k / 2;
		printf '%5d = ' k;
		loop;
			s = sosu[i++];
			if s > k2 thenl break;
			m = k - s;
//print m;
			if ((ret=akxg_sosu_chk_by_tbl_opt(sosu,max_sosu,m))>0) then
				printf '%2d+%2d, ' s m;
			elseif ret<0;
				max_sosu = add_next_sosu(sosu,max_sosu,m);
				if max_sosu<0;
					putline('*** few sosu table!!');
					break 2;
				endif;
//print sosu[max_sosu-1];
			endif;
		endloop;
		print;
	next;
  catch;
	print ERRMSG;
  end try;
	return ERROR;
end proc;

func akxg_sosu_chk_by_tbl_opt(sosu,max_size,l);
	dim i,mmax,m as dec(50,0);
	dim ll,l1,l2 as dec(50,0);

	mmax=max_size;
	if (!(sosu)) thenl return -1;
	ll = l;

	if (ll < 2) then return 0;
	elseif (ll == 2) then return 1;
	elseif (ll <= 7) then
		if (ll&0x01) thenl return 1;
		return 0;
	end if;

	l2 = sqrt(ll);
	for (i=0;i<mmax;i++) do;
		if (!(ll % (m=sosu[i]))) then
			break;
		endif;
		if (m > l2) thenl break;
	next;
	if (i>=mmax) then
		return -2;
	elseif (m>l2) thenl return 1;
	return 0;
end func;

func add_next_sosu(sosu,max_sosu,m);
	i0 = sosu[max_sosu-1] + 2;
//	$max = (CINT)sqrt(m)+1;
	$max = m;
print max_sosu m i0 $max;
	for (i=i0;i<=$max;i+=2);
		if (ret=akxg_sosu_chk_by_tbl_opt(sosu,max_sosu,i))>0 then
			if max_sosu<MAX_SOSU then
				sosu[max_sosu++] = i;
			endif;
		elseif ret<0;
			return ret;
		endif;
	next;
print max_sosu;
	return max_sosu;
end func;
//8589869056

