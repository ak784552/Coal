//Attribute VB_Name = 'Module1';
//Option Compare Database;
#>define Object Integer
#>define Database Variant
#>define Recordset Variant
dim Const F_PATH As String = 'C:\temp\';
dim Const LOG_NAME As String = 'error_log.txt';
dim Const DAT_NAME As String = '�o�׎w�}��.txt';
dim Const MAX_LINE As Integer = 60;
Dim fs As Object;
Dim df As Object;
Dim page As Integer;
Dim line As Long;

Sub main();

    Dim DB As Database;
    Dim RS As Recordset;
    Dim SQL As String;
    Dim SQLArray As Variant;
    Dim RECCnt As Long;
    Dim s As String;
    Dim key0 As String;
    Dim key As String;
    variant dat(5);
    Integer suu(25);

    dir_log = F_PATH;
    dir_dat = F_PATH;
    file_log = LOG_NAME;
    file_dat = DAT_NAME;

    //�t�@�C���I�[�v��;
    filename = dir_dat & file_dat;
    Set fs = CreateObject('Scripting.FileSystemObject');
    Set df = fs.OpenTextFile(filename, 2, True);

    //�w�b�_�o��;
    page = 1;
    line = header(page);

    Set DB = CurrentDb;

    $SQL = 'SELECT';
    $SQL = $SQL & '   C.PROD_COD';
    $SQL = $SQL & '  ,D.PROD_NAM';
    $SQL = $SQL & '  ,D.PROD_UNIT';
    $SQL = $SQL & '  ,A.COURCE_NO';
    $SQL = $SQL & '  ,sum(C.NUM) as COUNT';
    $SQL = $SQL & ' FROM CUSTMER      as A';
    $SQL = $SQL & '     ,ORDER_HEADER as B';
    $SQL = $SQL & '     ,ORDER_CONT   as C';
    $SQL = $SQL & '     ,PROD         as D';
    $SQL = $SQL & ' WHERE A.CUSTMER_COD = B.CUSTMER_COD';
    $SQL = $SQL & '   AND B.ORDER_NO    = C.ORDER_NO';
    $SQL = $SQL & '   AND C.PROD_COD    = D.PROD_COD';
    $SQL = $SQL & ' GROUP BY C.PROD_COD, D.PROD_NAM, D.PROD_UNIT, A.COURCE_NO';

    Set RS = DB.OpenRecordset($SQL, dbOpenSnapshot);

    If RS.EOF = False Then;
        exec IP suu0(suu);
        exec IP set_dat(RS, dat);
        key0 = dat(0);
        suu(dat(3)) = dat(4);
//MsgBox (dat(0) & dat(1));
        RS.MoveNext;
    End If;
    Until RS.EOF = True;
        key = RS!PROD_COD;
        If key0 <> key Then;
            If line + 4 > MAX_LINE Then;
                page = page + 1;
                line = header(page);
            End If;
            exec IP detail(dat, suu);
            line = line + 4;
            exec IP suu0(suu);
            key0 = key;
        End If;
        exec IP set_dat(RS, dat);
        suu(dat(3)) = dat(4);
        RS.MoveNext;
    end until;
    If line + 4 > MAX_LINE Then;
        page = page + 1;
        line = header(page);
    End If;
    exec IP detail(dat, suu);

    RS.Close;
    DB.Close;

    //�t�@�C���N���[�Y;
    Err.Clear;
    df.Close;

End Sub;

Function header(p As Integer);
    Dim s As String;

    s = Space(56) & '�����@�o�@�ׁ@���@�v�@�\�@����' & Space(37);
    s = s & '���t ' & Format(Now(), 'YYYY.MM.DD') & '  �� ' & pernd(5, p);
    exec IP putline(s);
    s = Space(123) & '���� ' & Time();
    exec IP putline(s);
    exec IP putline('');
    s = ' ���� �i�@��' & Space(20) & '�O���݌�<-----------------�@�R�@�[�@�X�@�ʁ@�o�@�ׁ@���@---------------->';
    s = s & '          �w����ʁ@�@�ۈ牀';
    exec IP putline(s);
    s = '      �K�@�i' & Space(20) & '��������    1    2    3    4    5    6    7    8    9   10   11   12   13';
    s = s & '          �@�@���`�@���ʎ�';
    exec IP putline(s);
    s = Space(40) & '   14   15   16   17   18   19   20   21   22   23   24   25     �R�[�X�v�@�@�@�Д́@�@���̑��@�o�׍��v�@�@�����c';
    exec IP putline(s);
    exec IP putline('');
    header = 7;

End Function;

Sub set_dat(ByRef RS As Recordset, ByRef dat);
    dat(0) = RS!PROD_COD;
    dat(1) = RS!PROD_NAM;
    dat(2) = RS!PROD_UNIT;
    dat(3) = RS!COURCE_NO;
    dat(4) = RS!Count;
End Sub;

Sub suu0(ByRef suu() As Integer);
    Dim i As Integer;

    For i = 0 To 25;
        suu(i) = 0;
    Next;
End Sub;

Sub detail(ByRef dat, ByRef suu() As Integer);
    Dim s As String;
    Dim i As Integer;
    Dim m As Integer;
    Dim su As Integer;
    Dim zaiko As Integer;
    Dim nyuka As Integer;
    Dim zan As Integer;
    Dim gaku As Integer;
    Dim hoik As Integer;
    Dim kari As Integer;
    Dim toku As Integer;
    Dim shahan As Integer;
    Dim sonota As Integer;

    zaiko = 1484;
    nyuka = 300;
    gaku = 1;
    hoik = 2;
    kari = 3;
    toku = 4;
    shahan = 5;
    sonota = 6;
    s = perns(5, dat(0), 1) & ' ' & perns(26, dat(1), 0) & pernd(8, zaiko);
    m = 0;
    For i = 1 To 13;
        su = suu(i);
        m = m + su;
        s = s & su2s(5, su);
    Next;
    s = s & pernd(18, gaku) & pernd(10, hoik);
    exec IP putline(s);
    s = '      �i' & perns(6, dat(2), 1) & ' �j' & pernd(23, nyuka);
    For i = 14 To 25;
        su = suu(i);
        m = m + su;
        s = s & su2s(5, su);
    Next;
    zan = zaiko - m;
    s = s & pernd(13, m) & pernd(10, kari) & pernd(10, toku);
    exec IP putline(s);
    s = Space(113) & pernd(10, shahan) & pernd(10, sonota) & su2s(10, m) & pernd(10, zan);
    exec IP putline(s);
    exec IP putline('');
End Sub;

Function su2s(ByVal n As Integer, ByVal num As Integer) As String;
    Dim x As String;

    If num > 0 Then;
        x = pernd(n, num);
    Else;
        x = Space(n - 1) & '-';
    End If;
    su2s = x;
End Function;

Function pernd(ByVal n As Integer, ByVal num As Integer) As String;
    Dim s As String;

    s = CStr(num);
    If Len(s) <= n Thenl s = Right(Space(n) & s, n);
    pernd = s;
End Function;

Function perns(ByVal n As Integer, ByVal name As String, ByVal flg As Integer) As String;
// flg: =0 �O�l��, <>0 ���l��;
    Dim s As String;
    Dim m As Integer;
    Dim mb As Integer;
    Dim nb As Integer;
    Dim i As Integer;

    mb = 0;
    m = 0;
    For i = 1 To Len(name);
        s = Mid(name, i, 1);
        nb = LenB(StrConv(s, vbFromUnicode));
        If mb + nb > n Then;
            Exit For;
        End If;
        mb = mb + nb;
        m = i;
    Next;
    s = Left(name, m);
    If n > mb Then;
        If flg = 0 Then;
            s = s & Space(n - mb);
        Else;
            s = Space(n - mb) & s;
        End If;
    End If;
    perns = s;
End Function;

Sub putline(s As String);
    df.WriteLine (s);
End Sub;

Sub ERROROUT(status As String, msg As String);
    Dim fs As Object;
    Dim df As Object;

    //�G���[���������Ȃ�;
//    On Error Resume Next;

    //DDL�t�@�C���I�[�v��;
    Set fs = CreateObject('Scripting.FileSystemObject');
    Set df = fs.OpenTextFile(dir_log & file_log, 8, True);

    df.WriteLine (Format(Now, 'yyyy/mm/dd hh:mm:ss') & ',' & status & ',' & msg);

    //DDL�t�@�C���N���[�Y;
    Err.Clear;
    df.Close;

End Sub;

