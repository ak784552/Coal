//
define array $a 10;
proc main;

	$101 = 1000;
	$a[1] = 101;
//	$2 = 1;
//	$$2 = 200;
	$$a[1] = 2000;
	print $a $a[1] $$a $$a[1];
//	print $1 $$a[1];
	print $$a[1];

	print $$a $;
	print $$;
	print $$a(1);
	return ERROR;
end proc;
