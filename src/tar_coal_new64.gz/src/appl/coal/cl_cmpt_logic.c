static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/*																	*/
/*	�@�\�� : �_�����Z����											*/
/*																	*/
/*	�֐��� : int cl_cmpt_logic(pAns,pOprtr,pInfoParm1,pInfoParm2)	*/
/*					(O)int		   *pAns							*/
/*					(I)char		   *pOprtr							*/
/*					(I)tdtInfoParm *pInfoParm1						*/
/*					(I)tdtInfoParm *pInfoParm2						*/
/*																	*/
/*	�߂�l : ERROR													*/
/*			 NORMAL													*/
/*																	*/
/*	�����T�v : 														*/
/*																	*/
/********************************************************************/
/* 210060000 */
#include <colmn.h>
extern CLPRTBL *pGLprocTable;
extern CLPRTBL *pCLprocTable;
extern GlobalCt *pGlobTable;
extern int giOptions[];

/****************************************/
/*	210060101							*/
/****************************************/
int cl_get_logic_val(pInfoParm1)
tdtInfoParm *pInfoParm1;
{
	int rc,atr,len;
	long Value;
	double dValue;
	char *dat;
	MPA *mpa;

	rc = 1;
	/* 2023.1.1 */
	if (pInfoParm1->pi_id == 'S') pInfoParm1 = (tdtInfoParm *)pInfoParm1->pi_pos;
	if (cl_is_null_value(pInfoParm1)) rc = 0;
	else if (pInfoParm1->pi_id == ' ') {
		atr = pInfoParm1->pi_attr;
		dat = pInfoParm1->pi_data;
		len = pInfoParm1->pi_dlen;	/* add 2026.4.2 */
		/* 2025.1.24 */
		if (atr>=2 && atr<=4) {
			rc = !cl_is_num_zero(atr,dat);
		}
#if 1	/* add 2026.4.2 */
		else if (len > 0) {
			if (!*dat) rc = 0;
		}
#endif
		else if (!len) rc = 0;
	}
	return rc;
}

/****************************************/
/*	210060201							*/
/****************************************/
int cl_cmpt_logic(pAns,pOprtr,pInfoParm1,pInfoParm2)
long *pAns;
char *pOprtr;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	int rc=0,Result,atr[2],len[2],i,k,Value[2];
	double dValue;
	char *dat[2];
	uchar *p;
	MPA *mpa;

	/* 2021.10.28 */
	Value[0] = cl_get_logic_val(pInfoParm1);
	Value[1] = cl_get_logic_val(pInfoParm2);
/*
printf("cl_cmpt_logic: Value1=%d Value2=%d pOprtr=[%s]\n",Value[1],Value[1],pOprtr);
*/
	sswitch( pOprtr )
		sicase( "AND" )
				Result = Value[0] & Value[1];
		sicase( "OR" )
				Result = Value[0] | Value[1];
		scase( "&&" )
				Result = Value[0] & Value[1];
		scase( "||" )
				Result = Value[0] | Value[1];
		sicase( "NOT" )
				Result = ! Value[1];
		scase( "!" )
				Result = ! Value[1];
		sdefault
			/* cl_cmpt_logic: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"cl_cmpt_logic",pOprtr);
			Result = 0;
			rc = ECL_SCRIPT_ERROR;
	endssw;

	*pAns = Result;
	return rc;

}

/****************************************/
/*	210060301							*/
/****************************************/
int cl_cmpt_agg(pInfoParmW,pOprtr,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW;
char        *pOprtr;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	int ret;
	char op,id1,id2;
	tdtRbCtl *pCt;
	tdtInfoParm tInfoParm;

DEBUGOUT_InfoParm(194,"cl_cmpt_agg: op=[%c] pInfoParm1=",pInfoParm1,*pOprtr,0);
DEBUGOUT_InfoParm(194,"cl_cmpt_agg:        pInfoParm2=",pInfoParm2,0,0);

	op = *pOprtr;
	id1 = pInfoParm1->pi_id;
	id2 = pInfoParm2->pi_id;
	if (id1=='L' || id2=='L' || id1=='N' || id2=='N') {
		if (op=='+' || op=='|' || op=='*') {
			ret = cl_gx_list_add(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else if (op=='-' || op=='&' || op=='^' || op=='/') {
			ret = cl_gx_list_minus(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else {
			ERROROUT1(FORMAT(256),pOprtr);	/* cl_cmpt_agg: non suported operater(%s)!! */
			ret = -1;
		}
		if (ret>=0 && !(pGlobTable->options[4] & 0x01)) {
			if (pCt = (tdtRbCtl *)pInfoParmW->pi_data) {
				if (akxs_rb_used(pCt) <= 0) cl_null_char(pInfoParmW);
			}
		}
	}
	else {
		if (op=='*' || (op=='+' && cl_get_option(2,0) & 0x2000)) op = '|';	/* add 2025.8.29 */
		if (op=='+' || op=='|') {
			ret = cl_gx_array_add(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else if (op=='-' || op=='&' || op=='^' || op=='/') {
			ret = cl_gx_array_minus(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else {
			ERROROUT1(FORMAT(256),pOprtr);	/* cl_cmpt_agg: non suported operater(%s)!! */
			ret = -1;
		}
	}
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_cmpt_agg:Exit ret=%d pOprtr=[%s] pInfoParmW=",pInfoParmW,ret,pOprtr);
	return ret;
}

/****************************************/
/*	210060401							*/
/****************************************/
int cl_func_logic(ppWork,pOperator,nparm,ppParm,ope)
char **ppWork;
char *pOperator;
tdtInfoParm **ppParm;
int nparm,ope;
{
	tdtInfoParm *pInfoParm;
	int  i,val,iAND,iOR;
	char *pWork;

	pWork = *ppWork;
	iAND = 1;
	iOR  = 0;
	for (i=0;i<nparm;i++) {
		pInfoParm = ppParm[i];
		if (!cl_is_null_parm(pInfoParm)) {
			val = cl_get_logic_val(pInfoParm);
			if (ope==D_FUC_OR && val) {
				iOR = 1;
				break;
			}
			else if (ope==D_FUC_AND && !val) {
				iAND = 0;
				break;
			}
		}
	}
	if (ope == D_FUC_AND) val = iAND;
	else val = iOR;
	memcpy(pWork,&val,sizeof(int));
	return DEF_ZOK_BINA;
}

/****************************************/
/*	210060501							*/
/****************************************/
int cl_gx_tenkai(ppmstk,irs,pInfoParmW,da2,opt,pmstk,dastk,Ms_ppmstk,Ms_pmstk,Ms_dastk)
tdtInfoParm *pmstk,*pInfoParmW,*ppmstk[];
int irs,opt;
char *da2,*dastk[];
MCAT *Ms_ppmstk,*Ms_pmstk,*Ms_dastk;
{
	tdtRbCtl *pCt;
	tdtInfoParm *pInfo,*pmW,*pm;
	tdtInfoParm *pInfoParm1,*pParmI;
	tdtInfoParm ***pTBL;
	tdtArrayIndex tIndex,*pIndex;
	XHASHB *xhp;
	char id,*p1,idm;
	int rc,optW,nm,*index,ix;

	id = pInfoParmW->pi_id;
	if (id==' ' && (pInfoParmW->pi_alen & D_AULN_RANGE_DATA)) {
		pInfoParmW->pi_aux[0] |= DEF_ZOK_DATA; 
		optW = opt;
		irs = cl_gx_range_tenkai(ppmstk,irs,pInfoParmW,optW,pmstk,dastk,
		                         Ms_ppmstk,Ms_pmstk,Ms_dastk);
	}
	else if (id=='L' || id=='N' || id=='A' || id=='R') {
		if (id=='L' || id=='N') {
			pCt = (tdtRbCtl *)pInfoParmW->pi_data;
			akxs_rb_read(pCt,0);
		}
		else {
			pIndex = &tIndex;
			if (rc=cl_get_array_index_tbl_ref(pInfoParmW,&pIndex,&pTBL,"cl_gx_array_bexp:")) return rc;
			index = pIndex->index;
			if (xhp=pIndex->xhp) {
				if (!(p1 = (char *)pInfoParmW->pi_pos)) p1 = "";
						/* "%s: �A�z�z��(%s)�͎w��ł��܂���B*/
				ERROROUT2(FORMAT(239),"cl_gx_tenkai",p1);
				irs = ECL_SCRIPT_ERROR;
			}
		}
		nm = 0;
		ix = 1;
		while (irs >= 0) {
			if (id=='L' || id=='N') {
			/*	if (!(pInfo = (tdtInfoParm *)akxs_rb_get_n(pCt))) break;	*/
				if (!(pInfo = (tdtInfoParm *)akxs_rb_read(pCt,1))) break;
			}
			else {
				if (ix > index[2]) break;
				if (!(pInfo = cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,'r'))) return -1;
				ix++;
			}
			/* 2024.9.15 */
			if (cl_gx_expand(Ms_pmstk,irs,&pmstk) < 0) return -4;
			pmW = &pmstk[irs];
			cl_gx_copy_info(pmW,pInfo);
			if (pmW->pi_id == 'S') pm = (tdtInfoParm *)pmW->pi_pos;
			else pm = pmW;
			if (!(idm=pm->pi_id)) p1 = "";
			else if (idm == ' ') parm_to_char_tmp(pm,&p1,0);
			else p1 = clstrdup(cl_get_variable_type(idm),D_OPT_ALC_TMP);
			/* 2024.9.15 */
			if (cl_gx_expand(Ms_ppmstk,irs,&ppmstk) < 0) return -4;
			if (cl_gx_expand(Ms_dastk,irs,&dastk) < 0) return -4;
			dastk[irs] = p1;
			ppmstk[irs++] = pmW;
			pInfo->pi_alen &= ~D_AULN_RANGE_INTVAL;	/* �r���͈��t���Ȃ� */
			nm++;
		}
		if (nm > 1) pmW->pi_alen |= D_AULN_RANGE_INTVAL;	/* �W�J���ꂽ�f�[�^�I���̈� */
	}
	else {
		/* %s: %s��'%s'�͎w��ł��܂���B */
		ERROROUT3(FORMAT(140),"cl_gx_tenkai",da2,"**");
		irs = ECL_EX_LET;
	}
	return irs;
}

/****************************************/
/*	210061101							*/
/****************************************/
static int _pop_array_pTBL(close_gap,nm,ngap,pIndex,pTBL,iFREE)
char *close_gap;
int nm,ngap,iFREE;
tdtArrayIndex *pIndex;
tdtInfoParm ***pTBL;
{
	tdtInfoParm *pInfo1,*pInfo2;
	int i,i2,mode,opt,count,*index;
	char c,*p;
/*
printf("_pop_array_pTBL:Enter nm=%d ngap=%d iFREE=%08x\n",nm,ngap,iFREE);
*/
	if (nm<=0 || ngap<=0) return 0;

	index = pIndex->index;
/*
printf("_pop_array_pTBL: index=%d %d %d %d %d %d\n",index[0],index[1],index[2],index[3],index[4],index[5]);
*/
	opt = cl_get_option(1,0) & 0x01;
	i2 = nm;
	count = mode = 0;
	p = close_gap;
	for (i=0;i<nm;i++) {
		c = *p++;
		if (mode) {
			if (!c) {
				if (!(pInfo1 = cl_get_array_and_var_ent_opt(pIndex,pTBL,i+1,'r'))) return -1;
				if (!(pInfo2 = cl_get_array_and_var_ent_opt(pIndex,pTBL,i2+1,'r'))) return -1;
				if (iFREE) cl_free_info_parm(pInfo2);
				cl_gx_copy_info(pInfo2,pInfo1);
				i2++;
/*
printf("_pop_array_pTBL: i=%d i2=%d\n",i,i2);
*/

			}
			else {
				count++;
			}
		}
		else {
			if (c) {
				mode = 1;
				i2 = i;
				count = 1;
			}
		}
	}
/*
printf("_pop_array_pTBL: i2=%d count=%d\n",i2,count);
*/
	count = 0;
	for (i=i2;i<nm;i++) {
		if (!(pInfo1 = cl_get_array_and_var_ent_opt(pIndex,pTBL,i+1,'r'))) return -1;
		if (opt) cl_null_char(pInfo1);
		else cl_parm_set0(pInfo1);
	}
	/* index[]�́A�e�̂��̂����A�����ύX���Ă����f����Ȃ��B */
	/* �e�́ApSize[]��ύX����K�v������B */
/*
printf("_pop_array_pTBL:Exit i2=%d mode=%d count=%d\n",i2,mode,count);
*/
	return count;
}

/****************************************/
/*	210061201							*/
/****************************************/
static int _pop_array_vari(close_gap,nm,ngap,pIndex,iFREE)
char *close_gap;
int nm,ngap,iFREE;
tdtArrayIndex *pIndex;
{
	tdtInfoParm **pw,*pInfo,**gap;
	int i,i2,mode,opt,count,*index;
	char c,*p;
/*
printf("_pop_array_vari:Enter nm=%d ngap=%d iFREE=%08x\n",nm,ngap,iFREE);
*/
	if (nm<=0 || ngap<=0) return 0;

	if (!(gap = (tdtInfoParm **)TEMPMalloc(nm))) return ECL_MALLOC_ERROR;
	index = pIndex->index;
	pw = pIndex->pVarIndex + index[3];
	i2 = nm;
	count = mode = 0;
	p = close_gap;
	for (i=0;i<nm;i++) {
		c = *p++;
		if (mode) {
			if (!c) {
				pw[i2++] = pw[i];
/*
printf("_pop_array_vari: i=%d i2=%d\n",i,i2);
*/
			}
			else {
				gap[count] = pw[i];
				count++;
			}
		}
		else {
			if (c) {
				mode = 1;
				i2 = i;
				gap[0] = pw[i];
				count = 1;
			}
		}
	}
/*
printf("_pop_array_vari: i2=%d count=%d\n",i2,count);
*/
	opt = cl_get_option(1,0) & 0x01;
	count = 0;
	for (i=i2;i<nm;i++) {
		pInfo = gap[count++];
		if (iFREE) cl_free_info_parm(pInfo);
		else {
			if (opt) cl_null_char(pInfo);
			else cl_parm_set0(pInfo);
		}
		pw[i] = pInfo;
	}
	index[2] -= count;
/*
printf("_pop_array_vari:Exit i2=%d mode=%d count=%d\n",i2,mode,count);
*/
	return count;
}

/****************************************/
/*	210061301							*/
/****************************************/
static int _pop_array_fixed(close_gap,nm,ngap,pIndex,iRANGE)
char *close_gap;
int nm,ngap,iRANGE;
tdtArrayIndex *pIndex;
{
	tdtInfoParm *pInfo;
	int i,i2,mode,count,*index,size,atr;
	char c,*p,*pw,*pw2,*pw1;
/*
printf("_pop_array_fixed:Enter nm=%d ngap=%d iRANGE=%08x\n",nm,ngap,iRANGE);
*/
	if (nm<=0 || ngap<=0) return 0;

	atr = pIndex->uAttr[0];
	size = pIndex->size;
	if (atr == DEF_ZOK_CHAR) size++;
	else if (atr == DEF_ZOK_BULK) size += sizeof(int);
	if (iRANGE) size += size;
/*
printf("_pop_array_fixed: size=%d\n",size);
*/
	index = pIndex->index;
	pw = (char *)pIndex->pVarIndex;
	pw += index[3]*size;
	i2 = nm;
	count = mode = 0;
	p = close_gap;
	pw1 = pw;
	for (i=0;i<nm;i++) {
		c = *p++;
		if (mode) {
			if (!c) {
				memcpy(pw2,pw1,size);
				i2++;
				pw2 += size;
/*
printf("_pop_array_fixed: i=%d i2=%d\n",i,i2);
*/
			}
			else {
				count++;
			}
		}
		else {
			if (c) {
				mode = 1;
				i2 = i;
				pw2 = pw + (i2*size);
				count = 1;
			}
		}
		pw1 += size;
	}
/*
printf("_pop_array_fixed: i2=%d count=%d\n",i2,count);
*/
	pw2 = pw + (i2*size);
	for (i=i2;i<nm;i++) {
		memset(pw2,0,size);
		pw2 += size;
	}
	index[2] -= count;
/*
printf("_pop_array_fixed:Exit i2=%d mode=%d count=%d\n",i2,mode,count);
*/
	return count;
}

/****************************************/
/*	210061401							*/
/****************************************/
static int _get_array_index_iVala(pInfoParm,nparm,ppParm,ppIndex,ppIndexW,ppTBL,ppSize,iVala)
tdtInfoParm *pInfoParm,*ppParm[],****ppTBL;
tdtArrayIndex **ppIndex,**ppIndexW;
int nparm,**ppSize,iVala[];
{
	tdtInfoParm *pInfo,tInfoParm,***pTBL;
	tdtArrayIndex *pIndex,*pIndexW,tIndex_sel;
	char *varnam,cn,id;
	int rc,nm,*index,iParm[4];
	int i1,iFREE,offset,np,nmw,*index_sel,*indexW,*pSize;
/*
printf("_get_array_index_iVala:Enter nparm=%d\n",nparm);
*/
	if ((rc=cl_array_check_valid(pInfoParm,1)) < 0) return rc;
	pIndex = *ppIndex;
	if (!(varnam = (char *)pInfoParm->pi_pos)) varnam = "";
	if (rc = _get_array_info_ref(1,&pInfoParm,&pIndex,&pTBL,iParm,1)) {
		if (rc == 2000) {
					/* "%s: �A�z�z��(%s)�͎w��ł��܂���B*/
			ERROROUT2(FORMAT(239),"cl_func_pop",varnam);
			rc = ECL_SCRIPT_ERROR;
		}
		return rc;
	}
/*
printf("_get_array_index_iVala: pIndex=%08x pTBL=%08x\n",pIndex,pTBL);
*/
	nm  = iParm[3];
	index = pIndex->index;
	offset = index[3] + 1;
/*
printf("_get_array_index_iVala: nm=%d index=%d %d %d %d %d %d\n",nm,index[0],index[1],index[2],index[3],index[4],index[5]);
*/
	memcpy(&tIndex_sel,pIndex,sizeof(tdtArrayIndex));
	index_sel = tIndex_sel.index;
	if (nparm>0 && ppParm) {
		if ((rc=cl_gx_array_conv_sel_index(nparm,ppParm,index_sel,NULL)) < 0) return rc;
/*
printf("_get_array_index_iVala: index_sel[4]=%d %d %d %d\n",index_sel[4],index_sel[5],index_sel[6]);
*/
		/* 2025.9.29 */
		index_sel[3] = pIndex->uaux2;
		if ((i1=cl_gx_conv_index2(index,index_sel,varnam)) < 0) return i1;
/*
printf("_get_array_index_iVala: i1=%d\n",i1);
*/
		i1 -= index[3] + 1;		/* i1�͐e��ParmNo�Ȃ̂Ŏq�̃C���f�b�N�X�Ɋ��Z */
	}
	else i1 = 0;
	/* 2025.9.12 */
	nmw = 0;
	id = pInfoParm->pi_id;
	if (id=='R' || id=='A') {
		if ((rc=cl_get_array_index_opt(pInfoParm,&pIndexW,1)) > 0) {
			indexW = pIndexW->index;
			nmw = indexW[2] + indexW[3];
/*
printf("_get_array_index_iVala: nmw=%d indexW=%d %d %d %d\n",nmw,indexW[0],indexW[1],indexW[2],indexW[3]);
*/
		}
		else if (rc < 0) return rc;
	}
	if (id != 'R') {
		if (id != 'A') pIndexW = pIndex;
		if ((rc=cl_get_array_psize(pInfoParm,&cn,&pSize,NULL)) < 0) return rc;
/*
printf("_get_array_index_iVala: pSize[2]=%d pSize[7]=%d\n",pSize[2],pSize[7]);
*/
		indexW = pIndexW->index;
		nmw = indexW[2] + indexW[3];
	}
	*ppIndex = pIndex;
	*ppIndexW = pIndexW;
	*ppTBL = pTBL;
	*ppSize = pSize;
/*
printf("_get_array_index_iVala: pIndex=%08x pIndexW=%08x pTBL=%08x\n",pIndex,pIndexW,pTBL);
*/
	iVala[0] = i1;
	iVala[1] = nm;
	iVala[2] = nmw;
	iVala[3] = offset;
/*
printf("_get_array_index_iVala:Exit i1=%d nm=%d nmw=%d offset=%d\n",i1,nm,nmw,offset);
*/
	return 0;
}

/****************************************/
/*	210061501							*/
/****************************************/
int cl_func_pop(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	char *pnama[]={"NUM","INTVAL"};
	tdtRbCtl *pCt;
	tdtInfoParm *pInfoParm,*pInfo,tInfoParm,*ppParm2[2],***pTBL,**pw,*pwi;
	tdtInfoParm *pInfoTemp,*pParmW[2],tInfoParm1;
	tdtArrayIndex tIndex,*pIndex,*pIndexW,*pIndexTmp,tIndex_sel,tIndexW;
	char id,*p1,idm,id0,*close_gap,*varnam,cn;
	int rc,optW,nm,*index,i,k,m,val[3],num,intval,skip,iParm[4],w,val2[2],lVal,iVala[4];
	int i1,i2,atr,iRANGE,count,iFREE,offset,np,nmw,*index_sel,*indexW,*pSize,iCONST,sel;

	cl_null_parm(pInfoParmW);
	pInfoParm = ppParm[0];
	id0 = id = pInfoParm->pi_id;
	if (id == ' ') atr = pInfoParm->pi_attr;
	else atr = 0;
	/* 2025.10.13 */
	sel = 0x02 | 0x08 | 0x1000;	/* �z��A���X�g�A�f�[�^���� */
	if (atr == DEF_ZOK_BINA) sel |= 0x2000;
	if ((rc=cl_check_data_id2(pInfoParm,sel,0x03)) < 0) return rc;
	pInfoParm = ppParm[0];
	pParmW[1] = pParmW[0] = NULL;
	if ((rc=cl_get_pname_info(nparm,ppParm,pParmW,pnama,2)) < 0) return rc;
	else if (rc > 0) {
		nparm -= rc;	/* ���O�t�������́A�����Ɉړ����Ă���̂ŁA���̕������� */
		for (i=0;i<2;i++) {
			if (pInfo=pParmW[i]) {
				if (rc=cl_get_parm_bin(pInfo,&val2[i],"cl_func_pop:val2:")) return -217032301;
			}
		}
	}
	rc = 0;
	/* 2025.10.10 */
	if (atr == DEF_ZOK_BINA) iCONST = 0;
	else iCONST = pInfoParm->pi_aux[1] & D_AUX1_PROTECTED;
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		nm = pCt->rb_used;
		if (nm <= 0) return 0;
		if ((np=nparm) > 4) np = 4;
		val[0] = nm - 1;
		val[1] = 1;
		val[2] = 1;
		for (i=1;i<np;i++) {
			if ((rc=cl_get_parm_bin(ppParm[i],&val[i-1],"cl_func_pop val:"))<0) return rc;
		}
		m = val[0];
		if (pParmW[0]) num = val2[0];
		else num = val[1];
		if (num <= 0) return 0;
		if (pParmW[1]) intval = val2[1];
		else intval = val[2];
		if (intval <= 0) intval = 1;
		i1 = m;
		if (m < 0) {
			m += nm;
			num = 1;
			intval = 1;
		}
		skip = intval - 1;
/*
printf("cl_func_pop: m=%d num=%d intval=%d\n",m,num,intval);
*/
		if (m<0 || m>=nm) {
			ERROROUT1(FORMAT(228),i1);	/* �Q�ƈʒu(%d)���s���ł��B */
			return ECL_SCRIPT_ERROR;
		}
/*
printf("cl_func_pop:LIST nm=%d m=%d num=%d intval=%d\n",nm,m,num,intval);
*/
		if (m < nm) {
			akxs_rb_read(pCt,0);
			for (i=0;i<=m;i++) if (!(pInfo=(tdtInfoParm *)akxs_rb_read(pCt,1))) break;
/*
printf("cl_func_pop: i=%d\n",i);
*/
			if (!m || pInfo) {
				for (k=0;k<num;k++) {
					if (!iCONST) pInfo = (tdtInfoParm *)akxs_rb_pop(pCt);
					if (pInfo) {
						if (!k) {
							if ((id=pInfo->pi_id)==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
								if ((rc=_tmp_list_copy(pInfoParmW,pInfo)) < 0) break;
								pInfoParmW->pi_id = id0;
							}
							else
								cl_gx_copy_info(pInfoParmW,pInfo);
						}
						else {
							if ((id=pInfoParmW->pi_id)==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
								if ((rc=_append_list(pInfoParmW,1,&pInfo,1)) < 0) break;
							}
							else {
								cl_gx_copy_info(&tInfoParm,pInfoParmW);
								ppParm2[0] = &tInfoParm;
								if ((rc=cl_set_list(pInfoParmW,1,ppParm2)) < 0) break;
								pInfoParmW->pi_id = id0;
								if ((rc=_append_list(pInfoParmW,1,&pInfo,1)) < 0) break;
							}
						}
					/*	pInfoParmW->pi_aux[1] |= D_AUX1_PROTECTED;	*/
DEBUGOUT_InfoParm(194,"cl_func_pop: pInfo=",pInfo,0,0);
DEBUGOUT_InfoParm(194,"cl_func_pop: pInfoParmW=",pInfoParmW,0,0);
					}
					else break;

					m += intval;
/*
printf("cl_func_pop: m=%d\n",m);
*/
					if (m >= nm) break;

					for (i=0;i<skip;i++) {
						if (!(pInfo=(tdtInfoParm *)akxs_rb_read(pCt,1))) break;
					}
					rc = 0;
				}
			}
		}
	}
	else if (id=='A' || id=='R' || atr==DEF_ZOK_BINA) {
		if (pParmW[0]) num = val2[0];
		else num = 1;
		if (num <= 0) return 0;
		if (pParmW[1]) intval = val2[1];
		else intval = 1;
		/* 2025.10.10 */
		pIndex = &tIndex;
		pIndexW = &tIndexW;
		if ((rc=_get_array_index_iVala(pInfoParm,nparm-1,ppParm+1,&pIndex,&pIndexW,&pTBL,&pSize,iVala)) < 0) return rc;
		i1  = iVala[0];
		nm  = iVala[1];
		nmw = iVala[2];
		offset = iVala[3];
		index = pIndex->index;
		iFREE = pInfoParm->pi_scale & D_DATA_INDEX_FREE;
/*
printf("cl_func_pop: offset=%d iFREE=%02x\n",offset,iFREE);
*/
		i2 = i1 + num - 1;
		if (i2 >= nm) {
			i2 = nm - 1;
			num = i2 - i1 + 1;
		}
/*
printf("cl_func_pop: i1=%d i2=%d num=%d intval=%d\n",i1,i2,num,intval);
*/
		if (num <= 0) {
			ERROROUT3(FORMAT(320),"cl_func_pop",varnam,i1);	/* %s: %s�̃C���f�b�N�X(%d)�͔͈͊O�ł��B*/
			return 0;
		}
		if ((rc=cl_def_array_tmp(&pInfoTemp,num,NULL)) < 0) return rc;
		cl_gx_copy_info(pInfoParmW,pInfoTemp);
		pIndexTmp = (tdtArrayIndex *)pInfoTemp->pi_data;
		pw = pIndexTmp->pVarIndex;
		if (nm > nmw) nmw = nm;
		if (!(close_gap = TEMPMalloc(nmw))) return ECL_MALLOC_ERROR;
		memset(close_gap,0,nmw);
		k = 0;
		for (i=i1;i<nm;i+=intval) {
			if (!(pInfo = cl_get_array_and_var_ent_opt(pIndex,pTBL,i+offset,'r'))) return -1;
			if (!(pwi=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
			if ((rc=cl_gx_rep_info_set_ign(pwi,pInfo,1)) < 0) return rc;
			*(close_gap+i+offset-1) = 1;
			pw[k++] = pwi;
			if (k >= num) break;
		}
/*
printf("cl_func_pop: k=%d\n",k);
*/
		if (!iCONST) {
			if (pTBL) {
				if ((rc=_pop_array_pTBL(close_gap,nmw,k,pIndexW,pTBL,iFREE)) < 0) return rc;
			/*	indexW[2] -= k;	*/
				/* indexW[]�́A�e�̂��̂����A�����ύX���Ă����f����Ȃ��B */
				/* �e�́ApSize[]��ύX����K�v������B */
				pSize[2] -= k;
				pSize[7] -= k;
				pInfo = cl_var_size_parm(pSize);
				cl_set_parm_bin(pInfo,pSize[7]);
				index[2] -= k;
/*
printf("cl_func_pop: k=%d index[2]=%d pSize[2]=%d pSize[7]=%d\n",k,index[2],pSize[2],pSize[7]);
*/
			}
			else {
				atr = pIndex->uAttr[0];
/*
printf("cl_func_pop: atr=%d nm=%d\n",atr);
*/
				if (!atr || atr==DEF_ZOK_VARI) {
					rc = _pop_array_vari(close_gap,nmw,k,pIndexW,iFREE);
				}
				else {
					iRANGE = pInfoParm->pi_alen & D_AULN_RANGE_DATA;
					rc = _pop_array_fixed(close_gap,nmw,k,pIndexW,iRANGE);
				}
/*
printf("cl_func_pop: pIndex=%08x pIndexW=%08x\n",pIndex,pIndexW);
*/
				if (rc>=0 && pIndex!=pIndexW) index[2] -= k;
			}
		}
	}
	if (rc > 0) rc = 0;
	return rc;
}

/****************************************/
/*	210062101							*/
/****************************************/
static int _set_random(p,pw,nm)
tdtInfoParm *p,**pw;
int nm;
{
	int ix,rc,m;
/*
printf("_set_random:Enter nm=%d\n",nm);
*/
	rc = 0;
	ix = drand48()*nm;
/*
printf("_set_random:1 ix=%d pw[ix]=%08x\n",ix,pw[ix]);
*/
	m = nm;
	while (pw[ix]) {
		if (!m--) break;
		ix++;
		if (ix >= nm) ix = 0;
/*
printf("_set_random: m=%d ix=%d\n",m,ix);
*/
	}
/*
printf("_set_random:2 ix=%d pw[ix]=%08x\n",ix,pw[ix]);
*/
	rc = ix;
	if (!pw[ix]) pw[ix] = p;
	else rc = -100;
	return rc;
}

/****************************************/
/*	210062201							*/
/****************************************/
static int _random_list(pInfoParm,im)
tdtInfoParm *pInfoParm;
int im;
{
	tdtRbCtl *pCt,*pCt2;
	int rc,nm,len,i;
	tdtInfoParm *p,**pw,*pww;
	char *p1,*(*m_alloc)();

	rc = 0;
	pCt = (tdtRbCtl *)pInfoParm->pi_data;
	if ((nm=pCt->rb_used) > 0) {
/*
printf("cl_func_random: nm=%d\n",nm);
*/
		len = sizeof(tdtInfoParm *)*nm;
		if (!(pw = (tdtInfoParm **)cl_tmp_const_malloc(len))) return ECL_MALLOC_ERROR;
		memset(pw,0,len);
		akxs_rb_read(pCt,0);
		for (i=0;i<nm;i++) {
			p=(tdtInfoParm *)akxs_rb_read(pCt,1);
			if ((rc=_set_random(p,pw,nm)) < 0) break;
		}
		if (rc >= 0) {
			if (im == D_OPT_ALC_MALLOC) m_alloc = NULL;
			else m_alloc = cl_tmp_const_malloc;
			if (!(pCt2 = akxs_rb_new2(0,0,m_alloc,NULL))) return ECL_MALLOC_ERROR;
/*
printf("cl_func_random: pCt2=%08x\n",pCt2);
*/
			for (i=0;i<nm;i++) {
/*
printf("cl_func_random: i=%d pw[i]=%08x\n",i,pw[i]);
*/
				p1 = akxs_rb_set_n(pCt2,pw[i]);
			}
			akxs_rb_free(pCt);
			pInfoParm->pi_data = (char *)pCt2;
		/*	*pInfoParmW = *pInfoParm;	*/
		/*	cl_gx_copy_info(pInfoParmW,pInfoParm);	*/
			rc = 0;
		}
		else {
			akxs_rb_free(pCt2);
		}
	}
	return rc;
}

/****************************************/
/*	210062301							*/
/****************************************/
static int _random_array_pTBL(nm,pIndex,pTBL)
int nm;
tdtArrayIndex *pIndex;
tdtInfoParm ***pTBL;
{
	int rc,len,i,offset;
	tdtInfoParm *p,**pw,*pww;

	rc = 0;
	offset = pIndex->index[3] + 1;
	len = sizeof(tdtInfoParm *)*nm;
	if (!(pw = (tdtInfoParm **)cl_tmp_const_malloc(len))) return ECL_MALLOC_ERROR;
	memset(pw,0,len);
	if (!(pww = (tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm)*nm))) return ECL_MALLOC_ERROR;
	for (i=0;i<nm;i++) {
		p = pww + i;
		if ((rc=_set_random(p,pw,nm)) < 0) break;
		p = cl_get_array_and_var_ent_opt(pIndex,pTBL,i+offset,'r');
		memcpy(pw[rc],p,sizeof(tdtInfoParm));;
	}
/*
printf("cl_func_random:VARI rc=%d\n",rc);
*/
	if (rc >= 0) {
		rc = 0;
		for (i=0;i<nm;i++) {
			p = cl_get_array_and_var_ent_opt(pIndex,pTBL,i+offset,'r');
			cl_gx_copy_info(p,pw[i]);
		}
	}
	return rc;
}

/****************************************/
/*	210062401							*/
/****************************************/
static int _random_array_vari(nm,pIndex,im)
int nm,im;
tdtArrayIndex *pIndex;
{
	int rc,len,i,offset;
	tdtInfoParm *p,**pw,*pww,**ppArrayInfo,**pw0;

	rc = 0;
	offset = pIndex->index[3] + 1;
	len = sizeof(tdtInfoParm *)*(nm+offset-1);
	if (!(pw0 = (tdtInfoParm **)OPTMalloc(im,len))) return ECL_MALLOC_ERROR;
	pw = pw0 + offset - 1;
	memset(pw,0,len);
	ppArrayInfo = pIndex->pVarIndex;
	for (i=0;i<nm;i++) {
		p = ppArrayInfo[i];
		if ((rc=_set_random(p,pw,nm)) < 0) break;
	}
/*
printf("cl_func_random:VARI rc=%d\n",rc);
*/
	if (rc >= 0) {
		pIndex->pVarIndex = pw0;
		rc = 0;
		if (im == D_OPT_ALC_MALLOC) Free(ppArrayInfo);
	}
	else {
		if (im == D_OPT_ALC_MALLOC) Free(pw);
	}
	return rc;
}

/****************************************/
/*	210062501							*/
/****************************************/
static int _random_array_fixed(nm,pIndex,iRANGE)
int nm,iRANGE;
tdtArrayIndex *pIndex;
{
	int rc,len,i,size,atr;
	tdtInfoParm *p,**pw,*pww;
	char *p1,*pp,*pArray;

	rc = 0;
	atr = pIndex->uAttr[0];
	if (!(size = pIndex->size)) return -1;
	if (atr == DEF_ZOK_CHAR) size++;
	else if (atr == DEF_ZOK_BULK) size += sizeof(int);
	if (iRANGE) size+= size;
/*
printf("cl_func_random: iRANGE=%08x size=%d\n",iRANGE,size);
*/
	len = sizeof(tdtInfoParm *)*nm;
	if (!(pw = (tdtInfoParm **)cl_tmp_const_malloc(len))) return ECL_MALLOC_ERROR;
	memset(pw,0,len);
	if (!(pp = cl_tmp_const_malloc(size*nm))) return ECL_MALLOC_ERROR;
	pArray = (char *)pIndex->pVarIndex;
	memcpy(pp,pArray,size*nm);
	p1 = pp;
	for (i=0;i<nm;i++) {
		if ((rc=_set_random(p1,pw,nm)) < 0) break;
		p1 += size;
	}
/*
printf("cl_func_random: rc=%d\n",rc);
*/
	if (rc >= 0) {
		rc = 0;
		p1 = pArray;
		for (i=0;i<nm;i++) {
			memcpy(p1,pw[i],size);
			p1 += size;
		}
	}
	return rc;
}

/****************************************/
/*	210062601							*/
/****************************************/
int cl_func_random(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm ***pTBL;
	tdtArrayIndex tIndex,*pIndex;
	int iParm[4],w;
	tdtRbCtl *pCt,*pCt2;
	tdtInfoParm *pInfoParm,*p,**pw,**ppArrayInfo,*pww,*pwi;
	char id,*p1,*pp,*pArray;
	int rc,nm,ix,m,i,len,atr,ix0,size,iRANGE,im;
	char *(*m_alloc)();

	cl_null_parm(pInfoParmW);
	pInfoParm = ppParm[0];
/*
printf("cl_func_random:Enter pi_scale=%02x\n",pInfoParm->pi_scale);
*/
	if (pInfoParm->pi_scale & D_DATA_INDEX_FREE) im = D_OPT_ALC_MALLOC;
	else im = D_OPT_ALC_TMP;
	rc = 0;
	id = pInfoParm->pi_id;
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		pInfoParm = ppParm[0];
		rc = _random_list(pInfoParm,im);
	}
	else if (id=='A' || id=='R') {
		nm = 0;
		pIndex = &tIndex;
		pInfoParm = ppParm[0];
		if ((rc=cl_array_check_valid(pInfoParm,1)) < 0) return rc;
		if (rc = _get_array_info_ref(1,ppParm,&pIndex,&pTBL,iParm,1)) {
			if (rc == 2000) {
				if (!(p1 = (char *)pInfoParm->pi_pos)) p1 = "";
						/* "%s: �A�z�z��(%s)�͎w��ł��܂���B*/
				ERROROUT2(FORMAT(239),"cl_func_random",p1);
				rc = ECL_SCRIPT_ERROR;
			}
			return rc;
		}
		else {
			nm  = iParm[3];
/*
printf("cl_func_random: rc=%d pTBL=%08x nm=%d\n",pTBL,nm);
*/
			if (pTBL) {
				rc = _random_array_pTBL(nm,pIndex,pTBL);
			}
			else {
				atr = pIndex->uAttr[0];
/*
printf("cl_func_random: atr=%d nm=%d\n",atr);
*/
				if (!atr || atr==DEF_ZOK_VARI) {
					rc = _random_array_vari(nm,pIndex,im);
				}
				else {
					iRANGE = pInfoParm->pi_alen & D_AULN_RANGE_DATA;
					rc = _random_array_fixed(nm,pIndex,iRANGE);
				}
			}
		}
	}
	if (!rc) cl_gx_copy_info(pInfoParmW,pInfoParm);
	return rc;
}

/****************************************/
/*	210063101							*/
/****************************************/
int cl_func_unique_opt(pInfoParmW,nparm,ppParm,opt)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
int opt;
{
	/* 2025.8.28 */
	tdtInfoParm tInfoParm,*pInfoParm;
	tdtArrayIndex *pIndex;
	char id;
	int rc,iDO;

DEBUGOUTL1(120,"cl_func_unique_opt:Enter: opt=%08x",opt);

	iDO = 0;
	pInfoParm = ppParm[0];
	id = pInfoParm->pi_id;
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) iDO = 1;
	else if (id=='A' || id=='R') {
		if ((rc=cl_array_check_valid(pInfoParm,1)) < 0) return rc;
		if ((rc=cl_get_array_index(pInfoParm,&pIndex)) < 0) return rc;
		if (pIndex->xhp) {
			if (opt & 0x01)
				ERROROUT2(FORMAT(239),"cl_func_unique",pInfoParm->pi_pos);	/* %s: �A�z�z��(%s)�͎w��ł��܂���B*/
		}
		else iDO = 1;
	}
	if (iDO) {
		cl_null_parm(&tInfoParm);
		if ((rc=cl_cmpt_agg(pInfoParmW,"/",pInfoParm,&tInfoParm)) > 0) rc = 0;
	}
	else {
		/* ���̂Ƃ��́ApInfoParm�ɑ΂��鏈�����s���Ȃ��������ƁA����сA
		   pInfoParmW���ApInfoParm�̃R�s�[�ɂȂ��Ă��邱�Ƃ��������߂ɁA1��Ԃ� */
		if (opt & 0x02) {
			rc = cl_gx_rep_info_set_ign(pInfoParmW,pInfoParm,1|D_GX_OPT_ALC_TMP);
		}
		else {
			cl_gx_copy_info(pInfoParmW,pInfoParm);
		}
		rc = 1;
	}

DEBUGOUTL1(120,"cl_func_unique_opt:Exit: rc=%d",rc);

	return rc;
}

/****************************************/
/*	210063201							*/
/****************************************/
int cl_func_unique(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	int rc;

	if ((rc=cl_func_unique_opt(pInfoParmW,nparm,ppParm,0)) > 0) rc = 0;
	return rc;
}

/****************************************/
/*	210063601							*/
/****************************************/
int cl_adust_infoR(pInfoParm,pIndex)
tdtInfoParm *pInfoParm;
tdtArrayIndex *pIndex;
{
	tdtArrayIndex *pIndexW;
	int rc,*index,*indexW,offset,offsetW,m2W;

	if (!pInfoParm || !pIndex) return -1;

	if ((rc=cl_get_array_index_opt(pInfoParm,&pIndexW,1)) > 0) {
		indexW = pIndexW->index;
		offsetW = indexW[3];
		index = pIndex->index;
		offset = index[3];
		m2W = indexW[2] + offsetW;
		index[2] = m2W - offset;
		if (index[2] > index[1]) index[2] = index[1];
/*
printf("_adust_info: m2W=%d index[1]=%d index[2]=%d\n",m2W,index[1],index[2]);
*/
		rc = 1;
	}
	return rc;
}

/****************************************/
/*	210063701							*/
/****************************************/
static int _adust_info(pInfoParm,iKIND)
tdtInfoParm *pInfoParm;
int iKIND;
{
	tdtArrayIndex *pIndex,*pIndexW;
	int rc,*index,*indexW,offset,offsetW,m2W;
	char id;

	rc = 0;
	id = pInfoParm->pi_id;
/*
printf("_adust_info:Enter iKIND=%d id=[%c]\n",iKIND,id);
*/
	if (iKIND>=0 && id=='A') {
		rc = cl_get_array_index_tbl_ref(pInfoParm,NULL,NULL,"!cl_func_adjust");
		if (rc >= 0) rc = 1;
	}
	else if (iKIND<=0 && id=='R') {
		if ((rc=cl_get_array_index(pInfoParm,&pIndex)) >= 0) {
			rc = cl_adust_infoR(pInfoParm,pIndex);
		}
	}
	return rc;
}

/****************************************/
/*	210063801							*/
/****************************************/
int cl_adjust_scope(pha,iKIND)
XHASHB *pha;
int iKIND;
{
	tdtInfoParm *pInfoParm;
	int rc,m,i,ix,count,iMAX;
	char *hakey;

	rc = 0;
	/* 2025.12.31 */
	if (akxs_xhash(pha,'T',NULL) <= 0) return 0;
	iMAX = pha->xha_xhix;
	for (i=1;;i++) {
		i = akxs_xhash_next_i(iMAX,pha,i);
		if (i == AKX_HASH_NEXT_BREAK) break;
		pha->xha_xhix = i;
		if ((ix=akxs_xhash2(pha,'P',&hakey,&pInfoParm)) < 0) return ix;
		else if (ix > 0) {
/*
printf("cl_func_adjust_scope: hakey=[%s]\n",hakey);
*/
			if (*hakey != '$') {
				if ((rc=_adust_info(pInfoParm,iKIND)) < 0) break;
				if (rc > 0) count += rc;
			}
		}
	}
	if (rc >= 0) rc = count;
	return rc;
}

/****************************************/
/*	210063901							*/
/****************************************/
int cl_func_adjust(pAns,nparm,ppParm)
long *pAns;
int nparm;
tdtInfoParm *ppParm[];
{
	static char *scope[] = {"local","private","public","global","all"};
	tdtInfoParm *pInfoParm,tInfoParm;
	XHASHB *pha;
	ProcCT *proc;
	ScrPrCT *scrct;
	int rc,i,iKIND,ix,count;
	char id,*p,c;

	count = rc = 0;
	if (nparm > 0) {
		for (i=0;i<nparm;i++) {
			pInfoParm = ppParm[i];
			if (pInfoParm->pi_id == ' ') {
				if ((rc=parm_to_char_tmp(pInfoParm,&p,0)) < 0) break;
				iKIND = 0;
				if ((ix=instrchar(p,'.')) > 0) {
					c = toupper(*(p + ix));
					if (c == 'A') iKIND = 1;
					else if (c == 'R') iKIND = -1;
					else continue;
					*(p+ix-1) = '\0';
/*
printf("cl_func_adjust: iKIND=%d p=[%s]\n",iKIND,p);
*/
				}
				else if (ix < 0) break;
				if ((rc=akxs_seqr_str(scope,5,p,1)) < 0) break;
/*
printf("cl_func_adjust: rc=%d\n",rc);
*/
				if (rc == 1) {		/* local */
					if (!(proc = cl_search_proc_ct())) {
						rc = -1;
						break;
					}
					pha = proc->pha_vnam;
				}
				else if (rc == 2) {	/* private */
					if (!(scrct = cl_search_src_ct())) {
						rc = -1;
						break;
					}
					pha = scrct->Vary->pha_vnam;
				}
				else if (rc == 3) {	/* public */
					pha = pCLprocTable->pha_vnam;
				}
				else if (rc == 4) {	/* global */
					pha = pGLprocTable->pha_vnam;
				}
				else if (rc == 5) { /* all */
					pha = NULL;
					if (!(proc = cl_search_proc_ct())) {
						rc = -1;
						break;
					}
					if ((rc=cl_adjust_scope(proc->pha_vnam,iKIND)) < 0) break;
					if (rc > 0) count += rc;
					if (!(scrct = cl_search_src_ct())) {
						rc = -1;
						break;
					}
					if ((rc=cl_adjust_scope(scrct->Vary->pha_vnam,iKIND)) < 0) break;
					if (rc > 0) count += rc;
					if ((rc=cl_adjust_scope(pCLprocTable->pha_vnam,iKIND)) < 0) break;
					if (rc > 0) count += rc;
					if ((rc=cl_adjust_scope(pGLprocTable->pha_vnam,iKIND)) < 0) break;
					if (rc > 0) count += rc;
					if (!iKIND) break;
				}
				else pha = NULL;
				if (pha) {
					rc = cl_adjust_scope(pha,iKIND);
					if (rc > 0) count += rc;
				}
			}
			else {
				if (cl_check_data_id2(pInfoParm,0x02,0x03) >= 0) {
					rc = _adust_info(pInfoParm,0);
					if (rc > 0) count += rc;
				}
			}
		}
	}
	else {
		pInfoParm = &tInfoParm;
		cl_set_parm_char(pInfoParm,"all",3);
		rc = cl_func_adjust(pAns,1,&pInfoParm);
		if (rc > 0) count = rc;
	}
	*pAns = count;
	return rc;
}

/****************************************/
/*	210064101							*/
/****************************************/
static int _insert_array_pTBL(pInfoParm,pos,nmw,pIndexW,pTBL)
tdtInfoParm *pInfoParm;
int pos,nmw;
tdtArrayIndex *pIndexW;
tdtInfoParm ***pTBL;
{
	tdtInfoParm *pInfo1,*pInfo2;
	int i;

	for (i=nmw;i>pos;i--) {
		if (!(pInfo1 = cl_get_array_and_var_ent_opt(pIndexW,pTBL,i,'r'))) return -1;
		if (!(pInfo2 = cl_get_array_and_var_ent_opt(pIndexW,pTBL,i+1,'r'))) return -1;
		cl_gx_copy_info(pInfo2,pInfo1);
	}
	cl_gx_rep_info_set_ign(pInfo1,pInfoParm,1);
	return 0;
}

/****************************************/
/*	210064201							*/
/****************************************/
static int _insert_array_vari(pInfoParm,pos,nmw,pIndexW)
tdtInfoParm *pInfoParm;
int pos,nmw;
tdtArrayIndex *pIndexW;
{
	tdtInfoParm *pInfo,**pw;
	int i;

	pw = pIndexW->pVarIndex;
	for (i=nmw;i>pos;i--) {
		pw[i] = pw[i-1];
	}
	if (!(pInfo = (tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
	cl_gx_rep_info_set_ign(pInfo,pInfoParm,1);
	pw[pos] = pInfo;
	pIndexW->index[2]++;
	return 0;
}

/****************************************/
/*	210064301							*/
/****************************************/
static int _insert_array_fixed(pInfoParm,pos,nmw,pIndexW,iRANGE)
tdtInfoParm *pInfoParm;
int pos,nmw,iRANGE;
tdtArrayIndex *pIndexW;
{
	tdtInfoParm *pInfo,tInfo;
	int i,i2,mode,count,*index,size,atr,iParm[4],rc;
	char *pw,*pw1;
/*
printf("_insert_array_fixed:Enter nm=%d ngap=%d iRANGE=%08x\n",nm,ngap,iRANGE);
*/
	atr = pIndexW->uAttr[0];
	size = pIndexW->size;
	if (atr == DEF_ZOK_CHAR) size++;
	else if (atr == DEF_ZOK_BULK) size += sizeof(int);
	if (iRANGE) size += size;
/*
printf("_insert_array_fixed: size=%d iRANGE=%08x\n",size,iRANGE);
*/
	index = pIndexW->index;
	pw = (char *)pIndexW->pVarIndex;
	pw += size*nmw;
	for (i=nmw;i>pos;i--) {
		pw1 = pw - size;
		memcpy(pw,pw1,size);
		pw -= size;
	}
/*
printf("_insert_array_fixed: atr=%d pi_attr=%d\n",atr,pInfoParm->pi_attr);
*/
	if (atr != pInfoParm->pi_attr) {
		iParm[0] = atr;
		iParm[1] = pIndexW->size;
		iParm[2] = pIndexW->uAttr[2];
		iParm[3] = pIndexW->uAttr[3];
		pInfo = &tInfo;
		if ((rc=cl_set_parm_init(pInfo,iParm,iRANGE)) < 0) return rc;
		if ((rc=cl_gx_rep_info_set(pInfo,pInfoParm,1|D_GX_OPT_ALC_TMP)) < 0) return rc;
		pInfoParm = pInfo;
	}
	memcpy(pw1,pInfoParm->pi_data,size);
	index[2]++;
	return 0;
}

/****************************************/
/*	210064401							*/
/****************************************/
int cl_func_insert(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int nparm;
tdtInfoParm *ppParm[];
{
	char *pnama[]={"OPT"};
	tdtArrayIndex *pIndex,*pIndexW,tIndex,tIndexW;
	tdtInfoParm *pInfoParm,*pInfo,tInfoParm,***pTBL,*pParmW[2],tInfoParm1,tInfoParm2,tInfoParm3;
	tdtRbCtl *pCt;
	int pos,nm,rc,atr,i1,nmw,offset,*pSize,*index,iVala[4],opt,iRANGE,sel,etc_parm[2];
	long lVal;
	char id,*nam;
	uchar aux0;
	qOpeTable pot;
/*
printf("cl_func_insert:Enter nparm=%d\n",nparm);
*/
	cl_null_parm(pInfoParmW);
	pInfoParm = ppParm[0];
	id = pInfoParm->pi_id;
	if (id == ' ') atr = pInfoParm->pi_attr;
	else atr = 0;
	/* 2025.10.13 */
	sel = 0x02 | 0x08 | 0x1000;	/* �z��A���X�g�A�f�[�^���� */
	if (atr == DEF_ZOK_BINA) sel |= 0x2000;
	if ((rc=cl_check_data_id2(pInfoParm,sel,0x03)) < 0) return rc;
	id = pInfoParm->pi_id;
	opt = 0;
	pParmW[0] = NULL;
	if ((rc=cl_get_pname_info(nparm,ppParm,pParmW,pnama,1)) > 0) {
		nparm -= rc;	/* ���O�t�������́A�����Ɉړ����Ă���̂ŁA���̕������� */
		if ((rc=cl_get_parm_long(pParmW[0],&lVal,"opt:")) < 0) return rc;
		opt = lVal;
		rc = 0;
	}
	else if (rc) return rc;
	if (atr!=DEF_ZOK_BINA && (pInfoParm->pi_aux[1] & D_AUX1_PROTECTED)) {
		aux0 = pInfoParm->pi_aux[0];
		if (id=='A' || id=='R') pInfoParm->pi_aux[0] |= DEF_ZOK_DATA;
		if ((rc=cl_gx_rep_info_set_ign(&tInfoParm,pInfoParm,1)) < 0) return rc;
		pInfoParm->pi_aux[0] = aux0;
		pInfoParm = &tInfoParm;
	}
	pos = 0;
	if (nparm >= 3) {
		if ((rc=cl_get_parm_bin(ppParm[2],&pos,"cl_func_insert pos:")) < 0) return rc;
	}
	rc = 0;
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		nm = pCt->rb_used;
		if (nparm <= 2) pos = nm;
		else if (pos < 0) pos += nm + 1;
/*
printf("cl_func_insert: nm=%d pos=%d\n",nm,pos);
*/
		if (!(pInfo=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
		if ((rc=cl_gx_rep_info_set_ign(pInfo,ppParm[1],1)) < 0) return rc;
		rc = akxs_rb_insert(pCt,pInfo,pos);
	}
	else if (id=='A' || id=='R' || atr==DEF_ZOK_BINA) {
		pIndex = &tIndex;
		pIndexW = &tIndexW;
		if ((rc=_get_array_index_iVala(pInfoParm,nparm-2,ppParm+2,&pIndex,&pIndexW,&pTBL,&pSize,iVala)) < 0) return rc;
		i1  = iVala[0];
		nm  = iVala[1];
		nmw = iVala[2];
		offset = iVala[3];
		index = pIndex->index;
		if (nmw < nm) nmw = nm;
		if (nmw >= pIndexW->index[1]) {
			if (id=='A' || (opt & 0x01)) {
				nam = (char *)pInfoParm->pi_pos;
				ERROROUT3(FORMAT(323),"cl_func_insert",nam,"");	/* %s: %s��%s�G���g���p�̋󂫂�����܂���B*/
				return ECL_SCRIPT_ERROR;
			}
			if ((rc=_append_redefine(pIndex,1,pIndexW)) < 0) return rc;
		}
		if (nparm <= 2) pos = nm;
		else pos = i1;
		pos = pos + offset -1;
		/* pos�́A�e�̗v�f�ʒu(�擪��0)�������B���̑O�ɑ}������ */
/*
printf("cl_func_insert: nm=%d pos=%d\n",nm,pos);
*/
		if (pos >= nmw) {	/* �e�̐ݒ�ςݍő�ʒu���z���Ă�����ǉ����� */
			cl_append_sub(&lVal,2,ppParm,0x01);
		}
		else {
			if (pTBL) {
				if ((rc=_insert_array_pTBL(ppParm[1],pos,nmw,pIndexW,pTBL)) < 0) return rc;
			/*	indexW[2] -= k;	*/
				/* indexW[]�́A�e�̂��̂����A�����ύX���Ă����f����Ȃ��B */
				/* �e�́ApSize[]��ύX����K�v������B */
				pSize[2]++;
				pSize[7]++;
				pInfo = cl_var_size_parm(pSize);
				cl_set_parm_bin(pInfo,pSize[7]);
				index[2]++;
/*
printf("cl_func_insert: k=%d index[2]=%d pSize[2]=%d pSize[7]=%d\n",k,index[2],pSize[2],pSize[7]);
*/
			}
			else {
				atr = pIndex->uAttr[0];
/*
printf("cl_func_pop: atr=%d nm=%d\n",atr);
*/
				if (!atr || atr==DEF_ZOK_VARI)
					rc = _insert_array_vari(ppParm[1],pos,nmw,pIndexW);
				else {
					iRANGE = pInfoParm->pi_alen & D_AULN_RANGE_DATA;
					rc = _insert_array_fixed(ppParm[1],pos,nmw,pIndexW,iRANGE);
				}
/*
printf("cl_func_insert: pIndex=%08x pIndexW=%08x\n",pIndex,pIndexW);
*/
				if (rc>=0 && pIndex!=pIndexW) {
					index[2]++;
					if (index[1] < index[2]) index[1] = index[2];
				}
			}
		}
	}
	cl_gx_copy_info(pInfoParmW,pInfoParm);
	return rc;
}

/****************************************/
/*	210065101							*/
/****************************************/
static int _mcat_var_list(pha,name,mcat,flgs)
XHASHB *pha;
char *name;
MCAT *mcat;
int flgs[];
{
	tdtInfoParm *pInfoParm;
	int rc,m,i,ix,n,iMAX;
	char *hakey,buf[3];

	rc = 0;
	/* 2025.12.30 */
	if ((rc=akxs_xhash(pha,'T',NULL)) <= 0) return 0;
	iMAX = pha->xha_xhix;
/*
printf("_mcat_var_list: iMAX=%d\n",iMAX);
*/
	for (i=1;;i++) {
		if ((i=akxs_xhash_next_i(iMAX,pha,i)) == AKX_HASH_NEXT_BREAK) break;
		pha->xha_xhix = i;
		if ((ix=akxs_xhash2(pha,'P',&hakey,&pInfoParm)) < 0) return ix;
		else if (ix > 0) {
/*
printf("_mcat_var_list: hakey=[%s]\n",hakey);
*/
			if (*name == '%') rc = 0;
			else if ((rc=akxs_str_like(hakey,name)) < 0) break;
			if (!rc) {
				akxtmcats(mcat,hakey);
				akxtmcats(mcat," ");
				if ((rc=cl_print_info(mcat,pInfoParm,flgs)) < 0) break;
				rc = 0;
				if ((n=akxa_log_new_line_str(buf,cl_get_option(3,0))) > 0) {
					akxtmcat(mcat,buf,n);
				}
			}
		}
	}
	return rc;
}

/****************************************/
/*	210065201							*/
/****************************************/
int cl_func_var_list(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW,*ppParm[];
int nparm;
{
	static MCAT tmcat={'M','C',256,0,0,0,NULL,0};
	static char *scope[] = {"local","private","public","global","all"};
	MCAT *mcat;
	tdtInfoParm *pInfoParm,tInfoParm;
	XHASHB *pha;
	ProcCT *proc;
	ScrPrCT *scrct;
	int rc,flgs[MAX_PRINT_FLGS],lpat,k,i;
	char *p,*name,*pat;

	rc = 0;
	if (nparm >= 2) {
		if ((rc=parm_to_char_tmp(ppParm[1],&name,0)) < 0) return rc;
	}
	else name = "%";
/*
printf("cl_func_var_list: name=[%s]\n",name);
*/
	mcat = &tmcat;
	mcat->mc_ipos = 0;
	mem_set_int(flgs,0,MAX_PRINT_FLGS);
	if (nparm > 0) {
		if ((lpat=parm_to_char_tmp(ppParm[0],&pat,0)) < 0) return lpat;
		else if (!lpat) nparm = 0;
	}
/*
printf("cl_func_var_list: lpat=%d pat=[%s]\n",lpat,pat);
*/
	if (nparm > 0) {
		if ((k=akxs_seqr_str(scope,5,pat,1)) < 0) return k;
/*
printf("cl_func_var_list: k=%d\n",k);
*/
		if (k) lpat = 1;
		p = pat;
		for (i=0;i<lpat;i++,p++) {
			if (!k) {
				rc = instrichar("LSPGA",*p);
/*
printf("cl_func_var_list: instrichar rc=%d\n",rc);
*/
			}
			else rc = k;
			if (rc > 0) {
				pha = NULL;
				if (rc == 1) {		/* local */
					if (proc = cl_search_proc_ct()) pha = proc->pha_vnam;
					else rc = -1;
				}
				else if (rc == 2) {	/* private */
					if (scrct = cl_search_src_ct()) pha = scrct->Vary->pha_vnam;
					else rc = -1;
				}
				else if (rc == 3) {	/* public */
					pha = pCLprocTable->pha_vnam;
				}
				else if (rc == 4) {	/* global */
					pha = pGLprocTable->pha_vnam;
				}
				else if (rc == 5) {	/* all */
					nparm = 0;
					break;
				}
				if (pha) rc = _mcat_var_list(pha,name,mcat,flgs);
			}
		}
	}
	if (!nparm) {
		if (proc = cl_search_proc_ct()) {
			if ((rc=_mcat_var_list(proc->pha_vnam,name,mcat,flgs)) < 0) return rc;
		}
		if (scrct = cl_search_src_ct()) {
			if ((rc=_mcat_var_list(scrct->Vary->pha_vnam,name,mcat,flgs)) < 0) return rc;
		}
		if ((rc=_mcat_var_list(pCLprocTable->pha_vnam,name,mcat,flgs)) < 0) return rc;
		if ((rc=_mcat_var_list(pGLprocTable->pha_vnam,name,mcat,flgs)) < 0) return rc;
	}
	cl_set_parm_char(pInfoParmW,mcat->mc_bufp,mcat->mc_ipos);
	return rc;
}

/****************************************/
/*	210065601							*/
/*	opt : = 0 : in						*/
/*		  = 1 : as						*/
/****************************************/
/* 2026.8.16 */
static int _func_act(pInfoParmW,nparm,ppParm,opt)
tdtInfoParm *pInfoParmW;
int nparm;
tdtInfoParm *ppParm[];
int opt;
{
	static char *_fn_="_func_actin";
	char *pnama[]={"NUM"};
	tdtArrayIndex *pIndex,tIndex,*pIndexW;
	tdtInfoParm *pInfoParm,*pInfo,*pInfo2,***pTBL,tInfoParm,*pInfoW,*pInfoWW,*ppParmW[2];
	tdtInfoParm *pInfoF,**ppParmF,tInfoW;
	tdtRbCtl *pCt,*pCt2;
	XHASHB *xha,*xhaW;
	tdtIterate_ctl tIter_ctl;
	tdtIterate *pIter,tIter2;
	int i,ii,num,nm,rc,atr,*index,count,sel,len,ex_opt,ary_opt,iAns,nparmF,max_layer,etc_parm[10];
	int iCONST,iMAX,iUSE_HASH_KEY;
	char id,*pOperator,id2,ope,wrk[15],*cpKey,*cpDat;
/*
printf("%s:Enter nparm=%d\n",_fn_,nparm);
*/
	cl_null_parm(pInfoParmW);

	/* NUM==>num */
	ppParmW[0] = NULL;
	if ((rc=cl_get_pname_info(nparm,ppParm,ppParmW,pnama,1)) > 0) {
		if ((rc=cl_get_parm_bin(ppParmW[0],&num,"num:")) < 0) return rc;
		nparm -= rc;	/* ���O�t�������́A�����Ɉړ����Ă���̂ŁA���̕������� */
		rc = 0;
	}
	else if (rc) return rc;

	pInfoParm = ppParm[0];
	id = pInfoParm->pi_id;
	if (id == ' ') atr = pInfoParm->pi_attr;
	else atr = 0;
	sel = 0x02 | 0x08 | 0x1000;	/* �z��A���X�g�A�f�[�^���� */
	if (atr == DEF_ZOK_BINA) sel |= 0x2000;
	if ((rc=cl_check_data_id2(pInfoParm,sel,0x03)) < 0) return rc;
	if ((rc=cl_info2maparray(&tInfoW,pInfoParm,NULL)) < 0) return rc;
	else if (rc) {
		pInfoParm = &tInfoW;
		id = pInfoParm->pi_id;
	}
	pInfo2 = ppParm[1];
	ope = pInfo2->pi_id;
	if (ope == 'F') {
		pInfoF = pInfo2;
		nparmF = 1 + nparm - 2;
		if ((rc=cl_get_ppParm_and_copy(ppParm+2,1,nparmF,&ppParmF)) < 0) return rc;
	}
	else {
		len = parm_to_char_tmp(ppParm[1],&pOperator,0);
		ope = *pOperator;
	}
/*	opt = 0;	*/
/*	if (nparm >= 5) {
		opt = cl_is_true(ppParm[4]);
	}
	else */if (len>1 && ope=='=') {
		pOperator++;
		ope = *pOperator;
		opt = 1;	/* ��p���������ʂ�Ԃ��B���̗v�f�͕ύX����Ȃ� */
	}

	iCONST = pInfoParm->pi_aux[1] & D_AUX1_PROTECTED;
	/* 2026.8.14 */
	if (iCONST) opt = 1;

DEBUGOUTL4(180,"%s: iCONST=%08x opt=%d pOperator=[%s]",_fn_,iCONST,opt,pOperator);

	if (nparm >= 3) {
		pInfo2 = ppParm[2];
		if (ope == 'F') ;
		else if ((id2=pInfo2->pi_id) != ' ') {
			ERROROUT2(FORMAT(636),_fn_,cl_get_variable_type(id2));	/* %s: %s�͎w��ł��܂���B*/
			return ECL_SCRIPT_ERROR;
		}
	}
#if 0
	if (nparm >= 4) {
/*
DEBUGOUT_InfoParm(0,"%s:ppParm[3]=",ppParm[3],_fn_,0);
*/
		pInfo = ppParm[3];
		if (cl_is_null_value(pInfo) || cl_is_null_parm(pInfo)) num = -1;
		else if ((rc=cl_get_parm_bin(pInfo,&num,"cl_func_element_ope pos:")) < 0) return rc;
	}
	else num = -1;
#endif
	count = rc = 0;
	max_layer = 0;
	if ((rc=cl_iterate_info_init(&tIter_ctl,NULL,pInfoParm,max_layer)) < 0) return rc;
	pIter = tIter_ctl.itc_pIter;
	nm = pIter->it_nm ;

	ex_opt = cl_get_option(28,0);
	if (!opt && nm<=0) {
		cl_set_parm_int(pInfoParmW,0);
		if (ex_opt & 0x01) ERROROUT1(FORMAT(203),_fn_);	/* %s: �f�[�^�����ݒ�ł��B*/
		return 0;
	}
	if (num>0 && nm>num) nm = num;

	/* opt<>0�̂Ƃ��́A��p���������ʂ�Ԃ����̂𐶐����� */
	if (opt) {
		memset(&tIter2,0,sizeof(tdtIterate));
		tIter2.it_id = id;
		tIter2.it_ix = 1;
		tIter2.it_nm = nm;
	/*	tIter2.it_pInfo = pInfoParm;	*/
		tIter2.it_pIndex = pIter->it_pIndex;
		if ((rc=cl_new_array_or_list(pInfoParmW,&tIter2)) < 0) return rc;
	}

	for (i=1;i<=nm;i++) {
		pInfoW = &tInfoParm;
		if ((rc=cl_iterate_info(&tIter_ctl)) < 0) break;
		if (!(pInfo=pIter->it_pInfo)) break;
		if (ope == '=') {
			pInfoW = pInfo2;
		}
		else if (!pInfo || cl_is_null_parm(pInfo) || !pInfo->pi_id) {
			sprintf(wrk,"%dth",i);
			if (ex_opt & 0x02) ERROROUT2(FORMAT(127),_fn_,wrk);	/* %s: %s�̃f�[�^�����ݒ�ł��B*/
			if (!pInfo) continue;
			pInfoW = pInfo;
		}
		else if (pInfo->pi_id == ' ') {
			if (opt || !(pInfo->pi_aux[1] & D_AUX1_PROTECTED)) {
				if (ope == 'F') {
					ppParmF[0] = pInfo;
					cl_parm_set0(pInfoW);
					if ((rc=cl_gx_func_method(pInfoW,pInfoF,nparmF,ppParmF,0)) < 0) return rc;
				}
				else {
					if ((rc=cl_gx_bexp(pInfoW,pInfo,pOperator,pInfo2,0,NULL)) < 0) return rc;
				}
			}
			else pInfoW = pInfo;
		}
		else pInfoW = pInfo;
		if (opt) {
			if ((rc=cl_set_array_or_list(&tIter2,pInfoW,pIter)) < 0) break;
		}
		else if (pInfo != pInfoW) {
			cl_gx_rep_info_set(pInfo,pInfoW,1);
			count++;
		}
	}
	if (!opt) cl_set_parm_int(pInfoParmW,count);
DEBUGOUT_InfoParm(161,"%s: count=%d pInfoParmW=",pInfoParmW,_fn_,count);
/*
printf("%s:Exit rc=%d\n",_fn_,rc);
*/
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_actin(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int nparm;
tdtInfoParm *ppParm[];
{
	return _func_act(pInfoParmW,nparm,ppParm,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_func_actas(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int nparm;
tdtInfoParm *ppParm[];
{
	return _func_act(pInfoParmW,nparm,ppParm,1);
}

/****************************************/
/*	210065701							*/
/****************************************/
int cl_func_set_const(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int nparm;
tdtInfoParm *ppParm[];
{
	int i,rc;
	tdtInfoParm *pInfoParm;

	for (i=0;i<nparm;i++) {
		pInfoParm = ppParm[i];
/*
printf("cl_func_set_const: pi_id=[%c]\n",pInfoParm->pi_id);
*/
	/*	if (pInfoParm->pi_id == 'S') {
			pInfoParm = (tdtInfoParm *)pInfoParm->pi_pos;	*/
		/*	if (!pInfoParm->pi_id || cl_is_undef_parm(pInfoParm) || cl_is_eof_parm(pInfoParm) ||
			    cl_is_null_value(pInfoParm) || cl_is_null_parm(pInfoParm)) ;
			else */pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED;
	/*	}	*/
	}
	cl_set_parm_int(pInfoParmW,0);
	return 0;
}

/****************************************/
/*	210066101							*/
/****************************************/
int cl_func_reverse(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int nparm;
tdtInfoParm *ppParm[];
{
	char *_fn_="cl_func_reverse";
	tdtInfoParm *pInfoParm,***pTBL,tInfo,*pInfo1,*pInfo2,*pInfoW;
	tdtArrayIndex *pIndex,tIndex,*pIndexW;
	tdtRbCtl *pCt,*pCt2,*pCt0;
	int rc,i,j,atr,sel,nm,n,m,*index,iRANGE;
	char id,*p;

	cl_null_parm(pInfoParmW);
	pInfoParm = ppParm[0];
	id = pInfoParm->pi_id;
	if (id == ' ') atr = pInfoParm->pi_attr;
	else atr = 0;
	sel = 0x02 | 0x08 | 0x1000;	/* �z��A���X�g�A�f�[�^���� */
	if (atr == DEF_ZOK_BINA) sel |= 0x2000;
	if ((rc=cl_check_data_id2(pInfoParm,sel,0x03)) < 0) return rc;

	rc = 0;
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		nm = pCt->rb_used;
	}
	else if (id=='A' || id=='R' || atr==DEF_ZOK_BINA) {
		pIndex = &tIndex;
		if ((rc=cl_get_array_index_tbl_ref(pInfoParm,&pIndex,&pTBL,_fn_)) < 0) return rc;
		index = pIndex->index;
		if (pIndex->xhp) {
			if (!(p = (char *)pInfoParm->pi_pos)) p = "";
					/* "%s: �A�z�z��(%s)�͎w��ł��܂���B*/
			ERROROUT2(FORMAT(239),_fn_,p);
			return ECL_SCRIPT_ERROR;
		}
		else {
			nm = index[2];
		}
	}
	n = nm;
	if (nparm >= 2) {
		if ((rc=cl_get_parm_bin(ppParm[1],&n,"cl_func_reverse:n")) < 0) return rc;
		if (n > nm) n = nm;
	}

	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		if (n < nm) {
			if (!(pCt2 = cl_tmp_rb_new(0,0,NULL))) return ECL_MALLOC_ERROR;
			if (!(pCt0 = akxs_rb_new(0,0))) return ECL_MALLOC_ERROR;
		}
		else pCt2 = pCt;
		*pInfoParmW = *pInfoParm;
		pInfoParmW->pi_data = (char *)pCt2;
		akxs_rb_read(pCt,0);
		for (i=0;i<nm;i++) {
			if (!(p = akxs_rb_read(pCt,1))) break;
			if (i < n) {
				akxs_rb_set_t(pCt0,p);
				if (n < nm) akxs_rb_set_t(pCt2,p);
			}
			else akxs_rb_set_n(pCt0,p);
		}
		akxs_rb_free(pCt);
		pInfoParm->pi_data = (char *)pCt0;
	}
	else if (id=='A' || id=='R' || pTBL) {
		if (n<nm || pTBL) {
			if ((rc=cl_def_array_tmp_opt(&pInfoW,n,NULL,0)) < 0) return rc;
			cl_gx_copy_info(pInfoParmW,pInfoW);
			pIndexW = (tdtArrayIndex *)pInfoParmW->pi_data;
		}
		if (pTBL) {
			for (i=0,j=n-1;i<j;i++,j--) {
				if (!(pInfo1 = cl_get_var_ent_opt(pTBL,i+1,'r'))) return -1;
				if (!(pInfo2 = cl_get_array_and_var_ent_opt(pIndex,pTBL,j+1,'r'))) return -1;
				cl_gx_copy_info(&tInfo,pInfo1);
				cl_gx_copy_info(pInfo1,pInfo2);
				cl_gx_copy_info(pInfo2,&tInfo);
			}
		}
		else {
			p = (char *)pIndex->pVarIndex;
			if ((atr=pIndex->uAttr[0]) == DEF_ZOK_VARI) {
				rc = mem_reverse_addr(p,n);
			}
			else {
				iRANGE = pIndex->uaux1 & D_AULN_RANGE_DATA;
				if (iRANGE) m = 2;
				else m = 1;
				if (atr == DEF_ZOK_BINA) {
					rc = mem_reverse_long_cell(p,n,m);
				}
				else if (atr == DEF_ZOK_FLOA) {
					rc = mem_reverse_double_cell(p,n,m);
				}
				else {
					m = pIndex->size;
					if (atr == DEF_ZOK_CHAR) m++;
					else if (atr == DEF_ZOK_BULK) m += sizeof(int);
					if (iRANGE) m+=m;
					rc = mem_reverse_byte_cell(p,n,m);
				}
			}
		}
		if (n<nm || pTBL) {
			for (i=1;i<=n;i++) {
				if (!(pInfo1 = cl_get_array_and_var_ent_opt(pIndex,pTBL,i,'r'))) return -1;
				if (!(pInfo2 = cl_get_array_and_var_ent_opt(pIndexW,NULL,i,'s'))) return -1;
				cl_gx_rep_info_set_ign(pInfo2,pInfo1,1);
			}
		}
		else cl_gx_rep_info_set_ign(pInfoParmW,pInfoParm,1);
	}
	pInfoParmW->pi_scale &= ~(D_DATA_MALLOC | D_DATA_INDEX_FREE);
	return rc;
}

/****************************************/
/*	210066501							*/
/*	i2<--i1								*/
/****************************************/
static int _cpy_pTBL(pTBL,i2,i1,n)
tdtInfoParm ***pTBL;
int i1,i2,n;
{
	int i;
	tdtInfoParm *pInfo1,*pInfo2;
/*
printf("_cpy_pTBL:Enter i2=%d i1=%d n=%d\n",i2,i1,n);
*/
	for (i=0;i<n;i++,i1++,i2++) {
		if (!(pInfo1 = cl_get_var_ent_opt(pTBL,i1,'r'))) return -210066501;
		if (!(pInfo2 = cl_get_var_ent_opt(pTBL,i2,'r'))) return -210066502;
		cl_gx_copy_info(pInfo2,pInfo1);
	}
	return 0;
}

/****************************************/
/*	210066601							*/
/*	w<--i1								*/
/****************************************/
static int _cpy_w_pTBL(pTBL,w,i1,n)
tdtInfoParm ***pTBL,w[];
int i1,n;
{
	int i;
	tdtInfoParm *pInfo1;

	for (i=0;i<n;i++,i1++,w++) {
		if (!(pInfo1 = cl_get_var_ent_opt(pTBL,i1,'r'))) return -210066601;
		cl_gx_copy_info(w,pInfo1);
	}
	return 0;
}

/****************************************/
/*	210066701							*/
/*	i2<--w								*/
/****************************************/
static int _cpy_pTBL_w(pTBL,i2,w,n)
tdtInfoParm ***pTBL,w[];
int i2,n;
{
	int i;
	tdtInfoParm *pInfo2;

	for (i=0;i<n;i++,i2++,w++) {
		if (!(pInfo2 = cl_get_var_ent_opt(pTBL,i2,'r'))) return -210066701;
		cl_gx_copy_info(pInfo2,w);
	}
	return 0;
}

/****************************************/
/*	210066801							*/
/*	i1-->i2								*/
/****************************************/
static int _rcpy_pTBL(pTBL,i2,i1,n)
tdtInfoParm ***pTBL;
int i1,i2,n;
{
	int i;
	tdtInfoParm *pInfo1,*pInfo2;

	i1 = n - i1 + 1;
	i2 = n - i2 + 1;
	for (i=0;i<n;i++,i1--,i2--) {
		if (!(pInfo1 = cl_get_var_ent_opt(pTBL,i1,'r'))) return -210066801;
		if (!(pInfo2 = cl_get_var_ent_opt(pTBL,i2,'r'))) return -210066802;
		cl_gx_copy_info(pInfo2,pInfo1);
	}
	return 0;
}

/****************************************/
/*	210066901							*/
/*	(s0,ix,n)							*/
/****************************************/
static int _rotate_pTBL(pTBL,ix,n)
tdtInfoParm ***pTBL;
int ix,n;
{
	int i,m,s,d,ret;
	tdtInfoParm w[10];
/*
printf("_rotate_pTBL:Enter ix=%d n=%d\n",ix,n);
*/
	ret = 0;
	if (X_ABS(ix) >= n) ret = 0;
	else {
		if (ix < 0) ix = n + ix;
		m = 10;
		if (m > ix) m = ix;
		d = 1;
		if (ix <= n/2) {
			for (i=0;i<ix;i+=m) {
				if (i+m > ix) m = ix - i;
				s = d + m;
				if ((ret=_cpy_w_pTBL(pTBL,w,d,m)) < 0) break;
				if ((ret=_cpy_pTBL(pTBL,d,s,n-m)) < 0) break;
				if ((ret=_cpy_pTBL_w(pTBL,d+n-m,w,m)) < 0) break;
			}
		}
		else {
			ix = n - ix;
			for (i=0;i<ix;i+=m) {
				if (i+m > ix) m = ix - i;
				s = d + m;
				if ((ret=_cpy_w_pTBL(pTBL,w,d+n-m,m)) < 0) break;
				if ((ret=_rcpy_pTBL(pTBL,s,d,n-m)) < 0) break;
				if ((ret=_cpy_pTBL_w(pTBL,d,w,m)) < 0) break;
			}
		}
	}
	return ret;
}

/****************************************/
/*	210067001							*/
/*	(s0,ix,n)							*/
/****************************************/
int cl_func_rotate(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int nparm;
tdtInfoParm *ppParm[];
{
	char *_fn_="cl_func_reverse";
	tdtInfoParm *pInfoParm,***pTBL,tInfo,*pInfo1,*pInfo2,*pInfoW;
	tdtArrayIndex *pIndex,tIndex,*pIndexW;
	tdtRbCtl *pCt,*pCt2,*pCt0;
	int rc,i,j,atr,sel,nm,n,m,*index,iRANGE,ix;
	char id,*p;

	cl_null_parm(pInfoParmW);
	pInfoParm = ppParm[0];
	id = pInfoParm->pi_id;
	if (id == ' ') atr = pInfoParm->pi_attr;
	else atr = 0;
	sel = 0x02 | 0x08 | 0x1000;	/* �z��A���X�g�A�f�[�^���� */
	if (atr == DEF_ZOK_BINA) sel |= 0x2000;
	if ((rc=cl_check_data_id2(pInfoParm,sel,0x03)) < 0) return rc;

	rc = 0;
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		nm = pCt->rb_used;
	}
	else if (id=='A' || id=='R' || atr==DEF_ZOK_BINA) {
		pIndex = &tIndex;
		if ((rc=cl_get_array_index_tbl_ref(pInfoParm,&pIndex,&pTBL,_fn_)) < 0) return rc;
		index = pIndex->index;
		if (pIndex->xhp) {
			if (!(p = (char *)pInfoParm->pi_pos)) p = "";
					/* "%s: �A�z�z��(%s)�͎w��ł��܂���B*/
			ERROROUT2(FORMAT(239),_fn_,p);
			return ECL_SCRIPT_ERROR;
		}
		else {
			nm = index[2];
		}
	}
	n = nm;
	if (nparm >= 3) {
		if ((rc=cl_get_parm_bin(ppParm[2],&n,"cl_func_rotate:n")) < 0) return rc;
		if (n > nm) n = nm;
	}
	ix = 1;
	if (nparm >= 2) {
		if ((rc=cl_get_parm_bin(ppParm[1],&ix,"cl_func_rotate:ix")) < 0) return rc;
	}
	if (X_ABS(ix) >= n) return 0;

	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		if (n < nm) {
			if (!(pCt2 = cl_tmp_rb_new(0,0,NULL))) return ECL_MALLOC_ERROR;
			if ((rc=akxs_rb_cpy(pCt2,pCt,n)) < 0) return rc;
			if (!(pCt0 = akxs_rb_new(0,0))) return ECL_MALLOC_ERROR;
			akxs_rb_read(pCt,-n);
		}
		else pCt2 = pCt;
		*pInfoParmW = *pInfoParm;
		pInfoParmW->pi_data = (char *)pCt2;
		if (ix < 0) ix = n + ix;
		if (ix >= 0) {
			for (i=0;i<ix;i++) {
				if (!(p = akxs_rb_get_n(pCt2))) break;
				else akxs_rb_set_n(pCt2,p);
			}
			if (n < nm) {
				if ((rc=akxs_rb_cpy(pCt0,pCt2,-1)) < 0) return rc;
				for (i=n;i<nm;i++) {
					p= akxs_rb_read(pCt,1);
					akxs_rb_set_n(pCt0,p);
				}
				akxs_rb_free(pCt);
				pInfoParm->pi_data = (char *)pCt0;
			}
		}
	}
	else if (id=='A' || id=='R' || pTBL) {
		if (n<nm || pTBL) {
			if ((rc=cl_def_array_tmp_opt(&pInfoW,n,NULL,0)) < 0) return rc;
			cl_gx_copy_info(pInfoParmW,pInfoW);
			pIndexW = (tdtArrayIndex *)pInfoParmW->pi_data;
		}
		if (pTBL) {
			if ((rc=_rotate_pTBL(pTBL,ix,n)) < 0) return rc;
		}
		else {
			p = (char *)pIndex->pVarIndex;
			if ((atr=pIndex->uAttr[0]) == DEF_ZOK_VARI) {
				rc = mem_rotate_addr_cell(p,ix,n,1);
			}
			else {
				iRANGE = pIndex->uaux1 & D_AULN_RANGE_DATA;
				if (iRANGE) m = 2;
				else m = 1;
				if (atr == DEF_ZOK_BINA) {
					rc = mem_rotate_long_cell(p,ix,n,m);
				}
				else if (atr == DEF_ZOK_FLOA) {
					rc = mem_rotate_double_cell(p,ix,n,m);
				}
				else {
					m = pIndex->size;
					if (atr == DEF_ZOK_CHAR) m++;
					else if (atr == DEF_ZOK_BULK) m += sizeof(int);
					if (iRANGE) m+=m;
					rc = mem_rotate_byte_cell(p,ix,n,m);
				}
			}
		}
		if (n<nm || pTBL) {
			for (i=1;i<=n;i++) {
				if (!(pInfo1 = cl_get_array_and_var_ent_opt(pIndex,pTBL,i,'r'))) return -210067001;
				if (!(pInfo2 = cl_get_array_and_var_ent_opt(pIndexW,NULL,i,'s'))) return -210067002;
				cl_gx_rep_info_set_ign(pInfo2,pInfo1,1);
			}
		}
		else cl_gx_rep_info_set_ign(pInfoParmW,pInfoParm,1);
	}
	pInfoParmW->pi_scale &= ~(D_DATA_MALLOC | D_DATA_INDEX_FREE);
	return rc;
}
