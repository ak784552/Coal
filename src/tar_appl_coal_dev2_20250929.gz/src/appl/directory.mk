#---------------------------------------------------------------
#			directory
#---------------------------------------------------------------
#DEVELOPHOME		= ../../../..
DEVELOPBIN		= $(DEVELOPHOME)/bin
DEVELOPINC		= $(DEVELOPHOME)/include
DEVELOPLIB		= $(DEVELOPHOME)/lib
DEVELOPSRC		= $(DEVELOPHOME)/src
DEVELOPTOOLS	= $(DEVELOPHOME)/tools
DEVSRCTOOLS		= $(DEVELOPSRC)/tools
DEVELOPLIB		= $(DEVELOPSRC)/lib
LIBINC			= $(DEVELOPLIB)/include
LIBAKX			= $(DEVELOPLIB)/akx
LIBAKB			= $(DEVELOPLIB)/akb
LIBAKA			= $(DEVELOPLIB)/aka
LIBTLS			= $(DEVELOPLIB)/tools

