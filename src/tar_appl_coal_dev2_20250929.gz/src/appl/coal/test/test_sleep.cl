//
PROC main;
	print TIME gettime(0) gettime(1);
//	funcs(5 - 1.5);
//	sleep 5 - 1.5;
	sleep %1;
	print ERROR ERRMSG TIME gettime(0) gettime(1);
	RETURN $ERROR;
END PROC;

function funcs(a);
	sleep a;
	return 0;
end func;
