//
define array $a 17;
//define array BIN $a 17;
//define array CHAR(11) $a 17;
//define array FLOAT $a 17;
//define array $a HASH 20;
proc main;
//	option 11 4;
//	$dir = '.';
//	$dir = 'hon1';
	$dir = %1;
	$dp = opendir($dir);
	if ERROR; return ERROR; endif;
	loop while $f = readdir($dp);
//		if ERROR; break; endif;
//		putline($f,',',$1);
/*
		stat($dir &+ '/' &+ $f,1,17);
		loop for $i=1 $i<=17 $i++;
			putline('i=',$i,' val=',$$i);
		end loop;
*/
		stat($dir &+ '/' &+ $f,$a);
/*
		loop for $i=0 $i<17 $i++;
			putline('i=',$i,' val=',$a[$i]);
		end loop;
*/
		putline('*** ',$f,' ***');
		loop each $i in $a;
			putline('i=',$i.Index,' val=',$i.Value);
		end loop;
	end loop;
	closedir($dp);

//	$fp = fopen('a');
	return $ERROR;
end proc;
