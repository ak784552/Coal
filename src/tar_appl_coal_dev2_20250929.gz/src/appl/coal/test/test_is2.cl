//
PROC main;
	$1 = is(' -123 ','N');
	print $1 is($1,'t');
	print "is(' -123 A ','N')";
	print "is(' -123F ','N')";
	print "is(' -0xff ','N')";
	print "is(' -123.45 ','N')";
	print "is(' -123.45A ','N')";
	print "is('XYZ-123.45 ',4,'N')";
	print "is('XYZ-123.45 ',4,6,'N')";
	print "is('XYZ-123.45 ',4..6,'N')";
	print "is(123.45,3,'N')";
	print "is(123.45,3,'I')";
	print "is(123.45,3,'T')";
	RETURN $ERROR;
END PROC;
