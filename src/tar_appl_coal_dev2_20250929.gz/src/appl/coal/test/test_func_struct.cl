//
define type struct z
	int a
	,char(5) b
	, dec(10,2) c
	,bulk(20) d
;
define var x as z;
proc main;
	x.a = 10;
	x.b = 'XYZ';
	x.c = 12345.67;
	x.d = '1234567890';
	print func1(x.a,x.b,x.c,x.d);
	print func2(x);
	print *x;
	return $ERROR;
end proc;

function func1 argc argv (a,b,c,d);
	print a b c d;
	return a += 10;
end func;

function func2 argc argv (xx);
	print xx.a xx.b xx.c xx.d;
	return xx.a += 10;
end func;
