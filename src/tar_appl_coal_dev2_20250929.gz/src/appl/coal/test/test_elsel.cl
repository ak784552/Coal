//
proc main;

	if %1 thenl print %1;

	if %1=='1' then print 'then' %1;
	elsel print 'else' %1;

	if %1=='1' then print 'then' %1;
	elseif %1=='2' thenl print 'elseif then' %1;

	if %1=='1' then print 'then' %1;
	elseif %1=='2' then print 'elseif then' %1;
	elsel print 'else' %1;

	if %1 then
		if %2 thenl print %1 %2;
	end if;

	if %1 then
		if %2 then print %1 %2;
		elsel print %4;
	end if;

	if %1 then
		if %2 thenl print %1 %2;
	elsel print %4;

	if %1 then
		if %2 thenl print %1 %2;
	else
		print %4;
	end if;

	if %1 thenl
		if %2 thenl print %1 %2;

	if %1 then print 'X';
	elsel
		if %2 then print %1 %2;
		else print 'D';
		end if;
/*
//	error
	if %1 thenl
		else print 'thenl else';

//	error
	if %1 thenl
//	end if;
	elseif %3 thenl print 'thenl else';
*/

	if %1 thenl
			if %2 then
				print 'A';
				if %3 then
					print %3;
				else
					print %3;
				end if;
			else
				print %4;
			end if;

	return $ERROR;
end proc;
