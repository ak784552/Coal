//
proc main;
	option 18 %1;	// 1
	text = 'abcdefg1234ABCDEFxxYYzZ����%��pQrabcABC';
	print %1 leng(text) text;
	print skip_opt(text,'','T');
	print skip_opt(text,'','RT');
	print skip_opt(text,'','N');
	print skip_opt(text,'','RN');
	print skip_opt(text,'y','T');
	print skip_opt(text,'y','RT');
	print skip_opt(text,'a','N');
	print skip_opt(text,'C','RN');
	print skip_opt(text,'1','T');
	print skip_opt(text,'1','RT');
	print skip_opt(text,'cdab','N');
	print skip_opt(text,'cdab','RN');
	print skip_opt(text,'��');
	print skip_opt(text,text,'N');
	print skip_opt(text,text,'RN');

	print skip_opt(text,10,'xY','T');
	print skip_opt(text,10,'abc','RT');
	print skip_opt(text,10,10,'CD','T');
	print skip_opt(text,5..10,'xY','T');

	print "text skip_opt 'EF'";

	return ERROR;
end proc;
