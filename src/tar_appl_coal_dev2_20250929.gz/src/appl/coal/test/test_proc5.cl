//
define global gn = 2;
proc main;
	print gn;
	gn--;
	if gn > 0;
		exec sc test_proc5 gn;
	end if;
	return ERROR;
end proc;
