//
define array a 10;
//if 0;endif;
PROC main;
//	proc aa; endproc;
	loop 1;
	print "3 eq 2 + 2";
	let $ff = 2;
	$1 = %1 condas '//null/%q';
	a[0] = 1;
	$rep = rep('A&0&BC&1&de','123&&456&&789');
	$condas = condas('ABC','/ABC/Yes%s/No');
	print $rep $condas $1 $ff;
	endloop;
	RETURN ERROR;
END PROC;
