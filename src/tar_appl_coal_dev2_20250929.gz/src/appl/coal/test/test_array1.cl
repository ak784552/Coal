//
define mappedarray %parm 2 10;
define array ha 10;
proc main;
//	print %parm ha;
	print /d %parm ha;
	print *%parm *ha;
//	loop for (i=0;i<%0;i++);
	print countv(%parm) m=countv(%parm,1);
	loop for (i=0;i<m;i++);
//	loop for (i=0;i<(m=countv(%parm));i++);
		print %parm[i];
//		ha[%parm[i]] = %parm[i];
	end loop;

//	n = sort(1,%parm,m);
	n = sort(1,%parm,m,'F',1,0,'N');
	loop for (i=1;i<=n;i++);
		print $$i;
	end loop;

	return $ERROR;
end proc;
