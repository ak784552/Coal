//
define array $a 10;
//define array char(10) $a 10;
//define array BIN $a 10;
proc main;
	option 5 1;
	$1 = LIST(1, 2, 3, 'A', 's');
	print $1;
	print rest($1);
	loop for $i=0 $i<6 $i++;
		print rest($1,$i);
	end loop;
	return ERROR;
end proc;
