//
proc main;

//	print  (1,2,3,4,5,6,7,8,9);
loop 2;
	for each $_x in 1,2,3,4,5,6,7,8,9;
//		print /i $_x;
		print $_x.Index $_x.Value;
//		print *$_x;
	next;
	print /i $_x;

	a = 1;

	for each $_x in ['A','B',1,2,3,4,5,'C'] do
//		print $_x.Index $_x.Value;
		print *$_x;
	next;
	print /i $_x;
	b = 1;

end loop;

	return ERROR;
end proc;
