//
def const global d = 4;
def type struct aa
	int a,
	char c;
//def error;
proc main;
/*
	redef const global d = 444;
	print d /i d;
	print "aa = 1";

	const x;
	x = 0;
	print x /i x;
*/
	print error;
	print error=0;
	print aaaaa;
	return ERROR;
end proc;
