//
def aa 10 = '��','�K','��';
def bb 10 = 10,20,{30,40,[50,60,70],80,90},100;
proc main;

	print in('yy','yy','A');
	print iin('YY','yy','A');
	bexp a = 'AA' in 'yy' 'AA';
	bexp b = 'AA' iin 'yy' 'aa';
	print a b;
	print in('yy','xx','A');
	print iin('YY','XX','A');
	bexp a = 'AA' in 'yy' 'BB';
	bexp b = 'AA' iin 'yy' 'bb';
	print a b;

	print in('��','��','�K','��');
	print in('��','��','�K','Y',2);
	print in('�`B','AB','�`B');
	print in('�`B','AB','�`B',2);
	print in('ABC','AB','�`B�b',2);

	BEXP x = 'ABC' in 'AB' '�`B�b' 2;
	print x;

	print in('��',aa,2);
	print in(100,1,2,3,10,100,4);
	print in(60,bb);
	print in(5,bb);
	print "80 in bb";
	print "10 == bb";
	print in(50,cc);

	return ERROR;
end proc;
