//
proc main;
/*
	$1 = '1';
	$2 = '10';
	$1++ = $2++ + 1.0;
	echo $1 $2;
*/
	a = 1;
	print ++a a++;
	b = *(1..10);
	print b;
	c = (1,2,3,4,5,6,7,8,9,10);
	print c;
	return ERROR;
end proc;
