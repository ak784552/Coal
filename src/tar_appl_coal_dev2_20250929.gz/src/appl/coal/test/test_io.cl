//
proc main;
	try;
		print edit('%08x',$STDOUT);
		$r = felwrite($STDOUT,'Endter :');
		$n = fgetline($STDIN);
		print $n;
	catch -1;
	catch;
		echo ERROR ERRNO ERRMSG;
	end try;
	return $ERROR;
end proc;
