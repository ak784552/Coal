//
proc main;
	if %2;
		fputline(STDOUT,'Enter any key');
		fgetline(STDIN);
	endif;
	$i = 0;
	loop 10;
		loop 100;
			$i++;
		end loop;
		fputline(STDOUT,$i,' thread=',%1);
	//	fgetline(STDIN);
	end loop;
	return $ERROR;
end proc;
