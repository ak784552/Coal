//
define array $a 10 = ['X','Y','Z'];
//define array char(10) $a 10;
//define array BIN $a 10;
type struct t_a 
	int a,
	char b,
	c[3];
t_a ta = [100,'AAA',10,'XXX',20];
proc main;
	let option 5 1;
if %1;
	print "{1, 2, 3, *$a, ta, 1..3}";
	print "[1, 2, 3, *$a, ta, 1..3]";
	$1 = FL('LIST', 1, 2, 3, *$a, ta, 1..3);
	print /c- $1 *$1 /i $1;
	$2 = FL('LIST', 'A', 's');
	print $2 *$2 /i $2;
	print $1&+$2;
	loop while countv($1);
		$3 = FL('first',$1);
		print $3;
		$1 = FL('rest',$1);
		print $1;
	end loop;

	$a[0] = FL('LIST', 1, 2, 3);
	$a[1] = FL('LIST', 'A', 's');
	print $a[0] $a[1] FL('LIST',$a[0],$a[1]);
	print countv($a[0]) countv($a[1]) countv(FL('LIST',$a[0],$a[1])) countv(10);
	$5 = FL('CONS',$a[0],$a[1]);
	print $5 countv($5);
else;
	$1 = LIST(1, 2, 3, $a, ta, 1..3);
	print /c- $1 *$1 /i $1;
	print $1.first();
	$2 = LIST('A', 's');
	print $2 *$2 /i $2;
	print $1&+$2;
	loop while countv($1);
		$3 = first($1);
		print $3;
		$1 = rest($1);
		print $1;
	end loop;
	print first($1) $1.first();
//	a[0] = $1;
//	print *a;

	$a[0] = LIST(1, 2, 3);
	$a[1] = LIST('A', 's');
	print $a[0] $a[1] LIST($a[0],$a[1]);
	print countv($a[0]) countv($a[1]) countv(LIST($a[0],$a[1])) countv(10);
	$5 = CONS($a[0],$a[1],'XYZ');
	print $5 countv($5);
end if;
	for each x in a;
		print *x;
	next;
	return ERROR;
end proc;
