//
proc main;
	a = 102;
	exec ip proc-1 a;
	return ERROR;
end proc;

proc proc-1 (x);
	print 'called proc-1';
	print x;
	return -10;
end proc;
