//
define array a 4;
proc main;
	option 18 2;
	x = '12�R�S5123456ABCDEabcdef67890';
/*
//	n = inlike(1,,x,'ABC','ig');		//[%ABC%]
	n = inlike(1,,x,'[123]','ig');		//[%ABC%]
	f(n,a);

	n = inlike(a,2,x,'ABC','ig');		//[%ABC%]
	f(x,n,a);
*/
	n = inlike(a,2,x,6,'ABC','ig');		//[%ABC%]
	f(x,n,a);
	n = inlike(a,2,x,6,10,'ABC','ig');		//[%ABC%]
	f(x,n,a);
	n = inlike(a,2,x,6..10,'ABC','ig');		//[%ABC%]
	f(x,n,a);

	n = inlike(a,2,x.6,'ABC','ig');			//[%ABC%]
	f(x.6,n,a);
/*
	putline(replike(x,'ABC','WXYZ','g'));		//[%ABC%]
	putline(replike(x,'ABC','WXYZ','iG'));		//[%ABC%]
	putline(replike(x,'ABC%de','WXYZ','g'));	//[%ABC%de%]
	putline(replike(x,'ABC%de','WXYZ','Ig'));	//[%ABC%de%]
	putline(replike(x,'^1234','WXYZ','g'));		//iTOP=1 iBTM=0 patlen=5 pat=[1234%]
	putline(replike(x,'^','WXYZ','g'));			//iTOP=1 iBTM=0 patlen=0 pat=[]  �擪�̂�
	putline(replike(x,'7890$','WXYZ','g'));		//iTOP=0 iBTM=1 patlen=5 pat=[%7890]
	putline(replike(x,'$','WXYZ','g'));			//iTOP=0 iBTM=1 patlen=0 pat=[]�@�����̂�
	putline(replike(x,'^%$','WXYZ','g'));		//iTOP=1 iBTM=1 patlen=1 pat=[%]�@�S��
	putline(replike(x,'^$','WXYZ','g'));		//iTOP=1 iBTM=1 patlen=0 pat=[]�@�擪�Ɩ����̂�
	putline(replike(x,'^%','WXYZ','g'));		//iTOP=1 iBTM=0 patlen=1 pat=[%]�@�S��
	putline(replike(x,'%','WXYZ',''));			//iTOP=0 iBTM=0 patlen=1 pat=[%]�@�S��
	putline(replike(x,'','WXYZ','g'));			//��v���Ȃ�
*/
	return ERROR;
end proc;

func f(x,n,a);
	print n *a;
	for (i=0,k=0;i<n;i++);
		print pos=a[k++] len=a[k++] substr(x,pos,len);
	next;
	return 0;
end func;
