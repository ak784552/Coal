//
define array $z 10f;
def type struct tttt
	int a,
	char b;
tttt t;
proc main;
	const w = 1;
//	x=1;
//	print %(3);
	print 'AB%CD';
	$(1) = 'AB%CD';
//	exec ip sub1;
//	exec ip sub1;
//	print "10 %(3)";
//	print "10 + %(3)";
//	print "10 % {3}";
//	$z[0] = 1;
//	$1 = 'AA';
//	$a = 'BB';
//	print ${%{1}};
	print $((%1));
//	print ${$z[0]};
//	print $($z[0]);
//	$(a) = 100;
//	print $(a);
//	print !1 ~3;
//	print 1! 3~;
	print ++1 3++ +-2 ++w w++;
//	print ++'1' '3'++;
//	print 'A'(0);
//	print 'X'[0];
	print t=1 ++t t++;
	print 2147483648;
	return ERROR;
end proc;

proc sub1;
	print $(1);
	return ERROR;
end proc;
