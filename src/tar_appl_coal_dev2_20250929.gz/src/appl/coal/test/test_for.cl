//
define array $a hash 5;
PROC main;
//	$MAX_LOOP_WHILE = 10;
//	loop for "$x=0,$i=1;" "$x<3;" "$x++,$i+=2";
//	loop for "$x=0,$i=1" "$x<3" $x++,$i+=2;
	for ($x=0,i=1;$x<4;i++,x++);
		print $x $i;
	endfor;
//	end do;
//	loop while 1;
	for ($x=0 ;$x<4;x++,x/0);
		print $x $i;
//	end for;
	next;
//	end loop;
	RETURN $ERROR;
END PROC;
