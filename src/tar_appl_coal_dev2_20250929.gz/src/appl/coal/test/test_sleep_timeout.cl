//
proc main;
	$1 = 60;
//	$1 = 700;
	$2 = 10;
	loop while $1>0;
		print $1 gettime();
		sleep $2;
		$1 -= $2;
	end loop;
	return ERROR;
end proc;
