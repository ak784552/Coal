//

//define mappedarray %parm 1 100;
//define array a 10;
//define array ha hash 10;
proc main;
//	print %parm[0];
//	a[0]=1;
//	ha['A']=10;
	$1=1;
	a=3;
	private a=2;
	print a "private a";
	undefine a;
	print a;
	return $ERROR;
end proc;
