//
import 'lib_iconv';
import 'lib_math';
import 'test_import3';
import 'lib_iconv';
import 'lib_math';
define a;
PROC main;
	a='aaa';
	print a;
	print /x conv('ABC123',6);
	print sind(30d);
	RETURN $ERROR;
END PROC;
