//
//	../coal -o13=2 test_print /c 2 A
//
def a 5;
PROC main;
//	option(1) 2;
//	option 13 2;
	x = 1000.5;
	output dt 98888 0 %1 %2 %3 x;
	output pr %1 %2 %3 x;
	print %1 %2 %3 x;
	lprint %1 %2 %3 x;
	echo %1 %2 %3 x;
	say %1 %2 %3 x;
	print /d %1,%2,%3,x;
	print abs;
	print (%1,%2,%3,x);
	1+print(%1,%2,%3,x);
	lprint(%1,%2,%3,x);
	print(%1,%2,%3,x);
	echo(%1,%2,%3,x);
	say(%1,%2,%3,x);
	putline(%1,%2,%3,x);
	x = 'A'..'C';
	print %1 %2 *x;
	print(%1,%2,*x);
	putline(%1,%2,*x);
//	print "( CINT )(1,2,3)";
//	call(aaa);
	x = [1,2,3];
	print [1,2,3] x;
	print /i [1,2,3] x;
	x = {1,2,3};
	print {1,2,3} x;
	print /i {1,2,3} x;
	print({1,2,3},x);
	echo({1,2,3},x);
	putline({1,2,3},x,a);
	print -12345.0 /p+Z -12345.0 /p,1 -12345.0;
	y = sprint(%1,%2,%3,x);
	print y;

	RETURN $ERROR;
END PROC;
