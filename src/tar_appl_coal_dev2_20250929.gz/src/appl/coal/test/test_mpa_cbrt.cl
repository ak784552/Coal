//
proc main;
	print edit('%.15e',cbrt(%1+0));
	print u_cbrt(%1+0);
//	dec(20,15) x = u_cbrt(%1+0);
//	print x;
	return $ERROR;
end proc;

function u_cbrt(b);
	const dec d0 = '1.-40';
	s = 0;
	if b < 0 then
		b = -b;
		s = 1;
	end if;
	x0=b;
	if (x0>=6) then x0/=3; endif;
print x0;
	loop 10 do
		xx=x0*x0;
		if abs(d=((y=xx*x0)-b)/(3*xx)) <= d0 thenl break;
print d;
		x0-=d;
print x0;
	end do;
	if (y-b>=1) thenl x0--;
	if s thenl x0 = -x0;
	return x0;
end func;
