//
public pa='QWE';
global ga=100;
proc main;
	public pa='X';
	global ga=200;
	print pa ga;
	return ERROR;
end proc;
