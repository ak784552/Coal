//
proc main;
/*
	$a = 1;
	print a;
	$b = $a << 2;
	$c = $a << 2 + 1;
	$d = $a << 2 * 3;
	print $a $b $c $d;
*/
	i = -1;
	print i>>1 "i >>> 1";
/*
	print i>>2 "i >>> 2";
	uint ui=-1;
	print ui>>1;
	ui = -1;
	double dd = ui;
	print dd;
	print 256>>-1 256<<33;
*/
	return ERROR;
end proc;
