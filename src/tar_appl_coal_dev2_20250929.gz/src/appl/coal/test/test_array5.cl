//
//define const array $a 10 = (1,2,3,4,5);
//define array $a 10 = (1,2,3,4,5);
//define array $a 10 = (1,2,3,4,5),6,7,8,9,10;
define array $a 10 = 6,7,8,(1,2,3,4,5),9,10;
//define array $a 10 = 1,2,3,4,5;
//define array $a = (1,2,3,4,5);
define char $b =20;
define array x = {1,2,3,4,5},{10,{11,12},13};
proc main;
//	$a++;
//	fopen = 1;
//	$a = 1;
//	fopen = 1;
//	$a = 1;
	print *a;
	print $b;
//	private array $a 10;
//	const private array $a 10;
//	array private $a 10;

//	$b = 2;
	$a[1] = 2;
//	$b = $a[1];
	print $a[1] $a $b a[3];
	print x[0] x[1];
	return ERROR;
end proc;
