//
define global $g;
//define global $ga;
define global gaa 10;
proc main;
//	print $g $ga;
	exec ip sub1 gaa;
	print $g[0] $g[1];
	print $g;
	print gam;
	print gm;
//	exec sc test_array9sub;
//	print $ga[0] $ga[1];
//	print $ga;
	return ERROR;
end proc;

proc sub1(p1);
//	array $a 10;
	a = p1;
	$a[0] = 1;
	$a[1] = 2;
	$g = $a;
	global gam = a + 2;
	global gm = arraymap(a,2);
//	print /d $g;
//	print $g[0] $g[1];
	return ERROR;
end proc;
