//
// 
//
define a[10];
proc main;
	xyz=3;

	a[0]=2;
	a[1]=abs;
	a[2]='XYZWTSR';

	'ABC'.print();
	'EFGH'.putline();
	print 'ABCDEF'.leng();
	print 'ABCDEF'.3;
	'5'.times(print,'X');

	print 'ABCDEF'.leng()+10;

	print 'ABCDEF'.xyz;
	print 'ABCDEF'.'xyz';

	print 'ABCDEF'.(CBULK)xyz;

	print 'ABCDEF'.(a[0]);
	print a[2].(a[0]);
	print a[1](-2);

	print ('ABCDEF'.3).2;
	print 'ABCDEF'.3.(2);
	print 'ABCDEF'.(3).2;
	print 'ABCDEF'.(leng('123'));

	print 'ABCDEF'.((func)'leng')();
	print ((func)'abs')(-2);
	print (Char(10))'123456789012345';

	return ERROR;
end proc;
