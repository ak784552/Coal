#! /bin/coal
//
//#>define YH01	yh01 + \
//	12
//#>include test_prepro
#>define yh01	YH01
//#>define YH01	yh02
//pragma define AAAA;
define array $a 10;
proc main;
#>if 0
	$a[0] = 'Table';
#>elif 1
#>if 1
	$a[0] = 'AAAAAAA';
#>else

	$a[0] = 'BBBBBBB';
#>endif
#>else
	$a[0] = "Table";
#>endif
#>ifdef YH01
//	SQL YH01 "" 1;
//print $TRNSHID ERROR;
	SQL YH01 "" "select * from dual" 'A234' 1 + 1 5.5;
#>elifdef YH02
	SQL yh02 "" "select * from $a[0]" "" 6.6;
//	SQL YH01 "" "select * from %(1)" "" 7.7;
#>else
	SQL SV01 "" "select * from '%{1}' ABCDEFG" "" 8.8;
#>endif
	"";
	print '';
	print ERROR;
	return ERROR;
end proc;
