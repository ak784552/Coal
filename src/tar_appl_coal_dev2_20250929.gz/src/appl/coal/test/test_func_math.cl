//
//option 20 16;
import lib_math.cl;
proc main;
/*
	print abs(-10.0f);
	print /p50 sqrt(4.0);
	print /p50 sqrt(2.0);
	print (CDEC)PI;
	print (CDEC)PI/180.0;
	print sin(30.0*PI/180.0);
	print cos(60.0*PI/180.0);
	print tan(45.0*PI/180.0);
	print sind(30.0);
	print cosd(60.0);
	print tand(45.0);
	print cbrt(10.0d);
	print cbrt(10.0);
*/
//	print log10(M_E2);
//	print log10(2.0);
	print log10(10.0);
	print log10(10.0d);
/*
	print log10(10.1);
	print log10(10.1d);
	print log(2.0);
*/
	print log(9000.0);
	print log(9000.0d);
//	print log(10.1d);
//	print log(10.1);
	print log(0.1);
	print log(0.05);
	print log(0.05d);
	print ln(10.0);
/*
	print /p+ (9.99e-307);

	print log(10.0d);
	print log(10.0);
	print /pZ log10(10.0);
	print -5.3D;
	print -5.0D;
	print -12345.6789123456789D;
	print 12345.6789123456789D;
	print 123456789123456789.0D;
	print 0.00123456789123456789D;
	print 'AAA' 0.1251D +01234567890 01234567890;

	print exp(0.0);
	print power(3.0,2.0);
	print 3.0**2 4*3**2 3**2*4 4**3**2;
	print rand1();
	print rand1();
	print rand1();
	print srand1(100);
	print rand1();
	print rand1();
	print rand1();

	print "3 power 2";
	print "3 sqrt 0";
	print "3 concat 0";
*/
	return $ERROR;
end proc;
