//
define type struct z
	int a 5 3 2
	,char(5) b
	, dec(10,2) c 10,
	bulk(20) d
	,double e hash
	, variant f
	, g
;
define var a as z;
define var y as DEC(5,2);
define array bulk(10) x 10;
//redefine array bulk(5) x 10 = ['98765',1234];
define char(10) cc = '9876543210a';
define mappedarray ma 1 3 2 4 = 10;
proc main;
	x[0] = '1234567890';
	print x[0];
	redefine array bulk(5) x 10 = ['98765',1234];
	print x[0] x[1];
	redefine array a.a = ['98765',1234];
//	array a.a = '98765',1234;
	print a.a[0] a.a[0,0,1];
	print cc;
	redefine char(5) cc;
	print cc;
	redefine char(15) cc = '012334567890asdfgh';
	print cc;
	print ma *ma;
loop 2;
	redefine mappedarray ma 2 10 = [1000,2000,3000];
	print ma *ma;
end loop;

	redefine mappedarray mb 4 10 = 400;
	print mb *mb *$();

	return ERROR;
end proc;
