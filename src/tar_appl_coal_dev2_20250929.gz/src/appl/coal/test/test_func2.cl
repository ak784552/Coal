//
proc main;
	option 8 4;
	print substr('ABCDRF',,2);
	Func1();
	return $ERROR;
end proc;

proc func1;
	print 'called func';
	return $ERROR;
end proc;

func func1;
	print 'called func';
	return $ERROR;
end func;
