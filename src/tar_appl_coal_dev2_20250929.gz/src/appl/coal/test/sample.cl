//
//  sample.cl
//
proc main;
	putline('Hello World! ',%1);
//	print 'Hello World!' %1;
	print /qnc- 'Hello World!' %1;
	echo 'Hello World!' %1;
	printf '%s %s\n' 'Hello �v���������I' %1;
	output dt 98888 2 /cnq- 'Hello World!' %1;		// --p1,1
	output dt 98888 2 /cnq- /e 'Hello World!' %1;
	print getmemused(1,6) *$();

	return;
end proc;
