//
proc main argc argv (aa,bb,cc);
	print %0 argc countv(%argv) *%argv;
	for i=1 to 4;
		print %$i %argv[i-1];
	next;
	print aa bb cc;
	a = 102;
	exec ip proc-1 a 'A' "" 'C';
	return ERROR;
end proc;

proc proc-1 argc argv (char x,y,z);// as char;
	print argc countv(%argv) *%argv;
	print x y z;
	for i=0 to 4;
		print %argv[i];
	next;
	return ERROR;
end proc;
