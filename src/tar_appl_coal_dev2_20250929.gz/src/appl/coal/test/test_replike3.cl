//
proc main;
	x = '12345$67\';
	y = '\\\\';
	print x y;
	print x replike(x,'\\$','|','g');
	return ERROR;
end proc;
