//
proc main;
	x = 'pPacket->SrcInf.ucDispos |= opt;';
	y = 'pPacket->SrcInf';
	y = 'pPacket[-]>SrcInf';
	y = 'pPacket[A-Z]>SrcInf';
	y = 'pPacket[A\\-Z]>SrcInf';
	print x y;
	print x replike(x,y,'abc','g');
	x = 'abwfdr123bcaefgf789';
	print x replike(x,'[a-c3-7]','X','g');
	x = '��ABC 	 DEF ';
	print x replike(x,'[ \t]','X','g');
	return ERROR;
end proc;
