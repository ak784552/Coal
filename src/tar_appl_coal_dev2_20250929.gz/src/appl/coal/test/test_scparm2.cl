//
//proc main;
proc main (a);
	print %0 *%();
//	$1 = L('LIST',%1,2);
//	$1 = LIST($a,2);
	print %1;
	$x = %1;
	$x[0] = 10;
	print $x[1];
	print $x[2](-3) %2(5,8);
	print %3 %4;
	return ERROR;
end proc;
