//

define array aa[2,3,4] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];
define array ah hash[10];
define mappedarray %am [5,10];
define array bb[-1..0,1..3,4] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];

define const int IP_SHIGYO = 22;
proc main;

	print aa;
	print %am *%am;
	f(aa+10);
	f(%am+3);
	aam = arraymap(aa,1,2);
	print aam *aam;
	bbm = arraymap(bb,0,3);
	print bbm *bbm;
//	print aa[0,0,4];

	f2(10,2);
//	f2(6,3);
	return ERROR;
end proc;

func f(a);
	print a *a;
	return 0;
end func;

func f2(a,b);
	const dec(a,b) IP_SHIGYO = 13.4567;
//	dec(10,2) IP_SHIGYO	= 13.4567;
print a b IP_SHIGYO;
	return 0;
end func;
