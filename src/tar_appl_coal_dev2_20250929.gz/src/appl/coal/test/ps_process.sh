#!/bin/sh
ps -ef | egrep '(Main|Edit)' | coal -s ps_tree akProm - $1
