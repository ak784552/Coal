//
proc main;
	x = to_bulk('12345');
	SQL "" "" "select * from ERROR where col=$x";
//	SQL "" "" "select * from dual";
	print ERROR ERRMSG;
	return ERROR;
end proc;
