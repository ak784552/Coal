//
proc main;
	a=2;
	b=2;
	c=3;
	d=4;
	e=5;
//	x1 = a ? b : c;
//	x2 = a+1 ? b+2 : c+3;
//	x3 = a ? b ? 'A' : 'B' : 'C';
//	print x1 x2 x3;
/*
	if ((a-1) ? (b+2) ? (d+4) : (e+5): (c+3)) then
//	if a ? b : c then
		print b+2;
	else
		print c+3;
	endif;
*/
	print NULL?a:c;
	print iif(NULL,a,c);

	return ERROR;
end proc;
