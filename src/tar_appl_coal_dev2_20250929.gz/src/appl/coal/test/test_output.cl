//
PROC main;
	$a = '1234567890';
//	$a = '';
	output tn $a substr($a,1) substr($a,1,5) substr($a,3,5);
	output tn $a left($a,3) left($a,0) left('',3);
	output tn $a right($a,3) right($a,0) right('',3);
	$r1 = right($a,3);
	$r2 = right($a,0);
	$r3 = right('',3);
	output tn $r1 $r2 $r3;
	output tn strings('Aa',10) strings('Aa',0) strings('',10);
	$1 = $a substr '1,3';
	print $1;
	//;
	RETURN $ERROR;
END PROC;
