//
define type struct z
	int a,b
;
define array aa 10;
proc main;
	var x0 x1 x2 as z;
	var y0 y1 y2 as z;
	print x0;
	aa[0] = x0;
	aa[1] = x1;
	aa[2] = x2;
	x0.b = y0;
	y0.a = 100;
	print aa[0];
	print aa[0].b;
	print aa[0].b.a;
	print *aa;
	aa[0].b.a = 200;
	print y0.a;
	return ERROR;
end proc;
