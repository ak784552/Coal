//
#=include common.ch
proc main;
	text = 'aaaaa2222AAAAAAAxxYYyzZz����%��ppppppAA  ';
	w = 123;
	print text w skip_opt(text,w);
	w = 'yy';
	print skip_opt(text,'a');
	print skip_opt(text,'');
	print "text skip_opt 'a2'";
	print skip_opt(text,'%',0x08);
	print skip_opt(text,'��',0x08);
	print skip_opt(text,'yz',0x08);
	print skip_opt(text,'aA',0x02|0x08);
	print SkipiTo(text,'yz');

	return ERROR;
end proc;
