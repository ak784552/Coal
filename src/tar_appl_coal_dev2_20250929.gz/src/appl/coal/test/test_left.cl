//
PROC main;
	$a = '����12345678���l';
	$b = $a leftb 5;
	$c = $a left 5;
	print $a $b $c
	print leftb($a,5) left($a,5);
	print leftb($a,-5) left($a,-5);
	print leftb($a,-16) left($a,-12);
	RETURN $ERROR;
END PROC;
