//
//define global $a;
//define array $w 10;
import test_import;
import test_ip;
proc main;
	print func1(0);
//	exec ip proc1;
	$proc = 'proc1';
	call $proc;
	return $ERROR;
end proc;

function func1 (aa);
	print 'func1: called';
	local $a = 10 &+ func2($aa);
	print func2;
	return $a;
end func;

function func2 (aa);
	local $a = '1010' + $aa;
//	SQL "" "" 3;
//	exec ip proc1;
	call proc1;
	print 'func2: ret proc1';
	return $a;
end func;

proc proc1;
	print 'proc1';
//	SQL "" "" 3;
	return ERROR;
end proc;

proc proc2;
	print 'proc2';
	exec sc test_LET;
//	SQL "" "" 3;
	return ERROR;
end proc;
