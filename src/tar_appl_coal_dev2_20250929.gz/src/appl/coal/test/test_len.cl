//
define array $a 10;
PROC main;
	$1 = %1 is %2;
	print %1 ' is ' %2 ' = ' $1;
	$2 = '��x�c�v';
	print $2 is($2,'L');
	print leng($2) lenb($2);
	print leng($a) lenb($a) a;
	$b = to_bulk('12345');
	print leng($b) lenb($b) b;
	$c = list(123);
	print leng($c) lenb($c) c;
	$d = 123.45;
	print leng($d) lenb($d) d;
	$e = 123.45d;
	print leng($e) lenb($e) e;
	print leng(abs) lenb(abs) abs;
	print leng(f) lenb(f) f;
	print leng(Cclass) lenb(Cclass) Cclass;
	x = new Cclass();
	print leng(x) lenb(x) x;
	print leng(pp) lenb(pp) pp;
	VARI v;
	print leng(v) lenb(v) v;
	RETURN $ERROR;
END PROC;

func f();
end func;

class Cclass;
end class;

proc pp();
end proc;
