//
define array $b 10 = ['X','Y','Z'];
define array $c[-3..3] = [100,110,120];
define mappedarray %ma[2,5..9];
proc main;
	$1 = 2;
	$(2) = 'A';
	print *$();
	print "%1 = 1";
	print "#1 = 1";

	print $$1;
	$a = 2;
	print $$a;

	$1 = 'AA';
	b[1] = 1;
	$$b[1] = 0;
//	$$x[1] = 0;
	$b[1] = 2;
//	$2 = 10;
	print $$b[1];

	$i = 1;
	$1 = FF('abs');
	print $$i(-2);

	print %$i;
	$i++;
	print %$i;
	i=1;
	loop %0;
		$$i = %$i;
		print %$i;
//		$i++;
		print $($i++);
	end loop;

//	for each x in %,$;
//	for each x in %(), $();
//	for each x in *%(), *$();
	for each x in *%()+*$();
//	for each x in *$();
		print *x;
	end for;

	print %ma *%ma;
	print b *b;
	print c *c;
	x = *%();
	print x *x;
	xc = *c;
	print xc *xc xc[-2];
	xm = *%ma;
	print xm *xm xm[6];
	return ERROR;
end proc;
