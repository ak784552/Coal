//
proc main;
	x=10;
	private x=30;
	print x "private x";
	undefine x;
	print x;
	return ERROR;
end proc;
