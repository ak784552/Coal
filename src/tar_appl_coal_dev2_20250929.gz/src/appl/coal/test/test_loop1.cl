//
proc main;
	i = 0;
	loop;
		print 'loop1 i=' i;
		if i == 1;
			print 'continue';
			i++;
			continue;
		elseif i == 10;
			break;
		end if;
		i++;
	end loop;
	return ERROR;
end proc;
