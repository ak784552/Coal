//
proc main;
	if %1 thenl print %1;

	if %1=='1' then print 'then' %1;
	elsel print 'else' %1;

	if %1=='1' then print 'then' %1;
	elseif %1=='2' then print 'elseif then' %1;
	elsel print 'else' %1;
/*
	if %1 thenl
		if %2 then
			print %1 %2;
		elseif %3 thenl
			print %3;
		else
			print %4;

	if %1 thenl
		else
			if %2 then
				if %3 thenl
					print %3;
				else
					print %3;
			else
				print %4;
*/
	if %1 then do
		print %1;
		end do;
	end if;
	return $ERROR;
end proc;
