//
define array $a 10;
proc main;
	$a[1] = 100;
	$a[2] = ff('ABS');
	$x = LIST(1,2,3,4,5,LIST('AAA'));
	exec sc 'test_'&+'scparm2' $a ff('max') "  " $x;
	exec sc 'test_scparm2' a ff('max');// %* #*;
	print $a[0];
	return ERROR;
end proc;
