//
proc main;
//	bu = '123';
//	bu;
//	dec wt = 32.5;
	print bu wt;
	return $ERROR;
end proc;

func ff();
	dec wt = 12.7;
	bu = 'ABC';
	return 0;
end func;
