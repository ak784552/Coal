//
//define nn = 2;
proc main;
if 0 then
	option 16 (CINT)%2;
	n=%1+1;
	x=%1+1;
	while (--n > 1) do;
		x*=n;
		if ERROR then option 16 %2&~(0x02|0x08); endif;
//		n = n - 1;
	end do;
	echo x;
elseif 1 then
	echo fpower(%1+0);
else
	array a 2;
	exec ip fpower %1+0 a;
	echo a[0];
endif;
	return $ERROR;
end proc;

function fpower (n);
//	print 'Enter' n;
	if (n > 1);
		m = fpower(n-1);
		print n m;
		n *= m;
	end if;
//	print 'Return' n;
	return n;
end func;

proc fpower (n,a);
//	echo 'Enter' n;
	if (n >= 1);
		exec ip fpower n-1 a;
//		echo a[0];
		n *= a[0];
	else;
		n = 1;
	end if;
//	echo 'Return' n;
	a[0] = n;
	return ERROR;
end proc;
