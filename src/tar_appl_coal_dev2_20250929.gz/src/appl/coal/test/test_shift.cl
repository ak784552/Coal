//
proc main;
	print %0 %1 %2 %3 %4;
	private x = 1;
	print func1(%1,%2,%3,%4);
	exec ip sub1 %*;
	loop 3;
		print %0 %1;
		let shift;
	end loop;
	print argc x;
	return ERROR;
end proc;

proc sub1 argc argv;
	print argc %argv[0] %argv[1] %argv[2] %argv[3];
	loop 3;
		print argc %argv[0];
		let shift local;
	end loop;
//	argc = 0;
	x = %argv;
	return ERROR;
end proc;

func func1 argc argv;
	print argc %argv[0] %argv[1] %argv[2] %argv[3];
	loop 3;
		print argc %argv[0];
		let shift local;
	end loop;
//	argc = 0;
	x = %argv;
	return ERROR;
end func;
