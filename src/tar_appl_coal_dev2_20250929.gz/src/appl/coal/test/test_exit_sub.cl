//
proc main;
	exec ip 'sub1';
	return $ERROR;
end proc;

proc sub1;
	loop 2;
		exec ip 'sub2';
		if (ERROR); break; endif;
	end loop;
	return $ERROR;
end proc;

proc sub2;
	$1 = %1 + 0;
	if ($1 == 0);
		let exit;
	elseif ($1 == 1);
		let exit %2;
	elseif ($1 == 2);
		exit();
	elseif ($1 == 3);
		exit(%2);
	elseif ($1 == 4);
		$r = $(exit());
	elseif ($1 == 5);
		$r = exit(%2);
	end if;
	return $ERROR;
end proc;
