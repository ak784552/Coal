//
//define array a hash[10];
define a hash[10];
#*if 0
PROC main;
//	option 1 1;
	a['ABCD'] = 100;
	print a['ABCD'];
	if !(i=a['ABC']) then
		print i;
	end if;
	RETURN $ERROR;
END PROC;
#*else
define global array a hash 10;
define array b hash 100;
PROC main;
	a['ABCD','XYZ',,,1] = 100;
	a['AB,CD','XY,Z',1] = 200;
	a['AB`CD','XY``Z',1] = 300;
//	$1 = a['ABCD',1];
	print a['ABCD','XYZ',,,1];
	loop each x in a;
		print x.Value x.Index;
		print a[x.Index];
	end loop;
#*if 0
	a[1] = 200;
	print a[1];
	$i = 0;
	loop 100;
		b[$i] = $i;
		$i++;
	end loop;
	$i = 0;
	loop 100;
		print b[$i];
		$i++;
	end loop;
#*endif
	RETURN $ERROR;
END PROC;
#*endif
