//
PROC main;
	$a = '1234567890';
	print $a;
	print substr($a,'f');
	print substr($a,to_bulk(1));
	print substr($a,1,to_bulk(1));
	print substr($a,4.0f,5.0f);
	print left($a,'A') left($a,to_bulk(1));
	print right($a,1.0) right(a,3.0f);
	print strings('Aa',10.0) strings('Aa',10.0f);
	print strings('Aa','X') strings('Aa',to_bulk(1));
	RETURN $ERROR;
END PROC;
