//
PROC main;
	$65536 = 1;
//	$65537 = 2;
	print $65536 $65537;
	RETURN $ERROR;
END PROC;
