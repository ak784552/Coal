//
define array $a 10;
//define array char(10) $a 10;
//define array BIN $a 10;
define array $ah hash 10;
proc main;
//	let option 5 1;

	$1 = LIST(1, 2, 3, 'A', 's', $a);
//	$1 = LIST($a);
	print $1;
//	print $1[5];
//	print a;
//	print y=a y[0];
//	x=list_ref($1);
	x = a;
	undefine $a;
	print a x x[0];
	print $1;
//	print x[0] ;
//	undefine $1;
//	print $1;

	$ah['A']=10;
	print $ah['A'];
	undefine $ah;
	print $ah['A'];

	return ERROR;
end proc;
