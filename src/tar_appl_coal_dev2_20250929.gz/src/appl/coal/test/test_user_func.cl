//
//import test_import;
//define global $a;
define array $w 10;
proc main;
//	$1 = func1(2) &+ func2(0);
//	$2 = func1(10) &+ func2(20);
//	$1 = proc1();
//	print $1 $func $func2;
	print func1(0);
//	exec ip func2 100;
	return $ERROR;
end proc;

//proc func1 argc argv (aa, bb cc);
function func1 (aa);
	print 'func: called';
//	SQL "" "" 3;
//	local $a = 10 &+ func2($aa);
	$a = 10 &+ func2($aa);
	print $func2;
	return $a;
end func;

//function (aa);
function func2 (aa);
//function 123456789012345678901234567890123 (aa);
//	local $a = 'TEST' &+ $aa;
//	local $a = 'TEST' + $aa;
	local $a = '1010' + $aa;
//	SQL "" "" 3;
//	sleep 1;
	exec ip proc1;
	print 'func2: ret proc1';
/*
	$w[1]='WWWW';
	$w[2]=abs;
	exec sc test_scparm2 $w max;
	print 'func2: ret test_scparm2';
*/
	return $a;
end func;

proc proc1;
	print "proc1";
	exec sc test_LET 1 2 3 4 5 6 7 8;
//	SQL "" "" 3;
	sleep 1;
	return ERROR;
end proc;
