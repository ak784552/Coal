//
//define option 1 2;
//option 1 2;
//option 1 '2.5.1';
option 2 4;
define array $a 10;
def h hash;
def b;
PROC main;
//	print 1.2.2.2;
//	option 4 1.2.3;
	print '*** no set option';
	print $a[0] $1 $x;

	print '*** option 1 1';
	option 1 1;
	print $a[0] $1 $x;

	print '*** option 1 2';
	option 1 2;
	print $a[0] $1 $x;

	print '*** undef a';
	undef a;
	print $a[0] $1 $x;

	undef a x;
	print '*** undef a x';
	print '*** option 1 0x12';
	option 1 0x12;
	print $a[0] $1 $x;

	print '*** option 1 0x0';
	option 1 0x0;
	print b;
	print ndef('b',,1);
	print c;
	print ndef('c',,1);
	print h['A'];
	h['A'] = 1;
	print ndef('h[''A'']',,1);
	print '*** option 1 0x4';
	option 1 0x4;
	print h['B'];
	print ndef('h[''B'']',,1);

	RETURN $ERROR;
END PROC;
