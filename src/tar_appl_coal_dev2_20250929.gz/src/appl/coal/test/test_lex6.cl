//
define a[10]='2','123','456','765';
proc main;
/*
	s = a[0];
//	s &= ',' & a[1] & ',' & a[2] &+ ',' &+ a[1]+a[2];
	s &= ',' & a[1] &+ ',';
	print s;
	print "a[0] is 'N'";
	print "a[0] is(123,'N')";
*/
	print "0 is 'N'";
	print "0 is(123,'N')";

	z = substr('ABCDEFG',3,2) to 'Z';
	print z;
	x = 0;
//	x putline('A',10);
	return ERROR;
end proc;
