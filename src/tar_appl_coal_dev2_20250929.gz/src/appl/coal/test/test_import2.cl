//
import 'test_user_func' -use_main;
import (%1);
import test_ip;
import test_import;
//define array $w 10;
PROC main;
	print func1(0);
	exec ip proc1;
//	print func2(1);
	RETURN $ERROR;
END PROC;
