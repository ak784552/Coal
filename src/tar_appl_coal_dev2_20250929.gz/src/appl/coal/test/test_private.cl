//
define private gg = 'AA';
//define array a 10;
proc main;
//	option 10 1;
	exec ip sub1;
//	print $a;
	print $a $la $ga $lb $gb gg;
	return ERROR;
end proc;

proc sub1;
private	$a = 1;
//local	$gg = 'BB';
private $gg = 10;
array $gg 10;
	local $la = $a + 2;
	global $ga = $a + 3;
	local $lb = $la + $ga;
	global $gb = $la + $ga;
	gg[0] = 100;
	print $a $la $ga $lb $gb $gg;
	return ERROR;
end proc;
