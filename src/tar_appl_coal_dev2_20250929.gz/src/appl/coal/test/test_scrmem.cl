//
proc main;
	exec sm ' {
proc main;\n
 print pr ''XXXXXX'' %1;\n
// $1;\n
 return 0;\n
 end proc;} 
' 'ABC';
//	exec sc yyyy\@test_scproc;
	exec sc yyyy\@'{proc yyyy; print PROCNAME %1; return 0; end proc;}' 'ABC';
	return $ERROR;
end proc;
