//
define global gg = 'AA';
proc main;
	$1 = 3;
	print sub(123) a;
	$1 = 1;
	print sub(234) a;
	return ERROR;
end proc;

func sub(x);
	private	char($1) a = x;
	return ERROR;
end func;
