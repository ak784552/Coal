//
proc main;
	print MAX_LOOP_WHILE;
	MAX_LOOP_WHILE = 10;
	print MAX_LOOP_WHILE /i MAX_LOOP_WHILE;
	$i = 0;
//	loop 2;
//	loop while( $i < 20);
//	while( 1);
	until( 0);
		print 'loop1' $i;
		$i++;
	end until;
//	end while;
	return $ERROR;
end proc;
