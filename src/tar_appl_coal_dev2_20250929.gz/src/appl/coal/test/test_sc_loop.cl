//
define global $count=0;
define global $val=0;
PROC main;
	print ++$count;
//	$val += %1;
	if $count<2;
		exec sc test_sc_loop;
	end if;
	RETURN $ERROR;
END PROC;
