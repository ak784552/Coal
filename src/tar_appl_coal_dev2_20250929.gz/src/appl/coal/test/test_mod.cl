//
proc main;
	print "10 mod 3";
	return $ERROR;
end proc;
