//
define array w 10;
proc main;
	setarray(w,0,1,2,3,4,5,6,7,8,9,10);
//	loop for (i=0;i<3;i++);
//		print func1(w[i]);
//	end loop;
//	print func1(w[0]);
//	print func1(w[1],11);
	print func1(10,12,102);
	print func1('','10+2',30.3456);
	return $ERROR;
end proc;

//function func1;
//function func1();
//function func1(aa,bb,cc);
//function func1 argc argv;
//function func1 argc argv as char xx;
function func1 argc argv (const char aa, dec(10,2) bb,const cc as dec(10,3))as char;
	print /i aa bb cc;
	print aa bb cc;
	print $argc;
	for each x in %argv do
		print *x;
	next;
	return aa + bb;
end func;

