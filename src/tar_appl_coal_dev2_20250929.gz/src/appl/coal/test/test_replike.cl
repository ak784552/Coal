//
proc main;
//	option 18 4;
	$x = '12345123456ABCDEabcdef67890';
	putline(replike($x,'ABC','WXYZ','g'));		//[%ABC%]
	putline(replike($x,'ABC','WXYZ','iG'));		//[%ABC%]
	putline(replike($x,'ABC%de','WXYZ','g'));	//[%ABC%de%]
	putline(replike($x,'ABC%de','WXYZ','Ig'));	//[%ABC%de%]
	putline(replike($x,'^1234','WXYZ','g'));	//iTOP=1 iBTM=0 patlen=5 pat=[1234%]
	putline(replike($x,'^','WXYZ','g'));		//iTOP=1 iBTM=0 patlen=0 pat=[]  �擪�̂�
	putline(replike($x,'7890$','WXYZ','g'));	//iTOP=0 iBTM=1 patlen=5 pat=[%7890]
	putline(replike($x,'$','WXYZ','g'));		//iTOP=0 iBTM=1 patlen=0 pat=[]�@�����̂�
	putline(replike($x,'^%$','WXYZ','g'));		//iTOP=1 iBTM=1 patlen=1 pat=[%]�@�S��
	putline(replike($x,'^$','WXYZ','g'));		//iTOP=1 iBTM=1 patlen=0 pat=[]�@�擪�Ɩ����̂�
	putline(replike($x,'^%','WXYZ','g'));		//iTOP=1 iBTM=0 patlen=1 pat=[%]�@�S��
	putline(replike($x,'%','WXYZ',''));			//iTOP=0 iBTM=0 patlen=1 pat=[%]�@�S��
	putline(replike($x,'','WXYZ','g'));			//��v���Ȃ�
	putline(replike($x,12,'ABC','WXYZ','g'));	//[%ABC%]
	putline(replike($x,12,2,'ABC','WXYZ','g'));	//[%ABC%]
	putline(replike($x,13..20,'ABC','WXYZ','ig'));	//[%ABC%]
	return ERROR;
end proc;
