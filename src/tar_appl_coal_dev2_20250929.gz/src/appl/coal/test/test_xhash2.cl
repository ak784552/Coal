//
define array $a 10;
PROC main;
	$xhp = XHash('New',4,10,0,1);
	$i = XHash($xhp,'S','ABCD','X123');
//	$i = XHash($xhp,'S','ABC',100);
	$i = XHash($xhp,'S',10,100);
	$j = XHash($xhp,'R','ABCD',1);
	print $xhp $i $j $1;
	$j = XHash($xhp,'R',10,2);
	$j = XHash($xhp,'R',10,$a);
	print $xhp $i $j $1 $2 $a[0];
	$j = XHash($xhp,'Free');
	RETURN $ERROR;
END PROC;
