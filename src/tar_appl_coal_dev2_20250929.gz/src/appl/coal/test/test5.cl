//
//define array a[10];
proc main;
//	print a[0];
//	x = 'A';
//	print x;
	dec(10,2) d0 = 0.0;
	dec(10,2) d1 = 1.0;
	dec(10,2) d2 = 2.0;
	print d0 d1 d0+d1 d0-d1 d0*d1 d0/d1 d1/d2;
	print d0 d1 d1+d0 d1-d0 d1*d0 d1/d0;
	return ERROR;
end proc;
