//
function mojisu (s);
/*
	n = 0;
	while str do
		str = substrb(str,(s is 'M')+1);
		n++;
	end do;
	return n;
*/
	return leng(s);
end function;
