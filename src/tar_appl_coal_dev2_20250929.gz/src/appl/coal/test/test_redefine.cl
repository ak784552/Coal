//
define type struct z
	int a 5 3 2
	,char(5) b
	, dec(10,2) c 10,
	bulk(65536) d
	,double e hash
	, variant f
;
define var a as z;
define var y as DEC(5,2);
define array bulk(10) x 10;
define bulk(20) bb;
proc main;
	print z;
	print a;
	x[0] = '01234567890';
	print x[0];
	redefine bulk(20) x 10 = ['X012345678901234567890',123];
	print x[0];
	redefine int a.a 10 = ['012345678901.','-12345678901.','012345678901','-012345678901','0x123456789','-0x123456789'];
	print a.a a.a[0] a.a[1] a.a[2] a.a[3] a.a[4] a.a[5];
	a.d = 'a.d012345678901234567890123456789';
	print a.d;
	bb = 'bb012345678901234567890123456789';
	print bb;
	redefine bulk(10) bb;
	print bb;
	return ERROR;
end proc;
