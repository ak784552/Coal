//
proc main;
	try;
		loop;
			line = f();
			print line;
		end loop;
	catch FILE_READ_END_EXCEPTION;
		print /x FILE_READ_END_EXCEPTION;
		print ERRMSG;
	catch ;
		print ERRMSG;
	finally;
		print 'Finally';
	end try;
	return ERROR;
end proc;

func f();
	return getline();
end func;
