//
define dec(10,5) d;
define dec(10,-2) dd;
proc main;
	d=0;
	dd=0;
	print d dd;
	d=123.456789;
	dd=123.456;
	print d dd;
	d=100;
	dd=100;
	print d dd;
	return ERROR;
end proc;
