//
proc main;
//	$a = '1 ,2, 3 , 4 ''5 6''';
//	$a = '|2| 3 , 4 ''5 6''';
	$a = 'asd:=,123 rr,sss:=ggg';
	print $a;
//	$n = getargs($a,1,,,'|');
	$n = getargs($a,1);
	print $n;
	$i = 1;
	loop $n;
		print $i $$i;
		$i++;
	end loop;
	return $ERROR;
end proc;
