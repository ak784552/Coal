//
def const char sep = ' \t,;()[]{}<>=''\"!^*/~';
define sspl[7];
proc main;
//	a = '  1 ,2, (3) , 4 ''5 6'' =X';
	a = '  1 ,�Q~��, (3) , 4  ''\\'''' 5 �Ӂ@�F6''7 ABC''DE';
	print a;
	i = 0;
	sspl[0] = 1;
if %1 then
	while (n=getword(a,sspl)) >= 0 do;
		i++;
		print i n *sspl;
	end do;
else
	$1 = 1;
//	while (n=getword(a,1,' ,',1,1000)) >= 0 do;
//	while (n=getword(a,1)) >= 0 do;
//	while (n=getword(a,1,sep,0x81)) >= 0 do;
//	while (n=getword(a,1,sep,0x1081)) >= 0 do;
	while (n=getword(a,1,sep,0x1001)) >= 0 do;
		i++;
		print i n *$();
	end do;
endif;
	print n;
	print $() sspl;
/*
	$1 = 1;
//	a = '''\\''''';
	a = getline();
	print a;
	while (n=getword(a,1,sep,0x81)) >= 0;
		print n *$();
	end while;
*/
	return ERROR;
end proc;
