//
define array x 10 = [1,2,3,4];
proc main;
//	array x 10 = 5,6,7,8,9;
	z = LIST(10,20,30,40,50,LIST('AAA','BBB'));
	print chr(is(z,'I'));
	print x[0];
	exec ip func1 x z %* %*;
	print z *x;
	return ERROR;
end proc;

proc func1 argc argv (px, pz);
//	const a;
	for each a in px;
		print *a;
	next;
	for each a in pz;
		if chr(is(a.Value,'I'))=='L';
			for each aa in a.Value;
				print *aa;
			next;
		else;
			print *a;
		end if;
	next;
/*
	for each %1 in %argv;
		print %1;
	next;
	for each x[9] in %argv;
		print x[9];
	next;
	for each c.a in %argv;
		print c.a;
	next;
*/
	return ERROR;
end proc;
