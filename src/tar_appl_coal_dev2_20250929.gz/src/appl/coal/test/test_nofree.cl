//
proc main;
	i=0;
	loop %2+0;
		i++;
		fputline(STDOUT,'***1: i=',i,' nofree no=',Nofree(0));
		exec sc %1;
		fputline(STDOUT,'***2: i=',i,' nofree no=',Nofree(0));
	end loop;
	return $ERROR;
end proc;
