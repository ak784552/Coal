//
proc main;
	$x = '0123456789';
	print a=to_bulk($x,,,0);
	print to_bulk($x,,,1);
	print to_bulks(to_bulk($x,),to_bulk($x,,,1));
	print to_bulk(1,,,0);
	print to_bulk(1,,,1);
	print to_bulk(1.0,,,0);
	print to_bulk(1.0,,,1);

	print a;

	return ERROR;
end proc;
