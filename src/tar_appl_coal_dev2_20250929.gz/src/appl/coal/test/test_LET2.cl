//
proc main;
/*
	$1 = max(1, 2, 3);
	$1 = max(1, $2=2, $3=3);
//	bexp "%1,%2,$1" = 10;
	"%1,%2,$1" = 10;
//	bexp "($1 = %1)++" = 10;
	"($1 = %1)++" = 10;
	print $1 $2 $3;
	$1 = ($2 = 1) + $2;
	++$3 = 300;
	print $1 $2 $3;
//	$2 = $1;
//	$1 ='';
	$1 = 4, $2 = 2;
	print $1 $2;
//	$1 = aaa;
	print $1(1);
//	print =;
//	$1 =;
//	$1 = 1 +;
//	$1 = aaa(1);
	$x = 1;
//	$x = $1, 5;
//	$x = *($1, 5);
	$y = 2;
//	$x, $y = 10;
	$x + $y = 10;
	print $x $y $1;
	$w = $z = 20;
	print $w $z;
//	1 + 2 = 3;
	print ++$w $z++;

	print $1 $2 $3;
	($1,$2,$3) = 200;
	print $1 $2 $3;

	print (1,2,3);
	(a1,b2,c3) = 'A';
	print a1 b2 c3;
	print (a1,b2,c3);
*/
	print {x};
	[a1,[b1,b2,b3],a2] = 'B';
	print a1 b1 b2 b3 a2;
	print [a1,[b1,b2,b3],a2];
	print [1,[2,3,4],5];
//	print (1,(2,3),4);
	print [x];
//	{a1,a2,a3} = 'C';
//	print {a1,a2,a3};
//	(1,3) = 2;
//	1 + 2 = 3;
	return ERROR;
end proc;
