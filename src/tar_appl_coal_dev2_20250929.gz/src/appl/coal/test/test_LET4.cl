//
proc main;
	local $nameX=1;
	global $nameX=2;
	$nameX=3;
	$('nameX')=1;
	local $('nameX')=2;
	global $('nameX')=3;
	exec ip sub1;
	print $nameX;
/*
	$line = 'ABC';
	loop for ($i=1;$c=substr($line,$i,1);$i++);
		print $i $c;
	end loop;
*/
	$1 = abs;
	print /d $1;
	print $1(-1);
	return ERROR;
end proc;

proc sub1;
//	$('nameX')=3;
	local char(3) $('nameX')=1;
	global $('nameX')=3;
//	local $nameX=1;
//	$nameX=3;
//	global $nameX=2;
	print $nameX 1 'A' "1+2+abs(1)";
	echo $nameX 1 'A' "1+2+abs(1)";
	say  $nameX 1 'A' "1+2+abs(1)";
	return ERROR;
end proc;
