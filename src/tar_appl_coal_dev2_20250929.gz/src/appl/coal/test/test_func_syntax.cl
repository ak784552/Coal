//
proc main;
	count=0;
	++count;
	count++
	putline('XYZ');
	print count n;
	return ERROR;
end proc;
