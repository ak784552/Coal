//
proc main;
	print "100 % 13";
	return ERROR;
end proc;
