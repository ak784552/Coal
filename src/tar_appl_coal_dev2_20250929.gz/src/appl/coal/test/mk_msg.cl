//
define int msgno=502;
define int fp = 0;
define int fpi = 0;
define int fpo = 0;
define int dp = 0;
proc main;
	try;
		fp = fopen('msg.c','w');
		dir = %1;
print dir;
		dp = opendir(dir);
		while file=readdir(dp) do
print file;
			if right(file,2)=='.c' then
				try;
					fpi = fopen(dir & '/' & file);
					fpo = fopen('../new/' & file,'w');
					loop do;
						fputline(fpo,errout_proc(fgetline(fpi)));
					end do;
				catch FILE_READ_END_EXCEPTION;
				catch ;
					print ERRMSG;
				end try;
				if (fpi) thenl fclose(fpi);
				if (fpo) thenl fclose(fpo);
			end if;
		end do;
	catch FILE_READ_END_EXCEPTION;
	catch ;
		print ERRMSG;
	end try;
	if (fp) thenl fclose(fp);
	if (dp) thenl closedir(dp);
	RETURN ERROR;
end proc;

func errout_proc(line);
	if !(i0=instr(line,'ERROROUT')) thenl return line;
	s = substr(line,i0+8);
	i = instr(s,'("');
	s1 = substr(s,i+1);
	j = instr(s1,1,'"');
	s2 = substr(s1,j+2);
//	k = instr(s2,');');
//	if !i || !j || !k thenl return line;
	if !i || !j thenl return line;
	format = substr(s1,1,j+1);
	ii = 1;
	loop j do
		if (substr(format,ii,1) is 'M')>1 thenl break;
		ii++;
	end do;
	if ii > j thenl return line;
	ss = substr(line,1,i0+7+i) & 'FORMAT(' &+ msgno &+ ')' & s2;
	mk_msg(msgno++,format);
	return ss;
end func;

func mk_msg(no,format);
	fputline(fp,',{',no);
	fputline(fp,',',format);
	fputline(fp,',""}');
	return 0;
end func;
