//
proc main;
//	count=0;
	$1 = %1 ? 'T'&+'0' : 'F';
//	print %1 $1;
	$2 = %1+0 ? 1 : 0;
	$3 = %1+0 ? 1+2 : 2*0;
	$4 = %1 ? %2 ? 'A' : 'B' : 'C';
	print %1 $1 $2 $3 $4;

	y = x = %1 ? (a=%2) : (b=%3);
	print x y;
	return ERROR;
end proc;
