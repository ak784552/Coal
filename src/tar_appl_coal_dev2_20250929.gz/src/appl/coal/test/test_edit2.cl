//
PROC main;
	$a = '2000/04/20';
	$b = to_bulks($a);
	print edit('%s',$b);
	print edit('%r',$b);
	print edit('%r %r',1234,12345U);
	print edit('%r %r',1.0e-5,1.0e-1);
	RETURN $ERROR;
END PROC;
