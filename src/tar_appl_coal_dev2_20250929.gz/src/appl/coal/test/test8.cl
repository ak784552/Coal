//
import lib_math;
//import class_math;
#=include class_math
proc main;
#=ifdef NEW
	a = new Math;
	print a.PI_180 a.PI_90;
	print a.sind(30.0);
	print a.cosd(60.0);
	print a.tand(45.0);
//	print a.tan(45.0);
#=else
	print Math.PI_180 Math.PI_90;
	print Math.sind(30.0);
	print Math.cosd(60.0);
	print Math.tand(45.0);
///*	print */Math.tan(45.0);
	print sind(30.0);
#=endif
//	print $PI_180 $D180_PI;
	print fact(%1+0);
	return ERROR;
end proc;
