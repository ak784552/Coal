//
PROC main;
	$1 = %1 is %2;
	print %1 ' is ' %2 ' = ' $1;
	$2 = '��x�c�v';
	$len = is($2,'LB');
	loop while $len>0;
		$m = $2 is 'm';
		print $2 ' is ' 'm' ' = ' $m;
		$c = leftb($2,$m);
		$2 = rightb($2,$len-$m); 
		print $2;
		$len = is($2,'LB');
	end loop;
	RETURN $ERROR;
END PROC;
