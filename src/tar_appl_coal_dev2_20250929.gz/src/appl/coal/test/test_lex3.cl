//
define array x 10;
define array $y 5;
define global g='GLOBAL';
PROC main;
	a = 1;
	print a g;
	x[0]=10;
	y[0]=10;
	print x[0] f() b y[0];
	RETURN $ERROR;
END PROC;

func f;
	private b=100;
	return ERROR;
end func;