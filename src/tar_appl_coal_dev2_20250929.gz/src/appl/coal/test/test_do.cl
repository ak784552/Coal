//
proc main;
	$i = 0;
	do as do1;
		$i++;
		print 'do1 $i=' $i;
		do as do2;
			$i++;
			print 'do2 $i=' $i;
			break %1;
			continue %2;
			$i++;
			print 'do2 $i=' $i;
		end do;
		$i++;
		print 'do1 $i=' $i;
	end do;
	return $ERROR;
end proc;
