//
define int dp=0;
define int fp=0;
proc main;
	dir = %1;
	try(dp = opendir(dir));
		while file=readdir(dp) do
print file;
			if right(file,3)=='log' then
				try
					fp = fopen(dir & '/' & file);
					loop do;
						line = fgetline(fp);
					end do;
				catch FILE_READ_END_EXCEPTION;
				catch;
					print 'in catch' ERRMSG /x EXCEPTION;
//				finally;
				end try;
				if fp then
					fclose(fp);
					fp = 0;
				end if;
			end if;
		end do;
//	catch FILE_READ_END_EXCEPTION;
	catch;
		print 'out catch' ERRMSG /x EXCEPTION;
//	finally;
//		print 'Finally' /x EXCEPTION;
	end try;
	if dp thenl closedir(dp);
	print ERRMSG /x EXCEPTION;
	return ERROR;
end proc;
