//
proc main;
/*
	i = 0;
	loop(3);
		print 'loop1' i;
		i++;
	end loop;
*/
	MAX_LOOP_WHILE = 8;
	3.times(print,1,2,3);
	print times(3);
	i=0;
	print times(3,(FUNC)'{func _salute(name);
	print name&'' World!!'';
	return 0;
end func;}','AAA');
	times(,echo,'X','Y');
	3.times('(i++).echo()');
	return $ERROR;
end proc;
