//
define aa[10]=[3,2,1,4,8,5];
proc main;
	x = 'asdfg';
	print x.leng();
	x.putline();
	(10.).sqrt().putline();
	print "20 sqrt 0";
	print "10. mod 3";
	200.sqrt().print();
	200.sqrt().echo();
	print -10.345E1.cbrt() 'abs'.ff()(-2);
	123.fun();
	print 1.sort(aa) *$();
	return ERROR;
end proc;

func fun(x);
	print x;
	return 0;
end func;
