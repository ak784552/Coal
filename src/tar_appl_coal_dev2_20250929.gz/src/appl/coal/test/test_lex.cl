//
define array aa 10;
PROC main;
/*
/* aaaaaaaaaa */
/* **************** */
//	$a = 'aaa@bb';
	�����@���@�faa�����f�f@''b�f'�G
	print $a;
/*	$x = ddd;
	*/
//	( a[1] );
//	( a(1) );
//	$1 = 1;
//	$1++,$1++;
//	$1=1,$1++;
	loop for ($1=1,i=0;i<5,$1<10;$1++,i++);
//	loop for ($1=1,$1<10,$1++);
//	loop for($1=1) $1<10 $1++;
		print $1 i;
//		break;
	end loop;
	print '(';
	print "(";
	print ')';
	print "')'";
*/

	print {1,2,3,4,5} (1,2,3,4,5);
	print 'abc'..'wxyz';
	a=1;
	print a..3;
	print {12.3..3.0};
	print (2.4..10.0);
	print '----------';
	for each x in 'a'..'d';
		print *x;
	next;
	print '----------';
	z={-3.3..5f};
	print z;

	print '----------';
	for each x in {-3.3..5f};
		print *x;
	next;

	print '----------';
	print abs(-2..3);
	print setarray(aa,0,-2..3);
	print *aa;
	print '----------';
	a = 5..8;
	print a;
	for each x in a;
		print *x;
	next;
	print '----------';
	aa[0] = 1;
	array aa = aa[0..8],5.5..10;
	for each x in aa;
		print *x;
	next;
	RETURN $ERROR;
END PROC;
