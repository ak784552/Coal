//
proc main;
	$fpr = fopen('rrr','r');
	print ERRNO STRERROR EXCEPTION;
	print ERROR ERRMSG;
	return ERROR;
end proc;
