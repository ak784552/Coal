//
proc main;
	$x = '12345$ABC^123$^456';
	$y = '$^';
	print $x replike($x,'\\$','WXYZ','g');
	print $y replike($y,'\$\^','WXYZ','g');
	print $x replike($x,'%$%^%','WXYZ','iG');
	print $x replike($x,'$%','WXYZ','g');
	$y = '$ABC';
	print $y replike($y,'$%','WXYZ','g');
	print $x replike($x,'%^','WXYZ','g');
	$y = 'ABC^';
	print $y replike($y,'%^','WXYZ','g');
	print $x replike($x,'_B_','WXYZ','g'); 
	print $x replike($x,'___','WXYZ','g');
	print replike('abc','ABC','WXYZ','ig');
	return ERROR;
end proc;
