//
//
//
define array col_0 10;
define array col_1 10;
proc main;
	if (%0 < 1);
		fputline(stderr,'usage: ',SCRIPTNAME,' in_file');
		return -1;
	end if;
	try;
		fpi = fopen(%1);
		arrayclr(col_0);
		loop;
			line = fgetline(fpi);
print line;
			n = getargs(line,col_1,10,,',');
			f = 0;
			for (i=3;i<=5;i++) do
				if (col_0[i] != col_1[i]);
					f = 1;
					break;
				end if;
			next;
			if f then
				putline(line);
print *col_0 *col_1;
				arraycpy(col_0,col_1);
//				end loop;
			end if;
		end loop;
	catch FILE_READ_END_EXCEPTION;
	catch;
		print /e ERRMSG;
	finally
		if fpi thenl fclose(fpi);
	end try;
	return ERROR;
end proc;
