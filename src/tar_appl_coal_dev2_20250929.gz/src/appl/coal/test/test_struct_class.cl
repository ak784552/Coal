//
define type struct Greeter
	 variant salute
	,variant name
;
define var g as Greeter;
define var h as Greeter;

func _new (g,name);
	g.name = name;
//	g.salute = _salute;
	g.salute = (FUNC)'{func _salute;
	print My.name&'' World!!'';
	return 0;
end func;}';
	return 0;
end func;
/*
func _salute;
	print My.name&' World!!';
	return 0;
end func;
*/
proc main;
	_new(g,'Hellow');
	g.salute();
	_new(h,'Good night');
	h.salute();
	return ERROR;
end proc;
