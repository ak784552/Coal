//
proc main;
//	option 8 1;
print *%();
//	print ABS(-1.25);
	print abs(%1);
	return $ERROR;
end proc;

function abs(dec a);
print 'user func';
//	if is($a,'T')==$FLOAT;
//		return -1;
//	else if $a<0;
	if $a<0;
		$a = -$a;
//	else;
//		$a = abs($a);
	endif; 
	return $a;
end func;
