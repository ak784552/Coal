//
define type struct aa
	 a;
define var f,g as aa;
PROC main;
	option 8 2;
//	$x = 0;
//	$x = 1 max -2;
//	$x = 1 + +2;

//	$x = 1 mod -2;
//	print $x;
/*
	$max   = (CINT)%2;
	$aho_c = %3;
	$aho_i = (CINT)$aho_c;
print $max $aho_c $aho_i ;
*/
//	g.a = main.func1;
//	f.a = g;
//	print f.a.a();
//	print func1.1;
	exec ip proc1_1;
//	exec sc proc2_2:/tmp/test2.3;
//	x = (CINT)'1';

//	print ff('func1.a')();
	print aaa(1);
	function aaa (x);

		proc bbb;
			print 'Proc bbb';
			return ERROR;
		end proc;

		func bbb;
			print 'Func bbb';
			print x;
			return ERROR;
		end func;

		print 'Func aaa' x;
		print func1_1();
		exec ip bbb;
		print bbb();
		print main.aaa2('A');
		return ERROR;
	end func;

	function aaa2 (x);
		print 'Func aaa2' x;
		return ERROR;
	end func;

//	print aaa(2);

//	$1 = 1 + -ABS(-2);
//	$1 = 1 + (++(ABS(-2)));
//	$1 = 1 + ++ABS(-2);
//	print $1;
//	print '10;
//	x = (3);
//	y = 1 + ++(-x);
//	y = 1 + (-x)++;
//	print y;

	RETURN $ERROR;
END PROC;

func func1_1;
	print 'func1_1';
	RETURN $ERROR;
END func;

proc proc1_1;
	print 'proc1_1';
	RETURN $ERROR;
end proc;
