//
proc main;
	print shell('ls -l');
	return ERROR;
end proc;
