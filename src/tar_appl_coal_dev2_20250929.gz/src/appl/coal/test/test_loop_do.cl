//
proc main;

	i = 0;
	loop (3)do
		print 'loop1' i;
		for (j=0;j<i;j++)as AA;
			print 'for' j;
			if j>3 thenl break AA;
//		end do;
		next;
		print 'loop3';
		i++;
//	end loop;
	end do;
	return $ERROR;
end proc;
