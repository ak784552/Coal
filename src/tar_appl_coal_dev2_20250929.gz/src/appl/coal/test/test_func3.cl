//
proc main;
	print %1;
	print gettime(0);
	loop (CINT)%1;
		func1();
	end loop;
	print gettime(0);
	return $ERROR;
end proc;

func func1;
//	print 'called func';
	1/0;
	return $ERROR;
end func;
