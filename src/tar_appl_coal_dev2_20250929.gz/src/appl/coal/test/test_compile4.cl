//
define const array a 5 = (1,2,3,4,5);
define const array b 3 = (2,4);
proc main;
	c = 1;
	print ---c c -++c c ++-c c;
//	print --(c=a) c;
	print c=a+2 /d c+1;
	print ++1 --3 --abs(-4);
	print -*b /d *(-*b);
//	print +*b;
//	print *a-*b;
	return ERROR;
end proc;
