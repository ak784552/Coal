//
def aa 10;
proc main();
//	print aa;
	a = 'XYZ';
	b = 'XTZ'<==y;
	ba = a<==y;
	baa = aa<==y;
	print b ba baa;

	h = heredoc(12345,'EOF');
	print to_bulk('ABC');
	fp = fopen('w','wt');
	print h;
	exec sc test_putline heredoc(fp,1);
	print h;

	print h b ba baa;
	return ERROR;
end proc;
