//
define array $a 5 4;
define array $ha hash 10;

PROC main;
//	print indexa($a,1,5);
	exec ip aaa;
	option 15 3;
	exec ip aaa;
	RETURN $ERROR;
END PROC;
proc aaa;
	print '***';
	print indexa($a,0,0,0) indexa($a,1,2) indexa($a,4,3) indexa($a,1,5);
	print indexa($ha,'ABCDE');
	$ha['ABCDE'] = 100;
	$a[3,2] = 200;
	print $a[3,2];
	print indexa($ha,'ABCDE');
	RETURN $ERROR;
END PROC;
