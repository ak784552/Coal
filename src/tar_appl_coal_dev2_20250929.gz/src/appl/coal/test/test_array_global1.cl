//
define array global $ab 2 3 4 = 100;
define global array $xx 10;
proc main;
	$ab[0,0,0]++;
	$xx[1] = 10;
	print $ab[0,0,0];
	return $ERROR;
end proc;
