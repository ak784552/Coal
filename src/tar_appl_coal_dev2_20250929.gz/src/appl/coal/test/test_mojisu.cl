//
import func_mojisu;
PROC main;
	print mojisu(%1);
	print mojisu('anc����c�q');
	RETURN $ERROR;
END PROC;
