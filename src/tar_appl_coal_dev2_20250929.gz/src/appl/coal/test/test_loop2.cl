//
proc main;
	$i = 0;
	loop 2;
		$j = 0;
		loop 3;
			sleep 1;
			print $i $j;
		//	return ERROR1;
			$j++;
		end loop;
		$i++;
	end loop;
	return $ERROR;
end proc;
