//
define type struct sss
	int ii,
	char(10) cc,
	hhh[10];

proc main;
	x = new aaa;
	x.a = 10;
	x.b = 'dssa';
	x.aa[5]='1234';
	x.ss.ii = 100;
	x.ss.hhh[3] = 300;
	print x;
	print x.ia x.cb x.a x.b x.aa;
	print x.ss x.ss.ii;
	print *x.aa *x.ss;
	print /d x;

	return ERROR;
end proc;

class aaa;
	int ia;
	char(30) cb;
	local a;
	local b;
	int aa[10];
	dim ss as sss;
end class;
