//
define type struct z
	int a 5 3 2
	,char(5) b
	, dec(10,2) c 10,
	bulk(65536) d
	,double e hash
	, variant f
;
define var a as z;
define var y as DEC(5,2);
define array char(10) ca[10] = ['ABCD',1234567890,''];
define array bulk(10) ba[10] = [12,'XYZ',''];
define array char cax[5] = ['ABCD',1234567890,''];
define array bulk bax[5] = [12,'XYZABCD',''];
proc main;

	print ca *ca /d ca;
	redefine char ca[5];
	print ca *ca /d ca;

	print ba *ba /d ba;
	redefine bulk ba[5];
	print ba *ba /d ba;

	print cax *cax /d cax;
	redefine char(5) cax[8];
	print cax *cax /d cax;

	print bax *bax /d bax;
	redefine bulk(5) bax[8];
	print bax *bax /d bax;

	return ERROR;
end proc;
