//
proc main;
	print comma('-12345678.9');
	print comma('-5678.9');
	print f2();
	print f() f();
//	f();
	return ERROR;
end proc;

func f;
	x = 2;
	y = 'ABCD�d�e'.x;

	print 'ABCD�d�e'.0;
	print 'ABCD�d�e'.1;
	print 'ABCD�d�e'.'3';
	print 'ABCD�d�e'.6;
	print 'ABCD�d�e'.7;
	print substr('ABCD�d�e'.3,2,3);

	return y;
end func;

func f2;
	loop 2;
		x = 2;
		print 'ABCD�d�e'.x;
	end loop;
	return ERROR;
end func;

func comma(s);
	s = s.2;
	pos = 5;
	s = s.pos;
	return s;
end func;
