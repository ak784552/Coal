//
proc main;
	$a = 102;
	loop 2;
		exec ip proc-1;
//	return $ERROR;
//	return 1020;
		print $a;
	end loop;
	return $a;
end proc;

proc proc-1;
	print 'called proc-1';
	loop 3;
		print 'proc-1 loop';
		loop 2;
			print 'proc-1 loop loop';
			return -1;
		end loop;
	end loop;
	return $ERROR;
end proc;
