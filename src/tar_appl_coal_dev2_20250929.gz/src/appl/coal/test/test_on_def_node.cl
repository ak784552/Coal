//
on GR  3 ip procGR-1 ip procGR-2;
define a 5;
on <A> ip proc-1  ip proc-2  ip proc-3;
proc main;
	ff();
	return $ERROR;
end proc;

func ff();
	print a b;
	return 0;
end func;

define b 3;
