//
proc main;
	local la = 0;
//	loop 2;
		local la concat= 1;
//		local la += 1;
//		local la+= 1;
//		local ++la;
//	end loop;
	print la;
	return ERROR;
end proc;
