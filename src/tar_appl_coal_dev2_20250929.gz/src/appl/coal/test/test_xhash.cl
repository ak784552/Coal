//
PROC main;
//	$xhp = XHash('New',-1,10,0);
//	$xhp = XHash('New',6,10,0);
	$xhp = XHash('New',0,10,0);
////	$i = XHash($xhp,'S','ABCDEF',100);
//	$n = 0;
//	$j = XHash($xhp,'R','ABCDEF',$n);
//	print $xhp $i $j $n;

	$i = 101;
	loop 10;
		$loc = XHash($xhp,'S',$i |+ '');
		print 'S' $i $loc;
		$i += 13;
	end loop;
	$i = 101;
	loop 10;
		$loc = XHash($xhp,'R',$i |+ '');
		print 'R' $i $loc;
		$i += 13;
	end loop;

	$j = XHash($xhp,'Free');
	RETURN $ERROR;
END PROC;
