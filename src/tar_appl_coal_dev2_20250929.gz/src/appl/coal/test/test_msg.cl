//
define array $recv 10;
//define mappedarray %recv 1 10;
proc main;
//	message send 'aa2853' 0 1 'TEST test 01234567' 'a' RECV %recv;
	message send 'aa2853' 0 1 'TEST test 01234567' 'a' RECV recv;
//	message send 'localhost' 0 1 'TEST test 01234567' 'a' RECV recv;
//	message send '' 0 65535-8 '-1' '' RECV recv;
//	message sleep 3;
	print ERROR ERRMSG TIME;
//	if ERROR; return ERROR; end if;
	i = 1;
//	loop recv;
	loop recv[0];
		print $recv[i];
		i++;
	end loop;
	return $ERROR;
end proc;
