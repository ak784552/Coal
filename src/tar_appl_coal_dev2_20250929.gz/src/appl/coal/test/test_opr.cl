//
define array $x 10;
proc main;

	$a = 1;
	$a += 2;
	$b = 9;
	$b %= 5;
	$c = 1;
	$c <<= 2;
	$d = 0b10000;
	$d >>= 2;
	$e = -11;
	$e mod= 7;

	$f = 3;

	$f ~= ;
	$g = 0;
	print "$g NOT= 0";
	print "$g = NOT $g";

	$h = 1;
	$h ^= 0;

	$m = -1;
	$m >>>= 1;
	print $a $b $c $d $e $f $g $h $m;

//	h = 2.5;
	h = 1;
	print h ~~h h~~ !!h h!!;
	i = ~h;
	print h i;
	j = 1;
	j!!;
	k = 1 ^ 1;
	print j k;

	$a = 'A';
	$a &+= 'B';
	$b = 'A';
	$b |+= 'B';
	$c = 'X' &+ 'Y';
	$d = 'X' |+ 'Y';
	print $a $b $c $d;

/*
	$x[0] + $[1] = $a;
//	fopen('a','r') = 1;
	$a = mod(3,1) + 10 mod 8;
	$b = !$a;

	$b = !mod(10,4);
	$c = not mod(10,4);
	$d = +mod(10,4);
	$e = -mod(10,4);
	$f = ~mod(10,4);
	$g = -to_number('1',FLOAT);
	print $b $c $d $e $f $g;
	$d = 10 > 9;
	print $x[0] $a $b $c $d;
*/
	a = 1;
	b = 2;
	a + (b = 10);
	print a b;
	return ERROR;
end proc;
