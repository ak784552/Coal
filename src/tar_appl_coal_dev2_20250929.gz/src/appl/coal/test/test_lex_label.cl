//
//LABEL head;
//abc:
proc main;
//LABEL test;
xyz: a = 0;
	return ERROR;
end proc;
