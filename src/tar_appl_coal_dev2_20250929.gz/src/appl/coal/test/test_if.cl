//
define int a[10];
proc main;
	$1 = %1 + 0;
	if ($1 == 1) then
		print 'if' %1;
		sleep 2;
	elseif $1 == a[0]then
		print 'elseif' %1;
//		let continue;
	elseif $1 == 3 then
		print 'elseif' %1;
//		break;
	else
		print 'else';
		sleep 2;
	end if;
	return ERROR;
end proc;
