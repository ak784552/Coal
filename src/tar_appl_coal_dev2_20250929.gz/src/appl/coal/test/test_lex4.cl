//
define type struct z
	int a 
	,char(5) b
	, dec(10,2) c 10,
	bulk(20) d
	,double e hash
	, variant f
	, g
;
define var zz as z;
define array x 10;
define array y 5;
define array hy hash 10;
define global g='GLOBAL';
define mappedarray $ma 101 10;
define mappedarray %mb 2 5;
define mappedarray #mc 1 5;
proc main;
	print ma %mb #mc;
	print ma %mb[0] #mc[0];
	ma[0] = 100;
	ma[2] = 'XYZ';
//	maa = *ma;
	maa = *%mb;
	ma[0] = 200;
	for each dd in ma do
		print dd.Index dd.value;
	next;
	for each dd in maa do
		print dd.Index dd.value;
	next;
//	*x = *y;
	zz.a = 1;
	zz.b = 'AAA';
	zz.c[1] = 12.3;
	a = *zz;
	zz.a = 2;
	zz.b = 'BBB';
	zz.c[1] = 20.5;
	y[0] = 10;
	y[2] = 'ABC';
//	print *a.a *a.c[1] *y[2];
	local b = *y;
	y[0] = 20;
//	c = *zz.b;
	print a.a a.c[1];
	print a b;
	for each dd in y do
		print dd.Index dd.value;
	next;
	for each dd in b do
		print dd.Index dd.value;
	next;
	hy['ABC'] = 10;
	hy['DEF'] = 20;
	for each dd in hy do
		print dd.Index dd.value;
	next;
	b = *hy;
	hy['DEF'] = 30;
	for each dd in b do
		print dd.Index dd.value;
	next;
	return ERROR;
end proc;
