//
define type struct z
	int a
	,char(5) b
	, dec(10,2) c 10
	,bulk(20) d
	,double e hash
	, variant f
	, g
;
define type struct zz
	int a
	,char(5) b
	, dec(10,2) c 10
;
z w[2]=[1,2,3,4,5];
define array a 10;
proc main;
	print *w;

	print a;
/*
//	print fun(5);
//	print *fun(5);
	aa = fun(5);
//	aa = *fun(5);
	print aa *aa;

	x = fun(5);
	print x+1;
*/
//	print fun_s(0);
//	redef private z a;
//	redef private zz y;
//	print *fun_s(0);
	print fun_s(2);
	print *fun_s(3);
//	print fun_s(0);
//	print *fun_s(0);

	return ERROR;
end proc;

func fun(n);
	redef private array x[n]=[1,2,3,4,5];
	print x;
	return x;
end func;

func fun_s(n);
	if n > 0 then
		redef private z y[n] = [5,6,7,8,9,10];
	else
		redef private z y = [10,11,12,13,14,15];
	end if;
	print y;
	return y;
end func;
