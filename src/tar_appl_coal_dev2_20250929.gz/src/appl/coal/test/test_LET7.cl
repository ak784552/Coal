//
define type struct ss
	char s_a,
	int  s_b; 
define array aa[10];
proc main;
//	option 5 1;
/*
	$1=-1;
//	a=${1};
	a = {0}<{1,2};
//	f(,);
	print /d a '';
	print /d {} -{3} -{};
	print {} -{3} -{};

//	lprint {}-{3};
//	print /d aa ss (1,aa) (1,{2,3});
//	dump aa ss (1,aa) (1,{2,3});

	a = 1,2;
	a = [1,2];
	print [1,2,{3,4,[5,6,7],8},9];
	for each x in [1,2,{3,4,[5,6,7],8},9];
		print x.Index x.Value;
	next;
	a = (CCHAR)10;
	print a;
*/
	print [,];
	for each x in [,];
		print x.Index x.Value;
	next;
	print {};
	print [];
/*
	print 1,2;
	print [[1,2],[3,4]];
	a = abs(1+2);
	print a;
	a = 1 + 2 * 3 / 4.;
	print a;
	a = 1 * 2 << 2 + 3 < 0b1000001;
	print a;
	a = 1 * 2 + 3 > 1 + 2 || 4 < 5 + 6 && 0;
	print a;
	a = 1 + 2 * 3 concat 4 / 2 + 5;
	print a;
	a = 3 &+ 4 < '35';
	print a;
	a = (1,2,3,4,5,6);
	print a;
	for each x in a;
		print x.Index x.Value;
	next;
	for each x in 1,2,(3,4);
		print x.Index x.Value;
	next;
	print (1,2,3,4,5,6);
	private array a 10 = (1,2,3,4,5,6);
	print "private a";
	for each x in private a;
		print x.Index x.Value;
	next;
*/
	return ERROR;
end proc;

func f(a);
	print {a};
	print "a+{1,2}";
	return 0;
end func;
