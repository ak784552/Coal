//
proc main;
	print ABC;
	print a=ABC;
	a = concat(ABC,'abc');
	$a = concat(ABC,'abc');
//	$b = fgetline(STDIN);
	print $a;
	return $ERROR;
end proc;
