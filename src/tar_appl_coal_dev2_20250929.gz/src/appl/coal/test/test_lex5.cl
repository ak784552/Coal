//
define b [10] = (1,2,3,(4,(5,6),7,8),9,10);
PROC main;
//	a = {1,(2,{3),4},5};
//	c = [1];
//	c = ERROR[1];
	print a *b;
	RETURN $ERROR;
END PROC;
