//
define array a hash;// 10; 
define array b 10 = [1,2,3,4,5,'A','B','C','D','E'];
define array BIN c 10 = [1,2,3,4,5,6,7,8,9,10];
define mappedarray $m 11 10;
define mappedarray %p 1 10;
define mappedarray #s 1 10;
proc main;

	print '--- each x in a ---';
	loop each x in a;
		print x.Index x.Value count(x);
	end loop;

	print '--- each x in b ---';
	loop each x in b;
		print x.Index x.Value;
	end loop;

	print '--- each x in c ---';
	loop each x in c;
		print x.Index x.Value;
	end loop;

	print arrayclr(b,'',5);
	print arrayclr(c+2,'',4);

	print '--- each x in b ---';
	loop each x in b;
		print x.Index x.Value;
	end loop;

	print '--- each x in c ---';
	loop each x in c;
		print x.Index x.Value;
	end loop;

	return ERROR;
end proc;
