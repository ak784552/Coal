//
proc main;
	loop %0;
		print stat(%1,1,20);
		print *$();
		if $1 == 5 then
			echo 'name=' %1 'size=' $9 'byte.';
		else
			echo 'name=' %1 'is not file.';
		end if;
		shift;
	end loop;
	return $ERROR;
end proc;
