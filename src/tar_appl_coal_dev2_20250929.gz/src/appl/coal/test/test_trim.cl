//
PROC main;
	$a = '  2000�N  04/20 	  ';
	a = str_conv(a,'s-jis');
//	a = str_conv(a,'utf8');
//	a = str_conv(a);
	print $a /i a;

	print trim($a);
	print trim($a,0);
	print trim($a,1);
	print trim($a,2);
	$b = '';
	print $b trim($b) trim($b,0) trim($b,1);
	print replike($a,'[ \t]','','g');
	print trim($a,'0 A\t');
	print '0 A'+1;
	print trim(' 01234.560�~ ',' 0�~');
	print trim(' 01234.560�~ ',,2);

	RETURN $ERROR;
END PROC;
