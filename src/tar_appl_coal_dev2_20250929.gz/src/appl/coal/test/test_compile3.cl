//
define array a 10;
proc main;
//	$1 = 100;
//	$x = 'A';
//	$1 = 1 + 2;
//	$1 = 1;
//	$1 = $1 + $1;
loop 2;
	array aa 10;
private	x = 10;
local	a = x + 1;
//private	const a = 2;
	b = a + 2;
	print b;
endloop;
	return ERROR;
end proc;
