//
proc main;
	$i = 0;
//	loop "";
//	loop '';
	loop 3;
		print 'loop1' $i;
		loop $i do
			print 'loop2 sleep2';
			sleep 2;
//		end loop;
		end do;
		print 'loop3';
		$i++;
//	end;
//	end do;
	end loop;
	return $ERROR;
end proc;
