//
PROC main;
	$say = 'I loVE r����y ��aA,df.fg_ty ';
	echo $say;
	putline($say to 'C');
	putline($say to 'P');
	$say = replike($say,'love','*love*','i');
	putline($say to 'U');
	loop 5 do putline($say);enddo;
	putline($say to 'C');
	putline($say to 'P');
	say $say;
	RETURN $ERROR;
END PROC;
