//
proc main;
	$1 = %1;
	loop 10;
//		print "$1 -= $1/10";
		print $1-=$1/10 'ASDFG';
	end loop;
	return ERROR;
end proc;
