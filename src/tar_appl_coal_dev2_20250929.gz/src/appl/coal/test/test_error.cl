//
proc main;
	exec ip funcp;
	a = funcf();
	print a;
	return $ERROR;
end proc;

proc funcp;
//	1/0;
	return $ERROR;
end proc;

func funcf;
	1/0;
	return 'A';
end func;
