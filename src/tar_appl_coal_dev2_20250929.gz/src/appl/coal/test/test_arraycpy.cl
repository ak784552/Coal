//

define array a hash;// 10; 
define array b 10 = [1,2,3,4,5,'A','B','C','D','E'];
define array BIN c 10 = [1,2,3,4,5,6,7,8,9,10];
define mappedarray $m 11 10;
define mappedarray %p 1 10;
define mappedarray #s 1 10;
define array aa hash;// 10;
define array a3 hash;// 10;
define array d 10;

//define array b 10 = 1;
//define array BIN c 10 = 10;
proc main;
	exec ip sub1 1 2 3 4;

	a['A']='aaa';
	a['B']={'bbb',123};

	loop each x in a;
		print *x;
	end loop;

	loop each x in b;
		print *x;
	end loop;

	loop each x in c;
		print *x;
	end loop;

	print arraycpy($m,b+1,4);
	print arraycpy(%p,b+1,4);
	print arraycpy(#s,b+1,4);
	print arraycpy(a,b+1,4);
	print arraycpy(a,b+2,5);
	print arraycpy(b,a+1,4);
	print arraycpy(b+1,c+2,10);
	print arraycpy(aa,a,1);
	print arraycpy(abs,a,1);
	print arraycpy(aa,abs,1);

	a['A']='bbb';
	loop each x in a;
		print *x;
	end loop;

//	print arraycpy(b,0,c,0,1);
	loop each x in b;
		print *x;
	end loop;

	loop each x in aa;
		print *x;
	end loop;

//	loop each x in c;
//		print *x;
//	end loop;

	a['A']='aaa';
	a['B']=123;
	aa['A']='aaa';
	aa['B']=123;
	print arraycmp(aa,a);
	print arraybxp(a3,aa,a,,'&+');
	loop each x in a3;
		print *x;
	end loop;

	print arraybxp(d,b,c,5,'+');
	loop each x in d;
		print *x;
	end loop;

	c[0]=0;
	print arraycpy(c+1,c);
//	print arrayclr(c,5);
	loop each x in c;
		print *x;
	end loop;

	print arraycpy(z=1,b+1,4);
	print *$();

	return ERROR;
end proc;

proc sub1 argc argv;
//	mappedarray %a 1 5;
	local b = *%argv;
//	arraycpy(b,%argv);
	loop each x in b;
		print *x;
	end loop;
	return ERROR;
end proc;
