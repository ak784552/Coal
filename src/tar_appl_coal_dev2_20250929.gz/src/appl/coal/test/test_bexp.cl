//
proc main;
	BEXP $1 = 1;
	print $1;
	BEXP $2 = 1 + 2;
	print $2 $1+$2;
	BEXP $x = 'a' concat 'b' 'c' 'd' "1+10";
	print $x;
//	BEXP $1++ = ++$2 - 100;
	BEXP ++$1++ = $1 + 10;
	print $1 $2;

	BEXP $1 += 10;
	print $1;

//	BEXP $a concat= 'w' concat 'x' 'y' 'z';
	BEXP $1 concat= 'w' concat 'x' 'y';
	print $1;
/*
	BEXP 1 = 2 + 3;
	BEXP %1 = 2 + 3;
	print %1;
	BEXP #1 = 2 + 3;
	print #1;
*/
	return ERROR;
end proc;
