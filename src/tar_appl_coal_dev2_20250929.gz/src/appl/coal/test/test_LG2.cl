//
define x[10] = [1,2,3,4,5,6,7];
proc main;
//	local xa[20];
	a = '55';
	int a = a + 100;
	print a;
	dec(10,5) b = 12345.6789;
	print b;
	redefine clear dec(5,2) b;
	print b /i b;
	print *x;
	redefine array clear x = [8,9];
	print x *x;
	return ERROR;
end proc;
