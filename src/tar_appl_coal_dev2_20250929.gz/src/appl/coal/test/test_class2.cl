//
Class Greeter;
	variant salute = (FUNC)'{func _salute;
	print My.name&'' World!!'';
	return 0;
end func;}';
	variant name;
//	char name;
	func Greeter(name);
		My.name = name;
//		return 0;
	end func;
end class;

proc main;
	g = new(Greeter,'Hellow');
	print g.name;
	g.salute();
	h = new(Greeter,'Good night');
	print h.name;
	h.salute();
	return ERROR;
end proc;
