//
//proc main;
proc main (a);
	print %0 %1;
	print $a;
	return ERROR;
end proc;

proc proc-1(a);
//proc proc-1;
	print %0 %1;
	print $a;
	return ERROR;
end proc;
