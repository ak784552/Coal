//
define a[10];
define h hash;
proc main;
//	$1 = 10;
//	print $1;
	a[0] = 100;
	print a[0];
//	h['AA'] = 1000;
	print h['AA'];
	return ERROR;
end proc;
