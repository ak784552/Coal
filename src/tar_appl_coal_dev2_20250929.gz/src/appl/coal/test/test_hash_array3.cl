//
define array a hash 10;
PROC main;
	if w=a['X'] then
		print w;
	end if;
	a['A'] = 1;
	a['B'] = 2;
	a['C'] = 3;
	print a['A'] a['B'] a['C'];
	loop each x in a;
		print x.value x.Index;
	end loop;
	RETURN $ERROR;
END PROC;
