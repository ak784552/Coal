//
define type mappedarray ym;
define var %ymv as ym;
proc main;

	type struct z
		int a 5 3 2
		,char(5) b
		, dec(10,2) c 10,
		bulk(20) d
		,double e hash
		, variant f
		, g
	;
	var $x, a, b as z;
	print z x a;

	type array char za 10 7;
	var xa as za = 'X','Y','Z';
	print za xa *xa;

	type mappedarray zm 2 4 6;
	var $zmv as zm;
	var %zmv as zm;
	var #zmv as zm;
	print zm $zmv %zmv #zmv;


	var y as DEC(5,2) = 23.45;
	var v as VARI = 'AADDD';
	double hh hash(12) = ['AA',1234];
	print y v hh *hh;

	array xx 10 5 4 = [1,2,3,4,5,6];
	print xx *xx;

	print %ymv;
	for each x in %ymv;
		print *x;
	next;

	return ERROR;
end proc;
