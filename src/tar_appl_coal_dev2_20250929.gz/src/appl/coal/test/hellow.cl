//
proc main;
	option 3 2;
	try;
		loop do
		 	line=getline();
			n=getargs(line,1);
			a=left($1,5);
			b=substr($1,7);
			putline(a,'\t',b,'\t',line);
		end do;
	catch;
//		print ERRMSG;
	finally;
//		print 'finally';
	end try;
	return ERROR;
end proc;
