//
proc main;
	a = 'proc-1';
	b = 'test_scproc1';
	exec sc test_scproc1 'ABC';
	exec sc test_msg;
//	exec sc proc-1\@test_scproc1 'PROC';
//	exec sc $a\@$b 'PROC';
	exec sc ($a\@$b) 'PROC';
	print %1;
	exec sc %1?%1:'$a@$b' 'XXXX';
	exec ip �J�i�� 100 200;
	call �J�i�� 10 20;
	return ERROR;
end proc;

proc �J�i��(�ݽ�,b);
	print �ݽ� b;
	return ERROR;
end proc;
