//
define array a 10;
define array dec(10,2) $dec 10;
proc main;
/*
	$1 = 1;
	print ++$1 $1++;
	a[0] = 1;
	print ++a[0] a[0]++;
	$dec[0] = 1.0;
	$dec[1] = ++$dec[0];
	print ++$dec[0] $dec[1];
	print $dec[0]++ $dec[0];

	x = 1;
	print x++;
	$dec[0] = 1.0;
	print $dec[0]++;

	i = 2;
	print i++ i;

	$1 = 1;
	print --$1 $1--;
	a[0] = 1;
	print --a[0] a[0]--;
	$dec[0] = 1.0;
	$dec[1] = --$dec[0];
	print --$dec[0] $dec[1];
	print $dec[0]-- $dec[0];

	x = 1;
	print x--;
	$dec[0] = 1.0;
	print $dec[0];

	i = 2;
	print i-- i;
*/
	dec z = 1.5;
	y = z++;
	print y z;
	z = 1.5;
	y = ++z;
	print y z;

	return ERROR;
end proc;
