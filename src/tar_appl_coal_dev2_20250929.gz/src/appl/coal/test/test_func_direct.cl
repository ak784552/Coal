//
define type struct Greeter
	 variant salute
	,variant name
;
define type struct Counter
	 variant count
	,variant num
;

func _new (name);
	var g as Greeter;
	g.name = name;
	g.salute = (FUNC)'{func _salute;
	print My.name&+'' World!!'';
	return 0;
end func;}';
	return g;
end func;

func _new_count (n);
	var g as Counter;
	g.num = n;
	g.count = (FUNC)'{func _count;
	My.num++;
	return My.num;
end func;}';
	return g;
end func;

proc main;
	((FUNC)'{func x (a, b); print a b; return 0; end func;}')(1,2);

	g = _new('Hellow');
	g.salute();
	h = _new('Good night');
	h.salute();

	x = _new_count(10);
	print x.count();
	print x.count();

	return ERROR;
end proc;
