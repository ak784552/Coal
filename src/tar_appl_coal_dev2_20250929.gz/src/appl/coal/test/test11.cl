//
/*
define MAX_SOSU	=100000;
define int gFlag;
*/
proc main();
/*
	print [*(2..5)];
	b = [*(2..5)];
	print b;
	print [*('2'..'5')];
*/
	a = '2'..'5';
	print a *a;
	a = '3'..'';
	print a *a;
	a = ''..'4';
	print a *a;
//	a = 2..5;
//	print a *a;
	return ERROR;
end proc;
