//
define array h hash;
proc main;
	try;
		loop do;
			h[getline()] = 1;
		end do;
	catch;
		print ERRMSG ERRNO ERROR;
		for each x in h;
			print x.index;
		next;
	end try;
	return ERROR;
end proc;
