//
proc main;
	$i = 0;
	$f = 0.1;
	print $f;
	while $i < 10 do
		print $i $f;
		$i++;
		$f++;
	end do;
	return $ERROR;
end proc;
