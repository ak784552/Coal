//
define dec adec[10];
PROC main;

	option 11 6;
/*
	print '*** $1++ ***';
	print $s=gettime() 'sec' $1=1;
	loop 1000;
		$1++;
	end loop;
	print gettime()-$s 'sec' $1 '\n';

	print $s=gettime() 'sec' $1=1f;
	loop 1000;
		$1++;
	end loop;
	print gettime()-$s 'sec' $1 '\n';
/*
	print $s=gettime() 'sec' $1=1.0;
	loop 1000;
		$1++;
//	print gettime()-$s 'sec' $1;
	end loop;
	print gettime()-$s 'sec' $1 '\n';
//
	print '*** $1 = $1 + $2 ***';
	print $s=gettime() 'sec' $1=1234 $2=2345;
	loop 1000;
		$1 = $1 + $2;
	end loop;
	print gettime()-$s 'sec' $1 '\n';

	print $s=gettime() 'sec' $1=1234f $2=2345f;
	loop 1000;
		$1 = $1 + $2;
	end loop;
	print gettime()-$s 'sec' $1 '\n';

	print $s=gettime() 'sec' $1=1234.0 $2=2345.0;
	loop 1000;
		$1 = $1 + $2;
	end loop;
	print gettime()-$s 'sec' $1 '\n';
//
	print '*** $1 = $1 * $2 ***';
	print $s=gettime() 'sec' $1=1 $2=3 $3=1;
	loop 100;
		$1 = $1 * $2 * $3;
	end loop;
	print gettime()-$s 'sec' $1 '\n';

	print $s=gettime() 'sec' $1=1f $2=1.2345678901234567890f $3=0.81000000729000006633f;
	loop 100;
		$1 = $1 * $2 * $3;
	end loop;
	print gettime()-$s 'sec' $1 '\n';

	print $s=gettime() 'sec' $1=1.0 $2=1.23456789012345678901234567890 $3=0.8100000072900000663390006036857151;
	loop 100;
		$1 = $1 * $2 * $3;
//	print gettime()-$s 'sec' $1;
	end loop;
	print gettime()-$s 'sec' $1 '\n';

	print '*** $1 = $1 / $2 ***';
	print $s=gettime() 'sec' $1=1 $2=2 $3=1;
	loop 100;
		$1 = $1 / $2 / $3;
	end loop;
	print gettime()-$s 'sec' $1 '\n';

	print $s=gettime() 'sec' $1=1f $2=1.312f $3=0.7733f;
	loop 100;
		$1 = $1 / $2 / $3;
	end loop;
	print gettime()-$s 'sec' $1 '\n';

	print $s=gettime() 'sec' $1=1.0 $2=1.312 $3=0.7733;
	loop 100;
		$1 = $1 / $2 / $3;
	end loop;
	print gettime()-$s 'sec' $1 '\n';
*/
	print 1.0/1.23456789012345678901234567890;

	print 1.0/3.0;
	print 1.0/3.0*3.0;
	print '1.23456+3'+0 '1.23456-3'+0;

	f('-3000');
	f('-3001');
	f('-30.01');
	f('-0.123');
	f('-0.0123');
	f('-0.0');
*/
	print '123-3'+0 '123-2'+0 '123-1'+0 /d '.00123+1'+0;

	RETURN $ERROR;
END PROC;

func f(dec n);
	adec[0] = n;
	print adec[0] (CINT)adec[0];
	s = '' &+ adec[0];
	print s;
	return ERROR;
end func;
