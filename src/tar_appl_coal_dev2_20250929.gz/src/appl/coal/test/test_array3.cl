//
define mappedarray $a 1 3 3;
proc main;
	$i = 0;
	$j = 0;
	loop 3;
		$a[$i,$j] = $i + $j;
		print $i $j $a[$i,$j];
		$i++;
		$j++;
	end loop;
	return ERROR;
end proc;
