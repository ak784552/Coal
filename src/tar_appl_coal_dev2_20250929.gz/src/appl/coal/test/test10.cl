//
public pa='QWE';
global ga=100;
define $proc=1;
proc main;
	public pa='X';
	global ga=200;
	print pa ga $proc;
	return ERROR;
end proc;
