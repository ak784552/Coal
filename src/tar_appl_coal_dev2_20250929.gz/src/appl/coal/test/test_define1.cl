//
define var yd as DEC(5,2) = 345.67;
define string ss = 'ABCDEF';
//define ERROR ;
define aa[10];
//define DEC(10,4) yd = 123.4567;
sub main;
/*
//	char xx={1,2,3,4};
//	xx={1,2,3,4};
	print xx;
	int xx=12345;
	print xx;

	print aa;
	array aa[15];
	print aa;
	print yd ss;
	ss = '1234567890';
	print 1 ss;
	ss = ss;
	print 2 ss;

	private char(2) ss = ss;
	print 3 ss /i ss;
	private dec(10,3) yd = yd;
	print yd /i yd;

	ss = '1234567890';
	print 4 ss /i ss;
	redefine char(10) ss = '1234567890';
	print 5 ss /i ss;//d ss;

	redefine char ss;
	print ss ;//d ss;
	array aa = [1,2,3,4];
//	local aa[5] = [1,2,3,4];
	local aa[5] = 10;
//	array char aa = [1,2,3,4];
	print aa *aa;
*/
	x = 'ss';
	redef private char(2) $(x) = $(x);
	print 7 $(x);
//	print "private $1";

	return ERROR;
end sub;
