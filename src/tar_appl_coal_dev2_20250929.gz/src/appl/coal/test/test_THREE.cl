//
proc main;
	putline('** Enter two unequal number 1 to 9 in ascending oeder **');
	line = getline();
	n = getargs(line,1);
	loop while $1>=$2 or is($1&+$2,'N')!=1 or leng($1&+$2)>2;
		elwrite('Input error: please reenter numbers - ');
		line = getline();
		n = getargs(line,1);
	end loop;
	c = $1 + $2;
	alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	putline('The number ',$1,' letter of the alphabet is ',substr(alpha,$1,1));
	putline('The number ',$2,' letter of the alphabet is ',substr(alpha,$2,1));
	putline('The sum number ',c,' letter of the alphabet is ',substr(alpha,c,1));
	putline('Deference number ',$2-$1,' letter of the alphabet is ',substr(alpha,$2-$1,1));
	putline('The string of letters from position ',$1,' to ',$2, ' is ',
		substr(alpha,$1,$2-$1+1));
	return $ERROR;
end proc;
