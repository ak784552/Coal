//
define dec(15,2) d=123.45;
PROC main;
	x = 123.45;
	d = round(x,%2,%3);
	print d;
	print round(%1,%2,%3);
//	print round(d,%2,%3);
	RETURN $ERROR;
END PROC;
