//
define char(10) a[5] = *{'abc',ERROR,'xy','',123,'ABCDE'};
define aa 4 3=['zab','',345,'FDHIJ'];
def b=20,c=10;
def var d 10 as int = 1,2,3,4,5,6,7;
def e = [1,2,3];
proc main;
	print a *a;// /d a;
	print aa *aa;
	print b c d *d e;
	char c = 12345;
	char(10) c10 = 1234567890;
	print c;// /d c;
	print c10 ;///d c10;

	redefine char a[10];
//	print a[0];
	print a *a;// /d a;
	redefine char(3) a[10];
	print a *a;// /d a;
	redefine char a[4];
//	redefine a[4];
	print a *a;// /d a;

	private x=100,y=200;
	print /i x y;
	print x y;

	w=100,z=200;
	print /i w z;
	print w z;

	f1(100);
	f1(200);
	return ERROR;
end proc;

func f1(x);
	private d[3] =x;
	print d *d;
	return 0;
end func;
