//
//option 17 1;
//option 11 0x40;
//option 20 30;
proc main;
	echo edit('%.15e',sqrt(%1+0));
	echo u_sqrt(%1+0);
//	dec(20,15) x = u_sqrt(%1+0);
//	echo x;
	return $ERROR;
end proc;

function u_sqrt(b);
	x0 = b;
//echo x0;
	if (x0 > 0) then
//		if (x0 >= 4) thenl x0 *= 0.5;
		if (x0 >= 4) thenl x0 /= 2.0;
print x0;
		for i=1 to 10;
//		while (d=((y=x0*x0)-b)/(x0+x0)) do
			d = ((y=x0*x0)-b)/(x0+x0);
print d;
//print y;
			x0 -= d;
print i x0;
			if (abs(d) <= 1.0e-50) then
				x0+=5.0e-50;
				break;
			endif;
		next;
print d;
//print y;
		if (y > b) thenl x0--;
	end if;
	return x0;
end func;
