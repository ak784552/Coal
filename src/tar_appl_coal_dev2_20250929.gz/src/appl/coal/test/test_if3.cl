//
proc main;
	print %1 %2 %3;
	print "(%1 == %2 && %3)" ;
	print "(%1 + %2 && %3)";
	print "((%1 |+ %2) && %3)";
	if x=(CDEC)%1/0 then
		print x '<>0.0';
	else
		print x '==0.0';
	end if;
	return ERROR;
end proc;
