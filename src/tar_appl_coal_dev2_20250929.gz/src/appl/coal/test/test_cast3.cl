//
proc main;
/*
	print (CHAR)1 (BIN)'2' (DOUBLE)3 (char)4.5 (string)4.5 ;
	print ((FUNC)'ABS')(-10);
	print ff('ABS')(-10);
	print (BULK)1 (BULK)1234567890;
	print (CHAR)ABS(1-2);
	print (CHAR)MAX(1,2);
	print (CHAR)LENG(1);
	print (CHAR)XXX(1-2);
	print (CHAR)+(FUNC);
	print (INT)'1'+2;
	print (INT)'1';
	print (CHAR)(BULK)1;
	print (INTE)'1';
	print "'A' & (CHAR)12";
	print (DEC)'12.345';
	dec(10,2) x = 12.345;
	print x;
	print (CHAR(10))'123456789012345';
*/
	print (INT(8))'1';
/*
	print (DOUBLE(8))3;
	print (DEC(10,2))'12.345';
	print (BULK(20))'1234567890123456789012345';

	print (CHAR())'1';
	print (CHAR('A'))'1';
	print (CHAR(0))'1';
	print (CHAR(-1))'1';
	print (DEC(,2))'12.345';
	print (DEC(10,))'12.345';
	print (DEC('A',2))'12.345';
	print (DEC(10,'A'))'12.345';
	print (DEC(0,2))'12.345';
	print (DEC(-1,2))'12.345';
	print (DEC(10,1000))'12.345';
	print (DEC(10,-1000))'12.345';
	print (POINTER)'12.345';
//	let array char(3) $a 10;
//	x = 1;
//	(CHAR)x = 1;
//	(INT)$a[0] = 1;
//	x=1;
//	-x=0;
//	print x /d x;
//	vari x = '123';
//	print x /d x;

	print (INT)'1';

	print (CHAR(10))'123456789012345';

	print (CHAR())123.4567;
	print (DEC(15,2,3))'123456789.012345';
	print (POINTER(0))123.4567;
	print ((FUNC(0))'ABS')(-10);

	print (CCHAR(123.4567));

	print CDEC('123456789.012345',15,2);
*/
	print (DBL(8))3;

	return ERROR;
end proc;
