//
//define array $a 10;
//define array char(4) $a 10;
//define array BIN $a 10;
//define array $a hash 10;
define mappedarray $a 1 10;
define mappedarray %a 1 10;
proc main;
	$n = setarray($a,2,11,12,13,14,15,16,17,,19);
//	$n = setarray(%a,2,11,12,13,14,15,16,17,,19);
	print $n countv($a);
	loop for $i=0 $i<10 $i++;
		print $i $a[$i];
	end loop;
	return ERROR;
end proc;
