//
define array $A 10;
proc main;

	$x = 'MAX';
//	$a = $x(1,2);
	print $x(1,2);
	$A[1] = 'ABS';
	$a = ff($A[1])(-1);
	print $a;
	print ff(0)(-1);
	print '$'(1);
	print ff('$')(-1);
	print "ff('A' &+ 'BS')(-1)";
	print 'ff'('ABS')(-1);

	$x = ff('ABS');
	print $x(-2);
	print (ff('ABS'))(-1);
	$x = $A;
	$x = 0;
//	let ABS = 0;
//	$A = 0;
	$a = $A;
	$a = 0;
	A[0] = ABS;
	print A[0] A[0](-1);
	print (ff('func1'))(1000);
	return ERROR;
end proc;

function func1(x);
	print 'func1:' x;
	return 0;
end func;
