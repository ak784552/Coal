//
proc main;

	switch %1 + 0;
	case (0);
		print 'case 0';
	case 1,max(1+3,2);
		print 'case 1';
		break %2;
	case 2;
		print 'case 2';
		break;
	case 3;
		print 'case 3';
	default;
		print 'default';
		switch 0;
		case 0;
			print 'default.case 5';
			break %2;
		endsw;
//		break;
	case 5;
		print 'case 5';
		continue;
	case 6;
		print 'case 6';
	endsw;

	switch %3;
		case like '%A%';
		print %3;
	default;
		NULL;
	endsw;
	return ERROR;
end proc;
