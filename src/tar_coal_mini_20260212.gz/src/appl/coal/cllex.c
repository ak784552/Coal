static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/* <cllex.c>														*/
/*		�����														*/
/*			���p���̈����ύX										*/
/*			�����񒷃`�F�b�N�����ύX								*/
/********************************************************************/
#include "colmn.h"

#define YEN '\\'
#define WKBUFLEN	BUFLEN*8	/* 512*8 */
#define WKBUFMAX	WKBUFLEN-1

extern CLCOMMON CLcommon;
extern GlobalCt *pGlobTable;
extern int giOptions[];
extern XHASHB *xhp_main_def;
#if 0
extern condList  CLcList;	/* ��񃊃X�g */
extern CLNCB     CLSTCB;	/* �^�O�̍\����͂��s�����߂̗̈� */
#endif
extern char cmp_sep[];

static int _parmset();
static int _kugiri();
static int _proc_prepro();
static int _pragma();
static void _lex_clear();
/*
static XHASHB *sqp_lex_def=NULL;
static XHASHB *xhp_lex_def=NULL;
*/
static char comstr[MAX_LEN_LABEL+2];
static char cM_QUOTE1, cM_QUOTE2;
static char *def_sep=" \t'\";(){}[]";
static int gSqlMode=0;
static char *gpLabel=NULL;
static cmdTable *gpCmd=NULL;
static int giPREPRO_SKIP=0;
#if 0
typedef struct {
	int  pra_opt;	/* 0:rep_def, 1:include */
	char *pra_defkey;
	SSPL_S pra_sspl;
	condList pra_cList;	/* ��񃊃X�g */
} tdtPragmaStack;

#define CLISTSTACKMAX	20
static int iListStack=0;
static int iListStack0=0;
static tdtPragmaStack tPragmaStack[CLISTSTACKMAX+1];

#define MAXIFNEST	20
static int ifnest_cnt,ifnest[MAXIFNEST],iftrue[MAXIFNEST];

#define DEF_OPTC_ICASE	'*'
#define DEFICASEMAX	20
#endif
/************************************/
/* _lex_addrchk						*/
/************************************/
static int _lex_addrchk(y,msg)
char *y,*msg;
{
	if (!akxm_addrchk(y)) {
		printf("%s: invalid y=%08x\n",msg,y);
		return ECL_SYS_INVALID_ADDR;
	}
	return 0;
}

/************************************/
/* _condense_space					*/
/************************************/
static int _condense_space(buff,i,buff_len)
char *buff;
int i,buff_len;
{
	char c,*p;
	int k;

	k = 0;
	if (p = buff) {
		p += i;
		for (;k<buff_len;k++) {
			if ((c=*p++)==' ' || c=='\t') ;
			else break;
		}
		if (k > 0) k--;
	}
	return k;
}

/********************************************/
/* cl_chk_pos								*/
/*	psspl : �ǂݍ��ݏ��					*/
/*		sp      : i							*/
/*		wd      : buf						*/
/*		attr[0] : ���g�p					*/
/*		attr[1] : ���g�p					*/
/*		attr[2] : >0:buf���ɍs�̐擪���Ȃ�	*/
/*		attr[3] : EOF�t���O					*/
/*		wdmax   : len						*/
/*		code    : �X�N���v�g�̕����R�[�h	*/
/*		resv    : =0:���s�܂œǂݍ���		*/
/*	offset : ����ǂޑO�Ɏc���o�C�g��		*/
/********************************************/
static int _chk_pos(y,psspl,offset)
condList *y;
SSPL_S *psspl;
int offset;
{
	int i,len,l,rc,lend,m,pos,chk_len;
	char *buf,*p;
	uchar uc,sc_code;
/*
printf("_chk_pos Enter: y=%08x\n",y);
*/
	pos = 0;
	buf = psspl->wd;
	i   = psspl->sp;
	len = psspl->wdmax;
/*
printf("_chk_pos Enter:pos=%d i=%d len=%d attr[3]=%d resv=%d offset=%d\n",pos,i,len,psspl->attr[3],psspl->resv,offset);
*/
DEBUGOUTL4(LEX_LOG_GROUP+255,"_chk_pos enter:pos=%d i=%d len=%d attr[3]=%d",pos,i,len,psspl->attr[3]);

	if (i>=len && psspl->attr[3]) return -1;
#if 1	/* 2025.12.7 */
	if (psspl->resv && i<len) {
		if ((sc_code=psspl->code) == CD_TYPE_SJIS) chk_len = 2;
		else chk_len = 4;
		if (i+chk_len > len) {
			uc = buf[i];
			/* �����ł́A1�o�C�g�Ń}���`�o�C�g�����̉\���𔻒肷�� */
			m = akxqmbslen1(sc_code,uc);
			if (i+m > len) pos = m;
/*
printf("_chk_pos: len=%d i=%d m=%d uc=%02x pos=%d\n",len,i,m,uc,pos);
*/
DEBUGOUTL5(LEX_LOG_GROUP+122,"_chk_pos: len=%d i=%d m=%d uc=%02x pos=%d",len,i,m,uc,pos);
		}
		if (offset > pos) pos = offset;
	}
	psspl->attr[2] = pos;
#endif
	/* pos=0 �̂Ƃ��̂݁Abuf�̐擪���s�̐擪�ɂȂ� */
	/* pos>0 �̂Ƃ��́A�ǂݍ��񂾃��R�[�h���ɍs�̐擪�͂Ȃ� */
	if (i+pos >= len) {
		l = len - i;
/*
printf("_chk_pos: pos=%d i=%d len=%d l=%d buf=[%s]\n",pos,i,len,l,buf);
*/
DEBUGOUTL5(LEX_LOG_GROUP+122,"_chk_pos: pos=%d i=%d len=%d l=%d buf=[%s]",pos,i,len,l,buf);
		if (l>0 && i>0) {
			memcpy(buf,buf+i,l);
			len = l;
		}
		else len = 0;
/*
printf("_chk_pos: len=%d pos=%d\n",len,pos);
*/
		buf[len] = '\0';
		psspl->sp = 0;
		psspl->resv = 0;
	/*	i = psspl->sp + pos;	*/
		i = pos;
		p = buf + len;
		while (i>=len && !psspl->attr[3]) {
			if (len>0 && *p=='\n') {
				len--;
				*(--p) = '\n';
			}
			rc = cl_get_str(y,p);
DEBUGOUTL3(LEX_LOG_GROUP+122,"_chk_pos: rc=%d len=%d buf=[%s]",rc,strlen(buf),buf);
			if (rc) {
				psspl->attr[3] = 1;		/* File End */
				if (!len) return -1;
			}
			else {
				l = strlen(p);
				len += l;
				p   += l;
/*
printf("_chk_pos: len=%d buf=[%s]\n",len,buf);
*/
			}
			if (*(p-1) != '\n') psspl->resv = 1;
		}
		psspl->wdmax = len;
/*
printf("_chk_pos ret  :sp=%d len=%d attr[3]=%d buf=[%s]\n",psspl->sp,len,psspl->attr[3],buf);
*/
DEBUGOUTL4(LEX_LOG_GROUP+124,"_chk_pos ret  :i=%d len=%d attr[3]=%d buf=[%s]",i,len,psspl->attr[3],buf);

	}
	return psspl->sp;
}

/************************************/
/* cl_chk_pos_offset				*/
/************************************/
static int cl_chk_pos_offset(y,psspl,offset)
condList *y;
SSPL_S *psspl;
int offset;
{
	int i;
/*
printf("cl_chk_pos_offset Enter: y=%08x\n",y);
*/
/*if (_lex_addrchk(y,"cl_chk_pos")<0) return ECL_SYS_INVALID_ADDR;*/
	if ((i=_chk_pos(y,psspl,offset)) < 0) {
		i = ECL_END_OF_FILE;
	}
	return i;
}

static int cl_chk_pos(y,psspl)
condList *y;
SSPL_S *psspl;
{
	return cl_chk_pos_offset(y,psspl,0);
}

/************************************/
/* _alloc_cmd_parl					*/
/************************************/
static int _alloc_cmd_parl(y)
condList *y;
{
	char *p;
	cmdInfo *cmd;

	cmd = y->cmd;
	if (!cmd->parnum) {
		if (!(cmd->parl=(ParList *)cl_const_ct_malloc(y->ConstCt,sizeof(ParList)*MAX_PARL))) {
 			ERROROUT("Malloc CLcList_parl");
			return ECL_MALLOC_ERROR;
		}
		cmd->parnum = MAX_PARL;
		memset(cmd->parl,0,sizeof(ParList)*cmd->parnum);
	
		cmd->parl[1].par = y->fullname;
		cmd->parl[1].parlen = 0;
	
/*
DEBUGOUTL1(LEX_LOG_GROUP+120,"_lex_cmd_init: y->fullname=[%s]",y->fullname);
*/
	}
	return 0;
}

/************************************/
/* cl_lex_snln						*/
/************************************/
char *cl_lex_snln(y)
condList *y;
{
	static char *fmt="at script=[%s] line=%d";
	static char wrk[128],*p0=NULL;
	char *buf,*name,sname[33];
	int len;

	if (!(buf=y->fullname)) buf = y->fname;
	name = akxt_get_last_name("\\/",buf);
	len = strlen(name) + 30;
	if ((len=akxmemwork(len,&buf,&p0,wrk,sizeof(wrk))) <= 0) {
		buf = wrk;
		strncpy(sname,name,32);
		name = sname;
	}
DEBUGOUTL1(LEX_LOG_GROUP+120,"cl_lex_snln: name=[%s]",name);
	sprintf(buf,fmt,name,y->line);
	return buf;
}

/***************************************************/
/* _parmset (�\���� cmdInfo �ւ̃p�����[�^�̐ݒ�)  */
/***************************************************/
static int _parmset(y,pp,len,opt)
condList *y;
char *pp;
int  len,opt;
{
	parmList *lp;
	int rc;
	cmdInfo *cmd;

	cmd = y->cmd;
	if (cmd->prmnum+2 >= y->max_prmnum) {
		y->max_prmnum += 64;	/*PM_MAX;*/
		if (!(cmd->prmp=(parmList **)Realloc(cmd->prmp,sizeof(parmList *)*(y->max_prmnum)))) {
			ERROROUT("Realloc CLcList_prmp");
			return ECL_MALLOC_ERROR;
		}
/*
printf("_parmset: y->max_prmnum=%d\n",y->max_prmnum);
*/
	}
	lp = (parmList *)cl_const_ct_malloc(y->ConstCt,sizeof(parmList));
	if (!lp) {
		ERROROUT2("cllex:malloc error.%s parm[%s]",cl_lex_snln(y),pp);
		return ECL_MALLOC_ERROR;
	}
	memset(lp,0,sizeof(parmList));
	lp->prmlen = len;
	lp->prp = (char *)pp;
/*
printf("_parmset: cid=%08x prmnum=%d len=%d pp=[%s]\n",cmd->cid,cmd->prmnum,len,pp);
*/
	cmd->prmp[cmd->prmnum] = lp;
	cmd->prmnum++;
	if (opt) {
		if (y->mcat->mc_ipos > 0) {
			rc = akxtmcats(y->mcat," ");
		}
		else rc = 0;
#if 1	/* 2025.12.25 */
		if (len<=0 || !pp) {
			pp  = "NULL";
			len = 4;
		}
#endif
		if (rc >= 0) rc = akxtmcat(y->mcat,pp,len);
		if (rc < 0) {
			ERROROUT2("cllex:malloc error.%s parm[%s]",cl_lex_snln(y),pp);
			return ECL_MALLOC_ERROR;
		}
	}
	rc = _alloc_cmd_parl(y);
	return rc;
}

/************************************/
/* clparmset						*/
/************************************/
int clparmsetopt(y,wkstr,parmlen,opt)
condList *y;
char *wkstr;
int parmlen,opt;
{
	char *parm;
	int rc;

	parm = cl_const_ct_malloc(y->ConstCt,parmlen+1);
	if (parm) {
		memzcpy(parm,wkstr,parmlen);
		parmlen = strlen(parm);
		rc = _parmset(y,parm,parmlen,opt);
	}
	else {
		ERROROUT2("cllex:malloc error.%s parm[%s]",cl_lex_snln(y),wkstr);
		rc = ECL_MALLOC_ERROR;
	}
	return rc;
}

int clparmset(y,wkstr,parmlen)
condList *y;
char *wkstr;
int parmlen;
{
	return clparmsetopt(y,wkstr,parmlen,0);
}

/************************************/
/* clparmset2						*/
/************************************/
int clparmset2(y)
condList *y;
{
	char *p;
	int len,lenc,rc=0;
	cmdInfo *cmd;

	cmd = y->cmd;
	lenc = strlen(comstr);
	len = y->mcat->mc_ipos;
	p = cl_const_ct_malloc(y->ConstCt,len+lenc+2);
	if (p) {
		if (rc=_alloc_cmd_parl(y)) return rc;
		memzcpy(p,y->mcat->mc_bufp,len);
		cmd->parl[0].par = p;
		cmd->parl[0].parlen = len;
		y->mcat->mc_ipos = 0;
		/* SET_CMD_NAME */
		p += len + 1;
		memzcpy(p,comstr,lenc);
		cmd->parl[2].par = p;
		cmd->parl[2].parlen = lenc;
/*
printf("clparmset2: parl[2].par=[%s]\n",p);
*/
	}
	else {
		ERROROUT2("cllex:malloc error.%s parm[%s]",cl_lex_snln(y),y->mcat->mc_bufp);
		rc = ECL_MALLOC_ERROR;
	}
	return rc;
}

/***************************************************/
/* clparmclr (�\���� cmdInfo �̃p�����[�^�̏���)�@ */
/***************************************************/
int clparmclr(y)
condList *y;
{
	int i;

	y->cmd->prmnum = 0;
	y->mcat->mc_ipos = 0;
	return 0;
}

/***************************************************/
/* cl_syn_main                                     */
/***************************************************/
int cl_syn_main(y)
condList *y;
{
	int rc;
	char *pCmdLine;

if (DEBUGOUTCHECK(LEX_LOG_GROUP+120)) {
	if (cl_get_cmd_line(y->cmd,&pCmdLine) >= 0) DEBUGOUTL1(LEX_LOG_GROUP+120,"cl_syn_main:[%s]",pCmdLine);
}
	rc = cl_tree_main(y);	/* �؍\���쐬 */
	if (rc) {
#if 1	/* 2023.8.12 */
		if (cl_get_cmd_line(y->cmd,&pCmdLine) >= 0) {
			if (pCmdLine) {
				ERROROUT2("cllex:Create tree error=%d %s",rc,cl_lex_snln(y));
				ERROROUT1(" ---> [%s]",pCmdLine);
			}
		}
#else
		ERROROUT2("cllex:Create tree error=%d %s",rc,cl_lex_snln(y));
		if (cl_get_cmd_line(y->cmd,&pCmdLine) >= 0) {
			if (!pCmdLine) pCmdLine = "";
			ERROROUT1(" ---> [%s]",pCmdLine);
		}
#endif
	}
/*
printf("cl_syn_main: rc=%d\n",rc);
*/
	return rc;
}

/************************************/
/* _to_han_type						*/
/*  flag :  = 0 : ���p�ɕϊ����ꂽ	*/
/*			= 1 : �S�p�̂܂܎g��	*/
/************************************/
static int _to_han_type(moji,lenc,quote,wrk,type,pflag)
char *moji,quote,*wrk;
int  lenc,type,*pflag;
{
	int byte,flag;
	char c;

	flag = 1;
	byte = lenc;
	if (!(pGlobTable->options[8] & 0x02) && !quote) {
		byte = akxctohan_type_opt(1,moji,wrk,type,0);	/* 2026.1.2 0x10->0 */
/*
printf("_to_han_type: byte=%d\n",byte);
*/
		if (byte == 1) {
			c = wrk[0];
			wrk[1] = '.';
			if (pGlobTable->options[8] & 0x01) flag = 0;	/* �S�Ẳp���L���𔼊p�ɕϊ����� */
			else if (!quote/* || c=='\'' || c=='"'*/) flag = 0;
		}
	}
	else memcpy(wrk,moji,lenc);
	*pflag = flag;
	return byte;
}

/************************************/
/* _is_han_type						*/
/************************************/
static char _is_han_type(moji,quote,wrk,type)
char *moji,quote,*wrk;
int  type;
{
	int lenc,c,flag,byte;

	if (lenc=akxqismbs(type,moji)) {
		c = '\0';
		byte = _to_han_type(moji,lenc,quote,wrk+1,type,&flag);
		if (!flag) c = wrk[1];
	}
	else {
		lenc = 1;
		c = moji[0];
	}
	wrk[0] = lenc;
/*
printf("_is_han: lenc=%d c=%c\n",lenc,c);
*/
	return c;
}
#if 0	/* 2021.4.5 */
/************************************/
/* _is_han							*/
/************************************/
static char _is_han(moji,quote,wrk)
char *moji,quote,*wrk;
{
	return _is_han_type(moji,quote,wrk,CD_TYPE_SJIS);
}
#endif
/************************************/
/* _skip_line						*/
/************************************/
static int _skip_line(y,buf,psspl)
condList *y;
char *buf;
SSPL_S *psspl;
{
	int len,flg,rc,i;
	char c1;

	len = psspl->wdmax;
/*
printf("_skip_line:Enter len=%d\n",len);
*/
	flg = 1;
	while (flg) {
		if ((c1=buf[len-1])=='\n' || c1=='\r') flg = 0;
		rc = cl_get_str(y,buf);	/* ���ݍs���̂ĂāA���̍s��Ǎ��� */
		if (rc != 0) {
			return ECL_END_OF_FILE;	/* File End */
		}
		len = strlen(buf);
/*
printf("_skip_line: len=%d buf=[%s]\n",len,buf);
*/
	}
	i = 0;
	psspl->wdmax = len;
	return i;
}

/************************************/
/* �������̃X�^�b�N�ɂ��Ǘ�		*/
/************************************/
#define _SP_EXT	64
static int _sp_max=0;
static int *_stack=NULL;
static int _sp=0;
static int _sp_save=0;

/****************************/
/* _get_kakko_no			*/
/****************************/
static int _get_kakko_no(c)
char c;
{
	return instrchar("({[)}]",c);
}

/****************************/
/* _get_kakko_str			*/
/****************************/
static char *_get_kakko_str(j)
int j;
{
	static int msg_index[] = {686,687,688};
	int i;
	char *p;

	if (j>=1 && j<=3) i = j;
	else if (4>=1 && j<=6) i = j - 3;
	else i = 0;
	if (i) p = FORMAT(msg_index[i-1]);
	else p = "";
	return p;
}

/****************************/
/* _push					*/
/****************************/
static int _push(x)
int x;
{
	if (_sp >= _sp_max) {
		_sp_max += _SP_EXT;
		if (_stack) _stack = (int *)Realloc(_stack,_sp_max*sizeof(int));
		else        _stack = (int *)Malloc(_sp_max*sizeof(int));
		if (!_stack) return -4;
	}
	_stack[_sp++] = x;
	return 0;
}

/****************************/
/* _pop						*/
/****************************/
static int _pop()
{
	if (_sp <= 0) return -5;
	return _stack[--_sp];
}

/****************************/
/* _peek					*/
/****************************/
static int _peek()
{
	if (_sp <= 0) return 0;
	return _stack[_sp-1];
}

/****************************/
/* _chk_act					*/
/****************************/
static int _chk_act(c)
char c;
{
	int i,j,rc;

	if (c < 0) {
		_sp = 0;
		return 0;
	}
	else if (!c) {
		return _sp;
	}
	/* 2026.1.3 */
	else if (!(j=_get_kakko_no(c))) return -2;

	rc = 0;
	if (j <= 3) rc = _push(j);
	else {
		i = _peek();
/*
printf("_chk_act: j=%d i=%d\n",j,i);
*/
		if (i<1 || i>3) rc = -3;
		else if (i == j-3) rc = _pop();
		else rc = -11;
	}
	if (rc > 0) rc = 0;
	return rc;
}

/****************************/
/* cl_get_kakko_no			*/
/****************************/
int cl_get_kakko_no(c)
char c;
{
	return _get_kakko_no(c);
}

/****************************/
/* cl_get_kakko_str			*/
/****************************/
char *cl_get_kakko_str(j)
int j;
{
	return _get_kakko_str(j);
}

/****************************/
/* cl_kakko_peek			*/
/****************************/
int cl_kakko_peek()
{
	if (_sp <= 0) return 0;
	return _stack[_sp-1];
}

/****************************/
/* cl_chk_act				*/
/****************************/
int cl_chk_act(c)
char c;
{
	return _chk_act(c);
}

/****************************/
/* _chk_act_save			*/
/****************************/
static int _chk_act_save()
{
	return _sp_save =_sp;
}

/****************************/
/* _chk_act_rollback		*/
/****************************/
static int _chk_act_rollback()
{
	return _sp =_sp_save;
}
#if 1	/* 2026.1.3 */
/************************************/
/* ���p���̃X�^�b�N�ɂ��Ǘ�		*/
/************************************/
#define DEF_QUOTE_STACK_MAX	2
SSPL_S _quote_stack;
char _quote_stack_data[DEF_QUOTE_STACK_MAX];

/****************************/
/* _quote_statck_init		*/
/****************************/
static void _quote_stack_init()
{
	_quote_stack.wdmax = DEF_QUOTE_STACK_MAX;
	_quote_stack.sp = 0;
	_quote_stack.wd = _quote_stack_data;
}

/****************************/
/* _quote_push				*/
/****************************/
static int _quote_push(c)
char c;
{
	int ret;

	ret = 0;
	if (_quote_stack.sp >= _quote_stack.wdmax)
		ret = -4;
	else {
		_quote_stack.wd[_quote_stack.sp] = c;
		_quote_stack.sp++;
	}
	return ret;
}

/****************************/
/* _quote_pop				*/
/****************************/
static int _quote_pop(p)
char *p;
{
	int ret;

	ret = 0;
	if (p) {
		if (_quote_stack.sp <= 0) {
			*p = '\0';
			ret = -8;
		}
		else {
			*p = _quote_stack.wd[--_quote_stack.sp];
		}
	}
	else ret = -1;
	return ret;
}
#endif
/****************************/
/* _is_sjis_hankaku_kana	*/
/****************************/
static int _is_sjis_hankaku_kana(c)
uchar c;
{
	int rc;

	if (c>=161 && c<=223) rc = 1;
	else rc = 0;
	return rc;
}

/********************************************************/
/* _add_wkstr_mcat										*/
/********************************************************/
/* 2025.1.5 */
/* 2025.11.15 */
static int _add_wkstr_mcat(mcat,wkstr,h)
MCAT *mcat;
char *wkstr;
int  h;
{
	if (h > 0) {
		/* 2025.11.30 */
			akxtmcat(mcat,wkstr,h);
			akxtmcats(mcat,"");
/*
printf("_add_wkstr_mcat: opt=%d h=%d mc_ipos=%d wkstr=[%s]\n",opt,h,mcat->mc_ipos,wkstr);
*/
			h = 0;
		/* 2025.11.30 */
	}
	wkstr[h] = '\0';
	return h;
}

/****************************/
/* _to_han_henkan			*/
/****************************/
static int _to_han_henkan(buff,sspl,i,cm_level,quote1,sc_code,ex_opt9_03)
char *buff,quote1;
SSPL_S *sspl;
int i,cm_level,sc_code,ex_opt9_03;
{
	int h,lenc,flag,byte,byte2,len8,rc;
	char *wkstr,*p,wrk[16],c;
	uchar uc;
	ushort sjis;

	h = sspl->wdmax;
	wkstr = sspl->wd;
	rc = 0;
	for (;;) {	/* continue��break�ɒu�����邽�� */
		p = buff + i;
#ifdef CYGWIN_U8	/* 2020.5.5 */
		uc = *p;
		if (lenc=akxqismbs(sc_code,p)) {
#else
		if (lenc=iskanji(p)) {
#endif
/*
printf("cllex: lenc=%d\n",lenc);
*/
			flag = 1;
			/* 2026.1.2 */
			if (cm_level) ;
			else if (ex_opt9_03 != 2) {
				if ((byte=_to_han_type(buff+i,lenc,quote1,wrk,sc_code,&flag)) < 0) return byte;
				c = wrk[0];
/*
printf("cllex: lenc=%d flag=%d wrk=%02x %02x c=[%c]\n",lenc,flag,wrk[0] & 0xff,wrk[1] & 0xff,c);
*/
				/* 2026.1.2 */
				if (sc_code == CD_TYPE_EUC) {
					if (flag) {	/* ���͒l�����̂܂܎g�� */
/*
printf("cllex: wrk[0]=%02x wrk[1]=%02x\n",wrk[0] & 0xff,wrk[1] & 0xff);
*/
						byte2 = akxcetos(byte,wrk,wrk+4);
					/*	akxcetos1(wrk,wrk+4);	*/
						wrk[0] = wrk[4];
						if (byte2 == 1) wrk[1] = '\0';
						else wrk[1] = wrk[5];
/*
printf("cllex: wrk[4]=%02x wrk[5]=%02x\n",wrk[4] & 0xff,wrk[5] & 0xff);
*/
						c = wrk[0];
						if (!wrk[1]) flag = 0;
					}
				}
				if (sc_code==CD_TYPE_SJIS || sc_code==CD_TYPE_EUC) {
					if (flag) {	/* ���͒l�����̂܂܎g�� */
						/* 2026.1.2 */
						sjis = wrk[0];
						sjis = sjis<<8 | (uchar)wrk[1];
						/* 2022.11.22 */
						p = wkstr + h;
						/* 2026.1.6 */
						len8 = akxcstou8(2,wrk,p);
						if (!*p) {
									/* %s: %s(%08x)�̕ϊ���R�[�h������܂���B*/
							ERROROUT3(FORMAT(647),"cllex","S-JIS",sjis);
							memset(p,'?',len8);
						}
/*
printf("cllex:zenkaku flga=%d len8=%d\n",flag,len8);
*/
						h += len8;
					}
					else if (_is_sjis_hankaku_kana(c)) {
						sjis = (uchar)c;
						len8 = akxc_sj_to_utf8(sjis,wkstr+h,NULL);
/*
printf("cllex:_hankaku_kana flga=%d len8=%d\n",flag,len8);
*/
						h += len8;
						i += lenc;
						rc = C_PARM_CONTINUE;
						break;
					}
				}
				else {
					if (flag) {	/* ���͒l�����̂܂܎g�� */
						/* 2026.1.2 */
						memcpy(wkstr+h,wrk,byte);
						h += byte;
					}
				}
			}
			i += lenc;
			if (flag) rc = C_PARM_CONTINUE;
		}
#ifdef CYGWIN_U8	/* 2020.5.6 */
		else if (!cm_level && sc_code==CD_TYPE_SJIS && _is_sjis_hankaku_kana(uc=*(buff+i))) {
			sjis = uc;
			len8 = akxc_sj_to_utf8(sjis,wkstr+h,NULL);
/*
printf("cllex:_hankaku_kana len8=%d\n",len8);
*/
			h += len8;
			i++;
			rc = C_PARM_CONTINUE;
		}
#endif
		else {
			c = buff[i++];
		}
		break;
	}
	sspl->sp = i;
	sspl->wdmax = h;
	sspl->attr[0] = c;
	return rc;
}

/************************************/
/* cl_lex (�f�l�k�^�O������)		*/
/************************************/
int cl_lex(y)
condList *y;
{
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	int   kugiri_flg = 0;
#if 1	/* 2025.12.12 */
	char *buff;
#else
	char  buff[BUFLEN*2];
#endif
	char  wkstr[BUFLEN],*wwkstr;
	int	exit_flag=0, line_cont;
	ushort sjis;
	char  comstr[24],wrk[16];
	char  *parm,*p;
	int   len,cut,iCURR;
	int   rc,rc_def;
	int   i,ii,tree,h,wh,parmlen,cnum,j,flag,lenc,len8,ex_opt,sc_code,cmnd,iKUGIRI,ex_opt9,ex_opt9_03;
	char  code,info,quote,c,c1,quote1,quote2,cc,info_save;
	unsigned char uc;
	int   new_lex = 0;
	int   moji_const = 0;	/* BEXP $a = '//null/%s';��//���R�����g�ɂ��Ȃ� */
	SSPL_S sspl,tohan;
	int   cm_level=0;	/* �^���@���^�`���̃R�����g�̃l�X�g���x�� */
	int   kk_level=0;	/* ()�̃l�X�g���x�� */
	int   k2_level=0;	/* {}�̃l�X�g���x�� */
	int   k3_level=0;	/* []�̃l�X�g���x�� */
	int   ka[3],stack_p,i_save,rep_opt;
	int   def_parm;
	ScrPrCT *scrptct;
	int   inter_mode;
	ParList par;
	cmdInfo *cmd,*leaf_cmd;
	int iAT_NO_COMMENT,sub_cid;
	Leaf *leaf;
/*
printf("cllex: y=%08x\n",y);
*/
	cmd = y->cmd;
	if (y->fp == NULL) return(-1);
#if 1	/* 2025.12.12 */
	if (!(buff = Malloc(BUFLEN*2))) return ECL_MALLOC_ERROR;
	y->rbuf_len = BUFLEN*2;
#else
	y->rbuf_len = sizeof(buff);
#endif
	y->rbuf = buff;
	rc = cl_get_str(y,buff);
	if (rc) {
		ERROROUT(FORMAT(40));	/* cllex:�X�N���v�g�E�t�@�C������ł��B */
		goto FEND2;					/* File End */
	}
DEBUGOUTL2(LEX_LOG_GROUP+122,"cllex: len=%d buff=[%s]",strlen(buff),buff);
	if (!memcmp(buff,"#!",2)) {
#if 1	/* 2025.12.13 */
		rc = _skip_line(y,buff,&sspl);		/* ���ݍs���̂ĂāA���̍s��Ǎ��� */
#else
		rc = cl_get_str(y,buff);		/* ���ݍs���̂ĂāA���̍s��Ǎ��� */
#endif
		if (rc != 0) goto FEND2;	/* File End */
	}
	len = strlen(buff);
DEBUGOUTL2(LEX_LOG_GROUP+122,"cllex: len=%d buff=[%s]",len,buff);
	def_parm = 0;
	h = 0;
	mcat.mc_ipos = 0;
	i = 0;
	info  = 'N';					/* NewLine */
	quote1 = quote2 = quote = '\0';
	clparmclr(y);
	y->clstcb->nestLev1 = NULL;
	y->clstcb->nestLev2 = NULL;
	cl_cmd_init(y->cmd);		/* �����ݒ� */
	y->mcat->mc_ipos = 0;
	if (y->option & D_SCRPT_NEW_LEX) new_lex = 1;

	if (scrptct = cl_search_src_ct()) inter_mode = scrptct->sc_pFlag & D_SCRPT_INTERACTIVE;
	else inter_mode = 0;

	cM_QUOTE1 = pGlobTable->Quot[0];
	cM_QUOTE2 = pGlobTable->Quot[1];

	if ((rc=_alloc_cmd_parl(y)) < 0) return rc;

	if (y->option & D_CLST_OPT_USE_DTYPE) {
		sc_code = (y->option & D_CLST_OPT_DTYPE)>>16;
/*
printf("cllex: y->option=%08x sc_code=%d\n",y->option,sc_code);
*/
	}
	else {
		sc_code = CD_TYPE_SJIS;
		ex_opt = cl_get_option(21,0);
/*
printf("cllex: ex_opt=%08x\n",ex_opt);
*/
		ex_opt = (ex_opt>>20) & CD_TYPE_CODE;	/* file */
		if (ex_opt) sc_code = ex_opt;
/*
printf("cllex: sc_code=%d\n",sc_code);
*/
	}
	_chk_act(-1);
	_quote_stack_init();
	memset(&sspl,0,sizeof(SSPL_S));	/* add 2025.12.7 */
	sspl.wd = buff;
	sspl.wdmax = len;
#if 1	/* 2025.12.7 */
	sspl.code = sc_code;
	if (buff[len-1] != '\n') sspl.resv = 1;
#else
	sspl.attr[3] = 0;
#endif
	ex_opt9 = cl_get_option(9,0);
	ex_opt9_03 = ex_opt9 & 0x03;
	iAT_NO_COMMENT = !(ex_opt9 & 0x40);
/*
printf("cllex: ex_opt9=%08x iAT_NO_COMMENT=%d\n",ex_opt9,iAT_NO_COMMENT);
*/
	while (!exit_flag) {
/*if (_lex_addrchk(y,"0")<0) return ECL_SYS_INVALID_ADDR;*/
#if 1	/* 2025.11.9 */
		/* wkstr�ɁA�f�[�^�����n�߂钼�O�̏�Ԃ�ۑ����� */
		if (!h) {
			/* 2025.12.18 */
			j = akxnskipin(buff+i,sspl.wdmax-i," \t");
			if (j > 0) i += j - 1;
			stack_p = _chk_act_save();
			ka[0] = kk_level;
			ka[1] = k2_level;
			ka[2] = k3_level;
			i_save = i;
			info_save = info;
/*
printf("cllex: check point: ka=%d %d %d save stack_p=%d i_save=%d\n",ka[0],ka[1],ka[2],stack_p,i_save);
*/
		}
/*if (_lex_addrchk(y,"4")<0) return ECL_SYS_INVALID_ADDR;*/
#endif
		/* 2022.11.24 */
#if 1	/* 2025.11.15 */
		if (h+3 > BUFLEN) {
			h = _add_wkstr_mcat(&mcat,wkstr,h);
		}
#else
		/* 2025.1.5 */
		h = _add_wkstr_mcat(&mcat,wkstr,h,0);
#endif
/*
printf("cllex:1 len=%d h=%d i=%d c=%c\n",len,h,i,buff[i]);
*/
		ii = i;
/*if (_lex_addrchk(y,"5")<0) return ECL_SYS_INVALID_ADDR;*/
		sspl.sp = i;
		if ((i=cl_chk_pos(y,&sspl)) < 0) goto FEND;		/* File End */
/*
printf("cllex:2 len=%d h=%d i=%d buff=[%s]\n",len,h,i,buff+i);
*/
/*
printf("cllex:2 len=%d i=%d sspl.attr[2]=%d sspl.resv=%d\n",len,i,sspl.attr[2],sspl.resv);
*/
		iCURR = i;
		/* 2026.1.6 */
		tohan.wdmax = h;
		tohan.wd = wkstr;
		if ((rc=_to_han_henkan(buff,&tohan,i,cm_level,quote1,sc_code,ex_opt9_03)) < 0) goto FEND;
		i = tohan.sp;
		h = tohan.wdmax;
		if (rc == C_PARM_CONTINUE) continue;
		c = tohan.attr[0];
		len = sspl.wdmax;
/*
if (DEBUGOUTCHECK(LEX_LOG_GROUP+255)) {
DEBUGOUTL3(LEX_LOG_GROUP+255,"cllex:len=%d h=%d i=%d",len,h,i);
p=buff+i;
lenc=akxqkanjilen2(p,len-i);
memzcpy(wrk,p,lenc);
DEBUGOUTL2(LEX_LOG_GROUP+255,"cllex:c=[%c] [%s]",c,wrk);
*/
DEBUGOUTL4(LEX_LOG_GROUP+255,"cllex:def_parm=%d kk_level=%d k2_level=%d k3_level=%d",def_parm,kk_level,k2_level,k3_level);
DEBUGOUTL3(LEX_LOG_GROUP+255,"cllex: info=[%c] quote=[%c] cm_level=%d",info,quote,cm_level);
/*}*/
/*
if (y->option & D_SCRPT_MEMORY) printf("cllex: len=%d h=%d i=%d c=%c\n",len,h,i,c);
*/
		iKUGIRI = 0;
/*
printf("cllex:0 i=%d c=[%c] quote=[%c] quote2=[%c]\n",i,c,quote,quote2);
*/
/*
if (_lex_addrchk(y,"1")<0) return ECL_SYS_INVALID_ADDR;
*/
#if 1	/* 2022.10.10 */
		cc = c;
		if (c==M_QUOTE3 && gSqlMode) cc = 'X';	/* default �ɂȂ镶���Ȃ牽�ł��ǂ� */
#endif
#if 1	/* 2025.12.1 */
		/* �擪��'#'�̂Ƃ��̂݁A�v���v���Z�b�T�s�Ƃ��� */
		/* �X�L�b�v���́A�v���v���Z�b�T�s�ȊO�͖������� */
#if 1	/* 2025.12.6 */
		if (giPREPRO_SKIP && (c!='#' || iCURR!=0 || sspl.attr[2])) {
#else
		if (giPREPRO_SKIP && (c!='#' || i!=1)) {
#endif
			if ((i=_skip_line(y,buff,&sspl)) < 0) goto FEND;
			continue;
		}
		/* �R�����g�O�ŁA1�d���p��('or`)���ł́A�J�n�̈��p����'\'�ȊO�P�Ȃ镶���Ƃ��Ĉ��� */
		/* 2026.1.3 */
/*
printf("cllex: cc=[%c] cm_level=%d quote=[%c]\n",cc,cm_level,quote);
*/
		if (!quote || cm_level ||
			(quote==cM_QUOTE1 && cc==quote)) ;
		else {
			j = _get_kakko_no(c);
			if ((quote==cM_QUOTE2 && (cc==quote || c==cM_QUOTE1 || c==M_QUOTE3 || j)) ||
			    (quote==M_QUOTE3 && (cc==quote || c==M_QUOTE1 || j))) ;
			else {
				if (c!='\\') {
					wkstr[h++] = c;
					continue;
				}
			}
		}
/*
if (y->line==1005) printf("cllex: c=[%c] cm_level=%d quote=[%c]\n",c,cm_level,quote);
*/
#endif
		if (instrchar("#*/@'\"`\n\r\t ;\\",cc) > 0) {
			switch(cc) {
			case '#':
/*
if (giPREPRO_SKIP) printf("cllex: c=[%c] cm_level=%d quote=[%c] buff=[%s]\n",c,cm_level,quote,buff);
*/
				if (cm_level) break;
				else if (!quote && (info=='N')) {
					sspl.sp = i;
					if ((i=cl_chk_pos(y,&sspl)) < 0) {	/* 1-->0 2021.5.16 */
						wkstr[h++] = c;
						goto FEND;
					}
					len = sspl.wdmax;
					c1 = _is_han_type(buff+i,'\0',wrk,sc_code);
					if (c1=='!') {
						if ((i=_skip_line(y,buff,&sspl)) < 0) goto FEND;
						break;
					}
#if 1	/* 2025.12.6 */
					else if (iCURR==0 && !sspl.attr[2] && strchr(M_PRAGMA,c1)) {	/* �v���v���Z�b�T�s�́A�擪��'#'�̂� */
#else
					else if (i==1 && strchr(M_PRAGMA,c1)) {	/* �v���v���Z�b�T�s�́A�擪��'#'�̂� */
#endif
						i += wrk[0];
						if ((i=_proc_prepro(y,buff,i,&sspl,c1,sc_code)) < 0) {
							if (i == ECL_END_OF_FILE) {
								goto FEND;		/* File End */
							}
							else {
							/*	rc = i;	*/
								rc = ECL_LEX;
								h = memzcpy(wkstr,buff+iCURR,akxnskipto(buff+iCURR,len-iCURR,"\r\n"));
								goto ERR;
							}
						}
						sc_code = sspl.code;	/* add 2025.12.9 */
						break;
					}
				}
				if (!giPREPRO_SKIP) wkstr[h++] = c;
				break;
			case '*':
DEBUGOUTL3(LEX_LOG_GROUP+120,"cllex:ASTAR 1 c=[%c] cm_level=%d quote=[%c]",c,cm_level,quote);
#if 1	/* 2025.12.1 */
				if (quote) {
					wkstr[h++] = c;
					break;
				}
#endif
				sspl.sp = i;
				if ((i=cl_chk_pos(y,&sspl)) < 0) {	/* 1-->0 2021.5.16 */
					wkstr[h++] = c;
					goto FEND;
				}
				len = sspl.wdmax;
				c1 = _is_han_type(buff+i,quote,wrk,sc_code);
DEBUGOUTL1(LEX_LOG_GROUP+120,"cllex:ASTAR 2 c1=[%c]",c1);
				/* 2022.12.04 */
#if 1	/* 2025.12.1 */
				if (c1 == '/') {
#else
				if (((!cm_level && !quote) || cm_level>0) && c1=='/') {
#endif
					if (cm_level > 0) {
						cm_level--;

DEBUGOUTL2(LEX_LOG_GROUP+120,"cllex: */ cm_level=%d(end) quote=[%c]",cm_level,quote);

						i += wrk[0];
					/*	i++;	*/
					}
					else {
						ERROROUT1("cllex: unpaired '*/' at line=%d",y->line);
						return ECL_LEX;
					}
				}
				else if (!cm_level) {
					wkstr[h++] = c;
				}
				break;
			case '/':
DEBUGOUTL3(LEX_LOG_GROUP+120,"cllex: %c cm_level=%d quote=[%c]",c,cm_level,quote);
				if (quote) {
					wkstr[h++] = c;
					break;
				}
				sspl.sp = i;
				if ((i=cl_chk_pos(y,&sspl)) < 0) {
					wkstr[h++] = c;
					goto FEND;
				}
				len = sspl.wdmax;
				c1 = _is_han_type(buff+i,quote,wrk,sc_code);

if (DEBUGOUTCHECK(LEX_LOG_GROUP+255)) {
cl_str_conv_get(&p,buff,strlen(buff));
DEBUGOUTL4(LEX_LOG_GROUP+255,"cllex:i=%d len=%d c1=%c buff=[%s]",i,len,akxctoank(c1),p);
if (p != buff) Free(p);
DEBUGOUTL2(LEX_LOG_GROUP+255,"cllex:moji_const=%d quote=%02x",moji_const,quote);
}
/*
printf("cllex: c=[%c] cm_level=%d quote=%c h=%d c1=[%c]\n",c,cm_level,quote,h,c1);
*/
				/* 2022.12.04 */
				if ((!cm_level && (moji_const || quote)) || (c1!='/' && c1!='*')) {
					if (!cm_level) {
						wkstr[h++] = c;
					}
					break;
				}
				if (c1 == '*') {
/*
printf("cllex:i=%d len=%d buf=[%s] cm_level=%d(start)\n",i,len,buff,cm_level);
*/
					cm_level++;
DEBUGOUTL3(LEX_LOG_GROUP+120,"cllex: /%c cm_level=%d(start) quote=[%c]",c1,cm_level,quote);
					i += wrk[0];
					break;
				}
DEBUGOUTL2(LEX_LOG_GROUP+120,"cllex: /%c quote=[%c]",c1,quote);
				if (!cm_level) {
					new_lex = 1;
					y->option |= D_SCRPT_NEW_LEX;
				}
			case M_COMMENT:
/*
printf("cllex: c=[%c] cm_level=%d quote=%c h=%d\n",c,cm_level,quote,h);
*/
#if 1	/* 2025,11,28 */
				if (new_lex && (quote || (iAT_NO_COMMENT && c==M_COMMENT))) {
#else
				if (new_lex && quote) {
#endif
					if (!cm_level) wkstr[h++] = c;
					break;
				}
				if ((i=_skip_line(y,buff,&sspl)) < 0) goto FEND;
				break;
			case M_QUOTE1:	/* ' */
			case M_QUOTE2:	/* " */
			case M_QUOTE3:	/* ` */	/* 2022.10.10 */
				if (cm_level) break;
DEBUGOUTL5(LEX_LOG_GROUP+120,"cllex:QUOTE 1 c=[%c] cm_level=%d quote=[%c] quote1=[%c] quote2=[%c]",c,cm_level,quote,quote1,quote2);
				/* 2022.11.24 */
/*
DEBUGOUTL3(LEX_LOG_GROUP+120,"cllex:QUOTE 2 quote=[%c] quote1=[%c] quote2=[%c]",quote,quote1,quote2);
*/
/*
printf("cllex:i=%d c=[%c] quote=[%c]\n",i,c,quote);
*/
				if (c==cM_QUOTE1 || c==M_QUOTE3) {
					if (cm_level) break;
					if (!new_lex) {
						if (h == 0) moji_const = 1;	/* add 2001.8.20 Koba */
						wkstr[h++] = c;
						break;
					}
				}
			/*	if (cm_level) break;	*/
/*
printf("cllex:i=%d c=[%c] quote=[%c] quote2=[%c]\n",i,c,quote,quote2);
*/
				if ((c==cM_QUOTE2 && quote==cM_QUOTE2) ||
				    (c==cM_QUOTE1 && quote==cM_QUOTE1) ||
				    (c==M_QUOTE3 && quote==M_QUOTE3)) {
					if (c==cM_QUOTE1 || c==M_QUOTE3) {
						wkstr[h++] = c;
						sspl.sp = i;
						if ((i=cl_chk_pos(y,&sspl)) < 0) goto FEND;	/* 1-->0 2021.5.16 */
						len = sspl.wdmax;
						/* ���p���p���̎����S�p���p���̂Ƃ��́A�A�����锼�p���p���ƌ��Ȃ��B */
						/* ���ׂ̈�quote�ł͂Ȃ�'\0'���w�肵�Ĕ��p�ɕϊ������悤�ɂ���B */
						c1 = _is_han_type(buff+i,'\0',wrk,sc_code);
/*
printf("cllex:i=%d len=%d c1=%c buff+i=[%s]\n",i,len,c1,buff+i);
*/
						if (c1 == c) {
							wkstr[h++] = c1;
							i += wrk[0];
							break;
						}
						/* 2021.10.31 *//* 0 -> 1 */
						else {
							/* 2026.1.3 */
							/* ���p����߂� */
							if ((rc=_quote_pop(&quote)) == -1) return rc;
							quote2 = quote;
							if (quote == cM_QUOTE1) quote1 = quote;
							else quote1 = '\0';
DEBUGOUTL3(LEX_LOG_GROUP+120,"cllex:QUOTE 3 (end) quote=[%c] quote1=[%c] quote2=[%c]",quote,quote1,quote2);
/*
printf("cllex:1 i=%d c=[%c] quote=[%c] quote2=[%c] line=%d\n",i,c,quote,quote2,y->line);
*/
							if (quote)  break;
							else if (c1!='\t' && c1!=M_SPACE && c1!=M_KUGIRI) {
								moji_const = 0;
/*
printf("cllex:moji_const=%d quote=%02x\n",moji_const,quote);
*/
								/* 2022.1.6 */
								if (info == 'C') {
									cmnd = cmd->cid;
									if (cmnd == C_LET) break;
									else if (c1!=' ' && (cmnd==C_IF || cmnd==C_ELSEIF ||
									     cmnd==C_LOOP || cmnd==C_FOR || cmnd==C_WHILE || cmnd==C_UNTIL ||
									     cmnd==C_DO || cmnd==C_SWITCH)) ;
									else break;
								}
								else break;
							}
						}
						c = c1;
					}
/*
printf("cllex:moji_const=%d info=[%c] h=%d\n",moji_const,info,h);
*/
					iKUGIRI = 3;
				}
				else {
					if (!quote) {
						if (h>0 && (c==cM_QUOTE2 ||
						            ((c==cM_QUOTE1 || c==M_QUOTE3) && info=='N' && new_lex))) {
							wkstr[h] = '\0';
							iKUGIRI = 4;
/*
printf("cllex: iKUGIRI=%d line=%d\n",iKUGIRI,y->line);
*/
							break;
						}
						quote = c;
						if (c == cM_QUOTE2) {
							break;
						}
						/* 2026.1.3 */
						else if (quote == cM_QUOTE1) quote1 = quote;
					}
					/* 2026.1.3 */
					else if (quote2!=quote &&
					         ((quote==cM_QUOTE2 && (c==cM_QUOTE1 || c==M_QUOTE3)) ||
					          (quote==M_QUOTE3 && c==cM_QUOTE1))) {
PRINTOUTL2(100,"cllex: ���p����(quote=[%c])�ł́Ac=[%c]�̈��p�������̊J�n",quote,c);
						/* 2�d���p�����ł́A'or`�̈��p�������̊J�n */
						/* 2026.1.3 */
						/* ���p����ۑ� */
						if ((rc=_quote_push(quote)) < 0) {
								/* %s: ���p���X�^�b�N(%d)���I�[�o�t���[���܂����B���p��=[%c] */
							ERROROUT3(FORMAT(685),"cl_lex",DEF_QUOTE_STACK_MAX,quote);
							return rc;
						}
						quote2 = quote;		/* ���p����ۑ� */
						/* 2026.1.3 */
						quote = c;
						if (quote == cM_QUOTE1) quote1 = quote;
						else quote1 = '\0';
					}
/*
printf("cllex:2 i=%d c=[%c] quote=[%c] quote2=[%c] line=%d\n",i,c,quote,quote2,y->line);
*/
					wkstr[h++] = c;
DEBUGOUTL3(LEX_LOG_GROUP+120,"cllex:QUOTE 4 (start) quote=[%c] quote1=[%c] quote2=[%c]",quote,quote1,quote2);
				}
				break;
			case '\n':
			case '\r':
				if (!new_lex) break;
				if (len==1 && inter_mode) goto FEND;
			case '\t':
			case M_SPACE:
			case M_KUGIRI:
				if (cm_level) break;
				else if (quote) {
					wkstr[h++] = c;
				}
				else if (c==M_KUGIRI && kk_level>0) {
					wkstr[h++] = c;
				}
				else {
					iKUGIRI = 2;
				}
				break;
			case YEN:
				sspl.sp = i;
				if ((i=cl_chk_pos(y,&sspl)) < 0) goto FEND;	/* 2-->0 2021.5.16 */
				len = sspl.wdmax;
				if (i < len) {
					if (akxqismbs(sc_code,buff+i)) break;
					c=buff[i];
					if (new_lex) {
						if (quote==cM_QUOTE1 || quote==M_QUOTE3) {
							if (c=='\r' || c=='\n') i++;
							else if (!cm_level) wkstr[h++] = YEN;
						}
						else {
							if (c=='\r' || c=='\n') i++;
							else {
								if (!cm_level) {
									wkstr[h++] = c;
								}
								i++;
							}
						}
					}
					else {
						if (c!='\t' && c!='\n' && c!=M_SPACE) {
							if (!cm_level) {
								wkstr[h++] = c;
							}
							i++;
						}
					}
				}
				break;
			default:
				if (!cm_level) {
					wkstr[h++] = c;
				}
				if (info=='N' && c==':') iKUGIRI = 1;
				break;
			}
		}
		else if (!giPREPRO_SKIP) {
			switch(cc) {
			case ')':
			case '}':
			case ']':
				if (!cm_level) {
					/* 2026.1.3 */
					if (!quote1) {
						rc = 0;
/*
printf("cllex:)}]:1 kk_level=%d k2_level=%d k3_level=%d c=%c\n",kk_level,k2_level,k3_level,c);
*/
						if (c==')' && kk_level>0) {
							kk_level--;
						/*
							if (!kk_level && cmd->cid==C_TRY) {
								wkstr[h++] = c;
								iKUGIRI = 1;
								break;
							}
						*/
						}
						else if (c=='}' && k2_level>0) k2_level--;
						else if (c==']' && k3_level>0) k3_level--;
						else rc = -11;
						if (!rc) rc = _chk_act(c);
						if (rc) {
							ERROROUT3("cllex: unpaired '%c' %s rc=%d",c,cl_lex_snln(y),rc);
/*
printf("cllex:)}]:2 kk_level=%d k2_level=%d k3_level=%d c=%c i=%d\n",kk_level,k2_level,k3_level,c,i);
*/
/*
if (_sp) printf("cllex:)}]:2 _sp=%d _stack[_sp-1]=%d\n",_sp,_stack[_sp-1]);
else printf("cllex:)}]:2 _sp=%d\n",_sp);
printf("cllex:)}]:2 kk_level=%d k2_level=%d k3_level=%d c=%c i=%d\n",kk_level,k2_level,k3_level,c,i);
*/
							return ECL_LEX;
						}
/*
printf("cllex:)}]:2 kk_level=%d k2_level=%d k3_level=%d c=%c\n",kk_level,k2_level,k3_level,c);
*/
						if (!kk_level && !k2_level && !k3_level) {
							sspl.sp = i;
							if ((i=cl_chk_pos(y,&sspl)) < 0) {	/* 1-->0 2021.5.16 */
								wkstr[h++] = c;
								goto FEND;
							}
							len = sspl.wdmax;
							c1 = _is_han_type(buff+i,'\0',wrk,sc_code);
/*
printf("cllex:i=%d c1=%c kk_level=%d k2_level=%d k3_level=%d\n",i,c1,kk_level,k2_level,k3_level);
*/
							/* 2022.1.5 */
							if (info == 'C') {
								cmnd = cmd->cid;
								/* 2022.1.5 */
								if (cmnd == C_LET) ;
								else if (c1!=' ' && (cmnd==C_IF || cmnd==C_ELSEIF ||
								     cmnd==C_LOOP || cmnd==C_FOR || cmnd==C_WHILE || cmnd==C_UNTIL ||
								     cmnd==C_DO || cmnd==C_SWITCH)) {
									iKUGIRI = 1;
									wkstr[h++] = c;
									break;
								}
							}
						}
					}
					wkstr[h++] = c;
				}
				break;
			case '{':
				if (!cm_level) {
					wkstr[h++] = c;
					/* 2026.1.3 */
					if (!quote1 && !def_parm) {
						k2_level++;
						if (rc=_chk_act(c)) goto ERR;
					}
				}
				break;
			case '\n':
			case '\r':
/*
printf("cllex:CR/LF: new_lex=%d inter_mode=%d i=%d len=%d c=%c buff=[%s]\n",new_lex,inter_mode,i,len,c,buff);
*/
				if (!new_lex) break;
				if (len==1 && inter_mode) goto FEND;
			case '\t':
			case '(':
			case '[':
			case M_SPACE:
			case M_KUGIRI:
				if (cm_level) break;
				/* 2026.1.3 */
				if (!quote1) {
					if (c=='(' || c=='[') {
						if (c == '(') kk_level++;
						else if (c=='[') k3_level++;
						if (rc=_chk_act(c)) {
							wkstr[h++] = c;
							goto ERR;
						}
					}
				}
/*
printf("cllex:i=%d h=%d c=%c kk_level=%d info=%c\n",i,h,c,kk_level,info);
*/
				if (quote || (info=='C' && (c=='[' || c=='('))) {
				/*	if (buff[i] == '\t')
						buff[i] = ' ';	*/
					wkstr[h++] = c;
				}
				else if (c==M_KUGIRI && kk_level>0) {
					wkstr[h++] = c;
				}
				else {
					iKUGIRI = 2;
				}
				break;
			default:
				if (!cm_level) {
					wkstr[h++] = c;
				}
				if (info=='N' && c==':') iKUGIRI = 1;
				break;
			}
		}
/*
if (_lex_addrchk(y,"2")<0) return ECL_SYS_INVALID_ADDR;
printf("cllex: iKUGIRI=%d h=%d wkstr=[%s] y=%08x\n",iKUGIRI,h,wkstr,y);
*/
		/* 2021.10.31 */
		if (iKUGIRI) {
			if (giPREPRO_SKIP) {
				h = 0;
				mcat.mc_ipos = 0;
				moji_const = 0;
				if (iKUGIRI == 3) {
					quote2 = quote1 = quote = '\0';
				}
				else if (iKUGIRI == 4) quote = c;
				continue;
			}
			wkstr[h] = '\0';

DEBUGOUTL3(LEX_LOG_GROUP+120,"cllex: iKUGIRI=%d h=%d wkstr=[%s]",iKUGIRI,h,wkstr);

			/* 2025.1.5 */
#if 0	/* 2025.11.30 */
			h = _add_wkstr_mcat(&mcat,wkstr,h,1);
#endif
			if (!mcat.mc_ipos) {
				wwkstr = wkstr;
				wh = h;
			}
			else {
#if 1	/* 2025.11.30 */
				h = _add_wkstr_mcat(&mcat,wkstr,h);
#endif
				wwkstr = mcat.mc_bufp;
				wh = mcat.mc_ipos;
				mcat.mc_ipos = 0;
			}
/*
printf("cllex:1 wh=%d wwkstr=[%s]\n",wh,wwkstr);
*/
			/* 2025.11.7 add rep_opt */
			/* XXX(a,b,c) ����n�܂�Ƃ��́AXXX���R�}���h�̉\�������邽�߁A'('�̑O�ň�U��؂���
			   XXX�݂̂ŁAkugiri�������s���B���̂Ƃ��AXXX���p�����[�^�t���̒u���Ώۂ̂Ƃ��́A
			   �u�p�����[�^���K�v�ł��v�̃G���[�ɂȂ邽�߁A�ȉ���rep_opt�Ő��䂷�� */
			if (info == 'N') rep_opt = 1;	/* �R�}���h�̂Ƃ��́A�u�p�����[�^���K�v�ł��v�̃G���[�ɂ��Ȃ� */
			else rep_opt = 0;
			/* 2025.11.8 */
/*
if (_stack) {
	if (_sp) printf("cllex: _sp=%d _stack[_sp-1]=%d\n",_sp,_stack[_sp-1]);
	else printf("cllex: _sp=%d \n",_sp);
else printf("cllex: _sp=%d _stack=NULL\n",_sp);
printf("cllex: kk_level=%d k2_level=%d k3_level=%d\n",kk_level,k2_level,k3_level);
*/
			if (iKUGIRI == 1) {
				if (rc = _kugiri(y,' ',wh,wwkstr,&info)) return rc;
				h = 0;
				moji_const = 0;
			}
			else if (iKUGIRI == 2) {
			/*
				if (info=='C' && cmd->cid==C_DO &&
				    !cmd->prmnum && stricmp(wwkstr,"AS")) {
					if (rc = _kugiri(y,';',0,wwkstr,&info)) return rc;
				}
			*/
				rc = _kugiri(y,c,wh,wwkstr,&info);
				if (rc == C_PARM_CONTINUE) {
					wkstr[h++] = c;
				}
				else if (rc == C_PARM_START) {
					h = 0;
					wkstr[h++] = c;
					moji_const = 0;
				}
				else if (rc == C_PARM_HEREDOC) {
					sspl.wdmax = 1;
					*buff = '\n';
					if ((i=_skip_line(y,buff,&sspl)) < 0) goto FEND;
/*
printf("cllex: buff=[%s]\n",buff);
*/
					h = 0;
					moji_const = 0;
				}
				else if (rc) return rc;
				else {
					h = 0;
					moji_const = 0;	/* add 2001.8.20 Koba */
#if 1	/* 2025.12.10 */
					if (c == ';') {
						/* define option/options �̂Ƃ��݂̂̏����ɂ��������A
						   ���̔���ɃR�X�g��������̂ŁA���肵�Ȃ����Ƃɂ��� */
						ex_opt9 = cl_get_option(9,0);
						ex_opt9_03 = ex_opt9 & 0x03;
						iAT_NO_COMMENT = !(ex_opt9 & 0x40);
					}
#else
#if 1	/* 2025.12.9 */
					if (c==';' && (leaf=y->AddressRoot)) {
						leaf_cmd = &leaf->cmd;
						sub_cid = leaf_cmd->sub_cid;
						/* define option/options �̂Ƃ��́A�I�v�V��������蒼�� */
						if (leaf_cmd->cid==0xe00 && (sub_cid==1 || sub_cid==2)) {
							ex_opt9 = cl_get_option(9,0);
							ex_opt9_03 = ex_opt9 & 0x03;
							iAT_NO_COMMENT = !(ex_opt9 & 0x40);
/*
printf("cllex:2 ex_opt9=%08x iAT_NO_COMMENT=%d\n",ex_opt9,iAT_NO_COMMENT);
*/
						}
/*
printf("cllex: cid=%08x sub_cid=%08x c=[%c]\n",leaf_cmd->cid,leaf_cmd->sub_cid,c);
printf("cllex: parl[0].par=[%s]\n",leaf_cmd->parl[0].par);
printf("cllex: parl[2].par=[%s]\n",leaf_cmd->parl[2].par);
*/
					}
#endif
#endif
				}
			}
			else if (iKUGIRI == 3) {
				if (info == 'N') {	/* �R�}���h */
					if (rc = _kugiri(y,c,wh,wwkstr,&info)) return rc;
				}
				else {
					parmlen = wh;
					wwkstr[wh] = '\0';
					if (rc = clparmsetopt(y,wwkstr,parmlen,1)) return rc;
				}
				h = 0;
				moji_const = 0;	/* add 2001.8.20 Koba */
				quote2 = quote1 = quote = '\0';
			}
			else if (iKUGIRI == 4) {
				if (rc = _kugiri(y,c,wh,wwkstr,&info)) return rc;
				h = 0;
				moji_const = 0;	/* add 2001.8.20 Koba */
				quote = c;
				if (c != cM_QUOTE2) {
					wkstr[h++] = c;
					quote1 = c;
				}
			}
			iKUGIRI = 0;
		}
	}
	ERROROUT2("cllex:String too long.[%s] %s", wkstr,cl_lex_snln(y));
	return ECL_LEX;
FEND:
/*
printf("cllex: i=%d\n",i);
*/
	if (i<0 && i!=ECL_END_OF_FILE) return i;
	p = cl_lex_snln(y);
	if (kk_level || k2_level || k3_level) {
					/* cllex: �J�b�R('(')�����Ă��܂���(%s)�Bkk_level=%d */
		if (kk_level) ERROROUT2(FORMAT(31),p,kk_level);
					/* cllex: ���J�b�R('{')�����Ă��܂���(%s)�Bk2_level=%d */
		if (k2_level) ERROROUT2(FORMAT(38),p,k2_level);
					/* cllex: ��J�b�R('[')�����Ă��܂���(%s)�Bk3_level=% */
		if (k3_level) ERROROUT2(FORMAT(39),p,k3_level);
		return ECL_LEX;
	}
	else if (cm_level) {
		/* cllex: �R�����g�����Ă��܂���(%s)�Bcm_level=%d */
		ERROROUT2(FORMAT(32),p,cm_level);
		return ECL_LEX;
	}
	else if (quote) {
		/* "cllex: ���p��(%c)�����Ă��܂���(%s)�B */
		ERROROUT2(FORMAT(33),quote,p);
		return ECL_LEX;
	}
	else if (info=='C' || h>0) {
		if (h>0) {
			wkstr[h] = '\0';
/*
printf("cllex: h=%d wkstr=[%s]\n",h,wkstr);
*/
			clparmsetopt(y,wkstr,h,1);
		}
		ERROROUT1(FORMAT(34),p);	/* cllex: �����I�����Ă��܂���(%s)�B */
		if (cl_get_cmd_line(y->cmd,&parm) >= 0) ERROROUT1(" ---> [%s]",parm);
		else ERROROUT1(FORMAT(35),wkstr);	/* cllex: [%s]�͗L���ȕ��ł͂���܂���B */
		return ECL_LEX;
	}
FEND2:
	cl_cmd_init(y->cmd);
	clparmclr(y);
	cmd->cid = C_FEND;	/* �t�@�C���I������ */
	cmd->type = 0;
	rc = cl_syn_main(y);
/*
printf("cllex: cl_syn_main rc=%d\n",rc);
*/
	cl_cmd_init(y->cmd);
	clparmclr(y);
	y->clstcb->nestLev1 = NULL;
	y->clstcb->nestLev2 = NULL;
	info = 'N';
	_lex_clear(y);
	return rc;
ERR:
	_lex_clear(y);
	ERROROUT2("cllex:rc=%d %s",rc,cl_lex_snln(y));
	wkstr[h] = '\0';
	if (cl_get_cmd_line(cmd,&parm) < 0) parm = "";
	/* 20241.14 */
	if (parm) ERROROUT2(" ---> [%s %s]",parm,wkstr);
	else ERROROUT1(" ---> [%s]",wkstr);
	return rc;
}

/************************************/
/* _chk_heredoc						*/
/************************************/
int _chk_heredoc(y)
condList *y;
{
	int i,parm_pos,len,nam_len,rc,cid,pos,del_tab_space,len_b,opt800;
	char *p,*name,buf[BUFLEN],*pp;
	parmList **prmp,*lp;
	cmdInfo *cmd;
	MCAT mcat;
/*
printf("_chk_heredoc:Enter\n");
*/
	cmd = y->cmd;
	prmp = cmd->prmp;
	rc = nam_len = del_tab_space = 0;
	name = NULL;
	for (i=0;i<cmd->prmnum;i++) {
		lp = prmp[i];
		nam_len = lp->prmlen;
		p = lp->prp;
/*
printf("_chk_heredoc: i=%d p=[%s]\n",i,p);
*/
		if (nam_len>=2 && !memcmp(p,"<<",2)) {
			nam_len -= 2;
			if (nam_len > 0) {
				p += 2;
				pos = akxnskipin(p,nam_len,"-=!");
/*
printf("_chk_heredoc: i=%d pos=%d\n",i,pos);
*/
				if (pos > 0) {
					del_tab_space = D_PFLAG2_DEL_TAB;
					if (inmemchars(p,pos,"=")) del_tab_space |= D_PFLAG2_DEL_SPACE;
/*
printf("_chk_heredoc: i=%d rc=%d del_tab_space=%02x\n",i,rc,del_tab_space);
*/
					p += pos;
					nam_len -= pos;
				}
			}
			if (nam_len > 0) name = akxttrim2(0,p,&nam_len);
			if (nam_len > 0) break;
			else if (i < cmd->prmnum - 1) {
				lp = prmp[i+1];
				nam_len = lp->prmlen;
				name = akxttrim2(0,lp->prp,&nam_len);
				if (nam_len > 0) break;
				return -1;
			}
			else return -1;
		}
	}
	if (name) {
		del_tab_space |= cl_get_option(25,0) & (AKX_TRIM_DEL_TAB | AKX_TRIM_DEL_SPACE);
		name = strmemk(name,nam_len,"_chk_heredoc");
/*
printf("_chk_heredoc: name=[%s]\n",name);
*/
		rc = 0;
		if (instrchar("$%#'",*name)) {
					/* %s: heredoc�̏I�[������[%s]������Ă��܂��B*/
			ERROROUT2(FORMAT(632),"_chk_heredoc",name);
			rc = -1;
		}
		opt800 = cl_get_option(25,0) & D_RED_PFLAG2_FILE;
		if (!opt800) {
			memset(&mcat,0,sizeof(MCAT));
			mcat.mc_extlen = 512;
		}
		while (!rc) {
			if (rc = cl_get_str(y,buf)) {
						/* %s: heredoc�̏I���s[%s]������܂���B*/
				ERROROUT2(FORMAT(631),"_chk_heredoc",name);
				rc = -1;
				break;
			}
			len = strlen(buf);
DEBUGOUTL2(LEX_LOG_GROUP+122,"cllex: len=%d buf=[%s]",len,buf);
			if (opt800) {
				len_b = 0;
			}
			else {
				len_b = mcat.mc_ipos;
				akxtmcat(&mcat,buf,len);
			}
			p = buf + len - 1;
			if (*p == '\n') *p = '\0';
/*
printf("_chk_heredoc: buf=[%s]\n",buf);
*/
			if (del_tab_space) {
				len = strlen(buf);
				p = akxttrim2(del_tab_space|2,buf,&len);
/*
printf("_chk_heredoc: p=[%s]\n",p);
*/
			}
			else p = buf;
			if (!strcmp(p,name)) {
				rc = 1;
				len = cmn_i_to_a(cmd->rc,buf);
				/* �I�[���������蒼�� */
				nam_len = lp->prmlen;
				name = akxttrim2(0,lp->prp,&nam_len);
				/* �ϐ��̈���m�� */
			/*	p = cl_const_ct_malloc(y->ConstCt,nam_len+len+len_b+4);	*/
				p = CTMalloc(y->ConstCt,nam_len+len+len_b+4);
				lp->prp = p;
				/* �I�[��������R�s�[ */
				memzcpy(p,name,nam_len);
				p += nam_len;
				if (opt800) {
					/* " F"�ƃR�}���h�s�ԍ����R�s�[ */
					*p++ = ' ';
					*p++ = 'F';
					memzcpy(p,buf,len);
					lp->prmlen = nam_len + len + 2;
				}
				else {
					/* '.'�ƃR�}���h�s�ԍ����R�s�[ */
					*p++ = '.';
					memzcpy(p,buf,len);
					p += len;
					/* " M"�Ɠ��̓f�[�^���R�s�[ */
					pp = mcat.mc_bufp;
/*
printf("_chk_heredoc: len=%d pp=[%s]\n",len_b,pp);
*/
					*p++ = ' ';
					*p++ = 'M';
					if (pp && len_b>0) {
						memzcpy(p,pp,len_b);
						Free(pp);
					}
					lp->prmlen = nam_len + len + len_b + 3;
				}
/*
printf("_chk_heredoc: lp->prmlen=%d lp->prp=[%s]\n",lp->prmlen,lp->prp);
*/
				break;
			}
		}
	}
/*
printf("_chk_heredoc:Exit rc=%d\n",rc);
*/
	return rc;
}

/************************************/
/* _kugiri							*/
/************************************/
static int _kugiri(y,kc,h,wkstr,pinfo)
condList *y;
char kc,*wkstr,*pinfo;
int  h;
{
	int rc,parmlen,cnum,cid,no_kugiri,n,i,thenl,elsel,cmd_count,scno,pos,heredoc,cmd_type;
	cmdTable *pcmd;
	char *p,wrk[2];
	cmdInfo *cmd;

	cmd = y->cmd;
	parmlen = h;
	wkstr[parmlen] = '\0';

DEBUGOUTL5(LEX_LOG_GROUP+124,"_kugiri: kc=[%c] h=%d wkstr=[%s] info=[%c] cid=%08x",kc,h,wkstr,*pinfo,cmd->cid);

/*
printf("_kugiri: kc=%c h=%d wkstr=[%s] info=%c cid=%08x\n",kc,h,wkstr,*pinfo,cmd->cid);
*/
/*
printf("_kugiri: cid=%08x thenl_level=%d\n",cid,thenl_level);
*/
	if (*pinfo == 'N') cmd->cid = C_UNKNOWN;
	thenl = 0;
	elsel = 0;
	heredoc = 0;
	if (parmlen>0 || (!parmlen && (kc=='(' || kc=='['))) {
		if (*pinfo == 'N') {	/* �R�}���h */
			cl_cmd_init(cmd);
#if 1	/* 2023.8.11 */
			if ((cmd_type=cl_cmd_chk2(wkstr,&pcmd)) < 0) return cmd_type;
			else if (cmd_type == 9) {
				if (gpLabel) {
					if ((rc=_kugiri(y,M_KUGIRI,0,wrk,pinfo)) < 0) return rc;
				}
				gpCmd = pcmd;
			/*	strcpy(comstr,wkstr);	*/
				wkstr[parmlen-1] = '\0';
/*
printf("_kugiri: wkstr=[%s] cmd_type=%d\n",wkstr,cmd_type);
*/
				gpLabel = Strdup(wkstr);
				cl_cmd_init(cmd);
				clparmclr(y);
				return 0;
			}
#else
			pcmd = cl_cmd_chk(wkstr);
#endif
/*
printf("_kugiri: wkstr=[%s] at line=%d\n",wkstr,CLcList.line);
*/
			if ((cid=pcmd->cmdid) == C_UNKNOWN) {
				strcpy(comstr,"LET");
				pcmd = cl_cmd_chk(comstr);
				cmd->cid = cid = pcmd->cmdid;
				cmd->type = pcmd->type;
				cmd->rc  =  y->line;
				*pinfo = 'C';
				if (kc=='[' || kc=='(') return C_PARM_CONTINUE;
				if (rc=clparmsetopt(y,wkstr, parmlen,1)) return rc;
			}
			else {
				cmd->cid = cid = pcmd->cmdid;
				cmd->type = pcmd->type;
				cmd->rc  =  y->line;/*add 95.1.4 Koba*/
				*pinfo = 'C';
				strcpy(comstr,wkstr);
				if (kc == '(') return C_PARM_START;
				if ((cid==C_ELSE || cid==C_DEFAULT/* || cid==C_FINALLY*/) &&
				    (kc==' ' || kc=='\t' || kc=='\n')) {
					kc = M_KUGIRI;
				}
			}
		}
		else {	/* �p�����[�^ */
			no_kugiri = 1;
			cid = cmd->cid;
			if (cid==C_IF || cid==C_ELSEIF) {
				if (!stricmp(wkstr,"THEN")) {
					no_kugiri = 0;
					kc = M_KUGIRI;
				}
			}
			else if ((cid==C_LOOP/* || cid==C_FOR || cid==C_WHILE || cid==C_UNTIL*/) &&
			     !stricmp(wkstr,"DO")) {
				no_kugiri = 0;
				kc = M_KUGIRI;
				cmd->sub_cid = C_LOOP_DO;
			}
		/*
			else if (cid == C_TRY) {
				pos= akxnskipin(wkstr,strlen(wkstr)," \t");
				if (!cmd->prmnum && wkstr[pos]!='(') {
					if ((rc=_kugiri(y,M_KUGIRI,0,wrk,pinfo)) < 0) return rc;
					return _kugiri(y,kc,h,wkstr,pinfo);
				}
			}
		*/
			if (no_kugiri) {
				if (rc=clparmsetopt(y,wkstr,parmlen,1)) return rc;
			}
		}
	}
	cid = cmd->cid;
#if 1	/* 2023.8.11 */
	if (gpLabel && kc==M_KUGIRI && *pinfo=='N' && !parmlen) {
		strcpy(comstr,gpLabel);		/* tree�\���ŃR�}���h�Ƃ��ĕ\�������邽�� */
		strcat(comstr,":");
	/*	pcmd = cl_cmd_chk("LABEL");	*/
		cmd->cid = C_LABEL;
		cmd->type = gpCmd->type;
		cmd->rc  =  y->line;
		if (rc=clparmsetopt(y,gpLabel,strlen(gpLabel),1)) return rc;
		Free(gpLabel);
		gpLabel = NULL;
	}
#endif
	if (kc==M_KUGIRI && cid!=C_UNKNOWN) {
		if (cid==C_EXEC || cid==C_CALL) {
			if ((rc=_chk_heredoc(y)) < 0) return rc;
			else if (rc > 0) heredoc = 1;
		}
/*
printf("_kugiri: comstr=[%s] at line=%d\n",comstr,y->line);
*/
		if (rc = clparmset(y,"",0)) return rc;	/* ���[�N�G���A���Ō�ɕt���� */
		if (rc = clparmset(y,"",0)) return rc;	/* 2020.10.29 add */
		cmd->prmnum -= 2;				/* �p�����[�^���ɏ�L�͓���Ȃ� */
		if (rc = clparmset2(y)) return rc;
		cid = cmd->cid;
/*
printf("_kugiri: thenl_level=%d else_level=%d cmd_count=%d\n",
thenl_level,else_level,cmd_count);
*/
		y->cdl_label = gpLabel;

		if (rc = cl_syn_main(y)) {	/* ��͖؍쐬 */
			return rc;
		}
#if 1	/* 2023.8.11 */
		gpLabel = NULL;
#endif
		scno = cmd->sub_cid;
		if ((cid==C_LET || cid==C_DEFINE) && (scno==CS_OPTIONS || scno==CS_OPTION)) {
			cM_QUOTE1 = pGlobTable->Quot[0];
			cM_QUOTE2 = pGlobTable->Quot[1];
		}
		/* "end if" �́Acl_syn_main()�̒���C_ENDIF�ɕϊ������̂�cid���Đݒ肷�� */
		cid = cmd->cid;
/*
printf("_kugiri: comstr=[%s] at line=%d thenl=%d elsel=%d thenl_level=%d\n",
comstr,y->line,thenl,elsel,_get_if_level());
*/
		*pinfo = 'N';
		cl_cmd_init(cmd);
		clparmclr(y);
	}
	if (heredoc) rc = C_PARM_HEREDOC;
	else rc = 0;
	return rc;
}

/************************************/
/* _proc_prepro						*/
/************************************/
static int _proc_prepro(y,buf,pos,psspl,optc,sc_code)
condList *y;
char *buf;
int pos,sc_code;
SSPL_S *psspl;
char optc;
{
	static char *_fn_="_proc_prepro";
	SSP_S ssp;
	char word[BUFLEN],*wbuf;
	int len,buf_len,word_len,rc,i;
	cmdInfo *ycmd;

	if (!y || !buf || !psspl) return -1;

	ycmd = y->cmd;
	word_len = sizeof(word);
	wbuf = buf;
	buf_len = psspl->wdmax;
	ycmd->cid = C_PRAGMA;
	ssp.sp = pos;
	ssp.wd = word;
	if ((len=akxtgwsp(wbuf,&ssp)) > 0) {

DEBUGOUTL1(LEX_LOG_GROUP+122,"_proc_prepro: word=[%s]",ssp.wd);

		if (strcmp(word,"pragma")) {
			ERROROUT1("_proc_prepro: invalid command(%s).",word);
			rc = -1;
		}
		else {
			ycmd->sub_cid = 1;
			rc = _pragma(y,psspl,wbuf+ssp.sp,buf_len-ssp.sp,word,word_len);
			i = _skip_line(y,buf,psspl);
			if (i < 0) rc = ECL_END_OF_FILE;
		}
	}
	return rc;
}
#if 1	/* 2025.12.9 */
/************************************/
/* _pragma							*/
/************************************/
static int _pragma(y,psspl,wbuf,buf_len,word,word_len)
condList *y;
SSPL_S *psspl;
char *wbuf,*word;
int buf_len,word_len;
{
	XML_ATTR xmlattr[10];
	int ret,argc,opt,code_type;
	char *code_str;

	ret = 0;
	opt = SET_TYPE_OPT(psspl->code);
	argc = akxt_get_xml_attr(wbuf,buf_len,xmlattr,10,word,word_len,opt);
	if (code_str = akxt_get_attr_val("encoding",xmlattr,10,1)) {
		if ((code_type=akxc_get_code_num(code_str)) >= 0)
			psspl->code = code_type;
		else ret = code_type;
/*
printf("_pragma: code_type=%d\n",code_type);
*/
	}
	return ret;
}
#endif
/************************************/
/* _lex_clear						*/
/************************************/
static void _lex_clear(y)
condList *y;
{
	ParList2 parl;

	Free(y->rbuf);
/*
printf("_lex_clear: iListStack=%d sqp_lex_def=%08x xhp_lex_def=%08x\n",sqp_lex_def,xhp_lex_def);
*/
/*
	_PragmaStackInit(y);
	parl.option = 0x01;
	_get_def_cont(NULL,NULL,0,0,&parl,0,0,NULL,NULL);
*/
}
