char version[] ="@(#) ***[V/R=1.2.0 (mini)]***";

