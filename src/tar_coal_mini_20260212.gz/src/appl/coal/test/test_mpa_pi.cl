//
//def const NARABI=0;
//def const USE_SQRT=0;
NARABI = %1;
USE_SQRT = %2;
//option 17 1;
option 20 17;
//define decimal aa[4];
proc main;
// initialize
print NARABI USE_SQRT;
	a = 1.0;
	b = 1.0/u_sqrt(2.0);
	t = 0.25;
	p = 1.0;

	d_b = 10.0;
	i = 1;
//	x = (a+b)**2/(4*t);
	x = a + b;
	x = (x*x)/(t*4.0);
	print i++ x;

// run
	loop 20;
		x_b = x;
if NARABI;
//print /p+5 a b t p;
		[a,b,t,p] = update(a,b,t,p);
else
		update(a,b,t,p);
		a = $1;
		b = $2;
		t = $3;
		p = $4;
endif;
//		x = (a+b)**2/(4*t);
		x = a + b;
		x = (x*x)/(t*4.0);
		print i++ x;
		d = x_b - x;
		print /p+30,2 d;
		if abs(d)<=1.0e-50 then break;endif;
	end loop;
	print /c- 0 x;
	print PI2;
	return $ERROR;
end proc;

// update algorithm
function update(a, b, t, p);
//	new_a = (a+b)/2.0;
	new_a = (a+b)*0.5;
	new_b = u_sqrt(a*b);
//	new_t = t-p*(a-new_a)**2;
	new_t = a-new_a;
	new_t = t-p*new_t*new_t;
//	new_p = 2.0*p;
	new_p = p+p;
if NARABI;
//print new_a new_b new_t new_p;
	return [new_a,new_b,new_t,new_p];
else
	$1 = new_a;
	$2 = new_b;
	$3 = new_t;
	$4 = new_p;
	return 0;
endif;
end func;

function u_sqrt(b);
if USE_SQRT;
	return sqrt(b);
else
	x0 = b;
	if (x0 > 0) then
		if (x0 >= 4) then x0 *= 0.5;endif;
		loop 10;
			d = ((y=x0*x0)-b)/(x0+x0);
			x0 -= d;
//print i x0;
			if (abs(d) <= 1.0e-50) then break;endif;
		end loop;
		if (y > b) then x0--; endif;
	end if;
endif;
	return x0;
end func;
