//
// ���͂����P��̐����q�X�g�O����(�x�����z�})�ɂ��ďo�͂���
// �q�X�g�O�����͉��ɏ��������ȒP�����A�c�����ɒ��킵�Ă݂�̂��悢
//
def const YES = 1;
def const NO  = 0;

option 1 1;

//def reg[100];
//def num[100];
def const ireg = 101;
def const inum = 201;
def max_reg;
def max_len;

proc main;
	int  nl, nw, nc, inword;
	char c,word;

	call << EOF1;
abc 2234 ff abc ff
xyz	sd234 sssss d ff
EOF1
	inword = NO;
	nl = nw = nc = 0;
	max_reg = 0;
	max_len = 0;
	word = '';
	loop;
		if !(c = getchar());
			break;
		end if;
//putchar(c);
		nc++;
		if c == '\n';
			nl++;
		end if;
		if c == ' ' || c == '\n' || c == '\t' || c == '�@';
			inword = NO;
			print word;
			regist(word);
			word = '';
		elseif inword == NO;
			inword = YES;
			nw++;
			word = c;
		else
			word &= c;
		end if;
	end loop;
	if word;
		print word;
		regist(word);
	end if;
	print nl nw nc;
	print max_reg *reg *num;
	hist();
	print;
	hist_tate();
	return ERROR;
end proc;

func regist(word);
	if w=in(word,$()+ireg-1) ;
		split(w,1);
		$2 -= ireg-1;
print w $1 $2;
//		num[$2-1]++;
		$(inum+$2-1)++;
//		$(inum+$2-1) += 1;
	else
//		reg[max_reg] = word;
		$(ireg+max_reg) = word;
//		num[max_reg] = 1;
		$(inum+max_reg) = 1;
		max_reg++;
		len = lenw(word);
		if len>max_len ;
			max_len = len;
		end if;
	end if;
	return ERROR;
end func;

func hist();
	i = 0;
	loop max_reg;
//		printf('%s %s\n',lpad(reg[i],max_len),strings('*',num[i]));
		printf('%s %s\n',lpad($(ireg+i),max_len),strings('*',$(inum+i)));
		i++;
	end loop;
	return ERROR;
end func;

func hist_tate();
	maxh = max($()+inum-1);
	h = maxh;
	loop;
		if h <= 0;
			break;
		end if;
		hh = '';
		i = 0;
		loop max_reg;
			c = ' ';
			if $(inum+i) >= h;
				c = 'H';
			end if;
			hh &= c & ' ';
			i++;
		end loop;
		printf('%s\n',hh);
		h--;
	end loop;
	print;
	h = 1;
	loop max_len;
		hh = '';
		i = 0;
		loop max_reg;
			c = substr($(ireg+i),h,1);
			if c == '' ;
				c = ' ';
			end if;
			hh &= c & ' ';
			i++;
		end loop;
		printf('%s\n',hh);
		h++;
	end loop;
	return ERROR;
end func;
