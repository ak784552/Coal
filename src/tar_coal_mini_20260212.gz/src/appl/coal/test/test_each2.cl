//
proc main;

//	print /d (1,2,3,4,5,6,7,8,9);

//	for each x in 1,2,3,4,5,6,7,8,9;
	xx = [1,2,3,4,5,6,7,8,9];
	i = 0;
	loop countv(xx);
		x = xx[i++];
		print x;
	end loop;
	return ERROR;
end proc;
