//
//	../coal test_xml3 '' Update.xml
//
on <?> ip procX-1; //ip procX-2 ip procX-3;
on <!> ip procD-1; //ip procD-2 ip procD-3;
on <> ip procT-1 ip procT-2 ip procT-3;
on <update> IP p-1 IP p-2 IP p-3;
on <fileEnable> IP p-1 IP p-2 IP p-3;
on <default> IP p-1 IP p-2 IP p-3;
on <basicInfo> IP p-1 IP p-2 IP p-3;
on <userAgent> IP p-1 IP p-2 IP p-3;
on <download> IP p-1 IP p-2 IP p-3;
on <message> IP p-1 IP p-2 IP p-3;
on <condition> IP p-1 IP p-2 IP p-3;
on <os> IP p-1 IP p-2 IP p-3;
on <toolbar> IP p-1 IP p-2 IP p-3;
on <browser> IP p-1 IP p-2 IP p-3;
on <additional> IP p-1 IP p-2 IP p-3;
on <basicInfo> IP p-1 IP p-2 IP p-3;
on <partner> IP p-1 IP p-2 IP p-3;
proc main;
//	try;
		cnt = 0;
		fp = 0;
		if %1;
			$1 = %1;
		elseif %2;
			if (fp = fopen(%2,'rb'));
				fpstat(fp,1);
print $9;
				$1 = FELREAD1(fp,1,$9);
			else;
				return ERROR;
			end if;
		end if;
		print $1;
		exec ep 'inputXML' $1;
//	catch;
//		print EXCEPTION ERRNO ERRMSG;
//	finally;
//		print EXCEPTION ERRNO ERRMSG;
		if (fp); fclose(fp); endif;
//	end try;
	return ERROR;
end proc;

proc print1 (a);
	echo "'*** ' & a";
	i = 1;
	loop %0;
		printf '%%%d = %s' $i %$i;
		i++;
	end loop;
//	1/0;
	return $ERROR;
end proc;

proc p-1;
	exec ip print1 'p-1';
	return $ERROR;
end proc;

proc p-2;
	exec ip print1 'p-2';
	return $ERROR;
end proc;

proc p-3;
	exec ip print1 'p-3';
	return $ERROR;
end proc;

proc procX-1;
	exec ip print1 'procX-1';
	return $ERROR;
end proc;

proc procD-1;
	exec ip print1 'procD-1';
	return $ERROR;
end proc;

proc procT-1;
	exec ip print1 'procT-1';
	return $ERROR;
end proc;

proc procT-2;
	exec ip print1 'procT-2';
	return $ERROR;
end proc;

proc procT-3;
	exec ip print1 'procT-3';
	return $ERROR;
end proc;
