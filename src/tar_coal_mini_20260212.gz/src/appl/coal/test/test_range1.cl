//
//option 20 20;
def x 10;
proc main;

	print a=range(1,10);
	print a *a;
	print a=range(1,10,2);
	print *a;
	print *range(10,1,-2);

	print b=range(1.2f,3.5f);
	print *b;
	print b=range(1.4f,8.9f,3.2f);
	print *b;
	print *range(9.4f,3.9f,-2.5f);

	print c=range(1.5,3.4);
	print *c
	print c=range(1.5,8.8,3.1);
	print *c;
	print *range(10.5,3.8,-2.5);

	print d=range('A','C');
	print *d;
	print d=range('A','I',3);
	print *d;
	print *range('Z','H',-3);

	print e=range(SYSDATE,SYSDATE+2);
	print *e;
	print e=range((DATE)'2021/06/05',(DATE)'2021/12/06','M 2');
	print *e;
	print *range((DATE)'2030/06/05',(DATE)'2021/12/06','Y-2');

	print "a=1 .. 5";
	print *a;
	print "a=1 .. 5 .. 3";
	print *a;
	print b=1.2f..3.5f;
	print *b;
	print b=1.4f..8.9f..3.2f;
	print *b;

	print c=1.5..3.4;
	print *c
	print c=1.5..8.8..3.1;
	print *c;

	print d='A'..'C';
	print *d;
	print d='A'..'I'..3;
	print *d;

	print e=SYSDATE..(SYSDATE+2);
	print *e;
	print e=(DATE)'2021/06/05'..(DATE)'2021/12/06'..'M 2';
	print *e;

	print range(x,abs);

	print a=range(1r,10) /i a;
	print a=range(1,2/10r) /i a;
	print a=range(1r,10r) /i a;

	print a=1r..10 /i a;
	print a=1..2/10r /i a;
	print a=1r..10r /i a;

	return ERROR;
end proc;
