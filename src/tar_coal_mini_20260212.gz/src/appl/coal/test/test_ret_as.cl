//
/*
type struct aaa
	int a,
	char(6) b;
*/
proc main;

	print func1(1.1,2.2,3.3,4.4);
	print func2(1.1,2.2,3.3,4.4);
	print func3(1.1,2.2,3.3,4.4);
/*
	print *func4(1.1,2.2,3.3,4.4);
*/
	return ERROR;
end proc;

function func1(a,b,c,d);
	return [a+1,b+2,c+3,d+4,10];
end func;

function func2(a,b,c,d) as aaa;
	return a+11,b+12,c+13,d+14,20;
end func;

function func3(a,b,c,d) as int;
	return [a+1,b+2,c+3,d+4,10];
end func;
/*
function func4(a,b,c,d);
	dim x as aaa;
	x.a = a;
	x.b = b;
	return x;
end func;
*/
