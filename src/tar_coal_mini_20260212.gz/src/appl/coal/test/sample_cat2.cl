//
// �t�@�C����A������
//
option 7 +0x20;
proc main argc ();
	if argc == 0 then		// �������Ȃ���΁A�W�����͂��R�s�[
		filecopy(STDIN);
	else
		loop argc;
			if !(fp = fopen(%1,'r')) then
				printf('cat: can''t open %s\n', %1);
				break;
			else
				filecopy(fp);
print ERROR ERRMSG;
				if ERROR && ERROR<>CLEOF then
					printf('cat: %s\n', ERRMSG);
					break;
				end if;
				fclose(fp);
				shift;
			end if;
		end loop;
	end if;
	return ERROR;
end proc;

function filecopy(fp);
/*
	while putline(fgetline(fp));
	end while;
*/
/*
	loop;
		line = fgetline(fp);
print ERROR ERRMSG line;
		if ERROR then
			break;
		end if;
		putline(line);
	end loop;
*/

	loop;
		putline(fgetline(fp));
//print ERROR ERRMSG;
		if ERROR then
			break;
		end if;
	end loop;

	return ERROR;
end func;
