//
// �t�|�[�����h�d��v���O����
//
//option 24 1;
define const char NUMBER = '0'; /* �������������Ƃ����M�� */
define const int  MAXVAL = 100;	/* val�X�^�b�N�̍ő�[�� */
	
define val = $() + 1;		//[MAXVAL];	/* �l�̃X�^�b�N */
define s = val + MAXVAL;	//[1]

int sp = 0;	/* �X�^�b�N�E�|�C���^ */

proc main;
	char $type;
	double op2;

//	while ($type = getop(s)) != '';
	loop;
		if ($type = getop(s)) == ''; break; end if;
		switch $type;
		case NUMBER;
			push(s[0]);
			break;
		case '+';
			push(pop() + pop());
			break;
		case '-';
			push(pop() - pop());
			break;
		case '*';
			push(pop() * pop());
			break;
		case '/';
			op2 = pop();
			if op2 == 0.0;
				putline('zero divisor poped');
			else
				push(pop() / op2);
			end if;
			break;
		case '=';
			putline('\n',push(pop()));
			break
		case 'c';
			clear();
			break;
		default;
			putline('unknown command ', $type, '\n');
			break;
		end switch;
	end loop;
	return ERROR;
end proc;

function push(double f) as double;
	if sp < MAXVAL;
		return val[sp++] = f;
	else
		putline('error: stack full');
		clear();
		return 0;
	end if;
end func;

function pop() as double;
	if sp > 0;
		return val[--sp];
	else
		putline('error: stack empty');
		clear();
	return 0;
	end if;
end func;

function clear();
	sp = 0;
	return 0;
end func;

function getop(s);	 /* ���̉��Z�q���邢�͔퉉�Z�������߂� */
	int i;
	char c, line;

	line = getline();
	i = 1;
//	while (c = substr(line, i, 1)) == ' ' || c == '\t' || c == '\n' ;
	loop;
		if !((c = substr(line, i, 1)) == ' ' || c == '\t' || c == '\n'); break; end if;
		i++;
	end loop;
	s[0] = substr(line, i);
//print s[0];
	if c == '.' || (c >= '0' && c <= '9');
		return NUMBER;
	else
		return c;
	end if;
end func;
