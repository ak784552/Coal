//
// echo
//
proc main argc argv;
//	for (i=0; i < argc; i++);
	i=0;
	loop argc;
		printf('%s%c', %argv[i], (i==argc-1) ? '\n' : ' ');
//	end for;
		i++;
	end loop;
	return ERROR;
end proc;
