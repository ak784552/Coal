//
/*
define xa[10] = 1,2,3,4,5,6,7,8,9,10;
define xb[10] =[1,2,3,[4,5,[6,7]],8,9,10];
define xc[10] =(1,2,3,(4,5,(6,7)),8,9,10);
*/
proc main;
/*
	print *xa;
	print *xb;
	print *xc;
	xc[0] = 20;
	print *xc;
	for each x in 1,2,[3,4],5;
		print *x;
	next;
	for each y in [1,2,[3,4],5];
		print *y;
	next;
*/
	print [100,200];
//	a = [100,200,y];
//	print a;
//	{[100,200,y]};
	print [100,200,y];
//	{x} = [1,2];
	print x;
	[a] = [1,2];
	print a;
	a = 11, b = 12, c = 13;
	print a b c;
//	[d,a+1]=100;
	print a d;
	[[a,b],c] = [3,[4,5]];
//	[[a,b],c] = 3;
	print a b c;
	[a,b,c] = [6,7,8];
	print a b c;
	[a,b,c] = [8];
	print a b c;
	[a,b,c] = 'A';
	print a b c;
	[a,b,c] = 'B','C';
	print a b c;
	[a,b] = [9,10,11];
	print a b c;
	a = 111, b = 112, c = 113;
	print a b c;
	print [1,2,3]+[4,5,6];

	w = func1([1,2,3,4,5]);
	exec ip proc1 *[1,2,3,4,5];

	z = [x1,y1] = [10,20];
	print z x1 y1;
	z = [100,200,300];
	print z x1 y1;
	z1 = {'A','B'};
	z1 = {'X','Y','Z'};
	print z1 /i z1;
	z1 = ['X','Y','Z'];
	print z1 /i z1;

	{a,b,c} = {6,7,8};
	print a b c;
	{a,b,c} = [6,7,8];
	print a b c;

	[x1,y1] = [x2,y2];

	return ERROR;
end proc;

func func1(x);
	print 'func1' x;
	return ERROR;
end func;

proc proc1(x);
	print 'proc1' x;
	return ERROR;
end proc;
