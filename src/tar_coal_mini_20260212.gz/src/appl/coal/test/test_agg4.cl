//
//def a 10 = [1,2,3,4,5,6,7,8,9,10];
//def b 10 = [11,2,13,4,15,6,17,8,19,10];
proc main;
	a = $() + [0,10];
	b = $() + [10,10];
	setarray(a,2,1,2,3,4,5);
	setarray(b,0,11,2,13,4,15,6,17,8,19,10);
	print $() *$();
//	$7 = 7;
	print a *a;
	print b *b;

	print *(*a+*b);
	print *(*a|*b);
	print *(*a-*b);
	print *(*a&*b);

	print *(100|*b);

	print *a;
	print a[2..5] *a[2..5];
	print b[1..10..2] *b[1..10..2];

	print *(*a[2..5]|*b[1..10..2]);

	print *(*a[2..5]|*b);
	print *(*a[2..5]&*b);

	aa = a;
	print aa *aa;
	c = *a[2..5];
	print c *c;

	x = {1,2,3,4,5,6};
	print x[2..4];
	y = {11,2,13,4,15,6};
	print (100|y);
	print (y|100);

	print (x[2..4]|y);
	print (x[2..4]&y);

	xx = [1,2,3,4,5,6];
	print xx[2..4];
	yy = [11,2,13,4,15,6];
	print (100|yy);
	print (yy|100);
	print (xx[2..4]|yy);
	print (xx[2..4]&yy);

	print (x|yy);
	print (xx|y);

	return ERROR;
end proc;
