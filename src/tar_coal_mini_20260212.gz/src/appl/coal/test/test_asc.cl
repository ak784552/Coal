//
PROC main;
	print ' ' asc(' ');
	setarray(1,0, **('A'..'Z'));
	i = 1;
	loop countv($());
		print i $$i asc($$i);
		i++;
	end loop;
	i = 0;
	loop 256;
		a = chr(i++);
		print /nq- edit('%03d',i) /q+ iif(is(a,'A'),a,'not ascii');
	end loop;
	RETURN $ERROR;
END PROC;
