//
//option 20 20;
proc main;
	print date_add('s',3661,'0000/00/00 00:00:00');
	print date_add('s',14009,'');
	print add_to_date('0000/00/00 00:00:00','s',3661);
	print add_to_date('','s',14009);

	print TO_DATE('');
	print TO_DATE('2014/05/10');
	print TO_DATE('20140510');
	print TO_DATE('14/05/10');
	print TO_DATE('2014/05');
	print TO_DATE('140510');
	print TO_DATE('14/05');
	print TO_DATE('2014');

	a = SYSDATE;
	print a;
	b = SYSDATE + 1;
	print b;
	if a <> b then print 'a <> b';endif;
	print "a == b";
	print "a == TO_DATE('2014/05/10')";
	print "a > TO_DATE('2014/05/10')";
	print "a MAX TO_DATE('2014/05/10')";
	print "a MIN TO_DATE('2014/05/10')";

	print "1.2 MAX 2.4";
	print "1.2 MIN 2.4";
	print "MAX(1.2,2.4,0.5)";
	print "MIN(1.2,2.4,0.5)";
	print "MAX('1.2','2.4','0.5')";
	print "MIN('1.2','2.4','0.5')";

	print "MAX(a,TO_DATE('2014/05/12'),TO_DATE('2015/05/10'))";
	print "MIN(a,TO_DATE('2014/05/08'),TO_DATE('2013/05/10'))";

	print CBIN(SYSDATE);
	print CDBL(SYSDATE);
	print CDEC(SYSDATE);
	print CBULK(SYSDATE);
	print TO_BULK(SYSDATE);
	print TO_BULKS(SYSDATE);
	print /x4 SYSDATE;
	print /x 1.23456789;

//	c = TO_DATE('2014/05/10');
	c = to_date('100/01/01','yyy/mm/dd');
	print date_diff('y',a,c);
	print date_diff('m',a,c);
	print date_diff('d',a,c);
	print date_diff('h',a,c);
	print date_diff('mi',a,c);
	print date_diff('s',a,c);
	print date_diff('q',a,c);
	print date_diff('ww',a,c);

	return ERROR;
end proc;
