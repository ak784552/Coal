//
//define array ulong a 10;
//define array dec(10,2) $dec 10;
proc main;

	$1 = 1;
	print ++$1 $1++;
/*
	a[0] = 1;
	print ++a[0] a[0]++;
	$dec[0] = 1.0;
	$dec[1] = ++$dec[0];
	print ++$dec[0] $dec[1];
	print $dec[0]++ $dec[0];

	uint x = 1;
	print x++;
	$dec[0] = 1.0;
	print $dec[0]++;

	ulong i = 2;
	print i++ i;
*/
	$1 = 1;
	print --$1 $1--;
/*
	a[0] = 1;
	print --a[0] a[0]--;
	$dec[0] = 1.0;
	$dec[1] = --$dec[0];
	print --$dec[0] $dec[1];
	print $dec[0]-- $dec[0];
*/
//	uint x = 1;
	x = 1;
	print x /i x;
	x += 1;
	print x /i x;
	print x-- x /i x;
	print x-- x /i x;
	print x-- x /i x;

//	ulong i = 2;
	i = 2;
	print i++ i /i i;
/*
//	uint x = 1;
	x = ULONG_MAX;
	print x ++x /i x;

	xx = x;
	print xx /i xx;
	print xx ++xx /i xx;
*/
	y = LONG_MAX;
	print y ++y y /i y;
	y = LONG_MIN;
	print y --y y /i y;

	long z = LONG_MAX;
	print z ++z z ;
	z = LONG_MIN;
	print z --z  z /i z;

	yy = '2147483647';
	print yy ++yy yy /i yy;

	char cy = '2147483647';
	print cy ++cy cy /i cy;

	return ERROR;
end proc;
