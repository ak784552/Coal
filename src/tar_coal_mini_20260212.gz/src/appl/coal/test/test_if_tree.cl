//
option 24 1;
//def x 10;
proc main;
//	char c;

	a = -2;
	b = 2;
	c = 3;
	d = 4;
	print a b c d;

	i=2;
	line = 'XA C';
//	if 10 then
//	if !10 then
//	if %1 then
//	if a=1 then
//	if 1,2,3 then
//	if (1,2,3) then
//	if {1,2,3} then
//	if [1,2,3] then
//	if (c=[1+1,2+2,3]) || (d={1+1,2}) then
//	if abs(-1) then
//	if abs(1-1) then
//	if abs((-1+2)*3) then
//	if abs((-1+2)*3)-21 then
//	if 1+xx[3,1] then
//	if abs((-1+2)*3)+xx[2+0,1] || 1 then
//	if abs((-1+2)*3)+xx[2,1]-23 then
//	if (-b > 0) then
//	if (a==1 or b>0) && (c<10 or d<>0) then
//	for i=1 to 2;
//		if 1..3 then
//	if (n=abs(-1)) then
//	if (n=abs(a))<10 then
//	if x = ndef('xx[0]','NULL') then
//	if x = nval('','NULL') then
//	if x = iif(xx[0]==0,100,200) then
//	if (c=xx[i])==' ' || c=='A' || c=='\n' then
//	if (c=xx[0,i-1]) then
//	if (c=substr(line,i,1+2))==' ' || c=='A' then
//	if (c=concat(line,i,2))==' ' || c=='A' then
//	if (c=concat(line,i+1,2))==' ' || c=='A' then
//	if (c=concat(line,i,1+2))==' ' || c=='A' then
//	if (c=concat(line & 'A',i,1))==' ' || c=='A' then
//	if (c=concat(line,i+1,1+2))==' ' || substr(c,2,1)=='A' then
//	if concat(line,i+1,1+2)==' ' || c=='A' then
//	if (c=substr(line,i,1))==' ' || c=='A' then
//	if c = a+2 || d then
	if ((c = (a+2))) && (e=(b+3,d+4)) then
//	if a>1, b>1 then
//	for (i=0; (c=xx[i])==' ' || c=='\t' || c=='\n'; i++);
//		if 1 then
			print i '<>0.0' c n;
		else
			print i '==0.0' c n;
		end if;
//	end for;

	return ERROR;
end proc;
