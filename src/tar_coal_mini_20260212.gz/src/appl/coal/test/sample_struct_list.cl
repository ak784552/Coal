//
//
//
typedef struct FAMILY
	     fa_next,	  // ���̉Ƒ��̃����o������
	int  fa_zokugara,  // 0:�{�l, 1:�z���, 2�`:�q
	char fa_name,
	char fa_furi,
	char fa_sex,
	char fa_birth;

FAMILY family_list,f;
int name_count = 0;

proc main;
	set_family(family_list);
	fnext = family_list;
	loop 10;
		set_family(f);
		if $ERROR thenl break;
		fn = next_name();
		$(fn) = *f;
		set_next(fnext,$(fn));
		fnext = fnext.fa_next;
	end loop;

	fnext = family_list;
	loop 5;
		print_family_member(fnext);
		if fnext.fa_next == '' thenl break;
		fnext = fnext.fa_next;
	end loop;
	return ERROR;
end proc;

function set_family(f);
	printf('Enter next family mamber:');
	line = getline();
	getargs(line,1);
	f.fa_next = '';
	f.fa_zokugara = $1;
	f.fa_name = $2;
	f.fa_furi = $3;
	f.fa_sex = $4;
	f.fa_birth = $5;
	return ERROR;
end func;

function set_next(f,fnext);
	f.fa_next = fnext;
	return ERROR;
end func;

function next_name();
	return 'f' &+ name_count++;
end func;

function print_family_member(f);
	printf('%3d %s %s %s %s\n',
		   f.fa_zokugara, f.fa_name, f.fa_furi, f.fa_sex, f.fa_birth); 
	return ERROR;
end func;
