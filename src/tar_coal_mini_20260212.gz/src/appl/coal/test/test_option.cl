//
//define option 1 2;
//option 1 2;
//option 1 '2.5.1';
option 2 4;
//define array $a 10;
PROC main;
//	print 1.2.2.2;
//	option 4 1.2.3;
	print '*** no set option';
	print $a[0] $1 $x;

	print '*** option 1 1';
	option 1 1;
	print $a[0] $1 $x;

	print '*** option 1 2';
	option 1 2;
	print $a[0] $1 $x /i x;

//	print '*** undef a';
//	undef a;
//	print $a[0] $1 $x;

	undef x;
	print '*** undef x';
	print '*** option 1 0x12';
	option 1 0x12;
	print $a[0] $1 $x;

	RETURN $ERROR;
END PROC;
