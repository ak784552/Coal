//
//option 17 1;
//option 11 0x40;
//option 20 30;
proc main;

	echo sqrt(%1+0);
//	echo round(sqrt(%1+0),49,0x10);
//	echo edit('%.15e',sqrt(%1+0));
	echo u_sqrt(%1+0);
//	dec(20,15) x = u_sqrt(%1+0);
//	echo x;
	return $ERROR;
end proc;

function u_sqrt(b);
	if is(b,'T')==3 then
		GOSA = 1.0e-15;
		KETA = 0;
	else
		GOSA = 1.0E-50;
		KETA = 48;
	endif;
	x0 = b;
//echo x0;
	if (x0 > 0) then
//		(x/2)**2-x>=0	x**2-4x>=0	x(x-4)>=0	x>=4
//		if (x0 >= 4) then x0 *= 0.5;endif;
		if (x0 >= 4) then x0 /= 2.0;endif;
print x0;
		i=1;
		loop 40;
//		while (d=((y=x0*x0)-b)/(x0+x0)) do
			d = ((y=x0*x0)-b)/(x0+x0);
print /p+20Z,2 d;
//print y;
			x0 -= d;
print i x0;
			if (abs(d) <= GOSA) then
				if KETA>0;x0+=5.0*GOSA;endif;
				break;
			endif;
			i++;
		end loop;
print /p+20Z,2 d;
//print y;
//		if (y > b) then x0--;endif;
	end if;
//logparm 2 2 200;
	if KETA>0;x0 = round(x0,KETA,0x10);endif;
	return x0;
end func;
