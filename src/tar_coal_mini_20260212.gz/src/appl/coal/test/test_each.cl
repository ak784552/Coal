//
proc main;
//	let options 0 0 1;

	loop each $x in FL('LIST',1,2,,'A');
		print x;
	end loop;

	$11 = 'AA';
	$20 = 'ZZ';
	loop each $x in $();
		print x;
	end loop;

	loop each $x in %();
		print x;
	end loop;

	loop each $x in #();
		print x;
	end loop;

	for each $x in 'B';
		print x;
	next;

//	for each $x in {1,2,3,4,5,'A','B'},'C' do
//	for each $x in {1,2,3,4,5,'A','B'} do
	xlist = {1,2,3,4,5,'A','B'};
	for each $x in xlist do
		print x;
//		x = 0;
//		break;
	next;
//	end do;
	return ERROR;
end proc;
