//
//
//
define const int EOF = -1;
char buf = '\0';
int  pos = 1;

proc main;
	int n;

	loop;
		if getint(&n) == EOF; break; end if;
		print n;
	end loop;
	return ERROR;
end proc;

function getint(pn);	/* ���͂�莟�̐��������o�� */
	int rc, sign;
	char c;

//	while (c=getch())==' ' || c=='\n' || c=='\t';	/* �󔒕������X�L�b�v */
//	end while;
	loop;
		if !((c=getch())==' ' || c=='\n' || c=='\t'); break; end if;	/* �󔒕������X�L�b�v */
	end loop;

	sign = 1;
	if c=='+' || c=='-' ;
		sign = (c=='+') ? 1 : -1;	/* �����Z�b�g */
		c = getch();
	end if;
//	for (*pn=c; c>='0' && c<='9'; c=getch());
	*pn=c;
	loop;
		if !(c>='0' && c<='9'); break; end if;
		c=getch();
print c;
		*pn = 10 * *pn + c;	 /* �����ϊ� */
	end loop;
	*pn *= sign;
print *pn;
	if c<> '' then
		rc = 0;
	else
		rc = EOF;
	end if;
	return rc;
end func;

function getch();
	c = substr(buf, pos++, 1);
//	while c  == '' || c == '\n';
	loop;
		if !(c == '' || c == '\n'); break; end if;
		buf = getline();
		if ERROR ; return ''; end if;
		pos = 1;
		c = substr(buf, pos++, 1);
print buf c;
	end loop;
print pos c;
	return c;
end func;
