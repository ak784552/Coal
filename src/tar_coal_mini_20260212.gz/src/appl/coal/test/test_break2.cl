//
proc main;
	x = %1+0;
	$i = 0;
	loop 3 as lp1;
		print 'loop1 $i=' $i;
		loop 2 as lp2;
			print 'loop2 $i=' $i;
			if $i == 1 then
				if x == 0 then
					print 'break lp1';
					break lp1;
				elseif x == 1 then
					print 'break ''lp1''';
					break 'lp1';
				elseif x == 2;
					print 'break 2';
					break 2;
				elseif x == 3 then
					print 'break 1.5f';
					break 1.5f;
				elseif x == 4 then
					print 'break 1.5';
					break 1.5;
				elseif x == 5 then
					print 'break to_bulk(1)';
					break to_bulk(1);
				elseif x == 6 then
					print 'break $SYSDATE';
					break $SYSDATE;
				else
					print 'contonue lp1';
					continue lp1;
				end if;
			end if;
			$i++;
		end loop;
	end loop;
	return $ERROR;
end proc;
