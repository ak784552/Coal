//
//define aa[5];
proc main;
	print gettime(0);
	loop %1;
//		a = 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10;
//		a = 1 * 2 * 3 * 4 * 5 * 6 * 7 * 8 * 9 * 10;
//		a = 1.0 * 2.0 * 3.0 * 4.0 * 5.0 * 6.0 * 7.0 * 8.0 * 9.0 * 10.0;
//		10**10;
//		10.0**10;
//		10.0d**10;
//		10.0**10.0;
		2**20;
	end loop;
	print gettime(0);
	print getmemused(1,5) *$();
	return ERROR;
end proc;
