//
define const int YES=1;
define const int NO =0;
proc main;		/* ���͒��̍s�A�P��A�����̃J�E���g */
	int  nl, nw, nc, inword;
	char c;

	inword = NO;
	nl = nw = nc = 0;
	loop;
		if !(c = getchar());
			break;
		end if;
//putchar(c);
		nc++;
		if c == '\n';
			nl++;
		end if;
		if c == ' ' || c == '\n' || c == '\t' || c == '�@';
			inword = NO;
		elseif inword == NO;
			inword = YES;
			nw++;
		end if;
	end loop;
	print nl nw nc;
	return ERROR;
end proc;
/*
func getchar();
	return elread1(1,1);
end func;
*/
