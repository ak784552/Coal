//
proc main;
	loop 3 + 1 as LL;
		print 'AA';
	end loop;
	return ERROR;
end proc;
