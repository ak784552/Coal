//
/*
//def a 10 = [1.0,2.0,3.0,4.0];
def a 10 = [1,2,3,4];
def b 10 = [1.5,2.3];
def c 10 = [5.5,6.3,7];
def d 10 = ['A','B','C',''];
*/
proc main;

	print max(1,2,3,4,5) min(1,2,3,4,5);
//	print max(a);
//	print max(a,b) min(a,b);

//	x = {1.0,2.0,3.0};
	x = {1,2,3};
//	y = [2.5,3.5,'0.5',c];
//	y = [2.5,3.5d,'0.5',c];
	y = [2.5,3.5d,'0.5'];
	print max(x,y) min(x,y);
//	print max(x,y);
	print sum(x,y);

	z = ['W','X','Y'];
	y = ['A','B','C'];
	x = {'1','2','',z};
	print max(x,y) min(x,y);

	print sum(1,2,3,4,5) avg(1,2,3,4,5);
//	print sum(a,b,c) avg(a,b,c);
	print sum(*(1..10)) avg(*(1..10));
	print max(abs) max(,);
	print min(abs) min(,);
	print sum(abs) sum(,);
	print avg(abs) avg(,);

	y = [1,2,3];
	x = {10,20,0,30};
	print max(x,y) min(x,y);
	print max(d) min(d);

	print "1 sum 2";
	print "1 avg 2";
	print ecmd('BEXP $1 = 1 sum 2 3 4 5;') $1;
	print ecmd('BEXP $1 = 1 avg 2 3 4 5;') $1;

	print max(SYSDATE,SYSDATE+10) min(SYSDATE,SYSDATE+10);
	print max(SYSDATE,'2021/08/10') min(SYSDATE,'2021/08/10');
	print sum(SYSDATE,'2021/08/10') avg(SYSDATE,'2021/08/10');

	print max(SYSDATE,'2021/130/10') min(SYSDATE,'2021/060/32');

	return ERROR;
end proc;
