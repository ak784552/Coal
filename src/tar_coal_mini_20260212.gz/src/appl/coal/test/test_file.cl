//
/*
define x 10;
define type struct s
	int a,
	char(5) b;
define var xx as s;
*/
proc main;
//	print elwrite1(x);
//	print elwrite1(xx);
	putline('aaaaaa',123d0);
	$a = 100;
	$b = 25.3;
	$c = 'ABCDEF';
	$r = elwrite($a,$b,$c,'\n');
	putline($r,ERROR,ERRMSG);
//	$r = getline();
//	putline($r);
	print "elwrite1(`print x`)";

	$c = 'ABCDEF';
	`print c`;
//	p = `print c`;
//	print p;

	return $ERROR;
end proc;
