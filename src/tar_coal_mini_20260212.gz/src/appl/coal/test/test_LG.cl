//
//define global gg = 'AA';
//define array a 10;
//define array int x 10=1,2,3,4,5,6,7,8,9,10;
//define array long xl 10=101,102,103,104,105,106,107,108,109,110;
proc main;
//	print x *x;
//	print xl *xl;
//	option 10 1;
	exec ip sub1;
//	print a;
	print a la ga lb gb gg;
//	private	x[0] = 21;
//	private	xl[0] = 121;
//	xx = x;
	xx = 1;
//	x++;
	print x-1;
	xx--;
	print xx *xx;
//	local x = 10;
//	local xl = 110;
//	print "private x[0]";
//	print "private xl[0]";
	print x /i x;
	print xl /i xl;
	return ERROR;
end proc;

proc sub1;
//local xa[20];
private	a = 1;
private	a = 2;
	a = 3;
//	array gg 10;
//	gg[0] = 'GG';
//local	gg = 'BB';
//global	gg = 'CC';
//global	gg = gg &+ 1;
/*
	local la = a + 2;
	global ga = a + 3;
	local lb = la + ga;
	global gb = la + ga;
	print a la ga lb gb;
	print gg gg[0];
//	const
	x[0] = 1;
*/
	return ERROR;
end proc;
