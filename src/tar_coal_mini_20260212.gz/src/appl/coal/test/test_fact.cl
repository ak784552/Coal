//
//define nn = 2;
proc main;
	$1 = %1 + 0;
	n = fact($1);
	print n;
/*
p = %3 + 0;
if p==2 then
	option 16 %2;
	n=%1+0;
	x=%1+0;
//	while (--n > 1) do;
	loop;
		if (--n <= 1); break; endif;
		x*=n;
		if ERROR then option 16 %2&~(0x02|0x08); endif;
//		n = n - 1;
//	end do;
	end loop;
	echo x;
elseif p==0 then
	echo fact(%1+0);
else
	a = $() + 0;
print a;
	exec ip fact %1+0 a;
	echo a[0];
endif;
*/
	print getmemused(1,6);
	print *$();
	return $ERROR;
end proc;

function fact(n);
	print 'Enter' n;
	if n > 1 then
		n *= fact(n-1);
	end if;
	print 'Return' n;
	return n;
end func;

proc fact(n,a);
//	echo 'Enter' n a[0];
//print /i n a;
	if (n > 1);
		exec ip fact n-1 a;
//		echo a[0];
		n *= a[0];
//	echo n a[0];
//	else;
//		n = 1;
	end if;
//	echo 'Return' n;
	a[0] = n;
	return ERROR;
end proc;
