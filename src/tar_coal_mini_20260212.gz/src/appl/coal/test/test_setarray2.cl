//
//define array a 10;
//define array b 10 = ['A','B','C',{100,200},'D'];
proc main;
	n = setarray(1,MAX_LAYER==>1,2,3,4,5,6,7,8,9,10);
	print n countv($()) *$();

//	n = setarray(1,*[1,2,[10,20],4,5],'A');
	n = setarray(1,*[1,2,[10,20],4,5],'A',MAX_LAYER==>1,'B');
//	n = setarray(1,1,2,3,4,5,6,7,8,9,10);
	print n countv($()) *$();
	i = 1;
	loop 10;
		printf '$(%d)=%s\n' i $$i;
//		printf '$(%d)=%s\n' i $(i);
		i++;
	end loop;
/*
//	b[5] = a;
	n = setarray(a,b,MAX_LAYER==>-1);
	print n countv(a) *a;
*/
	return ERROR;
end proc;
