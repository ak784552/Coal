//
// Fibonacci series:
// the sum of two elements defines the next
//
proc main;
	[a, b] = [0, 1];
	loop;
		if a >= 1000;
			break;
		end if;
		printf '%d,' a;
		[a, b] = [b, a+b];
	end loop;
	print;
	return ERROR;
end proc;
