//
proc main;
	print Math.sind(30.0);
	print Math.cosd(60.0);
	print Math.tand(45.0);
	return $ERROR;
end proc;
