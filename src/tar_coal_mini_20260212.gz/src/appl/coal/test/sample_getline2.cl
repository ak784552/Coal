//
const int MAXLINE = 1000;

//char(1) line[MAXLINE];
proc main;
//	try;
		loop;
			n = getline();
			if ERROR; break; endif;
			print n;
		end loop;
//	catch FILE_READ_END_EXCEPTION;
//	catch;
//		print ERRMSG;
//	end try;
	return ERROR;
end proc;

function getline();
	char c;

	i = 1;
	loop;
		c = getchar();
		if ERROR; break; endif;
//putchar(c);
		if c == '\n'; break; endif;
//		line[i] = c;
		$(i) = c;
		i++;
	end loop;;
	if c == '\n' then
//		line[i] = c;
		$(i) = c;
		i++;
	end if;
//	line[i] = '\0';
	$(i) = '\0';
	return i - 1;
end func;
/*
func getchar();
	return elread1(1,1);
end func;
*/
