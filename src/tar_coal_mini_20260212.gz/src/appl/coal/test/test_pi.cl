//
//
//
proc main;
	double M,m,r,N,dr,d,dri,drj;
	int i,j;

	print date_add('s',3661,'0000/00/00 00:00:00');
	print date_add('s',14009,'');
	print to_date('2021/05/04','yyyy/mm/dd');
	t0 = gettime();
	N=1000;
	r=1.0;
	dr=r/N;
	M=(N+1)*(N+1);
	m=0;
	i=0;
	loop N;
		dri = dr*i;
		dri2 = dri*dri;
		j=0;
		loop N;
			drj=dr*j;
			drj2=drj*drj;
			d = sqrt(dri2 + drj2);
			if d <= 1.0; m++; endif;
			j++;
		end loop;
		i++;
	end loop;
	print t=m/M*4.0;
	return ERROR;
end proc;
