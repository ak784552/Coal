//
PROC main;
	print %1;
	option 11 %1+0;
	option 12 %2+0;
	option 16 %3+0;
//	option 17 %4+0;

	print 1.D-4;
//	x = ' -123 A ' + 0;
	print "'' + 0";
	print "' - - 1' + 0";
	print "' + + 2' + 0";
	print "' - + 3' + 0";
	print "' + - 4' + 0";
	print "' - - 5.' + 0";
	print "' + + 6.' + 0";
	print "' - + 7.' + 0";
	print "' + - 8.' + 0";
	print "' -123 A ' + 0";
	print "' -123F ' + 0";
	print "' -123d ' + 0";
	print "' -0xff ' + 0";
	print "' -0b111 ' + 0";
	print "' -0o7 ' + 0";
	print "' -123.45 ' + 0";
	print "-123.45 + 0";
	print "' -123.45E0   ' + 0";
	print /p+50 1.234567890123456789012345678901234567890;
	print 1.23456789012e5;
	print 1.234567890123456789012345678901234567890e-10;
	print '1.234567890123456789012345678901234567890-10'+0;
	DEC d = 12345;
	print d /i d;
	print 00.0 123.0 000.12;
	print .0 .12;
	print 0xf12d " 'ASD' ";
	print 0d123;

//	print 0.01/3.0;
//	print 0.1/3.0;
	print 1.0/3.0;
	print 10.0/3.0;
	print 3.0*3.0;
//	print 1.0/10.0;

	int x = 2147483648;
	print x /i x;
	undef x;
	int x = 9223372036854775808;
	print x /i x;
	a = 123456789012345;
	print a /i a;

//	a = (DEC)123456789012345;
//	print a;
	print '+1.23+65535'+0;
	print '-1.23-65536'+0;
	print 1.23E+65535;
	print 1.23E-65536;
	print 1.23e+308;
	print 1.23e-309;
	DEC(5,2) dd = 1234567.897;
	print dd;

	print 1.23e++3+;
	print 0x012X;
	print '+'+0;
	print x='1,234';

	RETURN $ERROR;
END PROC;
