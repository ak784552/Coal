//
proc main;
	fpi = fopen(%1);
	if $ERROR then
		print ERRMSG ERROR ERRNO;
	else
		do;
			if %2=='' then
				fpo = STDOUT;
			else
				fpo=fopen(%2,'w');
				if $ERROR then
					print ERRMSG ERROR ERRNO;
					break;
				endif;
			endif;
			loop;
				a = getc(fpi,,2);
				if $ERROR then
					break;
				endif;
				print /x $a;
			//	putc(fpi,a);
				putc(fpo,a,,2);
			end loop;
			if fpo <> STDOUT then
				fclose(fpo);
			endif;
			fclose(fpi);
		end do;
	endif;
	return $ERROR;
end proc;
