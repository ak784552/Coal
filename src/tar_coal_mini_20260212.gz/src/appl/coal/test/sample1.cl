//
//  sample1.cl
//
proc main;
	$1 = 'AAA';
	$2 = 'BBB';
//	for (i=1;i<=2;i++) do
	i=1;
	loop;
		if i>2; break; end if;
//		exec ip proc1 $$i;
		call proc1 $$i;
		i++;
	end loop;
	return ERROR;
end proc;

proc proc1(aa);
	print aa;
	return ERROR;
end proc;
