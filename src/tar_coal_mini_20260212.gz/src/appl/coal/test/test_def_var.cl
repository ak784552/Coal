//

//implicit int (c,x,v);
define var y as DEC(5,2) = 1.2;
//define var y as DEC(5,2) = 1.2, yy = 3.14;
define var v as VARI;
dim yd as DEC(5,2) = 345.67;
define DEC(5,2) xd = 2.5;
var ca,cb;
def vari xa,xb;

proc main;

	print y yd xd yy v w;
	print /i y yd xd yy v;
	dim x;
	print /i x;
	print y=123 y='ABC' y=0.3;
	print v=123 v='ABC' v=0.3;
	var a,b;
	print a b;

	print /i ca cb;
	print /i xa xb;

	int ya;
	local ya =1, ww=4;
	print /i ya ww;
	print  *ya ww;

	return ERROR;
end proc;
