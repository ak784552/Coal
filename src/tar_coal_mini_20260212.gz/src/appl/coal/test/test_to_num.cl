//
proc main;
	option 17 +0x20;
//	option 11 0x20;
	print /x getval('OPTION',17);
	$a = 1E1;
	print $a;
	$b = 10 TO 'D';
	print $b /i b;
	$b = 10.35 TO 'D';
	print $b /i b;
	$b = 10 TO 'Int';
	print $b /i b;
	$b = 10.35 TO 'Int';
	print $b /i b;
	$b = ' 10.35' TO 'D';
	print $b /i b;
	$b = ' 10.35' TO 'Dec';
	print $b is(b,'T') /i b;
	print to(' 10.35 ','Dec');
	print /m+ to('123456.789',3..8,'Dec');
	print to('123456.789',3,7,'Dec');
	print to('123456.789',3..8,3..6,'Dec');
	print to('123,456.789','Dec');
	print to('123,456+2','Dec');
	print "'123456' TO 'Uint'" /i "'123456' TO 'Uint'";
	print to('123456','Uint') /i to('123456','Uint');
//	$c = TO_NUMBER('1',3);
	$c = TO_NUMBER('1',$CLFLOAT);
	print $c;
	$d = TO_NUMBER(2.5,$CLINT);
	print $d;
	print TO_NUMBER(2.5,$CLINT);

	$ff = 123 TO 'F';
	print $ff;
	print TO_NUMBER(123,$CLFLOAT);
//	$e = TO_NUMBER('3.5FA',$CLDOUBLE,0,0,1);
//	print $e;
	$f = TO_NUMBER('3.5D',3);
	print $f;
	g = TO_NUMBER(3,4,5,2);
	print g;
	print /m- TO_NUMBER('1,234,567,890',4,15,-3,2);
	print TO_NUMBER('0.012345');

	h = TO_NUMBER('2147483647');
	print h /i h;
	i = TO_NUMBER('2147483648');
	print i /i i;
//	j = TO_NUMBER('2147483648U');
//	print j /i j;
//	k = 2147483648U;
//	print k /i k;
	print TO_NUMBER('2147483648U');
	print 123456i;

	print TO_NUMBER('9876543210',4);
	print TO_NUMBER('9876543210',3);

	print /m+ TO_NUMBER('9876543210',4);
	print /m+ TO_NUMBER('9876543210',3);

	m = TO_NUMBER('2147483648',$CLUINT);
	print m /i m;

	return $ERROR;
end proc;
