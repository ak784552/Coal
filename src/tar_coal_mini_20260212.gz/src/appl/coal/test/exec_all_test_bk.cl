//
//	"@[�C�ӕ���] �P�[�X��" : �P�[�X�̊J�n�B����"@"�܂�
//	"@[�C�ӕ���]: �P�[�X�̏I���
//	"//": ���s�I��
//	"##": �P�[�X���ňȍ~���X�L�b�v�B"@[�C�ӕ���]"�݂̂Ɠ���
//	"#" : 1�s�X�L�b�v
//	"-o �I�v�V�����ݒ�": �ݒ�t�@�C����OPTION�Ɠ���
//	"/*": "*/"�܂ŃR�����g
//
//def a 50;
//def opt 30;
def int max_loop_while;
def here_doc = '';
def list_file = '';
def line;
def end_flg = 0;
//***************************
//*	main					*
//***************************
proc main;
	if !%0 ;
		echo 'usage:' SCRIPTNAME 'test_file [test_case ...]';
		return 1;
	elseif %0 == 1 ;
		list_file = %1;
		exec ip normal_exec;
	else
		list_file = %1;
		shift;
		exec ip find_exec_case;
	end if;
	return ERROR;
end proc;

//***************************
//*	find_exec_case			*
//***************************
proc find_exec_case;
	loop;
		if !%1; break; endif;
//		try (fp = fopen(list_file));
		fp = fopen(list_file);
		if fp ;
			get_option();
			i = 0;
			loop ;
				line = fgetline(fp);
				if ERROR; break; endif;
				if !line ;
					continue;
				end if;
				n = split(line,101,23);
				f = $101;
				if ret=if_other(n,fp,f,'') ;
					if ret == 100 ;
						break;
					end if;
				elseif left(f,1)=='@' && n>=2 ;
					if %1 == $102 ;
						exec ip exec_case fp $102;
						break;
					end if;
				end if;
			end loop;
		end if;
//		catch FILE_READ_END_EXCEPTION;
//			;
//		catch;
//			print ERRMSG;
//		end try;
		shift;
	end loop;
	return ERROR;
end proc;

//***************************
//*	normal_exec				*
//***************************
proc normal_exec();
//	try (fp = fopen(list_file)) ;
	fp = fopen(list_file);
	if fp;
		get_option();
		i = 0;
		line = '';
		loop ;
			if line == '' ;
				line = fgetline(fp);
				if ERROR; break; endif;
				if !line ;
					continue;
				end if;
			end if;
			n = split(line,101,23);
			f = $101;
			if ret=if_other(n,fp,f,'') ;
				if ret == 100 ;
					break;
				end if;
			elseif left(f,1)=='@' && n>=2 ;
				exec ip exec_case fp $102;
				if ERROR; break; endif;
				if end_flg ;
					break;
				end if;
			end if;
		end loop;
	end if;
//	catch FILE_READ_END_EXCEPTION;
//		;
//	catch;
//		print ERRMSG;
//	end try;
	return ERROR;
end proc;

//***************************
//*	exec_case				*
//***************************
proc exec_case(fp,case_nam);
	putline('@@@@@@@@@@ start ',case_nam);
	ret = 0;
	loop ;
		line = fgetline(fp);
print 'fgetline:' ERROR line;
		if ERROR; break; endif;
//print line;
		if !line ;
			continue;
		end if;
//		arrayclr(a);
		n = split(line,101,23);
//print n *$();
		f = $101;
		if left(f,1)=='@' ;
			if n == 1 ;
				line = '';
			end if;
			break;
		end if;
		f = $101;
		if ret=if_other(n,fp,f,case_nam,1) ;
			if ret == 100 ;
				break;
			end if;
		else
			echo '*** start' f '***';
//			try;
				nparm = chk_heredoc(n,fp);
//print *$();
			//	exec sc:trypass $f $*;
			//	exec sc:notrypass $f $*;
				exec sc $f $(1,nparm)*;	// here_doc;
print ERROR;
				if ERROR; break; endif;
//			catch FILE_READ_END_EXCEPTION;
//				;
//			catch;
//				print ERRMSG;
//			end try;
			undef const like public % not global ei_to_s eb_to_s PI_180;
			reset_option();
			echo '*** end  ' f '***';
		endif;
	end loop;
	if ret<>100 ;
		putline('@@@@@@@@@@ end ',case_nam);
	end if;
	return ERROR;;
end proc;

//***************************
//*	if_other				*
//***************************
func if_other(n,fp,f,nam,mode=0);
	f2 = left(f,2);
	if f2=='//' ;
//print '//';
		ret = 100;
		end_flg = 1;
	elseif left(f,2)=='##' ;
		if mode ;
			echo '*** skip ' nam '***';
		end if;
		ret = 100;
	elseif f2=='-o' ;
//print '-o';
		a[0] = substr(f,3);
		set_option(n);
		ret = 1;
	elseif f2=='/*' ;
//print '/*';
		skip_comment(fp);
		ret = 1;
	elseif left(f,1)=='#' ;
//print '#';
		if mode ;
			echo '*** skip ' f '***';
		end if;
		chk_heredoc(n,fp,0);
		if $1 ;
			t = '';
			if ($2 & 0x02) ;
				t &+= '\\t';
			end if;
			if ($2 & 0x04) ;
				t &+= ' ';
			end if;
			loop;
				line = fgetline(fp);
				if ERROR; break; endif;
//print line;
				if trim(line,t) == $1 ;
					break;
				end if;
			end loop;
		end if;
		ret = 1;
	else
		ret = 0;
	end if;
	return ret;
end func;

//***************************
//*	get_option				*
//***************************
func get_option();
	max_loop_while = MAX_LOOP_WHILE;
	ii = 201;
	i = 1;
	loop 23;
		$$ii = getval('OPTION',i);
		i++;
		ii++;
	end loop;
	return ERROR;
end func;

//***************************
//*	reset_option			*
//***************************
func reset_option();
	MAX_LOOP_WHILE = max_loop_while;
	ii = 201;
	i = 1;
	loop 23;
		option i $$ii;
		i++;
		ii++;
	end loop;
	return ERROR;
end func;

//***************************
//*	set_option				*
//***************************
func set_option(n);
	max_loop_while = MAX_LOOP_WHILE;
	jj = 101;
	i=0;
	loop n-1;
		ii = i;
		val = $$jj;
		if (pos=instr(val,'='))>0 ;
			ii = left(val,pos-1);
			val = substr(val,pos+1);
		end if;
//print ii val;
		option ii val;
		jj++;
		i++;
	end loop;
	return ERROR;
end func;

//***************************
//*	chk_heredoc				*
//***************************
func chk_heredoc(n,fp,mode=1);
print n;
	arrayclr(1,,,100);
	here_doc = '';
	nparm = 0;
	if !mode ;
		$1 = '';
		$2 = 0;
		nparm = 2;
	end if;
	ii = 102;
	i=1;
	loop n-1;
print $ii $$ii;
		x = $$ii;
		if left(x,2)=='<<' ;
			nam = substr(x,3);
			pos = skip_opt(nam,'-=!',8);
			hd_opt  = 0x10;
			if pos > 0 ;
			//	if instr(nam,1,pos,'!') ; hd_opt  = 0x10; endif;
				if instr(nam,1,pos,'-') ; hd_opt |= 0x20; endif;
				if instr(nam,1,pos,'=') ; hd_opt |= 0x60; endif;
				nam = substr(nam,pos+1);
			end if;
			if nam=='' ;
				if i < n-1;
					nam = x = $(ii+1);
				end if;
			endif;
//			if nam<>'' ;
			if mode ;
//print /x fp;
				here_doc = redirect(fp,nam,hd_opt);
//print to_bulks(fp,nam);
//				here_doc = to_bulks(fp,hd_opt,nam)<=='STDIN';
//print here_doc;
				$(i) = here_doc;
				nparm = i;
			else
				$1 = nam;
				$2 = hd_opt;
			endif;
			break;
		else
			if mode ;
				$(i) = x;
				nparm = i;
			end if;
//print ii $(i) $0;
		endif;
		i++;
		ii++;
	end loop;
	return nparm;
end func;

//***************************
//*	skip_comment			*
//***************************
func skip_comment(fp);
	loop;
		line = fgetline(fp);
		if ERROR; break; endif;
		if !line ;
			continue;
		end if;
			n = split(line,101,23);
			f = $101;
		if left(f,2)=='*/' ;
			break;
		end if;
	end loop;
	return ERROR;
end func;
