//
/*
define array a 10;
define array dec(10,2) $dec 10;
*/
proc main;

	$1 = 1;
	print ++$1 $1++;
/*
	a[0] = 1;
	print ++a[0] a[0]++;
	$dec[0] = 1.0;
	$dec[1] = ++$dec[0];
	print ++$dec[0] $dec[1];
	print $dec[0]++ $dec[0];
*/
	x = 1;
	print x++;
/*
	$dec[0] = 1.0;
	print $dec[0]++;
*/
	i = 2;
	print i++ i;

	$1 = 1;
	print --$1 $1--;
/*
	a[0] = 1;
	print --a[0] a[0]--;
	$dec[0] = 1.0;
	$dec[1] = --$dec[0];
	print --$dec[0] $dec[1];
	print $dec[0]-- $dec[0];
*/
	x = 1;
	print x--;
/*
	$dec[0] = 1.0;
	print $dec[0];
*/
	i = 2;
	print i-- i;

	x = 1.5;
	y = x++;
	print y x;
	x = 1.5;
	y = ++x;
	print y x;

	local w++ = 1;
	print w;

	return ERROR;
end proc;
