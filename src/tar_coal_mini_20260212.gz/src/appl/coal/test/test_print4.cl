//
//def xa 10 = [1,2,3,4,5,6,7,8,9,10];
//def ya hash = ['decimal',123.5,'char','abcdef'];
def a = {10,12,13,14,15};
def b = [20,22,23,24,25];
//dim ba 10 = [30,32,33,34,35],36,37,38;
//var b = [20,22,23,24,25];
/*
typedef struct TTT
	int x,
	char y,
	dec z[5];
TTT tt = [123,'XYZ',2.5,3.2,4.8];
TTT tta[3] = [444,'DKSA',2.2,3.5,4.4,5.0,6.6,555,'KKK',7.7,8.8,9.9];
*/
proc main;

	print '��ʕϐ�';
	ww = 'X';
	print ww /i ww;
	print &ww;

	print '�萔';
	print /i 'X';

	print '�͈�';
	h = 1..5;
	print h /i h;
	print *h /i *h;

	print '�萔';
	print /i 'A'..'D';
	print /i *('A'..'D');
	print /i 11..15;
	print /i *(11..15);

	xa = $();
	setarray(xa,100,3,'X','Y','Z');
	print '��ʔz��';
	print xa;
	print *xa;
	print /i xa;
	print /i *xa;
/*
	print ba;
	print *ba;
	print /i ba;
	print /i *ba;

	print 'HASH�z��';
	print ya;
	print *ya;
	print /i ya;
	print /i *ya;
*/
	print '���X�g';
	a = {10,12,13,14,15};
	print a;
	print *a;
	print /i a;
	print /i *a;

	print '�萔';
	print /i {10,20,xa,40,50};
	print /i *{10,20,xa,40,50};

	print '�f�[�^����';
	print b;
	print *b;
	print /i b;
	print /i *b;

	print '�萔';
	print /i [11,12,13,14,15];
	print /i *[11,12,13,14,15];
/*
	print '�\����';
	print tt;
	print *tt;
	print /i tt;
	print /i *tt;
	print "tt = 12345";

	print '�\���̔z��';
//	private TTT tta[3] = [444,'DKSA',2.2,3.5,4.4,5.0,6.6,555,'KKK',7.7,8.8,9.9];
	print tta;
	print *tta;
	print /i tta;
	print /i *tta;
	print "tta[2] = 666";
//	print *tta;
*/
	return $ERROR;
end proc;
