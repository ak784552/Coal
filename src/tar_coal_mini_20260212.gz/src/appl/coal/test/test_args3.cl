//
//define array $args 10;
proc main;
	$a = '1 2 3 4 5 6';
	$n = getargs($a,1,10);
	print $n;
	$i = 0;
//	loop $n;
	loop 10;
		print $i $$i;
		$i++;
	end loop;
	return $ERROR;
end proc;
