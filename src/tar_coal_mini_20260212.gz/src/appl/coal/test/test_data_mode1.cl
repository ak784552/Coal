//
define x2 = {**(3.1..5.6..1.1)};
/*
define xx 10 = **range(3.1,5.6,1.1);
define xa 10 = **range('A','E',2);
*/
proc main;
	print *%();
	print '1234'.3;
//	print *xx xx[0] xx[1];
//	print *xa xa[0] xa[1];
	print x2 x2[0] x2[1] x2[2];
//	xx[0] = 0;
	x2[0] = 0;
//	print xx[0] x2[0];
//	for each a in **(1..10..3);
//		print a;
//	next;
	x = -**(1..2..1);
	print x;
	print abs(**(1..2));
	print set_array(**(1..10));
	print *$();

	exec ip proc1 **(1..10);

	x = "**(1..5) - **(2..4)";
	print x;
	x1 = **(1..5) ? **(2.5..3.5) : **('A'..'C');
	print x1;

	x2 = 0 ? **(2.5..3.5) : **('A'..'C');
	print x2;

	print "**(1..2..1) = 0";

	print *(2.5..5.8..1.1);
	print *(SYSDATE..(SYSDATE+3)..'D 2');

	return ERROR;
end proc;

proc proc1 argc(a,b,c);
	print argc a b c;
	return ERROR;
end proc;
