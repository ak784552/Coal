//
// �z��̃f�[�^�z�u
//
//define array aa[4,3,2] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];
proc main;
	aa = $() + [0,4,3,2];
	setarray(1,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24);
	print aa *aa;
//	for (k=0;k<2;k++);
	k = 0;
	loop 2;
		print k;
		printf('    i=');
	//	for (i=0;i<4;i++);
		i = 0;
		loop 4;
			printf(' %2d',i);
			i++;
		end loop;
		print;
//		for (j=0;j<3;j++);
		j = 0;
		loop 3;
			printf('j=%d : ',j);
//			for (i=0;i<4;i++);
			i = 0;
			loop 4;
				printf(' %2d',aa[i,j,k]);
				i++;
			end loop;
			print;
			j++;
		end loop;
		k++;
	end loop;
	return ERROR;
end proc;
