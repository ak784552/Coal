//
def int a,b,c = 1;
/*
def array x,y,z = 1,2,3,4,5;
typedef struct SSS
	int x,
	char y;
SSS aa,bb=10,'AAA';
*/
//def xxx=1;
//def xxx+1;
proc main;
//	aaa = a;
//	print aaa;
//	const a = 10;
	xxx=1;
	local ++xxx = xxx;
	print xxx;
	local int $(y='yy')=1;
	print yy y;
//	local int xxx++ = xxx;
	local xxx++ = xxx;
	print xxx;
//	int xxx(0)=100;
//	int xxx+1;
	print $MAX_LOOP_WHILE;
//	int aa,bb=1;
	print /i xxx;
	print /i aa bb;
	print a b c;
	print x y z;
	print *x *y *z;
//	SSS aa,bb=10,'AAA';
//	print aa bb;
//	int ee++ =20;
//	int ee = 'AA';
	print ee;
	char cc+='1';
//	print cc;
	loop 2;
		local cc=30, private gg='BBB';
	end loop;
//	local cc=30;
//	local cc=30, private gg='BBB';
	local const hh=40, jj='CC';
//	local dd=40,'CCC';
	print cc dd ee gg hh jj;
	print /i cc dd ee gg hh jj;
//	1=1;
	return ERROR;
end proc;
