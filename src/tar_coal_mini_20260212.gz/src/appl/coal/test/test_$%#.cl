//
//define a 10;
proc main;
//	print a;
	print %0 $0 #0;
	print %();
	print $();
	print #();
	$1 = 1;
	$2 = 'A';
	print $0;
//	$0 = 1;
	$()[3] = 100;
	$11 = 11;
	print $(1,2,3) $11;
	print *%();
	print $();
	print $0;
	print *$();
	print $$();

	print *#();
	print %()[1];
	print %()[2];
	print $()[1];
	print $()[2];

	print $%(1);
	print $$%(1);

	print $(2) $$(2);
	print $2 $$2;

	return ERROR;
end proc;
