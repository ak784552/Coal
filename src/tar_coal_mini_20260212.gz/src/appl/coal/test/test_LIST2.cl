//
proc main;
	let option 5 1;
	a = LIST(1, 2, 3, ['A',3.5]);
	print a;
//	a.print();
//	print a.first();
	print first(a);
	print rest(a);
	print "CONS(a, [10,20,30], 'XYZ')";
	print "CONS(a, {10,20,30}, 'XYZ')";

	b = [1, 2, 3, {'A',3.5}];
	print b;
//	b.print();
//	print b.first();
	print first(b);
	print rest(b);
	print "CONS(b, {10,20,30}, 'XYZ')";
	print "CONS(b, [10,20,30], 'XYZ')";

//	{1,2}.print();
	print({1,2});
	return ERROR;
end proc;
