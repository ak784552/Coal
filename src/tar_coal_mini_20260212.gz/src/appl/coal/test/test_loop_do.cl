//
proc main;

	i = 0;
	loop (3)do
		print 'loop1' i;
		j=0;
		loop i as AA;
			print 'for' j;
			if j>3 then
				break AA;
			end if;
			j++;
		end loop;
		print 'loop3';
		i++;
//	end loop;
	end do;
	return $ERROR;
end proc;
