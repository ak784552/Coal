//
//define array a 3 2;
//define array b 3 2 = [1,2,3,4,5,6];
//define array c 3 2 = [11,12,13,14,15,16];
//define mappedarray b 11 3 2 = [1,2,3,4,5,6];
//define mappedarray c 21 3 2 = [11,12,13,14,15,16];
proc main; 

	a = $() + [0,10];
	b = $() + [10,3,2];
	c = $() + [20,3,2];
	print a b c;
	setarray(b,1,2,3,4,5,6);
	setarray(c,11,12,13,14,15,16);
	print *b;
	print *c;

	print matrixbxp(1,b,c,'+');
	print *$();

	print matrixbxp(a,b,c,'+');
	print *a;
	print matrixbxp(a,b,c,'-');
	print *a;
	print matrixbxp(a,b,c,'*');
	print *a;

	return ERROR;
end proc;
