//
//	sample_swap.cl
//
define c = $()+0;//10=1,2,3;
proc main;
	setarray(c,0,1,2,3);
//	print *$();
	a = 1;
	b = 2;
	print a b /i a b;
	print swap(&a,&b);
	print a b;

	print swap(&a,c);
	print a c;
	print *a *c;

	a = 1;
	print f(&a,c);
	print a c;
	print *a *c;

	return ERROR;
end proc;

function swap(pa,pb);
print 'Enter' pa pb;
print 'Enter' *pa *pb;
	tmp = *pa;
print tmp;
	*pa = *pb;
print *pa pa;
	*pb = tmp;
print 'Exit' *pb pb;
	return 0;
end func;

function f(pa,b);
print b;
	*pa = b;
	return 0;
end func;
