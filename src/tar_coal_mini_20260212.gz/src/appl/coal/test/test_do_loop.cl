//
//def a 10 = [1,2,3,4,5,6,7,8,9,10];
proc main argc xx;
	a = %() + 0;
//	MAX_LOOP_WHILE = 5;

//	let x=10;
	do i=1 ,5 as LLL;
		print %xx[i];
	end do;
	do i=1 ,5 ,2;
		print a[i];
	end do;
	do i=9 , 0 ,-2;
		print a[i];
	end do;
//	do i=1 ,  ,-2;
//	do aaaa=1,3,3,4;
	do;
		print 'do';
	end do;

	for i=1 to 10 as LLLL;
//	for i=1 to -10 step -2;
		print 'for1' i;
	next;

	i = 0;
	print a[i] do i=0,9;

	return ERROR;
end proc;
