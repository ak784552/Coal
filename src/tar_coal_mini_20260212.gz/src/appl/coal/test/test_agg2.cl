//
/*
define ac[10] = 'Tokyo','Osaka','Nagoya','Aomori','Fukuoka';
define av[10] = 'Fukuoka','Osaka';
*/
proc main;
	option 13 +0x02;
	cities = {'Tokyo','Osaka','Nagoya','Aomori','Fukuoka'};
	visited = {'Fukuoka','Osaka'};
	print {'Tokyo','Osaka','Nagoya','Aomori','Fukuoka'}-{'Fukuoka','Osaka'};

	print /c- cities-visited;

	a = 'I still need to visit' &
		 ' the following cities:';
	putline(a,'/c','/q',cities - visited);

	say a "cities - visited";
/*
	putline(a,'/c',*(*ac-*av));
	w='';
	for each x in *ac-*av do
		w &= ' ' & x.value;
	next;
	putline(a,w);
*/
	print /i cities-visited;
	print /i *(cities-visited);
/*
	print /i 1 'A';
	putline('/m+',123456.7);
*/
	return ERROR;
end proc;
