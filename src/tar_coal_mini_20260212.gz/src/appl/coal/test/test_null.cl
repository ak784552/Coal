//
//def x 10;
proc main;
	NULL;
	print NULL;
	print "NULL+NULL";
	print "NULL&NULL";
	print "NULL+1";
	print "2+NULL";
//	print "(CBIN)NULL";
	print "+NULL";
	print "-NULL";
	a = NULL;
	print a;
	print is_null(a) is_null(0);
	print "a is 'NULL'" "'A' is 'NULL'";
	print a..10 1..a;
	print range(a,10) range(1,a);
/*
	set_array(x,0,a,1,2,NULL);
	print *x;
*/
	printf '%d %d\n' a 10;
	printf('%d %d\n', a, 10);
	printf a a 10;
	printf(a, a, 10);
	return $ERROR;
end proc;
