//
proc main;
//	try;
		loop;
			a = getline();
			if ERROR; break; endif;
//			print $a;
			putline(a);
			$10 = 0;
			$n = getargs($a,1,10,,',');
//			$n = getargs($a,1);
			print $n *$();
/*
			$i = 1;
			loop $n;
				print $i $$i;
				$i++;
			end loop;
*/
		end loop;
//	end try;
	return $ERROR;
end proc;
