//
//define array $b 10;
//define h hash 10;
proc main;

	options %1 "" '' 0x100;
//	option 1 %1+0;
	print nval(1,'null');
	print nval('','null');
	print nsval('','null');
	print nsval(' ','null');
	print nsval('X','null');
	$a = 2;
	print ndef('$a','');
	print ndef('$x','');
	print nval(ndef('$x','YYYY'),'XXX');
	print nval(ndef('$x',''),'X01');
	print nval(ndef('$x'),'X02');
//	print nval(ndef('$b[0]'),'B0');
	print "ndef('b[0]','NOT' & 'DEFINE',2+3)";
//	print ndef('b[0]','NULL',0);
	print ndef(,'NULL',0);

//	print ndef('h[0]',,1);
	print ndef(,);
	print ndef('c','c is not defined.');
//	$y = $c;

	print iif(1,'null',100,200);
	print nval(1,'null',100);
	print nsval(1,'null',100);
//	print ndef('b[0]','NULL',0,100);
	return ERROR;
end proc;
