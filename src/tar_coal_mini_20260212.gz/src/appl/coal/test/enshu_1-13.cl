//
// power�֐��̃e�X�g
//
proc main;
	int i;

	i = 0;
	loop 10;
		print i power_int(2,i) power(-3,i);
		i++;
	end loop;
	print;
	ii = 0.0;
	loop;
		if ii >= 8.0 then;
			break;
		end if;
		print ii power(2.5,ii) power(-3.5,ii);
		ii +=1.5;
	end loop;
	return ERROR;
end proc;

func power_int(int x, int n) as int;
	p = 1;
	loop n;
		p *= x;
	end loop;
	return p;
end func;

func power(x, n);
	p = 1;
	loop n;
		p *= x;
	end loop;
	return p;
end func;
