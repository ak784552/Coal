//
// ���͒��̍s�A�P��A�����̃J�E���g
// ���͂����P����P�s�Ɉ���o�͂���
//
def const YES = 1;
def const NO  = 0;

def const char sep = ' \t,;()[]{}<>=''\"!^*/~';
proc main;
	int  nl, nw, nc, inword;
	char c,word;

	call << EOF1;
asd 2234
jsdg	sd234
xyz()kdlg
EOF1
	inword = NO;
	nl = nw = nc = 0;
	word = '';
	loop;
		if !(c = getchar());
			break;
		end if;
//putchar(c);
		nc++;
		if c == '\n';
			nl++;
		end if;
		if c == ' ' || c == '\n' || c == '\t' || c == '�@' ||
		   instrchars(sep,c)>0 ;
			inword = NO;
			kugiri++;
			if kugiri==1 && word ;
				print word;
			end if;
			word = '';
		elseif inword == NO;
			inword = YES;
			nw++;
			word = c;
			kugiri = 0;
		else
			word &= c;
		end if;
	end loop;
	if word ;
		print word;
	end if;
	print nl nw nc;
	return ERROR;
end proc;
