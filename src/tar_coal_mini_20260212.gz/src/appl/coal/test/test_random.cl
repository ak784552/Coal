//
/*
def ar[10] = ['A','B',,'D','E',10,20,30..35..2];
def ah hash = ['A','B','C','D','E',10];
def int ari[10] = [10,20,30,40,50];
def double ardbl[10] = [11.1,22.2,33.3,44.4,55.5];
def decimal ardec[10] = [11.1,22.2,33.3,44.4,55.5];
def char(3) arc[10] = ['AAA','BBB','CCC','DDD','EEE'];
def xxx = ['AAA','BBB','CCC','DDD','EEE'];
def complex dec arcmp[10] = [1+1i,2+2i,,4.8+4.3i,5,6i,7];
def date ardate[10] = ['2025/09/09',,'2024/01/01',1..2];
*/
proc main;
	a = [1,2,,4,5];
//	print append(a,6);
	print random(a);
	xa = $();
	setarray(xa,100,3,'X','Y','Z');
	print *random(xa);
/*
	print *random(ah);
	setarray($(),100,3/5r,'X','Y','Z');
	print *random($());
	print *random(ar);
	print *random(ari);
	print *random(ardbl);
	print *random(ardec);
	print *random(arcmp);
	print *random(ardate);
	print *random(arc);
*/
	print random('XX');
	print random({1,2,3,4});
//	print xxx;
	return ERROR;
end proc;
