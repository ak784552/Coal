//
def int max_loop_while;
def here_doc = '';
proc main;
//	try (fp = fopen(%1)) ;
		fp = fopen(%1) ;
		get_option();
		i = 0;
		loop ;//for i=0 to 5;
			line = fgetline(fp);
			if ERROR; break; endif;
print line;
			if !line then
				continue;
			end if;
//			arrayclr(a);
			n = split(line,101,23);
print n;
			f = $101;
			if left(f,2)=='//' then
				break;
			elseif left(f,2)=='-o' then
				a[0] = substr(f,3);
				set_option(n);
			elseif left(f,2)=='/*' then
				loop;
					line = fgetline(fp);
					if !line then
						continue;
					end if;
					n = split(line,101,2);
					f = $101;
					if left(f,2)=='*/' then
						break;
					end if;
				end loop;
			elseif left(f,1)=='#' then
				echo '*** skip ' f '***';
			else
				echo '*** start' f '***';
//				try;
					chk_heredoc(n,fp);
//print *$();
					exec sc $f $*;	// here_doc;
				//	heredoc(0);
//				catch FILE_READ_END_EXCEPTION;
					;
//				catch;
					print ERRMSG;
//				end try;
				undef const like public % not global ei_to_s eb_to_s PI_180;
//				undef const like public % not public ei_to_s eb_to_s PI_180;
				reset_option();
				echo '*** end  ' f '***';
			endif;
		end loop;
//	catch FILE_READ_END_EXCEPTION;
		;
//	catch;
		print ERRMSG;
//	end try;
	return ERROR;
end proc;

func get_option();
	max_loop_while = MAX_LOOP_WHILE;
	ii = 201;
	i=1;
	loop 23;
		$$ii = getval('OPTION',i);
		i++;
		ii++;
	end loop;
	return ERROR;
end func;

func reset_option();
	MAX_LOOP_WHILE = max_loop_while;
	ii = 201;
	i = 1;
	loop 23;
		option i $$ii;
		i++;
		ii++;
	end loop;
	return ERROR;
end func;

func set_option(n);
	max_loop_while = MAX_LOOP_WHILE;
	jj = 101;
	i=0;
	loop n;
		ii = i;
		val = $$jj;
		if (pos=instr(val,'='))>0 then
			ii = left(val,pos-1);
			val = substr(val,pos+1);
		end if;
//print ii val;
		option ii val;
		jj++;
		i++;
	end loop;
	return ERROR;
end func;

func chk_heredoc(n,fp);
	here_doc = '';
//	$1 = '';
	ii = 102;
	i=1;
	opt = 0;
	loop n-1;
		x = $$ii;
print x;
		if left(x,2)=='<<' then
			nam = substr(x,3);
			pos = skip_opt(nam,'-=!',8);
			opt  = 0x10;
			if pos > 0 then
			//	if instr(nam,1,pos,'!') then opt  = 0x10; endif;
				if instr(nam,1,pos,'-') then opt |= 0x20; endif;
				if instr(nam,1,pos,'=') then opt |= 0x60; endif;
				nam = substr(nam,pos+1);
			end if;
			if nam=='' then
				if i < n-1;
					nam = x = $(ii+1);
				end if;
			endif;
//			if nam<>'' then
print nam;
//print /x fp;
				here_doc = redirect(fp,nam,opt);
//print to_bulks(fp,nam);
//				here_doc = to_bulks(fp,opt,nam)<=='STDIN';
print here_doc;
				$(ii++) = here_doc;
				break;
//			endif;
		else
			$(i) = x;
//			$$i = x;
//print i $(i);
		endif;
		ii++;
		i++;
	end loop;
	return ERROR;
end func;
