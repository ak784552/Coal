//
proc main;

	a = 2..5;

	print a *a 3..6 'A'..'Z';
	print 'a';
	loop each x in a;
		print x;
	end loop;
	print '*a';
	loop each x in *a;
		print x;
	end loop;
	print '**a';
	loop each x in **a;
		print x;
	end loop;
	print;

//	loop each x in 1..100;
	loop each x in 2..5;
		print x;
	end loop;

	print *a *('A'..'Z') ;

	return ERROR;
end proc;
