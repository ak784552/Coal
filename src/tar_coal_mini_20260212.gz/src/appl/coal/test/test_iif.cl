//
//define a 10 = 1,2;
proc main;

//	print "(CBIN)%1 ? 'True' : 'False'";
//	print (CDEC(10,2))'12.345';
//	print SYSDATE;
	print iif((CDEC(10,2))%1,'True','False');
	print iif((CBIN)%1,'True','False');
	a = 'AA';
	b = 'BB';
	c = 'CC';
	print iif(a,b,c);

	print nval(ff('ABS')(%1),'NVAL');
	print ff('ABS')(iif(%1,-2,-1));

	print nsval(%1,'NSVAL');
	print ndef('X','NDEF');
	print ndef('%1','NDEF');

	print {1,2,3,nval(4,0)};

	print [1,2,3,nval(4,0)];
	print (1,2,3,nval(4,0));
//	print a[0];

//	char aa 10 = 'A','B';
//	print aa[nval(1,0)];

	return ERROR;
end proc;
