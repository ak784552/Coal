//
define const int MAXLINE = 1000;
define line = $()+1;	//[MAXLINE];
proc main;
//	try;
		loop;
			n = getline();
			if ERROR; break; endif;
			print n *line;
		end loop;
//	catch FILE_READ_END_EXCEPTION;
//	catch;
//		print ERRMSG;
//	end try;
	return ERROR;
end proc;

function getline();
	char c;

//	for (i=0; (i<MAXLINE-1 && (c=getchar()) && c<>'\n'); i++);
	i=0;
	loop;
		if !(i<MAXLINE-1 && (c=getchar()) && c<>'\n'); break; end if;
//putchar(c);
		line[i] = c;
		i++;
	end loop;
	if c == '\n' ;
		line[i] = c;
		i++;
	end if;
	line[i] = '\0';
	return i;
end func;
/*
func getchar();
	return elread1(1,1);
end func;
*/
