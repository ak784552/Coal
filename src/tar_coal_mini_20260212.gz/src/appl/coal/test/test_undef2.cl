//
define public _x=1;
//define ar 10;
proc main;
//	$1 = 1;
//	$a = 2;
	local _x=10;
//	ar[0]='X';
//	print $1 %1 #1;
//	print $a ar[0];
	loop 2;
//		$1++;
//		print "global x";
		print $_x /i $_x;
		fa();
//		undefine "local x";
		undefine $_x;
	end loop;
//	print $1;
	print $_x;
	return ERROR;
end proc;

func fa;
//	undefine x;
//	local x=20;
	print _x /i _x;
	return ERROR;
end func;
