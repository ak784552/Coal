//
proc main;

	x = [1,2,3,4,5,6,7];
	print x;
	print pop(x) x;
	print pop(x,2) x;
//	print pop(x,-8) x;		// error
	print pop(x,7) x;		// error
	print append(x,10) x;
	print append(x,11) x;
	print pop(x,-1,2,3) x;
	print pop(x,1,2,2) x;
//	print append(x,12) x;
//	print pop(x) x;
	print pop(x,3,2,2) x;
	print adjust(x);

	setarray($(),100,3,'X','Y','Z');
//	print $() *$();
	z = $();
	print z *z;
//	print *pop($(),2) *$();
	xx = $() + [2,2];
//	xx = $() + 2;
	print xx *xx;
	print *pop(xx,1);
	print xx *xx;
	print *$();
//	print adjust(z);
	print z *z;
//	print *pop($(),2);
	print *pop(1,2);

	print *$();
//	print adjust(z);
	print z *z;
//	pop($(),2);
	print *pop($(),2);
	print $() *$();
	print adjust(xx);
	print adjust('private.r','local.r');
//	print adjust(x);
	print xx *xx;
	print z *z;
	print adjust(1);

	return ERROR;
end proc;
