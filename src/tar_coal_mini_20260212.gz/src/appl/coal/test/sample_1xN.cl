//
// �P�`�m�܂ł̐ς����߂�
//
proc main;
	dec t1,t2;
	dec(8,7) t3;

	MAX_LOOP_WHILE = %1 + 10;
	int NN = %1;	// ����l
	int N = NN;
	print N;
	t1 = gettime(0);

	s = 1;
	loop N;
		s *= N--;
	end loop;
	N = %1;
	print s;
	t2 = gettime(0);
	t3 = (t2-t1)/N;
	print /qc- 'loop :' t2-t1 t3;
	t1=t2;
/*
	N = %1;
	s = 1;
	while N > 0;
		s *= N--;
//		N--;
	end while;
	N = %1;
	print s;
	t2 = gettime(0);
	t3 = (t2-t1)/N;
	print /qc- 'while:' t2-t1 t3;
	t1=t2;

	N = %1;
	s = 1;
	for (i=1;i<=N;i++);
		s *= i;
	next;
	print s;
	t2 = gettime(0);
	t3 = (t2-t1)/N;
	print /qc- 'for  :' t2-t1 t3;
	t1=t2;

	s = 1.0;
	for each x in (1.0..%1);
		s *= x.Value;
	next;
	print s;
	t2 = gettime(0);
	t3 = (t2-t1)/N;
	print /qc- 'each :' t2-t1 t3;
	t1=t2;
*/
//	print product(*(1.0..%1));
//	print *((%1+0)..1..-1);
	print product(*((%1+0)..1..-1));
	t2 = gettime(0);
	t3 = (t2-t1)/N;
	print /qc- 'prdct:' t2-t1 t3;

//	print product(*(N..1..-1));
	print product(*('1'..'9'));

	return ERROR;
end proc;
