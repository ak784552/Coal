//
//	sample_array.cl
//
proc main;
//	int arr[10];
	arr = $() + 1;
	arr[0] = 10;
	arr[1] = 20;
	print arr *arr;
	x = arr;
	x[2] = 30;
	print *arr;
	print x *x;
	print arr[2];
	y = *arr;
	print y *y;
	z = arr + 1;
	print z *z;
	print (arr+1)[0];
	print z[0];
	return ERROR;
end proc;
