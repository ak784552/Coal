//
//define array $a 10;
//define array char(10) $a 10;
//define array BIN $a 10;
proc main;
//	let option 5 1;
	$1 = LIST(1, 2, 3, 'A', 's');
	print $1;
	i = -1;
	loop;
		if i >= 6 then break; end if;
		print list_ref($1,i);
		i++;
	end loop;
	print list_ref('',0);
	return ERROR;
end proc;
