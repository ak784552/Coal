//
define const int MAXLINE = 1000;
proc main;
	fp = fopen(%1);
	if fp ;
		loop;
			line = fgetline(fp);
			if ERROR;
				break;
			end if;
			print line;
		end loop;
	else
		print ERRMSG;
	end if;
	return ERROR;
end proc;

function fgetline(fp);
	char c;

	line = '';
	loop;
		c = getc(fp);
		if ERROR; break; endif;
		if c == '\n'; break; endif;
		line &= c;
	end loop;
	if c == '\n';
		line &= c;
	end if;
	return line;
end func;
