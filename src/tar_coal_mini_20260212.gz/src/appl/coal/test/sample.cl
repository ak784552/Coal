//
//  sample.cl
//
proc main;
	putline('Hello World!',%1);
	print 'Hello World!' %1;
	echo 'Hello World!' %1;
/*
	int x;
	print x='0xff';
	print 3>1 3<1;
	char cc[10]='1','2','3','4','';
	print (int)concat(cc);
	print (dec)'123.45';
*/
	print getmemused(1,6) *$();
	return;
end proc;
