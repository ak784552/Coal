//
proc main;		/* ���͂��o�͂ɕ��ʁF��P�� */
/*
	try;
		loop;
			a = getchar();
			print $a;
			putchar(a);
		end loop;
	end try;
*/
//	while c = getchar();
	loop;
		if !(c = getchar()); break; end if;
		putchar(c);
	end loop;
	return $ERROR;
end proc;
