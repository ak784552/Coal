//
proc main;
	setarray($(),100,3,'X','Y','Z');
	print $() *$();
	print append($(),'A');
	print $() *$();
	xx = $() + 2;
	print xx *xx;
	print append(xx,'B');
	print xx *xx;
	print $() *$();

	return ERROR;
end proc;
