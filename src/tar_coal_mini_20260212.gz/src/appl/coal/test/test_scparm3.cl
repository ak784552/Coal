//
proc main;
	call proc1 %*;
	call proc1 %3*;
	set_array(1,0,1,2,3,4,5);
	call proc1 $*;
	call proc1 $3*;
	return ERROR;
end proc;

proc proc1 argc(a,b,c);
	print 'proc1' argc "local *%()";
	print a b c;
	call proc2 %4*;
	call proc2 "local %2*";
	return ERROR;
end proc;

proc proc2 argc(x,y,z);
	print 'proc2' argc "local *%()";
	print x y z;
	return ERROR;
end proc;
