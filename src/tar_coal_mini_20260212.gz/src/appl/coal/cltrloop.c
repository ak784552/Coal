static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_loop                */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Justify no shori.                         */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"
/********************************************/
/*											*/
/********************************************/
int col_mn_tr_loop(y)
condList *y;
{
	static char *_fn_="col_mn_tr_loop";
	int rc,len,n,i,pnum,cid,scno;
	char *name,*pnm,c;
	cmdInfo *cmd;
	parmList **prmL;

	cmd = y->cmd;
/*
	if ((cid=cmd->cid)!=C_DO && !cmd->prmnum) {
		ERROROUT(FORMAT(103);
		return ( ECL_TR_LOOP );
	}
*/
	cid = cmd->cid;
	prmL = cmd->prmp;
#if 0
	if (cid==C_FOR && !strnicmp(cmd->prmp[0]->prp,"EACH",4)) ;
	else if (cid==C_FOR || cid==C_WHILE || cid==C_UNTIL) {
		cl_tr_insert(y,0,cl_gets_cmd_name(cid));
		cmd->cid = C_LOOP;
	}
#endif
	pnum = cmd->prmnum;
	if (pnum > 0) {
		pnm = prmL[0]->prp;
		len = prmL[0]->prmlen;
	}
	else {
		pnm = "";
		len = 0;
	}

	scno = 0;
#if 0
	if (!strnicmp(pnm,"WHILE",5) || !strnicmp(pnm,"UNTIL",5) ||
	    !strnicmp(pnm,"EACH",4)) {
		cl_tr_split(y,0,"(");
		pnum = cmd->prmnum;
		pnm = prmL[0]->prp;
		if (pnum>=2 && !stricmp(pnm,"WHILE")) scno = D_LOOP_WHILE;
		else if (pnum>=2 && !stricmp(pnm,"UNTIL")) scno = D_LOOP_UNTIL;
		else if (pnum>=4) {
			scno = D_LOOP_EACH;
			if (len == 5) {
				c = toupper(pnm[4]);
				if (c == 'V') scno = D_LOOP_EACHV;
				else if (c == 'I') scno = D_LOOP_EACHI;
			}
/*
printf("%s: pnm=[%s] scno=%02x\n",_fn_,pnm,scno);
*/
		}
		else scno = -1;
	}
	else if (!strnicmp(pnm,"FOR",3)) {
		cl_tr_split(y,0,"(");
		if ((rc=_change_from_for(y)) < 0) return rc;
		else if (!rc) {
			if (rc=_change_from_to_step(y)) return rc;
		}
		pnum = cmd->prmnum;
		if (pnum>=2) scno = D_LOOP_FOR;
		else scno = -1;
	}
#endif
/*
	else if (cid==C_DO && cmd->prmnum>0) {
		ERROROUT1(FORMAT(41),"ColMnTrDo");
		return  ECL_TR_LOOP;
	}
*/
	if (scno < 0) {
		ERROROUT1(FORMAT(42),_fn_);
		return  ECL_TR_LOOP;
	}
	cmd->sub_cid |= scno;

	if (!(rc=cl_make_leaf(y))) {
		cl_pre_nest(y);
		if (!(rc=cl_push(y))) rc= cl_change_stcb(y);
	}
	return rc;
}

/********************************************/
/*											*/
/********************************************/
int cl_tr_insert(y,ip,name)
condList *y;
int ip;
char *name;
{
	int rc,len,n,i,num;
	cmdInfo *cmd;

	cmd = y->cmd;
	num = cmd->prmnum;
	if (ip<num && num<y->max_prmnum) {
		for (i=num;i>ip;i--) cmd->prmp[i] = cmd->prmp[i-1];
		cmd->prmnum = ip;
		if (rc=clparmset(y,name,strlen(name))) return rc;
		n = cmd->prmnum = num + 1;
	}
	else n = 0;
	return n;
}

int cl_search_active_loop(y)
condList *y;
{
	Leaf  *Dummy;
	CLNCB *p;

	p = y->clstcb;
	if (!(Dummy = p->nestLev2)) return 0;
	while (Dummy) {

		if ( Dummy == p->nestLev1 ||
		    (Dummy->cmd.type == 0 && Dummy->cmd.cid == C_LOOP) )
			return ( 0 );
	/*
		else if ( Dummy->cmd.cid == C_LOOP ) return ( -2 );
	*/
		Dummy = Dummy->preleaf;
	}
	return -1;
}
