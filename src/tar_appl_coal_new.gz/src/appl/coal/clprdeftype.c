static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/* <clprdeftype.c>                                                  */
/*      Define process   �@                          */
/*                                            (2009/05/17 Ver 0.01) */
/********************************************************************/

#include "colmn.h"

extern CLPRTBL  *pGLprocTable;
extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];
extern char cmp_sep2[];
extern MCAT2 *pGImplicit;
extern GXObjectExpand CLobjExp;	/* add 20231203 */

#if 1	/* 2020.10.25 */
static char *gsep=" \t(){}[],'=+-*/&|";
#else
static char *gsep=" \t(){}[],'=";
#endif

/************************************/
/*	cl_complex_attr_check			*/
/************************************/
int cl_complex_attr_check(iParm)
int iParm[];
{
	int i,rc;

	rc = 0;
	i = iParm[0] & DEF_ZOK_DTYP;
	if (i==DEF_ZOK_VARI || i==1 || i>DEF_ZOK_DECI) {
				/* %s: %s��'%s'�͎w��ł��܂���B*//* 635 ���f�� */
		ERROROUT3(FORMAT(140),"cl_complex_attr_check",FORMAT(635),cl_get_attr_name_opt(iParm,1));
		rc = ECL_SCRIPT_ERROR;
	}
	else if (!i) {
		iParm[0] = DEF_ZOK_FLOA;
		iParm[1] = sizeof(double);
	}
	return rc;
}

/************************************/
/*	cl_rationa_attr_check			*/
/************************************/
int cl_rational_attr_check(iParm,opt)
int iParm[],opt;
{
	int i,rc;

	rc = 0;
	i = iParm[0] & DEF_ZOK_DTYP;
	if (!i || i==DEF_ZOK_DECI) {
		if (i && (iParm[2] || iParm[3])) {
					/* %s: [%s]�ɂ́A�����A�܂��́A���x�A�ʎ��͎w��ł��܂���B*/
			ERROROUT2(FORMAT(480),"cl_rationa_attr_check",FORMAT(673));
			rc = ECL_SCRIPT_ERROR;
		}
		if (!rc) {
			iParm[0] = DEF_ZOK_DECI;
			iParm[1] = sizeofMPA();
		}
	}
	else {
				/* %s: %s��'%s'�͎w��ł��܂���B*//* 673 �L���� */
		ERROROUT3(FORMAT(140),"cl_rationa_attr_check",FORMAT(673),cl_get_attr_name_opt(iParm,1));
		rc = ECL_SCRIPT_ERROR;
	}
	return rc;
}
#if 1	/* 2026.10,8 */
/************************************/
/*	cl_check_bina_size				*/
/************************************/
int cl_check_bina_size(attr,len)
int attr,len;
{
	int size;

	size = len;
	if (attr == DEF_ZOK_BINA) {
#if defined(_LP64)
		if (size != sizeof(long)) {
			if (size <= 2) ;
			else if (size <= sizeof(int)) size = sizeof(int);
			else size = sizeof(long);
		}
#else
		if (size != sizeof(int)) {
			if (size <= 2) ;
			else size = sizeof(int);
		}
#endif
	}
	return size;
}
#endif
/************************************/
/*	cl_get_def_attr_check			*/
/************************************/
int cl_get_def_attr_check(nparm,ppParm,iParm,opt)
int nparm;
tdtInfoParm *ppParm[];
int iParm[];
int opt;
{
	static char *name="cl_get_def_attr_check";
	int rc,n,attr,size,opt2;
	int dec_pre,dec_sca;
	char *p0;

	dec_pre = dec_sca = 0;
	attr = iParm[0];
	size = iParm[1];
	if (attr == DEF_ZOK_DECI) {
		rc = cl_get_parm_bin(ppParm[0],&dec_pre,"cl_get_def_attr_check: ");
		if (rc) {
			p0 = NULL;
			if ((rc=parm_to_char(ppParm[0],&p0,NULL)) < 0) return rc;
			/* %s: ���x(%s)������Ă��܂��Brc=%d */
			ERROROUT3(FORMAT(463),name,p0,rc);
			return ECL_SCRIPT_ERROR;
		}
		if (dec_pre<=0 || dec_pre>m_get_nmpa10()) {
			/* %s: ���x(%d)������Ă��܂��B */
			ERROROUT2(FORMAT(464),name,dec_pre);
			return ECL_SCRIPT_ERROR;
		}
		if (nparm >= 2) {
			rc = cl_get_parm_bin(ppParm[1],&dec_sca,"cl_get_def_attr_check: ");
			if (rc) {
				p0 = NULL;
				if ((rc=parm_to_char(ppParm[1],&p0,NULL)) < 0) return rc;
				/* %s: �ʎ��(%s)������Ă��܂��Brc=%d */
				ERROROUT3(FORMAT(475),name,p0,rc);
				return ECL_SCRIPT_ERROR;
			}
			if (X_ABS(dec_sca) > dec_pre) {
				/* %s: �ʎ��(%d)������Ă��܂��B */
				ERROROUT2(FORMAT(476),name,dec_sca);
				return ECL_SCRIPT_ERROR;
			}
		}
#if 1	/* 2026.10,1 */
		iParm[2] = dec_pre;
		iParm[3] = dec_sca;
#endif
	}
	else {
		opt2 = opt & 0x02;
#if 1	/* 2026.10,1 */
		if (opt2 || (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK) || attr==DEF_ZOK_BINA) {
#else
		if (opt2 || (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK)) {
#endif
			rc = cl_get_parm_bin(ppParm[0],&size,"cl_get_def_attr_check: ");
			if (rc) {
				p0 = NULL;
				if ((rc=parm_to_char(ppParm[0],&p0,NULL)) < 0) return rc;
				/* %s: �T�C�Y(%s)������Ă��܂��Brc=%d */
				ERROROUT3(FORMAT(461),name,p0,rc);
				return ECL_SCRIPT_ERROR;
			}
			if (size <= 0) {
				/* %s: �T�C�Y(%d)������Ă��܂��B */
				ERROROUT2(FORMAT(462),name,size);
				return ECL_SCRIPT_ERROR;
			}
#if 1	/* 2026.10,2 */
			size = cl_check_bina_size(attr,size);
#endif
		}
	}
	iParm[1] = size;
#if 0	/* 2026.10,1 */
	iParm[2] = dec_pre;
	iParm[3] = dec_sca;
#endif
/*
printf("%s: attr=%d size=%d dec_pre=%d dec_sca=%d\n",name,attr,size, dec_pre,dec_sca);
*/
	return 0;
}

#if 1	/* 2026.10.1 */
/****************************************/
/*	_chk_def_attr_name_able_get_size	*/
/****************************************/
static int _chk_def_attr_name_able_get_size(name,iParm,opt)
char *name;
int iParm[],opt;
{
	int attr,rc;

	rc = 0;
	attr = iParm[0];
	if ((opt & 0x02) || attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK || attr==DEF_ZOK_DECI) ;
	else if (attr == DEF_ZOK_BINA) {
		if (name) {
			if (!stricmp(name,"BINARY") || !stricmp(name,"INTEGER") || !stricmp(name,"UINTEGER")) ;
			else rc = -1;
		}
	}
	else rc = -1;
	if (rc) {
				/* %s: [%s]�ɂ́A�����A�܂��́A���x�A�ʎ��͎w��ł��܂���B*/
		ERROROUT2(FORMAT(480),"cl_rationa_attr_check",name);
		rc = ECL_SCRIPT_ERROR;
	}
	return rc;
}
#endif
/************************************/
/*	_get_def_attr					*/
/************************************/
static int _get_def_attr(line0,llen,iParm,opt,bxobj,Obj)
char *line0;
int   llen;
int   iParm[];
int   opt;
GXObject *bxobj[];
tdtRbChain *Obj;
{
	int rc,nparm,attr,opt1;
	char *line;
	tdtInfoParm *ppParm[2],tInfoParm2[2],*pInfoParm;

	line = line0;
/*
printf("_get_def_attr: llen=%d line=[%s]\n",llen,line);
*/
	if (*line == '(') {
		line++;
		llen -=2 ;
	}
	nparm = rc = 0;
	attr = iParm[0];
	if ((opt & 0x02) || attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK || attr==DEF_ZOK_DECI
#if 1	/* 2026.10.2 */
	     || attr==DEF_ZOK_BINA
#endif
	) {
#if 0	/* 2026.10.2 */
		iParm[2] = 0;
		iParm[3] = 0;
#endif
		opt1 = (opt & D_GX_OPT_GET_DEF_ATTR) | D_GX_OPT_PARMINFO2;
		rc = cl_gx_expsn_obj_opt(line,llen,bxobj,Obj,tInfoParm2,opt1);
		if (rc) {
			/* %s: �����A�܂��́A���x�A�ʎ��̎w��(%s)������Ă��܂��Brc=%d */
			ERROROUT3(FORMAT(478),"_get_def_attr",strtemp(line,llen),rc);
			return ECL_SCRIPT_ERROR;
		}
		else {
			if (nparm=tInfoParm2[1].pi_pos) {
				if (!(rc=tInfoParm2[1].pi_hlen)) {
					pInfoParm = (tdtInfoParm *)tInfoParm2[1].pi_data;
					ppParm[0] = pInfoParm;
					if (nparm >= 2) {
						ppParm[1] = pInfoParm + 1;
						nparm = 2;
					}
				}
			}
			else {
				ppParm[0] = tInfoParm2;
				nparm = 1;
			}
			if (!rc) rc = cl_get_def_attr_check(nparm,ppParm,iParm,opt);
		}
	}
	return rc;
}

/************************************/
/*	cl_get_def_attr_opt				*/
/************************************/
int cl_get_def_attr_opt(varnam,vnlen,iParm,opt,bxobj,Obj)
char *varnam;
int   vnlen;
int   iParm[];
int   opt;
GXObject *bxobj[];
tdtRbChain *Obj;
{
	int rc,len,attr,size,line_len,iGET;
	qSubCommand *sc;
	char *line,*name;
/*
printf("cl_get_def_attr_opt: vnlen=%d varnam=[%s] opt=%08x\n",vnlen,varnam,opt);
if (bxobj) printf("cl_get_def_attr_opt: *bxobj=%08x\n",*bxobj);
*/
	iGET = 0;
	name = NULL;
	if (varnam && vnlen>0) {
		attr = 0;
		size = sizeof(tdtInfoParm *);
		len = akxnskipto(varnam,vnlen,"(");
		if (sc=cl_get_name_attr2(varnam,len,0x01,0x20)) {
			name = sc->name;
			size = sc->size;
			attr = sc->attr;
			if ((opt & 0x01) && (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK)) size = 0;
		}
		iParm[0] = attr & DEF_ZOK_MASK;	/* add & DEF_ZOK_MASK 2021.11.4 */
		iParm[0] |= attr & DEF_ZOK_IMGE;	/* add 2023.7.17 */
		iParm[1] = size;
		iParm[2] = 0;
		iParm[3] = attr & DEF_ZOK_USMASK;	/* add 2021.11.4 */
		if (iParm[0]==DEF_ZOK_BINA && (cl_get_option(17,0) & 0x100))
			iParm[3] |= DEF_ZOK_USMASK;
		line     = varnam + len;
		line_len = vnlen - len;
		if (vnlen > len) iGET = 1;
	}
	else {
		line     = "";
		line_len = 0;
		if (bxobj && bxobj[0]) iGET = 2;	/* 2026.10.1 1==>2 */
	}
	rc = 0;
#if 1	/* 2026.10.1 */
	if (iGET == 1) {
		rc = _chk_def_attr_name_able_get_size(name,iParm,opt);
	}
	if (!rc && iGET) {
#else
	if (iGET) {
#endif
	/*	rc = _get_def_attr(varnam+len,vnlen-len,iParm,opt,bxobj,Obj);	*/
		rc = _get_def_attr(line,line_len,iParm,opt,bxobj,Obj,name);
	}
/*
if (bxobj) printf("cl_get_def_attr_opt: iGET=%d *bxobj=%08x\n",iGET,*bxobj);
*/
	return rc;
}

/************************************/
/*	cl_set_parm_init				*/
/************************************/
int cl_set_parm_init(pInfoParm,iParm,opt)
tdtInfoParm *pInfoParm;
int iParm[],opt;
{
	int rc,attr,size,im,iRANGE,num,alen,iBLOCK,size_org;
	char *p;
	tdtInfoParm *pm[2],Info[2];
/*
printf("cl_set_parm_init:Enter attr=%d size=%d iParm[2]=%d iParm[3]=%08x opt=%08x\n",iParm[0],iParm[1],iParm[2],iParm[3],opt);
*/
	size_org = size = iParm[1];
	/* iParm[0]�ɂ́A21,22,23 �������ČĂ΂�邱�Ƃ�����̂ŁADEF_ZOK_MASK�Ń}�X�N�ł��Ȃ� */
	iBLOCK = pInfoParm->pi_aux[0] & D_AUX0_BLOCK_VAR;
	switch (attr=iParm[0]) {
		case 0:					/* add 2021.12.31 */
		case DEF_ZOK_VARI:
			rc = cl_parm_set0(pInfoParm);
			break;
		case DEF_ZOK_CHAR:
			rc = cl_set_parm_char(pInfoParm,NULL,0);
			break;
		case DEF_ZOK_BINA:
			rc = cl_set_parm_bin(pInfoParm,0);
			pInfoParm->pi_dlen = size;	/* add 2023.5.5 */
			if (iParm[3] == DEF_ZOK_USMASK) pInfoParm->pi_scale |= D_DATA_UNSIGNED;
#if 0	/* 2026.10.7 */
			MOD_BINA_LEN_BY_SIZE(size,size)
#else
			size = sizeof(long);
#endif
			break;
		case DEF_ZOK_FLOA:
			rc = cl_set_parm_double(pInfoParm,0.0);
			break;
		case DEF_ZOK_DECI:
		case DEF_ZOK_DATE:
			if (!(rc=cl_set_parm_mpa(pInfoParm,NULL))) {
				pInfoParm->pi_attr = attr;
				pInfoParm->pi_hlen = iParm[2];	/* precision */
				pInfoParm->pi_pos  = iParm[3];	/* scale */
/*
m_print_debug("cl_set_parm_init",pInfoParm->pi_data,0);
*/
			}
			break;
		case DEF_ZOK_BULK:
			rc = cl_set_parm_char(pInfoParm,NULL,0);
			pInfoParm->pi_attr = attr;
			break;
		case DEF_ZOK_VOID:
			cl_null_value(pInfoParm);
			return 0;
		default:
			rc = -100;
	}
/*
printf("cl_set_parm_init: attr=%d size=%d\n",attr,size);
*/
	iRANGE = opt & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA | D_AULN_RATIONAL);
	if (!rc && iRANGE && (attr==DEF_ZOK_DECI || attr==DEF_ZOK_DATE)) {
		pm[0] = &Info[0];
		pm[1] = &Info[1];
		cl_gx_copy_info(pm[0],pInfoParm);
		if (opt & D_AULN_RATIONAL) {
			num = 1;
			alen = D_AULN_RATIONAL;
		}
		else {
			num = 0;
			alen = D_AULN_COMPLEX_DATA;
		}
		rc = cl_set_parm_mpa(pm[1],m_get_i(num));
		rc = cl_gx_range_set(pInfoParm,2,pm,0);
#if 1	/* 2026.7.12 */
		if (opt & D_AULN_COMPLEX_DATA) {
			pInfoParm->pi_hlen = iParm[2];	/* precision */
			pInfoParm->pi_pos  = iParm[3];	/* scale */
		}
#endif
		pInfoParm->pi_alen |= alen | D_AULN_RANGE_DATA;
	}
	if (attr && attr!=DEF_ZOK_VARI && !rc) {
		pInfoParm->pi_len = size_org;		/* 2026.10.7 size==>size_org */
		pInfoParm->pi_aux[0] = attr;
		if (opt & 0x01) {
			if ((attr!=DEF_ZOK_BINA && attr!=DEF_ZOK_FLOA) ||
			    (attr==DEF_ZOK_FLOA && iRANGE)) {
				if (attr == DEF_ZOK_CHAR) size++;
				else if (attr == DEF_ZOK_BULK) size += sizeof(int);
				im = (opt & D_GX_OPT_ALC_MASK)>>12;
				if (!im) im = D_OPT_ALC_MALLOC;
				if (im & (D_OPT_ALC_TMP | D_OPT_ALC_MALLOC)) {
					if (iRANGE) size += size;
					if (p = cl_opt_malloc(im,size)) {
						if ((attr==DEF_ZOK_DECI || attr==DEF_ZOK_DATE) && pInfoParm->pi_data)
							memcpy(p,pInfoParm->pi_data,size);
						else memset(p,0,size);
						if (im == D_OPT_ALC_MALLOC) pInfoParm->pi_scale |= D_DATA_MALLOC;
					}
					else rc = -1;
/*
if (attr==4) {
if (p) m_print_debug("cl_set_parm_init",p,0);
else printf("cl_set_parm_init: rc=%d\n",rc);
}
*/
					pInfoParm->pi_data = p;
					pInfoParm->pi_scale &= ~D_DATA_LPOSDATA;
				}
				else rc = -1;
			}
		}
		pInfoParm->pi_paux = pInfoParm->pi_data;
	}
	pInfoParm->pi_aux[0] |= iBLOCK;
DEBUGOUT_InfoParm(151,"cl_set_parm_init: attr=%d rc=%d",pInfoParm,attr,rc);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_skip_to_delm(s,slen,delms,ssp,sep,level)
char *s,*delms,*sep;
int  slen;
SSPL_S *ssp;
int  level;
{
	char c,delm1,delm2,*wd;
	int len,wd_max;
	int kk_level;	/* ()�̃l�X�g���x�� */

	kk_level = level;
	delm1 = delms[0];
	delm2 = delms[1];
	wd = ssp->wd;
	wd_max = ssp->wdmax;
	ssp->wdmax = 0;
	while ((len=akxtgwnsl(s,slen,ssp,sep,0x41)) > 0) {
		if (ssp->attr[0] > 10) {
			c = *ssp->wd;
/*
printf("cl_skip_to_delm: sp=%d c=[%c]\n",ssp->sp,c);
*/
			if (c == delm1) kk_level++;
			else if (c == delm2) {
				if (kk_level > 0) {
					kk_level--;
					if (!kk_level) break;
				}
				else return -2;
			}
		}
	}
	if (len < 0) kk_level = len;
/*
printf("cl_skip_to_delm: sp=%d kk_level=%d\n",ssp->sp,kk_level);
*/
	ssp->wd = wd;
	ssp->wdmax = wd_max;
	return kk_level;
}

/****************************************/
/*										*/
/****************************************/
int clpeeksl(s,slen,ssp,sep,opt)
char *s,*sep;
int  slen,opt;
SSPL_S  *ssp;
{
	int sp,len;

	if (!ssp) return -1;

	sp = ssp->sp;
	len = akxtgwnsl(s,slen,ssp,sep,opt);
	ssp->sp = sp;
	return len;
}

/************************************/
/*	cl_get_def_attr_SSP_opt_sub		*/
/*  OUT : ssp->sp : int,dec(p,q)���A�܂��́A����ȊO��1���[�h��ǂݍ��񂾈ʒu */
/************************************/
int cl_get_def_attr_SSP_opt_sub(s,slen,ssp,sep,iParm,opt,bxobj,Obj)
char *s;
int   slen;
SSPL_S *ssp;
char  *sep;
int   iParm[];
int   opt;	/* 0x01:size=0, 0x02:int(n), 0x04:only error when (, 0x08: error when no attr */
GXObject *bxobj[];
tdtRbChain *Obj;
{
	static char *_fn_="cl_get_def_attr_SSP_opt";
	int rc,len,pos,wdmax_save,len1;
	int attr,size,dec_pre,dec_sca;
	qSubCommand *sc;
	char *line,*attr_name,*wrk,c,*wd_save,*name;
/*
printf("cl_get_def_attr_SSP_opt_sub:Enter ssp->sp=%d\n",ssp->sp);
*/
	if ((!s || slen<=0) && (bxobj && bxobj[0])) {
		return _get_def_attr("",0,iParm,opt,bxobj,Obj);
	}
	rc = 0;
	attr = dec_pre = dec_sca = 0;
	size = sizeof(tdtInfoParm *);
	iParm[0] = 0;
	iParm[1] = size;
	iParm[2] = 0;
	iParm[3] = 0;
	wd_save = ssp->wd;
	wdmax_save = ssp->wdmax;
	ssp->wdmax = 0;
	len = akxtgwnsl(s,slen,ssp,sep,0x1);
	attr_name = ssp->wd;
/*
printf("cl_get_def_attr_SSP_opt_sub:1 ssp->sp=%d attr_name=[%s]\n",ssp->sp,attr_name);
*/
	name = NULL;
	if (len>0 && (((c=*attr_name)>='A' && c<='Z') || (c>='a' && c<='z') || (opt & 0x08))) {
		if (sc=cl_get_name_attr2(attr_name,len,0x01,0x20)) {
			name = sc->name;
			size = sc->size;
			attr = sc->attr;
			if ((opt & 0x01) && (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK)) size = 0;
			iParm[0] = attr & (DEF_ZOK_DTYP | DEF_ZOK_RATI | DEF_ZOK_VOID);	/* add & DEF_ZOK_MASK 2021.11.4 *//* add DEF_ZOK_VOID 2026.3.11 */
			iParm[1] = size;
			iParm[3] = attr & DEF_ZOK_USMASK;	/* add 2021.11.4 */
/*
printf("cl_get_def_attr_SSP_opt_sub: iParm=%d %d %d %08x\n",iParm[0],iParm[1],iParm[2],iParm[3]);
*/
		}
		if ((opt & 0x08) && !sc) goto AttrErr;
		else if (sc || ((opt & 0x04) && !sc)) {
			attr &= DEF_ZOK_DTYP;		/* add 2026.10.1 */
			clpeeksl(s,slen,ssp,sep,0x41);
/*
printf("cl_get_def_attr_SSP_opt_sub:2 ssp->sp=%d\n",ssp->sp);
*/
			if (*ssp->wd == '(') {
				if (!sc) goto AttrErr;
#if 1	/* 2026.10.1 */
				rc = _chk_def_attr_name_able_get_size(name,iParm,opt);
				if (!rc &&
				    ((opt & 0x02) ||
				     (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_DECI || attr==DEF_ZOK_BULK || attr==DEF_ZOK_BINA
				    ))) {
#else
				if ((opt & 0x02) ||
				    (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_DECI || attr==DEF_ZOK_BULK)) {
#endif
					pos = ssp->sp;
					line = s + pos;
					if (rc=cl_skip_to_delm(s,slen,"()",ssp,sep,0)) {
						/* %s: �J�b�R�����Ă��܂���B */
						ERROROUT1(FORMAT(433),_fn_);
						rc = ECL_SCRIPT_ERROR;
					}
#if 1	/* 2026.7.4 */
					else {
						len1 = ssp->sp - pos;
/*
printf("%s: len1=%d line=[%s]\n",_fn_,len1,line);
*/
						if (len1!=3 || *(line+1)!='*') {
							rc = _get_def_attr(line,len1,iParm,opt|D_GX_OPT_GET_DEF_ATTR,bxobj,Obj);
						}
					}
#else
					else {
						rc = _get_def_attr(line,ssp->sp-pos,iParm,opt|D_GX_OPT_GET_DEF_ATTR,bxobj,Obj);
					}
#endif
				}
			}
		}
	}
	else if (opt & 0x08) {
		/* %s: �����w�肪����܂���B */
		ERROROUT1(FORMAT(498),_fn_);
		rc = ECL_SCRIPT_ERROR;
	}
	goto End;
 AttrErr:
	wrk = strname(attr_name,len);
	/* %s: ����������Ă��܂��Battr=[%s] */
	ERROROUT2(FORMAT(477),_fn_,wrk);
	rc = ECL_SCRIPT_ERROR;
 End:
	ssp->wd = wd_save;
	ssp->wdmax = wdmax_save;
	return rc;
}

/************************************/
/*	cl_get_def_attr_SSP_opt			*/
/************************************/
int cl_get_def_attr_SSP_opt(s,slen,ssp,sep,iParm,opt,bxobj,Obj)
char *s;
int   slen;
SSPL_S *ssp;
char  *sep;
int   iParm[];
int   opt;	/* 0x01:size=0, 0x02:int(n), 0x04:only error when (, 0x08: error when no attr */
GXObject *bxobj[];
tdtRbChain *Obj;
{
	int rc,spw,iParm2[8];

	rc = cl_get_def_attr_SSP_opt_sub(s,slen,ssp,sep,iParm,opt,bxobj,Obj);
	if (!rc && iParm[0]>0) {
		spw = ssp->sp;
		if (rc=cl_get_def_attr_SSP_opt_sub(s,slen,ssp,sep,iParm2,0,NULL,Obj)) return rc;
		else if (iParm2[0] > 0) {
			ERROROUT1(FORMAT(365),FORMAT(588));	/* �f�[�^�^�w�肪�d�����Ă��܂��B */
			rc = ECL_DUPLICATE;
		}
		else ssp->sp = spw;
	}
	return rc;
}

/************************************/
/*	cl_get_def_attr_SSP				*/
/************************************/
int cl_get_def_attr_SSP(s,slen,ssp,sep,iParm,bxobj,Obj)
char *s;
int   slen;
SSPL_S *ssp;
char  *sep;
int   iParm[];
GXObject *bxobj[];
tdtRbChain *Obj;
{
	return cl_get_def_attr_SSP_opt(s,slen,ssp,sep,iParm,0x01,bxobj,Obj);
}

/************************************/
/*	cl_im_parmset					*/
/************************************/
int cl_im_parmset(im,qprmp,pp,len)
int  im;
parmList *qprmp[];
char *pp;
int  len;
{
	parmList *prmp;
	char *p;
	int rc;

	if (!(p=cl_opt_malloc(im,sizeof(parmList)+len+1))) return ECL_MALLOC_ERROR;
	prmp = (parmList *)p;
	memset(prmp,0,sizeof(parmList));
	p += sizeof(parmList);
	memzcpy(p,pp,len);
/*
printf("cl_im_parmset: n=%d len=%d wd=[%s]\n",n,len,p);
*/
	prmp->prp = p;
	prmp->prmlen = len;
	qprmp[0] = prmp;
	return 0;
}

/************************************/
/*	cl_im_parmcpy					*/
/************************************/
int cl_im_parmcpy(im,qprmp,prmp0)
int  im;
parmList *qprmp[],*prmp0;
{
	int rc;
	parmList *prmp;

	if (rc=cl_im_parmset(im,qprmp,prmp0->prp,prmp0->prmlen)) return rc;
	prmp = qprmp[0];
	prmp->opt = prmp0->opt;
	prmp->bxobj = prmp0->bxobj;
/*
printf("cl_im_parmcpy: bxobj=%08x\n",prmp->bxobj);
*/
	return 0;
}

/************************************/
/*	_parmset						*/
/************************************/
static int _parmset(qprmp,nmax,n,pp,len)
parmList *qprmp[];
int   nmax,n;
char *pp;
int  len;
{
	int rc;

	if ((rc=cl_im_parmset(D_OPT_ALC_TMP,&qprmp[n],pp,len)) >= 0) rc = n + 1;
	return rc;
}

/********1*********2*********3*********4*********5*********6*********/
/*	cl_get_array_def_parm											*/
/*	(nmax<=0 || !qprmp)�̂Ƃ��́A�z���`��ǂݔ�΂��B				*/
/*	���A����Ƃ��Assp.sp�́A�z���`�̎��̃��[�h��ǂ񂾌�̈ʒu�A	*/
/*	�z���`���Ȃ��Ƃ��́A�ŏ��Ƀ��[�h��ǂ񂾌�̈ʒu�A			*/
/*  �܂��́Aslen���w���B											*/
/********************************************************************/
int cl_get_array_def_parm(s,slen,dlm,ssp,sep,nmax,qprmp,iEQU)
char *s;
int   slen;
char  *dlm;
SSPL_S  *ssp;
char  *sep;
int   nmax;
parmList *qprmp[];
int  *iEQU;
{
	static char *name="cl_get_array_def_parm";
	int len,kk,n,iSET,iRANGE,is,atr0,kk_level,i,atr_gw;
	char c,c1,*p,*pp,wrk[128],k1,k2,wsep[37],*pat;
	parmList *prmp;
	SSPL_S  sspl;
	uchar uc;
/*
printf("%s:Enter: nmax=%d dlm=[%s] sep=[%s]\n",name,nmax,dlm,sep);
printf("%s:Enter: sp=%d slen=%d s=[%s]\n",name,ssp->sp,slen,s);
*/
	/* 2020.10.25 */
	len = clpeeksl(s,slen,ssp,sep,0x41);
/*
printf("%s: len=%d sp=%d wd=[%s]\n",name,len,ssp->sp,ssp->wd);
*/
	n = 0;
	if (len > 0) {
		pp = strmemk(ssp->wd,len,name);
/*
printf("%s: wd=[%s]\n",name,pp);
*/
		if (!stricmp(pp,"HASH")) {
			len = akxtgwnsl(s,slen,ssp,sep,0x41);
			if (n<nmax && qprmp) {
				if ((n=_parmset(qprmp,nmax,n,pp,len)) < 0) {
					return n;
				}
			}
			len = clpeeksl(s,slen,ssp,sep,0x41);
		}
		/* 2021.5.7 */
	}
	if (len <= 0) {
/*
printf("%s:Exit: n=%d sp=%d wd=[%s]\n",name,n,ssp->sp,strmem(ssp->wd,len));
*/
		return n;
	}
	strcpy(p=wsep," \t'+-*/&|");
	p += strlen(p);
	pp = dlm;
	for (i=0;i<30 && (uc=*pp++);i++) {
		if (uc == '`');
		else if ((uc>=' ' && uc<'0') || (uc>'9' && uc <'A') ||
		    (uc>'Z' && uc<'a') || (uc>'z' && uc <0x7f)) *p++ = uc;
	}
	*p = '\0';
	if ((k1=*ssp->wd)=='[' || k1=='(') {
		kk = 1;
		akxtgwnsl(s,slen,ssp,sep,0x41);
		is = ssp->sp;
		if (k1 == '[') k2 = ']';
		else k2 = ')';
		*p++ = k1;
		*p++ = k2;
		strcpy(p,",");
		kk_level = 1;
	}
	else {
		is = ssp->sp;
		kk = 0;
	}
/*
printf("%s: kk=%d wsep=[%s]\n",name,kk,wsep);
*/
	iSET = iRANGE = 0;
	while ((len=akxtgwnsl(s,slen,ssp,wsep,0x41)) > 0) {
/*
printf("%s: n=%d sp=%d wd=[%s]\n",name,n,ssp->sp,strtemp(ssp->wd,len));
*/
		c = *ssp->wd;
		if (kk) {
			if (c == k2) {
				if (kk_level > 0) kk_level--;
				else {
					ERROROUT2("%s: '%c' unmatched.\n",name,c);
						return ECL_EX_DEFINE;
				}
				if (kk_level > 0) continue;
				iSET = ssp->sp;
/*
printf("%s: sp=%d\n",name,ssp->sp);
*/
				if ((len=akxtgwnsl(s,slen,ssp,wsep,0x41)) > 0) {
/*
printf("%s: len=%d sp=%d wd=[%s]\n",name,len,ssp->sp,strmem(ssp->wd,len));
*/
					if (*dlm == '`')
						pat = strname3("`",1,ssp->wd,len,"`",1);
					else
						pat = strname(ssp->wd,len);
/*
printf("%s: pat=[%s]\n",name,pat);
*/
					if (!inistr(dlm,pat)) {
						/* 2021.5.7 */
						ERROROUT2(FORMAT(567),name,pat);	/* %%s: �]���ȕ���(%s)������܂��B */
						return ECL_EX_DEFINE;
					}
					if (iEQU) *iEQU = ssp->sp;
				}
/*
printf("%s: len=%d sp=%d wd=[%s]\n",name,len,ssp->sp,strmem(ssp->wd,len));
*/
			}
			else if (c == ',') {
				iSET = ssp->sp;
			}
			else {
				if (c == k1) kk_level++;
				continue;
			}
		}
		else {
			if (instrchar("+-*/&|",c) > 0) {
				c1 = *(s+ssp->sp);
/*
printf("%s: c1=[%c]\n",name,c1);
*/
				if (c1 == '=') {
					ERROROUT1(FORMAT(171),name);	/* %s: SYNTAX�G���[�B */
					return ECL_EX_DEFINE;
				}
				else if (c1!=' ' && c1!='\t') continue;
				c1 = *(s+ssp->sp-2);
				if (c1!=' ' && c1!='\t') continue;
			}
			if (*dlm == '`')
				pat = strname3("`",1,ssp->wd,len,"`",1);
			else
				pat = strname(ssp->wd,len);
/*
printf("%s: pat=[%s]\n",name,pat);
*/
			if (inistr(dlm,pat)) {
/*
printf("%s: c=[%c]\n",name,c);
*/
				if (c=='=' && n>0) {
					sspl.sp = 0;
					sspl.wd = wrk;
					sspl.wdmax = sizeof(wrk);
					p = stradd(qprmp[n-1]->prp,"=");
					atr0 = cmpgwnsl(p,qprmp[n-1]->prmlen+1,&sspl);
/*
printf("%s: atr0=%d p=[%s]\n",name,atr0,p);
*/
					if (atr0>=71 && atr0<=90) n--;
				}
				if (c == '=') {
					if (iEQU) *iEQU = ssp->sp;
				}
				break;
			}
			pp = s + ssp->sp;
			for (i=ssp->sp;i<slen;i++) {
/*
printf("%s: i=%d c=[%c]\n",name,i,*pp);
*/
				if (instrchar(" \t\n\r,]=",*pp) > 0) break;
				pp++;
			}
			ssp->sp = i;
			iSET = ssp->sp + 1;
		}
		if (n<nmax && qprmp) {
			len = iSET - is - 1;
			pp = s + is;
			/* 2021.5.7 */
			pp = strmemk(pp,len,name);
			if (!stricmp(pp,"HASH")) {
				ERROROUT2(FORMAT(469),name,pp);	/* %s: \"%s\"�̈ʒu���s���ł��B*/
				return ECL_EX_DEFINE;
			}
			else if (cl_is_yoyakugo(pp)) {
				ERROROUT2(FORMAT(121),name,pp);	/* %s: [%s]�͗\���ł��B */
				return ECL_EX_DEFINE;
			}
/*
printf("%s: n=%d sp=%d pp=[%s]\n",name,n,ssp->sp,strmem(pp,len));
*/
			if ((n=_parmset(qprmp,nmax,n,pp,len)) < 0) break;
		}
/*
printf("%s: c=[%c]\n",name,c);
*/
		if (c == k2) break;
		is = iSET;
	}
/*
printf("%s:Exit: n=%d sp=%d\n",name,n,ssp->sp);
*/
	return n;
}

/************************************/
/*	_def_type_mappedarray			*/
/************************************/
static int _def_type_mappedarray(nparm,qprmp,pIndex)
int nparm;
parmList *qprmp[];
tdtArrayIndex *pIndex;
{
	static char *_name_="_def_type_mappedarray";
	int *index,i,rc;

	memset(pIndex,0,sizeof(tdtArrayIndex));
	pIndex->uAttr[0] = DEF_ZOK_VARI;
	pIndex->size = sizeof(tdtInfoParm *);
	index = pIndex->index;
	index[0] = 1;
	index[2] = 0;
	for (i=0;i<=index[0];i++) index[i+3] = 1;
	index[4] = 10;
	index[1] = index[4];
	if ((rc=_set_index(0,nparm,qprmp,0,index,_name_)) < 0) return rc;
	pIndex->uaux2 |= rc;
/*	if (index[3]+index[1]-1 < 0) {	*/
	if (index[3]+index[1] < 0) {
		/* %s: �͈͎w��([%d,%d,%d])���z��̍ő��(%d)�𒴂��Ă��܂��B */
		ERROROUT5(FORMAT(448),_name_,index[1],index[2],index[3],INT_MAX);
		return ECL_SCRIPT_ERROR;
	}
	return 0;
}

/****************************************/
/*	_get_def_member						*/
/*  type = array:						*/
/*		[�f�[�^�^] �z��^�� �z��̒�`	*/
/*  type = mappedarray:					*/
/*				   �z��^�� �z��̒�`	*/
/*  type = struct:						*/
/*		[�f�[�^�^] �ϐ���   �z��̒�`	*/
/****************************************/
static int _get_def_member(s,slen,ssp,varlen,pTypeInfo,parmName,type,opt,pos,bxobj,Obj)
char *s;
int  slen;
SSPL_S *ssp;
int  varlen;
tdtInfoParm *pTypeInfo[];
parmList  *parmName[];
int  type,opt,pos;
GXObject *bxobj[];
tdtRbChain *Obj;
{
	static char *_func="_get_def_member";
	int  i,iParmNo,rc,vnlen,attr,len,nparm,n,attr_set,kk,nset,is;
	int  size,iCOMPLEX,attr_set1;
	char c,*varnam,*pp,*p,*argv[6],*name,id;
	tdtInfoParm *pInfoParm,tInfoParm,tInfoParm2[2],tInfoType,*pInfoDef;
	tdtArrayIndex tIndex,*pIndex;
	int *index;
	int dec_pre,dec_sca,iParm[6];
	parmList *pL,**ppPrm,*prmpi,prmW;
	parmList *qprmp[4];
	ProcCT *proc;

	id = 'R';
	if (type == D_AUX0_TYPE_STRUCT) {
		name = FORMAT(465);	/* �����o�� */
		nset = 3;
	}
	else {
		name = FORMAT(466);	/* �^��`�� */
		if (type == D_AUX0_TYPE_ARRAY) nset = 3;
		else {
			nset = 4;
			id = 'A';
		}
	}

	varnam = ssp->wd;
	vnlen  = varlen;
/*
printf("_get_def_member:1 ssp->sp=%d s=[%s] vnlen=%d varnam=[%s]\n",ssp->sp,s,vnlen,varnam);
*/
	/* ���ڗL���`�F�b�N */
	vnlen = akxtpknsl(s,slen,ssp,gsep,0x41);
	if (vnlen<=0 || *varnam==',') {
		ERROROUT2(FORMAT(76),_func,name);	/* %s: %s������܂���B */
		return ECL_EX_DEFINE;
	}

	/* �ϐ��pInfoParm�̎擾 */
	if (!(pInfoParm=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
	cl_parm_set0(pInfoParm);	/* add 2021.12.31 */
	pTypeInfo[0] = pInfoParm;

	/* �����̎擾 */
	iCOMPLEX = 0;
	if (id == 'R') {	/* MAPPEDARRAY�̂Ƃ��́A�����͎w��ł��Ȃ� */
		/* 2023.5.15 */
		if ((rc=clpeeksl(s,slen,ssp,gsep,0x41)) > 0) {
/*
printf("%s: rc=%d wd=[%s]\n",_func,rc,strname(ssp->wd,rc));
*/
			p = "COMPLEX";
			if (!memrngcmp_opt(ssp->wd,rc,p,0,strlen(p),1)) {
				iCOMPLEX = D_AULN_COMPLEX_DATA | D_AULN_RANGE_DATA;
				akxtgwnsl(s,slen,ssp,gsep,0x41);
/*
printf("%s: iCOMPLEX=%08x ssp->sp=%d\n",_func,iCOMPLEX,ssp->sp);
*/
			}
		}
		if ((rc=clpeeksl(s,slen,ssp,gsep,0x41)) > 0) {
			varnam = ssp->wd;
			vnlen  = rc;
/*
printf("%s: vnlen=%d varnam=[%s]\n",_func,vnlen,strname(varnam,vnlen));
*/
		}
		is = ssp->sp;
		if (rc=cl_get_def_attr_SSP(s,slen,ssp,gsep,iParm,NULL,NULL)) return rc;
		/* ���̎��_�Ńf�[�^�^�̎w�肪�Ȃ������Ƃ��́Assp->wd�ɂ͕ϐ���������A*/
		/* ssp->sp�͕ϐ����̌��Ɉړ����Ă��� */
		/* �f�[�^�^�̎w�肪�������Ƃ��́A���̌��̕ϐ�����ǂݍ��ޕK�v������ */
		/* 2023.5.15 */
		attr_set = iParm[0];
		if (iCOMPLEX) {
/*
printf("%s: iParm[0]=%d\n",_func,iParm[0]);
*/
			if ((rc=cl_complex_attr_check(iParm)) < 0) return rc;
		}
		if (!iParm[0]) {
			proc = cl_search_proc_ct();
			if ((rc=cl_get_def_type(s,slen,ssp,is,proc,NULL,0,iParm,&tInfoType)) < 0) return rc;
			/* ���̎��_�Ńf�[�^�^�̎w�肪�Ȃ������Ƃ��́Assp->sp�͌��̈ʒu�ɖ߂��Ă��� */
			attr_set = 1;
			if (!iParm[0]) {
#if defined(_LP64)	/* 2021.2.13 */
				memcpy(&pInfoDef,iParm+2,sizeof(char *));
				if (pInfoDef) {
#else
				if (pInfoDef = (tdtInfoParm *)iParm[2]) {
#endif
					iParm[0] = pInfoDef->pi_aux[0];
					cl_gx_rep_info_set_ign(pInfoParm,pInfoDef,1);
				}
				else iParm[0] = DEF_ZOK_VARI;
			}
		}
		else {
			attr = iParm[0];
			size = iParm[1];
			cl_set_parm_init(pInfoParm,iParm,0);
			if (attr != DEF_ZOK_VARI) {
				pInfoParm->pi_aux[0] = attr;
				pInfoParm->pi_len = size;
			}
			pInfoParm->pi_alen |= iCOMPLEX;
		}
	}
	else {
		attr_set = 1;	/* ssp->sp�͕ϐ����̑O�ɂ���̂ŁA�ϐ�����ǂݍ���ŁA
							�ϐ����̌�Ɉړ������邽�� */
		iParm[0] = attr = DEF_ZOK_VARI;
		cl_set_parm_init(pInfoParm,iParm,0);
	}
/*
printf("%s: id=[%c] iParm[0]=%d attr_set=%d sp=%d\n",_func,id,iParm[0],attr_set,ssp->sp);
*/
	/* �ϐ����̎擾 */
	if (attr_set) {
		vnlen = akxtgwnsl(s,slen,ssp,gsep,0x41);
		if (vnlen <= 0) {
			ERROROUT2(FORMAT(76),_func,name);	/* %s: %s������܂���B */
			return ECL_EX_DEFINE;
		}
		varnam = ssp->wd;
	}
/*
printf("%s: vnlen=%d varnam=[%s]\n",_func,vnlen,strname(varnam,vnlen));
*/
	if ((c=*varnam)=='%' || c=='#') {
		ERROROUT2(FORMAT(125),_func,strname(varnam,vnlen));	/* %s: [%s]������Ă��܂��B*/
		return ECL_EX_DEFINE;
	}
	if (rc=cl_def_chk_name(varnam,vnlen,_func,name)) return rc;
	if (c == '$') {
		varnam++;
		vnlen--;
	}
	if (!(pL=(parmList *)Malloc(sizeof(parmList)))) return ECL_MALLOC_ERROR;
	parmName[0] = pL;
	pL->prp = Memdup(varnam,vnlen);
	pL->prmlen = vnlen;
	pL->opt = pos;
	if (attr == DEF_ZOK_BULK) size += sizeof(int);
	if (pInfoParm->pi_aux[0])
		pos += ((size+sizeof(int)-1)/sizeof(int))*sizeof(int);

	/* �z���`�̎擾 */
	n = cl_get_array_def_parm(s,slen,",",ssp,gsep,nset,qprmp,NULL);
	if (n < 0) return n;
	else if (n>0 || (type==D_AUX0_TYPE_ARRAY || type==D_AUX0_TYPE_MAPPED)) {
		if (id == 'R') {
			if (rc=_def_array(n,qprmp,opt|D_GX_OPT_NOALLOC_INDX,iParm,&tIndex,0,0)) return rc;
		}
		else {
			if (rc=_def_type_mappedarray(n,qprmp,&tIndex)) return rc;
		}
		attr = iParm[0];
		cl_parm_set0(pInfoParm);	/* add 2025.10.18 */
		pInfoParm->pi_id   = id;
		pInfoParm->pi_scale = D_DATA_MALLOC | D_DATA_INDEX_FREE;
		pInfoParm->pi_attr = DEF_ZOK_BULK;	/* attr;	*/
		pInfoParm->pi_dlen  = sizeof(tdtArrayIndex);
		if (!(pInfoParm->pi_data = Malloc(sizeof(tdtArrayIndex)))) return ECL_MALLOC_ERROR;
		memcpy(pInfoParm->pi_data,&tIndex,sizeof(tdtArrayIndex));
		if (!(p=Malloc(vnlen+1))) {
			ERROROUT1("%s: Array name area malloc",_func);
			rc = ECL_MALLOC_ERROR;
			goto Error;
		}
		strnzcpy(p,varnam,vnlen);
		pInfoParm->pi_pos = (long)p;
		index = tIndex.index;
		size = tIndex.size;
		if (attr=tIndex.uAttr[0]) {
			if (attr == DEF_ZOK_CHAR) size++;
			else if (attr == DEF_ZOK_BULK) size += sizeof(int);
			len = index[1]*size;
			pos = pL->opt + ((len+sizeof(int)-1)/sizeof(int))*sizeof(int);
		}
		else pos = pL->opt;

DEBUGOUT_InfoParm(194,"cl_pr_ex_def_type: attr=%d size=%d",pInfoParm,attr,size);

/*
len = akxtgwnsl(s,slen,ssp,gsep,0x41);
printf("cl_pr_ex_def_type: len=%d *wd=[%c]\n",len,*ssp->wd);
*/
	}
	return pos;
 Error:
	return rc;
}

/************************************/
/*	cl_pr_ex_def_type				*/
/************************************/
int cl_pr_ex_def_type(prmnum, pprmp, scrct, proc, opt)
int      prmnum;
parmList **pprmp;
ScrPrCT  *scrct;
ProcCT   *proc;
int      opt;
{
	static char *sep=" \t(){}[],'";
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	XHASHB *pha_vname,*xhp;
	tdtInfoParm ***pTBL_vname;
	int  i,iParmNo,rc,vnlen,attr,len,nparm,n,attr_set,type,is,scope;
	int  size,pos,slen;
	char c,*varnam,*pp,*p,*argv[8],*s;
	tdtInfoParm *pInfoParm,tInfoParm,tInfoParm2[2];
	tdtArrayIndex tIndex,*pIndex;
	int *index;
	int dec_pre,dec_sca,iParm[6];
	parmList  *parmName[MAX_MEMBER],*pL,**ppPrm,*prmpi,prmW;
	tdtInfoParm *pTypeInfo[MAX_MEMBER];
	tdtDefType *pDeftype;
	int ntype;
	SSPL_S ssp;
	parmList *qprmp[3];
/*
printf("cl_pr_ex_def_type:Enter prmnum=%d opt=%08x\n",prmnum,opt);
*/
	argv[0] = "cl_pr_ex_def_type";
	/* parameter check */
	/* DEFINE TYPE STRUCT name
	      var_type var_name,
	      var_type var_name;
	   DEFINE TYPE ARRAY var_type var_name;
	   DEFINE TYPE MAPPEDARRAY var_type var_name;	*/
	nparm = 3;
	if (prmnum >= 2) {
		p = pprmp[1]->prp;
		if (!stricmp(p,"ARRAY")) type = D_AUX0_TYPE_ARRAY;
		else if (!stricmp(p,"MAPPEDARRAY")) type = D_AUX0_TYPE_MAPPED;
		else if (!stricmp(p,"STRUCT")) {
			type = D_AUX0_TYPE_STRUCT;
			nparm++;
		}
		else type = -1;
	}
	if (prmnum < nparm) {
		/* %s: �p�����[�^������܂���Bprmnum=%d */
		ERROROUT2(FORMAT(467),argv[0],prmnum);
		return ECL_EX_DEFINE;
	}

	is = 2;
	pha_vname = NULL;
	if (type == D_AUX0_TYPE_STRUCT) {
		varnam = pprmp[2]->prp;
		vnlen  = pprmp[2]->prmlen;
		if ((c=*varnam)=='%' || c=='#') {
			ERROROUT2(FORMAT(125),argv[0],strname(varnam,vnlen));	/* %s: [%s]������Ă��܂��B*/
			return ECL_EX_DEFINE;
		}
		if (rc=cl_def_chk_name(varnam,vnlen,argv[0],FORMAT(466))) return rc;	/* �^��`�� */
		is = 3;
	}
	else if (type!=D_AUX0_TYPE_ARRAY && type!=D_AUX0_TYPE_MAPPED) {
		/* %s: �^�w�肪����Ă��܂��Btype=[%s] */
		ERROROUT2(FORMAT(468),argv[0],p);
		return ECL_EX_DEFINE;
	}

	ntype = pos = 0;
	s = pprmp[is]->prp;
	slen = pprmp[is]->prmlen;
/*
printf("cl_pr_ex_def_type: type=%d slen=%d s=[%s]\n",type,slen,s);
*/
	memset(&ssp,0,sizeof(SSPL_S));
	if (type==D_AUX0_TYPE_ARRAY || type==D_AUX0_TYPE_MAPPED) {
		if ((vnlen=clpeeksl(s,slen,&ssp,gsep,0x41)) > 0) {
			if ((pos=_get_def_member(s,slen,&ssp,vnlen,&pTypeInfo[0],&parmName[0],type,opt,pos,0,0)) < 0) {
				rc = pos;
				goto Error;
			}
			varnam = parmName[0]->prp;
			vnlen  = parmName[0]->prmlen;
		}
	}
	else {
		while ((vnlen=clpeeksl(s,slen,&ssp,sep,0x41)) > 0) {
			if ((pos=_get_def_member(s,slen,&ssp,vnlen,&pTypeInfo[ntype],&parmName[ntype],type,opt,pos,0,0)) < 0) {
				rc = pos;
				goto Error;
			}
			ntype++;
		}
		varnam = pprmp[2]->prp;
		vnlen  = pprmp[2]->prmlen;
	}
 	if (!(opt & D_GX_OPT_SET_SCOPE)) {
		if (proc) {
			if (!(pGlobTable->options[9] & 0x01) && (scrct->sc_pFlag & D_SCRPT_NEW_LEX))
				opt |= D_GX_OPT_SET_LOCAL;
			else opt |= D_GX_OPT_SET_PRIVATE;
		}
		else opt |= D_GX_OPT_SET_PRIVATE;
	}
	attr = DEF_ZOK_BULK;
	if ((c=*varnam) == '$') {
		varnam++;
		vnlen--;
	}
	if ((rc=_chk_define(scrct,proc,varnam,vnlen,opt,argv)) < 0) return rc;
	pha_vname  = (XHASHB *)argv[4];

	if ((iParmNo=cl_gx_chk_vnam_info('s',pha_vname,varnam,vnlen,&pInfoParm)) < 1) {
		/* %s: %s��%s�G���g���p�̋󂫂�����܂���B */
		ERROROUT3(FORMAT(323),argv[0],varnam,argv[3]);
		rc = ECL_SCRIPT_ERROR;
		goto Error;
	}
	if (!pInfoParm) return ECL_SCRIPT_ERROR;

	info_parm_clear(pInfoParm);
	if (type==D_AUX0_TYPE_STRUCT) {
		pInfoParm->pi_scale = D_DATA_MALLOC | D_DATA_INDEX_FREE;
		pInfoParm->pi_attr = attr;
		pInfoParm->pi_dlen = sizeof(tdtDefType);
		pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED;
		if (!(pDeftype=(tdtDefType *)Malloc(sizeof(tdtDefType)))) return ECL_MALLOC_ERROR;
		memset(pDeftype,0,sizeof(tdtDefType));
		pDeftype->size = pos;
		pDeftype->ntype = ntype;
		pInfoParm->pi_data = (char *)pDeftype;
		if (!(pDeftype->vname=(parmList **)Malloc(ntype*sizeof(parmList *)))) return ECL_MALLOC_ERROR;
		memcpy(pDeftype->vname,parmName,ntype*sizeof(parmList *));
		if (!(pDeftype->pType=(tdtInfoParm **)Malloc(ntype*sizeof(tdtInfoParm *)))) return ECL_MALLOC_ERROR;
		memcpy(pDeftype->pType,pTypeInfo,ntype*sizeof(tdtInfoParm *));
		if (!(p=Malloc(vnlen+1))) {
			ERROROUT1("%s: Type def name area malloc",argv[0]);
			rc = ECL_MALLOC_ERROR;
			goto Error;
		}
		strnzcpy(p,varnam,vnlen);
		pInfoParm->pi_pos = (long)p;
	}
	else {
		*pInfoParm = *pTypeInfo[0];
		pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED;
	}
	pInfoParm->pi_id     = 'P';
	pInfoParm->pi_aux[0] = type;
	pInfoParm->pi_len    = ++pGLprocTable->gid;
	i = akxs_xhasl(pGLprocTable->pha_gid,'S',pInfoParm->pi_len,0);
/*
printf("cl_pr_ex_def_type: Store gid=%ld ix=%d\n",pInfoParm->pi_len,i);
*/
	/* 2021.3.30 */
	pInfoParm->pi_hlen = _get_gid(scrct,proc,opt);

DEBUGOUT_InfoParm(194,"cl_pr_ex_def_type: attr=%d",pInfoParm,attr,0);

	rc =  0;

 Error:
	return rc;
}

/************************************/
/*	_def_var_array_member			*/
/************************************/
int _def_var_array_member(pParm,opt)	/* add opt 2024.12.26 */
tdtInfoParm *pParm;
int opt;
{
	tdtArrayIndex *pIndex;
	int *index,attr,size,len,n,iParmW[4],rc,iRANGE;
	char *p,*p0;

DEBUGOUT_InfoParm(170,"_def_var_array_member:Enter: opt=%08x",pParm,opt,0);

	if (!(pIndex = (tdtArrayIndex *)Malloc(sizeof(tdtArrayIndex)))) return -1;
	memcpy(pIndex,pParm->pi_data,sizeof(tdtArrayIndex));
	pParm->pi_data = (char *)pIndex;
	/* 2021.3.1 */
	if (p0=(char *)pParm->pi_pos) {
		if (!(p=Malloc((len=strlen(p0))+1))) {
			ERROROUT("_def_var_array_member: array name area malloc");
			return ECL_MALLOC_ERROR;
		}
		strnzcpy(p,p0,len);
		pParm->pi_pos = (long)p;
	}
	index = pIndex->index;
	if (index[2] < 0) {	/* HASH */
		if (!(pIndex->xhp = akxs_xhash_new2(0,index[4],0,pIndex->size))) return -9;
	}
	else {
		iParmW[0] = pIndex->uAttr[0];
		iParmW[1] = pIndex->size;
		iParmW[2] = 0;
		iRANGE = pParm->pi_alen & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA);
		if ((size=cl_get_def_alsize(iParmW,iRANGE)) < 0) return size;
		n = index[1];
		if (rc=_def_array_set_init_by_attr(iParmW[0],n,size,pIndex,iParmW)) return rc;
	}
	pParm->pi_hlen = _get_gid(NULL,NULL,opt);
	pParm->pi_paux = (char *)pParm;	/* �R�s�[���ꂽ�Ƃ��ɁA���̔z�񂪗L�������`�F�b�N���邽�߂ɕۑ����� */
	return 0;
}

/************************************/
/*	_def_var_struct					*/
/*  �쐬 : 2020.10.12				*/
/************************************/
int _def_var_struct(pInfoParm,pDeftypeP,pDefname,opt)
tdtInfoParm *pInfoParm;
tdtDefType *pDeftypeP;
char *pDefname;
int opt;
{
	tdtInfoParm *pParm,*pInfoP,**pTypeD,**pTypeS;
	tdtDefType *pDeftype,*pDef;
	parmList  **parmName;
	int  j,rc,ntype,attr,size,type,iRANGE;
	char id,*p,*p1,*p0;
	uchar uAux0;

DEBUGOUT_InfoParm(170,"_def_var_struct:Enter: pDefname=[%s] opt=%08x",pInfoParm,nval(pDefname),opt);
DEBUGOUTL1(170,"_def_var_struct: pDeftypeP=%08x",pDeftypeP);
/*
printf("_def_var_struct:Enter: pDefname=[%s]\n",nval(pDefname));
*/
	pInfoParm->pi_id = 'T';
	pDeftype = (tdtDefType *)pInfoParm->pi_data;
	ntype = pDeftype->ntype;
	parmName = pDeftype->vname;
	pTypeS = pDeftypeP->pType;
	if (!(pDeftype->pType=(tdtInfoParm **)Malloc(ntype*sizeof(tdtInfoParm *)))) return -1;
	rc = 0;
	for (j=0;j<ntype;j++) {
		if (!(pParm=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return -1;
		pDeftype->pType[j] = pParm;
		pInfoP = pTypeS[j];
DEBUGOUT_InfoParm(170,"_def_var_struct: pInfoP=",pInfoP,0,0);
		/* 2021.11.23 */
		uAux0 = pInfoP->pi_aux[0];
		if (rc=cl_gx_rep_info_set_ign(pParm,pInfoP,1)) return rc;
		pParm->pi_aux[0] = uAux0;
DEBUGOUT_InfoParm(170,"_def_var_struct:1 pParm=",pParm,0,0);
		if ((id=pParm->pi_id)=='A' || id=='R') {
			if (rc=_def_var_array_member(pParm,opt)) return rc;
		}
		else if (id == 'P') {
			type = pParm->pi_aux[0];
			pDef = (tdtDefType *)pInfoP->pi_data;
			if (type == D_AUX0_TYPE_STRUCT) {
DEBUGOUTL1(170,"_def_var_struct: pDef=%08x",pDef);
				if (rc=_def_var_struct(pParm,pDef,(char *)pInfoP->pi_pos,opt)) return rc;
			}
			else {
				if (type == D_AUX0_TYPE_ARRAY) {
					pParm->pi_id = 'R';
					if (rc=_def_var_array_member(pParm,opt)) return rc;
				}
				else pParm->pi_id = 'A';
			}
		}
		else if (attr=pParm->pi_aux[0]) {
			iRANGE = pInfoP->pi_alen & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA);
			if ((attr!=DEF_ZOK_BINA && attr!=DEF_ZOK_FLOA) ||
			    (attr==DEF_ZOK_FLOA && iRANGE)) {
		/*	if (attr!=DEF_ZOK_BINA && attr!=DEF_ZOK_FLOA) {	*/
				size = pParm->pi_len;
				if (attr == DEF_ZOK_CHAR) size++;
				else if (attr == DEF_ZOK_BULK)
					size += sizeof(int);
				if (iRANGE) size += size;
				if (p = Malloc(size)) {
					if (attr==DEF_ZOK_DECI || attr==DEF_ZOK_DATE)
						memcpy(p,pParm->pi_data,size);
					else strcpy(p,pParm->pi_data);
					pParm->pi_scale |= D_DATA_MALLOC;
				}
				else rc = -1;
				pParm->pi_data = p;
				pParm->pi_scale &= ~D_DATA_LPOSDATA;
			}
			pParm->pi_paux = pParm->pi_data;
			pParm->pi_aux[1] &= ~D_AUX1_PROTECTED;
			pParm->pi_alen |= iRANGE;
		}
DEBUGOUT_InfoParm(170,"_def_var_struct:2 pParm=",pParm,0,0);
	}
	rc = cl_set_struct_name(pInfoParm,pDefname);
	pInfoParm->pi_hlen = _get_gid(NULL,NULL,opt);
	pInfoParm->pi_paux = (char *)pInfoParm;	/* �R�s�[���ꂽ�Ƃ��ɁA���̍\���̂��L�������`�F�b�N���邽�߂ɕۑ����� */
/*
printf("_def_var_struct: rc=%d\n",rc);
*/
	return rc;
}

/************************************/
/*	cl_set_struct_name_len			*/
/************************************/
int cl_get_struct_name_len(pDefname)
char *pDefname;
{
	int pos;

	if (pDefname) {
		if ((pos=instrchar(pDefname,':')) < 0) return pos;
		else if (pos > 0) {
			pos--;
		}
		else pos = strlen(pDefname);
	}
	else pos = -1;
/*
printf("cl_get_struct_name_len:Exit: pos=%d\n",pos);
*/
	return pos;
}

/************************************/
/*	cl_set_struct_name				*/
/************************************/
int cl_set_struct_name(pInfoParm,pDefname)
tdtInfoParm *pInfoParm;
char *pDefname;
{
	int pos;
	char *p,*p0,*p1;

	if ((pos=cl_get_struct_name_len(pDefname)) >= 0) {
		if (!(p=Malloc(strlen(p1=(char *)pInfoParm->pi_pos)+pos+2))) return ECL_MALLOC_ERROR;
		p0 = p;
		memzcpy(p,pDefname,pos);
		p += pos;
		*p++ = ':';
		strcpy(p,p1);
		pInfoParm->pi_pos = (long)p0;
/*
printf("cl_set_struct_name:Exit: name=[%s]\n",p0);
*/
		pos = 0;
	}
	return pos;
}

/************************************/
/*	_get_word_mult					*/
/************************************/
static int _get_word_mult(line,line_len,ssp,patr)
char *line;
int line_len,*patr;
SSPL_S *ssp;
{
	int len,atr,pos;
	char c,c1;

	if ((len=akxtgwnsl(line,line_len,ssp,gsep,0x41)) > 0) {
		atr = ssp->attr[0];
		c = *ssp->wd;
		if (atr > 10) {
			pos = instrchar("()[]([{}*/%+-<>&^|",c);
			if (pos > 0) {
				if (pos >= 9) {
					if ((c1=*(line+ssp->sp)) == '=') {
						atr = 90;
						len++;
						ssp->sp++;
					}
					else if (pos <= 13) {
						if (pos>=12 || pos<=15) {
							if (c1 == c) {
								atr = pos - 12 + 14;
								len++;
/*
printf("_get_word_mult: pos=%d atr=%d\n",pos,atr);
*/
								ssp->sp++;
								if (c=='>' && *(line+ssp->sp)=='>') {
									atr = 48;
									len++;
									ssp->sp++;
								}
								if ((c1=*(line+ssp->sp)) == '=') {
									atr = 90;
									len++;
									ssp->sp++;
								}
							}
							else atr = pos - 9 + 21;
						}
						else atr = pos - 9 + 21;
					}
					else atr = pos -13 + 41;
				}
				else atr = pos;
			}
			else if (c == '=') atr = 90;
			else if (c == ',') atr = 98;
			else if (c == ';') atr = 99;
			else atr = 11;
		}
		else if (atr == 1) {
			if (c>='0' && c<='9') atr = 5000;
			else atr = 10000;
		}
		else atr = 5000;
	}
	else atr = 0;
	*patr = atr;
	return len;
}

/* 2023.3.2 */
/************************************/
/*	_pr3_pr2_pr4					*/
/************************************/
static int _pr3_pr2_pr4(line,line_len,ssp,varnam,proc,opt,iParm,iParm2)
char *line,*varnam;
int line_len,opt,iParm[],iParm2[];
SSPL_S *ssp;
ProcCT *proc;
{
	static char *_fn_="_pr3_pr2_pr4";
	int *obj,iob,ida,type,is,pos_var_end,npr,ipr_pos,nvar,iob_ary,ida_nam,pos,n,i,rc;
	int iARRAY0,iARRAY,iCLEAR,iCONST;
	char **da,c;
	parmList *qprmp[MAX_ARRAY_DIM+1];

	iob  = iParm2[0];
	ida  = iParm2[1];
	is   = iParm2[2];
	type        = iParm[0];
	pos_var_end = iParm[7];
	npr         = iParm[8];
	ipr_pos     = iParm[9];
	iARRAY      = iParm[11];
		/* 2023.12.03 */
		cl_im_expand(CLobjExp.ms_obj,iob+13,&obj);
		cl_im_expand(CLobjExp.ms_da,ida+2,&da);
		/* �ϐ����̎擾 */
		npr++;
		obj[ipr_pos] = iob;
		obj[iob++] = 3;	/* �����h�c���ϐ����擾�̏��� */
		ipr_pos = iob++;
		c = *varnam;
		obj[iob++] = ida;
		ida_nam = ida;
		da[ida++] = NULL;	/*clstrdup(varnam,0);*/
		/* �z�񖼂ɕϐ����w��\�Ƃ��� */
		obj[iob] = ida;	/*-1; 2020.10.28 */
		da[ida] = NULL;
		da[ida_nam] = clstrdup(varnam,0);
/*
printf("%s 2: type=%d ida_nam=%d varnam=[%s] ssp.sp=%d\n",_fn_,type,ida_nam,varnam,ssp->sp);
*/
		ida++;
		iob++;

		pos = ssp->sp;
		npr++;
		obj[ipr_pos] = iob;
		obj[iob++] = 2;	/* �����h�c���z���`�擾�̏��� */
		ipr_pos = iob++;

		ssp->sp = is;
		/* 2025.9.7 */
/*
printf("%s 2: iARRAY=%d is=%d\n",_fn_,iARRAY,is);
*/
		iob_ary = iob;
		obj[iob++] = iARRAY;	/* �z���`������ */
		n = 0;
		if (iARRAY >= 0) {
			/* �z���`�̎擾 */
			n = cl_get_array_def_parm(line,pos_var_end,",=",ssp,gsep,MAX_ARRAY_DIM,qprmp,NULL);
/*
printf("%s: n=%d\n",_fn_,n);
*/
			if (n < 0) return n;
			else if (n) {
				/* 2023.2.25 */
				if (opt & D_GX_OPT_SCALAR) {
							/* %s��`(%s)�͎w��ł��܂���B*/ /* �z�� */
					ERROROUT2(FORMAT(156),FORMAT(150),varnam);
					return ECL_EX_DEFINE;
				}
				iARRAY = 1;	/* �z���`���� */
			}
			else {
				if (iARRAY) {
					if (proc) iARRAY = 2;	/* define�ł͂Ȃ��āAarray������ */
				}
				else iARRAY = -1;	/* array���z���`���Ȃ�==>�ϐ��̒�`�܂��͎� */
			}
/*
printf("%s: n=%d iARRAY=%d\n",_fn_,n,iARRAY);
*/
			iCONST = opt & D_GX_OPT_SET_CONST;
			iCLEAR = opt & D_GX_OPT_SET_CLEAR;
			if (iARRAY==2 && (iCLEAR || iCONST || type)) iARRAY = 1;
			/* define�ł͂Ȃ��āAarray������Aclear��const���������w�肳��Ă��� */
			/* ARRAY=1: �z��ϐ��̒�` */
			/* ARRAY=2: �z��ϐ��ւ̃f�[�^�ݒ� */
/*
printf("%s: iARRAY=%d\n",_fn_,iARRAY);
*/
			/* 2021.8.28 */
			obj[iob++] = ida;	/* �z���` */
			obj[iob++] = n;
			iob_ary = iob;
			obj[iob++] = iARRAY;
			/* 20231203 */
			cl_im_expand(CLobjExp.ms_da,ida+n,&da);
			for (i=0;i<n;i++) {
				cl_im_parmcpy(D_OPT_ALC_LEAF,&da[ida++],qprmp[i]);
			}
			memcpy(qprmp,&da[ida-n],sizeof(parmList *)*n);
			if (!n) ssp->sp = pos;
		}
		else {
			/* �z���`��ǂݔ�΂� */
			rc = cl_get_array_def_parm(line,pos_var_end,",=",ssp,gsep,0,NULL,NULL);
			if (rc < 0) return n;
		}
/*
printf("%s: n=%d iARRAY=%d\n",_fn_,n,iARRAY);
*/
DEBUGOUTL3(170,"%s: n=%d iARRAY=%d",_fn_,n,iARRAY);

		npr++;
		obj[ipr_pos] = iob;
		obj[iob++] = 4;	/* �����h�c���ϐ���`/�Ē�`���� */
		ipr_pos = iob++;

	iParm2[0] = iob;
	iParm2[1] = ida;
	iParm[8]  = npr;
	iParm[9]  = ipr_pos;
	iParm[11] = iARRAY;
	iParm[12] = iob_ary;

	return 0;
}

/************************************/
/*	_pr5_pr6_pr7					*/
/************************************/
int cl_def_pr5_pr6_pr7(iParm,iParm2)
int iParm[],iParm2[];
{
	static char *_fn_="_pr5_pr6_pr7";
	int *obj,iob,ida,npr,ipr_pos,iEQU;
	char **da;

	iob     = iParm2[0];
	ida     = iParm2[1];
	iEQU    = iParm2[3];
	npr     = iParm[8];
	ipr_pos = iParm[9];
		/* 20231203 */
		cl_im_expand(CLobjExp.ms_obj,iob+4,&obj);
		cl_im_expand(CLobjExp.ms_da,ida+1,&da);
		if (iEQU) {
			npr++;
			obj[ipr_pos] = iob;
			obj[iob++] = 5;	/* �����h�c��������� */
			ipr_pos = iob++;
		}
		npr++;
		obj[ipr_pos] = iob;
		obj[iob++] = 6;	/* �����h�c��CONST���� */
		ipr_pos = iob++;

		npr++;
		obj[ipr_pos] = iob;
		obj[iob++] = 7;	/* �����h�c��pInfoParm��Ԃ����� */
		ipr_pos = iob++;
/*
printf("%s: iob=%d ida=%d da=%08x npr=%d\n",argv[0],iob,ida,da,npr);
*/
		obj[iob++] = ida++;

	iParm2[0] = iob;
	iParm2[1] = ida;
	iParm[8]  = npr;
	iParm[9]  = ipr_pos;

	return 0;
}

/************************************/
/*	_def_var_mult1					*/
/************************************/
static int _def_var_mult1(line,line_len,ssp,pvarnam,wrk,wrk_len,iParm,iParm2)
char *line,**pvarnam,*wrk;
int line_len,wrk_len,iParm[],iParm2[];
SSPL_S *ssp;
{
	static char *_fn_ = "_def_var_mult1";
	int rc,vnlen,is,pos_var_end,sp_save,type,len;
	int iCOM,iSKIP,iEQU;
	char c,*varnam;

	varnam = *pvarnam;
	is   = iParm2[2];
	iCOM = iParm2[5];
	pos_var_end = iParm[7];
	rc = 1;
	iEQU = 0;
	for (;;) {
		if ((vnlen=akxtgwnsl(line,pos_var_end,ssp,gsep,0x41)) <= 0) break;
		is = ssp->sp - vnlen;
		memnzcpy(wrk,ssp->wd,vnlen,wrk_len);
		varnam = wrk;
/*
printf("%s 0: is=%d ssp.sp=%d vnlen=%d varnam=[%s]\n",_fn_,is,ssp->sp,vnlen,varnam);
*/
DEBUGOUTL5(170,"%s 0: is=%d ssp.sp=%d vnlen=%d varnam=[%s]",_fn_,is,ssp->sp,vnlen,varnam);
DEBUGOUTL3(170,"%s 0: ssp.attr[0]=%d iCOM=%d",_fn_,ssp->attr[0],iCOM);

		iSKIP = 0;
		c = *varnam;
		if (instrchar("+-*/&|",c) > 0) {
			if (*(line+ssp->sp) == '=') break;
			iSKIP = 2;
		}
		else if (!stricmp(varnam,"AS") || c=='=') break;
		else if (c == ',') {
			if (iCOM) {
				ERROROUT2(FORMAT(458),_fn_,FORMAT(441));	/* %s: %s�͏ȗ��ł��܂���B *//* 441 �ϐ��� */
				return ECL_EX_DEFINE;
			}
			iCOM = 1;
			continue;
		}
#if 0	/* ���ꂪ�Ȃ��Ă� cl_get_array_def_parm()�̒��ŃG���[�Ȃ邪�A�O�̂��ߎc�� */
		/* 2021.5.24 ���ꂪ����ƁA�J���}�̌�̔z�񖼂��u�`������܂���v�̃G���[�ɂȂ�̂ŁA
		   �܂��A�����ł́Acl_chk_name()���ł��Ȃ�(�z�񖼂��ϐ��̂Ƃ�������)�̂ŁA�폜����B*/
		else if (!iCOM) {
			p = varnam;
			if (c=='$' || c=='%' || c=='#') {
				p++;
				vnlen--;
			}
			if (cl_chk_name(p, vnlen))
				ERROROUT2(FORMAT(125),_fn_,varnam);	/* %s: [%s]������Ă��܂��B*/
			else
				ERROROUT3(FORMAT(540),_fn_,FORMAT(474),varnam);	/* %s: %s������܂���B(at %s) �J���} */
			return ECL_EX_DEFINE;
		}
#endif
/*
printf("%s 1: pos=%d vnlen=%d varnam=[%s]\n",_fn_,pos,vnlen,varnam);
*/
DEBUGOUTL3(170,"%s 1: vnlen=%d varnam=[%s]",_fn_,vnlen,varnam);
		iCOM = 0;
		if (c == '(') iSKIP = 1;
		else if (!instrchar("()[] \t,",*(line+ssp->sp))) iSKIP = 2;
		else {
			clpeeksl(line,pos_var_end,ssp,gsep,0x41);
			if (*ssp->wd == '(') {
				len = akxnskipin(varnam,vnlen,"$%#");
				if (len >= vnlen) iSKIP = 1;
			}
		}
/*
printf("%s 2: iSKIP=%d\n",_fn_,iSKIP);
*/
		if (iSKIP) {
			if (iSKIP == 1) {
				ssp->sp = is;
				if (len=cl_skip_to_delm(line,pos_var_end,"()",ssp,gsep,0)) {
					ERROROUT1(FORMAT(433),_fn_);	/* %s: �J�b�R�����Ă��܂���B */
					return ECL_SCRIPT_ERROR;
				}
			}
			else { /*if (iSKIP == 2) {*/
				len = akxnskipto(line+ssp->sp,pos_var_end-ssp->sp," \t");
				ssp->sp += len;
			}
			memnzcpy(wrk,line+is,ssp->sp-is,wrk_len);
			varnam = wrk;
			vnlen = strlen(varnam);
/*
printf("%s SKIP: vnlen=%d varnam=[%s] ssp.sp=%d\n",_fn_,vnlen,varnam,ssp->sp);
*/
		}
		is = ssp->sp;
/*
printf("%s 3: is=%d\n",_fn_,is);
*/
		iParm[10]++;
		rc = 0;
		break;
	}
/*
printf("%s 2: is=%d vnlen=%d varnam=[%s]\n",_fn_,is,vnlen,varnam);
*/
	*pvarnam = varnam;
	iParm2[2] = is;
	iParm2[4] = sp_save;
	iParm2[5] = iCOM;
	iParm[7] = pos_var_end;
	return rc;
}

/************************************/
/*	_def_var_mult2					*/
/************************************/
static int _def_var_mult2(line,line_len,ssp,pvarnam,wrk,wrk_len,iParm,iParm2)
char *line,**pvarnam,*wrk;
int line_len,wrk_len,iParm[],iParm2[];
SSPL_S *ssp;
{
	static char *_fn_ = "_def_var_mult2";
	int vnlen,is,nvar,pos,pos_var_end,i_var,sp_save,type,atr,len,rc;
	int iEQU,iEQU2,iSTA;
	char c,*varnam,*p;

	varnam = *pvarnam;
	is   = iParm2[2];
	iEQU = iParm2[3];
	pos_var_end = iParm[7];
	iEQU2 = iSTA = 0;
	cl_chk_act(-1);
	for (;;) {
		vnlen = _get_word_mult(line,line_len,ssp,&atr);
/*
printf("%s 0: vnlen=%d atr=%d\n",_fn_,vnlen,atr);
*/
	/*	if (vnlen<0 || (!vnlen && !atr)) break;	*//* 2026.1.6 �����Ŕ�����Ƃ��낢��f�[�^���ݒ肳�ꂸ�Ƀ��^�[������ */
		if (atr < 0) return atr;
		if (!iSTA) iSTA = ssp->sp - vnlen;
		c = *ssp->wd;
/*
printf("%s 0: is=%d ssp.sp=%d iCOM=%d vnlen=%d wd=[%s]\n",_fn_,is,ssp->sp,iCOM,vnlen,ssp.wd);
*/
DEBUGOUTL5(170,"%s 0: is=%d ssp.sp=%d vnlen=%d varnam=[%s]",_fn_,is,ssp->sp,vnlen,varnam);
DEBUGOUTL3(170,"%s 0: ssp.attr[0]=%d atr=%d",_fn_,ssp->attr[0],atr);

		if (!varnam && atr==1) {
			/* 2024.12.25 */
			i_var = ssp->sp - 1;
			if (len=cl_skip_to_delm(line,line_len,"()",ssp,gsep,1)) {
				ERROROUT1(FORMAT(433),_fn_);	/* %s: �J�b�R�����Ă��܂���B */
				return ECL_SCRIPT_ERROR;
			}
			/* 2024.12.25 */
			memnzcpy(wrk,line+i_var,ssp->sp-i_var,wrk_len);
			varnam = wrk;
			if (!is) is = ssp->sp;
/*
printf("%s 0: is=%d vnlen=%d varnam=[%s]\n",_fn_,is,vnlen,varnam);
*/
			continue;
		}
		if (atr>=1 && atr<=10) {
/*
printf("%s: c=[%c]\n",_fn_,c);
*/
			if ((rc=cl_chk_act(c)) < 0) {
						/* %s: %s�̑Ή������Ă��܂��� \"%s\" rc=%d */
				ERROROUT4(FORMAT(689),_fn_,cl_get_kakko_str(cl_get_kakko_no(c)),line,rc);
				return ECL_SCRIPT_ERROR;
			}
		}
		if (atr && cl_chk_act(0)) continue;	/* 2026.1.6 add atr */
		if (!varnam && atr!=62 && atr!=14 && atr!=15) {
/*
printf("%s 0: atr=%d\n",_fn_,atr);
*/
			if (atr<2000 || atr==5000) {
				memnzcpy(wrk,ssp->wd,vnlen,wrk_len);
				if (atr>=14 && atr<=48)
					ERROROUT2(FORMAT(318),_fn_,wrk);	/* %s: %s�͎g�p�ł��܂���B */
				else ERROROUT2(FORMAT(458),_fn_,FORMAT(441));	/* %s: %s�͏ȗ��ł��܂���B *//* 441 �ϐ��� */
				return ECL_EX_DEFINE;
			}
		}
		if (atr!=62 && atr<100) {
			if (!atr || atr==99 || atr == 98) {
				if (iEQU) pos_var_end = iEQU2;
				else pos_var_end = ssp->sp - 1;
/*
printf("%s 0: pos_var_end=%d\n",_fn_,pos_var_end);
*/
				sp_save = ssp->sp;
			}
			else {
				if (atr>=71 && atr<=90) {
					iEQU = ssp->sp;
					iEQU2 = iEQU - vnlen;
/*
printf("%s 0: iEQU=%d iEQU2=%d\n",_fn_,iEQU,iEQU2);
*/
				}
				continue;
			}
		}
		else {
			if (!varnam) {
				p = ssp->wd;
				memnzcpy(wrk,p,vnlen,wrk_len);
				len = akxnskipin(wrk,vnlen,"$%#");
				if (len >= vnlen) {
					atr = cmppeekwnsl(line,line_len,ssp,0);
					if (atr == 1) {
						i_var = ssp->sp - 1;
						if (len=cl_skip_to_delm(line,line_len,"()",ssp,gsep,0)) {
							ERROROUT1(FORMAT(433),_fn_);	/* %s: �J�b�R�����Ă��܂���B */
							return ECL_SCRIPT_ERROR;
						}
						p = line+i_var;
						vnlen = ssp->sp-i_var;
					}
				}
				/* 2023.3.26 */
				vnlen = ssp->sp - iSTA;
				memnzcpy(wrk,line+iSTA,vnlen,wrk_len);
				varnam = wrk;
				if (atr==2000 || (atr>=4000 && atr<10000)) {
					ERROROUT2(FORMAT(436),_fn_,varnam);	/* %s: �ϐ���[%s]������Ă��܂��B*/
					return ECL_EX_DEFINE;
				}
				if (!is) is = ssp->sp;
/*
printf("%s 1: is=%d vnlen=%d varnam=[%s]\n",_fn_,is,vnlen,varnam);
*/
			}
			continue;
		}
/*
printf("%s 1: is=%d ssp.sp=%d vnlen=%d varnam=[%s]\n",_fn_,is,ssp.sp,vnlen,varnam);
*/
/*
printf("%s 1: pos=%d vnlen=%d varnam=[%s]\n",_fn_,pos,vnlen,varnam);
*/
DEBUGOUTL3(170,"%s 1: vnlen=%d varnam=[%s]",_fn_,vnlen,varnam);

		break;
	}
	if (rc=cl_kakko_peek()) {
		ERROROUT2(FORMAT(26),_fn_,cl_get_kakko_str(rc));	/* %s: %s�����Ă��܂���B */
		atr = ECL_SCRIPT_ERROR;
	}
	*pvarnam = varnam;
	iParm2[2] = is;
	iParm2[3] = iEQU;
	iParm2[4] = sp_save;	/* , or ; �̈ʒu */
	iParm[7] = pos_var_end;
	if (varnam) iParm[10]++;
	return atr;
}

/************************************/
/*	cl_def_var_mult					*/
/************************************/
int cl_def_var_mult(cmdobj,prmnum,pprmp,scrct,proc,opt,iParm)
CMDObject *cmdobj;
int      prmnum;
parmList **pprmp;
ScrPrCT  *scrct;
ProcCT   *proc;
int      opt,iParm[];
{
	static char *_fn_ = "cl_def_var_mult";
	int rc,vnlen,is,nvar,pos,pos_var_end,i_var,line_len,sp_save,type,atr,len,len_vals;
	int *obj,npr,iob,ida,ipr_pos,iob_ary,iParm2[10];
	int iARRAY,iEQU,iCONST,iARRAY0,iMAPPED,iSCALAR,iEQU2,iEQU0;
	int iCOM,iSKIP,iSTA,iMALTI2,iDEFPROC,iEX_DEF_SCALAR;
	char c,*varnam,*p,*argv[6],*line,wrk[256],**da;
	tdtInfoParm *pInfoDef;
	tdtDefType *pDeftypeP;
	SSPL_S ssp;
/*
printf("%s: Enter opt=%08x iParm=%d %d %08x %08x %08x %08x\n",
_fn_,opt,iParm[0],iParm[1],iParm[2],iParm[3],iParm[4],iParm[5]);
*/
	type = iParm[0];
	pDeftypeP = NULL;
#if defined(_LP64)	/* 2021.2.13 */
	memcpy(&p,iParm+2,sizeof(char *));
	if (!type && p) {
		if (pInfoDef = (tdtInfoParm *)p) {
#else
	if (!type && iParm[2]) {
		if (pInfoDef = (tdtInfoParm *)iParm[2]) {
#endif
			pDeftypeP = (tdtDefType *)pInfoDef->pi_data;
			type = pInfoDef->pi_aux[0];
		}
	}

	line = pprmp[0]->prp;
	line_len = pprmp[0]->prmlen;
	memset(&ssp,0,sizeof(SSPL_S));

	iob = cmdobj->nobj;
	ida = cmdobj->nda;
	obj = cmdobj->exobj;
	da  = cmdobj->da;
	pos         = iParm[6];
	pos_var_end = iParm[7];
	npr         = iParm[8];
	ipr_pos     = iParm[9];
/*
printf("%s: pos=%d pos_var_end=%d npr=%d ipr_pos=%d iob=%d ida=%d\n",
_fn_,pos,pos_var_end,npr,ipr_pos,iob,ida);
*/
	ssp.sp = pos;
	obj[iob++] = pos;
	iMAPPED = iARRAY = iCONST = iSCALAR = iEQU = iEQU2 = iEX_DEF_SCALAR = 0;
	iSKIP = 0;
	if (opt & D_GX_OPT_SET_ARRAY) iARRAY = 1;
	if (opt & D_GX_OPT_SET_MAPPED) {
		iARRAY = iMAPPED = 1;
	}
	if (opt & D_GX_OPT_SET_CONST) iCONST = D_AUX1_PROTECTED;
	/* 2023.2.25 */
	if (opt & D_GX_OPT_SCALAR) iSCALAR = 1;
/*
printf("%s: iARRAY=%d iMAPPED=%d iCONST=%d iSCALAR=%d\n",_fn_,iARRAY,iMAPPED,iCONST,iSCALAR);
*/
	iARRAY0 = iARRAY;
	cl_chk_act(-1);
	is = 0;
	nvar = 0;
	iCOM = 1;
	varnam = NULL;
	iParm[10] = nvar;
	iParm[16] = 0;
	sp_save = line_len;
/*
printf("cl_def_var_mult: cmdobj->cid=%08x\n",cmdobj->cid);
*/
	iMALTI2 = cmdobj->cid & C_USE_MALTI2;
	iMALTI2 = iMALTI2 && !(cl_get_option(24,0) & 0x10);
	iDEFPROC = cmdobj->cid & C_DEFINE_PROC;	/* scalar�ł͏������Ȃ� */
/*
printf("%s: iMALTI2=%08x iDEFPROC=%08x iParm[17]=%08x\n",_fn_,iMALTI2,iDEFPROC,iParm[17]);
*/
	if (!iMALTI2) iEQU = iParm[18];
	iEQU0 = iEQU;

	for (;;) {
		len_vals = 0;
		if (iMALTI2) {
			iParm2[2] = is;
			iParm2[3] = iEQU;
			iParm[7] = pos_var_end;
			iSTA = ssp.sp;
			if ((atr=_def_var_mult2(line,line_len,&ssp,&varnam,wrk,sizeof(wrk),iParm,iParm2)) < 0) return atr;
			is      = iParm2[2];
			iEQU    = iParm2[3];
			sp_save = iParm2[4];
			pos_var_end = iParm[7];
			if (iEQU) len_vals = ssp.sp - iEQU - 1;	/* �����l���̒��� */
		}
		else {
			iParm2[2] = is;
			iParm2[5] = iCOM;
			iParm[7] = pos_var_end;
			if ((rc=_def_var_mult1(line,line_len,&ssp,&varnam,wrk,sizeof(wrk),iParm,iParm2)) < 0) return rc;
			is      = iParm2[2];
			sp_save = iParm2[4];
			iCOM    = iParm2[5];
			pos_var_end = iParm[7];
/*
printf("%s: rc=%d is=%d ssp.sp=%d varnam=[%s]\n",_fn_,rc,is,ssp.sp,varnam);
*/
			if (rc == 1) break;
			if (iEQU) len_vals = line_len - iEQU;	/* �����l���̒��� */
		}
		/* �����l���̐ݒ� */
		if (iEQU) {
			/* 20231203 */
			cl_im_expand(CLobjExp.ms_obj,iob+3,&obj);
			npr++;
			obj[ipr_pos] = iob;
			obj[iob++] = 8;	/* �����h�c�������l���̏��� */
			ipr_pos = iob++;
			obj[iob++] = iEQU;
			obj[iob++] = len_vals;
			iParm[16] = 1;
		}
		/* 2023.3.2 */
		iParm2[0] = iob;
		iParm2[1] = ida;
		iParm2[2] = is;
		iParm[7] = pos_var_end;
		iParm[8] = npr;
		iParm[9] = ipr_pos;
		iParm[11] = iARRAY0;
		if ((rc=_pr3_pr2_pr4(line,line_len,&ssp,varnam,proc,opt,iParm,iParm2)) < 0) return rc;
		iob = iParm2[0];
		ida = iParm2[1];
		npr = iParm[8];
		ipr_pos = iParm[9];
/*
printf("%s: npr=%d\n",_fn_,npr);
*/
		iParm[13] = iParm[8];	/*npr;*/
		iParm[14] = iParm2[0];	/*iob;*/
		iParm[15] = iParm[9];	/*ipr_pos;*/
		if (iMALTI2) {
			/* 2023.3.2 */
			iParm2[3] = iEQU;
			cl_def_pr5_pr6_pr7(iParm,iParm2);
			iob = iParm2[0];
			ida = iParm2[1];
			npr = iParm[8];
			ipr_pos = iParm[9];
/*
printf("%s: sp=%d\n",_fn_,ssp.sp);
*/
#if 1	/* 2026.5.21 */
			if (atr==98 && (opt & D_GX_OPT_SET_FOR)) {
				iParm[4] = sp_save;
				break;
			}
			else if (!atr || atr==99) {
				iParm[4] = sp_save;
				break;
			}
#else
			if (!atr || atr==99) break;
#endif
			iEQU = is = 0;
			varnam = NULL;
			ssp.sp = sp_save;
		}
		else {
			iob = iParm2[0];
			ida = iParm2[1];
			npr = iParm[8];
			ipr_pos = iParm[9];
			iEQU = 0;
		}
	}
	nvar = iParm[10];
/*
printf("%s: nvar=%d iARRAY=%d\n",_fn_,nvar,iParm[11]);
*/
	if (!nvar) {
		ERROROUT2(FORMAT(111),_fn_,FORMAT(329));	/* %s: %s�����K�v�ł��B*/ /* �ϐ� */
		return ECL_EX_DEFINE;
	}
	/* 2023.3.29 */
	if (!iMALTI2 && !iEX_DEF_SCALAR) {
		iParm2[3] = iEQU0;
		cl_def_pr5_pr6_pr7(iParm,iParm2);
		iob = iParm2[0];
		ida = iParm2[1];
		npr = iParm[8];
		ipr_pos = iParm[9];
	}
	/* 20231203 */
	cl_im_expand(CLobjExp.ms_obj,0,&obj);
	cl_im_expand(CLobjExp.ms_da,0,&da);
/*
printf("%s: npr=%d ipr_pos=%d iob=%d ida=%d obj=%08x da=%08x\n",_fn_,npr,ipr_pos,iob,ida,obj,da);
*/

	cmdobj->nobj  = iob;
	cmdobj->nda   = ida;
	cmdobj->exobj = obj;
	cmdobj->da    = da;
	iParm[8] = npr;
	iParm[9] = ipr_pos;
	return 0;
}

/************************************/
/*	cl_get_def_type_opt				*/
/*  sp_save : �f�[�^�^���J�n�ʒu	*/
/*  �G���[�܂��̓f�[�^�^�łȂ��Ƃ��́Assp.sp=sp_save */
/************************************/
int cl_get_def_type_opt(line,line_len,ssp,sp_save,proc,pbxobj,iERROROUT,iParm,pInfoParm,ex_opt)
char *line;
int line_len,sp_save,iERROROUT,iParm[],ex_opt;
SSPL_S *ssp;
ProcCT   *proc;
GXObject **pbxobj;
tdtInfoParm *pInfoParm;
{
	static char *_fn_="cl_get_def_type";
	int type,len,vnlen,rc,opt,opt_ndef;
	char c,*varnam,*pp,cc;
	parmList qprmp;
	tdtInfoParm tInfoParmW,*pInfoParmW;

DEBUGOUTL4(170,"cl_get_def_type:Enter: sp_save=%d iERROROUT=%d line_len=%d line=[%s]",sp_save,iERROROUT,line_len,line);
/*
printf("cl_get_def_type:Enter: sp_save=%d line_len=%d line=[%s]\n",sp_save,line_len,line+sp_save);
*/
	rc = type = 0;
	ssp->sp = sp_save;
	if ((vnlen=akxtgwnsl(line,line_len,ssp,gsep,0x841)) <= 0) {
		if (iERROROUT) {
			ERROROUT1(FORMAT(457),_fn_);	/* %s: �^�w�肪����܂���B */
			rc = ECL_EX_DEFINE;
		}
		goto NotType;
	}
	/* 2022.12.07 */
	if (ssp->attr[0] > 100) goto NotType;
	varnam = clmemdup(ssp->wd,vnlen,3);
	/* �^��`���ɕϐ����w��\�Ƃ��� */
	c = *varnam;
	if (c=='(' || c=='$') {
		ssp->sp = sp_save;
		if ((len=_get_varname(line,line_len,ssp,proc,pbxobj,&pp)) < 0) {
			rc = len;
			goto NotType;
		}
		else if (len > 0) {
			varnam = pp;
			vnlen = len;
		}
	}
	if (iERROROUT) {
		if (rc=cl_def_chk_name(varnam,vnlen,_fn_,FORMAT(466))) goto NotType;	/* �^��`�� */
	}
	qprmp.prp = varnam;
	qprmp.prmlen = vnlen;

	opt = ex_opt & D_GX_OPT_SET_SCOPE;
	opt_ndef = D_GX_OPT_NOERROR_NDEF | D_GX_OPT_NOEROUT_NDEF | D_GX_OPT_NOHOLD_NDEF;
	if (iERROROUT) opt &= ~opt_ndef;
	else opt |= opt_ndef;

	/* 2021.2.6 */
	/* 2025.10.25 */
	if (inmemchar(varnam,vnlen,'.') > 0) {
		if ((rc=cl_gx_expsn_obj_opt(varnam,vnlen,NULL,NULL,pInfoParm,D_GX_OPT_GET_ADDR)) < 0) return rc;
/*
printf("%s: pi_id=[%c] pi_pos=%08x\n",_fn_,pInfoParm->pi_id,pInfoParm->pi_pos);
*/
DEBUGOUT_InfoParm(194,"%s:cl_gx_expsn_obj_opt ",pInfoParm,_fn_,0);
	}
	else rc = cl_conv_parm_opt(&qprmp,pInfoParm,opt|D_GX_OPT_SET_ADDR);
	if (pInfoParm->pi_id == 'S') pInfoParmW = (tdtInfoParm *)pInfoParm->pi_pos;
	else pInfoParmW = pInfoParm;
	if (!rc || rc==ECL_DEFINED_ARRAY) {
		if (pInfoParmW->pi_id == 'P') {
			type = pInfoParmW->pi_aux[0];
			if (pInfoParm->pi_id != 'S') {	/* ���̃P�[�X�́A�L���Ȃ����O�̂��� */
				if (!(pInfoParmW = (tdtInfoParm *)cl_opt_malloc(0,sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
				cl_gx_rep_info_set_ign(pInfoParmW,pInfoParm,1);
			}
			pp = Memdup(line+sp_save,ssp->sp-sp_save);
/*
printf("%s: sp_save=%d ssp.sp=%d pp=[%s]\n",_fn_,sp_save,ssp->sp,pp);
*/
#if defined(_LP64)	/* 2021.2.13 */
			memcpy(iParm+2,&pInfoParmW,sizeof(char *));
			memcpy(iParm+4,&pp,sizeof(char *));
#else
			iParm[2] = (int)pInfoParmW;
			iParm[4] = (int)pp;
#endif
			iParm[1] = sizeof(char *);	/* 2025.11.12 */
		}
		else {
			if (iERROROUT) {
				/* %s: �^�w�肪����Ă��܂��Btype=[%s] */
				ERROROUT2(FORMAT(468),_fn_,varnam);
				rc = ECL_EX_DEFINE;
			}
			goto NotType;
		}
	}
	else {
		if (iERROROUT) {
			if ((rc==ECL_NDEFVAR_ERROR || rc==ECL_NO_DATA_ERROR) && (opt & D_GX_OPT_NOERROR_NDEF)) rc = 0;
		}
		else rc = 0;
		goto NotType;
	}
/*
printf("%s: type=%d\n",_fn_,type);
*/
	return type;
NotType:
	ssp->sp = sp_save;
	return rc;
}

/************************************/
/*	cl_get_def_type					*/
/************************************/
int cl_get_def_type(line,line_len,ssp,sp_save,proc,pbxobj,iERROROUT,iParm,pInfoParm)
char *line;
int line_len,sp_save,iERROROUT,iParm[];
SSPL_S *ssp;
ProcCT   *proc;
GXObject **pbxobj;
tdtInfoParm *pInfoParm;
{
	return cl_get_def_type_opt(line,line_len,ssp,sp_save,proc,pbxobj,iERROROUT,iParm,pInfoParm,0);
}

/************************************/
/*	cl_pr_ex_def_var				*/
/************************************/
int cl_pr_ex_def_var(cmdobj, prmnum, pprmp, scrct, proc, opt)
CMDObject *cmdobj;
int      prmnum;
parmList **pprmp;
ScrPrCT  *scrct;
ProcCT   *proc;
int      opt;
{
	XHASHB *pha_vname;
	tdtInfoParm ***pTBL_vname;
	int i,j,k,iParmNo,rc,vnlen,is,ias,ntype,datalen,iCONST,nvar,posa[4],kind;
	int iParm[20],check[4],*obj,npr,iob,exec_flg,ipr,ida,ipr_pos,ida_nam,iob_ary,iParm2[5];
	int iEQU,line_len,sp_save,pos,iCOM,type,vlen,iARRAY,n,pos_var_end,opt1;
	char c,*varnam,*p,id,*argv[6],*line,wrk[128],*pp,*vnam,**da;
	tdtInfoParm *pInfoParm,tInfoParm,*pParm,*pParmIO[2];
	tdtDefType *pDeftype,*pDeftypeP;
	parmList  **parmName;
	tdtArrayIndex *pIndex;
	int *index,attr,size,len;
	SSPL_S ssp;
	parmList qprmp,*pPrmp;
	parmList *qprmp3[4];
	tdtObjHead *pObj;
	GXObject *bxobj[2];
	uchar ucLOCAL;

	argv[0] = "cl_pr_ex_def_var";

DEBUGOUTL5(101,"%s:Enter prmnum=%d scrct=%08x proc=%08x opt=%08x",argv[0],prmnum,scrct,proc,opt);

	/* parameter check */
	/* DEFINE VAR [GLOBAL|PUBLIC|PRIVATE|LOCAL] var_name AS type; */
	if (prmnum < 1) {
		/* %s: �p�����[�^������܂���Bprmnum=%d */
		ERROROUT2(FORMAT(467),argv[0],prmnum);
		return ECL_EX_DEFINE;
	}

	bxobj[0] = bxobj[1] = NULL;
	pha_vname = NULL;
	iCONST = iEQU = 0;
	line = pprmp[0]->prp;
	line_len = pprmp[0]->prmlen;
/*
printf("%s: prmnum=%d line_len=%d line=[%s]\n",argv[0],prmnum,line_len,line);
*/
DEBUGOUTL3(120,"%s: line_len=%d line=[%s]",argv[0],line_len,line);

	if (proc) pObj = proc->Obj;
	else pObj = scrct->Obj;
/*
printf("%s: proc=%08x scrct=%08x pObj=%08x\n",argv[0],proc,scrct,pObj);
*/
	memset(&ssp,0,sizeof(SSPL_S));

	if (cmdobj->nobj) goto Exobj;	/* 2020.12.4 �b��Ή� */

	/* 20231203 */
	if (!(obj=cmdobj->exobj)) cl_im_expand(CLobjExp.ms_obj,50,&obj);
	if (!(da=cmdobj->da)) cl_im_expand(CLobjExp.ms_da,10,&da);
	npr = ida = 0;
	obj[0] = 0;	/* sub_id */
	obj[1] = 0;	/* npr */
	obj[2] = 3;	/* ipr_pos */
	iob = obj[2];

	/* �A�N�Z�X�����̎擾 */
	exec_flg = 1;
	npr++;
	obj[iob++] = 1;	/* �����h�c�������̎擾 */
	ipr_pos = iob++;
	obj[iob++] = ida;	/* �����w�莮���� */
	da[ida] = NULL;
	check[1] = 0x03;	/* only const,scope */
	if ((rc=cl_get_def_modifier_SSP(line,line_len,&ssp,gsep,check,iParm,NULL,NULL)) < 0) return rc;
	else if (rc > 0) {
		if (check[2] & 0x01) opt &= ~D_GX_OPT_SET_SCOPE;
		opt |= check[3];
		if (!proc && (opt & D_GX_OPT_SET_LOCAL)) {
			ERROROUT1(FORMAT(443),argv[0]);	/* %s: LOCAL�͎w��ł��܂���B */
			return ECL_SCRIPT_ERROR;
		}
		if (opt & D_GX_OPT_SET_CONST) iCONST = D_AUX1_PROTECTED;
		if (iParm[0] > 0) {
			/* %s: \"%s\"�̈ʒu���s���ł��B */
			ERROROUT2(FORMAT(469),argv[0],cl_get_attr_name(iParm));
			return ECL_SCRIPT_ERROR;
		}
	}
/*
printf("%s: ssp.sp=%d\n",argv[0],ssp.sp);
*/
	/* ������̃T�[�` */
	pos = ssp.sp;
	if ((len=_define_srch_equ(line,line_len,&ssp,posa)) < 0) return len;
	iEQU = posa[0];
	pos_var_end = posa[1];
	kind = posa[2];
	if (len < 0) {
		if (kind &  8)
			ERROROUT3(FORMAT(657),argv[0],"=",iEQU+4);/* %s: \"%s\"�̈ʒu(pos=%d)���s���ł��B*/
		else if (kind & 16)
			ERROROUT2(FORMAT(567),argv[0],"AS");	/* %s: �]���ȕ���(%s)������܂��B*/
		else
			ERROROUT1(FORMAT(171),argv[0]);			/* %s: SYNTAX�G���[�B */
		return ECL_EX_DEFINE;
	}
	iARRAY = 0;
	if (kind & 4) {	/* AS */
		/* �f�[�^�^�܂��͌^��`���̎擾 */
		sp_save = ssp.sp;
		if (rc=cl_get_def_attr_SSP(line,line_len,&ssp,gsep,iParm,&da[ida],pObj)) return rc;
		type = 0;
		cl_parm_set0(&tInfoParm);
		if (!iParm[0]) {
			if ((type=cl_get_def_type(line,line_len,&ssp,sp_save,proc,&pprmp[0]->bxobj,1,iParm,&tInfoParm)) < 0) return type;
			else if (!type) {
				ERROROUT2(FORMAT(125),argv[0],FORMAT(588));	/* %s: [%s]������Ă��܂��B*//* �f�[�^�^�w�� */
				return ECL_EX_DEFINE;
			}
		}
	}
	else {
		iParm[0] = 0;	/*DEF_ZOK_VARI; 2023.9.6 for implicit */
		type = 0;
		if (!len) ssp.sp--;
	}
	if (!(opt & D_GX_OPT_SET_SCOPE)) {
		if (proc) {
			if (!(pGlobTable->options[9] & 0x01) && (scrct->sc_pFlag & D_SCRPT_NEW_LEX))
				opt |= D_GX_OPT_SET_LOCAL;
			else opt |= D_GX_OPT_SET_PRIVATE;
		}
		else opt |= D_GX_OPT_SET_PRIVATE;
	}

	ida++;
	memcpy(&obj[iob],iParm,sizeof(int)*6);
	iob += 6;
	obj[iob++] = opt;
	obj[iob++] = iEQU;	/* add 2020.11.3 */
	obj[iob++] = iCONST;

	if ((len=akxtgwnsl(line,line_len,&ssp,gsep,0x41)) < 0) return len;
	else if (*ssp.wd == '=') iEQU = ssp.sp;

	/* �ϐ��̒�` */
	iParm[6] = pos;
	iParm[7] = pos_var_end;
	iParm[8] = npr;
	iParm[9] = ipr_pos;
	iParm[17] = iParm[0] | type;
/*
printf("%s: iEQU=%d\n",argv[0],iEQU);
*/
	iParm[18] = iEQU;
	cmdobj->nobj  = iob;
	cmdobj->nda   = ida;
	cmdobj->exobj = obj;
	cmdobj->da    = da;
	rc = cl_def_var_mult(cmdobj,prmnum,pprmp,scrct,proc,opt,iParm);
	if (rc < 0) return rc;
	npr     = iParm[8];
	ipr_pos = iParm[9];
	iob = cmdobj->nobj;
	ida = cmdobj->nda;
	obj = cmdobj->exobj;
	da  = cmdobj->da;
	obj[1] = npr;

if (DEBUGOUTCHECK(250)) {
for (i=0;i<iob;i++)
DEBUGOUTL2(250,"ARRY: obj[%d]=%d",i,obj[i]);
for (i=0;i<ida;i++)
DEBUGOUTL3(250,"ARRY: da[%d]=0x%08x[%s]",i,da[i],da[i]);
}
	cmdobj->nobj  = iob;
	cmdobj->nda   = ida;
	cmdobj->exobj = (int *)clmemdup(obj,iob*sizeof(int),0);
	cmdobj->da    = (char **)clmemdup(da,ida*sizeof(char *),0);

	if (iEQU && (kind & 2)) {
		memzcpy(wrk,line+posa[3],iEQU-posa[3]);
				/* %s:(W)���Z�q[%s]�́A�w��ł��܂���B'='�ƌ��Ȃ��܂��B */
		ERROROUT2(FORMAT(608),argv[0],wrk);
	}

Exobj:

	rc = cl_pr_ex_def_array_engine(cmdobj,prmnum,pprmp,scrct,proc,opt);
/*
printf("%s: return cl_pr_ex_def_array_engine() rc=%d\n",argv[0],rc);
*/
	/* 2024.3.3 */
	cl_pr_def_set_scr_extern(scrct,opt);
	if (rc == C_EX_DEF_SCALAR) rc = 0;

DEBUGOUTL2(102,"%s:Exit rc=%d",argv[0],rc);

	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_free_deftype(id,pDeftype)
char id;
tdtDefType *pDeftype;
{
	int i,ntype;
	parmList *pL,**pparmL;
	tdtInfoParm **ppParm,*pInfoParm;

	ntype = pDeftype->ntype;
	if (id == 'P') {
		pparmL = pDeftype->vname;
		for (i=0;i<ntype;i++) {
			pL = *pparmL++;
			Free(pL->prp);
			Free(pL);
		}
		Free(pDeftype->vname);
	}
	ppParm = pDeftype->pType;
	for (i=0;i<ntype;i++) {
		cl_free_info_parm(pInfoParm=*ppParm);
		Free(pInfoParm);
		ppParm++;
	}
	Free(pDeftype->pType);
	return 0;
}
/* 2026.1.3 */
/********************************************/
/*		posa[0] : '=','+='����'='�̈ʒu		*/
/*		posa[1] : �ϐ���������Ō�̈ʒu	*/
/*		posa[2] : �Ō�ɓǂ񂾂���			*/
/*					1 : '='					*/
/*					2 : '+='��				*/
/*					4 : AS					*/
/*					8 : AS �̑O��'=','+='������	*/
/*				   16 : AS ��2����		*/
/*		posa[3] : '+='���̊J�n�ʒu			*/
/*  �ԋp : �Ō�ɓǂ�word��(�o�C�g)		*/
/********************************************/
int _define_srch_equ(line,line_len,ssp,posa)
char *line;
int line_len,posa[];
SSPL_S *ssp;
{
	static char *_fn_="_define_srch_equ";
	/* 2026.1.3 */
	SSPL_S sspl;
	long w[50],j;
	int len,rc,iEQU,pos_var_end,kind,atr0,sp,pos_enzan;
	char c,c2,wrk[128],buf[256];
/*
printf("%s:Enter ssp->sp=%d line_len=%d line=[%s]\n",_fn_,ssp->sp,line_len,line);
*/
	/* 2026.1.3 */
	cl_chk_act(-1);
	rc = iEQU = kind = pos_enzan = 0;
	pos_var_end = line_len;
	posa[0] = iEQU;
	posa[1] = pos_var_end;
	posa[2] = 0;
	while ((len=akxtgwnsl(line,line_len,ssp,gsep,0x41)) > 0) {
/*
printf("%s: sp=%d len=%d wd=[%s]\n",_fn_,ssp->sp,len,strtemp(ssp->wd,len));
*/
		if (len == 1) {
			c = *ssp->wd;
			if (j=instrchar("({[)}]",c)) {
				/* 2026.1.3 */
				if ((rc=cl_chk_act(c)) < 0) {
							/* %s: %s�̑Ή������Ă��܂��� \"%s\" rc=%d */
					ERROROUT4(FORMAT(689),_fn_,cl_get_kakko_str(cl_get_kakko_no(c)),line,rc);
					return rc;
				}
				continue;	/* add 2022.10.1 */
			}
			/* 2026.1.3 */
			else if (!cl_chk_act(0) && c=='=') {
				if (!iEQU) {
					iEQU = ssp->sp;
					pos_enzan = iEQU - 1;
					if (!kind) pos_var_end = iEQU - 1;
					kind |= 1;
				}
				if (kind & 4) break;
			/*	break;	*/
			}
		}
		if (!cl_chk_act(0)) {
			if ((c2=*(line+ssp->sp))=='=') {
				if (!iEQU) {
					sspl.sp = 0;
					sspl.wd = wrk;
					sspl.wdmax = sizeof(wrk);
					memcpy(buf,ssp->wd,len);
					memcpy(buf+len,"=",2);
					atr0 = cmpgwnsl(buf,len+1,&sspl,0);
/*
printf("%s: atr0=%d buf=[%s]\n",_fn_,atr0,buf);
*/
					if (atr0>=71 && atr0<=90) {
						iEQU = ssp->sp + 1;
						pos_enzan = ssp->sp - len;
						if (!kind) pos_var_end = ssp->sp - len;
						kind |= 2;
						if (kind & 4) break;
					/*	break;	*/
					}
				}
			}
			else if (!stricmp(strtemp(ssp->wd,len),"AS")) {
				if (kind & (3+4)) {
					if (kind & 4) kind |= 16;
					else kind |= 8;
					posa[0] = iEQU;
					posa[2] = kind;
					return ECL_SYNTAX_ERROR;
				}
				pos_var_end = ssp->sp - (len+1);
				kind |= 4;
				sp = ssp->sp;
			/*	break;	*/
			}
		}
	}
	if (len == -1) len = 0;
	if (kind & 4) ssp->sp = sp;
	posa[0] = iEQU;
	posa[1] = pos_var_end;
	posa[2] = kind;
	posa[3] = pos_enzan;
/*
printf("%s: iEQU=%d pos_var_end=%d kind=%d ssp->sp=%d\n",_fn_,iEQU,pos_var_end,kind,ssp->sp);
*/
	return len;
}

/************************************/
/*	_chk_implicit_char				*/
/************************************/
static int _chk_implicit_char(scope_str,pImp)
char scope_str;
tdtImplicit *pImp;
{
	int rc;
	char c;

	/* MAX_LOOP_WHILE���O���ϐ����e�����󂯂�̂ŁA�X�R�[�v�ƕ����𐧌����� */
	rc = 0;
	if (scope_str == 'P') {
		if (((c=*pImp->imp_from)>='A' && c<='Z') || ((c=*pImp->imp_to)>='A' && c<='Z')) {
					/* %s: %s��'%s'�͎w��ł��܂���B*/
			ERROROUT3(FORMAT(140),"_chk_implicit_char",cl_get_scope_name_from_opt(D_GX_OPT_SET_PUBLIC),"A�`Z");
			rc = ECL_SCRIPT_ERROR;
		}
	}
	return rc;
}

/************************************/
/*	_sort_func_implicit				*/
/************************************/
static int _sort_func_implicit(a,b)
tdtImplicit *a,*b;
{
	int ret,len1,len2;
	uchar ca1,ca2,cb1,cb2;

	ca2 = *a->imp_to;
	cb2 = *b->imp_to;
	if (ca2 && cb2) {	/* ���� �͈͎w�� */
		ca1 = *a->imp_from;
		cb1 = *b->imp_from;
		ret = (int)ca1 - (int)cb1;
	}
	else if (ca2 && !cb2) {	/* a:�͈�, b:�P�� */
		ret = 1;
	}
	else if (!ca2 && cb2) {	/* a:�P��, b:�͈� */
		ret = -1;
	}
	else {	/* ���� �P��w�� */
		len1 = a->imp_flen;
		len2 = b->imp_flen;
		if (len1 > len2) ret = -1;
		else if (len1 < len2) ret = 1;
		else ret = memcmp(a->imp_from,b->imp_from,len1);
	}
	return ret;
}

/************************************/
/*	cl_pr_ex_def_implicit			*/
/************************************/
/*
	char imp_scope;		 G,P,S,L 
	char imp_from[4];
	char imp_to[4];
	char imp_attr[4];
	char imp_flen;
	char imp_rsv[2];
*/
int cl_pr_ex_def_implicit(prmnum,pprmp,scrct,proc,opt)
int      prmnum;
parmList **pprmp;
ScrPrCT  *scrct;
ProcCT   *proc;
int      opt;
{
	static char *_fn_="cl_pr_ex_def_implicit";
	int line_len,iParm[20],check[4],n,len,disp,ret,rc,posa[2],scope,i,opt1;
	char *line,wrk[256],c,scope_str;
	SSPL_S ssp;
	tdtImplicit tImp;
	MCAT2 *pImplicit;
/*
printf("cl_pr_ex_def_implicit: prmnum=%d pprmp[0]->prp=[%s]\n",prmnum,pprmp[0]->prp);
*/
	line = pprmp[0]->prp;
	line_len = pprmp[0]->prmlen;
	memset(&ssp,0,sizeof(SSPL_S));
	mem_set_int(iParm,0,4);
	check[1] = 1 | D_DEF_MODIFIER_OTHER;	/* scope */
#if 1	/* 2026.7.1 */
	check[1] |= D_DEF_MODIFIER_COMPLEX | D_DEF_MODIFIER_RATIONAL;
#endif
	ret = scope = 0;
	scope_str = '\0';
	if ((n=cl_get_def_modifier_SSP(line,line_len,&ssp,gsep,check,iParm,NULL,NULL)) < 0) return n;
	else if (n > 0) {
/*
printf("cl_pr_ex_def_implicit: opt=%08x attr=%d %d %d %d\n",check[3],iParm[0],iParm[1],iParm[2],iParm[3]);
printf("cl_pr_ex_def_implicit: ssp.sp=%d ssp.wd=[%s]\n",ssp.sp,ssp.wd);
*/
		if (check[2] & D_DEF_MODIFIER_OTHER) {
			ERROROUT2(FORMAT(135),_fn_,ssp.wd);	/* %s: �X�R�[�v��[%s]���s���ł��B*/
			return ECL_SCRIPT_ERROR;
		}
#if 1	/* 2026.7.1 */
		opt1 = check[3] & 0x7fffffff;
/*
printf("cl_pr_ex_def_implicit: opt1=%08x\n",opt1);
*/
		if (opt1 & D_GX_OPT_SET_RATIONAL) {
			if (!iParm[0]) iParm[0] = DEF_ZOK_DECI;
			if ((ret= cl_rational_attr_check(iParm,0)) < 0) return ret;
		}
		scope = opt1 & D_GX_OPT_SET_SCOPE;
		tImp.imp_rsv[0] = opt1>>24;
#else
		scope = check[3];
#endif
	}
	else {
		ERROROUT1(FORMAT(457),_fn_);	/* %s: �^�w�肪����܂���B*/
		return ECL_SCRIPT_ERROR;
	}
	pImplicit = NULL;
	if (proc) {
		if (!scope || (scope & D_GX_OPT_SET_LOCAL)) {
			if (!(pImplicit=proc->pImplicit)) {
				pImplicit = akxs_mseq2_new(sizeof(tdtImplicit),0,11,NULL,NULL);
				proc->pImplicit = pImplicit;
			}
			scope_str = 'L';
			scope = D_GX_OPT_SET_LOCAL;
		}
	}
	if (!scope_str && scrct) {
		if (!scope || (scope & D_GX_OPT_SET_PRIVATE)) {
			if (!(pImplicit=scrct->pImplicit)) {
				pImplicit = akxs_mseq2_new(sizeof(tdtImplicit),0,11,NULL,NULL);
				scrct->pImplicit = pImplicit;
			}
			scope_str = 'S';
			scope = D_GX_OPT_SET_PRIVATE;
		}
		else if (scope & (D_GX_OPT_SET_LOCAL | D_GX_OPT_SET_BLOCK)) {
			ret = -10;
		}
	}
	if (!ret && !scope_str) {
		if (scope & D_GX_OPT_SET_PUBLIC) {
			pImplicit = pGImplicit;
			scope_str = 'P';
		}
		else if (scope & D_GX_OPT_SET_GLOBAL) {
			/* ���Z�b�V�����O�Œ�`���ꂽ�O���ϐ����e�����󂯂�̂ŁA�X�R�[�v�𐧌����� */
			ret = -11;
		}
	}
	if (ret < 0) {
		ERROROUT2(FORMAT(636),_fn_,cl_get_scope_name_from_opt(scope));	/* %s: %s�͎w��ł��܂���B*/
		return ECL_SCRIPT_ERROR;
	}
	if (!pImplicit) return ECL_MALLOC_ERROR;

	if (iParm[0] <= 0) {
		ERROROUT1(FORMAT(457),_fn_);	/* %s: �^�w�肪����܂���B*/
		return ECL_SCRIPT_ERROR;
	}
	tImp.imp_attr[0] = iParm[0];
	tImp.imp_attr[1] = iParm[1];
	tImp.imp_attr[2] = iParm[2];
	tImp.imp_attr[3] = iParm[3];
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk);
	ret = disp = 0;
	while ((len=akxtgwnsl(line,line_len,&ssp," \t()-,",0x41)) > 0) {
/*
printf("cl_pr_ex_def_implicit: len=%d wd=[%s]\n",len,ssp.wd);
*/
		c = *ssp.wd;
		if (disp == 0) {	/* ( */
			if (c != '(') {
				ret = -1;
				break;
			}
			disp = 1;
		}
		else if (disp==1 || disp==3) {	/* A or B */
			if (ssp.attr[0]>10 || (c>='0' && c<='9')) {
				ret = -2;
				break;
			}
			else {
				if (disp == 1) {
					tImp.imp_scope = scope_str;
					/* from�Z�b�g, to ��0���Z�b�g */
					strnzcpy(tImp.imp_from,ssp.wd,3);
					tImp.imp_to[0] = '\0';
					tImp.imp_flen = len;
				}
				else {
					/* to �ɃZ�b�g */
					strnzcpy(tImp.imp_to,ssp.wd,3);
				}
				disp++;
			}
		}
		else if (disp == 2) {	/* - or , */
			if (c == '-') {
				disp = 3;
			}
			else if (c==',' || c==')') {
				/* from,to��o�^ */
/*
printf("cl_pr_ex_def_implicit: scope=[%c] from=[%s] to=[%s]\n",tImp.imp_scope,tImp.imp_from,tImp.imp_to);
*/
				if ((rc=_chk_implicit_char(scope_str,&tImp)) < 0) return rc;
				if ((rc=akxs_mseq_s(pImplicit,&tImp)) < 0) return rc;
				if (c == ')') {
					disp = 5;
					break;
				}
				disp = 1;
			}
			else {
				ret = -3;
				break;
			}
		}
		else if (disp == 4) {	/* , or ) */
			if (c==',' || c==')') {
				/* from,to��o�^ */
/*
printf("cl_pr_ex_def_implicit: scope=[%c] from=[%s] to=[%s]\n",tImp.imp_scope,tImp.imp_from,tImp.imp_to);
*/
				if ((rc=_chk_implicit_char(scope_str,&tImp)) < 0) return rc;
				if ((rc=akxs_mseq_s(pImplicit,&tImp)) < 0) return rc;
				if (c == ')') {
					disp = 5;
					break;
				}
				disp = 1;
			}
			else {
				return -4;
			}
		}
	}
	if (!ret) {
		if ((len=akxtgwnsl(line,line_len,&ssp," \t()-,",0x41)) > 0) ret = -5;
		else if (disp < 5) ret = -6;
	}
	if (ret < 0) {
/*
printf("cl_pr_ex_def_implicit: ret=%d\n",ret);
*/
		ERROROUT2(FORMAT(440),_fn_,ret);
		return ECL_SYNTAX_ERROR;
	}
/*
printf("cl_pr_ex_def_implicit: pImplicit->mc_ipos=%d\n",pImplicit->mc_ipos);
*/
	/* 2024.6.12 */
	qsort(pImplicit->mc_bufp,pImplicit->mc_ipos,sizeof(tdtImplicit),_sort_func_implicit);
/*
i=1;
while (akxs_mseq_get(pImplicit,i,&tImp) > 0) {
printf("cl_pr_ex_def_implicit: scope=[%c] flen=%d from=[%s] to=[%s]\n",
tImp.imp_scope,tImp.imp_flen,tImp.imp_from,tImp.imp_to);
i++;
}
*/
	/* 2023.8.25 */
	if (!ret) set_attr_scalar_var(scrct,proc,scope);
/*
printf("cl_pr_ex_def_implicit: ret=%d\n",ret);
*/
	return ret;
}

/************************************/
/*	cl_get_implicit					*/
/************************************/
int cl_get_implicit(varnam,varlen,iParm,scrct,proc,scope)
char *varnam;
int varlen,iParm[];
ScrPrCT *scrct;
ProcCT *proc;
int scope;
{
	static char *_fn_="cl_get_implicit";
	int i,atr,ret;
	char c,c1,c2;
	tdtImplicit tImp;
	MCAT2 *pImplicit;

	if (!varnam || varlen<=0 || !iParm) return -1;

DEBUGOUTL5(120,"cl_get_implicit: scrct=%08x proc=%08x scope=%08x varlen=%d varnam=[%s]",scrct,proc,scope,varlen,varnam);

	mem_set_int(iParm,0,4);
	pImplicit = NULL;
	if (!scope) {
		if (scrct) {
			if (proc) pImplicit = proc->pImplicit;
			else  pImplicit = scrct->pImplicit;
/*
printf("cl_get_implicit: pImplicit=%08x\n",pImplicit);
*/
		}
	}
	else if (scope & D_GX_OPT_SET_LOCAL) {
		if (proc) pImplicit = proc->pImplicit;
	}
	else if (scope & D_GX_OPT_SET_PRIVATE) {
		if (scrct) pImplicit = scrct->pImplicit;
	}
	else if (scope & D_GX_OPT_SET_PUBLIC) {
		pImplicit = pGImplicit;
	}
#if 0	/* def global xxx; �̂Ƃ��Ă΂��̂ŃG���[�ɂł��Ȃ� */
	else if (scope & D_GX_OPT_SET_GLOBAL) {
		ERROROUT2(FORMAT(636),_fn_,cl_get_scope_name_from_opt(scope));	/* %s: %s�͎w��ł��܂���B*/
		return ECL_SCRIPT_ERROR;
	}
#endif
	if (!pImplicit) return 0;

	i = 1;
	c = *varnam;
	ret = 0;
	while (akxs_mseq_get(pImplicit,i,&tImp) > 0) {
/*
printf("cl_get_implicit: from=[%s] to=[%s]\n",tImp.imp_from,tImp.imp_to);
*/
		if (c2=*tImp.imp_to) {
			c1 = *tImp.imp_from;
			if (c>=c1 && c<=c2) {
				ret = 1;
				break;
			}
		}
		else {
			if (varlen >= tImp.imp_flen) {
				if (!memcmp(varnam,tImp.imp_from,tImp.imp_flen)) {
					ret = 2;
					break;
				}
			}
		}
		i++;
	}
	if (ret) {
		iParm[0] = tImp.imp_attr[0];
		iParm[1] = tImp.imp_attr[1];
		iParm[2] = tImp.imp_attr[2];
		iParm[3] = tImp.imp_attr[3];
DEBUGOUTL5(120,"%s: iParm=%d %d %d %d",_fn_,iParm[0],iParm[1],iParm[2],iParm[3]);
		iParm[19] = tImp.imp_rsv[0]<<24;
/*
printf("%s: iParm[19]=%08x\n",_fn_,iParm[19]);
*/
	}
	return ret;
}
/* 2023.8.25 */
/************************************/
/*	set_attr_scalar_var				*/
/************************************/
int set_attr_scalar_var(scrct,proc,scope)
ScrPrCT *scrct;
ProcCT *proc;
int scope;
{
	XHASHB *xha;
	tdtInfoParm *pInfo,tInfoParm;
	int i,m,ih,rc,iParm[4],iMAX;
	char *cpKey,id;
/*
printf("set_attr_scalar_var:Enter scrct=%08x proc=%08x scope=%08x\n",scrct,proc,scope);
*/
	rc = 0;
	xha = NULL;
	if (scope & D_GX_OPT_SET_LOCAL) {
		if (proc) xha = proc->pha_vnam;
	}
	else if (scope & D_GX_OPT_SET_PRIVATE) {
		if (scrct) xha = scrct->Vary->pha_vnam;
	}
	else if (scope & D_GX_OPT_SET_PUBLIC) xha = pCLprocTable->pha_vnam;
	else if (scope & D_GX_OPT_SET_GLOBAL) {
		return ECL_SCRIPT_ERROR;
	}
	if (xha) {
		/* 2025.12.31 */
		if (akxs_xhash(xha,'T',NULL) <= 0) return 0;
		iMAX = xha->xha_xhix;
		for (i=1;;i++) {
			i = akxs_xhash_next_i(iMAX,xha,i);
			if (i == AKX_HASH_NEXT_BREAK) break;
			xha->xha_xhix = i;
			if ((ih = akxs_xhashn2(xha,'P',&cpKey,0,&pInfo)) < 0) break;
			else if (ih > 0) {

DEBUGOUTL3(120,"set_attr_scalar_var: cpKey=[%s] pi_id=[%c] pi_aux[0]=%02x",cpKey,pInfo->pi_id,pInfo->pi_aux[0]);

				if ((id=pInfo->pi_id)==' ' || id=='\0') {
					if (!(pInfo->pi_aux[0] & D_AUX0_ZOK_DTYP)) {
						rc = cl_get_implicit(cpKey,strlen(cpKey),iParm,scrct,proc,scope);
/*
printf("set_attr_scalar_var: rc=%d\n",rc);
*/
						if (rc > 0) {
/*
printf("set_attr_scalar_var: cpKey=[%s] iParm=%d %d %d %d\n",cpKey,iParm[0],iParm[1],iParm[2],iParm[3]);
*/
							if (id) cl_gx_copy_info(&tInfoParm,pInfo);
							rc = cl_set_parm_init(pInfo,iParm,1);
							if (id && !rc) rc = cl_gx_rep_val_set(pInfo,&tInfoParm,0);
						}
					}
				}
			}
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_struct_check_valid(pInfoParm,iEROUT_NDEF)
tdtInfoParm *pInfoParm;
int iEROUT_NDEF;
{
	static char *_fn_ = "cl_struct_check_valid";
	int rc,iINVALID,ix;
	tdtInfoParm *pInfo;
	tdtDefType *pDeftype0,*pDeftype;
	char *name,id,id0,*p;

	if (!pInfoParm) return -1;
/*
printf("%s:Enter pInfoParm=%08x id=[%c]\n",_fn_,pInfoParm,pInfoParm->pi_id);
*/
	rc = 0;
	if ((id=pInfoParm->pi_id)=='T' && pInfoParm->pi_dlen == sizeof(tdtDefType)) {
DEBUGOUT_InfoParm(194,"%s: pInfoParm=",pInfoParm,_fn_,0);
/*
printf("%s: pInfoParm=%08x pi_paux=%08x\n",_fn_,pInfoParm,pInfoParm->pi_paux);
*/
		pDeftype = (tdtDefType *)pInfoParm->pi_data;	/* �����A�q�����m��Ȃ� */
		if ((pInfo=(tdtInfoParm *)pInfoParm->pi_paux) && pInfo!=pInfoParm) {
DEBUGOUT_InfoParm(194,"%s: pInfo=",pInfo,_fn_,0);
			/* pInfo���葱�����̒��Œ�`���ꂽ�z��̂Ƃ��́A���^�[���������_�ŁA
			   pInfo����0�N���A����Ă��邽�߁ApIndex0��NULL�ɂȂ��Ă��� */
			pDeftype0 = (tdtDefType *)pInfo->pi_data;
/*
printf("%s: pDeftype=%08x pDeftype0=%08x\n",_fn_,pDeftype,pDeftype0);
*/
			if (pDeftype0 != pDeftype) {	/* �e�̉\�� */
				iINVALID = 0;
				id0 = pInfo->pi_id;
				if (id != id0) iINVALID = 1;	/* pInfo����0�N���A����Ă���Ƃ��́A�����ň��������� */
				else {
					if ((ix=akxs_xhasl(pGLprocTable->pha_gid,'R',pInfo->pi_hlen,0)) <= 0) iINVALID = 2;
					else if (pDeftype0) {
/*
printf("%s: pDeftype->pType=%08x pDeftype0->pType=%08x\n",_fn_,pDeftype->pType,pDeftype0->pType);
*/
						if (pDeftype0->pType != pDeftype->pType) iINVALID = 3;
					}
/*
printf("%s: ix=%d pi_hlen=%d\n",_fn_,ix,pInfo->pi_hlen);
*/
				}
				if (iINVALID) {
/*
printf("%s: iINVALID=%d\n",_fn_,iINVALID);
*/
					if (iEROUT_NDEF) {
						if (!(name=(char *)pInfoParm->pi_pos)) name = AKX_NULL_PRINT;
						p = FORMAT(154);	/* �\���� */
						if (iINVALID == 3)
								/* %s: �R�s�[��%s[%s]�̃f�[�^�悪�Ē�`���ꂽ���ߖ{%s�͖����ł��B*/
							ERROROUT4(FORMAT(659),_fn_,p,name,p);
						else
								/* %s: �R�s�[����%s[%s]�������ł��B(%d) */
							ERROROUT4(FORMAT(231),_fn_,p,name,iINVALID);
					}
					rc = ECL_SCRIPT_ERROR;
				}
			}
		}
	}
	return rc;
}

/************************************************/
/*	ppDeftype : ppDeftype<>NULL�̂Ƃ��ȉ���Ԃ�	*/
/*			   rc = 0 : �q��pIndex				*/
/*			   rc = 1 : �e��pIndex				*/
/*	opt = 0 : �e�����߂Ȃ�						*/
/*		<>0 : �e�����߂�						*/
/*	rc = 0: �e�����߂Ȃ��Ƃ����A�e���Ȃ�		*/
/*		 1: �e������							*/
/************************************************/
int cl_get_struct_member_opt(pInfoParm,ppDeftype,opt)
tdtInfoParm *pInfoParm;
tdtDefType **ppDeftype;
int opt;
{
	static char *_fn_="cl_get_struct_member_opt";
	char id;
	int  rc;
	tdtInfoParm *pInfo;
	tdtDefType *pDeftype0,*pDeftype;

	if (!pInfoParm) return -1;
DEBUGOUT_InfoParm(194,"%s:Enter pInfoParm=",pInfoParm,_fn_,0);
/*
printf("%s:Enter pInfoParm=%08x id=[%c] opt=%08x\n",_fn_,pInfoParm,pInfoParm->pi_id,opt);
*/
	rc = 0;
	if (ppDeftype) *ppDeftype = NULL;
	if (pInfoParm->pi_id == 'T' && pInfoParm->pi_dlen==sizeof(tdtDefType)) {
		pDeftype  = (tdtDefType *)pInfoParm->pi_data;	/* �����A�q�����m��Ȃ� */
		if (opt) {
/*
printf("%s: pInfoParm=%08x pi_paux=%08x\n",_fn_,pInfoParm,pInfoParm->pi_paux);
*/
			if ((pInfo=(tdtInfoParm *)pInfoParm->pi_paux) && pInfo!=pInfoParm) {
				if (pDeftype0 = (tdtDefType *)pInfo->pi_data) {		/* �e�̉\�� */
/*
printf("%s: pDeftype=%08x pDeftype0=%08x\n",_fn_,pDeftype,pDeftype0);
*/
					/* InfoParm���P���ɃR�s�[���ꂽ�����ł��ApInfo!=pInfoParm�ƂȂ�A*/
					/* �e����ƂȂ��Ă��܂��̂ŁApDeftype���قȂ�ApDeftype->pType�� */
					/* �����Ƃ��̂݁ApInfoParm�� �������ꂽ�q�ł���A�e����Ƃ������ƂɂȂ� */
/*
printf("%s: pDeftype->pType=%08x pDeftype0->pType=%08x\n",_fn_,pDeftype->pType,pDeftype0->pType);
*/
					if (pDeftype0!=pDeftype && pDeftype0->pType==pDeftype->pType) {
						pDeftype = pDeftype0;	/* �e */
						rc = 1;
/*
printf("%s: rc=%d\n",_fn_,rc);
*/
DEBUGOUT_InfoParm(194,"%s: parent rc=%d pInfo=",pInfo,_fn_,rc);
					}
				}
/*
printf("%s: parent pInfo=%08x rc=%d\n",_fn_,pInfo,rc);
*/
			}
		}
		if (ppDeftype) *ppDeftype = pDeftype;
	}
	else rc = ECL_SYSTEM_ERROR;
/*
printf("%s: rc=%d\n",_fn_,rc);
*/
	return rc;
}
