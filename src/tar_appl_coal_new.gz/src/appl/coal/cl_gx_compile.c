static  char    sccsid[]="%Z% %M% %I% %E% %U%";
/*****************************************************/
/*                                                   */
/*       Compile & Execution expression              */
/*                                                   */
/*           coded by A.Kobayashi 2010.10.26         */
/*                                                   */
/*****************************************************/
#include "colmn.h"
/*
#define LVL_GXCOMPL	150
#define LVL_GXEXOBJ	160
*/
#define DATA_NARABI

extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern int giOptions[];
extern char *ScopeNames[];
extern char *ScopeMarks[];
extern int  ScopeGXOpts[];
extern int  ScopeAUX1s[];
extern char cmp_sep2[];
extern char cmp_sep3[];
/* 2021.11.1 */
extern char cmp_sep[];

static int iEROUT_NDEF;
static int _rep_info_set(/*mc,ppInfoParm1,pInfoParm2,opt,dastk,irs,ppmstk*/);

static char *logical[]={"AND","OR","NOT","&&","||","!",NULL};
static char *math[]={"+","-","*","/","&","^","|","~","%","<<",">>","**",">>>","..",NULL};
static char *hk[]={"<=","=<",">=","=>","==","==","<>","><","!=","!=","<",">",NULL};
static char *HK[]={"LT","GT","LE","GE","EQ","NE","iEQ","iNE",NULL};
static char *ex[]={"&=","^=","|=","","","","","","~=","",
"*=","/=","%=","+=","-=","<<=",">>=","&+=","|+=",">>>=",NULL};
static char *cast[]={"CCHAR","CBIN","CINT","CLONG","CLNG","CDEC","CFLOAT","CFLT","CDOUBLE","CDBL"
	,"CBULK","CDATE","FUNC","CIMG","CIMAGE",NULL};

static short act[29][29]={																   /*  �O   */
	{99, 2,-1, 2,-1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2,-1, 2, 2, 2, 2, 1}, /* 0       */
	{-1, 2, 4, 2,-1, 2, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 6, 2,-1, 2, 2, 2, 2, 1}, /* 1  (    */
	{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-2,-2,-1,-1,-1,-1,-1,-1,-1,-1,-1}, /* 2  )    */
	{-1, 2,-1, 2, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 6, 2,-1, 2, 2, 2, 2, 1}, /* 3  [    */
	{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-2,-2,-1,-1,-1,-1,-1,-1,-1,-1,-1}, /* 4  ]    */
	{ 3, 2, 3, 2, 3, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /* 5 ! ~   */
	{ 3, 2, 3, 2, 3, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /* 6 (x)   */
	{ 3, 2, 3, 2, 3, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /* 7 * /   */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /* 8  +-   */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /* 9 << >> */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /*10 CONCAT*/
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /*11 <= >  */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /*12 == != */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /*13  &    */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /*14  ^    */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /*15  |    */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /*16  &&   */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /*17  ||   */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /*18  ?    */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /*19  :    */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 3, 2, 2, 2, 2, 1}, /*20 = +=  */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,-1, 2, 3, 2, 2, 2, 2, 1}, /*21  ,    */
	{-1, 2,-1, 2,-1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 6, 2, 4, 2, 2, 2, 2, 1}, /*22  {    */
	{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-2,-2,-1,-1,-1,-1,-1,-1,-1,-1,-1}, /*23  }    */
	{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 3, 3, 3, 3, 1}, /*24 .name */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /*25 ..    */
	{ 3, 2, 3, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3, 2, 3, 1}, /*26 **    */
	{ 3, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 2, 3, 2, 2, 2, 2, 1}, /*27 ==>   */
	{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1}  /*28  ��   */
 /* {    (  )  [  ] !~ (x) *  +- << C  <= != &  ^  |  && || ?  : += ,  {  } .x .. ** ==> ��}  <-- �� */
};

/****************************************/
/*										*/
/****************************************/
char *_atr2ope(atr)
int atr;
{
	static char *ope[]={""
/*  1-10 */ ,"(",")","[","]","func(","array[","{","}",0,"cast("
/* 11-20 */ ,0,0,"NEW","++","--","!!","~~","!","~","CAST"
/* 21-30 */ ,"*","/","%","+","-","<<",">>","ABS",".","**"
/* 31-40 */ ,"<",">","<=",">=","==","!=","LIKE","MAX","MIN",0
/* 41-50 */ ,"&","^","|",0,0,0,0,">>>",0,"`"
/* 51-60 */ ,"&&","||",0,0,0,0,0,0,"?",":"
/* 61-70 */ ,0,0,"MOD",0,"iEQ","iNE",0,0,0,0
/* 71-80 */ ,"&=","^=","|=",0,0,0,0,0,"~=",0
/* 81-90 */ ,"*=","/=","%=","+=","-=","<<=",">>=","&+=",">>>=","="
/* 91-100*/ ,"PUSH",0,0,0,"..","<==","==>",",",";",0};
	char *op=NULL;

	if (atr < 0) {
		atr= -atr;
		if ((atr>=14 && atr<=19) || atr==21 || atr==24 || atr==25 || atr==30) op = ope[atr];
	}
	else if (atr < 100) {
		op = ope[atr];
	}
	return op;
}

/****************************************/
/*										*/
/****************************************/
static char *_atr2name(da,atr)
char *da[];
int atr;
{
	static char *obj[]={"�������Z�l","�֐��l","��ʕϐ��l","�V�X�e���ϐ��l",
	                    "NULL","cast�l","CLASS�l","new CLASS�l","�z��l","NAME"};
	int i,j,k;
	char *p;

	if (atr<100) {
		if (!(p=_atr2ope(atr))) p = AKX_NULL_PRINT;
		return p;
	}
	j = 9;
	for (k=9001;k>=1001;k-=1000,j--) {
		if (atr >= k) {
			i = atr - k;
			break;
		}
	}
/*	if (i==998) return "�֐��lor�z��l";	*/
	if (i >= 997) {
		if (i == 998) p = obj[j-1];
		else p = obj[8];
	}
	else p = da[i];
	return p;
}

/****************************************/
/*										*/
/****************************************/
static int _rep_data_memory(im,pInfoParmW)
int im;
tdtInfoParm *pInfoParmW;
{
	tdtInfoParm tInfoParm;
	char *pW,*p;
	uchar uc;
	int rc,len;

	if (!pInfoParmW) return -1;
	if (pInfoParmW->pi_id==' ' && (len=pInfoParmW->pi_dlen)>0 &&
	    ((uc=pInfoParmW->pi_attr)==DEF_ZOK_CHAR || uc==DEF_ZOK_BULK ||
	      uc==DEF_ZOK_DECI || uc==DEF_ZOK_DATE) &&
	    (pW=pInfoParmW->pi_data)) {
		if (uc == DEF_ZOK_CHAR) len++;
#if 1	/* 2025.3.25 */
		if (pInfoParmW->pi_alen & D_AULN_RANGE_DATA) len += len;
#endif
		if (!(p=cl_opt_malloc(im,len))) return -1;
		memcpy(p,pW,len);
		pInfoParmW->pi_data = p;
		if (im == D_OPT_ALC_MALLOC) pInfoParmW->pi_scale |= D_DATA_MALLOC;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_aux1_from_opt(opt)
int opt;
{
	int i,k;

	i = 0;
	if ((k=akxs_iseq_opt(ScopeGXOpts,D_MAX_SCOPE,opt,1)) > 0) i = ScopeAUX1s[k-1];
	return i;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_opt_from_aux1(i)
int i;
{
	int opt,k;

	opt = 0;
	if ((k=akxs_iseq_opt(ScopeAUX1s,D_MAX_SCOPE,i,1)) > 0) opt = ScopeGXOpts[k-1];
	return opt;
}

/****************************************/
/*										*/
/****************************************/
char *cl_get_scope_from_opt(opt)
int opt;
{
	char *pp;
	int k;

	pp = "";
	if ((k=akxs_iseq_opt(ScopeGXOpts,D_MAX_SCOPE,opt,1)) > 0) pp = ScopeMarks[k-1];
	return pp;
}

/****************************************/
/*										*/
/****************************************/
char *cl_gx_get_name_from_id(id)
char id;
{
	/* 2023.8.24 */
	return cl_get_variable_type(id);
}

/****************************************/
/*										*/
/****************************************/
char *cl_gx_get_name_from_info(pInfoParmW)
tdtInfoParm *pInfoParmW;
{
	char id,*nam;
	tdtInfoParm *pInfo;

	id = pInfoParmW->pi_id;
	if (id==' ' || !id) {
		if (pInfoParmW->pi_aux[1] & D_AUX1_PROTECTED) {
			nam = FORMAT(302);
			return nam;
		}
	}
	else if (id == 'S') {
		if (!(pInfoParmW->pi_aux[1] & D_AUX1_POINTER)) {
			pInfo = (tdtInfoParm *)pInfoParmW->pi_pos;
			return cl_gx_get_name_from_info(pInfo);
		}
	}
	nam = cl_gx_get_name_from_id(id);
	return nam;
}

/****************************************/
/*										*/
/****************************************/
char *cl_gx_get_obj_name(pInfoParm,pa)
tdtInfoParm *pInfoParm;
char *pa[];
{
	char id,*nam;

	id = pInfoParm->pi_id;
	if (instrchar("ARPT",id)) nam = (char *)pInfoParm->pi_pos;
	else if (instrchar("FCMO",id)) nam = pInfoParm->pi_data;
	else if (id == 'I') nam = (char *)pInfoParm->pi_hlen;
	else nam = "";
	if (!akxm_addrchk(nam)) nam = "";
	if (pa) {
		pa[0] = cl_gx_get_name_from_id(id);
		pa[1] = nam;
	}
	return nam;
}

/****************************************/
/*										*/
/****************************************/
int cl_skip_scope_mark(pLprp,pLlen,pix)
char *pLprp;
int pLlen,*pix;
{
	char buf[D_LEN_SCOPE_MARK+1];
	int rc,ix;

	rc = 0;
	if (!pLprp) return -1;
	ix = 0;
	if (*pLprp == '<') {
		memzcpy(buf,pLprp,D_LEN_SCOPE_MARK);
		if (!(ix=cl_get_def_scope(buf))) {
			ERROROUT2(FORMAT(135),"cl_skip_scope_mark",buf);	/* %s: Invalid scope name[%s] */
			return -1;
		}
		rc = D_LEN_SCOPE_MARK;
	}
	if (pix) *pix = ix;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int _conv_arg_opt2(da,len,pInfoParmW,opt)
char *da;
tdtInfoParm *pInfoParmW;
int len,opt;
{
	static char *_fn_="_conv_arg_opt2";
	parmList qprmL;
	int x,rc;

DEBUGOUTL3(194,"--->%s:Enter: opt=%08x da=[%s]",_fn_,opt,da);

	if (!pInfoParmW) return -1;
	qprmL.prp = da;
	qprmL.prmlen = len/* = strlen(da)*/;
	qprmL.opt = SET_TYPE_OPT(akxt_get_code_type());
	if (!(rc=cl_skip_scope_mark(qprmL.prp,qprmL.prmlen,&x))) ;
	else if (rc > 0) {
		qprmL.prp += rc;
		qprmL.prmlen -= rc;
	/*	opt |= x;	2022.9.26 */
		opt = (opt & ~D_GX_OPT_SET_SCOPE) | x;
	}
	else return rc;

DEBUGOUTL3(150,"%s: opt=%08x da=[%s]",_fn_,opt,qprmL.prp);

	if (rc=cl_conv_arg_opt(&qprmL,pInfoParmW,opt)) {
DEBUGOUTL2(197,"%s:<--- cl_conv_arg_opt rc=%d",_fn_,rc);
		if (rc == NAME_CONST) {
			rc = cl_conv_parm_opt(&qprmL,pInfoParmW,opt);
DEBUGOUTL2(197,"%s:<--- cl_conv_parm_opt rc=%d",_fn_,rc);
		}
		if (rc == ECL_NDEFVAR_ERROR) {
			if (cl_get_option(1,0) & 0x10) {
				ERROROUT2(FORMAT(438),_fn_,da);	/* %s: [%s]�͖���`�ł��B*/
			}
			else {
				cl_set_parm_char(pInfoParmW,da,len);
				pInfoParmW->pi_id = D_DATA_ID_UNDEFVAR;
				pInfoParmW->pi_aux[1] = cl_gx_get_aux1_from_opt(opt);
				rc = 0;
			}
		}
		else if (rc==ECL_DEFINED_ARRAY || rc==NULL_PARM || rc==ECL_NO_DATA_ERROR) {
			rc = 0;
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int _conv_arg_opt(da,pInfoParmW,opt)
char *da;
tdtInfoParm *pInfoParmW;
int opt;
{
	return _conv_arg_opt2(da,strlen(da),pInfoParmW,opt);
}

/****************************************/
/*										*/
/****************************************/
int _name_to_func_var(atr,name,pInfoParm)
int atr;
char *name;
tdtInfoParm *pInfoParm;
{
	ScrPrCT *pScCT;
	ProcCT  *cur_procct;
	Leaf    *wkleaf,*nodeleaf;
	char     id;
	int      ctag;

	if (atr == 10000) {
		wkleaf = nodeleaf = NULL;
		id = '\0';
		if (!stricmp(name,D_SYS_CLASS_SYSTEM) ||
		    !stricmp(name,D_SYS_CLASS_FILE) ||
		    !stricmp(name,D_SYS_CLASS_MATH)) {
			atr = 101;
			id = 'C';
		}
		else if (pScCT = cl_search_src_ct()) {
			cur_procct = cl_search_proc_ct();
#if 0	/* 2025.1.26 */
			if (wkleaf=cl_search_method_leaf_and_inner(pScCT,cur_procct,name,&nodeleaf,CTAG_PROC|CTAG_FUNC|CTAG_CLASS)) {
				ctag = wkleaf->cmdtag;
				if (ctag == CTAG_CLASS) {
					atr = 101;
					id = 'C';
				}
				else if (ctag == CTAG_FUNC) {
					atr = 62;
					id = 'F';
				}
				else if (ctag == CTAG_PROC) {
					atr = 101;
					id = 'O';
				}
/*
printf("_name_to_func_var: ctag=%08x atr=%d id=[%c]\n",ctag,atr,id);
*/
			}
#else
			if (wkleaf=cl_search_class_leaf_and_inner(pScCT,cur_procct,name,&nodeleaf)) {
				atr = 101;
				id = 'C';
			}
			else if (wkleaf=cl_search_func_leaf_and_inner(pScCT,cur_procct,name,&nodeleaf)) {
			/*	atr = 61;	*/
				atr = 62;
				id = 'F';
			}
			else if (wkleaf=cl_search_proc_leaf_and_inner(pScCT,cur_procct,name,&nodeleaf)) {
				atr = 101;
				id = 'O';
			}
#endif
			if (wkleaf) DEBUGOUT_Leaf(LVL_GXCOMPL+5,"wkleaf",wkleaf);
			if (nodeleaf) DEBUGOUT_Leaf(LVL_GXCOMPL+5,"nodeleaf",nodeleaf);
		}
		/* 2021.3.22 */
		if (atr!=62 && atr!=101) {
			atr = 3000;
			if (pInfoParm) cl_parm_set0(pInfoParm);
		}
		else if (pInfoParm) {
			cl_set_parm_char(pInfoParm,name,strlen(name));
			pInfoParm->pi_id = id;
			pInfoParm->pi_len = atr;
			pInfoParm->pi_pos = (long)wkleaf;
			pInfoParm->pi_paux = (char *)nodeleaf;
			pInfoParm->pi_alen = D_AULN_SET_POS_LEAF;
			pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED;
		}
	}
	return atr;
}

/****************************************/
/*										*/
/****************************************/
int cl_is_yoyakugo(name)
char *name;
{
	cmdTable *pcmd;

	if (pcmd = cl_cmd_chk(name)) {
		if (pcmd->cmdid != C_UNKNOWN) return 1;
	}
	if (cl_chk_sysvar_name(name,strlen(name))) return 3;
	if (cl_get_name_attr(name,strlen(name),0x01,0xffff)) return 2;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_is_yoyakugo_opt(name,n,white,opt)
char *name,*white[];
int n,opt;
{
	int rc;

	if ((rc=akxs_seqr_str(white,n,name,opt))) {
		if (rc > 0) rc = 0;
		return rc;
	}
	return cl_is_yoyakugo(name);
}

/****************************************/
/*										*/
/****************************************/
int cl_chk_pname_name(name)
char *name;
{
	char *p;
	int rc,len;

	if (!(p=name)) rc = -1;
	else if (cl_is_redirect_fp(name,0)) rc = 0;
	else {
		if (!(rc=cl_is_yoyakugo(name))) {
			len = strlen(p);
			if (!(rc=cl_chk_name(p,len))) {
				if ((rc=cl_gx_chk_opt(name,0))==NAME_CONST || rc==SYSVAR) rc = 0;
			}
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _set_null_parm(im,pGxObjExpand,piob,piob0,pida)
int im;
GXObjectExpand *pGxObjExpand;
int *piob,*piob0,*pida;
{
	short *obj;
	tdtInfoParm **obj0;
	char **da;
	int iob,iob0,ida;
	tdtInfoParm *pInfoParmW;

	iob = *piob;
	iob0 = *piob0;
	ida = *pida;

	if (cl_gx_expand(pGxObjExpand->ms_obj,iob+1,&obj) < 0) return ECL_MAX_OBJ_ERROR;
	obj[iob++]=91;
	if (!(pInfoParmW=(tdtInfoParm *)cl_opt_malloc(im,sizeof(tdtInfoParm))))
		return ECL_MALLOC_ERROR;
	cl_null_parm(pInfoParmW);
	obj[iob++]=ida;

	if (cl_gx_expand(pGxObjExpand->ms_obj0,iob0,&obj0) < 0) return ECL_MAX_OBJ_ERROR;
	if (cl_gx_expand(pGxObjExpand->ms_da,ida,&da) < 0) return ECL_MAX_DA_ERROR;
	obj0[ida]=pInfoParmW;
	da[ida++] = "";
	iob0 = ida;

	*piob = iob;
	*piob0 = iob0;
	*pida = ida;

	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _check_cast(parl,pssp,iOpt,cast_parm,pInfoParm)
ParList *parl;
SSPL_S *pssp;
int iOpt,cast_parm[];
tdtInfoParm *pInfoParm;
{
	SSPL_S qssp;
	char *line,*p,*word,*line0;
	int line_len,iTMP,iSKIP,len,word_len,atr,atrn,rc,isp,word_len0;

	line0 = line = parl->par;
	line_len = parl->parlen;
	word_len0 = word_len = len = cast_parm[0];
	iTMP = cast_parm[1];
	isp = pssp->sp;
	word = pssp->wd;
	memcpy(&qssp,pssp,sizeof(SSPL_S));
	qssp.wd = word + word_len + 1;	/*wrk;*/
	qssp.wdmax -= word_len + 1;
	atr = iSKIP = 0;
/*
printf("_check_cast:0 isp0=%d word_len0=%d word=[%s]\n",isp0,word_len0,word);
*/
	if ((atrn=cmpgwnsl(line,line_len,&qssp,iOpt))<0) return atrn;
	if (atrn==1) {	/* char(5)����(�̂Ƃ� */
/*
printf("_check_cast:1 atrn=%d\n",atrn);
*/
		/* )�܂ŃX�L�b�v���� */
		if (rc=cl_skip_to_delm(line,line_len,"()",&qssp," \t(),'",1)) return rc;
/*
printf("_check_cast:1 word=[%s]\n",word);
*/
		iSKIP = 1;
		if ((atrn=cmpgwnsl(line,line_len,&qssp,iOpt))<0) return atrn;
/*
printf("_check_cast:2 atrn=%d\n",atrn);
*/
	}
	/* add 2023.5.3 */
	if (atrn==21) {	/* "cast������ *"�̂Ƃ� */
		*(word+len) = '*';
		len++;
		if (!iSKIP) isp = qssp.sp;
		word_len = len;
		if (!iTMP) {
			if (!(p=cl_tmp_const_malloc(line_len+1))) return ECL_MALLOC_ERROR;
			memzcpy(p,line,line_len);
			iTMP = 1;
			line = p;
			parl->par = line;
		}
		*(line+qssp.sp-1) = ' ';
/*
printf("_check_cast:2.1 isp=%d word_len=%d word=[%s]\n",isp,word_len,word);
*/
		if ((atrn=cmpgwnsl(line,line_len,&qssp,iOpt))<0) return atrn;
	}
	if (atrn==2) {
		if ((atrn=cmpgwnsl(line,line_len,&qssp,iOpt))<0) return atrn;
		atrn = _name_to_func_var(atrn,qssp.wd,pInfoParm);
/*
printf("_check_cast:3 atrn=%d wd=[%s]\n",atrn,qssp.wd);
*/
		if (atrn==1 || atrn==3000 || atrn==4000 || atrn==5000) atr=6000;
		else if (atrn==61 || atrn==62 || atrn==63 || atrn==28) {
			if ((atrn=cmpgwnsl(line,line_len,&qssp,iOpt))<0) return atrn;
/*
printf("_check_cast:4 atrn=%d\n",atrn);
*/
			if (atrn==1) atr=6000;	/* CAST */
		}
	}
	if (atr==6000) {
		pssp->sp = isp;
		*(word+len) = '\0';
/*
printf("_check_cast:5.1 line=[%s]\n",line);
*/
		cast_parm[0] = word_len;
		cast_parm[1] = iTMP;
	}
	else {
		*(word+word_len0) = '\0';
	}
/*
printf("_check_cast:5.2 atr=%d pssp->sp=%d word_len=%d word=[%s]\n",atr,pssp->sp,word_len,word);
*/
	return atr;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_compile_gp_opt(pgwprm,pssp,iOpt,pGxObjExpand)
GWPRM_S *pgwprm;
SSPL_S  *pssp;
int iOpt;
GXObjectExpand *pGxObjExpand;
{
	static char *name="cl_gx_compile";
	static char *fa[]={"(","[","{"};
	static tdtInfoParm tInfoParmK,tInfoParmF,tInfoParmA,tInfoParmL;
	int ida,idai,isp,line_len,isp0,word_len0;
	char **da,*cast0,*word,cw,*fai,buf[64],*line,*line0;
	short *obj;
	int nobj,iob,iob0;
	int sp;
	MCAT ms_stack,ms_stk_str;
	short *stack;
	int i,opt1,im,opt_scope;
	char *p,c,*pp;
	parmList  *prmL, qprmL;
	int atr,attr0,i1,i2,ac,mc,atrn,rc,conv_flg,len,attr1,word_len,kind,iSKIP,iTMP,atr_ix,atr_AO;
	tdtInfoParm *pInfoParmW,**obj0,tInfoParm;
	int iobj_goto1,iobj_goto2,ista_goto1,ista_goto2,lvl_3kou1,lvl_3kou2,optimize_flg;
	int sta_goto1[10],sta_goto2[10],cast_parm[4];
	char **stk_str;
	ParList parl;
/*
printf("cl_gx_compile: len=%d buf=[%s]\n",pgwprm->line_len,pgwprm->line);
*/
	cl_parm_set0(&tInfoParm);
	cl_set_parm_bin(&tInfoParmK,0);
	tInfoParmK.pi_aux[1] = D_AUX1_FUNC_ARRY;
	cl_set_parm_bin(&tInfoParmF,1);
	tInfoParmF.pi_aux[1] = D_AUX1_FUNC_ARRY;
	cl_set_parm_bin(&tInfoParmA,2);
	tInfoParmA.pi_aux[1] = D_AUX1_FUNC_ARRY;
	cl_set_parm_bin(&tInfoParmL,3);
	tInfoParmL.pi_aux[1] = D_AUX1_FUNC_ARRY;
	iobj_goto1=iobj_goto2=ista_goto1=ista_goto2=lvl_3kou1=lvl_3kou2=0;
	iob0=iob=0;
	ida=0;
	word = pssp->wd;
	pGxObjExpand->nobj = iob;
	pGxObjExpand->nda = ida;
	pGxObjExpand->nobj0 = iob0;
	cl_gx_expand(pGxObjExpand->ms_obj,-1,&obj);
	cl_gx_expand(pGxObjExpand->ms_obj0,-1,&obj0);
	cl_gx_expand(pGxObjExpand->ms_da,-1,&da);
	cl_gx_init_expand(&ms_stack,"ST",sizeof(short),MAX_STACK);
	cl_gx_expand(&ms_stack,0,&stack);
	cl_gx_init_expand(&ms_stk_str,"SS",sizeof(char *),MAX_STACK);
	cl_gx_expand(&ms_stk_str,0,&stk_str);
	prmL = &qprmL;
	stack[0]=0;
	sp=1;
	atr=0;
	optimize_flg=0;
	im = (iOpt & D_GX_OPT_ALC_MASK)>>12;
	opt1 = (iOpt & ~D_GX_OPT_SET_SCOPE) | D_GX_OPT_SET_ADDR | D_GX_OPT_NOEROUT_NDEF;
	opt_scope = iOpt & D_GX_OPT_SET_SCOPE;
/*
printf("cl_gx_compile: *** start iOpt=%08x opt1=%08x opt_scope=%08x\n",iOpt,opt1,opt_scope);
*/
DEBUGOUTL4(LVL_GXCOMPL+1,"cl_gx_compile: *** start iOpt=%08x opt1=%08x opt_scope=%08x im=%d",iOpt,opt1,opt_scope,im);

	line0 = line = pgwprm->line;
	line_len = pgwprm->line_len;
	cast_parm[1] = 0;
	for(;;) {
		/* x++,x-- �̂Ƃ��́A++,--���P�O�̂���(attr0)�Ƃ͂��Ȃ� */
		if (atr!=14 && atr!=15) attr0 = atr;
		for(;;) {
			atr_AO = 0;
			if ((atr=cmpgwnsl(line,line_len,pssp,iOpt))<0) return atr;
			cw = *word;
			word_len = strlen(word);

DEBUGOUTL4(LVL_GXCOMPL+1,"cl_gx_compile:cmpgwnsl: attr0=%d, gtwd attr=%d, wd=[%s] ssp.sp=%d",
attr0,atr,word,pssp->sp);

			tInfoParm.pi_id = '\0';
			tInfoParm.pi_len = atr;
			tInfoParm.pi_pos = 0;
			tInfoParm.pi_paux = NULL;
			if (attr0==1 && ((atr>=3000 && atr<=5000) || atr>=10000)) {
				if (atr == 3000) i = 1;
				else if (cl_gx_is_operator(word,FUNCCAST)) i = 1;	/* �O��(�Ō��݂�cast������ */
				else i = 0;
/*
printf("cl_gx_compile: i=%d\n",i);
*/
				if (i) {
					/* 2023.10.21 */
					parl.par = line;
					parl.parlen = line_len;
					cast_parm[0] = word_len;
					if ((rc=_check_cast(&parl,pssp,iOpt,cast_parm,&tInfoParm)) < 0) return rc;
					if (rc==6000) {
						atr = rc;
						line = parl.par;
						word_len = cast_parm[0];
						if (stack[sp-1]==1) {
							stack[sp-1] = 10;	/* 6;	*/	/* '(' of cast */
							i = obj[iob-1];
/*
printf("cl_gx_compile:6 obj=%d %d da=%s\n",obj[iob-2],i,da[i]);
*/
							if (obj[iob-2]==91 && *da[i]==*fa[0]) {
								iob -= 2;
								ida--;
							}
						}
					}
#if 0	/* 2023.10.19 *//* 2023.10.21 1-->0 */
					else {
						pssp->sp = isp0;
						word_len = word_len0;
						*(word+word_len) = '\0';
						line = line0;
/*
printf("cl_gx_compile:5.2 isp0=%d word_len=%d word=[%s]\n",isp0,word_len,word);
*/
					}
#endif
				}
			}
			if (atr==10001) atr = 62;
			if (atr == 10000) {
				if (rc=cl_get_def_scope(word)) {
					opt_scope = rc;
					continue;
				}
				else if (!stricmp(word,D_STR_NAME_STATIC)) {
					continue;
				}
#if 1	/* 2021.12.29 */
				else if (!strcmp(word,D_STR_MARK_INSTANCE)) {
					continue;
				}
#endif
				/* 2021.3.22 */
#if 1	/* 2023.2.22 */
				if (attr0 == 29) atr = 3000;
				else
#endif
				if ((atr=_name_to_func_var(atr,word,&tInfoParm)) == 3000) {
/*
printf("cl_gx_compile: atr=%d word=[%s]\n",atr,word);
*/
					if (cl_is_yoyakugo(word)) {
/*
printf("cl_gx_compile: cl_is_yoyakugo()=%d\n",i);
*/
						ERROROUT2(FORMAT(121),name,word);	/* %s: [%s]�͗\���ł��B */
						RETURN(-11)
					}
				}
			}
			pp = pssp->wd;
			pssp->wd += word_len + 1;	/*strlen(word)*/
			attr1 = cmppeekwnsl(line,line_len,pssp,iOpt);
			pssp->wd = pp;
			if (atr==23 && 	/* 23=% */
				(attr0==0 || attr0==1 || attr0==3 || attr0==5 || attr0==7 ||
				    attr0<0 ||
				    (attr0>=20 && attr0<2000))) {
					atr = 63;	/* �֐� */
			}
			else if (atr==13) {	/* new */
				if (attr1 == 1) atr = 62;
			}
DEBUGOUTL1(LVL_GXCOMPL+1,"cl_gx_compile: modified attr=%d",atr);

			if (attr0==0 || attr0==1 || attr0==3 || attr0==5 || attr0==7 ||
			    (attr0>=21 && attr0<=2000)) {
				if ((atr>=14 && atr<=19) || atr==24 || atr==25 || atr==28 || atr==41 || atr==30 ||
				    atr==61 || atr==62 ||atr==63) ;
				else if (atr==98 && (attr0==0 || attr0==1 || attr0==3 ||
				                     attr0==5 || attr0==7 || attr0==98)) ;
				else if ((atr>=22 && atr<100) ||
				         (attr0==29 && (atr>=2 && atr<22))) {
					/* %s: [%s]�̌��[%s]�̈ʒu���s���ł��B */
					ERROROUT3(FORMAT(122),name,_atr2name(da,attr0),word);
					return -8;
				}
			}
			else if ((attr0==14 || attr0==15) && (atr==61 || atr==62 || atr>=3000)) {
				/* %s: [%s]�̌��[%s]�̈ʒu���s���ł��B */
				ERROROUT3(FORMAT(122),name,_atr2name(da,attr0),word);
				return -8;
			}
			if (atr==99) {
				atr=0;
			}
			else if ((attr0>=2000 && (atr==7 || atr==101 || atr>=2000)) ||
			         (((attr0>=4000 && attr0<6000) || (attr0>=7000 && attr0<8000)) && (atr==1 /*|| atr==3 || atr==7*/))) {
				/* %s: ���Z�q������܂���B%s %s */
				ERROROUT3(FORMAT(123),name,
				          _atr2name(da,attr0),word);
				return -2;
			}
			else if (atr>=3000 && atr<=6000) {
				rc = 0;
				if (opt_scope) {
					if (atr==4000 || atr==5000) rc = -9;
					else if (atr==3000 && (cw=='$' || cw=='#'/* || cw=='%'*/)) {
						if (cw=='$') {
							if (word_len>1 && atoi(word+1)) rc = -9;	/*strlen(word)*/
						}
						else rc = -9;
					}
				}
				if (rc) {
					/* %s: [%s]�ɃA�N�Z�X�C���q�͎w��ł��܂���B */
					ERROROUT2(FORMAT(124),name,word);
					return rc;
				}
				if (cl_gx_expand(pGxObjExpand->ms_da,ida,&da) < 0) return ECL_MAX_DA_ERROR;
				if (!(da[ida]=cl_opt_malloc(im,strlen(word)+2+D_LEN_SCOPE_MARK)))
					return ECL_MALLOC_ERROR;
				p = da[ida];
				if (atr == 3000) {
					if (attr0 == 29) {
						/* 2021.3.15 */
						if (cl_chk_name_var(word,word_len)) {
							/* %s: �����o�[��[%s]���s���ł��B */
							ERROROUT2(FORMAT(136),name,word);
							return ECL_SCRIPT_ERROR;
						}
					}
				}
				strcpy(p,word);
				if (atr==6000) cast0 = da[ida];
				atr += ++ida;
			}
			else if ((atr>=13 && atr<=19) || atr==21 || atr==24 || atr==25 || atr==41 || atr==30) {
				if (attr0==0 || attr0==1 || attr0==3 || attr0==5 || attr0==6 || attr0==7 ||
				    (attr0>=21 && attr0<=2000) ||
					(atr!=21 && (attr0<=-14 && attr0>=-19) || attr0==-21 || attr0==-25 || attr0==-41 || attr0==-30)) {
					atr = -atr;
				}
			}
			else if (atr==61 || atr==62 || atr==63 || atr==28 || atr==101) {	/* 63=MOD 28=ABS */
				if (attr0==0 || attr0==1 || attr0==3 || attr0==5 || attr0==6 || attr0==7 ||
				    attr0<0 ||
				    (attr0>=20 && attr0<2000)) {
					if (atr == 101) {
						if (attr0 == -13) atr = 8000;	/* new CLASS */
						else atr = 7000;	/* CLASS */
					}
					else atr = 2000;	/* �֐��� */
				}
				else if (atr==62 || atr==28) atr = 2000;	/* 62�͊֐��̂� */
				else if (atr==61) {							/* 61�͓񍀉��Z�q�ɂȂ� */
					atr = 1000;	/* �������Z�q */
					pssp->attr[1] = 61;
					pssp->wd = word;
					if (!stricmp(word,"AND")) atr_AO = 0x10000+51;
					else if (!stricmp(word,"OR")) atr_AO = 0x20000+52;
				}
				if (attr0>=2000 && atr>=2000) {
								/* %s: ���Z�q������܂���B%s %s */
					ERROROUT3(FORMAT(123),name,_atr2name(da,attr0),word);
					return -2;
				}
				if (atr==1000 || atr==2000 || atr==7000 || atr==8000) {
					if (opt_scope) {
						if (atr==2000 && (cw=='$' || cw=='#'/* || cw=='%'*/)) ;
						else {
							/* %s: [%s]�ɃA�N�Z�X�C���q�͎w��ł��܂���B */
							ERROROUT2(FORMAT(124),name,word);
							return -10;
						}
					}
					if (cl_gx_expand(pGxObjExpand->ms_da,ida,&da) < 0) return ECL_MAX_DA_ERROR;
					if (!(da[ida]=cl_opt_malloc(im,word_len+1+D_LEN_SCOPE_MARK)))	/*strlen(word)*/
						return ECL_MALLOC_ERROR;
					strcpy(da[ida],word);
					atr += ++ida;
				}
			}
			else if (atr==1 && ((attr0>=2001 && attr0<=5000) ||
			                    (attr0>=6001 && attr0<=7000) ||		/* �֐���( */
			                    (attr0>=8001 && attr0<=9000))) {	/* new Class��( */
				atr = 5;
			}
			else if (atr==2 && attr0>=6001 && attr0<=7000) {	/* CAST */
				atr = 20;
			}
			else if (atr == 3) {	/* [ */
				if ((attr0>=3001 && attr0<4000) ||	/* ��ʕϐ� */
				    attr0==2 || attr0==4 || attr0==2998 || attr0==2999) atr = 6;	/* �z���[ */
				else if (attr0<=100 || (attr0>=1000 && attr0<2000)) ;	/* �f�[�^���ю��̊J�n��'[' */
				else {
					/* %s: �z�񖼂��Ȃ����s���ł��B */
					ERROROUT1(FORMAT(137),name);
					return -10;
				}
			}
			else if (atr>=71 && atr<=90)
				opt1 &= ~(D_GX_OPT_SET_LOCAL | D_GX_OPT_SET_PUBLIC | D_GX_OPT_SET_GLOBAL);
			break;
		}

DEBUGOUTL2(LVL_GXCOMPL+1,"cl_gx_compile:          attr=%d opt_scope=%08x",atr,opt_scope);

		if (atr == 60) lvl_3kou2 = lvl_3kou1;
#if 1	/* 2022.1.25 */
		else if (atr==51 || atr==52) pGxObjExpand->index0 |= 0x10;
#endif
		/* 2023.8.8 */
		if (atr_AO & 0x10000) atr_ix = 51;
		else if (atr_AO & 0x20000) atr_ix = 52;
		else {
			atr_AO = atr_ix = atr;
		}
		i2=cmp_mkix(atr_ix);
		for(;;) {
			if (sp<1) return ECL_SYNTAX_ERROR;
			/* 2023.8.8 */
			mc = stack[sp-1];
			atr_ix = mc;
			if (mc > 0) {
				if (mc & 0x10000) atr_ix = 51;
				else if (mc & 0x20000) atr_ix = 52;
				mc &= 0xffff;
			}
			i1=cmp_mkix(atr_ix);
			ac=cmp_act(i1,i2);
			if (atr==D_IMD_PNAME && mc==D_IMD_PNAME) ac = 3;
			if (mc==59 && atr==60) {
DEBUGOUTL2(LVL_GXCOMPL+1,"cl_gx_compile: lvl_3kou1=%d lvl_3kou2=%d",lvl_3kou1,lvl_3kou2);
				if (lvl_3kou1 < lvl_3kou2) ac = 2;
			}
			if (i1==24 && i2==1 && attr0==29) ac=2;

DEBUGOUTL5(LVL_GXCOMPL+1,"cl_gx_compile:cmp_act: attr=%d, mc=%d, act i1=%d, i2=%d, ac=%d",
atr,mc,i1,i2,ac);

			if (ac<0) return ECL_SYNTAX_ERROR;
			else if (ac == 99) {
				if (cl_gx_expand(pGxObjExpand->ms_obj,iob+1,&obj) < 0) return ECL_MAX_OBJ_ERROR;
				obj[iob++]=ac;
				obj[iob]=0;
if (DEBUGOUTCHECK(LVL_GXCOMPL)) {
for (i=0;i<iob;i++) {
DEBUGOUTL2(LVL_GXCOMPL,"obj[%2d]=%d",i,obj[i]);
}
for (i=0;i<iob0;i++) {
DEBUGOUTL2(LVL_GXCOMPL,"obj0[%2d]=0x%08x",i,obj0[i]);
DEBUGOUT_InfoParm(LVL_GXCOMPL+5,"",obj0[i],0,0);
}
for (i=0;i<ida;i++) {
DEBUGOUTL2(LVL_GXCOMPL,"da[%2d]=[%s]",i,da[i]);
}
}
				pGxObjExpand->nobj = (iob+1) & (~0x01);
				pGxObjExpand->nda = ida;
				pGxObjExpand->nobj0 = iob0;
				return optimize_flg;
			}
			else if (ac == 1) {
				if (cl_gx_expand(&ms_stk_str,ida,&stk_str) < 0) return ECL_MALLOC_ERROR;
				if (cl_gx_expand(pGxObjExpand->ms_obj,iob+1,&obj) < 0) return ECL_MAX_OBJ_ERROR;
				conv_flg = 1;
				p = "";
				if (atr<=3000 || atr>6000) {
					if (!(pInfoParmW=(tdtInfoParm *)cl_opt_malloc(im,sizeof(tdtInfoParm))))
						return ECL_MALLOC_ERROR;
					if (atr <= 3000) {	/* �֐��� */
						idai = atr - 2001;
						p = da[idai];
						cl_set_parm_char(pInfoParmW,p,strlen(p));
						pInfoParmW->pi_id = D_DATA_ID_FUNCTION;
						pInfoParmW->pi_pos = tInfoParm.pi_pos;
						pInfoParmW->pi_paux = tInfoParm.pi_paux;
						pInfoParmW->pi_alen = tInfoParm.pi_alen;
						pInfoParmW->pi_aux[1] |= D_AUX1_PROTECTED;
						if (opt_scope) {
							pInfoParmW->pi_aux[1] |= cl_gx_get_aux1_from_opt(opt_scope);
							opt_scope = 0;
						}

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_gx_compile:FUNCTION ",pInfoParmW,0,0);

							if (!(pp=cl_tmp_const_malloc(strlen(p)+1))) return ECL_MALLOC_ERROR;
							stk_str[sp] = pp;
							strcpy(pp,p);

DEBUGOUTL2(LVL_GXCOMPL+1,"cl_gx_compile:set stk_str[%d]=%s",sp,pp);

						if (cl_get_optimize_kind(p)) {
							optimize_flg = C_DO_OPTIMIZE;
						}
					}
					else if (atr <= 7000) {	/* CAST�� */
						idai = atr - 6001;
						cl_set_parm_char(pInfoParmW,da[idai],strlen(da[idai]));
						pInfoParmW->pi_id = D_DATA_ID_FUNCTION;
						pInfoParmW->pi_aux[0] = FUNCCAST;
						pInfoParmW->pi_aux[1] |= D_AUX1_PROTECTED;

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_gx_compile:CAST ",pInfoParmW,0,0);

					}
					else if (atr <= 9000) {	/* CLASS�� */
						if (atr <= 8000) idai = atr - 7001;
						else idai = atr - 8001;
						cl_set_parm_char(pInfoParmW,da[idai],strlen(da[idai]));
						pInfoParmW->pi_id = tInfoParm.pi_id;
						pInfoParmW->pi_pos = tInfoParm.pi_pos;
						pInfoParmW->pi_aux[1] |= D_AUX1_PROTECTED;

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_gx_compile:CLASS ",pInfoParmW,0,0);

					}
				}
				else {
					if (atr <= 4000) {	/* Variable */
						idai = atr - 3001;
						p = da[idai];
/*
printf("cl_gx_compile_gp_opt: opt_scope=%08x p=[%s]\n",opt_scope,p);
*/
						if (opt_scope) {
							pp = cl_get_scope_from_opt(opt_scope);
							if (!*pp) pp = D_STR_MARK_LOCAL;
							strnzcpy(buf,p,sizeof(buf)-1);
							strcpy(p,pp);
							strcat(p,buf);
							opt_scope = 0;
						}
						/* ��ʕϐ��́A�ϊ����ăA�h���X��ۑ����Ă����A���s���ɂ́A
						   ������g���悤�ɂ���B(���̍s���R�����g�ɂ���) */
						/* �h�b�g�̉E���������A���s���ɖ���ϊ�����悤�ɂ���B
						   ���s�X�s�[�h�͗����� */
					/*	if (attr0 != 29) conv_flg = 0;	*/
					}
					else if (atr <= 5000) {	/* System Var. */
						idai = atr - 4001;
						conv_flg = 0;
					}
					else {
						idai = atr - 5001;	/* CONSTANT */
					}
/*
printf("cl_gx_compile_gp_opt: conv_flg=%d attr0=%d atr=%d idai=%d\n",conv_flg,attr0,atr,idai);
*/
					if (conv_flg) {
						p = da[idai];
						/* 2021.2.3 */
						if (atr <= 4000) {
							c = *p;
							cw = *(p+1);
							if (attr0 == 29) {
								/* �h�b�g�̉E������ʕϐ��̂Ƃ��́A�ϊ������A�ϐ����̕����f�[�^�Ƃ��Ă��� */
								/* 2021.7.20 */
								cl_set_parm_char(&tInfoParm,p,strlen(p));
								tInfoParm.pi_alen = D_AULN_NAME_DATA;
							}
							else if ((attr0==D_IMD_PNAME || attr1==D_IMD_NAMED)
							     && atr<=4000 && !(c=='$' || c=='%' || c=='#')) {
								/* 2021.7.20 */
								cl_set_parm_char(&tInfoParm,p,strlen(p));
								tInfoParm.pi_id = D_DATA_ID_PNAME;
							}
							/* 2021.7.18 *//* ��ʕϐ��́A���s���ɖ���ϊ�����悤�ɂ��Aclear_var_obj�����~�߂� */
							else if ((c=='$' || c=='%' || c=='#') &&
							         (cw=='$' || cw=='%' || cw=='#')) conv_flg = 0;	/* ����]������ */
							/* 2022.10.18 */
							else if (/*c!='<' && */c=='$' && cw=='_') conv_flg = 0;
						}
						/* 2021.7.20 */
						if (conv_flg) {
							if (!(pInfoParmW=(tdtInfoParm *)cl_opt_malloc(im,sizeof(tdtInfoParm))))
								return ECL_MALLOC_ERROR;
							if (atr <= 4000)
								*pInfoParmW = tInfoParm;
							else {
								if (rc=_conv_arg_opt(p,pInfoParmW,opt1|opt_scope)) return rc;
								if (atr > 5000) {
									if (rc=_rep_data_memory(im,pInfoParmW)) return rc;
								}
							}

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_gx_compile:Conv da=[%s]",pInfoParmW,p,0);

						}
					}
				}
				if (conv_flg) {
					obj[iob++]=91;
					obj[iob++]=idai;
					if (cl_gx_expand(pGxObjExpand->ms_obj0,iob0,&obj0) < 0) return ECL_MAX_OBJ_ERROR;
					obj0[idai]=pInfoParmW;
					iob0 = ida;
#if 1	/* 2020.10.08 */
				  if (atr>=5001 && atr<=6000) {
					if (*p==M_QUOTE3) {
						word_len = strlen(p);
						word_len -= 2;
						if (word_len>=0) {
							if (!(pp=cl_opt_malloc(im,word_len+2))) return ECL_MALLOC_ERROR;
							memzcpy(pp,p+1,word_len);
							p = pp + word_len - 1;
							if (*p != M_KUGIRI) {
								p++;
								*(p++) = M_KUGIRI;
								*p = '\0';
								word_len++;
							}
/*
printf("cl_gx_compile: word_len=%d pp=[%s]\n",word_len,pp);
*/
							cl_set_parm_char(pInfoParmW,pp,word_len);
							pInfoParmW->pi_aux[1] = D_AUX1_PROTECTED;
						}
						if (cl_gx_expand(pGxObjExpand->ms_obj,iob+1,&obj) < 0) return ECL_MAX_OBJ_ERROR;
						obj[iob++]=-50;
					}
				  }
#endif
				}
				else {
					obj[iob++]=92;
					obj[iob++]=idai;
				}
				opt_scope = 0;
DEBUGOUTL3(LVL_GXCOMPL+1,"cl_gx_compile:PUSH:    sp=%d, opr=[%s] iob=%d",sp,word,iob);
			}
			else if (ac == 2) {
				if (cl_gx_expand(&ms_stack,sp,&stack) < 0) return -4;
				/* 2023.8.8 */
				stack[sp++]=atr_AO;
				if (atr==1 || atr==5 || atr==3 || atr==6 || atr==7) {	/* ( func( [ { */
					if (cl_gx_expand(pGxObjExpand->ms_obj,iob+1,&obj) < 0) return ECL_MAX_OBJ_ERROR;
					obj[iob++]=91;
					obj[iob++]=ida;
					if (atr==1) {
						fai = fa[0];
						pInfoParmW = &tInfoParmK;
					}
					else if (atr==5) {
						fai = fa[0];
						pInfoParmW = &tInfoParmF;
					}
					else if (atr==3 || atr==6) {
						fai = fa[1];
						pInfoParmW = &tInfoParmA;
					}
					else {
						fai = fa[2];
						pInfoParmW = &tInfoParmL;
					}
					if (cl_gx_expand(pGxObjExpand->ms_obj0,iob0,&obj0) < 0) return ECL_MAX_OBJ_ERROR;
					if (cl_gx_expand(pGxObjExpand->ms_da,ida,&da) < 0) return ECL_MAX_DA_ERROR;
					da[ida] = fai;
					obj0[ida++]=pInfoParmW;
					iob0 = ida;
#if 1	/* 2022.6.7 */
					if (atr==5) {
						p = stk_str[sp-1];
DEBUGOUTL4(LVL_GXCOMPL+1,"cl_gx_compile: ac=%d atr=%d sp-1=%d p=[%s]",ac,atr,sp-1,p);
						if (p) {
							kind = cl_get_optimize_kind(p);
							if (kind >= 6) {
								if (cl_gx_expand(pGxObjExpand->ms_obj,iob+1,&obj) < 0) return ECL_MAX_OBJ_ERROR;
								obj[iob++]=0;
								da[ida] = "0";
								obj[iob++]=92;
								obj[iob++]=ida;
								if (!(pInfoParmW=(tdtInfoParm *)cl_opt_malloc(im,sizeof(tdtInfoParm))))
									return ECL_MALLOC_ERROR;
								cl_set_parm_bin(pInfoParmW,0);
								obj0[ida++]=pInfoParmW;
								iob0 = ida;
							}
						}
					}
#endif
				}
				else if (atr == 59) {
					if (cl_gx_expand(pGxObjExpand->ms_obj,iob+1,&obj) < 0) return ECL_MAX_OBJ_ERROR;
					obj[iob++] = atr;
					obj[iob++] = 0;
					sta_goto1[ista_goto1++] = iob;
DEBUGOUTL2(LVL_GXCOMPL+1,"cl_gx_compile:Push goto1: iob=%d ista_goto1=%d",iob,ista_goto1);
					obj[iob++] = 0;
					lvl_3kou1++;
				}
				if (atr==1 || atr==5 || atr==3 || atr==6 || atr==7) {	/* ( func( [ { */
					atrn = cmppeekwnsl(line,line_len,pssp,iOpt);
					if (atrn == 98) {	/* , */
						/* ",,"���ň������ȗ����ꂽ�ꍇ�́ANULL��}������ */
						if (rc=_set_null_parm(im,pGxObjExpand,&iob,&iob0,&ida)) return rc;
						cl_gx_expand(pGxObjExpand->ms_obj,-1,&obj);
						cl_gx_expand(pGxObjExpand->ms_obj0,-1,&obj0);
						cl_gx_expand(pGxObjExpand->ms_da,-1,&da);

DEBUGOUTL4(LVL_GXCOMPL+1,"cl_gx_compile:         iob=%d atr=%d atrn=%d ida=%d func(, or [,",
iob,atr,atrn,ida);

					}
				}
			}
			else if (ac == 3) {
				if (sp < 1) return ECL_SYNTAX_ERROR;
				sp--;
				if (mc == 60) {	/* : */
					if (ista_goto1==0 || ista_goto1!=ista_goto2) {
						ERROROUT2(FORMAT(178),name,pssp->sp);
						return ECL_SYNTAX_ERROR;
					}
					ista_goto1--;
					ista_goto2--;
					iobj_goto2 = sta_goto2[ista_goto2];
DEBUGOUTL2(LVL_GXCOMPL+1,"cl_gx_compile:Pop goto2: iobj_goto2=%d ista_goto2=%d",iobj_goto2,ista_goto2);
					obj[iobj_goto2] = iob - iobj_goto2;
					lvl_3kou2--;
				}
				else if (mc == 59) {	/* ? */
					if (cl_gx_expand(pGxObjExpand->ms_obj,iob,&obj) < 0) return ECL_MAX_OBJ_ERROR;
					obj[iob++] = 93;	/* GOTO */
					obj[iob] = 0;
					ista_goto2 = ista_goto1;
					sta_goto2[ista_goto2-1] = iob;
DEBUGOUTL2(LVL_GXCOMPL+1,"cl_gx_compile:Push goto2: iob=%d ista_goto2=%d",iob,ista_goto2);
					iob++;
					iobj_goto1 = sta_goto1[ista_goto1-1];
DEBUGOUTL2(LVL_GXCOMPL+1,"cl_gx_compile:Peek goto1: iobj_goto1=%d ista_goto1=%d",iobj_goto1,ista_goto1);
					obj[iobj_goto1] = iob - iobj_goto1;
					lvl_3kou1--;
				}
				else {
					if (cl_gx_expand(pGxObjExpand->ms_obj,iob,&obj) < 0) return ECL_MAX_OBJ_ERROR;
					/* 2023.8.8 */
					obj[iob++]=stack[sp] & 0xffff;

DEBUGOUTL3(LVL_GXCOMPL+1,"cl_gx_compile:         sp=%d, opr=%s iob=%d",sp,pssp->wd,iob);

					if (mc==20 && !stricmp(cast0,"FUNC")) attr0 = 2001;
					if (mc>=14 && mc<=17) pGxObjExpand->index0 |= 0x02;
					if (mc == -30) pGxObjExpand->index0 |= 0x04;
				}
				continue;
			}
			else if (ac == 4) {	/* ( and ) or { and } */
				sp--;
				if (mc==1 || mc==5 || mc==7) {	/* �֐� */
					if (cl_gx_expand(pGxObjExpand->ms_obj,iob,&obj) < 0) return ECL_MAX_OBJ_ERROR;
					obj[iob++]=mc;
					if (mc == 1) {
						if (attr0 == 1) atr = 5999;	/* NULL */
					/*	else atr = attr0;	*/
						else atr = 3999;	/* �� */
						pGxObjExpand->index0 |= 0x01;
					}
					else atr = 2999;	/* �֐��l */
				}
				else if (atr==20 || mc==10) {	/* CAST */
					if (cl_gx_expand(&ms_stack,sp,&stack) < 0) return -4;
					atr = 20;
					stack[sp++]=atr;
				}
				else if (attr0 == 3) atr = 5999;	/* NULL */
				else atr = attr0;
DEBUGOUTL3(LVL_GXCOMPL+1,"cl_gx_compile:         sp=%d, opr=%s iob=%d",sp,word,iob);
			}
			else if (ac == 5) {	/* [ and ] �z�� or �f�[�^���ю� */
				sp--;
				if (cl_gx_expand(pGxObjExpand->ms_obj,iob,&obj) < 0) return ECL_MAX_OBJ_ERROR;
				obj[iob++]=mc;
DEBUGOUTL3(LVL_GXCOMPL+1,"cl_gx_compile: sp=%d, opr=%s iob=%d",sp,word,iob);
				if (mc == 3) {
					if (attr0 == 3) atr = 5999;	/* NULL */
					else atr = attr0;
					pGxObjExpand->index0 |= 0x01;
				}
				else atr = 2998;	/* �z��l */
			}
			else if (ac == 6) {
				p = stk_str[sp-1];
DEBUGOUTL2(LVL_GXCOMPL+1,"cl_gx_compile:get stk_str[%d]=%s",sp-1,p);
			/*	if (!p) p = "+";	*/
			  if (p) {
				kind = cl_get_optimize_kind(p);
				if (kind>=1 && kind<=5) {
					if (cl_gx_expand(pGxObjExpand->ms_obj,iob+1,&obj) < 0) return ECL_MAX_OBJ_ERROR;
					obj[iob++]=98;
					obj[iob++]=0;
				}
				else if (kind >= 6) {
					if (cl_gx_expand(pGxObjExpand->ms_obj,iob+2,&obj) < 0) return ECL_MAX_OBJ_ERROR;
					obj[iob++]=98;
					obj[iob++]=0;
					obj[iob++]=0;
				}
			  }
				atrn = cmppeekwnsl(line,line_len,pssp,iOpt);
				if (atrn==98 || atrn==2 || atrn==4 || atrn==8) {
					/* ",,"���ň������ȗ����ꂽ�ꍇ�́ANULL��}������ */
					if (rc=_set_null_parm(im,pGxObjExpand,&iob,&iob0,&ida)) return rc;
					cl_gx_expand(pGxObjExpand->ms_obj,-1,&obj);
					cl_gx_expand(pGxObjExpand->ms_obj0,-1,&obj0);
					cl_gx_expand(pGxObjExpand->ms_da,-1,&da);

DEBUGOUTL4(LVL_GXCOMPL+1,"cl_gx_compile:         iob=%d atr=%d atrn=%d ida=%d func(, or [,",
iob,atr,atrn,ida);

				}
			}
			else if (ac == 0) {
				if ((iOpt & D_GX_OPT_PARMINFO2) && atr==98 && (attr0==0 || attr0==98)) {
					if (rc=_set_null_parm(im,pGxObjExpand,&iob,&iob0,&ida)) return rc;
					cl_gx_expand(pGxObjExpand->ms_obj,-1,&obj);
					cl_gx_expand(pGxObjExpand->ms_obj0,-1,&obj0);
					cl_gx_expand(pGxObjExpand->ms_da,-1,&da);

DEBUGOUTL4(LVL_GXCOMPL+1,"ccl_gx_compile:         iob=%d atr=%d atrn=%d ida=%d ,,",
iob,atr,atrn,ida);

				}
			}
			else {
				return -6;
			}
			break;
		}
	}
}

/****************************************/
/*										*/
/****************************************/
int cl_gp_gwse(gwprm,ssp,sep,opt)
GWPRM_S *gwprm;
SSPL_S *ssp;
char *sep;
int opt;
{
	int len,line_len;
	char *line;
	parmList *pparmList;

	if (!gwprm || !ssp) return -1;
/*
DEBUGOUTL3(195,"cl_gp_gwse: nparam=%d iparam=%d sp=%d",
gwprm->nparam,gwprm->iparam,ssp->sp);
*/
	if (gwprm->iparam < 0)
		return akxtgwnsl(gwprm->line,gwprm->line_len,ssp,sep,opt);
	else if (gwprm->iparam >= gwprm->nparam) return 0;
	else if (!(pparmList = gwprm->parmLp[gwprm->iparam])) return -2;
	line_len = pparmList->prmlen;
	if (!(line = pparmList->prp)) return -3;
/*
DEBUGOUTL1(195,"cl_gp_gwse: line=[%s]",line);
*/
	while ((len=akxtgwnsl(line,line_len,ssp,sep,opt)) <= 0) {
		if (ssp->wdmax>0 && ssp->attr[1]) return -4;
/*
printf("cl_gp_gwse:i=%d\n",gwprm->iparam);
*/
DEBUGOUTL1(195,"cl_gp_gwse:i=%d",gwprm->iparam);
		if (++gwprm->iparam >= gwprm->nparam) return 0;
		if (!(pparmList = gwprm->parmLp[gwprm->iparam])) return -5;
		ssp->sp = 0;
		line_len = pparmList->prmlen;
		if (!(line = pparmList->prp)) return -6;
DEBUGOUTL1(195,"cl_gp_gwse: line=[%s]",line);
	}
/*	if (len == -1) len = 0;	*/
/*
printf("cl_gp_gwse:i=%d sp=%d wd=%s\n",gwprm->iparam,ssp->sp,ssp->wd);
*/
DEBUGOUTL3(195,"cl_gp_gwse: i=%d sp=%d wd=[%s]",gwprm->iparam,ssp->sp,ssp->wd);
	gwprm->line = line;
	gwprm->line_len = line_len;
	return len;
}

/****************************************/
/*										*/
/****************************************/
int cmppeekwnsl(line,line_len,ssp,ex_opt)
char *line;
int  line_len,ex_opt;
SSPL_S *ssp;
{
	int sp,ret,attr0;

	attr0 = ssp->attr[1];	/* add 2023.05.27 */
	sp = ssp->sp;
	ret = cmpgwnsl(line,line_len,ssp,ex_opt);
	ssp->attr[1] = attr0;	/* add 2023.05.27 */
	ssp->sp = sp;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cmp_peekwd(gwprm,ssp,ex_opt)
GWPRM_S *gwprm;
SSPL_S  *ssp;
int ex_opt;
{
	GWPRM_S qgwprm;
	SSPL_S  qssp;
	parmList *pparmList;
	char *line;

	if (!gwprm || !ssp) return -1;

	memcpy(&qgwprm,gwprm,sizeof(GWPRM_S));
	memcpy(&qssp,ssp,sizeof(SSPL_S));
	return cmp_gtwd(&qgwprm,&qssp,ex_opt);
}

/****************************************/
/*										*/
/****************************************/
int cmpgtwdx(line,line_len,ssp,ex_opt)
char *line;
int  line_len,ex_opt;
SSPL_S *ssp;
{
	SSPL_S  qssp;
	char *wd0,c,c1,wrk_sep[32];
	int  len0,len,i,attr0,gw_opt;

	strcpy(wrk_sep,cmp_sep3);
	if (!(ex_opt & D_GX_OPT_PROC_NAME)) strcat(wrk_sep,"-");
	gw_opt = 0x845;
	attr0 = ssp->attr[1];
	if ((len=akxtgwnsl(line,line_len,ssp,wrk_sep,gw_opt)) <= 0) {
		if (len == -1) len = 0;
		return len;
	}
	if ((i=ssp->attr[0]) > 10) {
		if (*ssp->wd=='.') {
/*
printf("cmpgtwdx: attr0=%02x c=[%c]\n",attr0,line[ssp->sp]);
*/
DEBUGOUTL3(152,"cmpgtwdx: attr0=%02x c=[%c] ssp->sp=%d",attr0,line[ssp->sp],ssp->sp);

			if ((c=line[ssp->sp])=='.') {
				strcpy(ssp->wd,"..");
				ssp->sp++;
				len = 2;
/*
printf("cmpgtwdx: wd=%s\n",ssp->wd);
*/
			}
			/* ���O���A�����萔 NAME ) ] } �̂Ƃ��́A�h�b�g���Z�q�ƌ��Ȃ�
			  (�����̂Ƃ��́A���ɁA���l�萔�ƂȂ��Ă��āA�����ɂ͗��Ȃ� */
			else if ((attr0>0 && attr0<=10) || attr0==0xa9 || attr0==0xdd || attr0==0xfd) ;
			else if (c>='0' && c<='9') {
				qssp.wd = ssp->wd;
				len0 = len;
				ssp->wd += len;
				len = akxtgwnsl(line,line_len,ssp,wrk_sep,gw_opt);
				ssp->wd = qssp.wd;
				if (len > 0) len0 += len;
				len = len0;
			}
		}
		return len;
	}
	else if (i != 1) return len;
	else if ((c=*ssp->wd)<'0' || c>'9') return len;
	memcpy(&qssp,ssp,sizeof(SSPL_S));
	len0 = len;
	qssp.wd += len;
	len = akxtgwnsl(line,line_len,&qssp,wrk_sep,gw_opt);
	if (len>0 && *qssp.wd=='.') {
		if ((c=line[qssp.sp]) == '.') {
			if (ssp->wdmax) ssp->wd[len0] = '\0';
			return len0;
		}
		else if ((c>='0' && c<='9') ||
		         (strchr("efdEFD",c) &&
				  (((c1=line[qssp.sp+1])>='0' && c1<='9') || c1=='-' || c1=='+'))) {	/* 2023.8.7 add '-','+' */
			qssp.wd++;
			len0++;
			len = akxtgwnsl(line,line_len,&qssp,wrk_sep,gw_opt);
			ssp->sp = qssp.sp;
			if (len > 0) len0 += len;
			return len0;
		}
		else if (strchr(cmp_sep,c)) {
			len0++;
			ssp->sp = qssp.sp;
		}
	}
	if (ssp->wdmax) ssp->wd[len0] = '\0';
	return len0;
}

/****************************************/
/*										*/
/****************************************/
static int _chk_point(line,ssp,len0)
char *line;
SSPL_S *ssp;
int len0;
{
	int k,len=len0;
	char *spwd;

	spwd = ssp->wd;
	if ((k=akxnskipto(spwd,len,".")) < len) {
		ssp->sp -= len-k;
		while (line[ssp->sp] != '.') ssp->sp--;
		len = k;
		if (ssp->wdmax) *(spwd+len) = '\0';
	}
	return len;
}

/****************************************/
/*										*/
/****************************************/
static int _chk_number(line,line_len,ssp,len0,cmp_sep)
char *line;
int  line_len;
SSPL_S *ssp;
int len0;
char *cmp_sep;
{
	int k,len=len0;
	char *spwd,c,*p;

	spwd = ssp->wd;
	if ((c=toupper(spwd[len-1]))=='E' || c=='D') {
		if ((c=line[ssp->sp])=='+' || c=='-' ||
		    (c>='0' && c<='9')) {
			p = spwd + len;
			if (c=='+' || c=='-') {
				*p++ = c;
				ssp->sp++;
			}
			ssp->wd = p;
			akxtgwnsl(line,line_len,ssp,cmp_sep,0x5);
			ssp->wd = spwd;
/*
printf("cmp_gtwd: wd=[%s]\n",spwd);
*/
		}
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cmpgwnsl(line,line_len,ssp,ex_opt)
char *line;
int  line_len,ex_opt;
SSPL_S *ssp;
{
	parmList  **prmp;
	int len,atr,i,k,kk;
	char wk[5],c,*p,*spwd;

	atr=0;
	if ((len=cmpgtwdx(line,line_len,ssp,ex_opt)) <= 0) return len;
	ssp->attr[1] = ssp->attr[0];
	spwd = ssp->wd;

DEBUGOUTL4(152,"cmpgwnsl:cmpgtwdx len=%d, wd=[%s] ssp.sp=%d ssp.attr[0]=%d",
len,spwd,ssp->sp,ssp->attr[0]);

	if ((k=ssp->attr[0]) < 10) {
		if (k >= 5) atr = 5000;
		else {
			if ((c=*spwd)=='.' || (c>='0' && c<='9')) {
				atr=5000;
				_chk_number(line,line_len,ssp,len,cmp_sep);
			}
			else if (len >= 2 && len <= 3) {
#if 0	/* 2022.6.4 �֐��ł��g�p�ł���悤�ɂ��邽�߉��Z�q�Ƃ��Ȃ� */
				for(i=0,p=HK[0];p=HK[i];i++) {
					if (!akxstricmp2(spwd,len,p,strlen(p))) {
						if (i >= 6) atr=i+59;
						else atr=i+31;
						return atr;
					}
				}
#endif
				if (!akxstricmp2(spwd,len,"OR",2)) atr=61;	/*atr=52;*/
				else if (!akxstricmp2(spwd,len,"NEW",3)) atr=13;
			}
		}
		if (!atr) {
			i = cl_gx_chk_opt(spwd,ex_opt);
			if (i==IS || i==TO || i==COMP || i==FUNC_OPE) atr=61;
			else if (cl_gx_is_func_kubun(i)) atr=62;
			else if (i==FUNCCAST) atr = 10001;
			else if (i==STRING) {
				if (!akxstricmp2(spwd,len,"CONCAT",6) && line[ssp->sp]=='=') {
					atr = 88;
					ssp->sp++;
					strcpy(spwd,"&+=");
				}
				else atr = 61;
			}
			else if (i==SYSVAR) {
				atr = 4000;	/* System Var. */
			}
			else if (i==NAME_CONST) {
				len = _chk_point(line,ssp,len);
				atr = 10000;
			}
			else if (!akxstricmp2(spwd,len,"AND",3)) atr=61;	/*atr=51;*/
			else if (!akxstricmp2(spwd,len,"NOT",3)) {
				if (line[ssp->sp] == '=') {
					atr = 36;
					ssp->sp++;
					strcpy(spwd,"!=");
				}
				else atr=18;
			}
			else if (!akxstricmp2(spwd,len,"MOD",3) ||
			         !akxstrcmp2(spwd,len,"%",1)) {
				if (line[ssp->sp] == '=') {
					atr = 83;
					ssp->sp++;
					strcpy(spwd,"%=");
				}
				else if (!akxstricmp2(spwd,len,"MOD",3)) atr = 63;
				else atr = 23;
			}
			else if (!akxstricmp2(spwd,len,"ABS",3)) {
				atr = 28;
			}
			else {
				atr=5000;
				len = _chk_point(line,ssp,len);
				if (c=='%' || c=='#') atr = 3000;	/* Variable */
				else if (c=='$') {
					if (cl_chk_sysvar_name(spwd+1,len-1)) atr = 4000;	/* SYSVAR */
					else atr = 3000;	/* Variable */
				}
			}
		}
	}
	else if (len==2) atr=D_IMD_RANGE;	/* .. */
	else if ((c=spwd[0])==';') atr=99;
	else if (c=='.') atr=29;
	else if (c==',') atr=98;
	else if (c=='(') atr=1;
	else if (c==')') atr=2;
	else if (c=='[') atr=3;
	else if (c==']') atr=4;
	else if (c=='{') atr=7;
	else if (c=='}') atr=8;
	else {
		wk[0]=c;
		wk[1]=line[ssp->sp];
		wk[2]='\0';
		for(i=0,p=hk[0];p=hk[i];i++) {
			if (!strcmp(wk,p)) {
				if (i<10) {
					atr=(i/2)+33;
					if (atr==37) atr=36;
					else if (atr==33 || atr==35) break;	/* <=, == */
					ssp->sp++;
					strcpy(spwd,wk);
				}
				else {
					atr = i + 21;	/* <, > */
/*
printf("cmp_gtwd: hk: wk=[%s] i=%d atr=%d\n",wk,i,atr);
*/
				}
				return atr;
			}
		}
		if (!strcmp(wk,"<<")) atr=26;
		else if (!strcmp(wk,">>")) atr=27;
		else if (!strcmp(wk,"&+")) atr=61;
		else if (!strcmp(wk,"|+")) atr=61;
		if (atr) {
			k = ssp->sp + 1;
/*
printf("cmp_gtwd: line_len=%d k=%d\n",line_len,k);
*/
			if (k<line_len) {
				c = line[k];
				if (atr==33) {
					if  (c=='=') {
						atr = D_IMD_PNAME;
						strcpy(&wk[2],"=");
						ssp->sp++;
					}
				}
				else if (atr==35) {
					if  (c=='>') {
						atr = D_IMD_NAMED;
						strcpy(&wk[2],">");
						ssp->sp++;
					}
				}
				else if (c=='=') {
					if (atr==61) {
						atr = 88;
						strcpy(wk,"&+=");
					}
					else {
						atr += 60;
						strcpy(&wk[2],"=");
					}
					ssp->sp++;
				}
				else if (atr==27) {
					if  (c=='>') {
						atr = 48;
						strcpy(&wk[2],">");
						ssp->sp++;
						k = ssp->sp + 1;
						if (k<line_len) {
							c = line[k];
							if (c == '=') {	/* >>>= */
								atr = 89;
								strcpy(&wk[3],"=");
								ssp->sp++;
							}
						}
					}
				}
			}
			ssp->sp++;
			strcpy(spwd,wk);
/*
printf("cmp_gtwd: wk=[%s]\n",wk);
*/
			return atr;
		}
		for(i=0,p=ex[i];p=ex[i];i++) {
			if (!strcmp(wk,p)) {
				atr=i+71;
				ssp->sp++;
				strcpy(spwd,wk);
				return atr;
			}
		}
		if (!strcmp(wk,"++")) atr=14;
		else if (!strcmp(wk,"--")) atr=15;
		else if (!strcmp(wk,"||")) atr=52;
		else if (!strcmp(wk,"&&")) atr=51;
		else if (!strcmp(wk,"!!")) atr=16;
		else if (!strcmp(wk,"~~")) atr=17;
		else if (!strcmp(wk,"**")) atr=30;
		if (atr) {
			ssp->sp++;
			strcpy(spwd,wk);
		}
		else if (c=='*') atr=21;
		else if (c=='/') atr=22;
		else if (c=='+') atr=24;
		else if (c=='-') atr=25;
		else if (c=='=') atr=90;
		else if (c=='!') atr=18;
		else if (c=='~') atr=19;
		else if (c=='>') atr=32;
		/* 2021.12.29 */
		else if (c=='<') {
			atr=31;
			k = ssp->sp;
			if (k+1 < line_len) {
				if (c=='<' && line[k+1]=='>') {
					wk[0]=c;
					wk[1]=line[k];
					wk[2]=line[k+1];
					wk[3]='\0';
					strcpy(spwd,wk);
					ssp->sp = k + 2;
					atr = 10000;
/*
printf("cmp_gtwd: wk=[%s] ssp->sp=%d line[ssp->sp]=[%c]\n",wk,ssp->sp,line[ssp->sp]);
*/
				}
			}
		}
		else if (c=='&') atr=41;
		else if (c=='^') atr=42;
		else if (c=='|') atr=43;
		else if (c=='?') atr=59;
		else if (c==':') atr=60;
		else atr = -1;
	}
	return atr;
}

/****************************************/
/*										*/
/****************************************/
int cmp_gtwd(gwprm,ssp,ex_opt)
GWPRM_S *gwprm;
SSPL_S *ssp;
int ex_opt;
{
	return cmpgwnsl(gwprm->line,gwprm->line_len,ssp,ex_opt);
}

/****************************************/
/*										*/
/****************************************/
int cmp_mkix(atr)
int atr;
{
	int atx,ix;

	if ((atx=atr)<0) {
		ix=5;					/*  */
	}
	else if (atx<=40) {
		if (atx<=20) {
			if      (atx<=4)  ix=atx;	/* ( ) [ ] */
			else if (atx<=5)  ix=1;		/* Function( */
			else if (atx<=6)  ix=3;		/* �z��[ */
			else if (atx<=7)  ix=22;	/* { */
			else if (atx<=8)  ix=23;	/* } */
			else if (atx<=10) ix=1;		/* Cast( */
			else if (atx<=19) ix=5;		/* �P�� ++ -- */
			else ix=6;		/* (CAST) */
		}
		else {
			if      (atx<=23) ix=7;		/* * / % */
			else if (atx<=25) ix=8;		/* + - */
			else if (atx<=27) ix=9;		/* << >> */
			else if (atx<=29) ix=24;	/* .name */
			else if (atx<=30) ix=26;	/* ** */
			else if (atx<=34) ix=11;	/* < > <= >= */
			else ix=12;	/* == != LIKE */
		}
	}
	else {
		if (atx<=60) {
			if      (atx<=41) ix=13;	/* & */
			else if (atx<=42) ix=14;	/* ^ */
			else if (atx<=48) ix=9;		/* >>> */
			else if (atx<=50) ix=15;	/* | */
			else if (atx<=51) ix=16;	/* && */
			else if (atx<=52) ix=17;	/* || */
			else if (atx<=59) ix=18;	/* ? */
			else ix=19;	/* : */
		}
		else {
			if      (atx<=61) ix=10;	/* CONCAT */
			else if (atx<=70) ix=11;	/* IEQ NEQ */
			else if (atx<=90) ix=20;	/* &= ... = */
			else if (atx<=D_IMD_RANGE) ix=25;	/* .. */
			else if (atx<=D_IMD_NAMED) ix=27;	/* ==> */
			else if (atx<=100) ix=21;	/* , */
			else if (atx<=1000) ix=-1;	/* error */
			else if (atx<=2000) ix=10;	/* CONCAT */
			else ix=28;
		}
	}
	return ix;
}

/****************************************/
/*										*/
/****************************************/
int cmp_act(i1,i2)
int i1,i2;
{
	if (i1<0 || i2<0) return -1;
	else return act[i1][i2];
}

/****************************************/
/*										*/
/****************************************/
static int _match(name_list,name)
char *name_list[],*name;
{
	char **nl,*p;
	int i;
/*
printf("_match: name=[%s]\n",name);
*/
	nl = name_list;
	for (i=1;p=*nl;i++,nl++) {
/*
printf("_match: i=%d p=[%s]\n",i,p);
*/
		if(!stricmp(p,name)) return i;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_is_operator(pOperator,kubun)
char *pOperator;
int  kubun;
{
	int rc,len;
	char c,*p=pOperator;

	rc = 0;
	switch (kubun) {
		case MATH:
			if (_match(math,p)) rc = kubun;
			break;
		case COMP:
			if (_match(hk,p) || _match(HK,p)) rc = kubun;
			break;
		case LOGICAL:
			if (_match(logical,p)) rc = kubun;
			break;
		case FUNCCAST:
			if (_match(cast,p)) rc = kubun;
			else {
#if 1	/* 2025.11.24 */
				len = cl_mod_cast_name(&p,strlen(p));
				if (cl_get_name_attr(p,len,0x01,0x20)) rc = kubun;
#else
				if ((c=*p)=='C' || c=='c') {
					if ((c=*(p+1))!='H' && c!='h') {
						p++;
#if 1	/* 2025.11.24 */
						if (!stricmp(p,"Str")) {
							p = "String";
						}
#endif
					}
				}
				if (cl_get_name_attr(p,strlen(p),0x01,0x20)) rc = kubun;
#endif
			}
			break;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_is_separator(c)
char c;
{
	if (strchr(cmp_sep2,c)) return 1;
	else return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_is_func_kubun(i)
int i;
{
	if (i==FUNCMATH || i==FUNCTION || i==FUNCFILE || i==FUNCLOG || i==FUNC_OPE) return 1;
	else return 0;
}
