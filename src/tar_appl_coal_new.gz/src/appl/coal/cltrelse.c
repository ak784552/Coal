static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       long       col_mn_tr_else               */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Equote no shori.                          */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_else(y)
condList *y;
{
	static int able[]={C_IF,C_ELSEIF,C_IFP,C_ELSEZ,C_ELSEM};
	static int deny[]={C_ELSE,C_ELSEL};
	static int ablezm[]={C_IF,C_ELSEIF,C_IFP};
	static int denyz[]={C_ELSEZ};
	static int denym[]={C_ELSEM};
	char *p;
	int  rc,cnum,i;
	cmdInfo *cmd;
	Leaf *leaf;

	cmd = y->cmd;
	if (cmd->prmnum > 0) {
		p = cmd->prmp[0]->prp;
		cnum = cl_cmd_chk_cid(p);
		if (cnum == C_IF) {
			cmd->cid = C_ELSEIF;
			cmd->prmnum--;
			for (i=0;i<cmd->prmnum;i++)
				cmd->prmp[i]->prp = cmd->prmp[i+1]->prp;
			return col_mn_tr_else_if(y);
		}
		else {
			/* %s: �]���ȃp�����[�^[%s]������܂��B */
			ERROROUT2(FORMAT(43),"col_mn_tr_else",p);
			return ECL_TR_ELSE;
		}
	}
#if 1	/* 2026.11.7 */
	if (!(rc=cl_tr_end_node_check(y,deny,1,able,5))) {
		if (cl_search_node_deny(y,denyz,1,ablezm,3,NULL) > 0) {
			if (cl_search_node_deny(y,denym,1,ablezm,3,NULL) > 0) {
				ERROROUT2(FORMAT(636),"col_mn_tr_else","(W) ELSE");	/* %s: %s�͎w��ł��܂���B*/
			}
		}
		rc = cl_tr_else_nest_check(y);
	}
#else
	if (!(rc=cl_tr_end_node_check(y,deny,1,able,5))) rc = cl_tr_else_nest_check(y);
#endif
	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_default(y)
condList *y;
{
	static int able[]={C_SWITCH,C_CASE};
	static int deny[]={C_DEFAULT/*,C_SWITCH*/};
	int rc;

	return col_mn_tr_elseNode(y,deny,1,able,2);
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_finally(y)
condList *y;
{
	static int able[]={C_TRY,C_CATCH};
	static int deny[]={C_FINALLY/*,C_TRY*/};
	int  rc;

	return col_mn_tr_elseNode(y,deny,1,able,2);
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_else_nest_check(y)
condList *y;
{
	int  rc ,tree;

	tree = cl_nest_tag(y,2);
	if ( tree != -1 ) {
		rc=cl_change_tree(y,y->clstcb->nestLev2 );
/*
		if (rc) return (rc);
*/
		cl_search_nest(y,2);
	}
	else return ECL_TR_ELSE;

	return cl_make_push_leaf(y);
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_elseNode(y,deny,nd,able,na)
condList *y;
int deny[],nd;
int able[],na;
{
	int rc;

	if (!(rc=cl_tr_end_prmnum_check(y))) {
		if (!(rc=cl_tr_end_node_check(y,deny,nd,able,na))) rc = cl_tr_else_nest_check(y);
	}
	return rc;
}
