static char sccsid[]="%Z% %M% %I% %E% %U%";
/************************************************************************
*																		*
*	�����ړI�@�@�FIS  ���Z����											*
*																		*
*	�֐����@	�Fint cl_cmpt_is(pAns , pOprtr , nparm,ppParm)			*
*					(O)int		*pAns									*
*					(I)char  	*pOprtr									*
*					(I)int		nparm									*
*					(I)tdtInfoParm *pppParm[]							*
*																		*
*	�߂�l�@�@�@�FERROR									�@				*
*				  NORMAL												*
*																		*
*	�����T�v�@�@�F�@													*
*																		*
*************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable,*pCLprocTable;

/****************************************/
/*										*/
/****************************************/
int cl_str_width(p,len,code_type)
char *p;
int len,code_type;
{
	char *p1;
	int len1,m,n,w;

	p1 = p;
	len1 = len;
	n = 0;
	while (len1 > 0) {
		m = akxqmbsnelen(code_type,p1,len1);
		w = akxqmbsnwidth(code_type,p1,m);
		n += w;
		p1 += m;
		len1 -= m;
	}
	return n;
}

/****************************************/
/*										*/
/****************************************/
/* 2024.12.17 */
int cl_cmpt_is(pAns,nparm,ppParm)
long *pAns;
int nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm1;
	tdtInfoParm *pInfoParm2;
	int  rc,len1,len2,i,attr,code_type,n,alen,range8,f;
	long lVal;
	char *p1,*p2,c,w1[16],c2,id;
	ParList3 par3;
	qSubCommand *sc;

	*pAns = 0;
	rc = NORMAL;
	pInfoParm2 = ppParm[1];
	if (nparm > 2) {
		if (pInfoParm2->pi_id==' ' && pInfoParm2->pi_attr==DEF_ZOK_BINA) {
			pInfoParm2 = ppParm[2];
			if (nparm > 3) {
				if (pInfoParm2->pi_id==' ' && pInfoParm2->pi_attr==DEF_ZOK_BINA) {
					pInfoParm2 = ppParm[3];
				}
			}
		}
	}
	len2 = pInfoParm2->pi_dlen;
	p2   = pInfoParm2->pi_data;
	if (pInfoParm2->pi_attr != DEF_ZOK_CHAR /*|| len2==0*/) {
		/* cl_cmpt_is:�p�����[�^�Q�̌^�������Ă��܂���B */
		ERROROUT1(FORMAT(251),"cl_cmpt_is");
		return ECL_SCRIPT_ERROR;
	}
	pInfoParm1 = ppParm[0];
	attr = pInfoParm1->pi_attr;
	len1 = pInfoParm1->pi_dlen;
	p1   = pInfoParm1->pi_data;
	code_type = pInfoParm1->pi_code;
	c2 = toupper(*p2);
	n = strlen(D_STR_NAME_NULL);
	if (len2==n && !memicmp(p2,D_STR_NAME_NULL,n)) {
		*pAns = cl_is_null_value(pInfoParm1);
		return 0;
	}
	else if (cl_is_null_value(pInfoParm1) || cl_is_null_value(pInfoParm2)) {
		/* 2024.4.6 */
		return 0;
	}
	if (c2=='N' || c2=='D' || c2=='F') {
		if (attr==DEF_ZOK_BINA || attr==DEF_ZOK_FLOA || attr==DEF_ZOK_DECI) {
			if (attr == DEF_ZOK_BINA) lVal = 1;
			else if (attr == DEF_ZOK_FLOA) lVal = 2;
			else lVal = 3;
			*pAns = lVal;
			return 0;
		}
	}
	else if (c2=='X' && attr==DEF_ZOK_BULK) {
		*pAns = 1;
		return 0;
	}
	else if (c2=='T') {	/*** Type ***/
		len2--;
		if (len2 > 0) {
			p2++;
			c2 = *p2;
			f = 0;
			if (pInfoParm1->pi_scale & D_DATA_UNSIGNED) f |= DEF_ZOK_USMASK;
			if (pInfoParm1->pi_scale & D_DATA_IMAGE) f |= D_DATA_IMAGE<<8;
			if (pInfoParm1->pi_aux[0] & DEF_ZOK_DATA) f |= DEF_ZOK_DATA;
			alen = pInfoParm1->pi_alen;
			range8 = D_AULN_RANGE_DATA<<8;
			if (alen & D_AULN_RANGE_DATA) f |= range8;
			if (alen & D_AULN_RATIONAL) {
				f |= D_AULN_RATIONAL<<8;
				f &= ~range8;
			}
			if (alen & D_AULN_COMPLEX_DATA) {
				f |= D_GX_OPT_SET_COMPLEX;	/*D_AULN_COMPLEX_DATA<<8;*/
				f &= ~range8;
			}
			if (pInfoParm1->pi_aux[1] & D_AUX1_PROTECTED) f |= D_GX_OPT_SET_CONST;
			if (c2 == '+') attr |= f;
			else {
				attr = 0;
				if (sc=cl_get_name_attr(p2,len2,1,0x2010)) {
					if (f & sc->attr) attr = 1;
				}
			}
		}
		*pAns = attr;
		return 0;
	}
	else if (c2=='I') {	/*** DataID ***/
		id = pInfoParm1->pi_id;
		len2--;
		if (len2 > 0) {
			c2 = *(p2+1);
			if (id == c2) f = 1;
			else f = 0;
			*pAns = f;
		}
		else *pAns = (uchar)id;
		return 0;
	}

	/* �f�[�^�̓��e�𒲂ׂ�ꍇ */
	if (nparm > 2) {
		if ((rc=cl_get_str_pos(nparm,ppParm,0,&par3,NULL,"")) < 0) return rc;
		p1 = par3.par;
		len1 = par3.parlen;
	}
	switch (c2) {
		case 'L':	/*** Length ***/
				c2 = toupper(*(p2+1));
				if (attr == DEF_ZOK_DATE) len1 = D_LEN_DATE;
				else if (c2 == 'O') {
					len1 = islower(*p1);
				}
				/* 2021.7.12 */
				else if (pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX) {
				/*	c2 = toupper(*(p2+1));	*/
					if (c2 == 'W') len1 = cl_str_width(p1,len1,code_type);
					else if (c2 != 'B') len1 = akxqmlen_type(p1,len1,code_type);
				}
				*pAns = len1;
				break;
		case 'N':	/*** Numeric || Number ***/
		case 'D':	/*** Decimal ***/
		case 'F':	/*** FLOAT ***/
				if (len1>0) {
					if ((i=akxnskipin(p1,len1," \t")) < len1) {
						p1 += i;
						len1 = akxnrskipin(p1,len1-i," \t");
						if ((c=*p1)=='+' || c=='-') {
							p1++;
							len1--;
						}
						if ((i=cl_chk_digit_n(p1,len1)) >= 0) *pAns = i+1;
					}
				}
				break;
		case 'B':	/*** Blank ***/
		case 'S':	/*** Space ***/
				if (len1>0) {
					if (akxnskipin(p1,len1," \t") >= len1) *pAns = 1;
				}
				break;
		case 'X':	/*** hex ***/
				if (len1>0) {
					*pAns = 1;
					for (i=0;i<len1;i++) {
						if (((c=*p1++)==' ')||(c=='+')||(c=='-')||(c=='.')||
						    (c>='0'&&c<='9')||
						    (c>='A'&&c<='F')||(c>='a'&&c<='f'))
							;
						else {
							*pAns = 0;
							break;
						}
					}
				}
				break;
		case 'Z':	/*** Zenkaku ***/
		case 'H':	/*** Hankaku ***/
				i = akxqiskanji(p1);
				if (c2 == 'H') i = i ? 0 : 1;
				*pAns = i;
				break;
		case 'A':	/*** Ank ***/
				*pAns = akxqisank(*p1);
				break;
		case 'M':	/*** Moji byte ***/
				/* 2021.7.12 */
				i = akxqkanjilen2(p1,len1);
				*pAns = i;
				break;
		case 'W':	/*** Moji Display byte ***/
				*pAns = akxqkanjiw2(p1,len1);
				break;
		case 'C':	/*** Moji code ***/
				if (attr == DEF_ZOK_CHAR) {
					if (!(i = pInfoParm1->pi_code)) i = akxt_get_code_type();
				}
				else i = 0;
				*pAns = i;
				break;
		case 'U':	/*** Upper ***/
				*pAns = isupper(*p1);
				break;
		default:
			/* cl_cmpt_is:�p�����[�^�Q�Ɍ�肪����܂��B */
			ERROROUT(FORMAT(252));
			rc = ECL_SCRIPT_ERROR;
	}

	return rc;
}

/****************************************/
/*	opt = 0 : lenm						*/
/*	opt <>0 : lenw						*/
/****************************************/
int cl_lenmw(pAns,mflg,nparm,ppParm,opt)
long *pAns;
int  mflg,nparm,opt;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm1;
	int len1,attr,ret,code_type,alen;
	long lVal1;
	char *p,id;
	uchar aux0;

	pInfoParm1 = ppParm[0];
	if ((id=pInfoParm1->pi_id) == ' ') {
		len1 = pInfoParm1->pi_dlen;
		attr = pInfoParm1->pi_attr;
		code_type = pInfoParm1->pi_code;
		/* 2025.8.22 */
		if (pInfoParm1->pi_alen & D_AULN_RANGE_DATA) {
			aux0 = pInfoParm1->pi_aux[0];
			pInfoParm1->pi_aux[0] |= DEF_ZOK_DATA; 
			ret = cl_func_count(&len1,nparm,ppParm,-1);
			pInfoParm1->pi_aux[0] = aux0;
		}
		else if (attr == DEF_ZOK_CHAR) {
			if (mflg && nparm>=2) {
				if ((ret=cl_get_code_type(ppParm[1],&code_type,NULL)) < 0) return ret;
			}
			if (opt)
				len1 = cl_str_width(pInfoParm1->pi_data,len1,code_type);
			else if (mflg)
				len1 = akxqmlen_type(pInfoParm1->pi_data,len1,code_type);
		}
		else if (attr == DEF_ZOK_DATE) len1 = D_LEN_DATE;
		ret = 0;
	}
	/* 2025.8.22 */
	else if (id=='A' || id=='R' || id=='L' || id=='N') {
		ret = cl_func_count(&len1,nparm,ppParm,-1);
	}
	else len1 = sizeof(tdtInfoParm);
	*pAns = len1;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_lenm(pAns,mflg,nparm,ppParm)
long *pAns;
int  mflg,nparm;
tdtInfoParm *ppParm[];
{
	return cl_lenmw(pAns,mflg,nparm,ppParm,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_lenw(pAns,mflg,nparm,ppParm)
long *pAns;
int  mflg,nparm;
tdtInfoParm *ppParm[];
{
	return cl_lenmw(pAns,mflg,nparm,ppParm,1);
}

/****************************************/
/*	atr=DEF_ZOK_DECI�̂Ƃ�				*/
/*		|lCmp|>=RADIX(100)�̂Ƃ��́A	*/
/*		DEF_ZOK_FLOA�ɂ��Ĕ�r����		*/
/****************************************/
int cl_is_num_comp(atr,dat,lCmp,dCmp)
int atr;
char *dat;
long lCmp;
double dCmp;
{
	int rc,i,iCmp;
	long Value;
	double dValue;
	MPA *mpa,*mpa1;

	rc = 0;
	if (atr == DEF_ZOK_BINA) {
		memcpy(&Value,dat,sizeof(long));
		if (Value == lCmp) rc = 1;
	}
	else if (atr == DEF_ZOK_FLOA) {
		memcpy(&dValue,dat,sizeof(double));
		if (dValue == dCmp) rc = 1;
	}
	else if (atr == DEF_ZOK_DECI) {
		if ((iCmp=lCmp) >= RADIX) {
			dCmp = lCmp;
			return cl_is_num_comp(DEF_ZOK_FLOA,dat,lCmp,dCmp);
		}
		mpa = (MPA *)dat;
		if (iCmp) {
			mpa1 = m_get_i(iCmp);
			if (!m_cmp(mpa,mpa1)) rc = 1;
		}
		else if (mpa->zero) rc = 1;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _is_num_zero_one(atr,dat,iCmp)
int atr;
char *dat;
int iCmp;
{
	return cl_is_num_comp(atr,dat,(long)iCmp,(double)iCmp);
}

/****************************************/
/*										*/
/****************************************/
int cl_is_num_zero(atr,dat)
int atr;
char *dat;
{
	int rc;
	long Value;
	double dValue;
	MPA *mpa;
#if 1
	return _is_num_zero_one(atr,dat,0);
#else
	rc = 0;
	if (atr == DEF_ZOK_BINA) {
		memcpy(&Value,dat,sizeof(long));
		if (!Value) rc = 1;
	}
	else if (atr == DEF_ZOK_FLOA) {
		memcpy(&dValue,dat,sizeof(double));
		if (dValue == 0.0) rc = 1;
	}
	else if (atr == DEF_ZOK_DECI) {
		mpa = (MPA *)dat;
		if (mpa->zero) rc = 1;
	}
	return rc;
#endif
}

/****************************************/
/*										*/
/****************************************/
int cl_is_zero(pInfoParm)
tdtInfoParm *pInfoParm;
{
	int rc,iAttr[4],atr;
	long Valz[NMPA_LONG],*Val;
	MPA *mpa;

	rc = 0;
	if (pInfoParm->pi_attr == DEF_ZOK_CHAR) {
		Val = cl_get_tmpMPA(Valz);
		iAttr[0] = 0;
		if ((rc=cl_get_parm_mpa(pInfoParm,Val,"cl_is_zero:",iAttr)) >= 0) {
			atr = iAttr[0];
			/* 2025.1.24 */
			rc = cl_is_num_zero(atr,Val);
		}
	}
	else rc = !cl_is_true(pInfoParm);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_is_num_one(atr,dat)
int atr;
char *dat;
{
	int ret;
	long lVal;
	double dVal;
	MPA *mpa,*mpa1;
#if 1
	return _is_num_zero_one(atr,dat,1);
#else
	ret = 0;
	if (atr == DEF_ZOK_BINA) {
		memcpy(&lVal,dat,sizeof(long));
		if (lVal == 1) ret = 1;
	}
	else if (atr == DEF_ZOK_FLOA) {
		memcpy(&dVal,dat,sizeof(double));
		if (dVal == 1.0) ret = 1;
	}
	else if (atr == DEF_ZOK_DECI) {
		mpa = (MPA *)dat;
		mpa1 = m_get_i(1);
		if (!m_cmp(mpa,mpa1)) ret = 1;
	}
	return ret;
#endif
}

/****************************************/
/*										*/
/****************************************/
int cl_is_one(pInfoParm)
tdtInfoParm *pInfoParm;
{
	int rc,iAttr[4],atr;
	long Valz[NMPA_LONG],*Val,lValue;;
	double dValue;
	MPA *mpa;

	rc = 0;
	atr = pInfoParm->pi_attr;
	if (atr == DEF_ZOK_CHAR) {
		Val = cl_get_tmpMPA(Valz);
		iAttr[0] = 0;
		if ((rc=cl_get_parm_mpa(pInfoParm,Val,"cl_is_one:",iAttr)) >= 0) {
			atr = iAttr[0];
		}
	}
	else Val = (long *)pInfoParm->pi_data;
	rc = cl_is_num_one(atr,Val);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int _is_1(pInfoParm)
tdtInfoParm	*pInfoParm;
{
	int atr;
	char *dat;

	atr = pInfoParm->pi_attr;
	dat = pInfoParm->pi_data;
	return cl_is_num_one(atr,dat);
}

/****************************************/
/* ���� : pInfoParm : datatype�̔���Ώ�*/
/*		  opt       : ����t���O		*/
/*		opt		datatype				*/
/*		0x00		int,double,decimal	*/
/*		0x01	2	int					*/
/*		0x02	3	double				*/
/*		0x04	4	decimal				*/
/*		0x08	6	date				*/
/*		0x10	1	char				*/
/*		0x20	5	bulk				*/
/*		0x40	7	variant				*/
/*		0x100		datatype�ԋp�r�b�g	*/
/*		0x200		����Ȃ���datatype��Ԃ�*/
/* �ԋp : > 0 : opt�ɑΉ�����datatype�ł���	*/
/*				datatype�ɑΉ�����opt��Ԃ�	*/
/*				opt:0x100 ON�̂Ƃ��́Adatatype��Ԃ�*/
/*		  = 0 : opt�ɑΉ�����datatype�łȂ�	*/
/*		  < 0 : pInfoParm is NULL		*/
/****************************************/
int cl_is_num_info_opt(pInfoParm,opt)
tdtInfoParm	*pInfoParm;
int opt;
{
	static int atr_opt[]={0,0x10,0x01,0x02,0x04,0x20,0x08,0x40};
	int ret,atr;

	ret = 0;
	if (pInfoParm) {
		if (pInfoParm->pi_id == ' ') {
			atr = pInfoParm->pi_attr & 0x07;
			if (opt & 0x200) ret = atr;
			else {
				if (!opt) opt = 0x07;
				ret = atr_opt[atr] & opt;
				if (ret>0 && (opt & 0x100)) ret = atr;
			}
/*
printf("cl_is_num_info_opt: opt=%04x atr=%d ret=%02x\n",opt,atr,ret);
*/
		/*
			if (opt <= 7) {
				if (opt & 0x01) {
					if (atr == DEF_ZOK_BINA) ret = 1;
				}
				else if (opt & 0x02) {
					if (atr == DEF_ZOK_FLOA) ret = 2;
				}
				else if (opt & 0x04) {
					if (atr == DEF_ZOK_DECI) ret = 4;
				}
			}
			else if (opt & 0x10) {
				if (atr == DEF_ZOK_CHAR) ret = 16;
			}
		*/
		}
	}
	else ret = -1;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_is_num_info(pInfoParm)
tdtInfoParm	*pInfoParm;
{
	int ret,atr;

	return cl_is_num_info_opt(pInfoParm,0);
}
