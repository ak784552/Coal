static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_end_if              */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Equote no shori.                          */
/* --------------------------------------------- */
/*************************************************/
/* */
#include "colmn.h"          /* �\���̒�` */

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_end_if(y)
condList *y;
{
	static int able[]={C_IF,C_ELSEIF,C_ELSE,C_IFP,C_ELSEZ,C_ELSEM};
	static int deny[]={0};

	return col_mn_tr_end_node(y,deny,0,able,6);
}

/************************************************/
/*                                              */
/*     cl_if_close                              */
/*----------------------------------------------*/
/*                                              */
/*                                              */
/************************************************/
/* */
int cl_if_close(y)
condList *y;
{
	int rc = 0;
	CLNCB *p;

	p = y->clstcb;
	for (;;) {
		if (!p->nestLev2) break;
		if (p->nestLev2->cmd.cid == C_LOOP ) {
			rc = cl_nest_tag(y,2);
			if (rc != -1) {
				cl_change_tree(y,p->nestLev2);
				cl_search_nest(y,2);
/*
				ERROROUT(FORMAT(66));
*/
				rc = 10000;
			}
		}
		else break;
	}
	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_end_sw(y)
condList *y;
{
	static int able[]={C_SWITCH,C_CASE,C_DEFAULT};
	static int deny[]={C_SWITCH};

	return col_mn_tr_end_node(y,deny,0,able,3);
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_end_try(y)
condList *y;
{
	static int able[]={C_TRY,C_CATCH,C_FINALLY};
	static int deny[]={C_TRY};

	return col_mn_tr_end_node(y,deny,0,able,3);
}

/************************************************/
/*     cl_search_node_leaf                      */
/************************************************/
int cl_search_node_leaf(y,deny,nd,able,na,ppleaf,check)
condList *y;
int deny[],nd;
int able[],na;
Leaf  **ppleaf;
int check;
{
	Leaf *Dummy;
	CLNCB *clncb;
	int i,id,flag,able_id;
	char *p1,*p2;

	clncb = y->clstcb;
/*
if (Dummy = clncb->nestLev1) p1 = cl_gets_cmd_name(Dummy->cmd.cid);
else p1 = AKX_NULL_PRINT;
if (Dummy = clncb->nestLev2) p2 = cl_gets_cmd_name(Dummy->cmd.cid);
else p2 = AKX_NULL_PRINT;
printf("cl_search_node_leaf: nestLev1=%08x[%s] nestLev2=%08x[%s]\n",
clncb->nestLev1,p1,clncb->nestLev2,p2);
*/
	if (ppleaf) *ppleaf = NULL;
#if 1
	if (Dummy = clncb->nestLev2) {
		id = Dummy->cmd.cid;
		flag = Dummy->cmd.sub_cid & check;
		for (i=0;i<na;i++) {
			able_id = able[i];
			if (flag) {
				if (able_id & flag) able_id &= ~C_CMD_FLAGS;
				else continue;
			}
			if (id == able_id) {
				if (ppleaf) *ppleaf = Dummy;
				return 0;
			}
		}
		return -1;
	}
	if (ppleaf) *ppleaf = Dummy;
	return -2;
#else
	if (!(Dummy = clncb->nestLev2)) return 0;
	while(Dummy) {
		id = Dummy->cmd.cid;
/*
printf("cl_search_node: Dummy=%08x id=[%s] \n",Dummy,cl_gets_cmd_name(id));
*/
		for (i=0;i<nd;i++) {
			if (id == deny[i]) return i+1;
		}
		for (i=0;i<na;i++) {
			if (id == able[i]) return 0;
		}
		if (Dummy == clncb->nestLev1) break;
		Dummy = Dummy->preleaf;
	}
	return -1;
#endif
}

/************************************************/
/*	cl_search_node_deny							*/
/*		deny : �T���m�[�h						*/
/*		able : ���ꂪ�o�Ă�����T�[�`�I��		*/
/* �ԋp : > 0 : deny�̔ԍ�(�擪��1)				*/
/*		  = 0 : able����						*/
/*		  < 0 : �u���b�N�O or able�Ȃ�			*/
/************************************************/
int cl_search_node_deny(y,deny,nd,able,na,ppleaf)
condList *y;
int deny[],nd;
int able[],na;
Leaf  **ppleaf;
{
	Leaf *Dummy;
	CLNCB *clncb;
	int rc,i,id,cmid;
	char *p1,*p2;

	clncb = y->clstcb;
/*
if (Dummy = clncb->nestLev1) p1 = cl_gets_cmd_name(Dummy->cmd.cid);
else p1 = AKX_NULL_PRINT;
if (Dummy = clncb->nestLev2) p2 = cl_gets_cmd_name(Dummy->cmd.cid);
else p2 = AKX_NULL_PRINT;
printf("cl_search_node_deny:Enter nestLev1=%08x[%s] nestLev2=%08x[%s]\n",
clncb->nestLev1,p1,clncb->nestLev2,p2);
*/
	if (ppleaf) *ppleaf = NULL;
	rc = -1;
	if (Dummy = clncb->nestLev2) {
		while(Dummy) {
			id = Dummy->cmd.cid;
/*
printf("cl_search_node_deny: Dummy=%08x id=[%s] \n",Dummy,cl_gets_cmd_name(id));
*/
			for (i=0;i<nd;i++) {
				cmid = deny[i];
/*
printf("cl_search_node_deny: i=%d id=%08x[%s] \n",i,cmid,cl_gets_cmd_name(cmid));
*/
				if (id == cmid) {
					rc = i + 1;
					break;
				}
			}
			if (rc > 0) break;
			for (i=0;i<na;i++) {
				if (id == able[i]) {
					if (ppleaf) *ppleaf = Dummy;
					rc = 0;
					break;
				}
			}
			if (!rc) break;
			if (Dummy == clncb->nestLev1) break;
			Dummy = Dummy->preleaf;
		}
	}
/*
printf("cl_search_node_deny:Exit rc=%d\n",rc);
*/
	return rc;
}

/************************************************/
/*     cl_search_node                             */
/************************************************/
int cl_search_node(y,deny,nd,able,na)
condList *y;
int deny[],nd;
int able[],na;
{
	return cl_search_node_leaf(y,deny,nd,able,na,NULL,0);
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_end_prmnum_check(y)
condList *y;
{
	int rc, i;

	if (y->cmd->prmnum > 0) {
		ERROROUT1(FORMAT(41),"col_mn_tr_end_node");	/* %s: �s�v�ȃp�����[�^������܂��B */
		rc = ECL_TR_ENDIF;
	}
	else rc = 0;
	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_node_check_leaf_check(y,deny,nd,able,na,ppleaf,check)
condList *y;
int deny[],nd;
int able[],na;
Leaf  **ppleaf;
int check;
{
	int rc, i, able_id, flag;
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};

	rc = cl_search_node_leaf(y,deny,nd,able,na,ppleaf,check);
	if (rc) {
		mcat.mc_ipos = 0;
		if (rc < 0) {
/*
printf("cl_tr_node_check_leaf_check: rc=%d\n",rc);
*/
			for (i=0;i<na;i++) {
				if (i > 0) akxtmcats(&mcat,",");
				able_id = able[i];
				flag = able_id & C_CMD_FLAGS;
				akxtmcats(&mcat,cl_gets_cmd_name(able_id & ~C_CMD_FLAGS));
				if (flag == C_LOOP_DO) akxtmcats(&mcat," DO");
			}
					/* col_mn_tr_end_node: %s���Ȃ��̂�%s���ݒ肳��܂����B */
			ERROROUT2(FORMAT(67),mcat.mc_bufp,cl_gets_cmd_name(y->cmd->cid));
		}
		else if (deny && nd>0) {
		/*
			for (i=0;i<nd;i++) {
				if (i > 0) akxtmcats(&mcat,",");
				akxtmcats(&mcat,cl_gets_cmd_name(deny[i]));
			}
			ERROROUT2(FORMAT(68),
				mcat.mc_bufp,cl_gets_cmd_name(CLcList.cmd.cid));
		*/
					/* col_mn_tr_end_node: %s�̌��%s�͎g�p�ł��܂���B */
			ERROROUT2(FORMAT(68),cl_gets_cmd_name(deny[rc-1]),cl_gets_cmd_name(y->cmd->cid));
		}
		return ECL_TR_ENDIF;
	}
	return rc ;
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_node_check_leaf(y,deny,nd,able,na,ppleaf)
condList *y;
int deny[],nd;
int able[],na;
Leaf  **ppleaf;
{
	return cl_tr_node_check_leaf_check(y,deny,nd,able,na,ppleaf,0);
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_node_check(y,deny,nd,able,na)
condList *y;
int deny[],nd;
int able[],na;
{
	return cl_tr_node_check_leaf(y,deny,nd,able,na,NULL);
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_end_node_check(y,deny,nd,able,na)
condList *y;
int deny[],nd;
int able[],na;
{
	int rc;

	if (!(rc = cl_tr_node_check(y,deny,nd,able,na))) {
	/*
		rc = cl_if_close();
		if (rc == 10000) {
			ERROROUT(FORMAT(69));
			return (ECL_TR_ENDIF);
		}
	*/
	}
	return rc ;
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_end_nest_check(y)
condList *y;
{
	int rc ,tree;

	tree = cl_nest_tag(y,2);
	if (tree != -1) {
		rc=cl_change_tree(y,y->clstcb->nestLev2 );
	/*	if (rc) return rc;	*/
		cl_search_nest(y,2);
	}
	else return ECL_TR_ENDIF;
  /* else clError(30); */

	if (!(rc=cl_make_leaf(y))) rc = cl_push(y);

	return rc ;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_end_node(y,deny,nd,able,na)
condList *y;
int deny[],nd;
int able[],na;
{
	int rc;

	if (!(rc=cl_tr_end_prmnum_check(y))) {
		if (!(rc=cl_tr_end_node_check(y,deny,nd,able,na))) rc = cl_tr_end_nest_check(y);
	}
	return rc ;
}
