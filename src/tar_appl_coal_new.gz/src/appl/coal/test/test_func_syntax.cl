//
proc main;
/*
	count=0;
	++count;
	count++
	putline('XYZ');
	print count n;
*/
//	print "'abcdef' instr 'de'";
	print f1();
	return ERROR;
end proc;

func f1;
	return 0;
end func;
