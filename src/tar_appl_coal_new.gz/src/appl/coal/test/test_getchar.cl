//
proc main;
	try;
		loop;
			a = getchar();
			print $a;
			putchar(a);
		end loop;
	catch;
		print ERRMSG;
	end try;
	return $ERROR;
end proc;
