//
// Code7-1.cl : 1�����g���������̃V�~�����[�V����
//
option 5 1;		//�v�f�Ȃ��̃��X�g�̈��� 0x01 : NULL���X�g�Ƃ���
option 22 1;	//for each x �ŁAx�ɒl��ݒ肷��

##define T 5.0
//##define M 5000
##define M 50
##define L 1.0
##define N 100
##define C 1.0
//##define INTV 100
##define INTV 10

const tau = T/cfloat(M);
const h = L/cfloat(N);
const Lambda = C*tau/h;

func f(x);
	return 2*x*(1.0 - x);
//	return math.exp(-100*(x-0.4)*(x-0.4));
end func;

func g(x);
	return 0.0;
//	return -200*(x - 0.4)*f(x);
end func;

proc main();
	double x[N+2],old_u[N+2],u[N+2],new_u[N+2];

//	fig = plt.figure();
	ims = [];

	print Lambda;

	for each j in range(1, N);
		x[j] = (j - 0.5)*h;
		old_u[j] = f(x[j]);
	next;
	old_u[0] = -old_u[1];
	old_u[N+1] = -old_u[N];

	for each j in range(1, N);
		u[j] = old_u[j] + tau*g(x[j]) + (Lambda*Lambda/2.0)*(old_u[j-1] - 2*old_u[j] + old_u[j+1]);
	next;

	for each k in range(0, M);
		t = k*tau;
		if k % INTV == 0 then
		//	im = plt.plot(x[1:N+1], u[1:N+1], linewidth=2, color="blue");
			im = 'x=';
			im &= concat(*x[1..N+1],SEP==>',');
			im &= '\ny=';
			im &= concat(*u[1..N+1],SEP==>',');
			im &= concat('\nlinewidth=2\ncolor="blue"');
			ims.append(im);
print k;
//print im;
		end if;
		u[0] = -u[1];
		u[N+1] = -u[N];

		for each j in range(1, N);
			new_u[j] = 2*u[j] - old_u[j] + (Lambda*Lambda)*(u[j-1] - 2*u[j] + u[j+1]);
		next;

		for each j in range(1, N);
			old_u[j] = u[j];
		next;

		for each j in range(1, N);
			u[j] = new_u[j];
		next;
	next;

	for each x in ims;
		putline(x);
	next;
/*
	plt.title("7-1")
	plt.xlabel("x")
	plt.ylabel("u(x,t)")
	ani = animation.ArtistAnimation(fig, ims, interval=100, repeat=False)
	plt.show()
//	ani.save("anim.gif", writer="pillow", fps=10)
*/
	return ERROR;
end proc;
