//
//define type struct z
deftype struct z
//typedef struct z
	int a (5, 3, 2)
	,char(5) b
	, dec(10,2) c 10,
	bulk(20) d
	,double e hash
	, variant f
	,complex int g
	, h
;
//define var $x as z;
//define var as int;
define type array char za 10 7;
define type array complex zx 5;
//def private z int;
define var xa as za = 'X','Y1234','Z56';
define type mappedarray zm [2,( 4), 6];
define var $x, a, b as z;
define var y as DEC(5,2);
define var v as VARI;
//define var $zmv as zm;
//define var %zmv as zm;
//define var #zmv as zm;
define var $zmv,%zmv,#zmv as zm;
define double hh hash(12);
define dec(5,2) dd[5];
//define +v ;
//define var x.a as VARI;
//define xx 10 5 4 = 1,2,3,4,5,6;
//define xxx 32767 32767;
proc main;
//	option 12 2;
//	z = 0;
//	z.b = 0;
//	var private y as int;
//	private int y++ = 5;
//	private int y = 5;
//	int xx[0] = 3;
//	const xx[0] = 3;
//	local abs(-1);
//	int abs(-1);
//	const abs(-1);
//	array abs(-1) 10;
//	var z as int;

	print za zx zm;
	print $zmv %zmv #zmv;
	print %zmv[0];
	print xa *xa;
	echo z *z;
	hh['A'] = 123.45;
	print *hh;
	print x;
	x.e['A']=123.45;
	print *x;
	print dd *dd;

//	echo x *x;
	print hh *hh;
//	array local xx;
	print xx;
	array local int xx = [10,20,30];
	print xx *xx;
	array x.c = [10,20,30];
	print x.c[0] x.c[1] x.c[2];
//	array x.f = [10,20,30];
//	array x.c[0] = [10,20,30];
//	array x.f 10;
//	print z;
//	print x.f;
//	print v.a;
//	print x x.a x.b x.c;
//	x.a[0,0,0] = 10;
//	a.a[4,2,1] = 20;
//	x.e['ABC'] = 12.34D;
//	print x.e['ABC'];
//	x.f = 'asdf';
//	print x.f;
//	private x.f = 5432.198;
//	print x.f;

//	x.b = 'XYZ';
//	x.c[0] = 12345.67;
	x.d = '1234567890';
	x.f = '1234567890';
	x.g = '1234567890'+54321i;

/*
	print x;
	print x.a[0,0,0];
	print x.a;
	print x.b;
	print x.c[0];
*/
	print x.d;
	print x.f;
	print x.g;
/*
	print x.e['ABC'];
	print y;
	print a;
	print a.a[4,2,1];
	print b;
	print y=123 y='ABC' y=0.3;
	print v=123 v='ABC' v=0.3;
*/
/*
	x.d = to_bulk('1234567890');
	x.f = to_bulk('1234567890');
	x.g = to_bulk('1234567890');
	print x.d;
	print x.f;
	print x.g;
*/
/*
	x.b = 'ABC';
	print f() f();
	dim xxx;
	print xxx;
*/
	return ERROR;
end proc;

func f;
	print x.b;
	return 0;
end func;
