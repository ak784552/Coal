//
define global const double $PI_180=PI/180.0D;
define global const double $D180_PI=180.0D/PI;
//define const public double $PI_180=PI/180.0D;
//define const public double $D180_PI=180.0D/PI;
define $_d=srand1(TIME);
//def aa = 'XX';

func radians(doo);
	return $doo*$PI_180;
end func;

func sind(doo);
//	print aa;
	return sin($doo*$PI_180);
end func;

func cosd(doo);
	return cos($doo*$PI_180);
end func;

func tand(doo);
	return tan($doo*$PI_180);
end func;

func asind(x);
	return asin(x)*D180_PI;
end func;

func acosd(x);
	return acos(x)*D180_PI;
end func;

func atand(x);
	return atan(x)*D180_PI;
end func;

func fact(x);
	return product(*((x+0)..1..-1));
end func;

func randint(int a,int b) as int;
	x = rand1();
	return (x+a)*(b-a)+0.5;
end func;
