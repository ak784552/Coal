//
//import 'lib_math';
proc main;
//	exec sc lib_dll;
	print sind(30d);
	return ERROR;
end proc;
