//
//import 'lib_math';
proc main;
//	exec sc lib_dll;
	print sind(30d);
	print x;
	return ERROR;
end proc;
