//
proc main;
	try(fp=fopen(%1));
		if %4 then
			f3 = fopen(%4,'wt');
		else
			f3=0;
		end if;
		loop;
			a = fgetline(fp,,3,%2,%3);
//			print $a;
			if f3 then
				fputline(f3,a,TO_CODE==>2);
			else
				putline(a);
//				print /x a;
			end if;
		end loop;
	catch FILE_READ_END_EXCEPTION;
	catch;
		print /x EXCEPTION;
		print ERRMSG;
	end try;
	print '~';
	return $ERROR;
end proc;
