//
PROC main;
	print getenv('LOGNAME');
	print getenv('HOST');
	print getenv('SCRIPTPATH');
	RETURN $ERROR;
END PROC;
