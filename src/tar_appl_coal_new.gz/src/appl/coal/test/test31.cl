//
def void v;
proc main;
	print v /i v;
	x = 1 + 2 * 3 - 4 / 2;
	print x /i x;
	return ERROR;
end proc;
