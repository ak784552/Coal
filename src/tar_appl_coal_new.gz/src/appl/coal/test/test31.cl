//
##define p print
def void v;
proc main;
/*
	print v /i v;
	x = 1 + 2 * 3 - 4 / 2;
	print x /i x;

	print sum('123.5');
	print sum('1.0f','2.0','3.0d');
*/
	p (1i**1i;

	return ERROR;
end proc;
