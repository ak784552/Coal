//
##define p print
def void v;
proc main;

	print v /i v;
	x = 1 + 2 * 3 - 4 / 2;
	print x /i x;

	print sum('123.5');
	print sum('1.0f','2.0','3.0d',4.0d);
	print sum(1,2.0,3.0,4.0);

	print 0+'3/5r';
	print 0+'3';
	print sum(1.0/2r,2.0/3r,eval('3.0/5r'));

	print sum('1.0/2r','2.0/3r','3.0/5r');
//	print sum(1.0/2r,2.0/3r,3.0/5r);

	p 1i**1i;

	print 0+'3+5i';

	print sum('1.0+2i','2.0+3i','3.0+5i');

	print sum(1.0..5.0..2.0);
	return ERROR;
end proc;
