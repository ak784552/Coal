//
##define p print
def void v;
proc main;
/*
	print v /i v;
	x = 1 + 2 * 3 - 4 / 2;
	print x /i x;

	print sum('123.5');
	print sum('1.0f','2.0','3.0d');
*/
	print 0+'3.0/5r';
//	print sum(1.0/2r,2.0/3r,eval('3.0/5r'));

//	p 1i**1i;

	return ERROR;
end proc;
