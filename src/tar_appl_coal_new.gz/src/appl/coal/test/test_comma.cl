//
import lib_util;
proc main;
	print comma('-12345678.9');
	print comma('-5678.9');
	print comma('-678.9');
	print comma('-78.9');
	print comma('-8.9');
	print comma('-.9');
	print comma(-12345678.9);
	print comma(-5678.9);
	print comma(-678.9);
	print comma(-78.9);
	print comma(-8.9);
	print comma(-.9);
	return ERROR;
end proc;
