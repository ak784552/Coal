//
def nofr hash 100;
proc main;
	try;
		disp=0;
		count=0;
		loop;
			line = getline();
			i=instr(line,'addr');
			if i>0 then
				nam=line.(i+5);
			endif;
			if disp==0 then
				if left(line,12)=='***** Nofree' then
					putline(line);
					disp=1;
				endif;
			elseif disp==1 then
				if left(line,9)=='***** End' then
					putline(line);
					disp=0;
				elseif ndef('nofr[nam]',,1) then
					putline(line);
					nofr[nam]=count++;
				endif;
			endif;
		endloop;
	catch;
		print ERRMSG;
	endtry;
	return ERROR;
end proc;
