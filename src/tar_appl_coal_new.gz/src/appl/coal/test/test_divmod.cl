//
proc main;
	print divmod(10,3);
	print divmod(10.5,3.3);
	print divmod(10.5d,3.3d);
	print divmod(20/3r,3);
	print divmod(20/3r,7/3r);
	print divmod(20+5i,3);
	print "10 divmod 3";
	return ERROR;
end proc;
