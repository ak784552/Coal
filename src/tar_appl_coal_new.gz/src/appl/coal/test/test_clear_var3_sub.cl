//
def private ss = 100;
proc main;
	$1 = 10;
	for k=1 to 2;
		print k pp ss $1;
		fun1(k);
	next;
	print 3 pp ss $1;
	return ERROR;
end proc;

function fun1(k);
	print 'fun1' k pp ss $1;
	pp = 'XXX';
	ss = 200;
	$1 = 20;
	return k;
end func;
