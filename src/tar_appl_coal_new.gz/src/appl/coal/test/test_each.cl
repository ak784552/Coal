//
define array $a hash;// 10;
define array $b 10;
define array BIN $c 10=[1,2,3];
define mappedarray $m 11 10;
define mappedarray %p 1 10;
define mappedarray #s 1 10;
proc main;
//	let options 0 0 1;
	$a['A'] = 1;
	$a['B`',',','`C'] = 2;
	$a['C'] = FL('LIST',1,2,3);
//	$x = 'B``C';
//	$y = $a[$x];
//	print $x $y $a[$x];
//	loop each $x in abs;

	loop each $x in $('a');
		print $x *$x countv($x.Value);
	end loop;

	loop each $x in $a['C'];
		print $x *$x countv($x.Value);
	end loop;

	loop each $x in FL('LIST',1,2,,'A');
		print $x *$x;
	end loop;

	$b[0] = 'A';
	$b[2] = 'X';
	$b[4] = 'Y';
	$b[9] = 'Z';
	print $b[2] $b[4];
	loop each $x in $b;
		print $x *$x;
	end loop;

	c[4] = 100;
	print *c;

	loop each x in $c;
		print $x *$x;
	end loop;

	$11 = 'AA';
	$20 = 'ZZ';
//	print *m;
	loop each $x in $m;
		print $x *$x;
	end loop;

	loop each $x in %p;
		print $x *$x;
	end loop;

	loop each $x in #s;
		print $x *$x;
	end loop;

	for each $x in 'B';
		print $x *$x;
	next;

//	loop each $x in "";
	loop each $x in $b;
		print $x *$x;
	end loop;

//	for each $x in {1,2,3,4,5,'A','B'},'C' do
//	for each $x in {1,2,3,4,5,'A','B'} do
	xlist = {1,2,3,4,5,'A','B'};
	ylist = {'A','B'};
	for each $x in xlist-ylist do
		print $x.Value $x.Index;
//		x = 0;
//		break;
	next;
//	end do;
	print xlist;
	print ylist;

	loop each $x in SYSDATE..(SYSDATE+2);
		print *$x;
	end loop;
	return ERROR;
end proc;
