//
def a 10 = [1,2,3,4,5,6,7,8,9,10];
def type struct sss
	char x,
	int  y;
sss ss;

proc main;
//	aa = ['A','B','C','D','E','F','G','H','I','J'];
	aa = [1,2,3,4,5,6,7,8,9,10];
// ���o�������w��
	r = 3;
// �A�C�e���͈͂��w��
//	n = a.countv();
	n = 5;
//	print ss;
	print combination(ss,r,n);
	print combination(' ',r,n);
	print combination(a,r,n);
	print combination(aa,r,n);
	print combination(10..20,r,n);
//	bb = {'A','B','C','D','E','F','G'};
//	print combination(bb,r,n);
	print combination({'A','B','C','D','E','F','G'},r,n);
// �A�C�e���͈͂��w��
	setarray(1,1,2,3,4,5,6,7,8,9,10);
	print combination(1,r,n);
	print combination($(),r,n);

	return ERROR;
end proc;
