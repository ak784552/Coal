//
// �R�[�h�ϊ�
//
proc main;
	c = '����ABC���';
//	c = '�\';
//	c = '�]';
	ch = c to 'H';
	print ch /x0 ch;

	cz = strconv(c,'SJIS');
	print 'SJIS' cz /x0 cz;
	ch = cz to 'H';
	print ch /x0 ch;

	cz = strconv(c,'UTF8');
	print 'UTF8' cz /x0 cz;
	ch = cz to 'H';
	print ch /x0 ch;

	cz = strconv(c,'EUC');
	print 'EUC' cz /x0 cz;
	ch = cz to 'H';
	print ch /x0 ch;
	c = strconv(ch,'UTF8');
	print c /x0 c;

	cz = strconv(c,'JIS');
	print 'JIS' cz /x0 cz;
	ch = cz to 'H';
	print ch /x0 ch;
/*
	czs = ['�[','�\','�]','�','�','-'];
	for eachv cz in czs;
		print '----------';
		print cz /x0 cz;
		cz = strconv(cz,'EUC');
		print 'EUC' cz /x0 cz;
		cz = strconv(cz,'JIS');
		print 'JIS' cz /x0 cz;
		cz = strconv(cz,'EUC');
		print 'EUC' cz /x0 cz;
		cc = cz to 'H';
		print cc /x0 cc;
		cz = cc to 'Z';
		print cz /x0 cz;
	next;
*/
	return ERROR;
end proc;
