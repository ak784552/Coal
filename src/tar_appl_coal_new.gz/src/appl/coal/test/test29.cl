//
// �R�[�h�ϊ�
//
proc main;
//	c = '����ABC���';
//	c = '�\';
	c = '�]';
	ch = c to 'H';
	print ch /x ch;

	cz = strconv(c,'SJIS');
	print 'SJIS' cz /x cz;
	ch = cz to 'H';
	print ch /x ch;

	cz = strconv(c,'UTF8');
	print 'UTF8' cz /x128 cz;
	ch = cz to 'H';
	print ch /x ch;

	cz = strconv(c,'EUC');
	print 'EUC' cz /x cz;
	ch = cz to 'H';
	print ch /x ch;
	c = strconv(ch,'UTF8');
	print c /x c;

	cz = strconv(c,'JIS');
	print 'JIS' cz /x cz;
	ch = cz to 'H';
	print ch /x ch;
/*
	czs = ['�[','�\','�]','�','�','-'];
	for eachv cz in czs;
		print '----------';
		print cz /x cz;
		cz = strconv(cz,'EUC');
		print 'EUC' cz /x cz;
		cz = strconv(cz,'JIS');
		print 'JIS' cz /x cz;
		cz = strconv(cz,'EUC');
		print 'EUC' cz /x cz;
		cc = cz to 'H';
		print cc /x cc;
		cz = cc to 'Z';
		print cz /x cz;
	next;
*/
	return ERROR;
end proc;
