//
rational ra ;//= 3/2r;
//rational int ira;
//rational dec(10,3) dra;
rational dec dra ;//= 3.1/2.3r;
rational dec raa[10];// = 5;//[3/2r,2.5/2r,3.5/5r,1/2r] ;
complex dec ca 10;//=5;
complex dec cc;//=5;
int aa 5;
proc main;

	print ra /i ra;
	print cc /i cc;
	print ca ca[0] *ca aa aa[0] *aa;
//	print ira /i ira;
	dra = 5;
	print dra /i dra;
	raa[0] = 5;
	print raa raa[0] *raa;
	ra = 3;
	print ra /i ra;
//	xra = dra + ra;
//	print xra /i xra;
	ca[0] = 5;
	print ca ca[0] *ca;

	return ERROR;
end proc;
