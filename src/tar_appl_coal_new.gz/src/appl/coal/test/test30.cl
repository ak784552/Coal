//
def h hash 10 = ['A',11,'B',22,'C',33,'D',44,'E',55];
proc main;
	print *h;
	h['F'] = 66;
	print h['F'];
	print *h;
	return ERROR;
end proc;
