//
PROC main;
	print chr('48',0x30,0x30+1.5);
	print to(asc('ABC'),'x');
	print to_bulks(asc('ABC'))&+'';
	print 1.2539 to(1.2539,'X');
	print 1.0F to(1.0F,'X');
	print to(100,'x');
	$a = to_bulks('CdE',1,1.5);
	print to_bulks($a)&+987;
	print substr('1234',1);

	print to_bulk('123',1);
	print to_bulk(1,1,4);
	print to_bulk(0,1,1);
	print to_bulk(1);
	print to_bulk(1.0F);
	print to_bulk('');

	print asc('�`a') ascb('�`a');
	print to(asc('�`a'),'x') to(ascb('�`a'),'x');
	print 'A'.asc().to('X');

	RETURN $ERROR;
END PROC;
