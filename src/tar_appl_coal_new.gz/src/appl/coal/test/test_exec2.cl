//
proc main;
	call "> aaaaa ";
	putline('call > aaaaa');
	call > /dev/tty;
	putline('call > /dev/tty');
	call "<<= EOF ";
  	aaa
	  bbb
		ccc
   EOF
	loop 2;
		line = getline();
		if ERROR; break; endif;
		putline(line);
	end loop;
	call <<- EOF2;
	xxxxxxx
	yyyyyyy
	EOF2
	line = getline();
	if !ERROR;
		putline(line);
	endif;
	return ERROR;
end proc;
/*
proc ppp(a);
	putline('called ppp',a);
	exec > 'xxx';
	putline('exec > xxx');
	return ERROR;
end proc;

func fff(a);
	putline('called fff',a);
	exec > 'fff';
	putline('exec > fff');
	return ERROR;
end func;
*/
