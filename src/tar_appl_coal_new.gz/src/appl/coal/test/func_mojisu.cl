//
function mojisu (s);
/*
	n = 0;
	while s do
		s = substrb(s,(s is 'M')+1);
		n++;
	end do;
	return n;
*/
	return leng(s);
end function;
