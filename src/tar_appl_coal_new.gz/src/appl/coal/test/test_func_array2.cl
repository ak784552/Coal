//
define type struct z
	int a (5, 3, 2)
	,char(5) b
	, dec(10,2) c 10,
	bulk(20) d
	,double e hash
	, variant f
	, g
;
define array a 10;
proc main;
	print /d fun(5) *fun(5);
	aa = *fun(5);
	print aa *aa;
	x = fun(5);
	print x+1;
	return ERROR;
end proc;

func fun(n);
	redef private array x[n]=[1,2,3,4,5];
	return x;
end func;
