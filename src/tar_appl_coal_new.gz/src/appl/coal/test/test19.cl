//
class Card ;
	char suit;
	int  number;
	func Card(suit,number);
		My.suit = suit;
		My.number = number;
		return 0;
	end func;
end class;

class Deck;
	cards = '';
	var card;
	func Deck();
		option 5 +0x01;
		cards = [];
		for each suit in ['�n�[�g','�_�C��','�X�y�[�h','�N���u'];
//		for each suit in ['�n�[�g','�_�C��'];
			for each number in 1..13;
//			for each number in 1..1;
				My.card = new Card(suit.value,number.value);
//print card.suit card.number;
				append(My.cards,My.card);
//print card.suit card.number;
			next;
		next;
//print My.cards[0].suit My.cards[0].number;
//print My.cards[1].suit My.cards[1].number;
		return 0;
	end func;
	func shuffle();
		random(My.cards);
		return 0;
	end func;
	func draw_card();
		return pop(My.cards,0);
	end func;
end class;

proc main;
	option 5 +0x01;
/*
	card = new Card('�n�[�g',1);
	print card.suit card.number;
	cards = [];
	append(cards,card);
	x = cards[0];
	print cards[0].suit cards[0].number;
	print card.suit card.number;
	print x.suit x.number;
	card = new Card('�X�y�[�h',5);
	print card.suit card.number;
	append(cards,card);
//	print cards;
	print cards[0].suit cards[0].number;
	print cards[1].suit cards[1].number;
*/
/*
	cards = [];
//		for each suit in ['�n�[�g','�_�C��','�X�y�[�h','�N���u'];
		for each suit in ['�n�[�g','�_�C��'];
//			for each number in 1..13;
			for each number in 1..1;
				card = new Card(suit.value,number.value);
//print card.suit card.number;
				append(cards,card);
//print card.suit card.number;
			next;
		next;
	print cards[0].suit cards[0].number;
	print cards[1].suit cards[1].number;
*/

	deck = new Deck();
	deck.shuffle();
	card = deck.draw_card();
//	card = deck.cards[1];
	print card.suit card.number;
/*
	card2 = deck.cards[0];
	print card2.suit card2.number;
*/
	print countv(deck.cards);
	for each card in deck.cards;
		print card.value.suit card.value.number;
	next;
//	card = deck.cards[1];
//	print card.suit card.number;

	return ERROR;
end proc;
