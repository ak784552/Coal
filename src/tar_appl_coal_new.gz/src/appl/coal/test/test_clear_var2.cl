//
proc main;
	fun1();
	fun1();
	fun2();
	exec ip p-1;
	exec ip p-2;
	return ERROR;
end proc;

function print1f (a);
	echo "'*** ' & a";
	i = 1;
	printf 'i=%d' i;
	return ERROR;
end func;

function fun1();
//	print1f('fun1');
	x = 1;
	y = x;
	print y;
	return 0;
end func;

function fun2();
	print1f('fun2');
	return 0;
end func;

proc print1 (a);
	echo "'*** ' & a";
	i = 1;
	printf 'i=%d' i;
	return ERROR;
end proc;

proc p-1;
	exec ip print1 'p-1';
	return $ERROR;
end proc;

proc p-2;
	exec ip print1 'p-2';
	return $ERROR;
end proc;
