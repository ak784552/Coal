//
//define array a 10 = ['%A%','%C%','%C%','%','%F%'];
//define array b 10 = [1i,2,3,4,5,'AB','BC','CD','DE','EF'];
//define array BIN c 10 = [1i,3,2,7,5,6,4,9,10,8];
//define array d 10 = [1,3,2,7,5,6,4,9,10,8];
def wc = {1,2,3,4,5,6,7,8,9,10};
//define array r 10;
//define ha hash = ['A',1,'B',2,'C',3,'D',4,'E',5];;
//define hb hash = ['A',10,'B',20,'X',30,'D',40,'E',5];
proc main; 
	a = $() + [0,10];
	b = $() + [10,10];
	c = $() + [20,10];
	d = $() + [30,10];
	r = $() + [40,10];
	s = d + [5,3];
	setarray(a,'%A%','%C%','%C%','%','%F%');
	setarray(b,1i,2,3,4,5,'AB','BC','CD','DE','EF');
	setarray(c,1i,3,2,7,5,6,4,9,10,8);
	setarray(d,1,3,2,7,5,6,4,9,10,8);
	print *s;
/*
	print 1i+1i;
	print arraybxp(r,b,c,5,'+');
	print *r;
	print arraybxp(r,b,c,5,lambda('a,b','a+b'));
	print *r;
*/
	print arraybxp(r,b+5,a,5,like);
	print *r;
/*
	print arraybxp(r,b,c,5,max);
	print *r;

	print arraybxp(r,wc,c,5,'+');
	print *r;

	print *arraybxp(0,b,c,5,'+');
	print arraybxp(0,wc,c,5,'+');
/*
	print *arraybxp(0,ha,hb,5,'+');
	print *arraybxp(0,ha,hb,5,'==');
	print *arraybxp(0,ha,b,5,'==');
*/
	print *arraybxp(0,d,c,5,complex);
	print *arraybxp(0,b,c,5,rational);
	*r = 0;
	print *r;
*/
	return ERROR;
end proc;
