//
def aa[10] = ['A','�a',,'C','�c','E'];
def bb[10];
def hh hash;
type struct zt
	int a
	,char(5) b
;
var zz as zt;
proc main;

	$a = 1 concat 2;

	$b = 10 &+ 4;
	$c = &+(10,4);
	$d = 10 |+ 4;
	$e = |+(10,4);
	print $a $b $c $d $e "concat('A','B')";
	$a concat= 3;
	$b &+= 5;
	$c |+= 5;

	print $a $b $c;

//	call pr1;
	print "'ABC' & '�wY�y'";
	print "'123' | '456'";
	print "123 & 456";
	print "3 | 4";
	print "'A' concat .5e2";
	print .5e2;

	BEXP x = 'P' concat 'Q' '�q' 'S';
	print x;
	BEXP x = aa concat 'Q' 'R' 'S';
	print x;

	aa[2] = {'X','Y','Z'};
//	print *aa;
	print concat(aa);
	print concat({1,2,3,4,5,6,aa});
	print concat([10,11,'A','B',aa]);
	print concat(('A'..'Z'));
	print *('Z'..'A'..(-1));
	print concat(('A'..'Z'));
	print concat(*('A'..'Z'));
	print concat(**('A'..'Z'));
//	print *(10..1..(-1));
	print concat(*(1..10));
	print *(1.5..10.5..0.5);
//	print *(10.5..1.5..(-0.5));

	print concat(*(1.5..10.5..0.5));

	print concat(*((SYSDATE+5)..SYSDATE..'D-2'));
	print *(SYSDATE..(SYSDATE+5)..'D');

	BEXP a = 'A' concat **('5'..'9');
	print a;

	print *bb;
	print concat(bb);

	hh['AMC'] = 'AA';
	hh['XGN'] = [8,9,10];
	hh['PAW'] = 'CC';
	print *hh;
	print concat(hh);
	print concat(zz);
	aa[3] = zz;
	print concat(aa);
	print concat(main);
	print concat(abs);
	aa[3] = aa;
	bb[0] = 'H';
	print concat(bb,aa,bb);
	aa[2] = {'X',aa,'Z'};
	print concat(aa);
	print *aa;
	xx = *aa;
	print *xx;

	$1 = '$1';
	$2 = '$2';
	$3 = '$3';
	print concat($());

	$2 = {'X',$(),'Z'};
	print concat($());

	print concat(1,2,3,4,5,6);

	array bb = ['A','�a',100,'C','�c','E'];
	print *bb;
	bb[1] = str_conv(bb[1],'S-JIS');
	print concat(bb);

	array aa = ['A','�a',100,'C','�c','E'];
	print *aa;

	aa[1] = str_conv(aa[1],'S-JIS');
	print *aa;
	print concat(aa);

	return ERROR;
end proc;

proc pr1;
	return ERROR;
end proc;
