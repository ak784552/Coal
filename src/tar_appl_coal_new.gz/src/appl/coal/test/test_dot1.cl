//
proc main;
	text='1234567890';
	print text.0;
	print text.1;
	print text.5;
	print text.10;
	print text.11;
	print text.(-1);
	print text.(-5);
	print text.(-10);
	print text.(-11);

	print text.'0,6';
	print text.'1,6';
	print text.'1,10';
	print text.'1,11';
	print text.'1,0';
	print text.'1,-1';
	print text.'2,-2';
	print text.'1,-9';
	print text.'1,-10';
	print text.'1,-11';
	print text.'-5,3';
	print text.'-5,-3';
	return ERROR;
end proc;
