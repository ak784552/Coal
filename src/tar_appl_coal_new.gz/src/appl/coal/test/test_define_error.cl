//
//def >& aaaa;
//define dd ee;
define dd dec(10,5);
//define array array a;
//define const const a;
//define static static a;
//define clear clear a;
//define char char a;
//define int char a;
//int x=1;
//define array const static clear char a;
type struct aa
//	int int a;
	int a,
	char b;
//var const private x as int char;
var const private x as int;
//var const private array y as int;
//var const private static y as int;
//var const private clear y as int;
sub main;
	print /i dd;
	int y=1;
	print /i a;
	print aa;
	return ERROR;
end sub;
