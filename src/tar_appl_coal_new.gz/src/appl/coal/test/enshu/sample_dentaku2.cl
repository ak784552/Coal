//
// �t�|�[�����h�d��v���O����
//
//option 24 1;
##define NUMBER '0' /* �������������Ƃ����M�� */

proc main;
	char $type, s[1];
	double op2;

	while ($type = getop(s)) != '';
	switch $type;
		case NUMBER;
			push(s[0]);
			break;
		case '+';
			push(pop() + pop());
			break;
		case '-';
			push(pop() - pop());
			break;
		case '*';
			push(pop() * pop());
			break;
		case '/';
			op2 = pop();
			if op2 == 0.0 then
				putline('zero divisor poped');
			else
				push(pop() / op2);
			end if;
			break;
		case '=';
			putline('\n',push(pop()));
			break
		case 'c';
			clear();
			break;
		default;
			putline('unknown command ', $type, '\n');
			break;
		end switch;
	end while;
	return ERROR;
end proc;

##define MAXVAL 100	/* val�X�^�b�N�̍ő�[�� */
	
int sp = 0;	/* �X�^�b�N�E�|�C���^ */
double val[MAXVAL];	/* �l�̃X�^�b�N */

function push(double f) as double;
	if sp < MAXVAL then
		return val[sp++] = f;
	else
		putline('error: stack full');
		clear();
		return 0;
	end if;
end func;

function pop() as double;
	if sp > 0 then
		return val[--sp];
	else
		putline('error: stack empty');
		clear();
	return 0;
	end if;
end func;

function clear();
	sp = 0;
	return 0;
end func;

function getop(s);	 /* ���̉��Z�q���邢�͔퉉�Z�������߂� */
	int i;
	char c, line;

	line = getline();
	i = 1;
	while (c = substr(line, i, 1)) == ' ' || c == '\t' || c == '\n' ;
		i++;
	end while;
	s[0] = substr(line, i);
//print s[0];
	if c == '.' || (c >= '0' && c <= '9') then
		return NUMBER;
	else
		return c;
	end if;
end func;
