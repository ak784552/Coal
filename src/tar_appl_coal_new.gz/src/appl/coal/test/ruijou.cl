//
// ruijou.cl
//
def na 32;
proc main;

//print na;
	n = 30;	// 16 + 8 + 4 + 2
	x = 2;
	xx = x;
	nn = 1;
	na[0] = 1;
	for (i=0;i<31;i++);
print i nn xx;
		if n & nn then
			na[i] = xx;
		else
			na[i] = 0;
		endif;
print i na[i];
		nn += nn;
		if nn > n thenl break;
		xx = xx*xx;
	next;
	i--;
print i xx;
	while i >= 0;
		if na[i] thenl xx *= na[i];
print i xx;
		i--;
	end while;
print xx;

print x**n;
//print 10**12;
print 10**14;

	print 50000*50000;

//print sqrt(LONG_MAX);

	return ERROR;
end proc;
