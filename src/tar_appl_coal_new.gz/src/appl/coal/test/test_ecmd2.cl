//
proc main;
	loop 2;
		ecmd('break %1;',%3);
		print 1;
		ecmd('continue %2;',%3);
		print 2;
	end loop;
	return ERROR;
end proc;
