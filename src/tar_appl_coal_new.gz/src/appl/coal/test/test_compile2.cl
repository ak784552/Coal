//
proc main;
//	$ERROR = 1;
	$1 = 100;
	if 2 == ($1 = 2);
		print %0 %1 $1;
	endif;
	let shift;
	print %0 %1;
//	let %0 = 10;
//	let %1 = 20;
//	print %0 %1;
	let #0 = 10;
	let #1 = 20;
	print #0 #1;
	return ERROR;
end proc;
