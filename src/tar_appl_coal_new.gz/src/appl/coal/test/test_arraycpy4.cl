//
define array r 20 = [1,2,3,4,5,6,7,8,9,10];
define array s 20 = [1,2,3,4,5,6,7,8,9,10];
define array t 20 = [1,2,3,4,5,6,7,8,9,10];
define array a 10 = [11,12,13,14,15];
define ha hash = ['A',1,'B',2,'C',3,'D',4,'E',5];;
define hb hash = ['A',10,'C',20,'X',30,'Y',40,'E',5];
proc main; 

	print arraycpy(r,s,,fun,2);
	print *r;
	print arraycpy(1,s,,fun,3);
	print *$();
	print *arraycpy(0,s,,fun,4);
	return ERROR;
end proc;

func fun(a,b);
print a b;
	return a*b;
end func;
