//
//def image i;
complex aa;
def ac = 10+5i;
rational bb;
//rational int ira;
rational dec dra;
rational dec dra5 = 5;
proc main;

	print aa /i aa;
	print ac /i ac;
	print bb /i bb;
	print dra /i dra;
	print dra5 /i dra5;

//	return $ERROR;
end proc;
