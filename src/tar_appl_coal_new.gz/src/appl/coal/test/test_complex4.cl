//
//def image i;
complex aa;
complex dec(5,2) ca=1.2+2.5i;
//complex char cc;
//complex bulk bu;
//complex date da;
def ac = 10+5i;
rational bb;
//rational int ira;
rational dec dra;
rational dec dra5 = 5;
proc main;

	print aa /i aa;
	print ca /i ca;
	print ac /i ac;
	print bb /i bb;
	print dra /i dra;
	print dra5 /i dra5;

//	return $ERROR;
end proc;
