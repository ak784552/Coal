//
proc main;

	print "a = '\0'";
	print a leng(a) /x a;
//	a = '';
	if a then
		print 'true';
	else
		print 'false';
	endif;

	print "'\0' & 'XYZ'";
	print "'ABCD' & '\0' & 'XYZ'";
	print '\0';
	return ERROR;
end proc;
