//
define array r 20 = [1,2,3,4,5,6,7,8,9,10];
define array s 20 = [1,2,3,4,5,6,7,8,9,10];
define array t 20 = [1,2,3,4,5,6,7,8,9,10];
define array a 10 = [11,12,13,14,15];
define ha hash = ['A',1,'B',2,'C',3,'D',4,'E',5];;
define hb hash = ['A',10,'C',20,'X',30,'Y',40,'E',5];
proc main; 

	r = *a;			// r��a�̔z���񂪃R�s�[�����
	print r *r;
	*s = *a;		// �z��s�ɔz��a�̗v�f���R�s�[�����
	print s *s;
	b = a;
	print b *b;
	c = *a;
	print c *c;
//	print arraycpy(t,a);
	print arraycpy(t,[21,22,23]);
	print t *t;
	x = 1;
	*s = *[31,32,33];
	print *s;

	d = [101,102,103,104,105];
	print arraycpy(d,{21,22,23});
	print d;

	e = [101,102];
	print arraycpy(e,{21,22,23,24,25});
	print e;

	print arraycpy(ha,hb);
	print *ha;

	return ERROR;
end proc;
