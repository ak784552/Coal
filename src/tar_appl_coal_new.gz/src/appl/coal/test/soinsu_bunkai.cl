//
##include sosu_tbl.cl
/*
define MAX_SOSU	=100000;
define int gFlag;
int sosu MAX_SOSU =
	{ 2,  3,  5,  7, 11, 13, 17, 19, 23, 29,
	 31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
	 73, 79, 83, 89, 97,101,103,107,109,113,
	127,131,137,139,149,151,157,163,167,173,
	179,181,191,193,197,199,211,223,227,229,
	233,239,241,251,257,263,269,271,277,281,
	283,293,307,311,313,317,331,337,347,349,
	353,359,367,373,379,383,389,397,401,409,
	419,421,431,433,439,443,449,457,461,463,
	467,479,487,491,499,503,509,521,523,541,
	547,557,563,569,571,577,587,593,599,601,
	607,613,617,619,631,641,643,647,653,659,
	661,673,677,683,691,701,709,719,727,733,
	739,743,751,757,761,769,773,787,797,809,
	811,821,823,827,829,839,853,857,859,863,
	877,881,883,887,907,911,919,929,937,941,
	947,953,967,971,977,983,991,997};
*/
proc main;
	dim ret,b,i,k,count as int;
	dim max_sosu,msosu,msosu2,i0,last,opt,max as int;

	max_sosu = add_sosu_tbl(sosu1,0);
	max_sosu = add_sosu_tbl(sosu2,max_sosu);
	max_sosu = add_sosu_tbl(sosu3,max_sosu);
//	max_sosu=countv(sosu);
	$max = sosu[max_sosu-1];
	putline('initial max sosu number=',max_sosu,' max sosu=',$max);
	max_sosu--;
	count_sosu=0;
	loop;
		printf('Entry number(<%d ,end <=0) ==> ',$max*$max);
		num=to_number(getline(),2,,,1);
		if num <= 0 thenl break;
		loop 100 as L10;
			nn = num;
			for i=0 to max_sosu;
				if (!(num % (m=sosu[i]))) then
					n = num / m;
					print m;
					num = n;
					break;
				else
					mm = m*m;
					if num < mm then
						printf('m=%d < %d * %d\n',num,m,m);
						break L10;
					endif;
				endif;
			next;
			if nn==num then
			//	printf('m=%d < %d * %d\n',num,m,m);
				if num > mm then
					printf('m=%d > %d * %d\n',num,m,m);
				endif;
				break;
			end if;
		end loop;
	end loop;
	return 0;
end proc;

//*************************
// �ԋp : = 1 : �f��
//*************************
func akxg_sosu_chk_by_tbl_opt(sosu,max_size,l,opt);
	dim i,mmax,m as int;
	dim ll,l1,l2 as int;

	mmax=max_size;
//print sosu max_size l opt;
	if (!(sosu)) thenl return -1;
	ll = l;

	if (ll < 2) then return 0;
	elseif (ll == 2) then return 1;
	elseif (ll <= 7) then
		if (ll&0x01) thenl return 1;
		return 0;
	end if;

	l2 = (CINT)sqrt(ll);
//print l2;
	for (i=0;i<mmax;i++) do;
		if (!(ll % (m=sosu[i]))) then
//			if gFlag thenl print ll m ll/m;
			break;
		endif;
		if (m > l2) thenl break;
	next;
	if (i>=mmax) then
//putline('akxg_sosu_chk: ll=',ll,' l2=',l2,' i='.i,' m=',m); 
		return -2;
	elseif (m>l2) thenl return 1;

//putline('akxg_sosu_chk: ll=',ll,' l2=',l2,' i='.i,' m=',m); 

	return 0;
end func;
