//
define array a 10 = ['%A%','%C%','%C%','%','%F%'];
define array b 10 = [1,2,3,4,5,'AB','BC','CD','DE','EF'];
define array BIN c 10 = [1,2,3,4,5,6,7,8,9,10];
define array BIN d 10 = [1,2,3,4,5,6,7,8,9,10];
def wa = {'%A%','%C%','%C%','%','%F%'};
def wb = {1,2,3,4,5,'AB','BC','CD','DE','EF'};
def wc = {1,2,3,4,5,6,7,8,9,10};
def wd = {1,2,3,4,5,6,7,8,9,10};
def xa = [['%A%','%C%','%C%','%','%F%']];
def xb = [[1,2,3,4,5,'AB','BC','CD','DE','EF']];
def xc = [[1,2,3,4,5,6,7,8,9,10]];
def xd = [[1,2,3,4,5,6,7,8,9,10]];
proc main; 
/*
	loop each x in b;
		print *x;
	end loop;

	loop each x in c;
		print *x;
	end loop;
*/
	print arraycmp(b,c,5,'EQ');
	print arraycmp(b,c);
	print arraycmp(b+5,a,,'like');

	print *c==*d;

	print arraycmp(wb,wc,5,'EQ');
	print arraycmp(wb,wc);
	print arraycmp(wb+5,wa,,'like');

	print wc==wd;

	print arraycmp(xb,xc,5,'EQ');
	print arraycmp(xb,xc);
	print arraycmp(xb+5,xa,,'like');

	print xc==xd;

	return ERROR;
end proc;
