//
proc main;
	exec sc test_exit_sub %*;
	return $ERROR;
end proc;
