//
//	hello.cl
//
proc main;
	print 'Hello World!';
	return;
end proc;
