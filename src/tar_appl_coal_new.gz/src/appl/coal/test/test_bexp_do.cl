//
//def a 10 = [1,2,3,4,5,6,7,8,9,10];
//def b 10;
proc main;
	a = $() + [0,10];
	b = $() + 10;
	print a b;
	setarray(1,0,1,2,3,4,5,6,7,8,9,10);

	bexp x = 'XYZ' substr 2 3;
	print x;

	bexp x = 1 + 2 + 3;
	print x;
	bexp x++;
	print x;

	i1 = getval('OPTION', 15) & 0x01 ? 1 :0;
	i2 = i1 + 9;

	bexp b[i] = a[i] do i=i1,i2;
//	bexp b[i] = a[i] do i=i1,1;
	print *a *b;

	bexp b[i]=a[i] do i=i1,i2;
//	bexp b[i]=a[i] do i=i1,1;
	print *a *b;

	bexp b[i]=a[i] for(i=i1;i<=i2;i++);
	print *a *b;

	t = 0;
	bexp t += a[i] do i=i1,i2;
	print t;

	print *a[2..7..2];

	return ERROR;
end proc;
