//
def type struct S_AA
	int x,
	char(5) y,
	dec x;
define int a 10 = [1,2,3,,5];
define  b 10 = ['A','B','C',,'E'];
def var c as S_AA;
proc main;
	print /i *b;
	echo '---in a';
	for each x in a;
		print *x;
	next;

	echo '---in b';
	for each x in b;
		print *x;
	next;
/*
	echo '---in c';
	for each x in c;
		print *x;
	next;
*/

	echo '---in a,b';
	for each x in a,b;	// ,c;
		print *x x.value;
	next;

	echo '---in *a,*b';
	for each x in *a,*b;	// ,c;
		print x.value;
	next;

	aa = {10,20,30};
	bb = ['X','Y','Z'];
//	for each x in {10,20,30};//,['X','Y','Z'];
//	for each x in aa;//,bb;
	echo '---in bb';
	for each x in bb;
		print *x x.value;
	next;

	cc = FL('LIST',1,2,,'A');
	echo '---in FL(''LIST'',1,2,,''A'')';
	loop each $x in FL('LIST',1,2,,'A');
//	loop each $x in cc;
		print $x *$x;
	end loop;

	echo '---in a,b,[...]';
//	bb = ['X','Y','Z'];
	for each x in a,b,bb;
		print *x x.value;
	next;

	return ERROR;
end proc;
