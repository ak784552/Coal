//
def type struct S_AA
	int x,
	char(5) y,
	dec x;
define int a 10 = [1,2,3,4,5];
define  b 10 = ['A','B','C'];
def var c as S_AA;
proc main;

	for each x in a;
		print *x;
	next;
	for each x in b;
		print *x;
	next;
/*
	for each x in c;
		print *x;
	next;
*/
	for each x in a,b;	// ,c;
		print *x x.value;
	next;

	for each x in *a,*b;	// ,c;
		print x.value;
	next;

	aa = {10,20,30};
	bb = ['X','Y','Z'];
//	for each x in {10,20,30};//,['X','Y','Z'];
//	for each x in aa;//,bb;
	for each x in bb;
		print *x x.value;
	next;
	cc = FL('LIST',1,2,,'A');
	loop each $x in FL('LIST',1,2,,'A');
//	loop each $x in cc;
		print $x *$x;
	end loop;

	return ERROR;
end proc;
