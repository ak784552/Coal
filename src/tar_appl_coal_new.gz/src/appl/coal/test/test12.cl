//
proc main();
	i = 1;
	loop %0;
//		print %1;
		LET SHIFT;
		print %(i);
//		i++;
	end loop;
	return ERROR;
end proc;
