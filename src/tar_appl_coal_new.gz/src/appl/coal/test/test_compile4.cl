//
define const array a 5 = [1,2,3,4,5];
define const array b 3 = [2,4];
proc main;
	c = 1;
	print ---c c -++c c ++-c c;
	print --(c=a) c /d c;
	print c=a+1 c /d c;
	print c=a+[,3] c /d c;
//	print (c=a) c;
	print ++1 --3 --abs(-4);
	print b -*b /d *(-*b);
//	print +*b;
	print *(*a-*b);
	print am=arraymap(a,0) /d am;
	print am=arraymap(a,1) /d am;
	print am=arraymap($(),2) /d am;
	return ERROR;
end proc;
