//
define var yd as DEC(5,2) = 345.67;
define string ss = 'ABCDEF';
//define ERROR ;
define aa[10];
//define DEC(10,4) yd = 123.4567;
//define public string ss = 'XYZ';
//define global string ss = 'XYZ';
define global ss;// = 'XYZ';
define global gg;
sub main;
	print /i MAX_LOOP_WHILE;
/*
//	char xx={1,2,3,4};
//	xx={1,2,3,4};
	print xx;
	int xx=12345;
	print xx;

	print aa;
	array aa[15];
	print aa;
	print yd ss;
*/
	x = 'ss';
//	local ss = '1234567890';
	local char ss = '1234567890';
	print $(x);
//	print 1 ss;
//	ss = ss;
//	print 2 ss;

	redef private char(4) ss = ss;
	print 3 ss /i ss;
	private dec(10,3) yd = yd;
	print yd /i yd;
	private dec(10,4) yd = 1234.5678;
	print yd /i yd;

	private dec(10,3) yd2 = yd;
	print yd2 /i yd2;

	ss = 'abcdefghijk';
	print 4 ss /i ss;
	char(10) ss = '0987654321';
	print 5 ss /i ss;//d ss;

	char ss;
	print 6 ss ;//d ss;
	ss = 'XYZ';
	array aa = [1,2,3,4];
//	local aa[5] = 1,2,3,4;
	local array aa[5] = [1,2,3,4];
//	array char aa = [1,2,3,4];
	print aa *aa;

	private char(5) $(x) = $(x);
//	public char(4) $(x) = $(x);
//	global char(4) $(x) = $(x);

	print 7 $(x);
//	print 8 "public $(x)";
	print 8 "global $(x)";
//	print 8 /i "public ss";
	print 9 "private $(x)";
	print 10 "private ss";
	print 11 "local $(x)";
	print 12 /i "global gg";
//	print "private $1";

	return ERROR;
end sub;
