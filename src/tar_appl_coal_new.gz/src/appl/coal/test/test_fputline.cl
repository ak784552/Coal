//
proc main;
//	let options "" "" 6;
	fp = fopen(%1,'wt');
	if fp then
		$2 = fputline(fp,'XYZ\n\n RT\n');
		fclose(fp);
	endif;
	return $ERROR;
end proc;
