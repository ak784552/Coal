//
proc main;
//	option 8 4;
//	print substr('ABCDRF',,2);
//	Func11='abs';
//	print Func11();
	print 1+func1();
	return $ERROR;
end proc;

proc func1;
	print 'called proc';
	return $ERROR;
end proc;

func func1;
	print 'called func';
//	1/0;
	return $ERROR;
end func;
