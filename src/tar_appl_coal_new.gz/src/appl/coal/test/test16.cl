//
proc main;
	exec sc test_const;
	undef const like public % not global ei_to_u eb_to_u PI_180;
	exec sc test_felwrite1;
	return ERROR;
end proc;
