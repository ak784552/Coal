//
##include class_sosu_chk.cl

proc main;
	MAX_LOOP_WHILE = 100000;
//	sch = new SosuCheck(100000);
	sch = new SosuCheck();
	n0=2;
  try;
	for i=0 to 100;
		s = sch.get_sosu(i);
		m = 1.0;
		loop s;
			m *= 2.0;
		endloop;
		m--;
print s m;
		loop;
			if ((ret=sch.sosu_chk_by_tbl_opt(m))>0) then
				kanzen = m*(m+1)/2.0;
				print kanzen;
			elseif ret<0;
				putline('*** few sosu table!!');
				break 2;
			endif;
			break;
		endloop;
	next;
  catch;
	print ERRMSG;
  end try;
	return ERROR;
end proc;
