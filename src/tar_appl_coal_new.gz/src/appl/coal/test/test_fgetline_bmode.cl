//
option 13 +0x400;
proc main;
	try(fpi=fopen(%1,'rb'));
		if %2=='' then
			fpo = STDOUT;
		else
			fpo=fopen(%2,'w');
		endif;
		loop;
			a = fgetline(fpi,,,2,2);
		//	a = fgetline(STDOUT,,,,);
			print /i $a;
			print a /x $a;
			fputline(fpo,a);
		//	fputline('x',a);
		//	fputline(STDIN,a);
		end loop;
	catch FILE_READ_END_EXCEPTION;
	catch;
		print ERRMSG ERROR ERRNO;
	finally;
	end try;
	return $ERROR;
end proc;
