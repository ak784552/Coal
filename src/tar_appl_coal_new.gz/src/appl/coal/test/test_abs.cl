//
proc main;
	print abs(-10) $abs;
	print abs(-1,-2);
	print abs('ABC');
	print abs(SYSDATE);
	return ERROR;
end proc;
