//
proc main;
	print CDATE('');
//	print CDATE('2025/07/31');
	return ERROR;
end proc;
