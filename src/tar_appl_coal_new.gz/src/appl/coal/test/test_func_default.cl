//
define x;
proc main;
	x=1000;
	print func1(10,12);

	print func1(aa==>'XYZ');
	print func1(bb==>99);
	print func2();
	print func3();
	print func4();
	print func5();

	return $ERROR;
end proc;

function func1(char aa = 200, bb as int = '120', cc = x, dd = '');
	print aa bb cc dd;
//	cc;
	return 0;
end func;

function func2(char aa = '200', bb as int =);
	print aa bb;
	return 0;
end func;

function func3(char aa = , bb as int = 0);
	print aa bb;
	return 0;
end func;

function func4(char aa XX , bb );
	print aa bb;
	return 0;
end func;

function func5(char aa, bb as int as);
	print aa bb;
	return 0;
end func;
