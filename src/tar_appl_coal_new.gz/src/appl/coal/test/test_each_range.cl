//
proc main;

//	a = 2..5;
	a = 'A'..'C';

	print a *a 3..6 'A'..'Z';
	print 'a';
	loop each x in a;
//		print *x;
		print *x x.value;
	end loop;
	print a;
	print '*a';
	loop each x in *a;
		print *x;
	end loop;
	print '**a';
	loop each x in **a;
		print *x;
	end loop;
	print;

//	loop each x in 1..100;
//	loop each x in 2..5;
//	loop each x in [(2..5),(10..15)];
	loop each x in *[(2..5),(10..15)];
//	loop each x in [*(2..5),*(10..15)];
//	loop each x in **(2..5),**(10..15);
//		print *x;
		print *x x.value;
//		print x.value;
//		print x.index x.value;
	end loop;

//	print *a *('A'..'Z') ;

	return ERROR;
end proc;
