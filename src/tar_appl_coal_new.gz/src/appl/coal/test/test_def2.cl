//
def global a = 'G';
def a = 'P';
def array char(10) aa;
def array bb;
def const c;
sub main;
	print a /i a;
	char a = 'L';
	print a /i a;
	int aa 5 = 1;
	print aa /i aa;
	int bb = 1;
	print bb /i bb;
	int c = 2;
	print c /i c;
	private int aa 5 = 1;
	return ERROR;
end sub;
