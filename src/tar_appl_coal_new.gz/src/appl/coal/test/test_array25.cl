//
//def a[10] = [1,2,3];
//def b[10] = [11,12,13];
def a = $();
def b = $() + 10;
proc main;
	*a = *[1,2,3];
//	setarray(a,*[1,2,3]);
	print a *a;
/*
	*b = *[11,12,13];
	print b *b;
	print append(a,13);
	print a.append(14);
	print "a append 102";
	BEXP x = a append 103 104 105;
	print x a *a;
//	print /d a[0];
	print *{a,a};
	a[0] = b;
//	a[1] = a;
	c = {a,'B'};
	a[1] = c;
	print a *a;
//	print /d a[0];
*/
	return ERROR;
end proc;
