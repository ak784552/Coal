//
def ar[10] = [1,2,3];
proc main;
	a = LIST('A',3.5);
	print a.append(ar);
	print a;
	print a.append([100,200,300]);
	print a;
	print *a;
//	print a.append({10,20,30});
	print a.append({10,20,30},OPT==>0x01);
	print a;
	print *a;
	return ERROR;
end proc;
