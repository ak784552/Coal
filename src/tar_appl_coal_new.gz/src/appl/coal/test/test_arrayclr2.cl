//
define array b 20 = 1;
define array BIN c 20= 10;
define mappedarray $m 11 10;
define mappedarray %p 1 10;
def wc = {1,2,3,4,5,6,7,8,9,10};
proc main;
	print *b;
	print *c;
	print arrayclr(b+2,5,2) *b;
	print arrayclr(c+2,15,2) *c;
	bb=b+2;
	cc=c+2;
	print arrayclr(bb,5,4) *bb *b;
	print arrayclr(cc,0,15,4) *cc *c;
	print arrayclr(cc,15,4) *cc *c;
	print arrayclr(,0,4);
	print arrayclr(NULL,0,4);
	print arrayclr(wc,0,4) wc;
	print arrayclr(wc) wc;
	xc = [];
	print arrayclr(xc,'A',4) xc;

	return ERROR;
end proc;
