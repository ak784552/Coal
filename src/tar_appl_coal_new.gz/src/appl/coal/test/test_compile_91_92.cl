//
def x;
proc main;
	print 'ABCD'.2;
	a = 'XYZ';
	print a.2;
	x = 1;
	for i=1 to 2;
		print x $_y;
		print a.x;
		x++;
		var local $_y=3;
		print f();
	next;
	return ERROR;
end proc;

func f();
	n = 'func';
	return n;
end func;
