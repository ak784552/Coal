//
def a 5 = ['A',2,'C','D','E'];
def type struct ttt
	int aa,
	char bb(3);
var ta as ttt = 10,'XYZ';
proc main;

	print *a;
	print func1(a);
	print *a;
	print func1(*a);
	print *a;

	call proc1 a;
	print *a;
	call proc1 *a;
	print *a;

	b = {1,2,3};
	print b;
	print func1(b);
	print b;
	print func1(*b);
	print b;

	call proc1 b;
	print b;
	call proc1 *b;
	print b;

	c = 1..5;
	print func2(c);
	print func2(*c);
	print func2(**c);

	print *ta;
	print func3(ta);
	print *ta;
	print func3(*ta);
	print *ta;

	return $ERROR;
end proc;

function func1 (x);
	print /i x;
	x[1]++;
	return 0;
end func;

proc proc1(x);
	print /i x;
	x[1]++;
	return 0;
end proc;

function func2 argc argv (x);
	print argc *%argv x /i x;
	return 0;
end func;

function func3(x);
	print /i x;
	x.aa++;
	return 0;
end func;
