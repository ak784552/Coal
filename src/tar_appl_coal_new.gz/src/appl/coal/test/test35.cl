//
proc main;
/*
	print 1+f();
	$(2) = 1;
	print *$();
*/
	print "$('XYZ') &+ '123'";
	return ERROR;
end proc;

func f();
	return 2;
end func;
