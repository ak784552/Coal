//
proc main;

	print 1+f();
	$(2) = 1;
	print *$();

	print "$('XYZ') &+ '123'";

	print to_char(to_number('123.0',CLDEC,8,4));
	print to_char(to_number('123.45',CLDEC,8,4));
	print to_char(to_number('123.45678',CLDEC,8,4));

	print to_char(to_number('123.0',CLDEC,8,3));
	print to_char(to_number('123.45',CLDEC,8,3));
	print to_char(to_number('123.45678',CLDEC,8,3));

	print to_char(to_number('123.45678',CLDEC));

	return ERROR;
end proc;

func f();
	return 2;
end func;
