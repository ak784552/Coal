//
proc main;

	print 1+f();
	return ERROR;
end proc;

func f();
	return 2;
end func;
