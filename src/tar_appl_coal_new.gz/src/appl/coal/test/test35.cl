//
proc main;

	print 1+f();
	$(2) = 1;
	print *$();
	return ERROR;
end proc;

func f();
	return 2;
end func;
