//
Class Test;
	int i=0;
	func Test;
		return 0;
	end func;
	func aaa();
		return i++;
	end func;
	func bbb();
		i=aaa();
		return i++;
	end func;
end class;

proc main;
	c = new Test;
	print c.aaa();
	print c.i;
	print c.bbb();
	return ERROR;
end proc;
