//
define type mappedarray tmb;
dim mb as tmb;
define mappedarray ma;
define array a;
define const array c=[1,2,3];
sub main;
	print c *c;
	print mb;
	mappedarray ma = [1,2,'A',4,5];
	print ma *ma;
	array ma 1 = [11,21,'AB',41,51];
	print ma *ma;
	array a 1 = [33,44,'XYZ',55,66,77];
	print a *a;
	const array c = 4;
	print c *c;
	return ERROR;
end sub;
