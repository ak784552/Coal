//
proc main;
	a = {1,2,3,4,5};
	print f(a) *a;
	return ERROR;
end proc;

class cc;
end class;

func f(a);
	a[2] = 10;
	print a *a;
	return 0;
end func;
