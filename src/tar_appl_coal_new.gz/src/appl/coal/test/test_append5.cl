//
proc main;

	a=[1,2,3,4,5,6];
	print append(a,1,6,3,OPT==>2);
	print a;
	print append(a,'A',OPT==>2);
	print a;
	print append(a,'B',OPT==>2+4);
	print a;

	b=['A','B','C'];
	print append(b,'B',OPT==>2);
	print b;
	print append(b,'b',OPT==>2);
	print b;
	print append(b,'b',OPT==>2+8);
	b=['A','B','C'];
	print append(a,b,OPT==>2)=1;
	print a;

	return ERROR;
end proc;
