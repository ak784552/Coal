//
proc main;
// �֐��̃��X�g
	func_list = [cfloat, cint, cstr];

	x = "10.5";

	for each k in range(0,2);
		print k.value func_list[k.value];
		x = func_list[k.value](x);
	next;
	print(x);
	return ERROR;
end proc;
