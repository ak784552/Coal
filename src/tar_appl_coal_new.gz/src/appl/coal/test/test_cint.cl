//
//
//
proc main;
	print cint(1.5);
	print cint(1.6f);
	print cint('1.7');
	print cdec(123.4567,5,2);
	print cdec(123.4567f,5,2);
	print cfloat(123.4567);
	print cfloat(123.4567);
	print sum(*(1..%1));

	print cint(1.5,2);
	print cint(32767,2);
	print cint('32768',2);

	return ERROR;
end proc;
