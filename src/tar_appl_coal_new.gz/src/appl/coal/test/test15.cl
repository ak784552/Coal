//
proc main;
	private x = 1;
	print func1();
//	x[0] = 1;
	print x;
	print x[0]=1;
	print func1();
	print x[0];
	return ERROR;
end proc;

func func1;
	vari a 10;
//	print a;
	x = a;
//	x[0] = 1;
	return ERROR;
end func;
