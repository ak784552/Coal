
proc main;
	BEXP $1 = %1 CONDAS '//null/'%q';
	print $1;
/*
	$2 = %1 CONDAS '//null/'%q'';
	print $2;
*/
	return ERROR;
end proc;
