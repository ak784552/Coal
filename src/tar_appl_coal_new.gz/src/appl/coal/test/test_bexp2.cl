//
proc main;
//	BEXP 1+2 = 3;
//	print +'1234' -'456.67';
	print +1234 -456;
//	print -123 " + - 87" 123.456e+2;
	return ERROR;
end proc;
