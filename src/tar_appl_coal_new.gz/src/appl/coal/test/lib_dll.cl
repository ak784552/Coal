//
define char args 255;
define global dll hash;
proc main;
	try (fp = fopen('dll.txt','rt'));
		loop 100;
			line = fgetline(fp);
			n = getargs(line,args);
			if n > 0 then
				fn = args[0];
//print fn;
				for (i=1;i<n;i++);
					dll[args[i]] = fn;
//print args[i];
				next;
			end if;
		end loop;
	end try;
	return $ERROR;
end proc;
