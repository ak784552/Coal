//
define type struct s
	aaa,
	bbb;
define var x,y as s;
proc main;
	option 8 2;
	func aaa;
		print 'func aaa';
		return 0;
	end func;
	proc ppp-1;
		print 'proc ppp-1';
		return 0;
	end proc;
	x.aaa = abs;
	print x.aaa(-1);
	print main.aaa() aaa();
	print main&'A';
	x.aaa = y;
	y.bbb = 'Y.BBB';
	print x.aaa.bbb;
	exec ip main.ppp-1;
	return ERROR;
end proc;
