//
define MAX_SOSU	=100000;
define int gFlag;
int sosu MAX_SOSU =
	[ 2,  3,  5,  7, 11, 13, 17, 19, 23, 29,
	 31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
	 73, 79, 83, 89, 97,101,103,107,109,113,
	127,131];
int next_index,max_sosu,cur_sosu;

proc main;
	int i;
	double d,sd,sd2;

	GOSA = 1.0e-7;
	d = 1.0f;
	sd = next_sosu(0);
	for (i=0;i<50000;i++);
		sd = next_sosu(1);
		if sd <= 0 thenl break;
		sd2 = sd * sd;
		d *= sd2/(sd2-1.0f);
		pi_d = sqrt(d*6.0f);
		gosa = abs((PI-pi_d)/PI);
		if gosa <= GOSA thenl break;
		if !mod(i,500) thenl printf 'i=%d sd=%d pi_d=%.10f gosa=%e\n' i sd pi_d gosa;
	next;
	printf 'i=%d sd=%d pi_d=%.10f gosa=%e\n' i sd pi_d gosa;
	return 0;
end proc;

func next_sosu(opt);
	if !opt then
		max_sosu=countv(sosu);
		cur_sosu = next_index = 0;
	elseif next_index < max_sosu then
		cur_sosu = sosu[next_index++];
	else
		loop;
			cur_sosu += 2;
			if ret=sosu_chk_by_tbl(cur_sosu) then
				break;
			end if;
		end loop;
		if ret > 0 then
			if max_sosu < MAX_SOSU then
				sosu[max_sosu++] = cur_sosu;
				next_index = max_sosu;
			else
				cur_sosu = -3;
			endif;
		else
			cur_sosu = ret;
		end if;
	end if;
	return cur_sosu;
end func;

func sosu_chk_by_tbl(l);
	dim i,mmax,m as int;
	dim ll,l1,l2 as int;

	mmax=max_sosu;
	if (!(sosu)) thenl return -1;
	ll = l;

	if (ll < 2) then return 0;
	elseif (ll == 2) then return 1;
	elseif (ll <= 7) then
		if (ll&0x01) thenl return 1;
		return 0;
	end if;
	l2 = (CINT)sqrt(ll);
	for (i=0;i<mmax;i++);
		if (!(ll % (m=sosu[i]))) then
			break;
		endif;
		if (m > l2) thenl break;
	next;
	if (i>=mmax) then
		return -2;
	elseif (m>l2) thenl return 1;
	return 0;
end func;
