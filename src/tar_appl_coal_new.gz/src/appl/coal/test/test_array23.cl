//
def array a 10 = [11,12,13,14,,16,17,18,19,20];
def mappedarray %c [2,10];
proc main;
	print *a;
	print a[4];
	p = %();
//	q = %c;
//	print p q %c;
	print "p[1] = 10";
	print "q[1] = 20";
	print p[1] *%();
	print /d p %c %() %1;
	%1 = 1;

	return ERROR;
end proc;
