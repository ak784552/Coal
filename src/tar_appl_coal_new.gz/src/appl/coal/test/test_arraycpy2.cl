//
define array a 10 = [4,2,1,5,3,'E','D','A','C','B'];
define b 10;
proc main;
	print arraycpy(b,a,7);
	print b *b;
	print arraycpy(b,1);
	print b *b;
	print arraycpy(b,[1,2,3]);
	print b *b;
	print arraycpy(b,);
	print b *b;
	return ERROR;
end proc;
