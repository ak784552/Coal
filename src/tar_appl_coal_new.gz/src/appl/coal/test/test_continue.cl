//
PROC main;
	$i=0;
//	continue;
//	break;
	loop(10);
		$x=$i;
		if $x mod 2; $i++; continue; endif;
		print $i $x;
		$i++;
	end loop;
	RETURN( $ERROR);
END PROC;
