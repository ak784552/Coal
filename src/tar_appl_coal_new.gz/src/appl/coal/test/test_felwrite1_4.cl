//
proc main;
	$fp = fopen('a','wb');
	print $ERROR $ERRMSG;
	$a = 'ABCDEF';
	$b = -100;
	$c = 12.4D;
	$d = -25.3;
	$e = to_bulk($a);
/*
	print felwrite1($fp,$a,,7);
	print felwrite1($fp,$b,,9);
	print felwrite1($fp,$c,,9);
*/
	print felwrite1($fp,$d,,4);
//	print felwrite1($fp,$e,,7);
	$r = fclose($fp);
	$fp = fopen('a','rb');
	print $ERROR $ERRMSG;
/*
	$aa = felread1($fp,1,6,6);
	$bb = felread1($fp,2,,4);
	$cc = felread1($fp,3,,8);
*/
	$dd = felread1($fp,4,30,4);
//	$ee = felread1($fp,5,6,6);
	print $a $aa $b $bb $c $cc $d $dd $e $ee;
	fclose($fp);
	return $ERROR;
end proc;
