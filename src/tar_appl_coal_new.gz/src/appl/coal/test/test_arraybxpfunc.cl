//
define array a 10 = ['%A%','%C%','%C%','%','%F%'];
define array b 10 = [1i,2,3,4,5,'AB','BC','CD','DE','EF'];
define array BIN c 10 = [1i,3,2,7,5,6,4,9,10,8];
def wc = {1,2,3,4,5,6,7,8,9,10};
define array r 10;
proc main; 
/*
	print 1i+1i;
	print arraybxp(r,b,c,1,'+');
	print *r;
*/

	print arraybxp(r,b,c,5,lambda('a,b','a+b'));
	print *r;
	print arraybxp(r,b+5,a,5,like);
	print *r;

	print arraybxp(r,b,c,5,max);
	print *r;

	return ERROR;
end proc;
