//
proc main;
Class Counter;
	int i=0;
	f = _count;
	x = new(XXX);
	func Counter;
		print f x x._X();
		return f;
	end func;
	func Counter(a);
		return 0;
	end func;
	func _count();
		return ++i;
	end func;
	Class XXX;
		int xx=200;
		func XXX;
			return 0;
		end func;
		func _X;
			print xx;
			return 2000;
		end func;
	end class;
end class;

	c = new(Counter);
	print c /d c;

	print c();
	print c();
	y = new(Counter,0);
	print y /d y;
	print y.XXX /d y.XXX;
	print y.x /d y.x;
	print y.XXX._X() y.x._X();

	return ERROR;
end proc;
