//
proc main;
	$i = 0;
	loop 3;
		print 'loop1' $i;
		loop 2;
			print 'loop2' $i;
			if $i == 1;
				print 'break';
				break;
			end if;
			$i++;
		end loop;
	end loop;
	return $ERROR;
end proc;
