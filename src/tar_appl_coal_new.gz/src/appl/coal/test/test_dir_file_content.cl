//
define int dp=0;
define int fp=0;
proc main;
	dir = %1;
//	try (dp = opendir(dir));
	if dp = opendir(dir) then
		while file=readdir(dp) do
			if ERROR thenl break;
print file;
			if right(file,3)=='log' then
//				try;
					if fp = fopen(dir & '/' & file) then
						loop do;
							line = fgetline(fp);
							if ERROR thenl break;
							putline(line);
							if ERROR thenl break;
						end do;
						fclose(fp);
					end if;
/*
				catch FILE_READ_END_EXCEPTION;
				catch;
					print 'in catch' ERRMSG /x EXCEPTION;
				finally;
					if fp thenl fclose(fp);
				end try;
*/
			end if;
		end do;
/*
	catch FILE_READ_END_EXCEPTION;
	catch;
		print 'out catch' ERRMSG /x EXCEPTION;
	finally;
		print 'Finally' /x EXCEPTION;
	end try;
*/
		closedir(dp);
	end if;
	print ERRMSG /x EXCEPTION;
	return ERROR;
end proc;
