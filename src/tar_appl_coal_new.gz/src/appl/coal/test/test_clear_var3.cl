//
def public pp = 'PUB';
def private ss = 'PRV';
proc main;
	$1 = 'DOL';
	print 1 pp ss;
	exec sc test_clear_var3_sub;
	print 2 pp ss;
	exec sc test_clear_var3_sub;
	print 3 pp ss;
	return ERROR;
end proc;
