//

define array w 10;
proc main;
	double d = 123.456;
	print func1('','10+2',30.3456,d,w) ERROR;
	print (dec)'10+2';
	return $ERROR;
end proc;

function func1 argc argv (const char aa, bb, cc, dd, ww)as char;
	implicit dec(10,2) (b);
	implicit int (c);

	print /i aa bb cc dd ww;
	print  aa bb cc dd;
	return 0;
end func;
