//
define N = 'ZZZ';
define xxx (10);
//define $$N [10];
define $($N) [10];
//define $$% (1);
//define ($%1) [5];
//define ZZZ;
//define ZZ;
//define aa[5]=f(1),f(2);
sub main;
	print xxx;
//	print ZZ;
	print $$N "$% (1)" $$%(1);
	private array aa[5]=f(1),f(2);
	print *aa;
	print f2() f2();
	return ERROR;
end sub;

func f(a);
	return a*2;
end func;

func f2();
	print $$N;
	return 0;
end func;
