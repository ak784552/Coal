//
//static int x  = 1;
char(5) cc;
proc main;
	aaaa('A');
	print ia;
	aaaa('B');
	return ERROR;
end proc;

func aaaa(a);
	print a;
	static int ia = 1;
	ia = ia + 10;
	print ia;
//	redef static w = 0;
	static Sxa 5 = 1;
	static int Sx;
	print Sxa[0]++ Sx++;
	return ERROR;
end func;
