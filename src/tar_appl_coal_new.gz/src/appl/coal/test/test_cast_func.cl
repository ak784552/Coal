//
proc main;

	print CCHAR(1) CBIN('2') CDOUBLE(3) cchar(4.5) cstring(4.5);
	print CSTR(123.4567);
	print CCHAR('123456789012345',10);
	print CINT('1')+2;
	print CBIN('1346');
	print CLONG('9999');
	print CLNG('888888');
	print CFLOAT('12.345');
	print CFLT('12.345');
	print CDOUBLE('12.345');
	print CDBL('12.345');
	print CDEC('12.345');
	print CDEC('12.345',,2);
	print CDEC('12.345',10,);
	print CDECIMAL('123456789.012345',15,2);
	print CBULK(1) CBULK(1234567890);
	print CDATE('');
	print CDATE('2021/01/05','YYYY/DD/MM');
	print CVARI('12.345');
	print CVARIANT(12.345);
	print ff('ABS')(-10);
	return ERROR;
end proc;
