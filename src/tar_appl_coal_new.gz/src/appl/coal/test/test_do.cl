//
proc main;

	do as do1;
		do as do2;
			break %1;
			print 'do2';
		end do;
		print 'do1';
	end do;

	$i = 0;
	do;
		$i++;
		print 'do1_1 $i=' $i;
		do;
			$i++;
			print 'do2_1 $i=' $i;
			break %1;
			continue %2;
			$i++;
			print 'do2_2 $i=' $i;
		end do;
		$i++;
		print 'do1_2 $i=' $i;
	end do;

	return $ERROR;
end proc;
