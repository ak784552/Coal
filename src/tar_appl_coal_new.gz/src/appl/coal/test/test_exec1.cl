//
proc main;
	call <<EOF1;
11111
2222
EOF1
	exec ip ppp 'XX' <<EOF2;
aaa
bbb
ccc
EOF2
	putline('main:1');
	line = getline();
/*
	loop 4;
		line = getline();
		if ERROR; break; endif;
		putline(line);
		exec sc test_getline;
/*
		exec sc test_getline <<EOF3;
xxxx
yyyyyyy
EOF3
*/
	end loop;
*/
	call <<EOF4;
33333
444444
EOF4
	exec sc test_getline <<EOF5;
xxxx
yyyyyyy
zz
EOF5
	putline('main:2');
	line = getline();
	putline(line);
	return ERROR;
end proc;

proc ppp(a);
	putline('called ppp a=',a);
	loop 4;
		line = getline();
		if ERROR; break; endif;
		putline(line);
	end loop;
	return ERROR;
end proc;
