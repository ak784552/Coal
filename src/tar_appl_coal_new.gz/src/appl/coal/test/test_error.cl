//
proc main;
//	print /x getval('OPTION',30);
	exec ip func1;
	a = funcf();
	print a;
	return $ERROR;
end proc;

proc func1;
//	1/0;
	return $ERROR;
end proc;

func funcf;
	1/0;
	return 'A';
end func;
