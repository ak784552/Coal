//
import 'lib_math' as LIB_MATH;
proc main;

	print sin(PI/2.0);
	print f();
	print MATH.fff();

	x = abs;
	print x(10);
	print LIB_MATH.sind(30d);
	print LIB_MATH.x(30d);
	print LIB_MATH.$x(30d);
	print LIB_MATH.x;
	print LIB_MATH.PI_180;
	return ERROR;
end proc;

func f();
	return 'func f';
end func;
