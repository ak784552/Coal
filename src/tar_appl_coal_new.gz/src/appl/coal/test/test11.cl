//
/*
define MAX_SOSU	=100000;
define int gFlag;
*/
define aa 10;
proc main();

	print [*(2..5)];
	b = [*(2..5)];
	print b /i b;
	print [*('2'..'5')];

	a = '2'..'5';
	print a *a;
	a = '3'..'';
	print a *a;
	a = ''..'4';
	print a *a;
//	a = 2..5;
//	print a *a;
	
	print abs*10;

	return ERROR;
end proc;
