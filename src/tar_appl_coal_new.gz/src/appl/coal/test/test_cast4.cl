//
proc main;

//	print log(1.2345e42)/log(100.0f);
	print (DEC(%1,%2))%3;
	print (DEC)%3;
	print (%4)(%3);
//	$1 = 'cbrt';
//	print ($1)(%3);
	$1 = 'abs';
	print ff($1)(%3);
	print ff(%4)(%3);
	a = (CINT)'123';
	print a;
	print (cbrt)(1000.0);
	print ('cchar')(1000.0);
	print (DOUBLE(10))%3;

	a = (dec)%3;
	print a /i a;
	d = (double)a;
	print d /i d;
//	print 1.2345E20;
//	printf '%e\n' 1.234567890123456789e20;
	return ERROR;
end proc;
