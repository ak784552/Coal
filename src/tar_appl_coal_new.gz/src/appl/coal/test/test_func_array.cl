//
define type struct z
	int a (5, 3, 2)
	,char(5) b
	, dec(10,2) c 10,
	bulk(20) d
	,double e hash
	, variant f
	, g
;
define type array char za 10 7;
define type mappedarray zm [2,( 4), 6];
define array a 10;
define mappedarray ma 1 10;
define var zx as z;
proc main;
	print a[];
	print a[a];
	print a[max];
	print abs(a);
	print abs(max);
	print abs(max());
	print getargs('1 2 3 4 5 6',a,6);
	print a[{1,2}];
	print a[main];
	print a[cc];
	ii = new cc();
	print a[ii];
	print a[z];
	print a[za];
	print a[zm];
	print a[zx];
	print a[ma];
	print f(a) *a a[6];
	return ERROR;
end proc;

class cc;
end class;

func f(a);
	a[6] = 10;
	print a *a;
	return 0;
end func;
