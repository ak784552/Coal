//
//define array aa[10] = 1..10;
define array aa[-2..7] = [1,2,3,4,5];
define array hh hash;
typedef struct TTT
	char ccc,
	int  iii,
	dec(10,2) ddd;
TTT tt;
proc main;

	a = 2.5..4i;
	print getval(a,1) getval(a,2) getval(a,3);
	print getval(a,'Real') getval(a,'Image') getval(a,'XXX') getval(a,'');
	print getval(a,'Image',0x04);

	b = {1,2,3,4};
	print getval(b,1) getval(b,4) getval(b,5) getval(b,'Image');

	cc = 1.5..3.5;
	print cc;
	print getval(cc,1) getval(cc,2) getval(cc,3) getval(cc,'Image');
	print getval(aa,0) getval(aa,5) getval(aa,-1) getval(aa,10);
//	print getval(aa,5);
//	print aa[5];
	print aa hh;
	print tt;

	hh['AAA'] = 3.0;
	print getval(hh,'AAA') getval(hh,'XXX');

	$1 = 'XYZ';
	$2 = 'ABC';
	print getval($(),0) getval($(),2) getval($(),65536);

	tt.ccc = 'TEST';
	tt.iii = 100;
	tt.ddd = 12345.67;
	print getval(tt,'iii') getval(tt,'xx');
	print getval(tt,1) getval(tt,1,0x02);
	print getval(tt,2) getval(tt,2,0x02);
	[atr,typ,size,pre,sca] = getval(tt,'ddd',0x04);
	print atr typ size pre sca;

	return $ERROR;
end proc;
