//
//option 20 20;
proc main;
	a = to_date('2023/04/16 23:26:12','YYYY/MM/DD hh:mi');
	b = to_date(SYSDATE,'YYYY/MM/DD hh:mi');
	print a (CBULK)a;
	print b (CBULK)b;
	print a>b a<b a==b;
	return ERROR;
end proc;
