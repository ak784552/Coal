//
//def image i;
def complex int aa;
proc main;

	print complex(1,2i);
	print complex(1i,2);
	print complex(1i,2i);
	print complex('1','2i');
	print complex('1i','2');
	print complex('1i','2.0i');
	print complex('1.0i','2i');
	print complex('1+2i','2i');

	print 0+'1+2i';
	print 0+eval('1+2i');

	print cimg(10);
	print cimg('10');
	print (cimg)10;
	print (cimg)'10';
	print 10.0..cimg(20);
	print (cint)'10';
	print cimg(10+20i);
	print cimg(SYSDATE);

	print aa /i aa;
	a = (cdbl)(1+2i);
	print a /i a;
	a = (dec(3,1))(1+2i);
	print a /i a;
	a = 1.2;
	print a /i a;
	b = cdbl(1..2);
	print b /i b;

	print (2+1i)+3 aa+5;

	print 2..0I;
	print 2..5r;

	return $ERROR;
end proc;
