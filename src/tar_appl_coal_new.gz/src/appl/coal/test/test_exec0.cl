//
proc main;
	call <<EOF1;
11111
2222
aaa
bbbbbbbbbb
ccc
EOF1
	exec ip ppp <<EOF2;
xxxx
yyyyyyy
zzzz
EOF2

	loop 10;
		line = getline();
		if ERROR; break; endif;
		putline(line);
	end loop;

	return ERROR;
end proc;

proc ppp(a);
	putline('called ppp a=',a);
	loop 4;
		line = getline();
		if ERROR; break; endif;
		putline(line);
	end loop;
	return ERROR;
end proc;
