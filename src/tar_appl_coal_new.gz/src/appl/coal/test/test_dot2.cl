//
proc main;

	'BBBB'.f2('CCC');
	print (-1).abs();
	print (-1).(abs(2));	// '-2'.2
	print 'abs'.ff()(-3);
	print 'abs'.f(-3);
	print (-10).('abs'.ff())();
	x = -10;
	print x.abs();
//	x = sin(1.0);
//	print asin(x);
//	print asin(sin(1.0));
	print 1.0.sin().cos().tan();
	print log(-1.0);

	return ERROR;
end proc;

func f(x,y);
	return ff(x)(y);
end func;

func f2(x,y);
	print x y;
	return 0;
end func;

