//
//	%1=U8_EX4_WDK
//
import lib_iconv;
proc main;
	option 11 4;
	try;
		fp = fopen(%1,'rb');
		try;
//			loop 2 do
			loop do
				a1 = felread1(fp,1,2);
				a = conv(a1,leng(a1));
				d1 = felread1(fp,4,3,0);
				d2 = felread1(fp,4,9,0);
				d3 = felread1(fp,4,3,0);
				d4 = felread1(fp,4,9,0);
				d5 = felread1(fp,4,3,0);
				d6 = felread1(fp,4,9,0);
				d7 = felread1(fp,4,11,0);
			//	print /i a d1 d2 d3 d4 d5 d6 d7;
				putline(edit('%2s %3d %9d %3d %9d %3d %9d %9d',a,d1,d2,d3,d4,d5,d6,d7));
			end do;
		finally
			fclose(fp);
		end try;
	catch FILE_READ_END_EXCEPTION;
	catch;
		print ERROR ERRMSG;
	end try;
	return ERROR;
end proc;
/*
function conv(a,len);
	array x 1;
	exec sc pconv:lib_iconv x a len;
	return x[0];
end func;
*/
