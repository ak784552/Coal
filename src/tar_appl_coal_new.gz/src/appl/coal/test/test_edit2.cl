//
PROC main;
	$a = '2000/04/20';
	$b = to_bulks($a);
	print edit('%s',$b);
	print edit('%r',$b);
	print edit('%r %r',1234,12345U);
	print edit('%r %r',1.0e-5,1.0e-1);
	print edit('%g %g',1234,123.45D);
	print /i 123.45D;
	RETURN $ERROR;
END PROC;
