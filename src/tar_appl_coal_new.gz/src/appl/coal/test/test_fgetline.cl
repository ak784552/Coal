//
proc main;
//	a=b;
print %0;
	try;
		fpr = STDIN;
		fpw = STDOUT;
		if %0 >= 1 then
			fpr = fopen(%1,'r');
			if %0 >= 2 then
				fpw = fopen(%2,'w');
			endif;
		end if;
		loop;
			a = fgetline(fpr);
//			print $a;
			fputline(fpw,a);
			$10 = 0;
			$n = getargs($a,1,10,,',');
//			$n = getargs($a,1);
//			print $n;
/*
			$i = 1;
			loop $n;
				print $i $$i;
				$i++;
			end loop;
*/
		end loop;
	catch FILE_READ_END_EXCEPTION;
	catch;
		print ERRMSG;
	finally;
//		print ERRMSG;
	end try;
	return $ERROR;
end proc;
