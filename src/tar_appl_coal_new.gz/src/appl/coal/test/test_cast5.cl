//
proc main;
	f1 = (FUNC)'{func _salute1(s);
	print /nq- s&'' World!!'';
	return 0;
end func;}';
	f2 = (FUNC(1))'{func _salute1(s);
	print /nq- s&'' World!!'';
	return 0;
end func;}';
	print f1('Hellow');
	print f2('Good night');
ptree();
	return ERROR;
end proc;
