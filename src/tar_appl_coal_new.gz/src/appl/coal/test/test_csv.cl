//
proc main;
	try (fp=fopen('table.csv'));
		n = getargs(fgetline(fp),1);
		for each x in $();
			print /n x.value;
		next;
	catch;
		print ERRMSG;
	end try;
	return ERROR;
end proc;
/*
proc main;
	try;
		loop;
			line = getline(,0x07);
			n = getargs(line,1,,,',');
print line n;
			for (i=1;i<=n;i++) do
				print $$i;
			end do;
		end loop;
	catch;
		print ERRMSG;
	end try;
	return ERROR;
end proc;
*/
