//
define a 3=[1,2,3];
define b 5=[1,2,3,4,5];
define bb 4=[2,3,4,6];
define aa 3=[1,2,3];
def mappedarray %ma 1 10;
define type struct z
	int a
	,char(5) b
;
define var az,bz as z;
proc main;

	c = [1,2];
	d = [1,2];
	print [1,2]==[1,2];
	print [1,2]<=[1,3];
	print {'A',1.5}=={'A',1.5};
	a1 = {'A',1.5};
	a2 = {'A',1.5,0};
	print a1==a2;
	print [1,2]=={1,2};
	print a==b;
	print *a==*b;
	print a==aa;
	print *a==*aa;
	x = a;
	print a==x a x;
	print az==bz az bz;
	print arraycmp(c,,d);
	print arraycmp(c,,d,,0);
	print arraycmp(a,,b,,2);
	print arraycmp(a,,b,,0);
	print arraycmp(b,,c);
	print arraycmp(b,1,bb);
	print arraycmp(b,1,bb,,3);
	print arraycmp(a1,,a2);
	print arraycmp(a1,1,a2,1);
	print arraycmp(a1,2,a2,2);
	print arraycmp(a1,,a2,,1);
	print arraycmp('123',,'123');
	print /i ma %();
	print arraycmp(%ma,,%());
//	$10 = 1;
//	print arraycmp('1',,'1') *$();
	print arraycmp(abs,,a2);
	print arraycmp(a1,,abs);
	print arraycmp(a,,b,,2,'like');
	print arraycmp(a,,b,,2,'xxxx');

	a1 = {'A',1.5,a};
	a2 = {'A',1.5,b};
	a[2] = a1;
	b[2] = a2;
	print arraycmp(a,,b);
	print arraycmp(a1,,a2);
	a1[2] = a1;
	a2[2] = a2;
	print arraycmp(a1,,a2);
	return ERROR;
end proc;
