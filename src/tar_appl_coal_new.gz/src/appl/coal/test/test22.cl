//
// �������\
//
proc main;
	print 'ABCDEFG';
	print 'ABCD\EFG';
	print 'ABCD\0EFG';
	print '\0';
	i = 1;
	i = i;
	return ERROR;
end proc;
