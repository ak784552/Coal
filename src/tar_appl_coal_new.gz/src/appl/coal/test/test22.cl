//
// �������\
//
proc main;
/*
	print 'ABCDEFG';
	print 'AB\\CD\EFG';
	print 'ABCD\0EFG';
	print '\0';
	i = 1;
	i = i;
*/
	print `print 'ABC'`;
//	print 'XYZ';
	return ERROR;
end proc;
