//
proc main;
//	$a = '1 ,2, 3 , 4 ''5 6''';
	$a = '|2| 3 , 4 ''5 6''';
//	$a = 'asd:=,123 rr,sss:=ggg';
	print $a;
	$10 = 0;
//	$n = getargs($a,1,10,,',');
	$n = getargs($a,1,10);
//	$n = getargs($a,1);
//	$n = getargs($a,1,0);
//	$n = getargs($a,1,257);
	print $n;

	$i = 1;
	loop $n;
		print $i $$i;
		$i++;
	end loop;

	$a = '1,2,3,4,5,6,7,8,9,10,11,12';
	$n = getargs($a,65531,10);
	print $n;

	return $ERROR;
end proc;
