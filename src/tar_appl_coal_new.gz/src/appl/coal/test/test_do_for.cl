//
define array s 10;
define array d 10;
proc main;
//	s = $() + [1,10];
//	d = $() + [11,10];
	setarray(s,0,1,2,3,4,5,6,7,8,9,10);
	do; for (i=0;i<10;i++);
		d[i] = s[i];
		print i d[i] s[i];
	next;
	end do;
	return $ERROR;
end proc;
