//
##define MAX_SOSU 32
int sosu MAX_SOSU =
	[ 2,  3,  5,  7, 11, 13, 17, 19, 23, 29,
	 31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
	 73, 79, 83, 89, 97,101,103,107,109,113,
	127,131];
proc main;
	log2 = log(2.0);
	for n=1 to MAX_SOSU;
		ss = sosu[n-1];
		a = 2*n;
		b = 7*log(ss)/log2;
		print n ss a b;
	next;

	for n=1 to MAX_SOSU;
		ss = sosu[n-1];
		c = 12+2*(log10(ss)*0.5+1);
		a = c*n;
		b = (7+c)*log(ss)/log2;
		print n ss a b;
	next;
	return ERROR;
end proc;
