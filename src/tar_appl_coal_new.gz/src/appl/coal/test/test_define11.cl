//
//int x 5 = [1,2,3];
char(5) cc;
proc main;
	char(5) aa;
//	local a;
	variant name;
	aaaa('A');
	aaaa('B');
	return ERROR;
end proc;

func aaaa(a);
	int $(a)[2]=[1,2];
	print A B *A *B;
	var x as char='X';
	print x /i x;
	return ERROR;
end func;
