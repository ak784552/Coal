//
// Collatz
//
proc main;
	if (%0 < 1);
		fputline(STDERR,'usage: ',SCRIPTNAME,' number(from) [(To) [(Incr)]]');
		return -1;
	end if;
	n_f = (long)%1;
	n_t = n_f;
	n_i = 1;
	if %0 >= 2 Then
		n_t = (long)%2;
		if n_t < n_f thenl n_i = -1;
	end if;
	if %0 >= 3 Then
		if !(n_i = (long)%3) then
			n_i = n_t >= n_f ? 1 : -1;
		end if;
	end if;
	for i=n_f to n_t step n_i;
		n = i;
		printf '(%d)' n;
		while n > 1;
			n = n % 2 ? n*3 + 1 : n/2;
			printf ' --> %d' n;
		end while;
		print;
	end for;
	return ERROR;
end proc;
