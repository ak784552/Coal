//
proc main;
	sc_nam = 'test_$%#.cl';
	exec sc $sc_nam 1 2 3;
	return ERROR;
end proc;
