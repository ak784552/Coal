//
option 13 +0x400;
proc main;
	try(fpi=fopen(%1,'r'));
		if %2=='' then
			fpo = STDOUT;
		else
			fpo=fopen(%2,'w');
		endif;
		loop;
			a = fgetline(fpi,,,5,-1);
		//	a = fgetline(STDOUT,,,,5);
			print a /i a;
			print /x a;
			fputline(fpo,a);
		//	fputline('x',a);
		//	fputline(STDIN,a);
		end loop;
	catch FILE_READ_END_EXCEPTION;
	catch;
		print ERRMSG ERROR ERRNO;
	finally;
	end try;
	return $ERROR;
end proc;
