//
proc main;
	a = 'a';
	b = 'b';
	print decode(%1,'A',a,'B',b,'','NULL','x');
	print decode(%1,'A',a,'B',b,3,3);
	return $ERROR;
end proc;
