//

typedef struct TTT
	int x,
	char y,
	dec z[5];
TTT tt = [123,'XYZ',2.5,3.2,4.8];
//TTT tta[3] = [444,'DKSA',2.2,3.5,4.4,5.0,6.6,555,'KKK',7.7,8.8,9.9];
TTT uu;
def int aa[10];
proc main;

	print '�\���̔z��';
	private TTT tta[3] = [444,'DKSA',2.2,3.5,4.4,5.0,6.6,555,'KKK',7.7,8.8,9.9];
/*
	print tta;
	print *tta;
	print /i tta;
	print /i *tta;
*/
	print "tta[0] = 9999";
/*
	print "tta[2] = 666";
	print "aa = 1";
	print "TTT = 0";
	print "tt = 1";
	print "uu = 2";
*/
	return $ERROR;
end proc;
