//
##include class_sosu_chk.cl

proc main;
	int nn = %1;
	if !nn thenl nn=100;
	n0=2;
  try;
	sch = new SosuCheck();
	for k=6 to nn step 2;
		i=1;
		k2 = k / 2;
		printf '%5d = ' k;
		loop;
			s = sch.get_sosu(i++);
			if s < 0 then
				return 0;
			elseif s > k2 then
				break;
			end if;
			m = k - s;
//print k i s m;
			if ((ret=sch.sosu_chk_by_tbl_opt(m))>0) then
				printf '%2d+%2d, ' s m;
			elseif ret<0;
				break;
			end if;
		end loop;
		print;
	next;
  catch;
	print ERRMSG;
  end try;
	return ERROR;
end proc;
