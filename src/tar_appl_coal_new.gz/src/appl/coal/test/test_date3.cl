//
//option 20 20;
proc main;
	print (DATE)0;
	print (DATE)'0000/01/01';
	print (DATE)'2025/01/16';
	print (DATE)'2024/13/33';
	print (DATE)'2024/02/30';
	return ERROR;
end proc;
