//
define a 10 = [1,2,3/*,4,5*/];
define b 4 = ['A'/*,'B','C','D'*/];
define c 3 = ['X','Y','Z'];
proc main;

	a[1] = {10,20,30};
//	a[3] = ['X','Y','Z'];

	echo '---a,b';
	for each x in a,b;
		print *x;
	next;

	echo '---a';
	for each x in a;
		print *x;
	next;
	echo '---[10,b,20,c]';
	for each x in [10,b,20,c];
//		print /r- *x;
		print x.Index *x.Value;
	next;
	echo '---*[10,b,20,c]';
	for each x in *[10,b,20,c];
		print /r- *x;
	next;
	echo '---3..6';
	for each x in 3..6;
		print *x;
	next;
	echo '---3..6,''A''..''C''';
	for each x in 3..6,'A'..'C';
		print *x;
	next;
	echo '---[3..6,''A''..''C'']';
	for each x in [3..6,'A'..'C'];
		print x.value *x;
	next;
	echo '---*[3..6,''A''..''C'']';
	for each x in *[3..6,'A'..'C'];
		print *x;
	next;
	echo '---[*(3..6),*(''A''..''C'')]';
	for each x in [*(3..6),*('A'..'C')];
		print x.value *x;
	next;

	return ERROR;
end proc;
