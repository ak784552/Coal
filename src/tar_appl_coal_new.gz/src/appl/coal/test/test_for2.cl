//
define array $a hash 5;
PROC main;
	$a['A'] = 1;
	$a['B',,'C'] = 2;
	print $a['A'] $a['B',,'C'];
	$i=0;
	loop 2;
		$x=$i;
		loop for " " "$x < 3" $x++;
			print '  for' $x;
			loop each $y in $a;
				print '    ' $y.Value $y.Index;
			end loop;
		end loop;
		$i++;
	end loop;
	RETURN $ERROR;
END PROC;
