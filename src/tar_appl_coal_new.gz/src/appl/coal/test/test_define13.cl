//
rational ra ;//= 3/2r;
//rational int ira;
//rational dec(10,3) dra;
rational dec dra = 3.1/2.3r;
rational raa[10] = [3/2r,2.5/2r,3.5/5r,1/2r] ;
int x[10] = [1,2,3,4,5];
complex rcc 10;
complex int cc;
proc main;

//	print ra /i ra;
//	print ira /i ira;
	print dra /i dra;
	print raa raa[0] *raa;
	print rcc /i cc;
	ra = 3;
	print ra /i ra;
	xra = dra + ra;
	print xra /i xra;
	print x *x;

//	print (1..2)+(3..4);
	print 3r rational(5) rational(5r) rational(5,3r);
//	a = rational(1,2);

	a = 2/4r;
	print a;
	printf('a = %r a = %f\n',a,a);
//	b = rational(3,4);
	b = 3/4r;
	print b;

//	print rational(1,2)+rational(3,4);
	c = a + b;
	print c;
	print a-a;

	print a*b *(a*b);

	print a/b;
	print a/0;
	print "a % b";
	print 3.5/5r;
	print 3.5r/5;
//	print 10/3*3 *(10r/3*3) 10./3*3;
	print rational('5.7','8.3');

	print a-b b-a getval(a-b) getval(b-a,3) getval(b-a,'v');

	print (2/3r)**2 (2/3r)**(-2) (2/3r)**0 (1r)**2 (-1r)**2 (-1r)**3;
//	print SUM(1.25,0.7,0.5);
//	print SUM(2.5/2r,3.5/5r);
	print SUM(2.5/2r,3.5/5r,1/2r);
	print MAX(2.5/2r,3.5/5r,1/2r);
	print MIN(2.5/2r,3.5/5r,1/2r);
	print PRODUCT(2.5/2r,3.5/5r,1/2r);

//	print MAX(3/2r,5/2r);
//	print MIN(5/2r,3/2r);

	print a++ a--;
	print ++b --b;

	print a+1 a-1;

	print a>b a<b;

//	print a b;
	print a..b;

	print abs(-2/5r);

	print to_char(-2/5r);
	print to_number(-2/5r,3);
	print 2/5r+1i;

	$d = -25.3/10r;
	$dd =  100.0/4r;
	print d dd;

	$c = -10000/100r;
	$cc =  100/10000r;
	print c cc;

	$e = -1000/100r;
	$ee =  100/1000r;
	print e ee;
//	print reduction(e);

	$f = -50/5r;
	$ff =  5/50r;
	print f $ff;

	print rational(LONG_MAX-2,LONG_MAX-1);

	print SUM(raa);
	print MAX(raa);
	print MIN(raa);
	print PRODUCT(raa);

	return ERROR;
end proc;
