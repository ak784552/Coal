//
def const global d = 4;
def type struct aa
	int a,
	char c;
proc main;
	redef const global d = 444;
	print d /i d;
	aa = 1;
	return ERROR;
end proc;
