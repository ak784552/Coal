//
proc main;

	for each x in 'A','B','C';
		print x.Index x.Value;
	next;

	for eachv x in 'A','B','C';
		print x;
	next;

	for eachi x in 'A','B','C';
		print x;
	next;

	option 22 1;

	for each x in 'A','B','C';
		print x;
	next;

	for eachv x in 'A','B','C';
		print x;
	next;

	for eachi x in 'A','B','C';
		print x;
	next;

	return ERROR;
end proc;
