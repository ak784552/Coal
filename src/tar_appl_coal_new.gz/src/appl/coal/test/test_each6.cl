//
define array a hash = ['AA',100,'BB',200,'CCC',300];
proc main;

	for each x in 'A','B','C',,'E';
		print x.Index x.Value;
	next;

	for eachv x in 'A','B','C';
		print x;
	next;

	for eachi x in 'A','B','C';
		print x;
	next;

	option 22 1;

	for each x in 'A','B','C';
		print x;
	next;

	for eachv x in a;
		print x;
	next;

	for eachi x in a;
		print x;
	next;

//	print to_dnara(`f1(a)`);
//	print `f1(a)`;
	print `for eachi x in a;echo x;next;`;

	print *sort(0,getval(*a,'I'),,'C',1,'D');
	print *$();

	return ERROR;
end proc;

func f1(a);
	for eachi x in a;
		echo x;
	next;
	return 0;
end func;
