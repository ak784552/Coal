//
def x 10;
proc main;

	a = [1,2,3,4,5];
	print a[i] for i=0 to 4;
	a.print();
	for eachv x in a;print x;next;

	print [1,2,3,4,5][1];
	print [][0];
	print ()[0];
	print ();
	print [];

	x[0] = a;
	print x[0][1];

	print fff(1)[1];

	return ERROR;
end proc;

func fff(a);
	return [10,20];
end func;
