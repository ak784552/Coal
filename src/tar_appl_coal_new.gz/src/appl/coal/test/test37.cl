//
proc main;
	a = [1,2,3,4,5];
	print a[i] for i=0 to 4;
	a.print();
	for eachv x in a;print x;next;
	return ERROR;
end proc;
