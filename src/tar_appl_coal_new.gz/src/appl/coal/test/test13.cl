//
proc main();
	print gettime(0);
	loop %1;
//		a = 'XXXX';
		f();
	end loop;
	print gettime(0);
	return ERROR;
end proc;

func f();
	x = 'AAA';
//	print x;
	return ERROR;
end func;
