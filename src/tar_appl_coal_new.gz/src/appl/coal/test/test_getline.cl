//
proc main;
	try;
		loop;
			printf('test_getline Enter:');
			a = getline('12345','10','3');
//			print $a;
			putline(a);
			$10 = 0;
			$n = getargs($a,1,10,,',');
//			$n = getargs($a,1);
			print $n *$();
/*
			$i = 1;
			loop $n;
				print $i $$i;
				$i++;
			end loop;
*/
		end loop;
	catch FILE_READ_END_EXCEPTION;
	catch;
		print /x EXCEPTION;
		print ERRMSG;
	end try;
	return $ERROR;
end proc;
