//
proc main;
	try;
//		exec sh >aaaa;
//		exec sh ps_senkyo.sh;
//		exec sh "ls aaaa" >zzz yyyy;
/*
		exec sh "ls aaaa
ls aaa";
*/
/*
		exec sh 'ls aaaa
ls aaa';
*/
		line = 'ls aaaa
ls aaa';
		exec sh $line;
//		exec sh >xxxxx;
//		exec sh;
//		exec sh "ls aaa" <xxxx;

//		exec sh <<EOF >xxxxx;
		exec sh <<EOF;
ls aaa
ls aaaa
EOF
//		print ERROR ERRMSG;
	catch;
		print ERROR ERRMSG;
	finally;
		print ERROR ERRMSG;
	end try;
	return ERROR;
end proc;
