//
//define global $('y')=1;
//define $('yy')=10;
//define  'm' (10);
define  ('m') (10);
//define ('m');
var ('n');
define  $%1 (10);
define type struct ss
	int i 5,
	double e,
	char(10) a,
	bulk(20) b;
define xxx (10);
sub main;
	$1 = 'XYZ';
	m[0] = 1;
	d=1.5;
	e = (CBULK)1;
	print ss;
	print $$%(1);
	print $%(1);
	print $$m[0];
/*
	print y yy m $%1;
	x = 100;
	loop 2;
		z = %1;
		print %1 z;
		local $(%1) = x;
		print $(%1);
		shift ;
		x *= 2;
	end loop;
	print a b;
*/
	return ERROR;
end sub;
