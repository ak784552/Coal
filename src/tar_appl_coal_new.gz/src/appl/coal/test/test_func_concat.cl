//
proc main;
	print ABC;
	a = concat(ABC,'abc');
	b = fgetline(STDIN);
	print a b;
	return $ERROR;
end proc;
