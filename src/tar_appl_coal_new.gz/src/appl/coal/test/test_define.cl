//
//def const def a;
//def global sca b;
dim yd as DEC(5,2) = 345.67;
define string ss;
//define char ERROR;
define array xx[10];
//def yd;
define char(2) c2 = 'ABCD';
define int(2) vint2 = 32769;
define int(2) xint2 = 65538;
define int(1) vint1 = 129;
define int(1) xint1 = 257;
define uint(2) vuint2 = 32769;
define uint(2) xuint2 = 65538;
define uint(1) vuint1 = 129;
define uint(1) xuint1 = 257;
//define short(1) xshort = 257;
sub main;

	print /i yd;
	dim x;
//	define xx;

	ss = 'ABCD';
	print yd ss;
	ss = '1234567890';
	print ss;
//	char(2) ss = 'XYZ';
	char ss = ss & 'dfrgsds';
	print ss;
/*
	vari ss = '123';
	print ss;
	ss = ss;
	print ss;
	char ss = 'qwert';
	print ss;
	dec ss=123.45;
	print ss;
*/
	print c2 /i c2;
	print vint2 /i vint2;
	print xint2 /i xint2;
	print vint1 /i vint1;
	print xint1 /i xint1;
	print vuint2 /i vuint2;
	print xuint2 /i xuint2;
	print vuint1 /i vuint1;
	print xuint1 /i xuint1;
	print x=(int(2))32769 /i x;

	vint1 = 64;
	vint2 = 32768;
	print vint1+vint1;
	print vint1+vint2;

	return(ERROR);
end sub;
