//
//
//
proc main;
	print 'a\0b' '\t\r' '\x01';
	return ERROR;
end proc;
