
	tdtInfoParm *pInfo;
	M_FILE *fp;

#if 1
fp = NULL;
if (pInfo=cl_get_var("fp")) {
	if (pInfo->pi_attr == DEF_ZOK_BINA) {
		if (fp = (M_FILE *)cl_get_data_long(pInfo))
printf("cl_node_process_opt:1 fp=%08x m_fp=%08x\n",fp,fp->m_fp);
	}
}
else {
printf("cl_node_process: not found %s\n","fp");
}
#endif

