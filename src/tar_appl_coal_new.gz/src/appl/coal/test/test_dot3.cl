//
proc main;
	text='123%456-ABC/78�S5%90/abc%8def';
//	a = '#*%*/';
/*
	print text a %1;
	print text.a;
*/
/*
	print text.' ';
	print text.%1;
	print text.$1;
	print text.'#�S5*8';
	print text.'##45*8';
*/
//	print text.'#*%*/';
//	print text.'##*%*/';
/*
	print text.'%45*8';
	print text.'%%45*8';
*/
//	print text.'%/*%*';
//	print text.'%%/*%*';
//	print text.'/45/XYZ';
//	print text.'//�S5/XYZ';
//	print text.'#/*';
//	print text.'##/*';
//	print text.'%*/';
//	print text.'%%*/';
/*
	print text.'#123%';
	print text.'##123%';
	print text.'#56/78';
	print text.'##56/78';
	print text.'#%8def';
	print text.'##%8def';
	print text.'#^23';
	print text.'#de$';
	print text.'%^123';
	print text.'%def$';
	print text.'s/45/XY/';
	print shsbs(text,' ');
	print shsbs(text,%1);
	print shsbs(text,$1);
*/
//	print shsbs(text,'%/*%*');
//	print shsbs(text,'/45/XY');
	print shsbs(text,'/45/');
	print shsbs(text,'/-/');
//	print shsbs(text,'s/*%*');
/*
	print shsbs(text,'s/abc/XY/gi');
	print shsbs(text,'S/abc/XY/gi');
	print shsbs(text,'s/abc/XY');
	print shsbs(text,5,10,'s/abc/XY/i');
	text2='123%456txt/7845%90/abc%8def.txt';
	print text2;
	print shsbs(text2,'s/.txt/_txt/g');
	print shsbs(text2,'s/\\.txt/_txt/g');
	print shsbs(text,'S/45/XYZ/');
	print shsbs(text,'S/45/XYZ/g');

	$1 = '/tmp/coal_mini/src/appl/coal/clnest.c';
	n = 1;
*/
//	name = left($(n).'##*/',-2);
//	print name;

	return ERROR;
end proc;
