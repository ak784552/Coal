//
proc main;
	try(fpi=fopen(%1));
		if %2=='' then
			fpo = STDOUT;
		else
			fpo=fopen(%2,'w');
		endif;
		loop;
			a = getc(fpi);
			print /x $a;
		//	putc(fpo,a);
			putc(fpo,a);
		end loop;
	catch FILE_READ_END_EXCEPTION;
	catch;
		print ERRMSG ERROR ERRNO;
	finally;
		if fpo thenl fclose(fpo);
	end try;
	return $ERROR;
end proc;
