//
proc main;
	char x;

	print "a = '\0'";
	print a leng(a) /x a;
	x = f();
	print /x x;
	return ERROR;
end proc;

func f();
	return '\0';
end func;
