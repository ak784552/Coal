//
// ����p�^�[���ƈ�v���镶������܂ނ��ׂĂ̓��͍s���o�͂��� (grep2)
//
proc main argc argv;
	long lineno = 0;
	int argc1, except, number;

	except = number = 0;
	argc1 = argc;
	while argc > 0 && left(s = %argv[0], 1) == '-' as WH1;
		for (s = substr(s ,2); (c = left(s,1)) <> ''; s = substr(s ,2));
			switch c;
			case 'x';
				except = 1;
				break;
			case 'n';
				number = 1;
				break;
			default;
				printf('%s: illegal option [%c]\n', SCRIPTNAME, c);
				argc1 = 0;
				break WH1;
			end switch;
		end for;
		shift;	/* argc��-1���Aargv��O�ւP�V�t�g���� */
		argc1 = argc;
	end while;

	if argc1<=0 || %argv[0]=='' then
		printf('usage: coal %s -x -n pattern\n', SCRIPTNAME);
		return 1;
	else
		try;
			loop;
				line = getline();
				lineno++;
				if (instr(line, %argv[0]) > 0) <> except then
					if number thenl printf('%d: ', lineno);
					putline(line);
				end if;
			end loop;
		catch;
		end try;
	end if;
	return ERROR;
end proc;
