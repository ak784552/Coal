//
//
//
typedef struct FAMILY
	     fa_next,	  // ���̉Ƒ��̃����o������
	int  fa_zokugara,  // 0:�{�l, 1:�z���, 2�`:�q
	char fa_name,
	char fa_furi,
	char fa_sex,
	char fa_birth;

FAMILY family_list,f;
int name_count = 0;

proc main;
	do;
//		if set_family(family_list) < 0 thenl return ERROR;
		set_family(family_list);
		if $ERROR thenl break;
		fnext = family_list;
		loop;
//			if set_family(f) < 0 thenl break;
			set_family(f);
			if $ERROR thenl break;
			fn = next_name();
print fn;
			$(fn) = *f;
			set_next(fnext,$(fn));
			fnext = fnext.fa_next;
		end loop;
	end do;
	fnext = family_list;
	loop;
		print_family_member(fnext);
		if fnext.fa_next == '' thenl break;
		fnext = fnext.fa_next;
	end loop;
	return ERROR;
end proc;

function set_family(f);
	printf('Enter next family mamber(zokugara,name,furigana,sex,birth):\n');
	line = getline();
//	if $ERROR thenl return ERROR;
	getargs(line,1,5);
//	if (int)$1 < 0 thenl return -1;
//print *$();

	f.fa_next = '';
	f.fa_zokugara = $1;
	f.fa_name = $2;
	f.fa_furi = $3;
	f.fa_sex = $4;
	f.fa_birth = $5;

//print *f;
	return ERROR;
end func;

function set_next(f,fnext);
//print 'set_next:Enter' *f;
	f.fa_next = fnext;
//print 'set_next:Exit' *f;
	return ERROR;
end func;

function next_name();
	return 'f' &+ name_count++;
end func;

function print_family_member(f);
//print *f;
	printf('%3d %s %s %s %s\n',
		   f.fa_zokugara, f.fa_name, f.fa_furi, f.fa_sex, f.fa_birth); 
	return ERROR;
end func;
