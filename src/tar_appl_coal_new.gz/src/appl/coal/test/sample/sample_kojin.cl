//
//
//
typedef struct ADDR
	char zip_code,
	char jusho,
	char build,
	char tel;

typedef struct KINMU
	char km_name,
	char km_furi,
	ADDR km_addr;

typedef struct FAMILY
	int  fa_zokugara,  // 0:�{�l, 1:�z���, 2�`:�q
	char fa_name,
	char fa_furi,
	char fa_sex,
	char fa_birth,
	ADDR fa_addr;

typedef struct PERSONAL
	FAMILY pa_family[10],   // fa_zokugara��char�ɕϊ��������̂��L�[�Ɏg�p����
	KINMU  pa_kinmu;

PERSONAL kojin_table[2];// = {0, '����', '�R�o���V', '�j','1951/05/28'};
FAMILY family_tab[2] = {0, '����', '�R�o���V', '�j','1951/05/28'};
ADDR addr = {'335-0022','�˓c�s','�R�X���˓c����','048-431-7812'};

proc main;
//print *family_tab[0];
	kojin_table[0].pa_family = family_tab;
	family_tab[0].fa_addr = addr;
//print *kojin_table[0].pa_family[0];

//	kojin_table[0].pa_family[0].fa_zokugara = 0;
	i = 0;
print kojin_table;
print *kojin_table;
	print countv(family_tab);
	print countv(kojin_table);
	loop countv(kojin_table);
		j = 0;
		loop countv(family=kojin_table[j].pa_family);
print j;
			f = family[j++];
			a = f.fa_addr;
			printf('%3d %s %s %s %s %s %s %s %s\n',
				   f.fa_zokugara, f.fa_name, f.fa_furi, f.fa_sex, f.fa_birth,
				   a.zip_code, a.jusho, a.build, a.tel); 
		end loop;
	end loop;
	fami(kojin_table[0].pa_family[0]);
	print *kojin_table[0].pa_family[0];

	return ERROR;
end proc;

function fami(f);
	f.fa_name = 'XXXXX';
	return ERROR;
end func;
