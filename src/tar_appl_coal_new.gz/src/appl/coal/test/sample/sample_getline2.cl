//
#+define MAXLINE	10

char(1) line[MAXLINE];
proc main;
	try;
		loop;
			n = getline();
			print n *line;
		end loop;
	catch FILE_READ_END_EXCEPTION;
//		print ERROR ERRMSG;
	catch;
		print ERROR ERRMSG;
	end try;
//	print ERROR ERRMSG;
	return ERROR;
end proc;

function getline();
	char c;

	for (i=0; (i<MAXLINE-1 && (c=getchar()) && c<>'\n'); i++);
//putchar(c);
		line[i] = c;
	next;
	if c == '\n' then
		line[i] = c;
		i++;
	end if;
	line[i] = '\0';
	return i;
end func;
/*
func getchar();
	return elread1(1,1);
end func;
*/
