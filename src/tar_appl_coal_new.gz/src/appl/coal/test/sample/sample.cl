//
//  sample.cl
//
proc main;
	print getmemused(1,6) *$();
	putline('Hello World!',' ',%1);
	print /qnc- 'Hello World!' %1;
	echo 'Hello World!' %1;
	printf '%s %s\n' 'Hello �v���������I' %1;
	output dt 98888 2 /cnq- 'Hello World!' %1;		// --p1,1
	output dt 98888 2 /cnq- /e 'Hello World!' %1;
/*
	int x;
	print x='0xff';
	print "3 > 1" 3<1;
	char cc[10]=['1','2','3','4',''];
	print (int)concat(cc);
	print (dec)'123.45';
	print 'ABC D\tEFG'XYZ.3;
	print XYZ'ABC D\tEFG'.3;
	print "1 getmemused 6" *$();
*/
	print getmemused(1,6) *$();
	print "`print 'ABC'`";
	return;
end proc;
