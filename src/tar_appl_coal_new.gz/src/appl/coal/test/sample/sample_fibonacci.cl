//
// Fibonacci series:
// the sum of two elements defines the next
//
proc main;
	[a, b] = [0, 1];
	while a < 1000;
		printf '%d,' a;
		[a, b] = [b, a+b];
	end while;
	print;
	return ERROR;
end proc;
