//
// �R�}���h�p�����[�^�ŗ^����ꂽ�f�B���N�g�����̂��ׂĂ�txt�t�@�C���̓��e���o�͂���
//
define int dp=0;
define int fp=0;
proc main;
    dir = %1;
    try (dp = opendir(dir));
        while file=readdir(dp) do
            if right(file,4)=='.txt' then
                try;
                    fp = fopen(dir & '/' & file);
                    putline(file, ':');
                    loop do;
                        putline(fgetline(fp));
                    end do;
                catch FILE_READ_END_EXCEPTION;
                catch;
                    print 'in catch' ERRMSG /x EXCEPTION;
                finally;
                    if fp thenl fclose(fp);
                end try;
            end if;
        end do;
    catch FILE_READ_END_EXCEPTION;
    catch;
        print 'out catch' ERRMSG /x EXCEPTION;
    finally;
        print 'Finally' /x EXCEPTION;
    end try;
    return ERROR;
end proc;
