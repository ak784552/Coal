//
// �e������󔒕����⑼�̕����̏o���p�x�𐔂���
//
proc main;
	int i, nwhite, nother, ndigit[10];
	char c;

	nwhite = nother = 0;
	for (i = 0; i < 10; i++);
		ndigit[i] = 0;
	next;

	while c = getchar();
##if 1
		switch c ;
		case '0','1','2','3','4,','5','6','7','8','9';
			ndigit[c]++;
			break;
		case ' ','\n','t';
			nwhite++;
			break;
##else
		switch 1 ;
		case (c>='0' && c<='9');
			ndigit[c]++;
			break;
		case (in(c,' ','\n','t')>0);
			nwhite++;
			break;
##endif
		default;
			nother++;
			break;
		end switch;
	end while;

	printf('digits =');
	for (i = 0; i < 10; i++);
		printf(' %d', ndigit[i]);
	end for;
	printf('\nwhite space = %d, other = %d\n',nwhite, nother);
	return ERROR;
end proc;
