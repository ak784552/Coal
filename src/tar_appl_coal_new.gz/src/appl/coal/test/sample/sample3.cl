//
//  sample3.cl
//
proc main;
	print abc12345='A';
	print abc_12345='B';
	print abc-12345='C';
	print $abc12345='D';
	print abc$12345='E';
	print return='E';
	print $return='E';
	print sprint('/i',abc12345,456);
	return;
end proc;
