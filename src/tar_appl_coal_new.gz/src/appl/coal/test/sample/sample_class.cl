//
// The Greeter class
Class Greeter;
	char name;
	// constructer
	func Greeter(name);
		My.name = name to 'Capitalize';
		return 0;
	end func;
	// method
	func salute;
		putline('Hello ',name,'!');
		return 0;
	end func;
end class;

proc main;
	// Create a new object
	g = new Greeter('world');

	// Output "Hello World!"
	g.salute();

	return ERROR;
end proc;
