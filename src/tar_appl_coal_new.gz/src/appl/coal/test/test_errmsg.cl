//
proc main;
	$fpr = fopen('rrr','r');
	print ERRNO STRERROR /x EXCEPTION;
	print ERROR ERRMSG;
	return ERROR;
end proc;
