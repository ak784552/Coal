//
def a,b,c;
proc main;
/*
	print %0;
	i=1;
	loop %0;
		local i++;
		print i %1;
		shift;
	end loop;
*/
	print *a;
	print func1(10,12,102,f);
//	[a,b,c] = '';
//	a=10;
	print func2(a,b,c);
	print a b c;

	print 'Enter "%d %f %s",a,b,c';
	print scanf('%d %f %s',a,b,c);
	print a b c;

	return $ERROR;
end proc;

function func1 argc argv;
//	print argc *%argv[0];
	print argc %argv[0];
	shift local;
	print argc %argv[0];
	print %argv[2](%argv[0]);
	return 0;
end func;

func f(x);
	return x*2;
end func;

function func2 argc *argv/* (*x,*y,*z)*/;
//	print argc %argv[0] x;
//	%argv = 0;
	*%argv[0] = '1';
	*%argv[1] = '2';
	*%argv[2] = '3';
	print %argv[0] %argv[1] %argv[2];

//	*x = 'A';
/*
	*y = 'B';
	*z = 'C';
*/
	return 0;
end func;

function scanf argc argv /*(form,*a,*b,*c)*/;
/*
	x = [%argv[1]];
	i = 1;
	for i=2 to argc-1;
		append(x,ndef('%argv[i]',''));
	next;

	return sscanf(getline(),%argv[0],**x);
*/
	form = %argv[0];
	shift local;
	return sscanf(getline(),form,**%argv);
//	return sscanf(getline(),form,a,b,c);
end func;
