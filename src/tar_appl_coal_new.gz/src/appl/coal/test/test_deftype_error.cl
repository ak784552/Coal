//

define type struct z
	int a
	,char(5) b
	,dec(10,2) c
;
def zz 10=1;
var y as zz;
proc main;
	print y *y;
	return ERROR;
end proc;
