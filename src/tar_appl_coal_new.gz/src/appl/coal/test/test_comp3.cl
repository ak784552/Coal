//
def mappedarray %ma 1 10;
def mappedarray ma 1 10;
def xx[10];
proc main;
//	print () [] {};
//	int ($())=1,2,3;
	setarray(1,1,2,3);
	print $() *$();
	print $()[1];
	$4 = 4;
	$()[5] = 5;
	print $() *$();
	print /i %ma %();
	print *%ma *%();
	print ma *ma;
	print arraycmp(ma,%());
	ma[5] = 'AA';
	$10 = 1;
//	print arraycmp('1','1') *$();
	print $(65) ma[10];
	print $(2);
	setarray(xx,1,2,3,4);
	print xx *xx;
	*xx==*ma;

	return ERROR;
end proc;
