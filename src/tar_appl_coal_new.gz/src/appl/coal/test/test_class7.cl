//
// 
//
define a[10];
class person;
	char sex;
	char name;
	int  year;
	char addr;
	func person(sex,name0,year0,addr0);
		My.sex=sex;
		name=name0;
		year=year0;
		addr=addr0;
		return 0;
	end func;
	func pr();
		print sex name year addr;
		return 0;
	end func;
end class;

class company; 
	char name;
	int  year;
	char addr;
	char tel;
	func company(name0,year0,addr0,tel0);
		name=name0;
		year=year0;
		addr=addr0;
		tel=tel0;
		return 0;
	end func;
	func pr();
		print name year addr tel;
		return 0;
	end func;
end class;

proc main;
	a[0]=new person('�j','����',20,'����');
	a[1]=new company('�`�a�b',30,'���','06-3456-9999');
	a[0].pr();
	a[1].pr();
	return ERROR;
end proc;
