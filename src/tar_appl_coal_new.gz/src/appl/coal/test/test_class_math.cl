//
//#*include class_math.cl
import class_math.cl;
proc main;
	tt=TIME;
print tt;
	srand48(tt);
#*ifdef NEW
	a = new Math;

	print a.sind(30.0);
	print a.cosd(60.0);
	print a.tand(45.0);
	a.tan(45.0);

#*else
	print Math.sind(30.0);
	print Math.cosd(60.0);
	print Math.tand(45.0);
	print rand1();
	loop 10;
		print Math.randint(0,9);
	end loop;
#*endif
	return $ERROR;
end proc;
