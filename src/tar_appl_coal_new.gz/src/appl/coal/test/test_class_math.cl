//
//#*include class_math.cl
import class_math.cl;
proc main;
#*ifdef NEW
	a = new Math;

	print a.sind(30.0);
	print a.cosd(60.0);
	print a.tand(45.0);
	a.tan(45.0);

#*else
	print Math.sind(30.0);
	print Math.cosd(60.0);
	print Math.tand(45.0);
#*endif
	return $ERROR;
end proc;
