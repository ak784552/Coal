//
typedef struct ST_XXX
	int a,
	char b;
ST_XXX ss = [1,'R'];
proc main;
	s = ss;
	t = *ss;
	ss.a = 2;
	print *s *ss;
	print *t *ss;
	return ERROR;
end proc;
