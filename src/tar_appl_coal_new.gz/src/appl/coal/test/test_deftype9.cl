//
typedef struct ST_XXX
	int a,
	char b;
ST_XXX ss = [1,'R'];
typedef struct ST_YYY
	char bb,
	int aa;
ST_YYY ww,yy = ['S',2];
proc main;
	print ST_XXX;
	print ss;
	s = ss;
	t = *ss;
	ss.a = 2;
	print s *s *ss;
	print t *t *ss;
	print ST_YYY;
	print yy;
	print "yy = ss";
	print "yy = *ss";
	print "ww = yy";
	print "ww = *yy";
	print ww *ww;
	return ERROR;
end proc;
