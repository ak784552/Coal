//
define array $tbl 10;
proc main;
//	let options 2 1;
//	$item = 'ABC$DEFG.DFELK01';
	$item = 2;
	$tbl[0] = $item;
	$$item = 0;
print $item $$item;
	$$tbl[0] = 'XXX';
//	$item = $tbl[0];
//	$$item = '';
print $$item $$tbl[0];
	return ERROR;
end proc;
