//
//define array aa[10] = 1..10;
define array aa[10];
def complex c = 1.5+2.5i;
proc main;
	print ABS(3+4I);
/*
	print c /x c /i c;

	print ABS(1e300+1e300i);
	print ABS(1E300+1E300i);
	print 3i ABS(3i);
	print 2.5i ABS(2.5i);
	print 2.5fi ABS(2.5fi);

	print 2..0I;
	print 0..3I;
	print 0..0I;
	print 3..4LUI ABS(3..4I);
	print 1..10LUI ABS(1..10LUI);
	print 2..5.6I ABS(2..5.6I);
	print 2.5..5.6fI abs(2.5..5.6fI);
	print 10i+20i;
	print 10+20i;
	print 10-20i;
	print 2+0i;
	print 0+3i;
	print 0+0i;
	print (2..0i)==2;
	print (0..3i)==3i;
	print 3..'4i';
	print 3+'4i';
	print '3'+4i;

	a = 3i;
	print a /i a;
	dec(5,2) c = 2.5i;
	print c /i c;
	print a==c;
	print a<>c;
	print a==1;
	a = 2.5fi;
	print a /i a;
	print 5<>5i;

	a = 3u..4ui;
	b = 2.5..5.6i;
	print /i a b;
	print a b;
	print abs(a) abs(b);
	print *a;
	print a+b;
	print a-b;
	print a*b;
	print a/b;
	print "a % b";
	print a**0;
	print -a -b;
	print (3+4i)/(5+3i);

	a = 3..4i;
	b = 3..5.6i;
	print a b;
	print a-b;
	print a==b;
	print a<>b;
	print a>b;
	print a==b;
	print a<>b;
	print a==1;
	print a==0;
	print b-cint(b/a)*a;
	print mod(b,a);

	a = 3..4i;
	b = 2.5..4i;
	print a b;
	print a-b;
	print getval(a,1) getval(a,2) getval(a,3);
	print getval(a,'Real') getval(a,'Image') getval(a,'XXX') getval(a,'') getval(a);

	print 2i*3i;
	print 2.0i/3.0i;
	print 2i**0;
	print 2i**1;
	print 2i**2;
	print 2i**3;
	print 2i**4;

	print 2.0i**0.5;
	print 2.5**0;

	cc = 1.5..3.5;
//	print cc;
	print getval(cc,1) getval(cc,2) getval(cc,3) getval(cc);

	print complex(1,0);
	print complex(0,1);
	print complex(0,0);
	print complex(1,1);
	print complex(1,2.5);
	print complex(1,2.5f);
	print complex(1.5,2);
	print complex(1.5,2.5);
	print complex(1.5,2.5f);
	print complex(1.5f,2.5f);
	print complex(1.5f,b);
	print complex(1.5f,SYSDATE);
	print complex(1,2i);
	print complex(1i,2);
	print complex(1i,2i);
	print complex('1','2i');
	print complex('1i','2');
	print complex('1i','2.0i');
	print complex('1.0i','2i');
	print complex('1+2i','2i');
	print cimg(10);
	a = 1.333;
	b = 4294967295U;
	print a b /i a b;
	print complex(a,b);
	print 4294967295U+4294967295Ui;
	print 4294967295U..4294967295Ui;
	print 2.5+4294967295Ui;
	print 2.5..4294967295Ui;

	print (2+1i)*(2+1i);

	print (2+1i)**2;
	print (2+1i)**2.0;
	print (2+1i)**2.0f;
	print (0.5+0.8660254i)**0.5;

	print UINT_MAX ULONG_MAX /i UINT_MAX ULONG_MAX;

	print rational(10+20i,1-5i);
	print (DEC)(10+20i) /i (DEC)(10+20i);
	uint i = 3+4i;
	print i /i i;
	print (int)(1.3+2.5i);
	print (int)2.5i;
*/
	return $ERROR;
end proc;
