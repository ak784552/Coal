//
define type struct z
//	,int a
	char(5) b
	, dec(10,2) c 5
	,int a
//	, d 5
;
//define var x1 as z = 10,'ABC',1.1,2.2,3.3,4.4,5.5,6.6;
define var x2[3] as z = 'ABC',1.1,2.2,3.3,4.4,5.5,10,'XYZ',11,22,33,44,55,66,20;
//define var x2[3] as z = 10,'ABC',1.1,2.2,3.3,4.4,5.5,20,'XYZ',11,22,33,44,55,66;
/*
define var y as int=10;
define char(10) w[6];
/*
define int ww[10];
define aa;
define char(5) cc;
*/
define var xa[5];
define mappedarray ma[1,5];
*/
//def array z bb;
proc main;
/*
	print z;
	print x1;
	print *x1;
*/
	print x2 x2[0];
	print *x2 *x2[0];
/*
	x1.a=1;
	x1.b='qwe';
	x1.c[0]=123.456;
	print x1.a x1.b;
	print *x1 x1.c[0];
	print y;
	print ww *ww ww[1] w[1];
/*
	w[0]=x1;
	print w *w w[0].a;
*/
	w[3] = 'XXX';
	print *w;
	x2[0].a=2;
	x2[0].b='fghjkl';
	x2[0].c[0]=0.0876;
	print *x2[0];
/*
	print aa cc;
*/
	print xa;
	set_struct(x1,30,'DEF',,6);
	print *x1;
//	set_array(x2,2,40,'HIJ',111.,222.,333.,444.,555.);
	print *x2;
	print *x2[2];

	x1.c[1]=ma;
	set_struct(x1,25,'abcde',50,60,70,80,90,100,110,120);
	print *x1;
	$1='XXXX';
	print *$();
	print *x1;
*/
	return ERROR;
end proc;
