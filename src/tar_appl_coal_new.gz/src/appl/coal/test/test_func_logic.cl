//
proc main;
	print ABS(-3);
	print "1 AND 1.0";
	print IIF('A'=='B',1,0);
	print AND(1,NVAL('',2),'a');
	print OR(0,0.0,'a');
	print AND(1,0,'a');
	print OR(0,0,'');
	print AND(,);
	print OR(,);
	print AND(10);
	print ABS(OR(1,2+AND('A','B'&'C',IIF('A'=='B',1,0))));

	print OR(0,0.0,1) "1 OR 0.0";
	print "'XXX' is('ABCDEFG','l')";
	print "'ABCDEFG' IS ('l')";
	print EQ(1,1.0) "1 EQ 1.0";
	print EQ('abc','ABC') "'ABC' EQ 'ABC'";
	print iEQ('abc','ABC') "'ABC' iEQ 'ABC'";
	print NE('abc','ABC') "'ABC' NE 'ABC'";
	print iNE('abc','ABC') "'ABC' iNE 'ABC'";
	print GT(2,1.0) "1 GT 2.0";
	print GT('ab','a') "'AB' GT 'a'";
	print iGT('ab','a') "'AB' iGT 'a'";
	print LT(2,1.0) "1 LT 2.0";
	print LT('ab','a') "'AB' LT 'a'";
	print iLT('ab','a') "'AB' iLT 'a'";

	return $ERROR;
end proc;
