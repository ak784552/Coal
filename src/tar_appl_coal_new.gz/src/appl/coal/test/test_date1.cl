//
//option 20 20;
proc main;
	print SYSDATE;
	print SYSDATE+1;
	print SYSDATE-1;
	print SYSDATE+SYSDATE;
	print SYSDATE..SYSDATE;
	print *(SYSDATE..(SYSDATE+3));
	print to_char(SYSDATE..SYSDATE,'YYYY-MM-DD HH:MI:SS.U P DAY DDD');
	print 1.5..3.5;
	print (BIN)SYSDATE;
	return ERROR;
end proc;
