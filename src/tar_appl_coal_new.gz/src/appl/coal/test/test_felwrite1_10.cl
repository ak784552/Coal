// 
proc main;
	$fp = fopen('a','wb');
	print $ERROR $ERRMSG;
	$d = -25.3/10r;
	$dd =  100.0/4r;
	print d dd;
	print felwrite1($fp,$d,8);
	print felwrite1($fp,$d,8,3);
	print felwrite1($fp,$d,8,-1);
	print felwrite1($fp,$d,8,-3);
	print felwrite1($fp,$dd,8);
	print felwrite1($fp,$dd,8,3);
	print felwrite1($fp,$dd,8,-1);
	print felwrite1($fp,$dd,8,-3);
	$r = fclose($fp);
	return $ERROR;
end proc;
