//
//#+define SCOPE global
//#+define SCOPE public
#+define SCOPE private
//#+define SCOPE local
//#+define SCOPE
def global gg = 'AA';
def public pp = 'BB';
def private ss = 'CC';
proc main;
	aa = 100;
	$1 = 20;
	for i=1 to 2;
		print i gg pp ss aa $1;
		SCOPE gg = 10;
		SCOPE pp = 20;
		SCOPE ss = 30;
		SCOPE aa = 40;
		$1 = 50;
	next;

	global gg = 'AAX';
	public pp = 'BBX';
	private ss = 'CCX';
	for k=1 to 2;
		i = fun1(k);
		print k i gg pp ss aa $1;
	next;
	return ERROR;
end proc;

function fun1(k);
	local aa = 1;
	for i=1 to 2;
		print k i gg pp ss aa $1;
		SCOPE gg = 11;
		SCOPE pp = 21;
		SCOPE ss = 31;
		SCOPE aa = 41;
		$1 = 51;
	next;
	return i;
end func;
