//

define type struct z
	int a
	,char(5) b
	, dec(10,2) c 10,
;

define global z x 5 = [10,'XY',11,22,33];
var global y as z = 100,'ABC',1,2,3,4,5,6;
define global g;
define public p=1;
define s;
proc main;
	print z;
	print /i p;
	print /i y;
	print /i g;
	print /i"global g";
	print g;
	print "global g";
	print x;
	print x[0];
	x[0].a = 100;
	print x[0];
	print *x[0];
	x[1].b = 'ABC';
	print x[1].b;
	print *y;
/*
	print /i $1;
	print /i w;
	print y.b;
	print y.c[0];
*/
	return ERROR;
end proc;
