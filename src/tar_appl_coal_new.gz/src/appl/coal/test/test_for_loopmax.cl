//
proc main;
	$MAX_LOOP_WHILE = 10;

	for x=0 x<10 x++;
		echo x;
	endfor;

	for x=1 To 10;
		echo x;
	endfor;
	for x=10 TO 1 STEP -1;
		echo x;
	endfor;

	for (x=0;x<10;x++);
		echo x;
	endfor;
	for (x=10;x>0;x--);
		echo x;
	endfor;
	return ERROR;
end proc;
