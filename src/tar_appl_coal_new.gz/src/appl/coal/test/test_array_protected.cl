//
proc main;
	a = [4,2,1,5,3];
	b = [4,2,1,5,3];
	print arrayclr([1,2,3],0);
	print arraycpy([1,2,3],a);
	print arraybxp([],a,b,'+');
	return ERROR;
end proc;
