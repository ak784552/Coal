//
PROC main;
	loop 2;
		if %1 == '1';
			print '1:%1=' %1;
		elsif %1 == '2';
			print '2:%1=' %1;
		else;
			print '%1=' %1;
		end if;
	end loop;
	RETURN $ERROR;
END PROC;
