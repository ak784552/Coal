//
proc main;

//	print  (1,2,3,4,5,6,7,8,9);
loop 2;
	for each x in 1,2,3,4,5,6,7,8,9;
//		print /i x;
		print x.Index x.Value;
//		print *x;
	next;
	print /i x;

	a = 1;

	for each x in ['A','B',1,2,3,4,5,'C'] do
//		print x.Index x.Value;
		print *x;
	next;
	print /i x;
	b = 1;

end loop;

	return ERROR;
end proc;
