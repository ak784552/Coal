//
class Card ;
	char suit;
	int  number;
	func Card(suit,number);
		My.suit = suit;
		My.number = number;
		return 0;
	end func;
end class;

class Deck;
	cards = [];
	var card;
//print cards;
	func Deck();
	//	option 5 +0x01;
		cards = [];
//print cards;
		for each suit in ['�n�[�g','�_�C��','�X�y�[�h','�N���u'];
//		for each suit in ['�n�[�g','�_�C��'];
			for each number in 1..13;
//			for each number in 1..2;
				My.card = new Card(suit.value,number.value);
//print card.suit card.number;
				append(My.cards,My.card);
//print card.suit card.number;
			next;
		next;
//print My.cards[0].suit My.cards[0].number;
//print My.cards[1].suit My.cards[1].number;
		return 0;
	end func;
	func shuffle();
		random(My.cards);
		return 0;
	end func;
	func draw_card();
		return pop(My.cards,0);
	end func;
end class;

def ar[10];

proc main;
//	option 5 +0x01;
/*
	card = new Card('�n�[�g',1);
	print card.suit card.number;
	cards = [];
	append(cards,card);
	x = cards[0];
	print cards[0].suit cards[0].number;
	print card.suit card.number;
	print x.suit x.number;
	card = new Card('�X�y�[�h',5);
	print card.suit card.number;
	append(cards,card);
//	print cards;
	print cards[0].suit cards[0].number;
	print cards[1].suit cards[1].number;
*/
/*
	cards = [];
//		for each suit in ['�n�[�g','�_�C��','�X�y�[�h','�N���u'];
		for each suit in ['�n�[�g','�_�C��'];
//			for each number in 1..13;
			for each number in 1..1;
				card = new Card(suit.value,number.value);
//print card.suit card.number;
				append(cards,card);
//print card.suit card.number;
			next;
		next;
	print cards[0].suit cards[0].number;
	print cards[1].suit cards[1].number;
*/

	deck = new Deck();
	deck.shuffle();
	print deck.cards[0];
	card1 = deck.draw_card();
	print card1.suit card1.number;
	card2 = deck.draw_card();
//	card = deck.cards[1];
//	print card.suit card.number;
//	card2 = deck.cards[0];
	print card2.suit card2.number;
	card3 = card1;
	print card1 card2 card3;
	print card1==card2 card1==card3;
	ar[0] = card1;
	print ar[0];
	print countv(deck.cards);
/*
	for each card in deck.cards;
		print card.value.suit card.value.number;
	next;
*/
//	card = deck.cards[1];
//	print card.suit card.number;
/*
	n = 10;
	print unique([1,2,1,card1,card2,3,4,5,4,card3,n,,1+2i,1r,3..5,1+2i,1r,3..5]);
	print [1,2,1,card1,card2,3,4,5,4,card3,n,1+2i,1r,3..5]/[];
	print /i [1,2,3,{'A','B'},4];
	print unique(card1);
	print unique(1);
	print unique(['A',1,1]);
*/
	return ERROR;
end proc;
