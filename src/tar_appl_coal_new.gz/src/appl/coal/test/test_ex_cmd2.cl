//
proc main;

	a = `!cat w`;
	print a;
	a = `!cat w1 2>&1`;
	print a;
	a = `!cp w w2`;
	print a;
	shell('cat w');

	return ERROR;
end proc;
