PROC main;
	print getmemused(1);
	print *$();
	RETURN $ERROR;
END PROC;
