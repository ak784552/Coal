//
/*
define mappedarray a [1,10]= ['%A%','%C%','%C%','%','%F%'];
define mappedarray b [11,10]= [1i,2,3,4,5,'AB','BC','CD','DE','EF'];
define mappedarray c [21,10]= [1i,2,3,4,5,6,7,8,9,10];
*/
def wc = {1,2,3,4,5,6,7,8,9,10};
//define mappedarray r [31,10];
define la = ['%A%','%C%','%C%','%','%F%'];
define lb = [1i,2,3,4,5,'AB','BC','CD','DE','EF'];
define lc = [1i,2,3,4,5,6,7,8,9,10];
def lwc = {1,2,3,4,5,6,7,8,9,10};
proc main;
	a = $() + [0,10];
	b = $() + [10,10];
	c = $() + [20,10];
	r = $() + [30,10];
	*a = *['%A%','%C%','%C%','%','%F%'];
	*b = *[1i,2,3,4,5,'AB','BC','CD','DE','EF'];
	*c = *[1i,2,3,4,5,6,7,8,9,10];
	print *$();
/*
	loop each x in b;
		print *x;
	end loop;

	loop each x in c;
		print *x;
	end loop;
*/
	print arraybxp(b,b,c,5,'+');
	print arraybxp(abs,b,c,5,'+');
	print arraybxp(b,abs,c,5,'+');
	print arraybxp(b,b,abs,5,'+');
	print arraybxp(b,0,b,c,5,'+');
	print *arraybxp(,b,c,5,'+');
	print arraybxp(b,,c,5,'+');
	print arraybxp(b,b,,5,'+');
	print *arraybxp(,21,11,5,'+');
	print arraybxp(lb,lb,lc,5,'+') lb;

	print arraybxp(NULL,b,c,5,'+');
	print arraybxp(b,NULL,c,5,'+');
	print arraybxp(b,b,NULL,5,'+');
	print arraybxp(b,b,c,NULL,'+');
	print arraybxp(b,b,c,5,NULL);
	print arraybxp('',b,c,5,NULL);
	print arraybxp(r,wc,b,5,'+');
/*
	print b[0] /i b[0];
	loop each x in b;
		print *x;
	end loop;
*/
	print b[0]..c[0];
	print arraybxp(r,b,c,1,'..');

//	bb = b + 5;
	bb = b + 2;
	print arraybxp(bb,b,c,5,'+') *b;
	print arraybxp(b,bb,c,3,'+') *b;

	cc = c + 2;
	print arraybxp(cc,b,c,5,'+') *c *cc;
	print arraybxp(c,b,cc,5,'+') *c *cc;

	print r[0];
	print 1..2..1i;
	print *(1..1) *(1..2);
	print *('A'..'A') *('A'..'B');
	print *(SYSDATE..SYSDATE) *(SYSDATE..SYSDATE+1);

	print "*(*b + *c)";
	print "*(*b - *c)";
	print "*(*b & *c)";
	print "*(*b | *c)";

	return ERROR;
end proc;
