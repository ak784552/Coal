//
//  sample_binary.cl
//
def v 10 = [1,2,3,4,5,6,7,8,9,10];
proc main;
	print binary_search(%1,v,10);
	return ERROR;
end proc;

function binary_search(x,v,n);
	int low, high, midd;

	low = 0;
	high = n - 1;
	while low <= high ;
		midd = (low+high) / 2;
		if x < v[midd] then
			high = midd - 1;
		elseif x > v[midd] then
			low = midd + 1;
		else
			return midd;
		end if;
	end while;
	return -1;
end func;
