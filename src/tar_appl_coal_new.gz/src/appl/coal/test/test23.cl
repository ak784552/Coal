//
// 
//
def r 10 = [1,2,3,4,5,3,2];
def int s 10 = [1,2,3,4,5,6];
def t 5 = [1,2,3,4,5];
def complex dec(5,2) d 10 = [1.0,2.0,3.0,4.0,5.0];
proc main;

	a = [1,2,3,4,5,3,2];
	print /i a *a;
	print "a[0..2] + 10 + a[3..4]";
	print "mid(a,1,3) + 10 + mid(a,4)";
	print "*(*(*mid(r,1,3) + 10) + *mid(r,4))";
	print "*(*(*r[0..2] + 10) + *r[3..4])";

	print "(1..5) + (6..10)";
	print mid(*(1..10),3,2);
	print left(*('A'..'E'),3);

	print "a - 3";
	print "*(*r - 3)";
	print "agg(a,'/',3)";

	print *agg(r[0..2],'+',10,mid(r,4));

	c = '123456789';
	print mid(c,1,4);
	print left(c,4) left(c,-4);
	print right(c,4) right(c,-4);

	print mid(a,1,4);
	print left(a,4);
	print right(a,4);

	print *mid(r,1,4);
	print *left(r,4);
	print *right(r,4);

	print insert(r,10,3) *r;
	print insert(c,10,3);
	print insert('A',10,3);
	print insert([1,2,3,4,5,6],10,3);
	print insert({1,2,3,4,5,6},10,3);
	print insert(a,10);

	rr = r + [2,4];
	print *insert(r,10,1) *r;
	print *insert(rr,20,2) *rr;
	print *insert(r,'10') *r;
	print *insert(rr,20) *rr;

	rr = r + [2,-1..2];
	print *insert(rr,20,1) *rr;
	print *insert(rr,20) *rr;

	set_array(1,1,2,3,4,5,6);
	print *insert($(),10,3) *$();
	print insert(2,'AA',3) *$();
	print insert(1,'BB') *$();

	print *insert(s,20,3) *s;
	print *insert(s,'10') *s;
	print *insert(s,'30',1) *s;

//	print d *d;
	print *insert(d,'30.4',1) d *d;
	print *insert(d,r,1) d *d;

//	print *insert(t,10) t *t;
	print *insert(t,10,OPT==>1) t *t;

	print *insert(r,t) *r;
//	for each x in r;
//		print *x;
//	next;

	print 1..3 *(1..3);
	print /i 1..3 *(1..3);
	h = 1..3;

	print /q- vari_list(,);
	print /q- vari_list(,'[!\$]%');
	print /qn- "vari_list('public','[!\$]%') & vari_list('pl','[!\$]%')";

	return ERROR;
end proc;
