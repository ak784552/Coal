//
// 
//
def r 10 = [1,2,3,4,5,3,2];
proc main;
	a = [1,2,3,4,5,3,2];
	print "a[0..2] + 10 + a[3..4]";
	print "mid(a,1,3) + 10 + mid(a,4)";
	print "*(*(*mid(r,1,3) + 10) + *mid(r,4))";
	print "*(*(*r[0..2] + 10) + *r[3..4])";

	print "(1..5) + (6..10)";
	print mid(*(1..10),3,2);
	print left(*('A'..'E'),3);

	print "a - 3";
	print "*(*r - 3)";
	print "agg(a,'/',3)";

	print *agg(r[0..2],'+',10,mid(r,4));

	c = '123456789';
	print mid(c,1,4);
	print left(c,4) left(c,-4);
	print right(c,4) right(c,-4);

	print mid(a,1,4);
	print left(a,4);
	print right(a,4);

	print *mid(r,1,4);
	print *left(r,4);
	print *right(r,4);

	print insert(r,10,3);
	print insert(c,10,3);
	print insert('A',10,3);
	print insert([1,2,3],10,3);
	print insert({1,2,3},10,3);
	print insert(a,10);
	return ERROR;
end proc;
