//
proc main;
	option 17 1;
	$1 = %512;
	$a = -1.2;
	$b = 2.4;
print is($1,'T') is(a,'T') is(b,'T');
	$c = $a - $b;
//print d;
	$d = $a * $b;
	$e = $a / $b;
	print $a $b $c $d $e;
	output tn '$a=' $a ' $b=' $b ' $c=' $c ' $d=' $d ' $e=' $e;
	return $ERROR;
end proc;
