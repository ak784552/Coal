//
define array a hash;// 10; 
define array b 10 = [1,2,3,4,5,'A','B','C'];
define array BIN c 10 = [1,2,3,4,5,6,7,8,9,10];
define array dec(5,2) d 10 = [1,2,3,4,5,6,7,8,9,10];
define mappedarray $m 11 10;
define mappedarray %p 1 10;
define mappedarray #s 1 10;
proc main;
/*
	print '--- each x in a ---';
	loop each x in a;
		print x.Index x.Value count(x);
	end loop;

	print '--- each x in b ---';
	loop each x in b;
		print x.Index x.Value;
	end loop;

	print '--- each x in c ---';
	loop each x in c;
		print x.Index x.Value;
	end loop;
*/

	print *d;

	print arrayclr(b,'',5) *b;
//	print arrayclr(b+6,'X',5) *b;
	print arrayclr(b+7,,1) *b;
	print arrayclr(b+8,NULL,1) *b;

	print arrayclr(c+2,'100',4) *c;
//	print arrayclr(c,0) *c;
	print arrayclr(c+3,NULL,1) *c;

	print arrayclr(d+2,'3.123',4);
/*
	print '--- each x in b ---';
	loop each x in b;
		print x.Index x.Value;
	end loop;
	print '--- each x in c ---';
	loop each x in c;
		print x.Index x.Value;
	end loop;
*/
	print *d;

	print arrayclr(abs,'',5);

	cc = c + 2;
	print arrayclr(cc) *cc;
/*
	print '--- each x in cc ---';
	loop each x in cc;
		print x.Index x.Value;
	end loop;
	print '--- each x in c ---';
	loop each x in c;
		print x.Index x.Value;
	end loop;
*/
	print arrayclr(b);

	print *b b[7];

	print arrayclr(c);
	print *c c[7];

	print arrayclr(b,clrf,10);
	print *b;

	return ERROR;
end proc;

func clrf(a,b);
print a b;
	if b<=5 then
		 a = 10;
	end if;
print a;
	return a;
end func;
