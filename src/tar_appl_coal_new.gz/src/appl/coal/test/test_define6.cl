//
define char c[10] = ['a','xx',1,''];
proc main;
	print c *c;
	c[0] = 123456;
	print c[0] /d c[0];
	return ERROR;
end proc;
