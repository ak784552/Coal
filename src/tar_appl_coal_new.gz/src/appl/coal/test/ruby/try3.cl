//
/*** Ruby code ************
# The Greeter class
class Greeter
  def initialize(name)
    @name = name.capitalize
  end

  def salute
    puts "Hello #{@name}!"
  end
end

# Create a new object
g = Greeter.new("world")

# Output "Hello World!"
g.salute
****************************/
// The Greeter class
class Greeter;
	name = '';
	func Greeter(name);
		My.name = name.to('C');
		return 0;
	end func;

	func salute as void;
		printf('Hello %s!\n',My.name);
		return 0;
	end func;
end class;

proc main;
// Create a new object
	g = new Greeter('world');

// Output "Hello World!"
	print g.salute();
	return ERROR;
end proc;
