//
/*** Ruby code ************
# Ruby knows what you
# mean, even if you
# want to do math on
# an entire Array
cities  = %w[ London
              Oslo
              Paris
              Amsterdam
              Berlin ]
visited = %w[Berlin Oslo]

puts "I still need " +
     "to visit the " +
     "following cities:",
     cities - visited
****************************/
proc main;
	option 13 +0x02;
	cities  =  { 'London'
				,'Oslo'
				,'Paris'
				,'Amsterdam'
				,'Berlin'};
	visited = {'Berlin','Oslo'};
/*
	print /lqnc- "'I still need ' &
			'to visit the ' &
			'following cities:'"
			"cities - visited";
*/
	putline('/gc-', 'I still need ' &
			'to visit the ' &
			'following cities: '
			,cities - visited);
	return ERROR;
end proc;
