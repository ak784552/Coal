//
proc main;

	print fff(1,2,3);
	print "fff(1 <== 'a', 2 <== 'c', 3<=='x')";
	print "fff(1 <== a, 2 <== c, 3<==x)";
	print "fff(100,1 <== a, 3<==x)";
	p1='a';
	p2='c';
	$1='x';
	$2=1;
	print "fff(1 <== $p1, 2 <== $p2, 3<==$$2)";

	print "fff(1 <== a, 2 <== c, 3<==ERROR)";
	print "fff(1 <== a, 2 <== c, 3<==DATE)";
	print "fff(1 <== a, 2 <== c, 3<=='and')";
	print "�֐�('XXX'<==������1,'��'<==������2)";

	exec ip ppp 'AA'<==y 'BBB' 'CCC'<==x;
	aa = 'AA'<==y;
	exec ip ppp aa 'BBB' 'CCC'<==x;

	print aa 'AA'<==y;
	print "(2<==x) + (3<==y)";

	bb = 'BB'<==y<==x<==z;
	print bb;

	print "fff('a' ==> 1, 'c' ==> 2, 'x'==>3)";
	print "fff(a ==> 1, c ==> 2, x==>3)";
	print "fff(100,a ==> 1, x==>3)";
	p1='a';
	p2='c';
	$1='x';
	$2=1;
	print "fff($p1 ==> 1, $p2 ==> 2, $$2==>3)";

	print "fff(a ==> 1, c ==> 2, ERROR==>3)";
	print "fff(a ==> 1, c ==> 2, DATE==>3)";
	print "fff(a ==> 1, c ==> 2, 'and'==>3)";
	print "�֐�(������1==>'XXX',������2==>'��')";

	exec ip ppp y==>'AA' 'BBB' x==>'CCC';

	aa = y==>'AA';
	exec ip ppp aa 'BBB' x==>'CCC';

	print aa y==>'AA';
	print "(x==>2) + (y==>3)";

	bb = z==>y==>x==>'BB';
	print bb;

	print "ffff(a==>10,c==>2)";
	print "ffff('A',,'B')";

	return ERROR;
end proc;

func fff(x, a, c);
	print x a c;
	return ERROR;
end func;

func �֐�(������1,������2);
	print ������1 ������2;
	return ERROR;
end func;

proc ppp(x,y,z);
	print 'proc' x y z;
	return ERROR;
end proc;

func ffff(x, a, c, p1,p2,p3);
	print x a c p1 p2 p3;
	return ERROR;
end func;
