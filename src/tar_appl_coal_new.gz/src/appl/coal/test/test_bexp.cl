//
proc main;
	BEXP $1 = 1;

	print $1;
	BEXP $2 = 3;
	print $2 $1+$2;
	BEXP $x = 'a' concat 'b' 'c' 'd' "1+10";
	print $x;
//	BEXP $1++ = ++$2 - 100;

	BEXP ++$1++ = $1 + 10;
	print $1 $2;

	BEXP $1 += 10;
	print $1;
	BEXP $1 concat= 'w' concat 'x' 'y';
	print $1;
//	BEXP $a concat= 'w' concat 'x' 'y' 'z';
//	BEXP a = 'w' concat 'x' 'y';
//	print a;
/*
	BEXP 1 = 2 + 3;
	BEXP %1 = 2 + 3;
	print %1;
	BEXP #1 = 2 + 3;
	print #1;
*/
	BEXP $1 = 10 sqrt 0;
	print $1;
	option 18 2;
	x = '12�R�S5123456ABCDEabcdef67890';
	BEXP $1 = 2 inlike 0 x '%ABC%' 'ig';		//[%ABC%]
	$1 = inlike(2,,x,'%ABC%','ig');		//[%ABC%]
	print $() /i $();
	print *$() /i *$();
	BEXP $1 = 'XYZ' putline 12345;
	BEXP $1 = x substr 10 5;
	print $1;

	return ERROR;
end proc;
