//
define ac[10] = ['Tokyo','Osaka','Nagoya','Aomori','Fukuoka'];
define av[10] = ['Fukuoka','Osaka'];
proc main;
	option 13 +0x02;
//	option 13 -0x280;
	a = 'I still need to visit' &
		 ' the following cities:';

	cities = {'Tokyo','Osaka','Nagoya','Aomori','Fukuoka'};
	visited = {'Fukuoka','Osaka'};
	print /l- {'Tokyo','Osaka','Nagoya','Aomori','Fukuoka'}-{'Fukuoka','Osaka'};

	print /c-  cities-visited;

	print a cities-visited;
	putline(a,cities - visited);
	putline(a,'/cq','/g-',cities - visited);

	say a "cities - visited";

	printf '%s%/lg-%%%s\n' a "cities - visited";
	printf '%s%/lga-%%%s\n' a "cities - visited";
	printf 'ABC%sDEF%/lga-%%%s\n' a "cities - visited";
	printf '%s%/p+10Z,2R/%/lg-/%%%s\n' a "cities - visited";
	printf '%s%/lg/x%%%s\n' a "cities - visited";

	putline(a,'/c','/g-',*(*ac-*av));

	w='';
##if 0
	b = *(*ac - *av);
	print *b /i b;
	for each x in b do
##else
	for each x in *ac-*av do
##endif
		w &= ' ' & x.value;
	next;
	putline(a,w);
	print /i cities-visited;
	print /i *(cities-visited);
	print /i 1 'A';
	putline('/m+',123456.7);

	for each x in *(*ac-*av), *(*ac&*av);
		print *x;
//		w &= ' ' & x.value;
	next;
//	putline(a,w);

	return ERROR;
end proc;
