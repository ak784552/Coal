//
define array a hash = ['A',1,'B',2,'C',3,'D',4,'E',5,'F',6];
define array b hash = ['A',10,'B',20,'C',30,'D',40,'E',50];
define array c hash = ['X',100,'Y',200,'Z',300];
proc main; 

	print *a;
	print *b;
	print arraybxp(c,a,b,5,'+') *c;
	print arraybxp(a,a,b,5,'+') *a;
//	print arraybxp(b,a,b,5,'+') *b;
	print *arraybxp(,a,b,5,'+');

	print arraybxp(,'10','5',,'+');

	return ERROR;
end proc;
