//
proc main;

	print "1 MAX '2'";
//	$x = 10 mod 4;
	$y = mod(10,4);
//	$x = 10 max 4;
//	$y = max(10,4);
	$x = 1 max -2;
//	$y = -10 abs 0;
	putline('$x=',$x,' $y=',$y);
	$max = max(-1.0,-2,3);
//	$max = max('1a','2b','3ab',423);
//	$max = max(1,-2);
	putline('$max=',$max);
//	$min = min(1,2);
	$abs = abs(-10.5);
	putline('$abs=',$abs);
//	putline('$max=',$max,' $min=',$min,' $abs=',$abs);
	print "abs == 0";
	print "10 <> to_bulk(10)";

	return ERROR;
end proc;
