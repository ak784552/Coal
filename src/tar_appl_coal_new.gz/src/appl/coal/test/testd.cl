//
PROC main;
	$d = 1.5f + 10;
	print $d;
	$fp = fopen('wwww','wb');
	print felwrite($fp,'AAAAA',$d,123456789012345.1234567890123456,10);
//	print felwrite($fp,'AAAAA',$d,10);
//	$r = felwrite($fp);
	$r = fclose($fp);
	$fp = fopen('wwww','rb');
	$r1 = felread1($fp,CLCHAR,5);
	$r2 = felread1($fp,CLFLOAT);
	$r3 = felread1($fp,CLDECI,30,15);
	$r4 = felread1($fp,CLBIN);
	print $r1 $r2 $r3 $r4;
	$r = fclose($fp);
	RETURN $ERROR;
END PROC;
