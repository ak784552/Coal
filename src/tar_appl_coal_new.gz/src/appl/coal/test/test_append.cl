//
def aa 10 = [1,2,3];
def bb 10 = [11,12,13];
typedef struct TTT
	int x,
	char y;
typedef array int aaa[10];
aaa b;
TTT xx = [200,'BBB'];
proc main;
	let option 5 1;
//	print bb;
	a = LIST('A',3.5);

//	print a.append(xx);
//	print a *a;
//	print a.append(aa+1);
//	print a a[3];
//	print a.append(*bb);
	a[1] = bb;
	print *a;

	print x=*bb;
	aa[0] = *bb;
	print *aa;

	print a.append(aa);
	print a *a;
//	print *{aa,aa};
	print a.append(a);
	print a *a;
	a[0] = a;
	print a *a;
	print aa.append([100,200,300]);
//	print aa.append(**[100,200,300]);
	print *aa;

	print aa.append(bb);
	print aa;
	print *aa;

	return ERROR;
end proc;
