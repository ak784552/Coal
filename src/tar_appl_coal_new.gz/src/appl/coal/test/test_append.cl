//
def aa 10 = [1,2,3];
def bb 10 = [11,12,13];
def cc 10 = [11,12,13,14,15,16];
typedef struct TTT
	int x,
	char y;
typedef array int aaa[10];
aaa b;
TTT xx = [200,'BBB'];
proc main;

	let option 5 1;
//	print bb;
	a = LIST('A',3.5);

//	print a.append(xx);
//	print a *a;
//	print a.append(aa+1);
//	print a a[3];
//	print a.append(*bb);
	a[1] = bb;
	print *a;

	print x=*bb;
	aa[0] = *bb;
	print *aa;

	print a.append(aa);
	print a *a;
//	print *{aa,aa};
	print a.append(a);
	print a *a;
	a[0] = a;
	print a *a;
	print aa.append([100,200,300]);
//	print aa.append(**[100,200,300]);
	print *aa;

//	print aa.append(bb);
	print append(aa,bb,21,22,23,24,25);
	print aa;
	print *aa;

	xc = cc + [3,2];
	print append(cc,'X') *cc;

	print *xc;
	print append(xc,'Y') *xc *cc;

	yc = cc + 3;
	print *yc;
	print append(yc,'Z');
	print *yc *cc;

//	print append(aa,100) *aa;
//	print aa.append(200) *aa;
	return ERROR;
end proc;
