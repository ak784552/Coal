//
//##include class_sosu_chk.cl
def const MAX_SOSU=1000;
define type struct z
	int a 3
	,char(5) b;
def z aa = [1,2,3,'A'];
proc main;
	print aa *aa;
	redefine aa.a[10];
	print aa *aa;
//	sch = new SosuCheck(100000);
	print ERRMSG;
	return ERROR;
end proc;
