//
define array $a hash;
PROC main;
	loop( 1);
		$a['X' |+ 'AA'] = 1;
		print $a['XAA'];
		putline('***');
	end loop;
	RETURN $ERROR;
END PROC;
