//
proc main;
	$1 = 'XYZ'//
		&+ 123;
	print $1//
 'ABC';//
	/* 'ldfdlkj/*fff'/*
//		*/
		*/
'sd*/sds'
*/
	print '123/* dd*/dd';
	print '123/* dddd';
	print '123 dd*/''dd';
	return ERROR;
end proc;
