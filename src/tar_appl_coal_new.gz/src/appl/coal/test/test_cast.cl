//
proc main;

	print (CCHAR)1 (CBIN)'2' (CDOUBLE)3 (char)4.5 (cstring)4.5 ;

	print ((FUNC)'ABS')(-10);

	print ff('ABS')(-10);
	print (CBULK)1 (CBULK)1234567890;
	print (CCHAR)ABS(1-2);
	print (CCHAR)MAX(1,2);
	print (CCHAR)LENG(1);
	print (CCHAR)XXX(1-2);
	print (CCHAR)+(FUNC);
	print (CINT)'1'+2;
	print (CINT)'1';
	print (CUINT)'-1';
	print (CCHAR)(CBULK)1;
	print (CINTE)'1';
	print "'A' & (CCHAR)12";
	print (CDEC)'12.345';
	dec(10,2) x = 12.345;
	print x;
	print (CCHAR(10))'123456789012345';
	print (CINT(8))'1';
	print (CDOUBLE(8))3;
	print (CDBL(8))3.5;
	print (CFLOAT)3.14;
	print (CFLT)0.456;
	print (CDEC(10,2))'12.345';
	print (CBULK(20))'1234567890123456789012345';

	print (CCHAR())'1';
	print (CCHAR('A'))'1';
	print (CCHAR(0))'1';
	print (CCHAR(-1))'1';
	print (CDEC(,2))'12.345';
	print (CDEC(10,))'12.345';
	print (CDEC('A',2))'12.345';
	print (CDEC(10,'A'))'12.345';
	print (CDEC(0,2))'12.345';
	print (CDEC(-1,2))'12.345';
	print (CDEC(10,1000))'12.345';
	print (CDEC(10,-1000))'12.345';
	print (CPOINTER)'12.345';
//	let array char(3) $a 10;
//	x = 1;
//	(CCHAR)x = 1;
//	(CINT)$a[0] = 1;
//	x=1;
//	-x=0;
//	print x /d x;
//	vari x = '123';
//	print x /d x;

	print (CCHAR(10))'123456789012345';

	print (CCHAR())123.4567;
	print (CDEC(15,2,3))'123456789.012345';
	print (CPOINTER(0))123.4567;

	print ((FUNC(0))'ABS')(-10);

	print (CCHAR(123.4567));
	print CDEC('123456789.012345',15,2);

	print (CINT)'1';
	print (CDEC(15,2))'123456789.012345';
	print (CDATE('YYYY/DD/MM'))'2021/01/02';
	print (CDATE)'2021/01/02';
	print CDATE('2021/01/02','YYYY/DD/MM');
	print CDATE('2021/01/02');
//	int i = 30.0**9;
	print (char)w;

	return ERROR;
end proc;
