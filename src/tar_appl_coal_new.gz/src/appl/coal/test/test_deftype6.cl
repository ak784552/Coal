//
type struct z
	int a
	,dec(10,2) c 10;
var x as z;
//def a.b  =2;
// a=2;
//def ++w = 1;
proc main;
//	char aa.b 2 =0;
//	redefine dec x.c 2;
//	print /i x;
//	local w++ = 1;
//	print w;

	print "private a";
	print y..b;
//	local y.b = 1+2;
	print (-1).abs;
	local array a[10];
//	local =1;
	print ww;
	$1 = 10;
	print $(x.a);
	array x.c=1,2,3,4,5;
	print *x y;
	print a;
	f = abs;
	print f(-2);
	f = 'A';
	print f;

	return ERROR;
end proc;
