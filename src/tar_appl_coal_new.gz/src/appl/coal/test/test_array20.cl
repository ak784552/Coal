//
def opt = $() + [21,4,3,2];
def aaa = $() + [1,-10..10];
//def bbb = $() + {1,SYSDATE..SYSDATE};
def ppp = %() + [1,3..5];
def xxx 20;
proc main;
	print opt;
	print aaa;
//	print bbb;
//	print ppp *ppp /d ppp;
//	print /d SYSDATE..SYSDATE;
	$1 = 123;
	$2 = 456;
	print *$();
	print *aaa;
	aaa[0] = 'ABC';
	print *$() *aaa;
	yyy = xxx + 5;
	xxx[5] = 'AAA';
	print *xxx *yyy;
	yyy[0] = 'BBB';
	print *xxx *yyy;

	return ERROR;
end proc;
