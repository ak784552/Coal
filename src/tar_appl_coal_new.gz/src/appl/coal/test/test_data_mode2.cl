//
define x2 = {**(3.1..5.6..1.1)};
define xx 10 = **range(3.1,5.6,1.1);
define xa 10 = **range('A','E',2);
def aa[10] = ['A','B',,'C','D','E'];
typedef struct ST_XXX
	int a,
	char b;
ST_XXX ss = [1,'R'];
//ST_XXX ss = 1;
proc main;
	print *xx;
	print *xa;
	print *aa;
	x = xx;
	xx[0]= 4;
	print *x *xx;
	y = *xx;
	xx[1]= 7;
	print *y *xx;
	print *ss;
	s = ss;
	t = *ss;
	ss.a = 2;
	print *s *ss;
	print *t *ss;
	return ERROR;
end proc;

proc proc1 argc,argv(a,b,c);
	print argc *%argv a b c;
	return ERROR;
end proc;
