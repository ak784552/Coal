//
//
//
def a = 20;
proc main;
	$1 = 'A';
	local a = 10;
	print "<L>$1";
	return ERROR;
end proc;
