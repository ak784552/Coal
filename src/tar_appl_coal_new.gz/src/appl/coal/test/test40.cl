//
//
//
def a = 20;
proc main;

	$1 = 'A';
	local a = 10;

	print <S>a;
	print <L>a;

	print "<G>$1";
	print "<P>$1";
	print "<S>$1";
	print "<L>$1";

	print "<G>%1";
	print "<P>%1";
	print "<S>%1";
	print "<L>%1";

	print "<G>#1";
	print "<P>#1";
	print "<S>#0";
	print "<L>#1";

	print aaa('A');

	print <L>aaa;
	print <L>$abs;

	print (char)<S>$a;

	return ERROR;
end proc;

func aaa(a);
	print a "<S>%1";
	print a "<L>%1";
	return ERROR;
end func;
