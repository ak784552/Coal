//
//def int ++a = 11;
def int a = 11, b = 21, c = 1;
def array x,y,z = [1,2,3,4,5];
typedef struct SSS
	int x,
	char y;
SSS aa,bb=*[10,'AAA'];
//def xxx=1;
//def xxx+1;
proc main;
	print *aa *bb;
	print a b c;
//	vari ++xx = 11, yy = 21, zz = 1;
//	print xx yy zz;
	aaa = a;
	print aaa;
//	const a = 10;
	xxx=1;
	local ++xxx = xxx;
//	local +xxx = xxx;
//	local -xxx = xxx;
//	local +-xxx = xxx;
	print xxx;
	local int $(y='yy')=1;
	print yy y;
//	local int xxx++ = xxx;
	local xxx++ = xxx;
	print xxx;
//	int xxx(0)=100;
//	int xxx+1;
	print $MAX_LOOP_WHILE;
//	int aa,bb=1;
	print /i xxx;
	print /i aa bb;
	print *aa *bb;
	print a b c;
	print x y z;
	print *x *y *z;

	SSS aa,bb = *[11,'BBBB'];
	print *aa *bb;

//	int ee++ =20;
//	int ee = 'AA';
	print ee;
	char cc+='1';
//	print cc;
	loop 2;
		local cc=30, private gg='BBB';
		print cc gg;
	end loop;
//	local cc=35;
	local cc=35, private gg='bbb';
	local const hh=40, jj='CC';
//	local dd=40,'CCC';
	print cc dd ee gg hh jj;
	print /i cc dd ee gg hh jj;
//	1=1;
	ff(10,'AAAA');
	print cc gg;
	ff(20,'CC');
	print cc gg;
	char kk 5 = ['A','B','C'], mm = 100;	// -o24=0x10 �ŃG���[
//	char kk 5 = 'A','B','C', mm = 100;	// -o24=0x10 �ŁAKK�ɂ́A'A','B','C','100'���Z�b�g�����
	print *kk mm;
	return ERROR;
end proc;

func ff(a,b);
	local cc=a, private gg=b;
	return ERROR;
end func;
