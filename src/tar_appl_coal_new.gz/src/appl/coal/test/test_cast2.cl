//
option 11 6;
define array a[10] = [1,2,3,4,5];
proc main;
	print (CCHAR(%1))a[0]*2;
	print (CCHAR(%1))(a[0]*2);
	x=10000000.0;
	print cdec(x);
	print cstr(x);
	x=9.999999999999999999999999999999999999999999999999999992;
	print round(x,48,0x10);
	dec(20,15) w=x;
	print w;
	print (VARI(10))1.6;
	return ERROR;
end proc;
