//
proc main;
	print eval('',1) ERROR;
	print eval('',2) ERROR;
	print eval('1+1') ERROR;
	print eval('1+1',1) ERROR;
	print eval('$x+1',1) ERROR;
	print eval('$x+1',2) ERROR;
//	print eval('1+a',0) ERROR;

//	$a = max(1,2);
	return ERROR;
end proc;
