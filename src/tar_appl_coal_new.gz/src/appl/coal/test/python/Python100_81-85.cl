//
//
//
import module;
/*
class Card ;
	char suit;
	int  number;
	func Card(suit,number);
		My.suit = suit;
		My.number = number;
		return 0;
	end func;
end class;
*/
class Deck;
	cards = '';
	func Deck();
		cards = [];
		for each suit in ['�n�[�g','�_�C��','�X�y�[�h','�N���u'];
			for each number in 1..13;
				card = new Card(suit.value,number.value);
//print card.suit card.number;
				append(My.cards,card);
			next;
//print *My.cards;
		next;
	end func;
	func shuffle();
		return 0;
	end func;
	func draw_card();
		return pop(My.cards);
	end func;
end class;

proc main;
// 81
echo '81���';
	option 5 +0x01;
	deck = new Deck();
	deck.shuffle();
	loop 5;
		card = deck.draw_card();
//		print card;
//		print card.suit card.number;
	end loop;

// 82
echo '82���';
	print add(1,2);

// 83
echo '83���';
	card = new Card('�n�[�g',1);
	print card.suit card.number;
	print URL;
//84
echo '84���';

//85
echo '85���';

	return;
end proc;
