//
def a 5 = ['A',2,'C','D','E'];
def b,bb;
proc main;

//	print *a;
//	b = '';
	c = 123;
	d = a;

	print func1(a,b,c);
	print *a a[0];
	print b c;
/*
	call proc1 a bb c;
	print *a;
	print bb c;
*/
	return $ERROR;
end proc;

function func1 (x,*y,z);
	x[0] = 'B';
	*y = 'AAA';
	print *x *y z;
	z = 456;
	return 0;
end func;

proc proc1(x,*y,z);
	x[0] = 'F';
	*y = 'BBB';
	print z;
	z = 789;
	return 0;
end proc;
