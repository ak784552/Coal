//
define array int $a 10000;
//define array char $a 10000;
//define array     $a 10000;
proc main;
	let options 2;
	$i = 0;
//	loop 10000;
	loop 10;
//		$a[$i] = '*';
//		$a[$i] = 1;
		$x = $a[$i];
		$i++;
	endloop;
	print i;
	return ERROR;
end proc;
