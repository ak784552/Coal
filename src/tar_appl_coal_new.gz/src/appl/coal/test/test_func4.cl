//
//
proc main;
	a = 1.0;
	b = 1.5;
	y = 0.3;
	z=f(a,y)+f(b,y); 
	print z;
	return $ERROR;
end proc;

func f(x,y);
	return x*y;
end func;
