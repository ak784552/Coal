//
proc main;
	xx = new aaa(10);
	print xx.a;
	print xx.b;
	print xx.d;
	xx.bbb(30);
	print xx.b;
	xx.ccc('AAA');
	print xx.c;
	return ERROR;
end proc;

//class aaa extends super_aaa;
class aaa < super_aaa;
//	int a;
//	char b;
//	local a;
	local b=10;
	print 'class aaa' b;
/*
	func aaa(x);
		print 'aaa' x;
		a = x;
		return 0;
	end func;
*/
end class;

class super_aaa extends super_xxx;
//	int a;
//	char b;
	local a='asdf';
	local b=20;
	print 'class super_aaa' b;
	func super_aaa(x,y);
		print 'super_aaa' x;
		a = x;
		return 0;
	end func;
	func bbb(x);
		print 'bbb' x;
		b = x;
		return 0;
	end func;
end class;

class super_xxx;
	local c='ABCD';
	print 'class super_xxx' c;

	func super_xxx(x);
		print 'super_xxx' x;
		c = x;
		return 0;
	end func;
	func ccc(x);
		print 'ccc' x;
		c = x;
		return 0;
	end func;
end class;
