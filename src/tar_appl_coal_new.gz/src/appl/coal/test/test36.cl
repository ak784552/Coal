//
proc main;
	call proc1;
	getmemused(1);
	printf strings(' ',21);
	print /n- *$();
	return ERROR;
end proc;

proc proc1;
	implicit double (d);

	t0 = gettime();
	print /nq- ' k   time(s)       N  mem(1,2,3,4,5,M,U,m,f,r)';
	N = 3;
	for k=1 to 3;
		dr = 0.05;
		dri = 0.0;
		drj0=1.0;
		j0=N;
		for i=0 to N;
//print i;
			drj = drj0;
			dri2 = dri*dri;
//print dri2 dri;
			for j=j0 to 0 step -1;
//print j;
				drj2=drj*drj;
//print drj*drj;
//print dri2 drj drj2;
				d = sqrt(dri2 + drj2);
//print d;
				drj -= dr;
//print drj dr;
			next;
			dri += dr;
//print dri dr;
		next;
		N += N;
		t = gettime()-t0;
		tt = 0;
		st = edit('%5.3f',t);
		st = lpad(st,9);
		getmemused(1);
		printf('%2d %s %7d ',k,st,N);
		print /n- *$();
//		printf '%d,' $(i) do i=1,4;print;
/*
		printf strings(' ',23);
		printf '%d,%d,' $5 $6;print;
		printf strings(' ',23);
		printf '%d,' $(i) do i=7,9;print /n- $10;
*/
	next;
	return ERROR;
end proc;
