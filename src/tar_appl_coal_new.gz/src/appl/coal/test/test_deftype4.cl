//
define type struct z
	int a
	,char(5) b
	, dec(10,2) c 10,
;
define var x1,x2,x3 as z;
define x[10];
proc main;

	print z;
	print x;
	x1.a=1;
	x1.b='qwe';
	x1.c[0]=123.456;
	print *x1;
	x[0]=*x1;
	print *x;
	x1.a=2;
	x1.b='fghjkl';
	x1.c[0]=0.0876;
	x[1]=x1;
	print *x;

	y=0.00823;
	w=0.1823;
	print y w;
	y1=12.00823;
	w1=345.1823;
	print y1 w1;
	return ERROR;
end proc;
