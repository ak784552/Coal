//
def h hash 10 = ['A',11,'B',22,'C',33,'D',44,'E',55];
def char x 10 = [10,20,30,40,,60];
def y 10 = [21,22,23,24,,26];
def xx 10;
proc main;

	a = [1,2,x,4,5,,7];
	print actas(a,'+',10);
	print a;
	print *actas(x,'-',5);
	print *x;
	print *actas(y,'-',5,NUM==>3);
	print *y;
	print actas(a,'CONCAT',10);
	print a;
//	print /i {1,2,3};
	print actas({1,2,3},'*',2);
	print actas({1,2,3},'*',2,,1);
	b = [11,22,33,x,55];
	print actas(b,'=+',10);
	print *actas(x,'=-',5,3);
	print actas(a,'=',10);
	print a;
	b = [1,2,3,4,5];
	print actas(b,'+',100,,1);

	print *actas(h,'*',2,,1);
	print *h;
	print *actas(h,'*',2);
	print *h;
	set_array(1,10,11,12,13,14,15);
//	print *actas(1,'/',2.0,,1);
	print *actas(1,'/',2.0);
	print *$();
	print /i actas(100,'+',100,,1);
	print $100;
	c = $() + 100;
	print c c[0];
	print *actas(xx,'+',5);
	print *xx;
	print *actas(xx,'+',5);
	print *xx;
	d = {};
	print actas(d,'+',5);
	print d;
	print actas(d,'+',5);
	print d;
	e = [1,2,NULL,,7];
	print actas(e,'+',10);

	print *actas(0,'+',20);

	print actas([-1,-2],abs,0);
	print actas([PI/2,M_E],sin,0);
	print actas(['1.25',3],to_number,2);

	print actas([-1,-2],fun,1);

	return ERROR;
end proc;

function fun(a,b,c);
print a b c;
	return a+b;
end func;
