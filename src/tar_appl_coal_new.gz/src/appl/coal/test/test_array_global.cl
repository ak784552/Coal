//
define array global $ab 2 3 4;
define global array $xx 10;
define global gw = 'AA';
define pwa 10;
define pw = 'CC';
//define pw;
//define pwa 20;
proc main;
	print ab xx;
	private pw;
	$ab[0,0,0] = 1;
	print $ab[0,0,0];
	exec sc 'test_array_global1';
	print $ab[0,0,0] $xx[1];
	print gw;
	return $ERROR;
end proc;
