//
define type struct z
	int a
	,char b;
dim s as z;
define text='1234567890';
proc main;
//	print '1234'.0;
//	print '1234'.3;
	print (1).0;
	print (1).(0);
	print 1.(0);	// "1."�����l�ƌ��Ȃ����
	print (1).print() 1.print();
	print System.print('AA');
	y = 2;
	print x.*y;
	print x./y 1./y (1)./y;

	print "s.a = 100";
	f(1);
//	f();
	f2(10,20);
	'AAAA'.f();
	'BBBB'.f2('CCC');

	print *('A'..'Z');

	return ERROR;
end proc;

func f(x);
	print x;
	a = 'XYZ';
	b = '3..8';
	c = 3..7;
	d = '2,3..8';
	e = a..b;
	print s.a;
	print text.6;
	print text.b;
	print text.c;
	print text.d;
	print text.'2,3';
	print text.e;
	print text.(3..7);
	print text.'3..7';
	return 0;
end func;

func f2(x,y);
	print x y;
	a = 'XYZ';
	b = '3,4';
	loop 2;
		print s.a;
		print text.b;
	end loop;
	return 0;
end func;
