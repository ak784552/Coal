//

define type struct z
	int a 5 3 2
	, char(5) b
	, dec(10,2) c 10,
	bulk(20) d
	,double e hash
	, variant f
;
define mappedarray $ma 3 20=[1,2,3,4,5];
//define mappedarray %pa 5 17;
dim x as z;

define global x=1;
define global xx='A';
define array aa 10;
proc main;
//	option 12 2;
	print ma *ma;
//	dim a as ('z');
	print a;
//	dim private  dec (10,3 ) y;
	var private yi as int;
	aa[0] = 'A';
	loop 2;
		print '1' x aa aa[0];
		var local x;
		if !ndef('local aa','');
			local array aa 20;
		end if;
		x = 10;
		aa[0] = 'B';
		print '2' x aa aa[0];
	end loop;
	private array xx 10;
	print x xx;
	return ERROR;
end proc;
