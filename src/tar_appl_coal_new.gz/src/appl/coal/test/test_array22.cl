//
//def array a 10 = [11,12,13,14,15,16,17,18,19,20];
proc main;

	a = $() + [0,10];
	setarray(1,11,12,13,14,15,16,17,18,19,20);
	print *$();
	print a *a;
	print a[2..5];
	print a[2..5..2];
	print *a[2..5];
	print *a[2..5..2];
	print *a[5..2..-2];

	array b 10 = a[2..5];
	print b b[0] /d b[0];
	print *b[0] *b;

	array bb 10 = *a[2..5];
	print bb bb[0] *bb;

	c = a[2..5];
	print c *c;

	d = *a[2..5];
	print d *d;

	print a[0];
	print *mid(a,3);

	return ERROR;
end proc;
