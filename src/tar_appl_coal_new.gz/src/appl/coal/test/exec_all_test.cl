//
//(1)�R�}���h
//	../coal exec_all_test list_test.txt [-pqsnl] [test_case ...]
//	�I�v�V����
//	"-p test_case ... ":test_case�ȍ~�����s�̗L�����m�F���Ȃ�����s����
//	"-q" : �X�N���v�g�̎��s�̗L�����m�F����
//	"-s" : ���s�̗L�����m�F���Ȃ�
//	"-n" : �P�[�X���݂̂��o�͂���
//	"-l" : ���s���C�����o�͂���
//
//(2)���X�g�t�@�C���d�l
//	"@[�C�ӕ���] �P�[�X��" : �P�[�X�̊J�n�B����"@"�܂�
//	"@[�C�ӕ���]: �P�[�X�̏I���
//	"//": ���s�I��
//	"##": �P�[�X���ňȍ~���X�L�b�v�B"@[�C�ӕ���]"�݂̂Ɠ���
//	"#" : 1�s�X�L�b�v
//	"-o �I�v�V�����ݒ�": �ݒ�t�@�C����OPTION�Ɠ����B"//"�ȍ~�̓R�����g
//	"--d2,200"
//	"/*": "*/"�܂ŃR�����g
//	�X�N���v�g�� �p�����[�^-1 �p�����[�^-2 �E�E�E: ���s����X�N���v�g
//		���s����X�N���v�g�̃p�����[�^����"//": �ȍ~�R�����g
//
def a 50;
def opt 31;
def logprm 10;
def int max_loop_while;
def here_doc = '';
def list_file = '';
def line;
def end_flg = 0;
def p_mode = 0;
def q_mode = 0;
def s_mode = 0;
def l_mode = 0;
def to_read = 1;
def opt15;
//***************************
//*	main					*
//***************************
proc main;
	if !%0 then
		echo 'usage:' SCRIPTNAME 'test_file [-psnl] [test_case ...]';
		echo '  -p test_case ... : test_case�ȍ~�����s�̗L�����m�F���Ȃ�����s����';
		echo '  -q : �X�N���v�g�̎��s�̗L�����m�F����';
		echo '  -s : ���s�̗L�����m�F���Ȃ�';
		echo '  -n : �P�[�X���݂̂��o�͂���';
		echo '  -l : ���s���C�����o�͂���';
		return 1;
	else
//		exec >& rusult.txt;
		list_file = %1;
		shift;
		while %0;
			arg = %1 to 'U';
			if left(arg,1) == '-' then
				if instr(arg,'S') > 0 thenl s_mode = 1;
				if instr(arg,'P') > 0 thenl p_mode = 1;
				if instr(arg,'Q') > 0 thenl q_mode = 1;
				if instr(arg,'N') > 0 thenl s_mode = 2;
				if instr(arg,'L') > 0 thenl l_mode = 1;
				shift;
			else;
				break;
			end if;
		end while;
//print %0 s_mode p_mode %1;
		if s_mode == 2 then
			exec ip list_case;
		elseif %0==0 then
			p_mode = 0;
			exec ip normal_exec;
		else
			if p_mode then
				exec ip normal_exec;
			else
				exec ip find_exec_case;
			end if;
		end if;
	end if;
	return ERROR;
end proc;

//***************************
//*	find_exec_case			*
//***************************
proc find_exec_case;
	while %1;
		try (fp = fopen(list_file)) ;
			get_option();
			i = 0;
			loop ;//for i=0 to 5;
				line = fgetline(fp);
				if !line then
					continue;
				end if;
				n = split(line,a,23,,0x80);
				f = a[0];
				if ret=if_other(n,fp,f,'') then
					if ret == 100 then
						break;
					end if;
				elseif left(f,1)=='@' && n>=2 then
					if %1 == a[1] then
						exec ip exec_case fp a[1];
						break;
					end if;
				end if;
			end loop;
		catch FILE_READ_END_EXCEPTION;
			;
		catch;
			print ERRMSG;
	//	finally;
	//		if ERRMSG thenl print /n ERRMSG;
		end try;
		shift;
	end while;
	return ERROR;
end proc;

//***************************
//*	normal_exec				*
//***************************
proc normal_exec();
//print 'Enter normal_exec' list_file %1;
	try (fp = fopen(list_file)) ;
		get_option();
		i = 0;
		line = '';
		loop ;//for i=0 to 5;
			if to_read then
				line = fgetline(fp);
//print line;
				if !line then
					continue;
				end if;
			end if;
			n = split(line,a,23,,0x80);
			f = a[0];
//print f;
//print f /x getval('OPTION',21);
			if ret=if_other(n,fp,f,'') then
				if ret == 100 then
					break;
				end if;
			elseif left(f,1)=='@' && n>=2 then
//print line;
				if p_mode then
					if %1 <> a[1] then
						continue;
					end if;
					p_mode = 0;
				end if;
				if !s_mode then
				//	printf /u '%s ��������܂����B���s���܂����H(n/c/[y|etc])' line;
					printf('%/u%s ��������܂����B���s���܂����H(n/c/[y|etc])',line);
					yn=left(getline(),1) to 'U';
					if yn=='N' then
						continue;
					elseif yn=='C' then
						break;
					end if;
				end if;
				exec ip exec_case fp a[1];
				if end_flg then
					break;
				end if;
			end if;
		end loop;
	catch FILE_READ_END_EXCEPTION;
		;
	catch;
		print ERRMSG;
//	finally;
//		if ERRMSG thenl print /n ERRMSG;
	end try;
	return ERROR;
end proc;

//***************************
//*	exec_case				*
//***************************
proc exec_case(fp,case_nam0);
	case_nam = case_nam0;
	putline('@@@@@@@@@@ start ',case_nam);
	ret = 0;
	to_read = 1;
	loop ;//for i=0 to 5;
		line = fgetline(fp);
//print line;
		if !line then
			continue;
		end if;
//		arrayclr(a);
		n = split(line,a,23,,0x80);
//print n *a;
		f = a[0];
		if left(f,1)=='@' then
			if n > 1 then
				to_read = 0;;
			end if;
			break;
		end if;
		f = a[0];
		if ret=if_other(n,fp,f,case_nam,1,1) then
			if ret == 100 then
				break;
			end if;
		else
			if q_mode then
//				printf('/u','%s �����s���܂����H(n/c/[y|etc])',$f);
				printf('%/u%s �����s���܂����H(n/c/[y|etc])',$line);
				yn=left(getline(),1) to 'U';
				if yn=='N' then
					continue;
				elseif yn=='C' then
					break;
				end if;
			end if;
			echo '*** start' f '***';
			try;
				nparm = chk_heredoc(n,fp);
//print *$();
				if l_mode ; setlogparm('DEBUG_LOG',1,100); end if;
			//	exec sc:trypass $f $*;
			//	exec sc:notrypass $f $*;
			//	exec sc $f $*;
			//	exec sc $f $1,20*;
				exec sc $f $(1,nparm)*;
				reset_option();
			catch FILE_READ_END_EXCEPTION;
				;
			catch;
				print ERRMSG;
			end try;
			undef const like public % not global ei_to_u eb_to_u PI_180;
			reset_option();
			echo '*** end  ' f '***';
		endif;
	end loop;
	reset_option();
	if ret<>100 then
		putline('@@@@@@@@@@ end ',case_nam);
	end if;
	return ERROR;;
end proc;

//***************************
//*	if_other				*
//***************************
func if_other(n,fp,f,nam,mode=0,ex_opt=0);
	to_read = 1;
	f2 = left(f,2);
	if f2=='//' then
//print '//';
		ret = 100;
		end_flg = 1;
	elseif left(f,2)=='##' then
		if mode then
			echo '*** skip ' nam '***';
		end if;
		ret = 100;
	elseif ex_opt && f2=='-o' then
//print '-o';
		a[0] = substr(f,3);
		set_option(n);
		ret = 1;
	elseif ex_opt && left(f,3)=='--d' then
		array x[2];
		nx = getargs(substr(f,4),x);
//print nx *x;
		if nx==2 then
			setlogparm('DEBUG_LOG',x[0],x[1]);
		end if;
		ret = 1;
	elseif f2=='/*' then
//print '/*';
		skip_comment(fp);
		ret = 1;
	elseif left(f,1)=='#' then
//print '#';
		if mode then
			echo '*** skip ' f '***';
		end if;
		chk_heredoc(n,fp,0);
		if $1 then
			t = '';
			if ($2 & 0x02) then
				t &+= '\\t';
			end if;
			if ($2 & 0x04) then
				t &+= ' ';
			end if;
			loop;
				line = fgetline(fp);
//print line;
				if trim(line,t) == $1 then
					break;
				end if;
			end loop;
			to_read = 0;
		end if;
		ret = 1;
	else
		ret = 0;
	end if;
	return ret;
end func;

//***************************
//*	get_option				*
//***************************
func get_option();
	getlogparm(2,logprm);
	max_loop_while = MAX_LOOP_WHILE;
	for i=1 to 30;
		opt[i] = getval('OPTION',i);
	next;
	opt15 = opt[15];
//print 'get_option' opt opt15;
	return ERROR;
end func;

//***************************
//*	reset_option			*
//***************************
func reset_option();
	reslogparm(logprm);
	option 15 opt15;
//print 'reset_option' opt;
	option 1 opt[1];
	MAX_LOOP_WHILE = max_loop_while;
	for i=1 to 30;
		option i opt[i];
	next;
	return ERROR;
end func;

//***************************
//*	set_option				*
//***************************
func set_option(n);
	max_loop_while = MAX_LOOP_WHILE;
	for i=0 to n-1;
		ii = i;
		val = a[i];
		if left(val,2) == '//' then
			break;
		elseif (pos=instr(val,'='))>0 then
			ii = left(val,pos-1);
			val = substr(val,pos+1);
		end if;
//print ii val;
		option ii val;
	next;
	return ERROR;
end func;

//***************************
//*	chk_heredoc				*
//***************************
func chk_heredoc(n,fp,mode=1);
	arrayclr(1);
	here_doc = '';
	nparm = 0;
	if !mode then
		$1 = '';
		$2 = 0;
		nparm = 2;
	end if;
	ii = 1;
	for i=1 to n-1;
		x = a[i];
//print i x;
		if left(x,2)=='<<' then
			nam = substr(x,3);
			pos = skip_opt(nam,'-=!',8);
			hd_opt  = 0x10;
			if pos > 0 then
			//	if instr(nam,1,pos,'!') then hd_opt  = 0x10; endif;
				if instr(nam,1,pos,'-') then hd_opt |= 0x20; endif;
				if instr(nam,1,pos,'=') then hd_opt |= 0x60; endif;
				nam = substr(nam,pos+1);
			end if;
			if nam=='' then
				if i < n-1;
					nam = x = a[i+1];
				end if;
			endif;
//			if nam<>'' then
			if mode then
//print /x fp;
				here_doc = redirect(fp,nam,hd_opt);
//print to_bulks(fp,nam);
//				here_doc = to_bulks(fp,hd_opt,nam)<=='STDIN';
				nparm = ii;
				$(ii++) = here_doc;
//print here_doc nparm;
			else
				$1 = nam;
				$2 = hd_opt;
			endif;
			break;
		elseif left(x,2)=='//' then
			break;
		else
			if mode then
				$(ii) = x;
			end if;
//print ii $(ii) $0;
			nparm = ii;
			ii++;
		endif;
	next;
	return nparm;
end func;

//***************************
//*	skip_comment			*
//***************************
func skip_comment(fp);
	loop;
		line = fgetline(fp);
//print line;
		if !line then
			continue;
		end if;
		n = split(line,a,2,,0x80);
		f = a[0];
		if left(f,2)=='*/' then
			break;
		end if;
	end loop;
	return ERROR;
end func;

//***************************
//*	list_case				*
//***************************
proc list_case;
	try (fp = fopen(list_file)) ;
		i = 0;
		loop;
			line = fgetline(fp);
			if line then
				if left(line,2)=='/*' then
					skip_comment(fp);
				elseif left(line,1)=='@' then
					n = split(line,a,2,,0x80);
					if n>=2 then
						putline(a[1]);
					end if;
				end if;
			end if;
		end loop;
	catch FILE_READ_END_EXCEPTION;
		;
	catch;
		print ERRMSG;
	end try;
	return ERROR;
end proc;
