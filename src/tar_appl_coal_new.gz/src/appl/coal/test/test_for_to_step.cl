//
proc main;
	y = 5;
	z = 1;

	for x=0 To 5;
		echo x;
	endfor;
	for x=0 TO 5 STEP 1;
		echo x;
	endfor;
	for x=5 TO 0 STEP -1;
		echo x;
	endfor;
	for x=0 TO y STEP z;
		echo x;
	endfor;

	z = -2;
	for "x = 5" TO 0 STEP z as lfor;
		echo x;
	endfor;

	n_f = 5;
	n_t = 5;
	n_i = 1;
	for x=n_f TO n_t STEP n_i;
		echo x;
	endfor;

	return ERROR;
end proc;
