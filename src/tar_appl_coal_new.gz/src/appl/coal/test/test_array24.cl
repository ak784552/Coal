//
option 15 0x01;
//def a[2,3,4] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];
def a[0..1,0..2,0..3] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];
def b hash = ['AA',100,'BB',200];
def mappedarray aa 1 5 = [101,102,103];
def cc 10;
proc main;
	print a *a;
	print b *b;
	print aa *aa *$();

//option 15 0x01;
//option 15 0x02;
	for k=0 to 3;
		print k;
		for j=0 to 2;
			printf('j=%d : ',j);
			for i=0 to 1;
				printf(' %d',a[i,j,k]);
			next;
			print;
		next;
	next;

	c = a + 12;
//	print c /d c;
	print *c;
//	print c[14] c[15];

	return ERROR;
end proc;
