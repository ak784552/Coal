//
proc main;
	loop 10;
		n = fun1();
		print $n;
	end loop;
	return $ERROR;
end proc;

func fun1();
	printf('Enter next any key.\n');
	line = getline();
//	if $ERROR thenl return ERROR;
	n = getargs(line,1,5);
	return n;
end func;
