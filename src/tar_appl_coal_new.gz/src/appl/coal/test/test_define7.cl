//
proc main;
//	print f1(10);
//	print f1(5);
//	print f3(3);

	xx = f2('a',10);
//	print a *a;
	print xx *xx;
	print y *y;
	print yy *yy;
	xx = f2('b',5);
//	yy = f2('b',5);
//	yy = f2('a',5);
	print y *y;
	print yy *yy;

	print var_list();

	return ERROR;
end proc;

func f1(n);
	array a[n,1,1] = [1,'A',10];
	print a *a;
	return 0;
end func;

func f2(x,n);

//	private
	array $$x[n,1,1] = [1,'A',10];
	print $$x *$$x;
	private y = *$$x;
	private yy = $$x;
	print y;
	print yy *yy;
//	return y;
	return yy;
//	return *$$x;
/*
	array a[n] = x;
	private y = *a;
	return 0;
*/
end func;

func f3(n);
	array a n+1 1 1 = [2,'B',20];
	print a *a;
	return 0;
end func;
