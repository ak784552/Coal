//
##define MAX_SOSU 100
##define INIT_MAX_SOSU 32
##define KMAX 20
/*
	dec sosu MAX_SOSU =
		{ 2,  3,  5,  7, 11, 13, 17, 19, 23, 29,
		 31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
		 73, 79, 83, 89, 97,101,103,107,109,113,
		127,131};
*/
def kaisou;
def const zero=0;
def dflg=0;

class SosuCheck;

	dec sosu MAX_SOSU =
		{ 2,  3,  5,  7, 11, 13, 17, 19, 23, 29,
		 31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
		 73, 79, 83, 89, 97,101,103,107,109,113,
		127,131,137,139,149,151,157,163,167,173,
		179,181,191,193,197,199,211,223,227,229,
		233,239,241,251,257,263,269,271,277,281,
		283,293,307,311,313,317,331,337,347,349,
		353,359,367,373,379,383,389,397,401,409,
		419,421,431,433,439,443,449,457,461,463,
		467,479,487,491,499,503,509,521,523,541,
		547,557,563,569,571,577,587,593,599,601,
		607,613,617,619,631,641,643,647,653,659,
		661,673,677,683,691,701,709,719,727,733,
		739,743,751,757,761,769,773,787,797,809,
		811,821,823,827,829,839,853,857,859,863,
		877,881,883,887,907,911,919,929,937,941,
		947,953,967,971,977,983,991,997};

	int max_sosu = INIT_MAX_SOSU;
	int def_max_size = MAX_SOSU;

func SosuCheck();
	kaisou=0;
	return 0;
end func;

func SosuCheck(n);
	kaisou=0;
//	if leng(My.sosu,2) < n then
//		redefine My.sosu n;
	if leng(sosu,2) < n then
		redefine sosu n;
		def_max_size = n;
print n sosu;
	end if;
	return 0;
end func;

func get_sosu(i);
	int mmax=max_sosu;

	kaisou++;
	if (i>=mmax) then
		ret = add_next_sosu(0);
		if ret < 0 then
			return ret;
		end if;
	end if;
	kaisou--;
//	return My,sosu[i];
	return sosu[i];
end func;

func sosu_chk_by_tbl_opt(l);
//	dim i,mmax,m as dec(50,0);
	dim ll,l1,l2,m as dec(50,0);
	int i,mmax;
//	int ll,l1,l2,m;

	mmax=max_sosu;
	ll = l;

	if (ll < 2) then return 0;
	elseif (ll == 2) then return 1;
	elseif (ll <= 7) then
		if (ll&0x01) thenl return 1;
		return 0;
	end if;
	kaisou++;

	l2 = sqrt(ll);
	for (i=0;i<mmax;i++) do;
//		if (!(ll % (m=My.sosu[i]))) then
		if (!(ll % (m=sosu[i]))) then
			break;
		endif;
		if (m > l2) thenl break;
	next;
	if (i>=mmax) then
##if 1
		kaisou--;
		return -2;
##else
		ret = add_next_sosu();
		if ret < 0 then
			kaisou--;
			return ret;
		else
			kaisou--;
			return sosu_chk_by_tbl_opt(l);
		end if;
##endif
	elseif (m>l2) then
		kaisou--;
		return 1;
	end if;
	kaisou--;
	return 0;
end func;

func add_next_sosu(m0);
	dec(50,0) $max;

	mmax = max_sosu;
	if mmax >= def_max_size thenl return -1;
//	i0 = My.sosu[mmax-1] + 2;
	i0 = sosu[mmax-1] + 2;
//	$max = (CINT)sqrt(m)+1;
//	$max = i0 + 20;
	$max = m0;
	if $max then
		$max = sqrt($max);
		$max += KMAX;
	end if;
print mmax i0 $max;
	kaisou++;
/*
if !dflg then
SETLOGPARM(2,2,200);
dflg=1;
else
dflg++;
if dflg>2 thenl return -1;
end if;
*/
	i=i0;
//	for (k=0;k<KMAX;);
//	for (i=i0;i<=$max;i+=2);
	k = 0;
	i=i0;
	loop;
		if m0 && i>$max thenl break;
		if (ret=sosu_chk_by_tbl_opt(i))>0 then
			if mmax<def_max_size then
			//	My.sosu[mmax++] = i;
				sosu[mmax++] = i;
				max_sosu = mmax;
				k++;
//print mmax k;
				if !m0 && k>=KMAX thenl break;
			else
				kaisou--;
				return -1;
			endif;
		elseif ret<0;
			kaisou--;
			return ret;
		end if;
		i += 2;
//	next;
	end loop;
print kaisou mmax i;
	max_sosu = mmax;
	kaisou--;
//GETMEMUSED(1);
//print *$();
	return 0;
end func;

end Class;
