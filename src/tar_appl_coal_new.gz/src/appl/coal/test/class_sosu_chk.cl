//
##define MAX_SOSU 2100
##define INIT_MAX_SOSU 32

	dec sosu MAX_SOSU =
		{ 2,  3,  5,  7, 11, 13, 17, 19, 23, 29,
		 31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
		 73, 79, 83, 89, 97,101,103,107,109,113,
		127,131};
def kaisou;
def const zero=0;
def const n10=10;

class SosuCheck;
	int max_sosu = INIT_MAX_SOSU;
	int def_max_size = MAX_SOSU;

func SosuCheck();
	kaisou=0;
	return 0;
end func;

func SosuCheck(n);
	kaisou=0;
//	if leng(My.sosu,2) < n then
//		redefine My.sosu n;
	if leng(sosu,2) < n then
		redefine sosu n;
		My.def_max_size = n;
print n My.sosu;;
	end if;
	return 0;
end func;

func get_sosu(i);
	int mmax=My.max_sosu;

	kaisou++;
	if (i>=mmax) then
		ret = My.add_next_sosu();
		if ret < 0 then
			return ret;
		end if;
	end if;
	kaisou--;
//	return My,sosu[i];
	return sosu[i];
end func;

func sosu_chk_by_tbl_opt(l);
//	dim i,mmax,m as dec(50,0);
	dim ll,l1,l2,m as dec(50,0);
	int i,mmax;
//	int ll,l1,l2,m;

	mmax=My.max_sosu;
	ll = l;

	if (ll < 2) then return 0;
	elseif (ll == 2) then return 1;
	elseif (ll <= 7) then
		if (ll&0x01) thenl return 1;
		return 0;
	end if;
	kaisou++;

	l2 = sqrt(ll);
	for (i=0;i<mmax;i++) do;
//		if (!(ll % (m=My.sosu[i]))) then
		if (!(ll % (m=sosu[i]))) then
			break;
		endif;
		if (m > l2) thenl break;
	next;
	if (i>=mmax) then
//		return -2;
		ret = My.add_next_sosu();
		if ret < 0 then
			kaisou--;
			return ret;
		else
			kaisou--;
			return sosu_chk_by_tbl_opt(l);
		end if;
	elseif (m>l2) then
		kaisou--;
		return 1;
	end if;
	kaisou--;
	return zero;
end func;

func add_next_sosu();
	mmax = My.max_sosu;
	if mmax >= MAX_SOSU thenl return -1;
//	i0 = My.sosu[mmax-1] + 2;
	i0 = sosu[mmax-1] + 2;
//	$max = (CINT)sqrt(m)+1;
//	$max = i0 + 20;
//print mmax m i0 $max;
	kaisou++;
	i=i0;
	for ($_k=zero;$_k<n10;);
//	for (i=i0;i<=$max;i+=2);
		if (ret=My.sosu_chk_by_tbl_opt(i))>zero then
			if mmax<My.def_max_size then
			//	My.sosu[mmax++] = i;
				sosu[mmax++] = i;
				My.max_sosu = mmax;
				$_k++;
//print mmax k;
			else
				kaisou--;
				return -1;
			endif;
		elseif ret<0;
			kaisou--;
			return ret;
		end if;
		i += 2;
	next;
print kaisou mmax i;
	My.max_sosu = mmax;
	kaisou--;
	return 0;
end func;

end Class;
