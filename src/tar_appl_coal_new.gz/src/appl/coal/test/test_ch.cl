//
define array $a 10;
PROC main;
	$ch = Channel('Open',%1,%2,%3);
	print ERROR ERRNO ERRMSG $ch;
	if $ch > 0;
		$msg = %4;
		if ($msg == ''); $msg = 'test_d'; end if;
		msg send channel $ch 1 $msg recv $a;
		if (ERROR);
			print ERROR ERRMSG;
		else;
			print $a[0] $a[1];
		end if;
	end if;
	RETURN $ERROR;
END PROC;
