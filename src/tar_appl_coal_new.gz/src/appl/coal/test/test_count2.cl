//
proc main;
	print *%();
	print countv(%());
	return ERROR;
end proc;
