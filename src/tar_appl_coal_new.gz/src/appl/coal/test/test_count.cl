//
define array $a 10;
define array BIN $b 10;
define mappedarray $m 11 5;
define mappedarray %p 1 5;
define mappedarray #s 1 5;
proc main;
	let option 5 1;

	print countv(10);
	$1 = LIST(1, 2, 3, 'A', 'B');
	print countv($1) countv(*$1);
	print countv($()) countv(*$());
	print countv(%()) countv(*%());
	setarray($a,0,1,2,3);
	print $a countv($a);
	a[3] = 4;
	print countv(*$a);
	setarray($b,0,1,2,3);
	print $b countv($b);
	b[3] = 5;
	print countv($b);
	setarray($m,0,1,2,3);
	print countv($m) countv(*$m);
	print countv(%p) countv(*%p);

//	print countv(#s);
	print countv([1,2,3,4,5,6,7,8,9]);
	print countv(*[1,2,3,4,5,6,7,8,9]);
	print "[1,2,3,4,5,6,7,8,9]";
//	[1,2,3,4,5,6,7,8,9];

	print countv(1..5) countv(*(1..5)) countv(**(1..5),1);
	a[6] = 6;
	print *a *b;
	print countv(a,b);
	print countv(a,b,1);
	print countv(a,b,OPT==>1);
	print countv(a,OPT==>1,b);
	print countv(OPT==>1,a,b);
	print countv(a,b,OPT==>1,1);
	print countv(a,b,OPTx==>1,1);
	print countv(a,b,OPT==>1,1,OPT==>2);

	print "1,2,3,4,5";

	return ERROR;
end proc;
