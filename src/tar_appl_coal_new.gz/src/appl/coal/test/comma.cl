//
//  
//
define array a 10 = [,2,,4,];
define array h hash 20;
define type struct t
	int x,
	int y 3 4 5,
;
define var b as t;
proc main;
	print ",1,,'X'";
	print 3..5;
	print a;
	print *a;
	h['A']=100;
	print h;
	print *h;
	print t;
	print *t;
	print b;
	print *b;
	return;
end proc;
