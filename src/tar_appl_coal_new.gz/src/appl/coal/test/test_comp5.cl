//
define array a 10 = ['%A%','%C%','%C%','%','%F%'];
define array b 10 = [1i,2,3,4,5,'AB','BC','CD','DE','EF'];
define array BIN c 10 = [1i,3,2,7,5,6,4,9,10,8];
def wc = {1,2,3,4,5,6,7,8,9,10};
define array r 10;
define ha hash = ['A',1,'B',2,'C',3,'D',4,'E',5];;
define hb hash = ['A',10,'B',20,'X',30,'D',40,'E',5];
proc main;
	print "'ABCDEFG' like '%A_C%'";
	return ERROR;
end proc;
