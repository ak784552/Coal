//
##if 0
#if 0
int x;
#endif
##endif
proc main;
	a = [];
##if 0
#if 0
	print a;
	print "b = list()";
	print b;
#else
	print "c = fl('LIST')";
	print c;
#endif
##endif
	print "d = cons()";
	print d;
	return ERROR;
end proc;
