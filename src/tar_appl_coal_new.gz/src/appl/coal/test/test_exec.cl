//
proc main;
	call > /tmp/wwaa;
//	call fff <aaaaa;
	exec ip ppp 'XX' >aaaaa;
//	exec ip ppp 'XX';
	putline('retuen ppp');
	fff(999);
	putline('retuen fff');
//	exec <w;
//	exec > 'xxx';
//	putline('exec > xxx');
//	exec > abc/123;
//	putline('exec > abc/123');
	a='xyz';
	call > $a&'789';
	putline('exec > ', a);
//	$EOF = 'EOF';
//	call <<$EOF;
	call << EOF1 > 'zzz' ;
aaa
bbb
ccc
EOF1
//	call <w;
//	call > /dev/tty;
	loop 10;
		line = getline();
		if ERROR; break; endif;
		putline(line);
		exec sc test_getline;
/*
		exec sc test_getline <<EOF2;
xxxx
yyyyyyy
EOF2
*/
	end loop;
	call > yyy;
	putline('call > yyy');
//	exec <xxx 'yyy';
	exec sc test_getline <<EOF3;
xxxx
yyyyyyy
zz
EOF3
	return ERROR;
end proc;

proc ppp(a);
	putline('called ppp a=',a);
	exec > 'xxx';
	putline('exec > xxx');
	return ERROR;
end proc;

func fff(a);
	putline('called fff a=',a);
	exec > 'fff';
	putline('exec > fff');
	return ERROR;
end func;
