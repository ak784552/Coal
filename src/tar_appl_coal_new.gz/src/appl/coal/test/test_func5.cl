//
//
proc main;
	z = f(1) + f(2) + f(3);
	print z;
	return $ERROR;
end proc;

func f(x);
	return 10+x;
end func;
