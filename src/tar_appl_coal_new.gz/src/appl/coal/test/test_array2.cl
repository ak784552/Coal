//
//define array vari $a 100;
define array vari $a;
proc main;

//	print a;
	$1 = 'XXX';
	$x = 'AAAA';
//	%1 = 1;
//	#1 = 1;
//	$a = 1234;
	$a[0] = 111;
	$a[1] = 222;
	$a[1]++ ;
//	loop 3;
		print $a[0] $a[1] $DATE DATETIME $1;
//		sleep 2;
//	end loop;
//	redefine array $DATE 10;
	$1 = ERROR;
//	undefine $a[0] $1 $x;

	undefine $a $b;
//	undefine $1;
	undefine $x;
//	print $a[0] $1 $x;
//	undefine ERROR;
//	undefine %1;
//	undefine $(abs(1));
//	undefine $xyz;

	BBBB = 1;
	$xyz = 'BBBB';
	undefine $(concat('x','y','z'));

	print $(concat('x','y','z'));
	print $(xyz);
	print $xyz /i xyz;
//	undefine 'XYZ';
	$(xyz) = 100;
	print $(xyz);

	return ERROR;
//	return DATE;
end proc;
