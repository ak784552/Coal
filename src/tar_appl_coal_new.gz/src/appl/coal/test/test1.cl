//
bu = '123';
proc main;
//	bu = '123';
//	bu;
//	dec wt = 32.5;
	print ff() bu wt;
//	print bu /i bu wt;
	return $ERROR;
end proc;

func ff();
	dec wt = 12.7;
	bu = 'ABC';
	print bu;
	return 0;
end func;
