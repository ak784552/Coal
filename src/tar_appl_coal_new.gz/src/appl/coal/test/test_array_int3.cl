//
define array int(1) a 10;
proc main;
	print *a a[1];
	$a[0] = 1.0;
	$a[1] = 10;
	$a[2] = 128;
	$a[1]++;
	print $a[1] $a[$a[0]] *a;
	return ERROR;
end proc;
