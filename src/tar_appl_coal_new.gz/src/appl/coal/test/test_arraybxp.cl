//
define array a 10 = ['%A%','%C%','%C%','%','%F%'];
define array b 10 = [1i,2,3,4,5,'AB','BC','CD','DE','EF'];
define array BIN c 10 = [1i,2,3,4,5,6,7,8,9,10];
def wc = {1,2,3,4,5,6,7,8,9,10};
define array r 10;
define la = ['%A%','%C%','%C%','%','%F%'];
define lb = [1i,2,3,4,5,'AB','BC','CD','DE','EF'];
define lc = [1i,2,3,4,5,6,7,8,9,10];
def lwc = {1,2,3,4,5,6,7,8,9,10};
proc main; 
/*
	loop each x in b;
		print *x;
	end loop;

	loop each x in c;
		print *x;
	end loop;

	print arraybxp(b,b,c,5,'+');
	print arraybxp(abs,b,c,5,'+');
	print arraybxp(b,abs,c,5,'+');
	print arraybxp(b,b,abs,5,'+');
	print arraybxp(b,0,b,c,5,'+');
	print *arraybxp(,b,c,5,'+');
	print arraybxp(b,,c,5,'+');
	print arraybxp(b,b,,5,'+');
*/
	print arraybxp(lb,lb,lc,5,'+');
	print lb;
/*
	print arraybxp(NULL,b,c,5,'+');
	print arraybxp(b,NULL,c,5,'+');
	print arraybxp(b,b,NULL,5,'+');
	print arraybxp(b,b,c,NULL,'+');
	print arraybxp(b,b,c,5,NULL);
	print *arraybxp('',b,c,5,'+');
	print arraybxp(r,wc,b,5,'+');

	print b[0] /i b[0];
	loop each x in b;
		print *x;
	end loop;

	print b[0]..c[0];
	print arraybxp(r,b,c,1,'..');

	print r[0];
	print 1..2..1i;
	print *(1..1) *(1..2);
	print *('A'..'A') *('A'..'B');
	print *(SYSDATE..SYSDATE) *(SYSDATE..SYSDATE+1);

	print "*(*b + *c)";
	print "*(*b - *c)";
	print "*(*b & *c)";
	print "*(*b | *c)";
*/
	return ERROR;
end proc;
