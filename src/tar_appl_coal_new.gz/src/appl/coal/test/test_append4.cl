//
proc main;

	a = [];
	print append(a,1..3,OPT==>1);
	print a;

	b = [];
	print append(b,*(1..3),OPT==>1);
	print b;

	c = [];
	print append(c,**(1..3),OPT==>1);
	print c;

	return ERROR;
end proc;
