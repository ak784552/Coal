//
//def image i;
def complex int aa;
proc main;

	print (M_E**complex(1,PI/6.0))/M_E;
	print M_E**cimg(PI/6.0);
	print exp(complex(1,PI/6.0))/M_E;
	print 1.5**(1+0.2i);
	print (1.5+0.5i)**(1+0.2i);
	print 1.5**0.2i;
	print (1+2i)**0.5;

	print sin(1+2i);
	print sin(2i);
	print cos(1+2i);
	print tan(1+2i);

	print log(1+2i);
	print log10(1+2i);

	print log(2i);
	print log10(2i);

	print sqrt(1+2i);

	return $ERROR;
end proc;
