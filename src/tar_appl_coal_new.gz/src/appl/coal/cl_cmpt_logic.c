static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �_�����Z����                          �@�@�@           *
*                                                                             *
*      �֐����@    �F�@int cl_cmpt_logic(pAns,pOprtr,pInfoParm1,pInfoParm2)   *
*						(O)int		 *pAns									  *
*						(I)char		 *pOprtr								  *
*						(I)tdtInfoParm *pInfoParm1							  *
*						(I)tdtInfoParm *pInfoParm2 							  *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL *pGLprocTable;
extern CLPRTBL *pCLprocTable;
extern GlobalCt *pGlobTable;
extern int giOptions[];

int cl_get_logic_val(pInfoParm1)
tdtInfoParm *pInfoParm1;
{
	int rc,atr;
	long Value;
	double dValue;
	char *dat;
	MPA *mpa;

	rc = 1;
#if 1	/* 2023.1.1 */
	if (pInfoParm1->pi_id == 'S') pInfoParm1 = (tdtInfoParm *)pInfoParm1->pi_pos;
#endif
	if (pInfoParm1->pi_id == ' ') {
		atr = pInfoParm1->pi_attr;
		dat = pInfoParm1->pi_data;
		if (atr == DEF_ZOK_BINA) {
			memcpy(&Value,dat,sizeof(long));
			if (!Value) rc = 0;
		}
		else if (atr == DEF_ZOK_FLOA) {
			memcpy(&dValue,dat,sizeof(double));
			if (dValue == 0.0) rc = 0;
		}
		else if (atr == DEF_ZOK_DECI) {
			mpa = (MPA *)dat;
			if (mpa->zero) rc = 0;
		}
		else {
			if (!pInfoParm1->pi_dlen) rc = 0;
		}
	}
	return rc;
}

int cl_cmpt_logic(pAns,pOprtr,pInfoParm1,pInfoParm2)
long *pAns;
char *pOprtr;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	int rc=0,Result,atr[2],len[2],i,k,Value[2];
	double dValue;
	char *dat[2];
	uchar *p;
	MPA *mpa;

#if 1	/* 2021.10.28 */
	Value[0] = cl_get_logic_val(pInfoParm1);
	Value[1] = cl_get_logic_val(pInfoParm2);
#else
	atr[0] = pInfoParm1->pi_attr;
	len[0] = pInfoParm1->pi_dlen;
	dat[0] = pInfoParm1->pi_data;
	atr[1] = pInfoParm2->pi_attr;
	len[1] = pInfoParm2->pi_dlen;
	dat[1] = pInfoParm2->pi_data;
	Value[0] = Value[1] = 0;
	for (k=0;k<2;k++) {
		if (atr[k] == DEF_ZOK_BINA) {
			memcpy(&Value[k],dat[k],sizeof(long));
			if (Value[k]) Value[k] = 1;
		}
		else if (atr[k] == DEF_ZOK_FLOA) {
			memcpy(&dValue,dat[k],sizeof(double));
			if (dValue != 0.0) Value[k] = 1;
			else Value[k] = 1;
		}
		else if (atr[k] == DEF_ZOK_DECI) {
			mpa = (MPA *)dat[k];
			Value[k] = mpa->zero ? 0 : 1;
		}
		else {
			if (len[k]) Value[k] = 1;
			else Value[k] = 0;
		}
	}
#endif
/*
printf("cl_cmpt_logic: Value1=%d Value2=%d pOprtr=[%s]\n",Value[1],Value[1],pOprtr);
*/
	sswitch( pOprtr )
		sicase( "AND" )
				Result = Value[0] & Value[1];
		sicase( "OR" )
				Result = Value[0] | Value[1];
		scase( "&&" )
				Result = Value[0] & Value[1];
		scase( "||" )
				Result = Value[0] | Value[1];
#if 1
		sicase( "NOT" )
				Result = ! Value[1];
		scase( "!" )
				Result = ! Value[1];
#endif
		sdefault
			/* cl_cmpt_logic: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"cl_cmpt_logic",pOprtr);
			Result = 0;
			rc = ECL_SCRIPT_ERROR;
	endssw;

	*pAns = Result;
	return rc;

}

/****************************************/
/*										*/
/****************************************/
int cl_cmpt_agg(pInfoParmW,pOprtr,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW;
char        *pOprtr;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	int ret;
	char op,id1,id2;
	tdtRbCtl *pCt;
	tdtInfoParm tInfoParm;

DEBUGOUT_InfoParm(194,"cl_cmpt_agg: op=[%c] pInfoParm1=",pInfoParm1,*pOprtr,0);
DEBUGOUT_InfoParm(194,"cl_cmpt_agg:        pInfoParm2=",pInfoParm2,0,0);

	op = *pOprtr;
	id1 = pInfoParm1->pi_id;
	id2 = pInfoParm2->pi_id;
	if (id1=='L' || id2=='L' || id1=='N' || id2=='N') {
		if (op=='+' || op=='|' || op=='*') {
			ret = cl_gx_list_add(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else if (op=='-' || op=='&' || op=='^' || op=='/') {
			ret = cl_gx_list_minus(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else {
			ERROROUT1(FORMAT(256),pOprtr);	/* cl_cmpt_agg: non suported operater(%s)!! */
			ret = -1;
		}
		if (ret>=0 && !(pGlobTable->options[4] & 0x01)) {
			if (pCt = (tdtRbCtl *)pInfoParmW->pi_data) {
				if (akxs_rb_used(pCt) <= 0) cl_null_char(pInfoParmW);
			}
		}
	}
	else {
		if (op=='*' || (op=='+' && cl_get_option(2,0) & 0x2000)) op = '|';	/* add 2025.8.29 */
		if (op=='+' || op=='|') {
			ret = cl_gx_array_add(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else if (op=='-' || op=='&' || op=='^' || op=='/') {
			ret = cl_gx_array_minus(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else {
			ERROROUT1(FORMAT(256),pOprtr);	/* cl_cmpt_agg: non suported operater(%s)!! */
			ret = -1;
		}
	}
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_cmpt_agg:Exit ret=%d pOprtr=[%s] pInfoParmW=",pInfoParmW,ret,pOprtr);
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_logic(ppWork,pOperator,nparm,ppParm,ope)
char **ppWork;
char *pOperator;
tdtInfoParm **ppParm;
int nparm,ope;
{
	tdtInfoParm *pInfoParm;
	int  i,val,iAND,iOR;
	char *pWork;

	pWork = *ppWork;
	iAND = 1;
	iOR  = 0;
	for (i=0;i<nparm;i++) {
		pInfoParm = ppParm[i];
		if (!cl_is_null_parm(pInfoParm)) {
			val = cl_get_logic_val(pInfoParm);
			if (ope==D_FUC_OR && val) {
				iOR = 1;
				break;
			}
			else if (ope==D_FUC_AND && !val) {
				iAND = 0;
				break;
			}
		}
	}
	if (ope == D_FUC_AND) val = iAND;
	else val = iOR;
	memcpy(pWork,&val,sizeof(int));
	return DEF_ZOK_BINA;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_tenkai(ppmstk,irs,pInfoParmW,da2,opt,pmstk,dastk,Ms_ppmstk,Ms_pmstk,Ms_dastk)
tdtInfoParm *pmstk,*pInfoParmW,*ppmstk[];
int irs,opt;
char *da2,*dastk[];
MCAT *Ms_ppmstk,*Ms_pmstk,*Ms_dastk;
{
	tdtRbCtl *pCt;
	tdtInfoParm *pInfo,*pmW,*pm;
	tdtInfoParm *pInfoParm1,*pParmI;
	tdtInfoParm ***pTBL;
	tdtArrayIndex tIndex,*pIndex;
	XHASHB *xhp;
	char id,*p1,idm;
	int rc,optW,nm,*index,ix;

	id = pInfoParmW->pi_id;
	if (id==' ' && (pInfoParmW->pi_alen & D_AULN_RANGE_DATA)) {
		pInfoParmW->pi_aux[0] |= DEF_ZOK_DATA; 
		optW = opt;
		irs = cl_gx_range_tenkai(ppmstk,irs,pInfoParmW,optW,pmstk,dastk,
		                         Ms_ppmstk,Ms_pmstk,Ms_dastk);
	}
	else if (id=='L' || id=='N' || id=='A' || id=='R') {
		if (id=='L' || id=='N') {
			pCt = (tdtRbCtl *)pInfoParmW->pi_data;
			akxs_rb_read(pCt,0);
		}
		else {
			pIndex = &tIndex;
			if (rc=cl_get_array_index_tbl_ref(pInfoParmW,&pIndex,&pTBL,"cl_gx_array_bexp:")) return rc;
			index = pIndex->index;
			if (xhp=pIndex->xhp) {
				if (!(p1 = (char *)pInfoParmW->pi_pos)) p1 = "";
						/* "%s: �A�z�z��(%s)�͎w��ł��܂���B*/
				ERROROUT2(FORMAT(239),"cl_gx_tenkai",p1);
				irs = ECL_SCRIPT_ERROR;
			}
		}
		nm = 0;
		ix = 1;
		while (irs >= 0) {
			if (id=='L' || id=='N') {
			/*	if (!(pInfo = (tdtInfoParm *)akxs_rb_get_n(pCt))) break;	*/
				if (!(pInfo = (tdtInfoParm *)akxs_rb_read(pCt,1))) break;
			}
			else {
				if (ix > index[2]) break;
				if (!(pInfo = cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,'r'))) return -1;
				ix++;
			}
#if 1	/* 2024.9.15 */
			if (cl_gx_expand(Ms_pmstk,irs,&pmstk) < 0) return -4;
#endif
			pmW = &pmstk[irs];
			cl_gx_copy_info(pmW,pInfo);
			if (pmW->pi_id == 'S') pm = (tdtInfoParm *)pmW->pi_pos;
			else pm = pmW;
			if (!(idm=pm->pi_id)) p1 = "";
			else if (idm == ' ') parm_to_char_tmp(pm,&p1,0);
			else p1 = clstrdup(cl_get_variable_type(idm),D_OPT_ALC_TMP);
#if 1	/* 2024.9.15 */
			if (cl_gx_expand(Ms_ppmstk,irs,&ppmstk) < 0) return -4;
			if (cl_gx_expand(Ms_dastk,irs,&dastk) < 0) return -4;
#endif
			dastk[irs] = p1;
			ppmstk[irs++] = pmW;
			pInfo->pi_alen &= ~D_AULN_RANGE_INTVAL;	/* �r���͈��t���Ȃ� */
			nm++;
		}
		if (nm > 1) pmW->pi_alen |= D_AULN_RANGE_INTVAL;	/* �W�J���ꂽ�f�[�^�I���̈� */
	}
	else {
		/* %s: %s��'%s'�͎w��ł��܂���B */
		ERROROUT3(FORMAT(140),"cl_gx_tenkai",da2,"**");
		irs = ECL_EX_LET;
	}
	return irs;
}

/****************************************/
/*										*/
/****************************************/
static int _pop_array_pTBL(close_gap,nm,ngap,pIndex,pTBL,iFREE)
char *close_gap;
int nm,ngap,iFREE;
tdtArrayIndex *pIndex;
tdtInfoParm ***pTBL;
{
	tdtInfoParm *pInfo1,*pInfo2;
	int i,i2,mode,opt,count,*index;
	char c,*p;
/*
printf("_pop_array_pTBL:Enter nm=%d ngap=%d iFREE=%08x\n",nm,ngap,iFREE);
*/
	if (nm<=0 || ngap<=0) return 0;

	index = pIndex->index;
/*
printf("_pop_array_pTBL: index=%d %d %d %d %d %d\n",index[0],index[1],index[2],index[3],index[4],index[5]);
*/
	opt = cl_get_option(1,0) & 0x01;
	i2 = nm;
	count = mode = 0;
	p = close_gap;
	for (i=0;i<nm;i++) {
		c = *p++;
		if (mode) {
			if (!c) {
				if (!(pInfo1 = cl_get_array_and_var_ent_opt(pIndex,pTBL,i+1,'r'))) return -1;
				if (!(pInfo2 = cl_get_array_and_var_ent_opt(pIndex,pTBL,i2+1,'r'))) return -1;
				if (iFREE) cl_free_info_parm(pInfo2);
				cl_gx_copy_info(pInfo2,pInfo1);
				i2++;
/*
printf("_pop_array_pTBL: i=%d i2=%d\n",i,i2);
*/

			}
			else {
				count++;
			}
		}
		else {
			if (c) {
				mode = 1;
				i2 = i;
				count = 1;
			}
		}
	}
/*
printf("_pop_array_pTBL: i2=%d count=%d\n",i2,count);
*/
	count = 0;
	for (i=i2;i<nm;i++) {
		if (!(pInfo1 = cl_get_array_and_var_ent_opt(pIndex,pTBL,i+1,'r'))) return -1;
		if (opt) cl_null_char(pInfo1);
		else cl_parm_set0(pInfo1);
	}
	/* index[]�́A�e�̂��̂����A�����ύX���Ă����f����Ȃ��B */
	/* �e�́ApSize[]��ύX����K�v������B */
/*	index[2] -= count;	*/
/*
printf("_pop_array_pTBL:Exit i2=%d mode=%d count=%d\n",i2,mode,count);
*/
	return count;
}

/****************************************/
/*										*/
/****************************************/
static int _pop_array_vari(close_gap,nm,ngap,pIndex,iFREE)
char *close_gap;
int nm,ngap,iFREE;
tdtArrayIndex *pIndex;
{
	tdtInfoParm **pw,*pInfo,**gap;
	int i,i2,mode,opt,count,*index;
	char c,*p;
/*
printf("_pop_array_vari:Enter nm=%d ngap=%d iFREE=%08x\n",nm,ngap,iFREE);
*/
	if (nm<=0 || ngap<=0) return 0;

	if (!(gap = (tdtInfoParm **)TEMPMalloc(nm))) return ECL_MALLOC_ERROR;
	index = pIndex->index;
	pw = pIndex->pVarIndex + index[3] - 1;
	i2 = nm;
	count = mode = 0;
	p = close_gap;
	for (i=0;i<nm;i++) {
		c = *p++;
		if (mode) {
			if (!c) {
				pw[i2++] = pw[i];
/*
printf("_pop_array_vari: i=%d i2=%d\n",i,i2);
*/
			}
			else {
				gap[count] = pw[i];
				count++;
			}
		}
		else {
			if (c) {
				mode = 1;
				i2 = i;
				gap[0] = pw[i];
				count = 1;
			}
		}
	}
/*
printf("_pop_array_vari: i2=%d count=%d\n",i2,count);
*/
	opt = cl_get_option(1,0) & 0x01;
	count = 0;
	for (i=i2;i<nm;i++) {
		pInfo = gap[count++];
		if (iFREE) cl_free_info_parm(pInfo);
		else {
			if (opt) cl_null_char(pInfo);
			else cl_parm_set0(pInfo);
		}
		pw[i] = pInfo;
	}
	index[2] -= count;
/*
printf("_pop_array_vari:Exit i2=%d mode=%d count=%d\n",i2,mode,count);
*/
	return count;
}

/****************************************/
/*										*/
/****************************************/
static int _pop_array_fixed(close_gap,nm,ngap,pIndex,iRANGE)
char *close_gap;
int nm,ngap,iRANGE;
tdtArrayIndex *pIndex;
{
	tdtInfoParm *pInfo;
	int i,i2,mode,count,*index,size,atr;
	char c,*p,*pw,*pw2,*pw1;
/*
printf("_pop_array_fixed:Enter nm=%d ngap=%d iRANGE=%08x\n",nm,ngap,iRANGE);
*/
	if (nm<=0 || ngap<=0) return 0;

	atr = pIndex->uAttr[0];
	size = pIndex->size;
	if (atr == DEF_ZOK_CHAR) size++;
	else if (atr == DEF_ZOK_BULK) size += sizeof(int);
	if (iRANGE) size += size;
/*
printf("_pop_array_fixed: size=%d\n",size);
*/
	index = pIndex->index;
	pw = (char *)pIndex->pVarIndex;
	pw += (index[3] - 1)*size;
	i2 = nm;
	count = mode = 0;
	p = close_gap;
	pw1 = pw;
	for (i=0;i<nm;i++) {
		c = *p++;
		if (mode) {
			if (!c) {
				memcpy(pw2,pw1,size);
				i2++;
				pw2 += size;
/*
printf("_pop_array_fixed: i=%d i2=%d\n",i,i2);
*/
			}
			else {
				count++;
			}
		}
		else {
			if (c) {
				mode = 1;
				i2 = i;
				pw2 = pw + (i2*size);
				count = 1;
			}
		}
		pw1 += size;
	}
/*
printf("_pop_array_fixed: i2=%d count=%d\n",i2,count);
*/
	pw2 = pw + (i2*size);
	for (i=i2;i<nm;i++) {
		memset(pw2,0,size);
		pw2 += size;
	}
	index[2] -= count;
/*
printf("_pop_array_fixed:Exit i2=%d mode=%d count=%d\n",i2,mode,count);
*/
	return count;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_pop(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	char *pnama[]={"NUM","INTVAL"};
	tdtRbCtl *pCt;
	tdtInfoParm *pInfoParm,*pInfo,tInfoParm,*ppParm2[2],***pTBL,**pw,*pwi,*pInfoTemp,*pParmW[2];
	tdtArrayIndex tIndex,*pIndex,*pIndexW,*pIndexTmp,tIndex_sel,tIndexW;
	char id,*p1,idm,id0,*close_gap,*varnam,cn;
	int rc,optW,nm,*index,i,k,m,val[3],num,intval,skip,iParm[4],w,val2[2],lVal;
	int i1,i2,atr,iRANGE,count,iFREE,offset,np,nmw,*index_sel,*indexW,*pSize;

	cl_null_parm(pInfoParmW);
	pInfoParm = ppParm[0];
	if ((rc=cl_check_data_id2(pInfoParm,0x02|0x08|0x1000,0x03)) < 0) return rc;

	id0 = id = pInfoParm->pi_id;
	pInfoParm = ppParm[0];
	pParmW[1] = pParmW[0] = NULL;
	if ((rc=cl_get_pname_info(nparm,ppParm,pParmW,pnama,2)) < 0) return rc;
	else if (rc > 0) {
		nparm -= rc;	/* ���O�t�������́A�����Ɉړ����Ă���̂ŁA���̕������� */
		for (i=0;i<2;i++) {
			if (pInfo=pParmW[i]) {
				if (rc=cl_get_parm_bin(pInfo,&val2[i],"cl_func_pop:val2:")) return -217032301;
			}
		}
	}
	rc = 0;
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		nm = pCt->rb_used;
		if (nm <= 0) return 0;
		if ((np=nparm) > 4) np = 4;
		val[0] = nm - 1;
		val[1] = 1;
		val[2] = 1;
		for (i=1;i<np;i++) {
			if ((rc=cl_get_parm_bin(ppParm[i],&val[i-1],"cl_func_pop val:"))<0) return rc;
		}
		m = val[0];
		if (pParmW[0]) num = val2[0];
		else num = val[1];
		if (num <= 0) return 0;
		if (pParmW[0]) intval = val2[1];
		else intval = val[2];
		if (intval <= 0) intval = 1;
		i1 = m;
		if (m < 0) {
			m += nm;
			num = 1;
			intval = 1;
		}
		skip = intval - 1;
/*
printf("cl_func_pop: m=%d num=%d intval=%d\n",m,num,intval);
*/
		if (m<0 || m>=nm) {
			ERROROUT1(FORMAT(228),i1);	/* �Q�ƈʒu(%d)���s���ł��B */
			return ECL_SCRIPT_ERROR;
		}
/*
printf("cl_func_pop:LIST nm=%d m=%d num=%d intval=%d\n",nm,m,num,intval);
*/
		if (m < nm) {
			akxs_rb_read(pCt,0);
			for (i=0;i<=m;i++) if (!(pInfo=(tdtInfoParm *)akxs_rb_read(pCt,1))) break;
/*
printf("cl_func_pop: i=%d\n",i);
*/
			if (!m || pInfo) {
				for (k=0;k<num;k++) {
				/*	if (!m) pInfo = (tdtInfoParm *)akxs_rb_get_n(pCt);
					else */pInfo = (tdtInfoParm *)akxs_rb_pop(pCt);
					if (pInfo) {
						if (!k) {
							if ((id=pInfo->pi_id)==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
								if ((rc=_tmp_list_copy(pInfoParmW,pInfo)) < 0) break;
								pInfoParmW->pi_id = id0;
							}
							else
								cl_gx_copy_info(pInfoParmW,pInfo);
						}
						else {
							if ((id=pInfoParmW->pi_id)==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
								if ((rc=_append_list(pInfoParmW,1,&pInfo,1)) < 0) break;
							}
							else {
								cl_gx_copy_info(&tInfoParm,pInfoParmW);
								ppParm2[0] = &tInfoParm;
								if ((rc=cl_set_list(pInfoParmW,1,ppParm2)) < 0) break;
								pInfoParmW->pi_id = id0;
								if ((rc=_append_list(pInfoParmW,1,&pInfo,1)) < 0) break;
							}
						}
					/*	pInfoParmW->pi_aux[1] |= D_AUX1_PROTECTED;	*/
DEBUGOUT_InfoParm(194,"cl_func_pop: pInfo=",pInfo,0,0);
DEBUGOUT_InfoParm(194,"cl_func_pop: pInfoParmW=",pInfoParmW,0,0);
					}
					else break;

					m += intval;
/*
printf("cl_func_pop: m=%d\n",m);
*/
					if (m >= nm) break;

					for (i=0;i<skip;i++) {
						if (!(pInfo=(tdtInfoParm *)akxs_rb_read(pCt,1))) break;
					}
					rc = 0;
				}
			}
		}
	}
	else if (id=='A' || id=='R') {
		if ((rc=cl_array_check_valid(pInfoParm)) < 0) return rc;
		pIndex = &tIndex;
		if (!(varnam = (char *)pInfoParm->pi_pos)) varnam = "";
		if (rc = _get_array_info_ref(1,ppParm,&pIndex,&pTBL,iParm,1)) {
			if (rc == 2000) {
						/* "%s: �A�z�z��(%s)�͎w��ł��܂���B*/
				ERROROUT2(FORMAT(239),"cl_func_pop",varnam);
				rc = ECL_SCRIPT_ERROR;
			}
			return rc;
		}
		if (pParmW[0]) num = val2[0];
		else num = 1;
		if (num <= 0) return 0;
		if (pParmW[0]) intval = val2[1];
		else intval = 1;
		index = pIndex->index;
		memcpy(&tIndex_sel,pIndex,sizeof(tdtArrayIndex));
		index_sel = tIndex_sel.index;
		if ((rc=cl_gx_array_conv_sel_index(nparm-1,ppParm+1,index_sel,NULL)) < 0) return rc;
/*
printf("cl_func_pop: index_sel[4]=%d %d %d %d\n",index_sel[4],index_sel[5],index_sel[6]);
*/
		if ((i1=cl_gx_conv_index2(index,index_sel,varnam)) < 0) return i1;
/*
printf("cl_func_pop: i1=%d\n",i1);
*/
		i1 -= index[3];		/* i1�͐e��ParmNo�Ȃ̂Ŏq�̃C���f�b�N�X�Ɋ��Z */
		/* 2025.9.12 */
		nmw = 0;
		if (id == 'R') {
			if ((rc=cl_get_array_index_opt(pInfoParm,&pIndexW,1)) > 0) {
				indexW = pIndexW->index;
				nmw = indexW[2] + indexW[3] - 1;
/*
printf("cl_func_pop: nmw=%d indexW=%d %d %d %d\n",nmw,indexW[0],indexW[1],indexW[2],indexW[3]);
*/
			}
			else if (rc < 0) return rc;
		}
		else {
			pIndexW = &tIndexW;
		/*	memcpy(pIndexW,pIndex,sizeof(tdtArrayIndex));	*/
			if ((rc=cl_get_array_psize(pInfoParm,&cn,&pSize,NULL)) < 0) return rc;
/*
printf("cl_func_pop: pSize[2]=%d pSize[7]=%d\n",pSize[2],pSize[7]);
*/
			indexW = pIndexW->index;
			indexW[0] = 1;
			indexW[1] = pSize[2];
			indexW[2] = pSize[7];
			indexW[3] = 1;
			indexW[4] = indexW[1];
			indexW[5] = 1;
			nmw = indexW[2] + indexW[3] - 1;
		}
		nm  = iParm[3];
/*
printf("cl_func_pop: nm=%d index=%d %d %d %d %d %d\n",nm,index[0],index[1],index[2],index[3],index[4],index[5]);
*/
		offset = index[3];
		iFREE = pInfoParm->pi_scale & D_DATA_INDEX_FREE;
/*
printf("cl_func_pop: offset=%d iFREE=%02x\n",offset,iFREE);
*/
		i2 = i1 + num - 1;
		if (i2 >= nm) {
			i2 = nm - 1;
			num = i2 - i1 + 1;
		}
/*
printf("cl_func_pop: i1=%d i2=%d num=%d intval=%d\n",i1,i2,num,intval);
*/
		if (num <= 0) {
			ERROROUT3(FORMAT(320),"cl_func_pop",varnam,i1);	/* %s: %s�̃C���f�b�N�X(%d)�͔͈͊O�ł��B*/
			return 0;
		}
		if ((rc=cl_def_array_tmp(&pInfoTemp,num,NULL)) < 0) return rc;
		cl_gx_copy_info(pInfoParmW,pInfoTemp);
		pIndexTmp = (tdtArrayIndex *)pInfoTemp->pi_data;
		pw = pIndexTmp->pVarIndex;
		if (nm > nmw) nmw = nm;
		if (!(close_gap = TEMPMalloc(nmw))) return ECL_MALLOC_ERROR;
		memset(close_gap,0,nmw);
		k = 0;
		for (i=i1;i<nm;i+=intval) {
			if (!(pInfo = cl_get_array_and_var_ent_opt(pIndex,pTBL,i+offset,'r'))) return -1;
			if (!(pwi=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
			if ((rc=cl_gx_rep_info_set_ign(pwi,pInfo,1)) < 0) return rc;
			*(close_gap+i+offset-1) = 1;
			pw[k++] = pwi;
			if (k >= num) break;
		}
/*
printf("cl_func_pop: k=%d\n",k);
*/
		if (pTBL) {
			if ((rc=_pop_array_pTBL(close_gap,nmw,k,pIndexW,pTBL,iFREE)) < 0) return rc;
			tInfoParm = *pInfoParm;
			tInfoParm.pi_data = (char *)pIndexW;
		/*	indexW[2] -= k;	*/
			/* indexW[]�́A�e�̂��̂����A�����ύX���Ă����f����Ȃ��B */
			/* �e�́ApSize[]��ύX����K�v������B */
			pSize[2] -= k;
			pSize[7] -= k;
			pInfoParm = cl_var_size_parm(pSize);
			cl_set_parm_bin(pInfoParm,pSize[7]);
			index[2] -= k;
/*
printf("cl_func_pop: k=%d index[2]=%d pSize[2]=%d pSize[7]=%d\n",k,index[2],pSize[2],pSize[7]);
*/
		}
		else {
			atr = pIndex->uAttr[0];
/*
printf("cl_func_pop: atr=%d nm=%d\n",atr);
*/
			if (!atr || atr==DEF_ZOK_VARI) {
				rc = _pop_array_vari(close_gap,nmw,k,pIndexW,iFREE);
			}
			else {
				iRANGE = pInfoParm->pi_alen & D_AULN_RANGE_DATA;
				rc = _pop_array_fixed(close_gap,nmw,k,pIndexW,iRANGE);
			}
/*
printf("cl_func_pop: pIndex=%08x pIndexW=%08x\n",pIndex,pIndexW);
*/
			if (rc>=0 && pIndex!=pIndexW) index[2] -= k;
		}
	}
	if (rc > 0) rc = 0;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _set_random(p,pw,nm)
tdtInfoParm *p,**pw;
int nm;
{
	int ix,rc,m;
/*
printf("_set_random:Enter nm=%d\n",nm);
*/
	rc = 0;
	ix = drand48()*nm;
/*
printf("_set_random:1 ix=%d pw[ix]=%08x\n",ix,pw[ix]);
*/
	m = nm;
	while (pw[ix]) {
		if (!m--) break;
		ix++;
		if (ix >= nm) ix = 0;
/*
printf("_set_random: m=%d ix=%d\n",m,ix);
*/
	}
/*
printf("_set_random:2 ix=%d pw[ix]=%08x\n",ix,pw[ix]);
*/
	rc = ix;
	if (!pw[ix]) pw[ix] = p;
	else rc = -100;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _random_list(pInfoParm,im)
tdtInfoParm *pInfoParm;
int im;
{
	tdtRbCtl *pCt,*pCt2;
	int rc,nm,len,i;
	tdtInfoParm *p,**pw,*pww;
	char *p1,*(*m_alloc)();

	rc = 0;
	pCt = (tdtRbCtl *)pInfoParm->pi_data;
	if ((nm=pCt->rb_used) > 0) {
/*
printf("cl_func_random: nm=%d\n",nm);
*/
		len = sizeof(tdtInfoParm *)*nm;
		if (!(pw = (tdtInfoParm **)cl_tmp_const_malloc(len))) return ECL_MALLOC_ERROR;
		memset(pw,0,len);
		akxs_rb_read(pCt,0);
		for (i=0;i<nm;i++) {
			p=(tdtInfoParm *)akxs_rb_read(pCt,1);
			if ((rc=_set_random(p,pw,nm)) < 0) break;
		}
		if (rc >= 0) {
			if (im == D_OPT_ALC_MALLOC) m_alloc = NULL;
			else m_alloc = cl_tmp_const_malloc;
			if (!(pCt2 = akxs_rb_new2(0,0,m_alloc,NULL))) return ECL_MALLOC_ERROR;
/*
printf("cl_func_random: pCt2=%08x\n",pCt2);
*/
			for (i=0;i<nm;i++) {
/*
printf("cl_func_random: i=%d pw[i]=%08x\n",i,pw[i]);
*/
				p1 = akxs_rb_set_n(pCt2,pw[i]);
			}
			akxs_rb_free(pCt);
			pInfoParm->pi_data = (char *)pCt2;
		/*	*pInfoParmW = *pInfoParm;	*/
		/*	cl_gx_copy_info(pInfoParmW,pInfoParm);	*/
			rc = 0;
		}
		else {
			akxs_rb_free(pCt2);
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _random_array_pTBL(nm,pIndex,pTBL)
int nm;
tdtArrayIndex *pIndex;
tdtInfoParm ***pTBL;
{
	int rc,len,i,offset;
	tdtInfoParm *p,**pw,*pww;

	rc = 0;
	offset = pIndex->index[3];
	len = sizeof(tdtInfoParm *)*nm;
	if (!(pw = (tdtInfoParm **)cl_tmp_const_malloc(len))) return ECL_MALLOC_ERROR;
	memset(pw,0,len);
	if (!(pww = (tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm)*nm))) return ECL_MALLOC_ERROR;
	for (i=0;i<nm;i++) {
		p = pww + i;
		if ((rc=_set_random(p,pw,nm)) < 0) break;
		p = cl_get_array_and_var_ent_opt(pIndex,pTBL,i+offset,'r');
		memcpy(pw[rc],p,sizeof(tdtInfoParm));;
	}
/*
printf("cl_func_random:VARI rc=%d\n",rc);
*/
	if (rc >= 0) {
		rc = 0;
		for (i=0;i<nm;i++) {
			p = cl_get_array_and_var_ent_opt(pIndex,pTBL,i+offset,'r');
			cl_gx_copy_info(p,pw[i]);
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _random_array_vari(nm,pIndex,im)
int nm,im;
tdtArrayIndex *pIndex;
{
	int rc,len,i,offset;
	tdtInfoParm *p,**pw,*pww,**ppArrayInfo,**pw0;

	rc = 0;
	offset = pIndex->index[3];
	len = sizeof(tdtInfoParm *)*(nm+offset-1);
	if (!(pw0 = (tdtInfoParm **)OPTMalloc(im,len))) return ECL_MALLOC_ERROR;
	pw = pw0 + offset - 1;
	memset(pw,0,len);
	ppArrayInfo = pIndex->pVarIndex;
	for (i=0;i<nm;i++) {
		p = ppArrayInfo[i];
		if ((rc=_set_random(p,pw,nm)) < 0) break;
	}
/*
printf("cl_func_random:VARI rc=%d\n",rc);
*/
	if (rc >= 0) {
		pIndex->pVarIndex = pw0;
	/*
		for (i=0;i<nm;i++) {
			ppArrayInfo[i] = pw[i];
		}
	*/
		rc = 0;
		if (im == D_OPT_ALC_MALLOC) Free(ppArrayInfo);
	}
	else {
		if (im == D_OPT_ALC_MALLOC) Free(pw);
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _random_array_fixed(nm,pIndex,iRANGE)
int nm,iRANGE;
tdtArrayIndex *pIndex;
{
	int rc,len,i,size,atr;
	tdtInfoParm *p,**pw,*pww;
	char *p1,*pp,*pArray;

	rc = 0;
	atr = pIndex->uAttr[0];
	if (!(size = pIndex->size)) return -1;
	if (atr == DEF_ZOK_CHAR) size++;
	else if (atr == DEF_ZOK_BULK) size += sizeof(int);
	if (iRANGE) size+= size;
/*
printf("cl_func_random: iRANGE=%08x size=%d\n",iRANGE,size);
*/
	len = sizeof(tdtInfoParm *)*nm;
	if (!(pw = (tdtInfoParm **)cl_tmp_const_malloc(len))) return ECL_MALLOC_ERROR;
	memset(pw,0,len);
	if (!(pp = cl_tmp_const_malloc(size*nm))) return ECL_MALLOC_ERROR;
	pArray = (char *)pIndex->pVarIndex;
	memcpy(pp,pArray,size*nm);
	p1 = pp;
	for (i=0;i<nm;i++) {
		if ((rc=_set_random(p1,pw,nm)) < 0) break;
		p1 += size;
	}
/*
printf("cl_func_random: rc=%d\n",rc);
*/
	if (rc >= 0) {
		rc = 0;
		p1 = pArray;
		for (i=0;i<nm;i++) {
			memcpy(p1,pw[i],size);
			p1 += size;
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_random(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm ***pTBL;
	tdtArrayIndex tIndex,*pIndex;
	int iParm[4],w;
	tdtRbCtl *pCt,*pCt2;
	tdtInfoParm *pInfoParm,*p,**pw,**ppArrayInfo,*pww,*pwi;
	char id,*p1,*pp,*pArray;
	int rc,nm,ix,m,i,len,atr,ix0,size,iRANGE,im;
	char *(*m_alloc)();

	cl_null_parm(pInfoParmW);
	pInfoParm = ppParm[0];
/*
printf("cl_func_random:Enter pi_scale=%02x\n",pInfoParm->pi_scale);
*/
	if (pInfoParm->pi_scale & D_DATA_INDEX_FREE) im = D_OPT_ALC_MALLOC;
	else im = D_OPT_ALC_TMP;
	rc = 0;
	id = pInfoParm->pi_id;
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		pInfoParm = ppParm[0];
		rc = _random_list(pInfoParm,im);
	}
	else if (id=='A' || id=='R') {
		nm = 0;
		pIndex = &tIndex;
		pInfoParm = ppParm[0];
		if ((rc=cl_array_check_valid(pInfoParm)) < 0) return rc;
	/*	cl_gx_copy_info(pInfoParmW,pInfoParm);	*/
		if (rc = _get_array_info_ref(1,ppParm,&pIndex,&pTBL,iParm,1)) {
			if (rc == 2000) {
				if (!(p1 = (char *)pInfoParm->pi_pos)) p1 = "";
						/* "%s: �A�z�z��(%s)�͎w��ł��܂���B*/
				ERROROUT2(FORMAT(239),"cl_func_random",p1);
				rc = ECL_SCRIPT_ERROR;
			}
			return rc;
		}
		else {
			nm  = iParm[3];
/*
printf("cl_func_random: rc=%d pTBL=%08x nm=%d\n",pTBL,nm);
*/
			if (pTBL) {
				rc = _random_array_pTBL(nm,pIndex,pTBL);
			}
			else {
				atr = pIndex->uAttr[0];
/*
printf("cl_func_random: atr=%d nm=%d\n",atr);
*/
				if (!atr || atr==DEF_ZOK_VARI) {
					rc = _random_array_vari(nm,pIndex,im);
				}
				else {
					iRANGE = pInfoParm->pi_alen & D_AULN_RANGE_DATA;
					rc = _random_array_fixed(nm,pIndex,iRANGE);
				}
			}
		}
	}
	if (!rc) cl_gx_copy_info(pInfoParmW,pInfoParm);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_unique_opt(pInfoParmW,nparm,ppParm,opt)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
int opt;
{
	/* 2025.8.28 */
	tdtInfoParm tInfoParm,*pInfoParm;
	tdtArrayIndex *pIndex;
	char id;
	int rc,iDO;

DEBUGOUTL1(120,"cl_func_unique_opt:Enter: opt=%08x",opt);

	iDO = 0;
	pInfoParm = ppParm[0];
	id = pInfoParm->pi_id;
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) iDO = 1;
	else if (id=='A' || id=='R') {
		if ((rc=cl_array_check_valid(pInfoParm)) < 0) return rc;
		if ((rc=cl_get_array_index(pInfoParm,&pIndex)) < 0) return rc;
		if (pIndex->xhp) {
			if (!(opt & 0x01))
				ERROROUT2(FORMAT(239),"cl_func_unique",pInfoParm->pi_pos);	/* %s: �A�z�z��(%s)�͎w��ł��܂���B*/
		}
		else iDO = 1;
	}
	if (iDO) {
		cl_null_parm(&tInfoParm);
		if ((rc=cl_cmpt_agg(pInfoParmW,"/",pInfoParm,&tInfoParm)) > 0) rc = 0;
	}
	else {
		/* ���̂Ƃ��́ApInfoParm�ɑ΂��鏈�����s���Ȃ��������ƁA����сA
		   pInfoParmW���ApInfoParm�̃R�s�[�ɂȂ��Ă��邱�Ƃ��������߂ɁA1��Ԃ� */
		if (opt & 0x02) {
			rc = cl_gx_rep_info_set_ign(pInfoParmW,pInfoParm,1|D_GX_OPT_ALC_TMP);
		}
		else {
			cl_gx_copy_info(pInfoParmW,pInfoParm);
		}
		rc = 1;
	}

DEBUGOUTL1(120,"cl_func_unique_opt:Exit: rc=%d",rc);

	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_unique(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	int rc;

	if ((rc=cl_func_unique_opt(pInfoParmW,nparm,ppParm,0)) > 0) rc = 0;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _adust_info(pInfoParm)
tdtInfoParm *pInfoParm;
{
	int rc;
	char id;

	rc = 0;
	id = pInfoParm->pi_id;
/*
printf("_adust_info: id=[%c]\n",id);
*/
	if (id == 'A') {
		rc = cl_get_array_index_tbl_ref(pInfoParm,NULL,NULL,"!cl_func_adjust");
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_adjust_scope(pha)
XHASHB *pha;
{
	tdtInfoParm *pInfoParm;
	int rc,m,i,ix;
	char *hakey;

	rc = 0;
	m = akxs_xhash2(pha,'M',NULL,NULL);
	for (i=1;i<=m;i++) {
		pha->xha_xhix = i;
		if ((ix=akxs_xhash2(pha,'P',&hakey,&pInfoParm)) < 0) return ix;
		else if (ix > 0) {
/*
printf("cl_func_adjust_scope: hakey=[%s]\n",hakey);
*/
			if ((rc=_adust_info(pInfoParm)) < 0) break;
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_adjust(pAns,nparm,ppParm)
long *pAns;
int nparm;
tdtInfoParm *ppParm[];
{
	static char *scope[] = {"local","private","public","global","all"};
	tdtInfoParm *pInfoParm,tInfoParm;
	XHASHB *pha;
	ProcCT *proc;
	ScrPrCT *scrct;
	int rc,i;
	char id,*p;

	rc = 0;
	if (nparm > 0) {
		for (i=0;i<nparm;i++) {
			pInfoParm = ppParm[i];
			if (pInfoParm->pi_id == ' ') {
				if ((rc=parm_to_char_tmp(pInfoParm,&p,0)) < 0) break;
				if ((rc=akxs_seqr_str(scope,5,p,1)) < 0) break;
/*
printf("cl_func_adjust: rc=%d\n",rc);
*/
				if (rc == 1) {		/* local */
					if (!(proc = cl_search_proc_ct())) {
						rc = -1;
						break;
					}
					pha = proc->pha_vnam;
				}
				else if (rc == 2) {	/* private */
					if (!(scrct = cl_search_src_ct())) {
						rc = -1;
						break;
					}
					pha = scrct->Vary->pha_vnam;
				}
				else if (rc == 3) {	/* public */
					pha = pCLprocTable->pha_vnam;
				}
				else if (rc == 4) {	/* global */
					pha = pGLprocTable->pha_vnam;
				}
				else if (rc == 5) { /* all */
					pha = NULL;
					if (!(proc = cl_search_proc_ct())) {
						rc = -1;
						break;
					}
					if ((rc=cl_func_adjust_scope(proc->pha_vnam)) < 0) break;
					if (!(scrct = cl_search_src_ct())) {
						rc = -1;
						break;
					}
					if ((rc=cl_func_adjust_scope(scrct->Vary->pha_vnam)) < 0) break;
					if ((rc=cl_func_adjust_scope(pCLprocTable->pha_vnam)) < 0) break;
					if ((rc=cl_func_adjust_scope(pGLprocTable->pha_vnam)) < 0) break;
					break;
				}
				else pha = NULL;
				if (pha) rc = cl_func_adjust_scope(pha);
			}
			else {
				if (cl_check_data_id2(pInfoParm,0x02,0x03) >= 0) {
					if ((id=pInfoParm->pi_id) == 'A') {
						rc = cl_get_array_index_tbl_ref(pInfoParm,NULL,NULL,"!cl_func_adjust");
					}
				}
			}
		}
	}
	else {
		pInfoParm = &tInfoParm;
		cl_set_parm_char(pInfoParm,"all",3);
		rc = cl_func_adjust(pAns,1,&pInfoParm);
	}
	*pAns = rc;
	return rc;
}
