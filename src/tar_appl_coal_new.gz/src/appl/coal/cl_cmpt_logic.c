static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �_�����Z����                          �@�@�@           *
*                                                                             *
*      �֐����@    �F�@int cl_cmpt_logic(pAns,pOprtr,pInfoParm1,pInfoParm2)   *
*						(O)int		 *pAns									  *
*						(I)char		 *pOprtr								  *
*						(I)tdtInfoParm *pInfoParm1							  *
*						(I)tdtInfoParm *pInfoParm2 							  *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;
extern GlobalCt  *pGlobTable;
extern int giOptions[];

int cl_get_logic_val(pInfoParm1)
tdtInfoParm *pInfoParm1;
{
	int rc,atr;
	long Value;
	double dValue;
	char *dat;
	MPA *mpa;

	rc = 1;
#if 1	/* 2023.1.1 */
	if (pInfoParm1->pi_id == 'S') pInfoParm1 = (tdtInfoParm *)pInfoParm1->pi_pos;
#endif
	if (pInfoParm1->pi_id == ' ') {
		atr = pInfoParm1->pi_attr;
		dat = pInfoParm1->pi_data;
		if (atr == DEF_ZOK_BINA) {
			memcpy(&Value,dat,sizeof(long));
			if (!Value) rc = 0;
		}
		else if (atr == DEF_ZOK_FLOA) {
			memcpy(&dValue,dat,sizeof(double));
			if (dValue == 0.0) rc = 0;
		}
		else if (atr == DEF_ZOK_DECI) {
			mpa = (MPA *)dat;
			if (mpa->zero) rc = 0;
		}
		else {
			if (!pInfoParm1->pi_dlen) rc = 0;
		}
	}
	return rc;
}

int cl_cmpt_logic(pAns,pOprtr,pInfoParm1,pInfoParm2)
long *pAns;
char *pOprtr;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	int rc=0,Result,atr[2],len[2],i,k,Value[2];
	double dValue;
	char *dat[2];
	uchar *p;
	MPA *mpa;

#if 1	/* 2021.10.28 */
	Value[0] = cl_get_logic_val(pInfoParm1);
	Value[1] = cl_get_logic_val(pInfoParm2);
#else
	atr[0] = pInfoParm1->pi_attr;
	len[0] = pInfoParm1->pi_dlen;
	dat[0] = pInfoParm1->pi_data;
	atr[1] = pInfoParm2->pi_attr;
	len[1] = pInfoParm2->pi_dlen;
	dat[1] = pInfoParm2->pi_data;
	Value[0] = Value[1] = 0;
	for (k=0;k<2;k++) {
		if (atr[k] == DEF_ZOK_BINA) {
			memcpy(&Value[k],dat[k],sizeof(long));
			if (Value[k]) Value[k] = 1;
		}
		else if (atr[k] == DEF_ZOK_FLOA) {
			memcpy(&dValue,dat[k],sizeof(double));
			if (dValue != 0.0) Value[k] = 1;
			else Value[k] = 1;
		}
		else if (atr[k] == DEF_ZOK_DECI) {
			mpa = (MPA *)dat[k];
			Value[k] = mpa->zero ? 0 : 1;
		}
		else {
			if (len[k]) Value[k] = 1;
			else Value[k] = 0;
		}
	}
#endif
/*
printf("cl_cmpt_logic: Value1=%d Value2=%d pOprtr=[%s]\n",Value[1],Value[1],pOprtr);
*/
	sswitch( pOprtr )
		sicase( "AND" )
				Result = Value[0] & Value[1];
		sicase( "OR" )
				Result = Value[0] | Value[1];
		scase( "&&" )
				Result = Value[0] & Value[1];
		scase( "||" )
				Result = Value[0] | Value[1];
#if 1
		sicase( "NOT" )
				Result = ! Value[1];
		scase( "!" )
				Result = ! Value[1];
#endif
		sdefault
			/* cl_cmpt_logic: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"cl_cmpt_logic",pOprtr);
			Result = 0;
			rc = ECL_SCRIPT_ERROR;
	endssw;

	*pAns = Result;
	return rc;

}

/****************************************/
/*										*/
/****************************************/
int cl_cmpt_agg(pInfoParmW,pOprtr,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW;
char        *pOprtr;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	int ret;
	char op,id1,id2;
	tdtRbCtl *pCt;
	tdtInfoParm tInfoParm;

DEBUGOUT_InfoParm(194,"cl_cmpt_agg: op=[%c] pInfoParm1=",pInfoParm1,*pOprtr,0);
DEBUGOUT_InfoParm(194,"cl_cmpt_agg:        pInfoParm2=",pInfoParm2,0,0);

	op = *pOprtr;
	id1 = pInfoParm1->pi_id;
	id2 = pInfoParm2->pi_id;
	if (id1=='L' || id2=='L' || id1=='N' || id2=='N') {
		if (op=='+' || op=='|') {
			ret = cl_gx_list_add(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else if (op=='-' || op=='&' || op=='^') {
			ret = cl_gx_list_minus(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else {
			ERROROUT1(FORMAT(256),pOprtr);	/* cl_cmpt_agg: non suported operater(%s)!! */
			ret = -1;
		}
		if (ret>=0 && !(pGlobTable->options[4] & 0x01)) {
			if (pCt = (tdtRbCtl *)pInfoParmW->pi_data) {
				if (akxs_rb_used(pCt) <= 0) cl_null_char(pInfoParmW);
			}
		}
	}
	else {
		if (op=='+' || op=='|') {
			ret = cl_gx_array_add(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else if (op=='-' || op=='&' || op=='^') {
			ret = cl_gx_array_minus(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else {
			ERROROUT1(FORMAT(256),pOprtr);	/* cl_cmpt_agg: non suported operater(%s)!! */
			ret = -1;
		}
	}
#if 1	/* 2025.8.28 */
	if (ret>=0 && op!='-' && (cl_get_option(2,0) & 0x2000)) {
		id1 = pInfoParmW->pi_id;
		if (id1=='L' || id1=='N' || id1=='A' || id1=='R') {
			if ((ret=cl_func_unique_opt(&tInfoParm,1,&pInfoParmW,1)) > 0) ret = 0;
			else if (!ret) cl_gx_copy_info(pInfoParmW,&tInfoParm);
		}
	}
#endif
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_cmpt_agg:Exit ret=%d pOprtr=[%s] pInfoParmW=",pInfoParmW,ret,pOprtr);
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_logic(ppWork,pOperator,nparm,ppParm,ope)
char **ppWork;
char *pOperator;
tdtInfoParm **ppParm;
int nparm,ope;
{
	tdtInfoParm *pInfoParm;
	int  i,val,iAND,iOR;
	char *pWork;

	pWork = *ppWork;
	iAND = 1;
	iOR  = 0;
	for (i=0;i<nparm;i++) {
		pInfoParm = ppParm[i];
		if (!cl_is_null_parm(pInfoParm)) {
			val = cl_get_logic_val(pInfoParm);
			if (ope==D_FUC_OR && val) {
				iOR = 1;
				break;
			}
			else if (ope==D_FUC_AND && !val) {
				iAND = 0;
				break;
			}
		}
	}
	if (ope == D_FUC_AND) val = iAND;
	else val = iOR;
	memcpy(pWork,&val,sizeof(int));
	return DEF_ZOK_BINA;
}
