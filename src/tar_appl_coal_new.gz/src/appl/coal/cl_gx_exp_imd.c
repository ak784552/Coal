static  char    sccsid[]="%Z% %M% %I% %E% %U%";
/*****************************************************/
/*                                                   */
/*       Execute expression imediately               */
/*                                                   */
/*****************************************************/
#include "colmn.h"

extern GlobalCt  *pGlobTable;
extern CLCOMMON  CLcommon;
extern int giOptions[];

/****************************************/
/*										*/
/****************************************/
int cl_gx_expsn_obj_opt(buf,len,bxobj,Obj,pInfoParmW,opt)
char *buf;
int  len;
GXObject *bxobj[];
tdtObjHead *Obj;
tdtInfoParm *pInfoParmW;
int opt;
{
	GWPRM_S gwprm;
	SSPL_S ssp;
	char wrk[4096];
/*
printf("cl_gx_expsn_obj_opt: len=%d buf=[%s]\n",len,buf);
*/
	ssp.sp = 0;
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk);
	memset(&gwprm,0,sizeof(GWPRM_S));
	gwprm.iparam = -1;
	gwprm.line = buf;
	gwprm.line_len = len;
	return cl_gx_exp_gp_obj_opt(&gwprm,&ssp,bxobj,Obj,pInfoParmW,opt);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_exps_obj_opt(buf,bxobj,Obj,pInfoParmW,opt)
char *buf;
GXObject *bxobj[];
tdtObjHead *Obj;
tdtInfoParm *pInfoParmW;
int opt;
{
	return cl_gx_expsn_obj_opt(buf,strlen(buf),bxobj,Obj,pInfoParmW,opt);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_exp(nparm,prmp,pInfoParmW)
int nparm;
parmList  *prmp[];
tdtInfoParm *pInfoParmW;
{
	return cl_gx_exp_obj_opt(nparm,prmp,NULL,pInfoParmW,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_exp_obj(nparm,prmp,Obj,pInfoParmW)
int nparm;
parmList  *prmp[];
tdtObjHead *Obj;
tdtInfoParm *pInfoParmW;
{
DEBUGOUTL2(150,"cl_gx_exp_obj: nparm=%d prmp[0]->opt=0x%08x",nparm,prmp[0]->opt);
	return cl_gx_exp_obj_opt(nparm,prmp,Obj,pInfoParmW,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_mk_gp_parm(mcat,pgwprm,nparm,prmp)
MCAT *mcat;
GWPRM_S *pgwprm;
int nparm;
parmList  *prmp[];
{
	int len,i,rc;
	char *p;

	if (nparm <= 0) {
		len = 0;
		p   = "";
	}
	else if (nparm > 1) {
		for (i=0;i<nparm;i++) {
			len = prmp[i]->prmlen;
			p   = prmp[i]->prp;
			if (len>0 && p) {
				if (i>0) if ((rc=akxtmcat(mcat," ",1))<0) return rc;
				if ((rc=akxtmcat(mcat,p,len))<0) return rc;
			}
		}
		if ((rc=akxtmcat(mcat,"",1))<0) return rc;
		len = mcat->mc_ipos;
		p   = mcat->mc_bufp;
	}
	else {
		len = prmp[0]->prmlen;
		p   = prmp[0]->prp;
	}
	pgwprm->line = p;
	pgwprm->line_len = len;
/*
printf("cl_mk_gp_parm: nparm=%d len=%d p=%08x [%s]\n",nparm,len,p,p);
*/
	return 0;
}

/****************************************/
/*										*/
/****************************************/
/* 2021.11.13 */
int cl_gx_exp_obj_opt(nparm,prmp,Obj,pInfoParmW,opt)
int nparm;
parmList  *prmp[];
tdtObjHead *Obj;
tdtInfoParm *pInfoParmW;
int opt;
{
	return cl_gx_exp_obj_opt_tree(nparm,prmp,Obj,pInfoParmW,opt,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_exp_obj_opt_tree(nparm,prmp,Obj,pInfoParmW,opt,iTREE)
int nparm;
parmList  *prmp[];
tdtObjHead *Obj;
tdtInfoParm *pInfoParmW;
int opt,iTREE;
{
	static char *sep=" \t*/&|=^~!<>[](),;?:{}";
	static MCAT mcat={'M','C',128,0,0,0,NULL,0};
	GWPRM_S gwprm;
	SSPL_S ssp;
	int rc,i,len,attr,qnum_opt,plen;
	long lVal;
	char wrk[4096],*p,c;
	GXObject  **bxobj;
	parmList qprmL,*pL;

DEBUGOUTL4(150,"cl_gx_exp_obj_opt_tree:Enter nparm=%d Obj=%08x prmp[0]->opt=0x%08x opt=0x%08x",nparm,Obj,prmp[0]->opt,opt);
/*
printf("cl_gx_exp_obj_opt_tree:Enter nparm=%d\n",nparm);
*/
#if 1	/* 2025.5.15 */
	pL = prmp[0];
	plen = pL->prmlen;
/*
printf("cl_gx_exp_obj_opt_tree: nparm=%d plen=%d prp=[%s]\n",nparm,plen,pL->prp);
*/
	if (nparm==1 && plen<=13) {	/* "NULL"�ƕ����t������ϊ����邽�߂̏��� */
#else
	if (nparm == 1) {	/* "NULL"�ƕ����t������ϊ����邽�߂̏��� */
		pL = prmp[0];
#endif
#if 1	/* 2025.11.6 *//* ()�ň͂܂�Ă��Ă��ǂ� */
		p = pL->prp;
		if (*p=='(' && *(p+plen-1)==')') {
			p++;
			plen-=2;
		}
#endif
		len = strlen(D_STR_NAME_NULL);
		if (plen==len && !memcmp(p,D_STR_NAME_NULL,len)) {
			cl_null_value(pInfoParmW);
/*
printf("cl_gx_exp_obj_opt_tree: NULL\n");
*/
			return 0;
		}
		else if ((rc=cl_qnconv(p,plen,&lVal)) == 1) {	/*rc<4) {*/
			cl_set_parm_long(pInfoParmW,lVal);
		/*	if (rc & 0x02) pInfoParmW->pi_alen |= D_AULN_OVERFLOW;	*/
/*
printf("cl_gx_exp_obj_opt_tree:OK rc=%d lVal=%d\n",rc,lVal);
*/
			return 0;
		}
/*
printf("cl_gx_exp_obj_opt_tree:NG rc=%d lVal=%d\n",rc,lVal);
*/
	}
	ssp.sp = 0;
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk);
	ssp.code =  GET_TYPE_OPT(prmp[0]->opt);
	if (prmp[0]->opt & D_GX_OPT_NO_USE_OBJ) bxobj = NULL;
	else bxobj = &prmp[0]->bxobj;

	gwprm.nparam = nparm;
	gwprm.maxlen = sizeof(wrk)-1;
	gwprm.parmLp = prmp;
	gwprm.iparam = 0;
	/* 2021.11.13 */
	rc = cl_gx_exp_gp_obj_opt_tree(&gwprm,&ssp,bxobj,Obj,pInfoParmW,opt,iTREE);

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_gx_exp_obj_opt_tree:Exit rc=%d",pInfoParmW,rc,0);

	return rc;
}
#if 1
/************************************/
/*									*/
/************************************/
int cl_set_obj0_used(used)
int used;
{
	ScrPrCT *scrct;
	ProcCT *proc;
	Leaf *leaf;

	if (proc=cl_search_proc_ct()) {
		if (leaf = proc->ProcTop)
			leaf->cmd.parl[D_PROC_OBJ0_USED].parlen = used;
/*
printf("cl_set_obj0_used:proc=%08x used=%d\n",proc,used);
*/
	}
	else if (scrct=cl_search_src_ct()) {
		if (leaf = scrct->TreeTop)
			leaf->cmd.parl[D_SCRP_OBJ0_USED].parlen = used;
/*
printf("cl_set_obj0_used:scrct=%08x: used=%d\n",scrct,used);
*/
	}
	return 0;
}

/************************************/
/*									*/
/************************************/
int cl_get_obj0_used(proc,scrct)
ScrPrCT *scrct;
ProcCT *proc;
{
	int used;
	Leaf *leaf;

	used = 0;
	if (proc) {
		if (leaf = proc->ProcTop)
			used = leaf->cmd.parl[D_PROC_OBJ0_USED].parlen;
/*
printf("cl_get_obj0_used:proc=%08x used=%d\n",proc,used);
*/
	}
	else if (scrct) {
		if (leaf = scrct->TreeTop)
			used = leaf->cmd.parl[D_SCRP_OBJ0_USED].parlen;
/*
printf("cl_get_obj0_used:scrct=%08x: used=%d\n",scrct,used);
*/
	}
	return used;
}
#endif
/* 2021.7.16 */
/****************************************/
/*										*/
/****************************************/
tdtObjHead *_mk_add_obj0(Obj,im)
tdtObjHead *Obj;
int im;
{
	/* 2021.7.16 */
	if (!(Obj=cl_mk_add_obj0(Obj,((im+MAX_CMD_OBJ0-1)/MAX_CMD_OBJ0)*MAX_CMD_OBJ0-Obj->alsz))) {
		ERROROUT("_mk_add_obj0: NULL return cl_mk_add_obj0()");
	}
	return Obj;
}

/****************************************/
/*										*/
/****************************************/
tdtObjHead *_add_obj0(Obj,pbxObj)
tdtObjHead *Obj;
GXObject *pbxObj;
{
	int im,ix;
	tdtInfoParm **ppObj0s,**ppObj0d,**Obj0,***p;
/*
printf("_add_obj0:Enter Obj=%08x\n",Obj);
*/
	if (!Obj || !pbxObj) return NULL;
	ix = Obj->used;
	im = ix + pbxObj->nobj0 + 1;/* 2023.4.21 add + 1 */
	if (im > Obj->alsz) {
		/* 2021.7.16 */
		if (!(Obj=_mk_add_obj0(Obj,im))) return NULL;
	}
	pbxObj->maxobj0 = ix + 1;	/* 2021.4.1 add +1 */
DEBUGOUTL4(158,"_add_obj0: Obj=%08x ix=%d nobj0=%d used=%d",Obj,ix,pbxObj->nobj0,im);
/*
printf("_add_obj0: Obj=%08x ix=%d nobj0=%d used=%d\n",Obj,ix,pbxObj->nobj0,im);
*/
	Obj->used = im;
	cl_set_obj0_used(im);

	return Obj;
}

/****************************************/
/*										*/
/****************************************/
int _not_same_obj0(Obj,pbxObj)
tdtObjHead *Obj;
GXObject *pbxObj;
{
	int ret,ix;
	tdtInfoParm **ppObj0d,**Obj0,*pd;

	if (!Obj || !pbxObj) return -1;
	ret = 0;
	ix = pbxObj->maxobj0 - 1;
	Obj0 = Obj->Obj0;
	ppObj0d = &Obj0[ix];
	pd = *ppObj0d;

DEBUGOUTL2(158,"_not_same_obj0: pd->pi_data=%08x pbxObj=%08x",pd->pi_data,pbxObj);

	if (pd->pi_data && pd->pi_data!=(char *)pbxObj) ret = 1;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int _re_set_obj0(Obj,pbxObj)
tdtObjHead *Obj;
GXObject *pbxObj;
{
	int i,ix,iCOPY;
	tdtInfoParm **ppObj0s,**ppObj0d,**Obj0,*p,*pd,*pds;
/*
printf("_re_set_obj0:Enter Obj=%08x\n",Obj);
*/
	if (!Obj || !pbxObj) return -1;
	ix = pbxObj->maxobj0 - 1;	/* 2021.4.1 add -1 */
	Obj0 = Obj->Obj0;
	ppObj0d = &Obj0[ix];
	ppObj0s = pbxObj->obj0;

DEBUGOUTL4(158,"_re_set_obj0: Obj=%08x ix=%d Obj0=%08x nobj0=%d",Obj,ix,Obj0,pbxObj->nobj0);

	/* 2023.4.21 */
	pd = *ppObj0d;
	pd->pi_data = (char *)pbxObj;

DEBUGOUTL1(158,"_re_set_obj0: set pbxObj=%08x",pbxObj);

	ppObj0d++;
	for (i=0;i<pbxObj->nobj0;i++) {

DEBUGOUT_InfoParm(158,"_re_set_obj0: *ppObj0d=",*ppObj0d,0,0);
DEBUGOUT_InfoParm(158,"_re_set_obj0: *ppObj0s=",*ppObj0s,0,0);

		/* 2021.2.3 */
		if (p = *ppObj0s) {
			pd = *ppObj0d;
			/* 2025.12.21 */
			iCOPY = 0;
			if (pd->pi_id == 'S') {
				pds = (tdtInfoParm *)pd->pi_pos;
				if (!pds->pi_id) iCOPY = 1;
			}
			else if (!pd->pi_id && (p->pi_id || p->pi_aux[1])) iCOPY = 1;
/*
printf("_re_set_obj0: iCOPY=%d\n",iCOPY);
*/
			if (iCOPY) {
				cl_gx_copy_info(pd,p);
DEBUGOUTL(158,"_re_set_obj0: copy_info *ppObj0d <--- *ppObj0s");
			}
		}
		/* del 2021.9.2 */
		/* 2025.12.21 */
		else {
			pd = *ppObj0d;
			if (pd->pi_id == 'S') {
				pd = (tdtInfoParm *)pd->pi_pos;
				if (!pd->pi_id) {
					*ppObj0d = NULL;
/*
printf("_re_set_obj0: *ppObj0d set NULL\n");
*/
DEBUGOUTL(158,"_re_set_obj0: *ppObj0d set NULL");
				}
			}
		}
#if 0	/* 2021.2.3 */
DEBUGOUT_InfoParm(158,"_re_set_obj0: *ppObj0d=",*ppObj0d,0,0);
#endif
		ppObj0d++;
		ppObj0s++;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
tdtObjHead *_check_add_obj0(Obj,pbxObj)
tdtObjHead *Obj;
GXObject *pbxObj;
{
	int im,ix;
	tdtInfoParm **ppObj0s,**ppObj0d,**Obj0,***p;
/*
printf("_check_add_obj0:Enter Obj=%08x\n",Obj);
*/
	if (!Obj || !pbxObj) return NULL;
	ix = pbxObj->maxobj0;
	if (ix <= 0) {
		Obj = _add_obj0(Obj,pbxObj);
	}
	else {
		im = ix + pbxObj->nobj0;	/* 2021.4.1 add -1 *//* 2023.4.21 del -1 */
		if (im > Obj->alsz) {
			/* 2021.7.16 */
			if (!(Obj=_mk_add_obj0(Obj,im))) return NULL;
		}
		if (im > Obj->used) {
			Obj->used = im;	/* 2021.4.1 add */
			cl_set_obj0_used(im);	/* 2021.7.11 add */
/*
printf("_check_add_obj0: Obj->used=%d\n",im);
*/
		}
	}
DEBUGOUTL5(158,"_check_add_obj0: Obj=%08x maxobj0=%d nobj0=%d im=%d used=%d",Obj,ix,pbxObj->nobj0,im,Obj->used);
	return Obj;
}

/****************************************/
/*										*/
/****************************************/
/* 2021.11.13 */
int cl_gx_exp_gp_obj_opt(pgwprm,pssp,bxobj,Obj,pInfoParmW,opt)
GWPRM_S *pgwprm;
SSPL_S  *pssp;
GXObject *bxobj[];
tdtObjHead *Obj;
tdtInfoParm *pInfoParmW;
int opt;
{
	return cl_gx_exp_gp_obj_opt_tree(pgwprm,pssp,bxobj,Obj,pInfoParmW,opt,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_exp_gp_obj_opt_tree(pgwprm,pssp,bxobj,Obj,pInfoParmW,opt,iTREE)
GWPRM_S *pgwprm;
SSPL_S  *pssp;
GXObject *bxobj[];
tdtObjHead *Obj;
tdtInfoParm *pInfoParmW;
int opt,iTREE;
{
	static char *name="cl_gx_exp_gp_obj_opt_tree";
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	int rc,do_compile,i,im,imw,n,nob0,cnt,ix,ix_obj0;
	GXObjectExpand bxObjExpand;
	MCAT Ms_obj,Ms_obj0,Ms_da;
	GXObject bxObj,*pbxObj;
	ProcCT *proc;
	tdtInfoParm **pObj0,*pInfo,**Obj0;
	/* 2021.11.13 */
	WHERE_TREE *tree;
	int ntr,nnest,nest[10],nest_flg[10];
	tdtObjHead tObj;

DEBUGENT2("bxobj=0x%08x Obj=0x%08x",bxobj,Obj);

DEBUGOUTL5(160,"%s:Enter bxobj=0x%08x Obj=0x%08x opt=%08x,iTREE=%d",
name,bxobj,Obj,opt,iTREE);

	if (pInfoParmW) memset(pInfoParmW,0,sizeof(tdtInfoParm));
	do_compile = 1;
	ix_obj0 = rc = 0;
	if (bxobj) {
		if (pbxObj=bxobj[0]) {
			if (pbxObj->nobj > 0) do_compile = 0;
DEBUGOUTL3(161,"%s: pbxObj=0x%08x nobj=%d",name,pbxObj,pbxObj->nobj);
		}
	}
	else {
		pbxObj = NULL;
		opt = (opt & ~D_GX_OPT_ALC_MASK) | D_GX_OPT_ALC_TMP;
	}

	if (CLcommon.dbgopt[2] & 0x01) do_compile = 1;

	if (do_compile) {
		if (pgwprm->iparam >= 0) {
			mcat.mc_ipos = 0;
			if ((rc=cl_mk_gp_parm(&mcat,pgwprm,pgwprm->nparam,pgwprm->parmLp)) < 0) return rc;
		}
/*
printf("cl_gx_exp_gp_obj_opt_tree: line_len=%d line=[%s]\n",pgwprm->line_len,pgwprm->line);
*/
		cl_gx_init_expand(&Ms_obj,"BJ",sizeof(short),MAX_OBJECT);
		cl_gx_init_expand(&Ms_obj0,"J0",sizeof(tdtInfoParm *),MAX_PMSTK);
		cl_gx_init_expand(&Ms_da,"DA",sizeof(char *),MAX_PMSTK);
		cl_gx_expand(&Ms_obj,0,NULL);
		cl_gx_expand(&Ms_da,0,NULL);
		cl_gx_expand(&Ms_obj0,0,NULL);
		bxObjExpand.ms_obj  = &Ms_obj;
		bxObjExpand.ms_da   = &Ms_da;
		bxObjExpand.ms_obj0 = &Ms_obj0;
		bxObjExpand.index0  = 0;
		if (pbxObj) opt = (opt & ~D_GX_OPT_ALC_MASK) | D_GX_OPT_ALC_TMP;
		rc=cl_gx_compile_gp_opt(pgwprm,pssp,opt,&bxObjExpand);
DEBUGOUTL2(150,"%s: cl_gx_compile_gp_opt rc=%d",name,rc);
		if (rc!=C_DO_OPTIMIZE && rc) {
			switch (rc) {
				case ECL_SYNTAX_ERROR:
					/* SYNTAX�G���[�B */
					ERROROUT1(FORMAT(171),name);
					break;
				case ECL_MAX_DA_ERROR:
					/* ���e�����v�[���E�I�[�o�t���[�B */
					ERROROUT1(FORMAT(172),name);
					break;
				case ECL_MAX_OBJ_ERROR:
					/* �I�u�W�F�N�g�E�I�[�o�t���[�B */
					ERROROUT1(FORMAT(173),name);
					break;
				case ECL_MALLOC_ERROR:
					/* malloc error. */
					ERROROUT1(FORMAT(174),name);
					break;
				case ECL_TOO_PARAMETER:
					/* %s: �s�v�ȃp�����[�^������܂��B */
					ERROROUT1(FORMAT(41),name);
					break;
				case -6:
					/* �����G���[(�A�N�V�����l���s���ł�)�B */
					ERROROUT1(FORMAT(175),name);
					break;
				default:
					break;
			}
		}
		else {
			bxObj.nobj  = bxObjExpand.nobj;
			bxObj.nda   = bxObjExpand.nda;
			bxObj.nobj0 = bxObjExpand.nobj0;
			cl_gx_expand(&Ms_da,-1,&bxObj.da);
			cl_gx_expand(&Ms_obj,-1,&bxObj.obj);
			cl_gx_expand(&Ms_obj0,-1,&bxObj.obj0);
			bxObj.index0 = bxObjExpand.index0;
			if (opt & D_GX_OPT_PARMINFO2) bxObj.index0 |= 0x04;
/*
printf("%s: index0 = %08x\n",name,bxObj.index0);
*/
			if (rc == C_DO_OPTIMIZE) {
				rc = cl_gx_iif_optimize(bxObj.obj,bxObj.nobj,bxObj.obj0);
				if (rc > 0) {
					if (rc == C_CAN_NOT_OPTIMIZE)
						ERROROUT1(FORMAT(176),name);
					rc = 0;
				}
				else if (rc == ECL_OPTIMIZE_ERROR)
					ERROROUT1(FORMAT(177),name);
				else if (rc == ECL_SYNTAX_ERROR)
					ERROROUT1(FORMAT(171),name);
				else if (rc ==  ECL_TOO_PARAMETER)
					ERROROUT1(FORMAT(41),name);
			}
if (DEBUGOUTCHECK(155)) {
short *objw;
objw = bxObj.obj;
for (i=0;i<bxObj.nobj;i++) {
DEBUGOUTL2(155,"optimized obj[%2d]=%d",i,objw[i]);
}
}
			pObj0 = bxObj.obj0;
			if (bxobj) {
				im = (opt & D_GX_OPT_ALC_MASK)>>12;
				if (!pbxObj) {
					bxobj[0] = pbxObj = (GXObject *)cl_opt_malloc(im,sizeof(GXObject));
					memset(pbxObj,0,sizeof(GXObject));
				}
DEBUGOUTL4(150,"%s: im=%d pbxObj=0x%08x nobj0=%d",name,im,pbxObj, bxObj.nobj0);
				pbxObj->nobj = bxObj.nobj;
				pbxObj->nda  = bxObj.nda;
				pbxObj->nobj0 = nob0 = bxObj.nobj0;
				pObj0 = pbxObj->obj0;
				if (bxObj.nobj) {
					n = sizeof(short)*bxObj.nobj + sizeof(tdtInfoParm *)*nob0;
					pbxObj->obj  = (short *)cl_opt_malloc(im,n);
					pbxObj->da   = (char **)cl_opt_malloc(im,sizeof(char **)*bxObj.nda);
					pbxObj->obj0 = (tdtInfoParm **)(pbxObj->obj + bxObj.nobj);
					pbxObj->index0 = bxObj.index0;
					memcpy((char *)pbxObj->obj,(char *)bxObj.obj,sizeof(short)*bxObj.nobj);
					memcpy((char *)pbxObj->da,(char *)bxObj.da,sizeof(char **)*bxObj.nda);
					memcpy((char *)pbxObj->obj0,(char *)bxObj.obj0,sizeof(tdtInfoParm *)*nob0);
					pObj0 = pbxObj->obj0;
					if (nob0) {
						if (Obj) {
							if (!(Obj=_add_obj0(Obj,pbxObj))) return ECL_MALLOC_ERROR;
							if (_re_set_obj0(Obj,pbxObj)) return -1;
							Obj0 = Obj->Obj0;
							ix_obj0 = pbxObj->maxobj0;	/* 2022.10.22 *//* 2023.4.21 del -1 */
							pObj0 = &Obj0[ix_obj0];	/* 2022.10.22 */
						/*	_clear_obj_addr(pbxObj,NULL,pbxObj->obj0);	*/
						}
					/* 2023.9.30 */
					}
					if (!Obj) {
						Obj = &tObj;
						ix_obj0 = 0;
						Obj->Obj0 = pObj0;
					}
				}
			}
			/* 2022.10.24 */
			else {
				pbxObj = &bxObj;
				Obj = &tObj;
				ix_obj0 = 0;
				Obj->Obj0 = pObj0;
			}
			/* 2021.11.13 */
/*
printf("cl_gx_exp_gp_obj_opt_tree: iTREE=%d index0=%08x\n",iTREE,pbxObj->index0);
*/
			if (iTREE && (pbxObj->index0 & 0x10)) {
				if ((ntr=cl_gx_cr_tree(pbxObj)) < 0) return ntr;
				tree = pbxObj->tree;
				nnest = 0;
				if (ntr > 0) {
				/*	nnest = cl_gx_cr_nest0(tree,nest,nest_flg);
					if (nnest < 0) return nnest;	*/
					n = ntr*sizeof(WHERE_TREE);
					if (!(pbxObj->tree=(WHERE_TREE *)cl_opt_malloc(im,n))) return ECL_MALLOC_ERROR;
					memcpy(pbxObj->tree,tree,n);
				}
				else pbxObj->tree = NULL;
			}
		}
	}
	else {
		if (nob0=pbxObj->nobj0) {
			if (Obj) {
				if (!(Obj=_check_add_obj0(Obj,pbxObj))) return ECL_MALLOC_ERROR;
				if (_not_same_obj0(Obj,pbxObj)) {
					if (!(Obj=_add_obj0(Obj,pbxObj))) return ECL_MALLOC_ERROR;
				}
				if (_re_set_obj0(Obj,pbxObj)) return -1;	/* 2021.1.31 */
				Obj0 = Obj->Obj0;
				ix_obj0 = pbxObj->maxobj0;	/* 2022.10.22 *//* 2023.4.21 del -1 */
				pObj0 = &Obj0[ix_obj0];	/* 2022.10.22 */
			}
		/* 2023.9.30 */
		}
		if (!Obj) {
			pObj0 = pbxObj->obj0;
			Obj = &tObj;
			ix_obj0 = 0;
			Obj->Obj0 = pObj0;
		}
if (DEBUGOUTCHECK(155)) {
char **daw;
short *objw;
int    nob,nda,nob0;
tdtInfoParm **objw0,**Objw0;
objw = pbxObj->obj;
daw = pbxObj->da;
nob = pbxObj->nobj;
nda = pbxObj->nda;
nob0 = pbxObj->nobj0;
if (Obj) {
	Objw0 = Obj->Obj0;
	objw0 = &Objw0[pbxObj->maxobj0];	/* 2021.4.1 add -1 *//* 2024.9.22 del -1 */
}
else objw0 = pbxObj->obj0;
for (i=0;i<nob;i++) {
DEBUGOUTL2(155,"saved obj[%2d]=%d",i,objw[i]);
}
DEBUGOUTL1(155,"index0=%d",pbxObj->index0);
for (i=0;i<nob0;i++) {
DEBUGOUTL2(155,"saved obj0[%2d]=0x%08x (reset)",i,objw0[i]);
DEBUGOUT_InfoParm(165,"",objw0[i],0,0);
}
for (i=0;i<nda;i++) {
DEBUGOUTL2(155,"saved da[%2d]=[%s]",i,daw[i]);
}
}
	}
	if (rc == 0) {
		/* 2023.1.2 */
		rc = cl_gx_ex_obj(Obj,ix_obj0,pbxObj,pInfoParmW,opt,iTREE);
DEBUGOUT_InfoParm(150,"%s: cl_gx_ex_obj rc=%d",pInfoParmW,name,rc);
		if (rc) {
			switch (rc) {
			case -3:
				/* ���Z�X�^�b�N�E�I�[�o�t���[�B */
				ERROROUT1(FORMAT(181),name);
				break;
			case -4:
				/* �����G���[(���Z�q�l���s���ł�)�B */
				ERROROUT1(FORMAT(182),name);
				break;
			case -5:
				/* �f�[�^������܂���B */
				ERROROUT1(FORMAT(183),name);
				break;
			case -6:
				/* �I�u�W�F�N�g���I�����Ă��܂���B */
				ERROROUT1(FORMAT(184),name);
				break;
			case -7:
				/* �I�u�W�F�N�g�E�f�[�^��NULL�ł��B */
				ERROROUT1(FORMAT(186),name);
				break;
			case 100:
											/* ��������܂���B */
				if (!(pGlobTable->options[3] & 0x01)) ERROROUT1(FORMAT(185),name);
				if (pGlobTable->options[3] & 0x02) rc = 0;
				if (pGlobTable->options[3] & 0x04) rc = ECL_EX_LET;
				break;
			case ECL_TOO_PARAMETER:
				/* %s: �s�v�ȃp�����[�^������܂��B */
				ERROROUT1(FORMAT(41),name);
				break;
			default:
				break;
			}
		}
	}
DEBUGRET1("rc=%d",rc);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_func(ppmstk,irs,pW,opt,pmstk,dastk,prc)
tdtInfoParm *pmstk,*pW,*ppmstk[];
int irs,opt,*prc;
char *dastk[];
{
	tdtInfoParm *pm,*pmW,*pInfo;
	int i,rc,iFunc,optW,iADDR;
	char id;

DEBUGOUTL2(161,"cl_gx_func:Enter irs=%d opt=%08x",irs,opt);

	/* 2024.7.7 */
	iFunc = 0;
	iADDR = optW = 0;
	i = irs;
	while (i >= 0) {
		pm = ppmstk[i];
		if (pm->pi_aux[1]==D_AUX1_FUNC_ARRY) {
			if (pm->pi_pos == 1) iFunc = 1;
		}
		else if (iFunc) {
DEBUGOUT_InfoParm(161,"cl_gx_func: pm: i=%d iFunc=%d",pm,i,iFunc);
			if ((id=pm->pi_id) == 'F') {
				if ((pm->pi_aux[0] & ~DEF_ZOK_DATA) != FUNCCAST) {
					optW = D_GX_OPT_GET_ADDR;
				/*	optW |= D_GX_OPT_NOERROR_NDEF | D_GX_OPT_NOEROUT_NDEF;	*/
/*
printf("cl_gx_func: optW=%08x\n",optW);
*/
					iADDR = 1;
				}
				break;
			}
		}
		else if (!pm->pi_id) {
			rc = cl_check_data_id(pm,0x04);
			return rc+ECL_CHK_VAR_ERROR;
		}
		i--;
	}
	*prc = 0;
	iFunc = 0;
	i = irs;
	while (i >= 0) {
		pm = ppmstk[i];
		pmW = pm;
		/* 2025.11.29 */
		if (iFunc==1 && pmW->pi_id=='U') {
			pmW->pi_id = D_DATA_ID_FUNCTION;
		}
		/* del 2022.9.16 */
		if (rc=_ex_conv_parm_opt(&pmW,optW,dastk[i])) {
			ERROROUT1("cl_gx_func: _ex_conv_parm_opt rc=%d",rc);
			return rc;
		}
		/* 2024.7.10 */
		cl_gx_copy_info(pm, pmW);	/* ���̒l��ύX���� */
#if 1	/* 2026.4.18 */
		/* pi_id ��'S'�ł́A�֐����̔��肪�ł��Ȃ� */
		cl_get_storevar(&pmW,0);
		pm = pmW;	/* ���̒l�͕ύX���Ȃ� */
#endif

DEBUGOUTL2(161,"cl_gx_func: i=%d iFunc=%d",i,iFunc);
DEBUGOUT_InfoParm(161,"cl_gx_func:pm: i=%d pScCT=%08x",pm,i,pm->pi_len);

		if (pm->pi_aux[1]==D_AUX1_FUNC_ARRY) {
			if (pm->pi_pos == 1) iFunc = 1;
			else {
				rc = cl_set_list(pW,irs-i,&ppmstk[i+1]);
				if (pm->pi_pos == 2) pW->pi_id = D_DATA_ID_NARABI;
				if (rc) i = cl_gx_conv_rc(rc, ECL_GX_FUNC_ERROR1);
DEBUGOUTL1(161,"cl_gx_func:Exit list i=%d",i);
				return i;
			}
		}
		else if (iFunc) {
			/* 2023.7.17 *//* 2023.8.27 del ���[�U��`�֐���I/O �֐��ȊO�ł̓N���A���Ȃ����߁A�����ł̓N���A���Ȃ� */
			if ((id=pm->pi_id) == 'F') {
				if ((pm->pi_aux[0] & ~DEF_ZOK_DATA) == FUNCCAST) {
					rc = cl_gx_mk_cast(pW,pm,irs-(i+1),&ppmstk[i+2]);
				}
				else {
					/* 2021.2.23 */
					pW->pi_paux = (char *)pm->pi_len;	/* �\����.�֐��̂Ƃ��A�\���̂�InfoParm�ւ̃|�C���^ */
/*
printf("cl_gx_func: pW->pi_paux=%08x\n",pW->pi_paux);
*/
#ifdef CANCEL_WHEN_EOF	/* 2022.6.24 */
					if (opt & D_GX_OPT_SET_IMPORT) rc = 0;	/* D_GX_OPT_SET_IMPORT��iFN_skip�Ƃ��Ďg�p */
					else
#endif
					rc = cl_gx_func_method(pW,pm,irs-(i+1),&ppmstk[i+2],opt,&pmstk[i+2]);
				}
				if (rc) *prc = cl_gx_conv_rc(rc, ECL_GX_FUNC_ERROR2);
DEBUGOUTL2(161,"cl_gx_func:Exit cast or func rc=%d i=%d",rc,i);
				return i;	/* mod "++i --> i" 2001.8.20 Koba */
			}
			else if (id == 'M') {
				opt = 0;
				rc = cl_ex_class_method(pW,pm,irs-(i+1),&ppmstk[i+2],opt);
				if (rc) i = cl_gx_conv_rc(rc, ECL_GX_FUNC_ERROR3);
DEBUGOUTL1(161,"cl_gx_func:Exit method i=%d",i);
				return i;
			}
			else if (id == 'C') {
				cl_set_parm_bin(pW,i);
DEBUGOUTL1(161,"cl_gx_func:Exit class i=%d",ECL_FUNC_CLASS);
				return ECL_FUNC_CLASS;
			}
			else {
				/* [%s]�͊֐����ł͂���܂���B */
				ERROROUT1(FORMAT(191),dastk[i]);
				return ECL_NOT_FUNCTION;
			}
		}
		else if (!pm->pi_id) {
			rc = cl_check_data_id(pm,0x04);
			return rc+ECL_CHK_VAR_ERROR;
		}
		i--;
	}
	/* �֐���������܂���B */
	ERROROUT(FORMAT(192));
	return i;
}
#if 0
/****************************************/
/*										*/
/****************************************/
cl_gx_chkset_null_parm(pInfoParm)
tdtInfoParm *pInfoParm;
{
	tdtInfoParm *pInfo;
	int iCONST;

	if (!pInfoParm) return -1;

	if (pInfoParm->pi_id == 'S') {
		pInfo = (tdtInfoParm *)pInfoParm->pi_pos;
		cl_gx_set_null_parm(pInfo);
	}
	else if (pInfoParm->pi_id=='\0') {
		iCONST = pInfoParm->pi_aux[1] & D_AUX1_PROTECTED;
		cl_null_parm(pInfoParm);
		pInfoParm->pi_aux[1] |= iCONST;
	}
	return 0;
}
#endif
/****************************************/
/*										*/
/****************************************/
int cl_gx_array3(ppmstk,irs,pW,opt,pmstk,dastk)
tdtInfoParm *pmstk,*pW,*ppmstk[];
int irs,opt;
char *dastk[];
{
	tdtInfoParm *pm,*pmW,*pp[2];
	int i,rc,iARRAY,nparm,optW;
	char c;

	iARRAY = 0;
	optW = opt & (D_GX_OPT_NOERROR_NDEF | D_GX_OPT_NOEROUT_NDEF);
	i = irs;
	while (i >= 0) {
		pm = ppmstk[i];
		pmW = pm;
		if (rc=_ex_conv_parm_opt(&pmW,optW,dastk[i])) return rc;
		cl_gx_copy_info(pm, pmW);

DEBUGOUT_InfoParm(194,"cl_gx_array3: i=%d pScCT=%08x",pm,i,pm->pi_len);

		if (iARRAY) {
			if ((c=pm->pi_id) == 'A' || c == 'R') {
				rc = cl_gx_array_bexp(pW,irs-i+1,&ppmstk[i],opt);
				if (rc > 0) i = -1;
				else if (rc < 0) i = rc;
				return i;
			}
			else if (c==D_DATA_ID_LIST || c==D_DATA_ID_NARABI) {
				/* 2023.10.9 */
				rc = cl_gx_list_bexp(pW,irs-i,&ppmstk[i],opt);
				if (rc < 0) i = rc;
				return i;
			}
			else {
				if (cl_check_data_id(pm,4) < 0) {	/* ����`�A���ݒ���`�F�b�N */
					/* [%s]�͔z�񖼂ł͂���܂���B */
					ERROROUT1(FORMAT(196),dastk[i]);
				}
				return -1;
			}
		}
		else {
			if (pm->pi_aux[1]==D_AUX1_FUNC_ARRY && pm->pi_pos==2) {
				iARRAY = 1;
				/* ��ɂ���pi_id�`�F�b�N�ŃG���[�ɂȂ�悤�ɁA
				   �ϐ����z��łȂ��A����`�̂Ƃ�����`�G���[�ɂȂ�Ȃ��悤�ɂ��� 2023.9.7 */
				optW = D_GX_OPT_NOERROR_NDEF | D_GX_OPT_NOEROUT_NDEF;
			}
			else if (rc=cl_check_data_id(pm,0x04)) return rc+ECL_CHK_VAR_ERROR;
		}
		i--;
	}
	/* �z�񖼂�����܂���B */
	ERROROUT(FORMAT(197));
	return i;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_array_conv_sel_index(nparm,ppParm,index,range)
int nparm,index[];
tdtInfoParm *ppParm[];
tdtRangeInt range[];
{
	int rc,i,ndim,iRANGE;
	tdtInfoParm *pInfo;

	ndim = index[0];
	if (nparm > ndim) {
		/* %s: ������(%d)���������܂��B(>%d) */
		ERROROUT3(FORMAT(427),"cl_gx_array_conv_sel_index",nparm,ndim);
		nparm = ndim;
	}
	index[0] = nparm;
	iRANGE = 0;
	for (i=0;i<ndim;i++) {
		if (i < nparm) {
			pInfo = ppParm[i];
			if (range) {
				memset(&range[i],0,sizeof(tdtRangeInt));
				if (pInfo->pi_alen & D_AULN_RANGE_DATA) {
					iRANGE = 1;
					if ((rc=cl_get_range_int(pInfo,&range[i])) < 0) return rc;
				}
			}
			if (!iRANGE) {
				if ((rc=cl_get_parm_bin(pInfo,&index[i+4],"cl_gx_array_bexp: ")) < 0)
					return rc;
			}
		}
		else {
			index[i+4] = index[i+ndim+4];
		}
	}
	return iRANGE;
}

/************************************************/
/* pInfoParmW = NULL : index No.��return����	*/
/************************************************/
int cl_gx_array_bexp(pInfoParmW,nparm,ppParm,opti)
tdtInfoParm *pInfoParmW;
int nparm;
tdtInfoParm *ppParm[];
int opti;
{
	static char *func_name="cl_gx_array_bexp";
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	tdtInfoParm IndexInfo;
	tdtInfoParm *pInfoParm1,*pParmI,*pInfo;
	tdtInfoParm ***pTBL;
	parmList  qprmList;
	int *index,ndim;
	int i,j,k,rc,opt,iEROUT_NDEF,iHASH,iCONST,f,iRANGE,attr,m;
	char c,c1,*name,cOpt,*pp,*p1,w1[32],*cpDat,cc[2],cCmd,**ppp;
	int  ParmNo,i1,ix,iParm[4];
	tdtInfoParm	**pvParm;
	tdtArrayIndex tIndex,*pIndex;
	ScrPrCT     *pScCT;
	XHASHB *xhp;
	tdtRangeInt range[MAX_ARRAY_DIM];

DEBUGOUTL2(190,"cl_gx_array_bexp: nparm=%d opt=%08x",nparm,opti);

	nparm -= 2;
	if (nparm <= 0) {
		/* �C���f�b�N�X���w�肳��Ă��܂���B */
		ERROROUT1(FORMAT(201),func_name);
		return ECL_SCRIPT_ERROR;
	}

	iEROUT_NDEF = !(opti & D_GX_OPT_NOEROUT_NDEF);
	opt= 0;
	cOpt= 'r';
	pInfoParm1 = ppParm[0];
/*
printf("cl_gx_array_bexp: cOpt=%c pi_id = %c\n",cOpt,pInfoParm1->pi_id);
*/
	if ((c=pInfoParm1->pi_id) != 'A' && c != 'R') {
		/* �z��ł͂���܂���B */
		ERROROUT1(FORMAT(202),func_name);
		return -2;
	}
	pIndex = &tIndex;
/*
printf("cl_gx_array_bexp:1 pIndex=%08x\n",pIndex);
*/
	if (rc=cl_get_array_index_tbl_ref(pInfoParm1,&pIndex,&pTBL,"cl_gx_array_bexp:")) return rc;
/*
printf("cl_gx_array_bexp:2 pIndex=%08x\n",pIndex);
*/

	iCONST = pInfoParm1->pi_aux[1] & D_AUX1_PROTECTED;

	if (!(name=(char *)pInfoParm1->pi_pos)) name = "";

	pParmI = NULL;
	mcat.mc_ipos = 0;
	index = pIndex->index;
	if (xhp=pIndex->xhp) {
		index[0] = 0;
		ParmNo = cl_gx_conv_index(pInfoParm1,pIndex);

DEBUGOUTL1(194,"cl_gx_array_bexp: HASH: ParmNo=%d",ParmNo);

		if (ParmNo < 0) return ParmNo;
		mcat.mc_ipos = 0;
		for (i=1;i<=nparm;i++) {
			p1 = w1;
			if ((ix=parm_to_char(ppParm[i+1],&p1,NULL)) < 0) return ix;
			if (ix > 0) {
				for (j=0;j<ix;) {
					if ((m=akxqkanjilen(p1)) > 1) {
						pp = p1;
						p1 += m;
						j += m;
					}
					else {
						pp = cc;
						c = *p1;
						if (c=='`') {
							m = 2;
							c1 = *(p1+1);
							if (c1=='`' || c1==',') {
								pp = p1;
								p1++;
								j++;
							}
							else {
								cc[0] = '`';
								cc[1] = c;
							}
						}
						else {
							cc[0] = c;
							m = 1;
						}
						j++;
						p1++;
					}
					if ((rc = akxtmcat(&mcat,pp,m)) < 0) break;
				}
			}
			if (rc < 0) return rc;
			if (i < nparm) {
				if ((rc=akxtmcat(&mcat,"`,",2)) < 0) return rc;
			}
		}
		if ((rc=akxtmcat(&mcat,"",1)) < 0) return rc;
		xhp->xha_xhix = 0;
		cCmd = 'r';
		/* 2026.1.30 */
		ix = cl_gx_chk_vnam_info(cCmd,xhp,mcat.mc_bufp,mcat.mc_ipos,&pParmI);
DEBUGOUTL2(194,"cl_gx_array_bexp: HASH: r mcat.mc_bufp=[%s] ix=%d",mcat.mc_bufp,ix);
		if (ix<0 || !pInfoParmW) return ix;
DEBUGOUT_InfoParm(194,"cl_gx_array_bexp: HASH: cmd=[%c] ix=%d",pParmI,cOpt,ix);
		if (pParmI) {
			if ((pGlobTable->options[0] & 0x01) && cl_is_undef_parm(pParmI)) cl_null_char(pParmI);
		}
	}
	else {
		iRANGE = 0;
		ndim = index[0];
		if (nparm > ndim) {
			/* %s: ������(%d)���������܂��B(>%d) */
			ERROROUT3(FORMAT(427),func_name,nparm,ndim);
			nparm = ndim;
		}
		if (&tIndex != pIndex) {
			memcpy(&tIndex,pIndex,sizeof(tdtArrayIndex));
			index = tIndex.index;
		}
		/* 2025.9.12 */
		if ((iRANGE=cl_gx_array_conv_sel_index(nparm,ppParm+2,index,range)) < 0) return iRANGE;
		if (iRANGE) {
			*pInfoParmW = *pInfoParm1;
			return cl_get_array_range(pInfoParmW,pIndex,pTBL,range,name,opti);
		}

DEBUGOUTL4(191,"cl_gx_array_bexp: index = %d %d %d %d",
index[0],index[1],index[2],index[3]);

		tIndex.pVarIndex = NULL;
		ParmNo = cl_gx_conv_index(pInfoParm1,&tIndex);

DEBUGOUTL1(194,"cl_gx_array_bexp: ParmNo=%d",ParmNo);

		if (ParmNo<0  || !pInfoParmW) return ParmNo;
		else if (ParmNo == 0) return -12;
		if ((rc=cl_array_get_info_parm(&pParmI,&tIndex,pTBL,ParmNo,cOpt)) < 0) return rc;
	}

	if (pInfoParm1->pi_scale & D_DATA_ARRAY_INDEX) {	/* 0x10 */
DEBUGOUT_InfoParm(194,"cl_gx_array_bexp: name=%s",pParmI,name,0);
		if (pParmI) {
			p1 = pp = name+strlen(name);
			if ((rc=parm_to_char(pParmI,&p1,NULL)) < 0) return rc;
			if (p1 != pp) strnzcpy(pp,p1,Var_NM_MAX*2);
DEBUGOUTL1(191,"cl_gx_array_bexp: Var name = [%s]",name);
			qprmList.prmlen = strlen(name);
			qprmList.prp    = name;
			if (rc = cl_conv_parm_opt(&qprmList,pInfoParmW,opti)) return rc;
		}
		else {
			cl_parm_set0(pInfoParmW);
		}
	}
	else if (pParmI) {
			cl_set_parm_long(pInfoParmW,(long)pParmI);
			pInfoParmW->pi_id = 'S';
			if ((c=*name)=='%' || c=='#') {
				pInfoParmW->pi_aux[1] = D_AUX1_PROTECTED;
				if (c=='%' && pParmI->pi_id=='\0') cl_null_parm(pParmI);
			}

#if 1	/* 2024.3.29 */
			if (!(pParmI->pi_aux[1] & D_AUX1_POINTER)) pParmI->pi_aux[1] |= iCONST;
#endif
			if (!tIndex.xhp) {
				pInfoParmW->pi_hlen  = ParmNo;
				/* 2023.12.18 */
				/* 2024.2.23 */
				if (pTBL) {
					p1 = (char *)pTBL[0];	/* pSize */
					index = NULL;
				}
				else {
					p1 = NULL;
					index = pIndex->index;
				}
				cl_set_pSize_index(pInfoParmW,p1,index,ParmNo,pInfoParm1->pi_paux);
			}
	}
	else {
		if (!(cpDat=cl_tmp_const_malloc(mcat.mc_ipos+1))) return -1;
		if (mcat.mc_ipos > 0) {
			memcpy(cpDat,mcat.mc_bufp,mcat.mc_ipos);
		}
DEBUGOUT_InfoParm(194,"cl_gx_array_bexp: pInfoParm1:",pInfoParm1,0,0);
		cpDat[mcat.mc_ipos] = '\0';
		cl_null_char(pInfoParmW);
		pInfoParmW->pi_id    = D_DATA_ID_UNDEFVAR;
		pInfoParmW->pi_attr  = DEF_ZOK_BULK;
		pInfoParmW->pi_dlen  = sizeof(tdtArrayIndex) + mcat.mc_ipos+1;
		pInfoParmW->pi_pos   = (long)name;
		pInfoParmW->pi_hlen  = ParmNo;
		pInfoParmW->pi_data  = pInfoParm1->pi_data;
		pInfoParmW->pi_len   = (long)cpDat;
		pInfoParmW->pi_paux  = (char *)pTBL;
/*
{
char buf[256*2+256/4+1];
int dat_len=pInfoParmW->pi_dlen;
if (dat_len > 256) dat_len = 256;
akxcxtocn(pInfoParm1->pi_data,dat_len,buf,sizeof(buf)-1,-4);
printf("cl_gx_array_bexp:dat_len=%d  pInfoParm1->pi_data=%s\n",dat_len,buf);
}
*/
	}
	pInfoParmW->pi_aux[1] |= iCONST;
DEBUGOUT_InfoParm(194,"cl_gx_array_bexp: return:",pInfoParmW,0,0);
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_list_bexp_sub(pInfoParmW,pInfo0,i1,i2,intval)
tdtInfoParm *pInfoParmW,*pInfo0;
int i1,i2,intval;
{
	static char *_fn_="cl_gx_list_bexp_sub";
	tdtInfoParm *pInfoParm,*pm[2],*pInfoParm1,tInfo,*pInfo;
	int rc,i,nm,len,i0;
	char *pp,*p0;
	tdtRbCtl *pCt,*pCt1;
/*
printf("%s: i1=%d i2=%d intval=%d\n",_fn_,i1,i2,intval);
*/
	rc = 0;
	pm[0] = pInfo0;
		*pInfoParmW = *pm[0];
		if (!(pCt = cl_tmp_rb_new(0,0,NULL))) rc = ECL_MALLOC_ERROR;
		else {
			pInfoParmW->pi_data = (char *)pCt;
			pCt1 = (tdtRbCtl *)pm[0]->pi_data;
			nm = akxs_rb_used(pCt1);
/*
printf("%s: nm=%d\n",_fn_,nm);
*/
			if (nm <= 0) return 0;
#if 1	/* 2026.3.25 */
			if (i2 >= nm) i2 = nm - 1;
#else
			if (i2 > nm) i2 = nm;
#endif
		  if (intval > 0) {
			if (i1 <= 0) {
				i0 = i1 % intval;
				i1 = i0;
			}
			else i0 = 0;
/*
printf("%s: i0=%d i1=%d i2=%d\n",_fn_,i0,i1,i2);
*/
			akxs_rb_read(pCt1,0);
			for (i=i0;i<=i2;i++) {
				if (i >= 0) {
					pInfo = (tdtInfoParm *)akxs_rb_read(pCt1,1);
					if (i == i1) {
						if (!(pInfoParm1=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm)))) {
							rc = ECL_MALLOC_ERROR;
							break;
						}
						cl_gx_copy_info(pInfoParm1,pInfo);
						if (!akxs_rb_set_n(pCt,pInfoParm1)) {
							rc = ECL_MALLOC_ERROR;
							break;
						}
						i1 += intval;
					}
				}
				else if (i == i1) {
					i1 += intval;
				}
			}
		  }
		  else {
			pm[1] = &tInfo;
			if (i1 < 0) i1 = i1 % intval;
/*
printf("%s: i1=%d i2=%d intval=%d\n",_fn_,i1,i2,intval);
*/
#if 1	/* 2025.9.10 */
			for (i=i1;;i+=intval) {
				if (intval > 0) {
					if (i > i2) break;
				}
				else {
					if (i < i2) break;
				}
#else
			for (i=i1;i<=i2;i+=intval) {
#endif
				if (i < 0) continue;
				cl_set_parm_int(pm[1],i);
				if (!(pInfoParm1=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm)))) {
					rc = ECL_MALLOC_ERROR;
					break;
				}
				if ((rc=cl_ope_list(pInfoParm1,NULL,2,pm,D_FUC_LIST_REF,0)) < 0) break;
DEBUGOUT_InfoParm(170,"cl_gx_list_bexp: ",pInfoParm1,0,0);
				if (!cl_tmp_rbset_n(pCt,pInfoParm1)) {
					rc = ECL_MALLOC_ERROR;
					break;
				}
				rc = 0;
			}
		  }
DEBUGOUT_InfoParm(170,"cl_gx_list_bexp: ",pInfoParmW,0,0);
		}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_list_bexp(pInfoParmW,nparm,ppParm,opti)
tdtInfoParm *pInfoParmW;
int nparm;
tdtInfoParm *ppParm[];
int opti;
{
	static char *_fn_="cl_gx_list_bexp";
	tdtInfoParm *pInfoParm,*pm[2];
	tdtRangeInt range;
	int rc,i,i1,i2,intval,nm;

	pm[0] = ppParm[0];
	pInfoParm = ppParm[2];
	if (pInfoParm->pi_alen & D_AULN_RANGE_DATA) {
		if ((rc=cl_get_range_int(pInfoParm,&range)) < 0) return rc;
		i1 = range.ri_start;
		i2 = range.ri_end;
		intval = range.ri_interval;
#if 1	/* 2025.9.10 */
		if (!intval) intval = 1;
#else
#if 1	/* 2025.8.22 */
		if (intval < 0) {
			intval = -intval;
			i = i1;
			i1 = i2;
			i2 = i;
		}
#endif
#endif
		nm = range.ri_num;
/*
printf("%s: i1=%d i2=%d intval=%d ri_num=%d\n",_fn_,i1,i2,intval,nm);
*/
		/* 2025.9.10 */
		rc = cl_gx_list_bexp_sub(pInfoParmW,pm[0],i1,i2,intval);
	}
	else {
		if (nparm >= 2) pm[1] = ppParm[2];
		rc = cl_ope_list(pInfoParmW,NULL,nparm,pm,D_FUC_LIST_REF,D_GX_OPT_GET_ADDR);
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_range_tenkai_sub(pIndex,pInfoParm,opt)
tdtArrayIndex *pIndex;
tdtInfoParm *pInfoParm;
int opt;
{
	int i,nm1,iRc,*index,m1,ic,code_type;
	int interval,iINTVAL,atr1,len,iVal[2];
	char *p1;
	tdtInfoParm tInfoParm,tInfoParm2,tInfoParm3,*pInfo,*pInfo2,*pInfo3,*ppParm[3];
	tdtInfoParm *ppInfo[3],tInfo[3],**ppParmW,*pParmW;

	/* range���̎擾 */
	ppParm[0] = &tInfoParm;
	ppParm[1] = &tInfoParm2;
	ppParm[2] = &tInfoParm3;
	if ((iRc=cl_get_range_info(pInfoParm,ppParm,iVal,1)) < 0) return iRc;
	pInfo  = ppParm[0];
	pInfo2 = ppParm[1];
	pInfo3 = ppParm[2];
	nm1      = iVal[0];
	interval = iVal[1];
	atr1 = pInfo->pi_attr;
	len  = pInfo->pi_dlen;
	code_type = pInfo->pi_code;
	iINTVAL = iRc & 0x01;
/*
printf("cl_gx_range_tenkai_sub: atr1=%d len=%d nm1=%d interval=%d iINTVAL=%d\n",atr1,len,nm1,interval,iINTVAL);
*/

	/* �W�J���ʂ��i�[����z����̐ݒ� */
	memset(pIndex,0,sizeof(tdtArrayIndex));
	if (!(ppParmW=(tdtInfoParm **)cl_tmp_const_malloc(nm1*sizeof(tdtInfoParm *)))) return ECL_MALLOC_ERROR;
	if (!(pParmW=(tdtInfoParm *)cl_tmp_const_malloc(nm1*sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
	pIndex->pVarIndex = ppParmW;
	pIndex->uAttr[0] = DEF_ZOK_VARI;
	pIndex->uAttr[1] = sizeof(tdtInfoParm *);
	pIndex->size = sizeof(tdtInfoParm *);
	index = pIndex->index;
	index[0] = 1;
	index[1] = nm1;
	index[2] = nm1;
	index[4] = nm1;

	/* �W�J���� */
	iRc = 0;
	if (atr1 != DEF_ZOK_BINA) {
		if (!(p1=cl_tmp_const_malloc(X_MAX(len,5)))) return ECL_MALLOC_ERROR;
		memcpy(p1,pInfo->pi_data,len);
		pInfo->pi_data = p1;
		if (atr1 == DEF_ZOK_CHAR) {
			m1 = akxqmbslen(code_type,p1);
			ic  = akxcmb2ul(p1,m1);
			*(p1+m1) = '\0';
			pInfo->pi_dlen = m1;
		}
		else if (atr1 == DEF_ZOK_DATE) {
			for (i=0;i<3;i++) ppInfo[i] = &tInfo[i];
			cl_set_parm_long(ppInfo[2],interval);
/*
printf("cl_gx_range_tenkai_sub: term=%d interval=%d\n",pInfo3->pi_hlen,interval);
*/
			if (!(i=pInfo3->pi_hlen)) i = 3;
			cl_set_parm_long(ppInfo[1],i);
		}
	}
	for (i=0;i<nm1;i++) {
		if (i > 0) {
			if (atr1 == DEF_ZOK_CHAR) {
				ic += interval;
				m1 = akxcul2mb(pInfo->pi_data,ic);
				pInfo->pi_dlen = m1;
			}
			else {
				if (iINTVAL) {
					if (atr1 == DEF_ZOK_DATE) {
						ppInfo[0] = pInfo;
						iRc = cl_func_add_to_date(pInfo2,3,ppInfo);
					}
					else {
						iRc = cl_gx_bexp(pInfo2,pInfo,"+",pInfo3,0,0);
					}
					cl_gx_copy_info2(pInfo,pInfo2);
				}
				else iRc = _gx_ppmm(14,pInfo);
				if (iRc < 0) break;
			}
		}
		cl_gx_rep_info_set_ign(pParmW,pInfo,1);
		*ppParmW++ = pParmW++;
	}
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_range_tenkai(ppmstk,irs,pW,opt,pmstk,dastk,ms_ppmstk,ms_pmstk,ms_dastk)
tdtInfoParm *pmstk,*pW,*ppmstk[];
int irs,opt;
char *dastk[];
MCAT *ms_ppmstk,*ms_pmstk,*ms_dastk;
{
	tdtInfoParm *ppParm[3],*pInfo,*pInfo2,*pInfo3,tInfoParm[3],*pParmI;
	tdtInfoParm *pm[3],tInfo[3],*ppInfo[3],*pmW,**ppParmW;
	int i,len,rc,atr1,ic,irs_max,iAttr[5],m1,nm,iINTVAL,interval,iVal[2],code_type;
	char *p,*p2,*p1,wrk[5];
	tdtArrayIndex tIndex;
/*
printf("cl_gx_range_tenkai:Enter irs=%d opt=%08x\n",irs,opt);
*/
DEBUGOUT_InfoParm(194,"cl_gx_range_tenkai:pW: irs=%d opt=%08x ",pW,irs,opt);

	if (irs < 0) return -1;
	else if (pW->pi_aux[0] & DEF_ZOK_DATA) {
#if 1	/* 2026.3.18 */
		if ((rc=cl_gx_range_tenkai_sub(&tIndex,pW,0)) < 0) return rc;
		nm = tIndex.index[2];
		ppParmW = tIndex.pVarIndex;
		pInfo = *ppParmW++;
		/* �z�񓙂ւ̏����l�ݒ�������A�ʏ�̑���ł́A���ӂƉE�ӂ̂Q���X�^�b�N�ɐς܂�Ă���B
		   �E�ӂ̓W�J�����Q�ȏゾ�ƁA���̍��ӂ̈ʒu��������Ȃ��Ȃ邽�߁A�W�J���ꂽ�f�[�^�Ɉ��t���A
		   ���Z�������ɁA���ӂ̈ʒu���T�[�`�ł���悤�ɂ���B*/
		if (nm > 1) {
			pInfo->pi_alen |= D_AULN_RANGE_INTVAL;	/* �W�J���ꂽ�f�[�^�J�n�� */
			pInfo->pi_aux[1] |= D_AUX1_PROTECTED;
		}
		pmW = &pmstk[irs];
		cl_gx_copy_info(pmW,pInfo);
		parm_to_char_tmp(pmW,&p1,0);
		dastk[irs] = p1;
		ppmstk[irs++] = pmW;
		for (i=1;i<nm;i++) {
			if (cl_gx_expand(ms_dastk,irs,&dastk) < 0) return -3;
			if (cl_gx_expand(ms_pmstk,irs,&pmstk) < 0) return -3;
			if ((irs_max=cl_gx_expand(ms_ppmstk,irs,&ppmstk)) < 0) return -3;
			else if (irs_max) _reset_addr(ppmstk,pmstk,irs);
			pInfo = *ppParmW++;
			pmW = &pmstk[irs];
			cl_gx_copy_info(pmW,pInfo);
			pmW->pi_alen &= ~D_AULN_RANGE_INTVAL;	/* �r���͈��t���Ȃ� */
			pmW->pi_aux[1] |= D_AUX1_PROTECTED;
			parm_to_char_tmp(pmW,&p1,0);
			dastk[irs] = p1;
			ppmstk[irs++] = pmW;
DEBUGOUT_InfoParm(194,"cl_gx_range_tenkai:pmW: i=%d irs=%d ",pmW,i,irs);
		}
		if (nm > 1) pmW->pi_alen |= D_AULN_RANGE_INTVAL;	/* �W�J���ꂽ�f�[�^�I���̈� */
#else
		for (i=0;i<3;i++) ppParm[i] = &tInfoParm[i];
		if ((rc=cl_get_range_info(pW,ppParm,iVal,1)) < 0) return rc;
		pInfo  = ppParm[0];
		pInfo2 = ppParm[1];
		pInfo3 = ppParm[2];
		interval = iVal[1];
		nm = iVal[0];	/* �W�J���́A�P�ȏ� */
		iINTVAL = rc & 0x01;
/*
printf("cl_gx_range_tenkai: nm=%d interval=%d\n",nm,interval);
*/
		atr1 = pW->pi_attr;
		len  = pW->pi_dlen;
		code_type = pW->pi_code;
		if (atr1 != DEF_ZOK_BINA) {
			if (atr1 == DEF_ZOK_CHAR) len++;
			if (!(p1=cl_tmp_const_malloc(len))) return ECL_MALLOC_ERROR;
			memcpy(p1,pInfo->pi_data,len);
			pInfo->pi_data = p1;
			if (atr1 == DEF_ZOK_CHAR) {
				m1 = akxqkanjilen(p1);
				ic  = akxcmb2ul(p1,m1);
				cl_set_parm_char2(pInfo,p1,m1,code_type);
				*(p1+m1) = '\0';
				ic += interval;
			}
			else if (atr1 == DEF_ZOK_DATE) {
				for (i=0;i<3;i++) ppInfo[i] = &tInfo[i];
				cl_set_parm_long(ppInfo[2],interval);
/*
printf("cl_gx_range_tenkai: term=%d interval=%d\n",pInfo3->pi_hlen,interval);
*/
				if (!(i=pInfo3->pi_hlen)) i = 3;
				cl_set_parm_long(ppInfo[1],i);
			}
		}
		/* �z�񓙂ւ̏����l�ݒ�������A�ʏ�̑���ł́A���ӂƉE�ӂ̂Q���X�^�b�N�ɐς܂�Ă���B
		   �E�ӂ̓W�J�����Q�ȏゾ�ƁA���̍��ӂ̈ʒu��������Ȃ��Ȃ邽�߁A�W�J���ꂽ�f�[�^�Ɉ��t���A
		   ���Z�������ɁA���ӂ̈ʒu���T�[�`�ł���悤�ɂ���B*/
		if (nm > 1) {
			pInfo->pi_alen |= D_AULN_RANGE_INTVAL;	/* �W�J���ꂽ�f�[�^�J�n�� */
			pInfo->pi_aux[1] |= D_AUX1_PROTECTED;
		}
		pmW = &pmstk[irs];
		cl_gx_copy_info(pmW,pInfo);
		parm_to_char_tmp(pmW,&p1,0);
		dastk[irs] = p1;
		ppmstk[irs++] = pmW;
		pInfo->pi_alen &= ~D_AULN_RANGE_INTVAL;	/* �r���͈��t���Ȃ� */
		for (i=1;i<nm;i++) {
			if (cl_gx_expand(ms_dastk,irs,&dastk) < 0) return -3;
			if (cl_gx_expand(ms_pmstk,irs,&pmstk) < 0) return -3;
			if ((irs_max=cl_gx_expand(ms_ppmstk,irs,&ppmstk)) < 0) return -3;
			else if (irs_max) _reset_addr(ppmstk,pmstk,irs);
			pmW = &pmstk[irs];
			if (atr1 == DEF_ZOK_CHAR) {
				if (!(p1=cl_tmp_const_malloc(len))) return ECL_MALLOC_ERROR;
				m1 = akxcul2mb(p1,ic);
				cl_set_parm_char2(pmW,p1,m1,code_type);
				*(p1+m1) = '\0';
				ic += interval;
			}
			else {
				if (iINTVAL) {
					if (atr1 == DEF_ZOK_DATE) {
						ppInfo[0] = pInfo;
						if ((rc=cl_func_add_to_date(pInfo2,3,ppInfo)) < 0) return rc;
					}
					else {
						if ((rc=cl_gx_bexp(pInfo2,pInfo,"+",pInfo3,0,0)) < 0) return rc;
					}
					pParmI = pInfo;
					pInfo  = pInfo2;
					pInfo2 = pParmI;
				}
				else {
					if (atr1==DEF_ZOK_DECI || atr1==DEF_ZOK_DATE) {
						rc = cl_set_parm_mpa(pInfo2,pInfo->pi_data);
						pInfo2->pi_attr = atr1;
						pInfo  = pInfo2;
					}
					if ((rc=_gx_ppmm(14,pInfo)) < 0) return rc;
				}
				cl_gx_copy_info(pmW,pInfo);
			}
			pmW->pi_aux[1] |= D_AUX1_PROTECTED;
			parm_to_char_tmp(pmW,&p1,0);
			dastk[irs] = p1;
			ppmstk[irs++] = pmW;
DEBUGOUT_InfoParm(194,"cl_gx_range_tenkai:pmW: i=%d irs=%d ",pmW,i,irs);
		}
		if (nm > 1) pmW->pi_alen |= D_AULN_RANGE_INTVAL;	/* �W�J���ꂽ�f�[�^�I���̈� */
#endif
	}
	return irs;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_range(ppmstk,irs,pW,opt,dastk)
tdtInfoParm *pW,*ppmstk[];
int irs,opt;
char *dastk[];
{
	tdtInfoParm *pmW,*pm[2],*ppParm[2],*pInfo,tInfo,tInfo1;
	int i,rc,atr;

	for (i=0;i<2;i++) {
		pmW = ppmstk[irs];
		if (rc=_ex_conv_parm_opt(&pmW,0,dastk[irs])) return rc;

DEBUGOUT_InfoParm(194,"cl_gx_range: irs=%d pScCT=%08x",pmW,irs,pmW->pi_len);

		if (cl_is_null_value(pmW)) {
			cl_null_value(pW);
			return 0;
		}
		if (rc=cl_check_data_id(pmW,0)) return rc;
		pm[i] = pmW;
		irs--;
	}
	irs++;
#if 1	/* 2025.4.2 */
	if (pm[0]->pi_alen & D_AULN_RATIONAL) {
		if ((rc=cl_rational_to_real(&tInfo,pm[0])) < 0) return rc;
		pm[0] = &tInfo;
	}
	if (pm[1]->pi_alen & D_AULN_RATIONAL) {
		if ((rc=cl_rational_to_real(&tInfo1,pm[1])) < 0) return rc;
		pm[1] = &tInfo1;
	}
#endif
	ppParm[0] = pm[1];
	ppParm[1] = pm[0];
	if (pm[1]->pi_alen & D_AULN_RANGE_DATA) {
		if ((rc=cl_func_range(pW,2,ppParm)) < 0) irs = rc;
	}
	else {
		/* "���l..����"�̂Ƃ��́A�����𐔒l�ɕϊ����Ȃ��Ƌ������ǂ���������Ȃ� */
		atr = ppParm[0]->pi_attr;
		if ((atr>=DEF_ZOK_BINA && atr<=DEF_ZOK_DECI) && ppParm[1]->pi_attr==DEF_ZOK_CHAR) {
			pInfo = &tInfo;
			if ((rc=cl_conv_const_n_str(pInfo,ppParm[1]->pi_data,ppParm[1]->pi_dlen)) < 0) return rc;
			else if (rc > 0) return ECL_SCRIPT_ERROR;
			ppParm[1] = pInfo;
		}
		if (ppParm[1]->pi_scale & D_DATA_IMAGE) {
			/* �͈͎w��̂Ƃ��́A�ʏ�̓[���ł����̂܂ܕ��f���ɂ��� */
			if (cl_get_option(2,0) & 0x100) {
				if (cl_adjust_complex(pW,ppParm[0],ppParm[1])) return irs;
			}
		}
		if ((rc=cl_gx_range_set(pW,2,ppParm,opt)) < 0) irs = rc;
	}

DEBUGOUT_InfoParm(194,"cl_gx_range:pW: irs=%d ",pW,irs,0);

	return irs;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_range_set(pW,nparm,pm,opt)
tdtInfoParm *pW,*pm[];
int nparm,opt;
{
	static char *_fn_="cl_gx_range_set";
	int i,len,rc,atr1,atr2,iAttr[5],sizeMPA,iCOMPLEX,iU1,iU2,code_type1,code_type2;
	long lVal1,lVal2,Valz[NMPA_LONG*2+1],*Val;
	char *p;

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_gx_range_set: Enter pm[0]=",pm[0],0,0);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"                       pm[1]=",pm[1],0,0);
DEBUGOUTL1(120,"cl_gx_range_set: opt=%08x",opt);

	if ((pm[0]->pi_alen & D_AULN_COMPLEX_DATA) || (pm[1]->pi_alen & D_AULN_COMPLEX_DATA)) {
		ERROROUT2(FORMAT(318),_fn_,FORMAT(635));	/* ���f�� *//*%s: %s�͎g�p�ł��܂���B*/
		return ECL_SCRIPT_ERROR;
	}
	atr1 = pm[0]->pi_attr;
	atr2 = pm[1]->pi_attr;
	iU1 = pm[0]->pi_scale & D_DATA_UNSIGNED;
	iU2 = pm[1]->pi_scale & D_DATA_UNSIGNED;
	code_type1 = cl_get_char_code_type(pm[0],2);
	code_type2 = cl_get_char_code_type(pm[1],2);
/*
printf("cl_gx_range: atr1=%d atr2=%d\n",atr1,atr2);
*/
	iCOMPLEX = 0;
	Val = cl_get_tmpMPA2(Valz,2);
	if ((atr1>DEF_ZOK_DECI && atr1!=DEF_ZOK_DATE) || (atr2>DEF_ZOK_DECI && atr2!=DEF_ZOK_DATE)) {
		/* From(%d)�܂���To(%d)�̃f�[�^�^�͎w��ł��܂���B */
		ERROROUT2(FORMAT(206),atr1,atr2);
		return ECL_SCRIPT_ERROR;
	}
	else if ((atr1>=DEF_ZOK_BINA && atr1<=DEF_ZOK_DECI) || (atr2>=DEF_ZOK_BINA && atr2<=DEF_ZOK_DECI)) {
		if (pm[0]->pi_scale & D_DATA_IMAGE) {
			ERROROUT1(FORMAT(634),_fn_);	/* %s: �����̈ʒu������Ă��܂��B*/
			return ECL_SCRIPT_ERROR;
		}
		/* ���̊֐��́ARange�f�[�^��Ԃ����Ƃ��O��̂��߁A
		   �����ɁAcl_adjust_complex()�����邱�Ƃ͂ł��Ȃ� */
		if ((atr1=cl_cmpt_math(Val,"..", pm[0],pm[1],iAttr)) < 0) return atr1;
		if (pm[1]->pi_scale & D_DATA_IMAGE) iCOMPLEX = D_AULN_COMPLEX_DATA;
	}
	else if (atr1==DEF_ZOK_DATE || atr2==DEF_ZOK_DATE) {
		sizeMPA = sizeofMPA();
		Val[0] = sizeMPA;
		p = (char *)&Val[1];
		if (atr1 != DEF_ZOK_DATE) {
			if ((rc=cl_get_parm_date(pm[0],p,"cl_gx_range:date")) < 0) return rc;
			atr1 = DEF_ZOK_DATE;
		}
		else memcpy(p,pm[0]->pi_data,sizeMPA);
		p += sizeMPA;
		if (atr2 != DEF_ZOK_DATE) {
			if ((rc=cl_get_parm_date(pm[1],p,"cl_gx_range:date")) < 0) return rc;
		}
		else memcpy(p,pm[1]->pi_data,sizeMPA);
		iAttr[0] = DEF_ZOK_DATE;
	}

	if (atr1==DEF_ZOK_CHAR && atr2==DEF_ZOK_CHAR) {
		if (code_type1 != code_type2) {
			ERROROUT3(FORMAT(648),_fn_,code_type1,code_type2);	/* %s: �����R�[�h���قȂ��Ă��܂��B��1=%d ��2=%d */
			return ECL_SCRIPT_ERROR;
		}
		len = X_MAX(pm[0]->pi_dlen,pm[1]->pi_dlen) + 1;
		if (!(p=cl_tmp_const_malloc(len*2))) return -1;
		memzcpy(p,pm[0]->pi_data,pm[0]->pi_dlen);
		memzcpy(p+len,pm[1]->pi_data,pm[1]->pi_dlen);
		cl_set_parm_char2(pW,p,len,code_type1);
	}
	else {
		cl_set_parm_long(pW,0);
		len = Val[0];
		pW->pi_attr = atr1;
		pW->pi_dlen  = len;
		if (atr1 == DEF_ZOK_BINA) {
			lVal1 = Val[1];
			lVal2 = Val[2];
/*
printf("cl_gx_range: lVal1=%d lVal2=%d\n",lVal1,lVal2);
*/
			cl_set_parm_long(pW,lVal1);
			pW->pi_hlen = lVal2;
		}
		else {
			if (!(p=cl_tmp_const_malloc(len*2))) return ECL_MALLOC_ERROR;
			memcpy(p,&Val[1],len*2);
			pW->pi_data = p;
			pW->pi_scale = 0;
			if (atr1==DEF_ZOK_CHAR || atr1==DEF_ZOK_DATE) {
				pW->pi_hlen = 1;	/* interval */
				if (atr1 == DEF_ZOK_DATE) pW->pi_pos = 3;	/* term */
			}
		}
	}
	pW->pi_alen |= D_AULN_RANGE_DATA | iCOMPLEX;
	if (pW->pi_attr == DEF_ZOK_BINA) pW->pi_scale |= iU1 | iU2;

DEBUGOUT_InfoParm(194,"%s:pW: ",pW,_fn_,0);

	return 0;
}

/****************************************/
/*										*/
/****************************************/
/*
	char   mc_id[2];     id[2]
	ushort mc_extlen;    size
	ushort mc_maxcnt;    max_cnt
	ushort mc_extcnt;    extent
	int    mc_alclen;
	char   *mc_bufp;     pbuf
	int    mc_ipos;      im
*/
int cl_im_init_expand(mcat,id,size,extent,im)
MCAT *mcat;
char *id;
int  size,extent,im;
{
/*
printf("cl_im_init_expand: %s size=%d extent=%d im=%d\n",id,size,extent,im);
*/
	if (!mcat) return -1;
	if (im<0 || im>4) return -2;
	memset(mcat,0,sizeof(MCAT));
	memcpy(mcat->mc_id,id,2);
	mcat->mc_ipos = im;
	mcat->mc_extlen = size;
	if (extent <= 0) extent = 8;
	mcat->mc_extcnt = extent;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_im_expand(mcat,cnt,pbuf2)
MCAT *mcat;
int  cnt;
char **pbuf2;
{
	char *p;
	int  im,ret,len,max_cnt;

	if (!mcat) return -1;
	ret = 0;
	max_cnt = mcat->mc_maxcnt;
	if (cnt >= max_cnt) {
		if (mcat->mc_extcnt <= 0) mcat->mc_extcnt = 8;
		while (cnt >= max_cnt) {
			max_cnt += mcat->mc_extcnt;
			mcat->mc_extcnt *= 2;
		}
		len = mcat->mc_extlen*max_cnt;
		if (mcat->mc_ipos == D_OPT_ALC_MALLOC) {
			p = MRealloc(mcat->mc_bufp,len);
			if (!p) return -1;
		}
		else {
			p = cl_opt_malloc(mcat->mc_ipos,len);
			if (!p) return -1;
			memcpy(p,mcat->mc_bufp,mcat->mc_alclen);
		}
		memset(p+mcat->mc_alclen,0,len-mcat->mc_alclen);
		mcat->mc_bufp = p;
		mcat->mc_maxcnt = max_cnt;
		mcat->mc_alclen = len;
/*
printf("cl_im_expand: %c%c max_cnt=%d cnt=%d\n",mcat->mc_id[0],mcat->mc_id[1],max_cnt,cnt);
*/
		ret = max_cnt;
	}
	else {
		p = mcat->mc_bufp;
		if (cnt < 0) ret = max_cnt;
	}
/*
printf("cl_im_expand: pbuf2=%08x p=%08x\n",pbuf2,p);
*/
	if (pbuf2) *pbuf2 = p;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
char *cl_im_init_set_expand(mcat,id,size,extent,buf,im)
MCAT *mcat;
char *id;
int  size,extent;
char *buf;
int  im;
{
	int len;

	cl_im_init_expand(mcat,id,size,extent,im);
	len = size*extent;
	mcat->mc_alclen = len;
	mcat->mc_maxcnt = extent;
	mcat->mc_bufp = buf;
/*
printf("cl_im_init_set_expand: buf=%08x len=%d\n",buf,len);
*/
	return buf + len;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_init_expand(mcat,id,size,extent)
MCAT *mcat;
char *id;
int  size,extent;
{
	return cl_im_init_expand(mcat,id,size,extent,D_OPT_ALC_TMP);
}

/****************************************/
/*										*/
/****************************************/
char *cl_gx_init_set_expand(mcat,id,size,extent,buf)
MCAT *mcat;
char *id;
int  size,extent;
char *buf;
{
	return cl_im_init_set_expand(mcat,id,size,extent,buf,D_OPT_ALC_TMP);
}

/****************************************/
/*										*/
/****************************************/
char *cl_gx_init_set_expand_im(mcat,id,size,extent,buf,im)
MCAT *mcat;
char *id;
int  size,extent,im;
char *buf;
{
	return cl_im_init_set_expand(mcat,id,size,extent,buf,im);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_expand(mcat,cnt,pbuf2)
MCAT *mcat;
int  cnt;
char **pbuf2;
{
	return cl_im_expand(mcat,cnt,pbuf2);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_conv_rc(rc, conv_rc)
int rc,conv_rc;
{
	if (rc > 0) rc = conv_rc;
	return rc;
}
