static	char	sccsid[]="%Z% %M% %I% %E% %U%";

#include <colmn.h>

extern CLPRTBL  *pCLprocTable;
/*
extern GlobalCt  *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];
*/
/********1*********2********3*********4*********5*********6******/
/* ���� : IN													*/
/*			p0		 : line�̃A�h���X							*/
/*			len0	 : line�̒��� (�o�C�g)						*/
/*			posa[]	 : posa[0] : start (�o�C�g/����)(�擪��1)	*/
/*					   posa[1] : len   (�o�C�g/����)			*/
/*		  OUT													*/
/*			posa1[]	 : len0�𔽉f�����l							*/
/*					 : posa1[0] : start��1�O(�o�C�g)(�擪��0)	*/
/*					   posa1[1] : len  (�o�C�g)					*/
/*					   posa1[2] : start��1�O(����)  (�擪��0)	*/
/*					   posa1[3] : len  (����)					*/
/****************************************************************/
static int _get_str_pos_posb(p0,len0,posa,posa1)
char *p0;
int len0,posa[],posa1[];
{
	char *pp0;
	int mflg,sta;

	if (!p0 || !posa || !posa1) return -1;

	if (pCLprocTable->CurScr)
		mflg = pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX;
	else mflg = 1;

	sta = posa[0];
	if (sta > 0) sta--;
	posa1[0] = akxqm2len(p0,len0,sta);
	if (posa[1] > 0) 
		posa1[1] = akxqm2len(p0+posa1[0],len0-posa1[0],posa[1]);
	else
		posa1[1] = len0 - posa1[0];
	posa1[2] = akxqmlen(p0,posa1[0]);
	posa1[3] = akxqmlen(p0+posa1[0],posa1[1]);

	return 0;
}

/********1*********2********3*********4*********5*********6******/
/* ���� : IN													*/
/*			pos[] : pos[0] : start (�o�C�g/����)				*/
/*					pos[1] : len   (�o�C�g/����)				*/
/*			par3  : ������J�n�ʒu���\���̂ւ̃|�C���^		*/
/*					par3->par      : ������J�n�ʒu�̃|�C���^	*/
/*					par3->parlen   : ����(�o�C�g)				*/
/*									<0 : strlen(par3->par)�ƂȂ�*/
/*					par3->parlaen2 : ���ݒ�	 					*/
/*		  OUT													*/
/*			par3  : ������J�n�ʒu���\���̂ւ̃|�C���^		*/
/*					par3->par      : ������J�n�ʒu+start		*/
/*					par3->parlen   : len(�o�C�g)				*/
/*					par3->parlaen2 : lenm(����) 				*/
/* �X�V : 2022.12.11 Akito Konayashi par3�g�p					*/
/****************************************************************/
static int _get_str_pos(pos,par3)
int pos[];
ParList3 *par3;
{
	static char null_str[2]={'\0','\0'};	/* 2021.7.28 add */
	ParList2 par2;
	char *pp0;
	int mflg,rc,len1,lenm,i_s,i_e,lenmm,n;
/*
printf("_get_str_pos:Enter pos[0]=%d pos[1]=%d\n",pos[0],pos[1]);
*/
/*	if (!ppp0) return -1;	*/
	if (!(pp0 = par3->par)) return -1;
/*
printf("_get_str_pos:1: pp0=[%s]\n",pp0);
*/
	if (pCLprocTable->CurScr)
		mflg = pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX;
	else mflg = 1;

	if ((len1=par3->parlen) < 0) len1 = strlen(par3->par);
	/* 2025.9.18 */
	lenm = len1;
	if (len1>0 && mflg) lenm = akxqmlen(pp0,len1);
	if (lenm > 0) {
		par2.option = 0;
		if (pos[1] == INT_MIN) n = 1;
		else n = 2;
		mod_pos_len(lenm,pos,n,cl_get_option(2,0)>>16);
		len1 = substr_mlen(&par2,pp0,len1,pos[0],pos[1]);
		pp0 = par2.par;
		if (len1>0 && mflg) lenm = akxqmlen(pp0,len1);
	}
	else {
		lenm = len1 = 0;
		pp0 = null_str;
	}
	par3->parlen = len1;
	par3->parlen2 = lenm;
	par3->par = pp0;
/*
printf("_get_str_pos:Exit mflg=%08x len1=%d lenm=%d pos=%d\n",mflg,len1,lenm,pos[0]);
printf("_get_str_pos:Exit pp0=%08x pp0=[%s]\n",pp0,pp0);
*/
	return 0;
}

/********1*********2*********3*********4*********5********6*********7/
/* �@�\ : �J�n�ʒu�ƒ��������߂�									*/
/* ���� : i         : �l��Ԃ�pos�̈ʒu								*/
/*		              pInfoParm���͈͎w��̂Ƃ��́A0 �Œ�			*/
/*		  pInfoParm : �p�����[�^�̃|�C���^							*/
/*		  pos       : pos[i] : �ݒ�l 								*/
/*		              �͈͎w��̂Ƃ���								*/
/*		            : pos[0] : �J�n�ʒu (�ݒ�l)					*/
/*		            : pos[1] : ����		(�ݒ�l)					*/
/* �ԋp : ���^�[���R�[�h											*/
/*		  = 1 : ���� i=0�Ŕ͈͎w�肠��								*/
/*		  = 0 : ����												*/
/*		  < 0 : �G���[												*/
/* �쐬 : 20XX.XX.XX Akito Konayashi								*/
/* �X�V :															*/
/********************************************************************/
static int _get_pos_len(i,pInfoParm,pos)
int i;
tdtInfoParm *pInfoParm;
int pos[];
{
	int rc;
	tdtInfoParm tInfoParm;

	rc = 0;
	if (pInfoParm->pi_id != ' ') return ECL_SYNTAX_ERROR;
	else if (pInfoParm->pi_alen & D_AULN_RANGE_DATA) {
		if (i) {
			/* _get_pos: �͈͎w�肪�擪�ȊO�ɂ���܂��Bi=%d */
			ERROROUT1(FORMAT(250),i);
			rc = ECL_SCRIPT_ERROR;
		}
		else if ((rc=cl_get_parm_bin(pInfoParm,pos,"str_pos1")) >= 0) {
			cl_gx_copy_info(&tInfoParm,pInfoParm);
			if (tInfoParm.pi_attr == DEF_ZOK_BINA) tInfoParm.pi_pos = tInfoParm.pi_hlen;
			else tInfoParm.pi_data += tInfoParm.pi_dlen;
			if ((rc=cl_get_parm_bin(&tInfoParm,&pos[1],"str_pos2")) >= 0) {;
				/* 2025.9.10 */
				pos[1] -= pos[0] - 1;
				rc = 1;
			}
		}
	}
	else {
		if ((rc=cl_get_parm_bin(pInfoParm,&pos[i],"str_posi")) > 0) rc = 0;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _rep_wildcard(pat,pat0,patlen,cmd,code_type)
char *pat,*pat0,cmd;
int patlen,code_type;
{
	int i,len,m,rem;
	char c,*p,*p0,c1;
/*
printf("_rep_wildcard:Enter patlen=%d pat0=[%s]\n",patlen,pat0);
*/
	p = pat;
	p0 = pat0;
	len = rem = patlen;
	if (cmd == 's') c1 = '.';
	else c1 = '?';
	while (rem > 0) {
/*
printf("_rep_wildcard: rem=%d\n",rem);
getchar();
*/
		m = akxqmbsnlen(code_type,p0,rem);
		if (m == 1) {
			if ((c=*p0) == '*') c = '%';
			else if (c == c1) c = '_';
			else if (c=='%' || c=='_') {
				*p++ = '\\';
				len++;
			}
			else if (c == '\\') {
				*p++ = c;
				p0++;
				c = *p0;
				rem--;
				m = akxqmbsnlen(code_type,p0,rem);
			}
		}
		if (m == 1) {
			*p++ = c;
			p0++;
			rem--;
		}
		else {
			memcpy(p,p0,m);
			p += m;
			p0 += m;
			rem -= m;
		}
	}
	*p = '\0';
/*
printf("_rep_wildcard: len=%d pat=[%s]\n",len,pat);
*/
	return len;
}

/********************************************/
/*	c2   : cmd == 's'|'S'�̂Ƃ��́A���g�p	*/
/*	cmd  : cmd != 's'|'S'�̂Ƃ��́Ac2���g�p	*/
/********************************************/
static int _gx_str_rep(pp1,len1,pat0,patlen,c2,cmd,code_type)
char **pp1,*pat0,c2,cmd;
int len1,patlen,code_type;
{
	char c,*p1,*pat,*p,sep,*sch,*rep,*opt,ucmd;
	int ret,i,pos1,pos2,schlen,replen,optlen,m,rem;
	tdtInfoParm pParm[5],*ppParm[5];

	p1 = *pp1;
/*
printf("_gx_str_rep:Enter len1=%d p1=[%s] patlen=%d pat0=[%s] c2=[%c] cmd=[%c]\n",
len1,p1,patlen,pat0,c2,cmd);
*/
	ret = 0;
	if (!(p = cl_tmp_const_malloc(patlen+1))) return ECL_MALLOC_ERROR;
	memzcpy(p,pat0,patlen);
	pat = p;
	rem = patlen;
	ucmd = toupper(cmd);
	i = 0;
	if (ucmd == 'S') {
		sep = *p++;
		rem--;
	/*	i++;	*//* del 2026.4.22 */
	}
	else sep = '/';
	pos1 = pos2 = 0;
	sch = p;
	schlen = rem;
	while (rem > 0) {
		m = akxqkanjilen2(p,rem);
		if (m == 1) {
			if ((c=*p++) == '\\') {
				m = akxqkanjilen2(p,rem);
				p += m;
				i += m;
				rem -= m;
			}
			else if (c == sep) {
				*(p-1) = '\0';
				if (!pos1) {
					rep = p;
					pos1 = i;
					schlen = pos1;	/* - 1;*//* 2025.8.22 del "- 1" */
					if (ucmd != 'S') break;
				}
				else if (!pos2) {
					opt = p;
					pos2 = i;
					replen = pos2 - pos1 - 1;
				}
				else {
					ret = ECL_SYNTAX_ERROR;
					break;
				}
			}
			i++;
			rem--;
		}
		else {
			p += m;
			i += m;
			rem -= m;
		}
	}
	if (!ret) {
		if (ucmd == 'S') {
			if (!pos2) ret = ECL_SYNTAX_ERROR;
			else {
				optlen = patlen - pos2 - 2;	/* 2026.4.22 1-->2 */
				if (cmd == 'S') {
					if (!(p=cl_tmp_const_malloc(schlen*2+3))) return ECL_MALLOC_ERROR;
					schlen = _rep_wildcard(p,sch,schlen,cmd,code_type);
					sch = p;
				}
			}
		}
		else {
			if (!pos1) ret = ECL_SYNTAX_ERROR;
			else {
				rep = p;
				replen = patlen-i-1;
				if (c2) {
					opt = "g";
					optlen = 1;
				}
				else {
					opt = "";
					optlen = 0;
				}
			}
		}
	}

	if (ret < 0) {
		ERROROUT2(FORMAT(628),"_gx_str_rep",pat0);	/* %s:  �ҏW�w��[%s]������Ă��܂��B*/
	}
	else {
/*
printf("_gx_str_rep: schlen=%d sch=[%s] replen=%d rep=[%s] optlen=%d opt=[%s]\n",
schlen,sch,replen,rep,optlen,opt);
*/
		/* REPLIKE(line,pat,rep,opt,escape)	*/
		cl_set_parm_char(&pParm[0],p1,len1);
		cl_set_parm_char(&pParm[1],sch,schlen);
		cl_set_parm_char(&pParm[2],rep,replen);
		cl_set_parm_char(&pParm[3],opt,optlen);
		cl_set_parm_char(&pParm[4],"\\",1);
		for (i=0;i<5;i++) ppParm[i] = &pParm[i];
		if (cmd == 's')
			ret = cl_rep_regex(pp1,5,ppParm);
		else
			ret = cl_rep_like(pp1,5,ppParm);
		if (!ret) ret = strlen(*pp1);
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
static int _like_pat_rzcpy(str1,str2,len)
char *str1,*str2;
int len;
{
	int len1,m,mlen,len2;
	char *p1,*p2,c,*pp;

	if (!(p1=str1) || !(p2=str2)) return -1;
/*
printf("_like_pat_rzcpy: len=%d str2=[%s]\n",len,str2);
*/
	mlen = 0;
	len1 = len;
	p1 += len1;
	*p1 = '\0';
	while (len1 > 0) {
		mlen++;
		m = akxqkanjilen2(p2,len1);
		if (m >= 2) {
			p1 -= m;
			memcpy(p1,p2,m);
			len1 -=m;
			p2 += m;
		}
		else if ((c=*p2)=='\\') {
			p2++;
			len1--;
			m = akxqkanjilen2(p2,len1);
			p1 -= m;
			memcpy(p1,p2,m);
			p1--;
			*p1 = c;
			p2 += m;
			len1 -= m;
			mlen++;
		}
		else if (c=='[') {
			len2 = 1;
			pp = p2;
			pp++;
			len1--;
			while (len1 > 0) {
				mlen++;
				m = akxqkanjilen2(pp,len1);
				if (m >= 2) len2 += m;
				else if ((c=*pp)=='\\') {
					pp++;
					len1--;
					m = akxqkanjilen2(pp,len1);
					pp += m;
					len1 -= m;
					len2 += m;
					mlen++;
				}
				else {
					pp++;
					len1--;
					len2++;
					if (c == ']') break;
				}
			}
			p1 -= len2;
			memcpy(p1,p2,len2);
			p2 = pp;
		}
		else {
			p1--;
			*p1 = *p2++;
			len1--;
		}
	}
/*
printf("_like_pat_rzcpy: mlen=%d str1=[%s]\n",mlen,str1);
*/
	return mlen;
}

/********************************************/
/*											*/
/* �ԋp : < 0 : �G���[�̈ʒu(�擪��-(1))	*/
/*		  = 0 : PNAME�̂�					*/
/*		  > 0 : text�̈ʒu(�擪��1)			*/
/********************************************/
static int _get_pos_text(nparm,ppParm)
int nparm;
tdtInfoParm *ppParm[];
{
	int i;
	tdtInfoParm *pInfoParm;

	i = 0;
	for (i=0;i<nparm;i++) {
		if (pInfoParm = ppParm[i]) {
			if (pInfoParm->pi_id != D_DATA_ID_PNAME) {
				i++;
				break;
			}
		}
		else {
			i = -(i+1);
			break;
		}
	}
/*
printf("_get_pos_text: i=%d\n",i);
*/
	return i;
}

/********1*********2********3*********4*********5*********6******/
/* ���� : IN													*/
/*			nparm	 : �p�����[�^��								*/
/*			ppParm[] : �ȉ��̃p�����[�^							*/
/*						line [,start [,len]]					*/
/*						start,len�̓��͕͂����P��				*/
/*			pos0[]	 : start,len��Ԃ�int�z��					*/
/*						NULL�̂Ƃ��̓G���[						*/
/*		  OUT													*/
/*			pos0[]	 : 											*/
/*						pos0[0]:start(�w��l�A�擪��1)			*/
/*						pos0[1]:len(�w��l)						*/
/*						pos0[2]:start�܂���len�̎��̈ʒu		*/
/* �ԋp : < 0 : �G���[											*/
/*		  = 0 : nparm<=0��ppParm[1]�����l�łȂ�					*/
/*		  = 1 : ppParm[1](start)�����l�ł���					*/
/*		  = 2 : ppParm[1](start)��ppParm[2](len)�����l�ł���	*/
/****************************************************************/
static int _get_parm_str_pos(nparm,ppParm,pos0)
int nparm,pos0[];
tdtInfoParm **ppParm;
{
	tdtInfoParm *pInfoParm;
	int ret,shift,i;

	if (!pos0) return -1;
	shift = 0;
	pos0[0] = 1;
	pos0[1] = -1;
	pos0[2] = 0;
	for (i=1;i<nparm;i++) {
		if (shift >= 2) break;
		pInfoParm = ppParm[i];
		if (pInfoParm->pi_id != D_DATA_ID_PNAME) {
			if (pInfoParm->pi_id==' ' && pInfoParm->pi_attr==DEF_ZOK_BINA) {
				if ((ret=_get_pos_len(shift,pInfoParm,pos0)) < 0) return ret;
				shift++;
				if (ret) {
					shift++;
				}
			}
			else break;
		}
	}
	pos0[2] = i;
/*
printf("_get_parm_str_pos: nparm=%d shift=%d pos0=%d %d %d\n",nparm,shift,pos0[0],pos0[1],pos0[2]);
*/
	return shift;
}

/********1*********2********3*********4*********5*********6******/
/* ���� : IN													*/
/*			nparm	 : �p�����[�^��								*/
/*			ppParm[] : �ȉ��̃p�����[�^							*/
/*						line [,start [,len]]					*/
/*						start,len�̓��͕͂����P��				*/
/*			pa[]	 : line�̃A�h���X��Ԃ��|�C���^�z��			*/
/*						NULL�̂Ƃ��́A���Ȃ��Ă�start,len��		*/
/*						�`�F�b�N�͍s��							*/
/*			lena[]	 : line�̒�����Ԃ�int�z��					*/
/*			max_pa	 : pa[],lena[]�̔z��						*/
/*						5�ȉ��̂Ƃ���1�ƌ��Ȃ�					*/
/*		  OUT													*/
/*			pa[]	 : 											*/
/*						pa[0]:line+start						*/
/*						pa[5]:line�̐擪�A�h���X				*/
/*			lena[]	 : 											*/
/*						lena[0]:p[0]�̒���(�o�C�g)				*/
/*						lena[5]:line�̃o�C�g��					*/
/*						lena[6]:start(�o�C�g�A�擪��1)			*/
/*						lena[7]:start�܂ŃX�L�b�v�����o�C�g��	*/
/*						lena[8]:start,len�̎��̈ʒu				*/
/* �ԋp : < 0 : �G���[											*/
/*		  = 0 : nparm<=0��ppParm[1]�����l�łȂ�					*/
/*		  = 1 : ppParm[1](start)�����l�ł���					*/
/*		  = 2 : ppParm[1](start)��ppParm[2](len)�����l�ł���	*/
/****************************************************************/
static int _get_text_str_pos(nparm,ppParm,pa,lena,max_pa)
int nparm,lena[],max_pa;
tdtInfoParm **ppParm;
char *pa[];
{
	int ret,shift,len1,len2,pos0[3],len0,posa1[4],i1;
	char *p1;

	if (pa) pa[0] = NULL;
	if (lena) {
		lena[0] = 0;
		if (max_pa >= 6) lena[5] = 0;
	}
	if (nparm <= 0) return 0;

	ret = shift = len1 = len0 = 0;
	if (pa) {
#if 1	/* 2022.10.20 */
		if ((i1=_get_pos_text(nparm,ppParm)) < 0) return i1;
		else if (!i1) {
			ERROROUT2(FORMAT(76),"_get_text_str_pos","text");		/* %s: %s������܂���B*/
			return ECL_SCRIPT_ERROR;
		}
		i1--;
#endif
		p1 = NULL;
		if ((ret=parm_to_char(ppParm[i1],&p1,NULL)) >= 0) {
			len0 = len1 = ret;
		}
		else shift = ret;
		if (max_pa >= 6) pa[5] = p1;
	}
	pos0[0] = 1;
	if (lena && max_pa>=8) lena[7] = 0;
	if ((shift=_get_parm_str_pos(nparm-i1,&ppParm[i1],pos0)) > 0) {
		if (len1 > 0) {	/* pa!=NULL�̏������܂�ł��� */
			/* 2022.6.19 */
			_get_str_pos_posb(p1,len0,pos0,posa1);
			len1 = posa1[0];
			p1 += len1;
			if (lena && max_pa>=8) lena[7] = len1;
			len1 = posa1[1];
		}
	}

	if (pa) pa[0] = p1;
	if (lena) {
		lena[0] = len1;
		if (max_pa >= 6) lena[5] = len0;
		if (max_pa >= 7) lena[6] = pos0[0];
		if (max_pa >= 9) lena[8] = pos0[2] + i1;
	}

	return shift;
}

/********1*********2*********3*********4*********5********6*********7/
/* �@�\ : �u������[,�J�n�ʒu[,����]]�v�`������͂���				*/
/* ���� : IN:														*/
/*		  nparm	 : �p�����[�^��										*/
/*		  ppParm : �p�����[�^�̃|�C���^�z��							*/
/*		  i1     : ������̃p�����[�^�ʒu(�擪��0)					*/
/*		  par3   : ������J�n�ʒu����Ԃ��\���̂ւ̃|�C���^		*/
/*				   ���e�͖��ݒ�ŗǂ�(�Q�Ƃ��Ȃ�)					*/
/*		  ppos   : (nparm=1(������̂�)�̂Ƃ��́A����)				*/
/*		           ppos[0] : �J�n�ʒu(����)							*/
/*		         : ppos[1] : ����(����)								*/
/*		  msg    : �Ăяo�����̃R�����g								*/
/*		  OUT:														*/
/*		  par3   : ������J�n�ʒu����Ԃ��\���̂ւ̃|�C���^		*/
/*				   ���e�͖��ݒ�ŗǂ�(�Q�Ƃ��Ȃ�)					*/
/*				   par3->par      : ������J�n�ʒu�̃|�C���^		*/
/*				   par3->parlen   : ����(�o�C�g)					*/
/*				   par3->parlaen2 : ����(����) 						*/
/*		  ppos   : 													*/
/*		           ppos[0] : �J�n�ʒu(����)							*/
/*		         : ppos[1] : ����(����)								*/
/* �ԋp : >0 : �u������,�J�n�ʒu[,������]�v�̎��̃p�����[�^�ʒu		*/
/*		  <0 : �G���[												*/
/* �쐬 : 20XX.XX.XX Akito Konayashi								*/
/* �X�V : 2022.12.11 Akito Konayashi par3�g�p						*/
/********************************************************************/
int cl_get_str_pos(nparm,ppParm,i1,par3,ppos,msg)
int nparm;
tdtInfoParm *ppParm[];
int i1;
ParList3 *par3;
int ppos[];
char *msg;
{
	tdtInfoParm *pInfoParm;
	int len1,lenm,rc,iGET,pos[3],mflg,ii,code_type;
	char *pp0;

	if (nparm < i1+1) return -1;
	/* 2022.10.20 *//* 1-->0 2022.10.21 */
	pp0 = NULL;
	if ((rc=parm_to_char(pInfoParm=ppParm[i1],&pp0,NULL)) < 0) return rc;
	lenm = len1 = rc;
	i1++;
	pos[1] = INT_MIN;	/* 2025.9.18 -1==>INT_MIN */
/*
printf("cl_get_str_pos: nparm=%d i1=%d len1=%d\n",nparm,i1,len1);
*/
	code_type = pInfoParm->pi_code;
	if (nparm >= i1+1) {
		if (!(pInfoParm = ppParm[i1])) return -2;
		/* 2022.10.20 */
		if ((rc=_get_parm_str_pos(nparm-i1+1,&ppParm[i1-1],pos)) < 0) return rc;
		else if (rc) {
			iGET = 1;
			i1 = pos[2];
/*
printf("cl_get_str_pos: rc=%d pos=%d %d %d\n",rc,pos[0],pos[1],pos[2]);
*/
		}
		else {
			iGET = 0;
			pos[0] = 1;
		}
		if (ppos) {
			ppos[0] = pos[0];
			ppos[1] = pos[1];
		}
	}
	else {
		if (ppos) {
			pos[0] = ppos[0];
			pos[1] = ppos[1];
		}
		else  return -11;
		iGET = 1;
	}
/*
printf("cl_get_str_pos: iGET=%d pos=%d %d\n",iGET,pos[0],pos[1]);
*/
	par3->parlen = len1;
	par3->parlen2 = lenm;
	par3->par = pp0;
	if (iGET) {
		if (rc=_get_str_pos(pos,par3)) return rc;
	}
	else {
		mflg = pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX;
		if (len1>0 && mflg) lenm = akxqmlen_type(pp0,len1,code_type);
		par3->parlen2 = lenm;
	}
/*
printf("cl_get_str_pos:Exit len1=%d lenm=%d\n",par3->parlen,par3->parlen2);
*/
/*	if (plen1) *plen1 = len1;
	if (plenm) *plenm = lenm;	*/
	return i1;
}
#if 0
/****************************************/
/*										*/
/****************************************/
int cl_get_str_pos2(nparm,pParm,i1,par3,ppos,msg)
int nparm;
tdtInfoParm *pParm;
int i1;
ParList3 *par3;
int *ppos;
char *msg;
{
	tdtInfoParm *ppParm[3];
	int rc,pos[2];

	ppParm[0] = &pParm[0];
	ppParm[1] = &pParm[1];
	if (nparm > 2) ppParm[2] = &pParm[2];
	if (ppos) pos[0] = *ppos;
	pos[1] = -1;
	rc = cl_get_str_pos(nparm,ppParm,i1,par3,pos,msg);
	if (ppos) *ppos = pos[0];
	return rc;
}
#endif

/****************************************/
/*										*/
/****************************************/
int cl_gx_str_pos(pInfoParmW,pInfoParm1,optW,pInfoParm2)
tdtInfoParm *pInfoParmW,*pInfoParm1,*pInfoParm2;
int optW;
{
	parmList pList;
	ParList3 par3;
	tdtInfoParm  tInfoParm,tInfoParm2[2],*pInfoParm;
	int pos[2],len1,rc,nparm,i,j;
	char *pp0,*p,c;

DEBUGOUTL1(161,"--->cl_gx_str_pos: optW=%08x",optW);
DEBUGOUT_InfoParm(161,"pInfoParm1:",pInfoParm1,0,0);
DEBUGOUT_InfoParm(161,"pInfoParm2:",pInfoParm2,0,0);

	if (pInfoParm1->pi_id != ' ') return ECL_SYNTAX_ERROR;

	len1 = pInfoParm2->pi_dlen;
	p = pInfoParm2->pi_data;
	if (pInfoParm2->pi_attr==DEF_ZOK_CHAR && len1>0) {
		if (pInfoParm2->pi_alen & D_AULN_NAME_DATA) {
			memset(&pList,0,sizeof(parmList));
			pList.prp = p;
			pList.prmlen = len1;
			pList.opt = SET_TYPE_OPT(cl_get_char_code_type(pInfoParm2,1));
			if ((rc=cl_conv_arg(&pList,&tInfoParm)) < 0) {
				if (rc != ECL_DEFINED_ARRAY) return rc;
			}
/*
DEBUGOUT_InfoParm(0,"cl_gx_str_pos:1: rc=%d",&tInfoParm,rc,0);
*/
			if (rc==NAME_CONST && tInfoParm.pi_dlen>0) {
				pList.prp = tInfoParm.pi_data;
				pList.prmlen = tInfoParm.pi_dlen;
				pList.opt = SET_TYPE_OPT(tInfoParm.pi_code);
				if (rc = cl_conv_parm(&pList,&tInfoParm)) {
					if (rc != ECL_DEFINED_ARRAY) return rc;
				}
/*
DEBUGOUT_InfoParm(0,"cl_gx_str_pos:2: rc=%d",&tInfoParm,rc,0);
*/
			}
			if (tInfoParm.pi_id != ' ') return ECL_SYNTAX_ERROR;
			p = tInfoParm.pi_data;
			len1 = tInfoParm.pi_dlen;
			pInfoParm2 = &tInfoParm;
		}
	}
	if (pInfoParm2->pi_attr == DEF_ZOK_CHAR) {	/*	move to. 2022.11.28 */
		if (len1 > 0) {
			len1 = akxtstrim(0,p,len1,AKX_TRIM_SPACE2);
		}
		if (len1 <= 0) {
			ERROROUT1(FORMAT(627),"cl_gx_str_rep");	/* %s: �؂�o���w��܂��͕ҏW�w�肪��ł��B*/
			return ECL_SCRIPT_ERROR;	/*ECL_SYNTAX_ERROR;*/
		}
/*	if (pInfoParm2->pi_attr == DEF_ZOK_CHAR) {	move from. 2022.11.28 */
		if ((c=*p)=='%' || c=='#' || c=='/' || c=='s' || c=='S') {
/*
printf("cl_gx_str_pos: p=[%s]\n",p);
*/
			return cl_gx_str_edit(pInfoParmW,pInfoParm1,p,len1);
		}
	}
	pos[1] = INT_MIN;	/* 2025.9.18 -1==>INT_MIN */
	if (pInfoParm2->pi_attr==DEF_ZOK_CHAR && !(pInfoParm2->pi_alen & D_AULN_RANGE_DATA)) {
		if (rc= cl_gx_exps_obj_opt(pInfoParm2->pi_data,NULL,NULL,tInfoParm2,D_GX_OPT_PARMINFO2|D_GX_OPT_GET_RANGE)) return rc;
		nparm = cl_get_InfoParm2(tInfoParm2,&pInfoParm,NULL);
		if (nparm > 2) nparm = 2;
		for (i=0;i<nparm;i++,pInfoParm++) {
/*
DEBUGOUT_InfoParm(0,"cl_gx_str_pos: i=%d",pInfoParm,i,0);
*/
			if ((rc=_get_pos_len(i,pInfoParm,pos)) < 0) return rc;
			else if (rc==1 && nparm>1) {
			/*	parm_to_char_tmp(pInfoParm,&p,0);
				ERROROUT2(FORMAT(649),"cl_gx_str_rep",p);	*//* %s: �؂�o���w��[%s]������Ă��܂��B*/
				return ECL_SYNTAX_ERROR;
			}
/*
printf("cl_gx_str_pos: i=%d pos[0]=%d pos[1]=%d\n",i,pos[0],pos[1]);
*/
			if (pos[1] >= 0) break;
		}
	}
	else if ((rc=_get_pos_len(0,pInfoParm2,pos)) < 0) return rc;
/*
printf("cl_gx_str_pos: pos[0]=%d pos[1]=%d\n",pos[0],pos[1]);
*/
	if ((rc=cl_get_str_pos(1,&pInfoParm1,0,&par3,pos,"str_pos")) < 0) return rc;
/*
printf("cl_gx_str_pos: len1=%d pos[0]=%d pp0=%08x\n",par3.parlen,pos[0],par3.par);
*/
	if (!(pp0 = cl_tmp_const_malloc(par3.parlen+1))) {
		ERROROUT("cl_gx_str_pos: malloc error");
	 	return ECL_MALLOC_ERROR;
	}
	memzcpy(pp0,par3.par,par3.parlen);
	cl_set_parm_char2(pInfoParmW,pp0,par3.parlen,pInfoParm1->pi_code);
DEBUGOUTL1(161,"<---cl_gx_str_pos: len1=%d",par3.parlen);
	return 0;
}

/********1*********2********3*********4*********5*********6******/
/* ���� : IN													*/
/*			nparm	 : �p�����[�^��								*/
/*			ppParm[] : �ȉ��̊֐��p�����[�^						*/
/*					IN (line[,start,len],pat,opt,escape)		*/
/*					REP(line[,start,len],pat,rep,opt,escape)	*/
/*			pa[]	 : �̕�����̃|�C���^�z��					*/
/*						p1[1]:NULL/char w[32*4]�̐擪�A�h���X	*/
/*			pos_opt	 :�I�v�V����								*/
/*						=3:in, =4:like							*/
/*			shift    :  = 0 : start,len �Ȃ�					*/
/*						= 1 : start     ����					*/
/*						= 2 : start,len ����					*/
/*			lena[]	 : lena[8] : pat�̈ʒu						*/
/*		  OUT													*/
/*			pa[]	 : �̕�����̃|�C���^�z��					*/
/*						p1[1]:pat�̐擪�A�h���X					*/
/*						pos_opt = 3 (in)�̂Ƃ�					*/
/*							p1[2]:opt							*/
/*						pos_opt = 4 (rep)�̂Ƃ�					*/
/*							p1[2]:rep							*/
/*							p1[3]:opt							*/
/*						opt�����l�w��̂Ƃ��́Ap1[]=NULL,		*/
/*						�l��len[]�ɐݒ肳���					*/
/*			lena[]	 : �����z��(�o�C�g)							*/
/*						lena[0]:p[0]�̒���(�o�C�g)				*/
/*						lena[1]:p[1]�̒���(�o�C�g)				*/
/*						lena[2]:p[2]�̒���(�o�C�g)				*/
/*						lena[3]:p[3]�̒���(�o�C�g)				*/
/****************************************************************/
static int _get_pat_rep(nparm,ppParm,pa,lena,pos_opt,shift)
int nparm,lena[],pos_opt,shift;
tdtInfoParm **ppParm;
char *pa[];
{
	int ret,i,j,n,nn,inx_opt,atr,val;
	tdtInfoParm *pInfoParm;

	n = X_MIN(nparm,pos_opt);
	for (i=2;i<n;i++) {
		pa[i] = pa[i-1] + 32;
	}
	ret = 0;
	nn = X_MIN(nparm,pos_opt+shift);
	inx_opt = pos_opt -1 ;
	for (i=1,j=1;i<nn;i++) {
		if ((i==1 && shift) || (i==2 && shift==2)) ;
		else {
			pInfoParm = ppParm[i];
			if (ret=cl_check_data_id(pInfoParm,0)) ret += ECL_CHK_VAR_ERROR;
			else {
				atr = pInfoParm->pi_attr;
				if (j == inx_opt) {
					if (atr == DEF_ZOK_CHAR) 
						ret = parm_to_char(pInfoParm,&pa[j],NULL);
					else if (atr==DEF_ZOK_BINA || atr==DEF_ZOK_FLOA || atr==DEF_ZOK_DECI) {
						pa[j] = NULL;
						if ((ret=cl_get_parm_bin(pInfoParm,&val,"_get_pat_rep:")) >= 0) ret = val;
/*
printf("_get_pat_rep: j=%d ret=%d\n",j,ret);
*/
					}
					else {
						ERROROUT2(FORMAT(395),"_get_pat_rep",atr);	/* %s: �f�[�^�^(%02x)���s���ł��B*/
						ret = ECL_SCRIPT_ERROR;
					}
				}
				else ret = parm_to_char(pInfoParm,&pa[j],NULL);
/*
printf("_get_pat_rep: pa[%d]=[%s]\n",j,pa[j]);
*/
			}
			if (ret < 0) break;
			lena[j++] = ret;
		}
		ret = 0;
	}
	if (n < pos_opt) pa[inx_opt] = NULL;
	return ret;
}

/********1*********2********3*********4*********5*********6******/
/* ���� : IN													*/
/****************************************************************/
static int _get_edit_rep_pat(pat,patlen,escape,iOpt,pa,lena)
char *pat,escape,*pa[];
int patlen,iOpt[],lena[];
{
	char *plen1,*plen2,c,c1,c2,*p;
	int ret,iTOP,iG,iBTM,iRVS;

	if (!pat) return -1;
	if (patlen <= 0) return 0;
	p = pat;
	plen1 = p + patlen - 1;
	if (!(pat = cl_tmp_const_malloc(patlen+3))) {
		return ECL_MALLOC_ERROR;
	}
	iG   = iOpt[1];
	iTOP = iOpt[2];
	iBTM = iOpt[3];
	iRVS = iOpt[5];
	memzcpy(pat+1,p,patlen);
	if (patlen==1 && *p==escape) {
		*pat = '%';
		*(pat+2) = escape;
		*(pat+3) = '%';
		patlen = 4;
	}
	else {
		if (patlen >= 2) plen2 = plen1 - 1;
		else plen2 = plen1 + 1;
		if ((c=*p) == '^') {
			iTOP = 1;
			iG = 0;
			pat += 2;
			patlen--;
		}
		else if (c == '%') {
			pat++;
		}
		else if (c == '$') pat++;
		else {
			*pat = '%';
			patlen++;
		}
		if ((c2=*plen2) != escape) {
			if ((c1=*plen1) == '$') {
				iBTM = 1;
				iG = 0;
				patlen--;
			}
			else if (c1 == '%') ;
			else if (c1 != '^') {
				*(pat+patlen) = '%';
				patlen++;
			}
		}
		else {
			*(pat+patlen) = '%';
			patlen++;
		}
	}
	*(pat+patlen) = '\0';
	if (iRVS) {
		if (!(p = cl_tmp_const_malloc(patlen+1))) {
			ret = ECL_MALLOC_ERROR;
		}
		else {
			_like_pat_rzcpy(p,pat,patlen);
			pat = p;
		}
	}
	pa[4] = pat;
	lena[4] = patlen;
	iOpt[1] = iG;
	iOpt[2] = iTOP;
	iOpt[3] = iBTM;
	return ret;
}

/********1*********2********3*********4*********5*********6******/
/* �@�\ : �Q�ƃI�v�V���������񒆂ɂ���I���I�v�V���������񒆂�	*/
/*		  �����ɑΉ�����I�v�V������OR��Ԃ�					*/
/* ���� : IN													*/
/*			sel_opt_str : �I���I�v�V����������(ignore case)		*/
/*											  (�\�[�g�s�v)		*/
/*						  NULL�̂Ƃ��́Aref_opt_str���g�p����	*/
/*			max_sel_opt : �I���I�v�V����������				*/
/*			ref_opt_str : �Q�ƃI�v�V����������(�啶��)(�~��)	*/
/*			max_ref_opt : �Q�ƃI�v�V����������				*/
/*			ref_opta[]  : �Q�ƃI�v�V�����z��					*/
/* �ԋp : �I���I�v�V�����l��OR									*/
/*			ref_opt_str=NULL or ref_opta=NULL or max_ref_opt<=0	*/
/*			�̂Ƃ��́A0 ��Ԃ�									*/
/****************************************************************/
static int _get_sel_ref_opt(sel_opt_str,max_sel_opt,ref_opt_str,max_ref_opt,ref_opta)
char *sel_opt_str,*ref_opt_str;
int max_sel_opt,max_ref_opt,ref_opta[];
{
	int i,j,opt,*ref_opt,i_sel,i_ref,max_i;
	char *p_sel,*p_ref,c_sel,c_ref,max_c,c;

	if (!ref_opt_str || !ref_opta || max_ref_opt<=0 || max_sel_opt<=0) return 0;
	if (!sel_opt_str) {
		sel_opt_str = ref_opt_str;
		max_sel_opt = max_ref_opt;
	}
/*
printf("_get_sel_ref_opt: max_sel_opt=%d sel_opt_str=[%s]\n",max_sel_opt,sel_opt_str);
printf("_get_sel_ref_opt: max_ref_opt=%d sel_ref_str=[%s]\n",max_ref_opt,ref_opt_str);
*/
	/*
	   sel_opt_str��啶���ɕϊ�����
	*/
	p_sel = sel_opt_str;
	for (i=0;i<max_sel_opt;i++) {
		*p_sel = akxcupper(*p_sel);
		p_sel++;
	}
/*
printf("_get_sel_ref_opt: upper: sel_opt_str=[%s]\n",sel_opt_str);
*/
	/*
	   sel_opt_str���~���Ƀ\�[�g����
	*/
	akxnstrsort_opt(sel_opt_str,max_sel_opt,1);
/*
printf("_get_sel_ref_opt: sort : sel_opt_str=[%s]\n",sel_opt_str);
*/
	/*
	   �}�b�`���O�����ɂ��I���I�v�V�����l��OR�����
	*/
	opt = 0;
	p_sel = sel_opt_str;
	p_ref = ref_opt_str;
	ref_opt = ref_opta;
	i_sel = i_ref = 0;
	for (;;) {
		if (i_sel>=max_sel_opt && i_ref>=max_ref_opt) break;
		c_sel = *p_sel;
		c_ref = *p_ref;
		if ((!c_sel || c_sel==' ') && (!c_ref || c_ref==' ')) break;
		if (c_sel == c_ref) {
			opt |= *ref_opt;
			ref_opt++;
			p_sel++;
			p_ref++;
			i_sel++;
			i_ref++;
		}
		else if (c_sel < c_ref) {
			ref_opt++;
			p_ref++;
			i_ref++;
		}
	/*	else if (c_sel > c_ref) {	*/
		else {
			p_sel++;
			i_sel++;
		}
	}
/*
printf("_get_sel_ref_opt: opt=%08x\n",opt);
*/
	return opt;
}

/********1*********2********3*********4*********5*********6******/
/* �@�\ : replike�p�I�v�V����(IZOLIG)������I���I�v�V����		*/
/*		  �����񒆂̕����ɑΉ�����I�v�V������OR��Ԃ�			*/
/* ���� : IN													*/
/*			sel_opt_str : �I���I�v�V����������(ignore case)		*/
/*											  (�\�[�g�s�v)		*/
/*			max_sel_opt : �I���I�v�V����������				*/
/* �ԋp : �I���I�v�V�����l��OR									*/
/*		  sel_opt_str=NULL�̂Ƃ��́Areplike�p�I�v�V�����l��Ԃ�	*/
/****************************************************************/
static int _get_opt_replike(sel_opt_str,max_sel_opt)
char *sel_opt_str;
int max_sel_opt;
{
	static char *ref_opt_str = "ZROLIG";
	static int ref_opta[] = {AKX_LIKE_IGN_HAZE,AKX_LIKE_REVERSE, D_LINE_PAT_ONLY>>8,
	                         AKX_LIKE_LNGMATCH,AKX_LIKE_IGN_CASE,D_LINE_PAT_GLOBAL>>8};

	return _get_sel_ref_opt(sel_opt_str,max_sel_opt,ref_opt_str,strlen(ref_opt_str),ref_opta);
}

/********1*********2********3*********4*********5*********6******/
/* ���� : IN													*/
/*			nparm	 : �p�����[�^��								*/
/*			ppParm[] : �ȉ��̊֐��p�����[�^						*/
/*					INLIKE (line[,start,len],pat,opt,escape)	*/
/*					REPLIKE(line[,start,len],pat,rep,opt,escape)*/
/*			pos_opt	 :�I�v�V����								*/
/*						0x000f : =4:replike, =3:inlike			*/
/*						0x1000 : revers							*/
/*						0x2000 : �Œ���v���[�h					*/
/*		  OUT													*/
/*			p1[]	 : �̕�����̃|�C���^�z��					*/
/*						p1[0]:line+start						*/
/*						p1[1]:����pat�̐擪�A�h���X				*/
/*						pos_opt = 3 (inlike)�̂Ƃ�				*/
/*							p1[2]:opt							*/
/*						pos_opt = 4 (replike)�̂Ƃ�				*/
/*							p1[2]:rep							*/
/*							p1[3]:opt							*/
/*						p1[4]:�ҏW���pat						*/
/*						p1[5]:line�̐擪�A�h���X				*/
/*			len[]	 : �����z��(�o�C�g)							*/
/*						len[0]:p[0]�̒���(�o�C�g)				*/
/*						len[1]:p[1]�̒���(�o�C�g)				*/
/*						len[2]:p[2]�̒���(�o�C�g)				*/
/*						len[3]:p[3]�̒���(�o�C�g)				*/
/*						len[4]:p[4]�̒���(�o�C�g)				*/
/*						len[5]:line�̃o�C�g��					*/
/*						len[6]:start							*/
/*						len[7]:start�܂ŃX�L�b�v�����o�C�g��	*/
/*			iOpt[]	 : �ݒ�I�v�V����							*/
/*						iOpt[0] = iCASE							*/
/*						iOpt[1] = iG							*/
/*						iOpt[2] = iTOP							*/
/*						iOpt[3] = iBTM							*/
/*						iOpt[4] = iONLY							*/
/*						iOpt[5] = iRVS | iLCMP					*/
/*			pplike	 : LIKE�\���̂ւ̃|�C���^��Ԃ��A�h���X		*/
/****************************************************************/
static int _get_line_pat(nparm,ppParm,p1,len,iOpt,pplike,pos_opt)
int nparm,len[],iOpt[];
tdtInfoParm **ppParm;
char *p1[];
tdtLike **pplike;
int pos_opt;
{
	static tdtLike *plike=NULL;
	int  optw,iCASE,iG,iTOP,iBTM,iONLY,iRVS,iLCMP;
	int  i,n,ret,opt,patlen,ll,pos_escape,pos0_opt,pos0_escape,j,shift,nn;
	int  code_type1,code_type2,iM1,iM2;
	char *p,*pat,*plen1,*pp,*plen2,c,c1,c2;
	uchar *pesc,escape;
	tdtInfoParm *pInfoParm;

	mem_set_int(len,0,8);
	mem_set_addr(&p1[2],NULL,5);
	code_type1 = cl_get_char_code_type(ppParm[0],1);
	iM1 = cl_is_mbyte(ppParm[0],code_type1);
	p1[1] = p1[0] + 32;
	if ((shift=_get_text_str_pos(nparm,ppParm,p1,len,9)) < 0) return shift;
	code_type2 = cl_get_char_code_type(pInfoParm=ppParm[shift+1],1);
	iM2 = cl_is_mbyte(pInfoParm,code_type2);
/*
printf("_get_line_pat: shift=%d code_type1=%d code_type2=%d iM1=%d iM2=%d\n",shift,code_type1,code_type2,iM1,iM2);
*/
	if ((iM1 | iM2) && akxq_code_type_cmp(code_type1,code_type2)) {
		ERROROUT3(FORMAT(648),"cl_replace",code_type1,code_type2);	/* %s: �����R�[�h���قȂ��Ă��܂��B��1=%d ��2=%d */
		return ECL_SCRIPT_ERROR;
	}
	iTOP = iBTM = 0;
	iG    = pos_opt & D_LINE_PAT_GLOBAL;
	iONLY = pos_opt & D_LINE_PAT_ONLY;
	optw = pos_opt>>8;
	iCASE = optw & (AKX_LIKE_IGN_CASE | AKX_LIKE_IGN_HAZE);
	iRVS  = optw & AKX_LIKE_REVERSE;
	iLCMP = optw & AKX_LIKE_LNGMATCH;
	pos_opt &= 0x0f;
	pos_escape = pos_opt + 1;
	pos0_opt = pos_opt - 1;
	pos0_escape = pos_escape - 1;

	if ((ret=_get_pat_rep(nparm,ppParm,p1,len,pos_opt,shift)) < 0) return ret;
/*
cl_str_conv_put(&pp,p1[1],len[1]);
printf("_get_line_pat: pat=[%s] opt=[%s]\n",pp,p1[pos0_opt]);
*/
	/* 2022.10.21 */
	if (p = p1[pos0_opt]) {
		n = _get_opt_replike(p,strlen(p));
	}
	else n = len[pos0_opt];
	if (n > 0) {
		iG    = n & (D_LINE_PAT_GLOBAL>>8);
		iONLY = n & (D_LINE_PAT_ONLY>>8);
		iCASE = n & (AKX_LIKE_IGN_CASE | AKX_LIKE_IGN_HAZE);
		iRVS  = n & AKX_LIKE_REVERSE;
		iLCMP = n & AKX_LIKE_LNGMATCH;
/*
printf("_get_line_pat: n=%08x iCASE=%d iG=%d iONLY=%d iLCMP=%02x iRVS=%02x\n",n,iCASE,iG,iONLY,iLCMP,iRVS);
*/
	}
	plike = *pplike;
	opt = iCASE | iLCMP | SET_TYPE_OPT(code_type1);
	if (plike) plike->lk_option = opt;
	else if (!(plike = akxs_xlike_new(0,opt))) return -1;
	*pplike = plike;

/*	escape = 0xff;	*/
	if (nparm >= pos_escape+shift) {
		if ((ret=parm_to_char_tmp(ppParm[pos0_escape+shift],&pesc,0)) < 0) goto Err;
		if (!(escape = *pesc)) escape = 0xff;
		plike->lk_escape = escape;
	}
	else escape = akxs_like_escape(0xff);
	if (iRVS) {
		if (!(p = cl_tmp_const_malloc(len[0]+1))) {
			ret = ECL_MALLOC_ERROR;
			goto Err;
		}
		cmn_mrzcpy(p,p1[0],len[0]);
		p1[0] = p;
	}
	if ((ret=akxs_xlike_set_line(plike,p1[0],len[0])) < 0) goto Err;

	pat = p = p1[1];
	patlen = len[1];
	/* 2022.10.11 */
	iOpt[1] = iG;
	iOpt[2] = iTOP;
	iOpt[3] = iBTM;
	iOpt[5] = iRVS;
	ret = _get_edit_rep_pat(pat,patlen,escape,iOpt,p1,len);
	iOpt[0] = iCASE;
	iOpt[4] = iONLY;
	iOpt[5] = iRVS | iLCMP;
	return 0;
 Err:
/*
printf("_get_line_pat:Exit ret=%d\n",ret);
*/
	akxs_xlike_free(plike);
	*pplike = NULL;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
static int _gx_str_edit_like(ptext,len1,pat0,patlen0,c1,c2,code_type)
char **ptext,*pat0,c1,c2;
int len1,patlen0,code_type;
{
	tdtInfoParm pParm[2],*ppParm[2];
	tdtLike *plike;
	int iRc,patlen,iOpt[6],mpn,mpn0,iRVS,iLCMP,lenL,lenR;
	int pos[6],len[9],mflg,pos1;
	char *text,*p1[9],w1[128],*pat,*p,*ps,c;

	text = *ptext;
/*
printf("_gx_str_edit_like:Enter len1=%d text=[%s] patlen0=%d pat0=[%s] c2=[%c]\n",len1,text,patlen0,pat0,c2);
*/
	iRVS = iLCMP = 0;
	if (c1 == '%') iRVS = D_LINE_PAT_REVERSE;
	if (c2) iLCMP = D_LINE_PAT_LNGMATCH;

	mpn = 0;
	pat = pat0 + 1;
	patlen = patlen0;
	if ((c=*pat) == '*') {
		mpn = 2;
		pat0++;
	}
	else if (c == '^') {
		pat0++;
	}
	else {
		*pat0 = '*';
		patlen++;
	}
	if ((c=*(pat+patlen0-1)) == '*') mpn += 1;
	else if (c != '$') {
		strcat(pat0,"*");
		patlen++;
	}

	if (!(pat=cl_tmp_const_malloc(patlen*2+3))) return ECL_MALLOC_ERROR;
	patlen = _rep_wildcard(pat,pat0,patlen,'\0',code_type);
/*
printf("_gx_str_edit_like: patlen=%d pat=[%s] mpn=%d\n",patlen,pat,mpn);
*/
	mflg = 0;
	cl_set_parm_char(&pParm[0],text,len1);
	cl_set_parm_char(&pParm[1],pat,patlen);
	ppParm[0] = &pParm[0];
	ppParm[1] = &pParm[1];
	p1[0] = w1;
	plike = NULL;
	if (iRc=_get_line_pat(2,ppParm,p1,len,iOpt,&plike,3|iRVS|iLCMP)) return iRc;
/*
printf("_gx_str_edit_like: len=%d %d %d %d %d %d %d\n",len[0],len[1],len[2],len[3],len[4],len[5],len[6]);
*/
	patlen = len[4];
	pat = p1[4];
/*
printf("_gx_str_edit_like: patlen=%d pat=[%s] c2=[%c]\n",patlen,pat,c2);
*/
	c2 = '\0';
	memset(pos,0,sizeof(int)*4);
	if (patlen > 0) {
		/* 2022.3.28 */
		if ((iRc=akxs_xlike_set_pat(plike,pat,patlen)) < 0) goto Err;
		while (len1 > 0) {
/*
printf("_gx_str_edit_like: p1[0]=[%s] len[0]=%d\n",p1[0],len[0]);
*/
			if (!(iRc=akxs_pxlike(plike,pos))) {
/*
printf("_gx_str_edit_like: pos=%d %d %d %d\n",pos[0],pos[1],pos[2],pos[3]);
*/
				if (!c2 || !mpn) break;
			}
			else {
				if (iRc > 0) iRc = 0;
				break;
			}
		}
		if (!iRc) {
			if (mflg) {
				pos[0] = pos[2];
				pos[1] = pos[3];
			}
			ps = p1[0];
			mpn0 = mpn;
			if (c1=='%' && mpn) {
				mpn = 3 - mpn;
			}
			if (mpn == 2) {
				pos1 = pos[0] + pos[1];
				len1 -= pos1;
				ps += pos1;
			}
			else if (mpn == 1) {
				len1 = pos[0];
				if (c1=='%' && mpn0==1) len1--;
			}
/*
printf("_gx_str_edit_like: mpn=%d ps=%d len1=%d\n",mpn,ps,len1);
*/
			if (p=cl_tmp_const_malloc(len1+1)) {
				if (mpn) {
					if (iRVS) cmn_mrzcpy(p,ps,len1);
					else memzcpy(p,ps,len1);
				}
				else {
					pos1 = pos[0] + pos[1];
					lenL = pos[0];
					lenR = len1 - pos1;
					len1 = lenL + lenR;
/*
printf("_gx_str_edit_like: pos1=%d lenL=%d lenR=%d len1=%d\n",pos1,lenL,lenR,len1);
*/
					if (iRVS) {
						memzcpy(ps+lenL,ps+pos1,lenR);
						cmn_mrzcpy(p,ps,len1);
					}
					else {
						memzcpy(p,ps,lenL);
						memzcpy(p+lenL,ps+pos1,lenR);
					}
				}
				*ptext = p;
				iRc = len1;
			}
			else iRc = ECL_MALLOC_ERROR;
		}
	}
 Err:
	akxs_xlike_free(plike);
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_str_edit(pInfoParmW,pInfoParm1,pat0,patlen)
tdtInfoParm *pInfoParmW,*pInfoParm1;
char *pat0;
int patlen;
{
	char *p1,c,c2,*pat,*p,cmd;
	int rc,len1,i,len,posa[6],lena[7],code_type;
	tdtInfoParm pParm[5],*ppParm[5];
/*
printf("cl_gx_str_edit:Enter patlen=%d pat0=[%s]\n",patlen,pat0);
*/
	if (patlen >= 2) {
		p1 = NULL;
		if ((len1=parm_to_char(pInfoParm1,&p1,NULL)) < 0) return len1;
		code_type = pInfoParm1->pi_code;
		c2 = c = '\0';
		patlen--;
		c = *pat0++;
		if (c=='s' || c=='S') {
			cmd = c;
		}
		else {
			cmd = '\0';
			c2 = *pat0;
			if (c == c2) {
				if (patlen < 2) {
					return ECL_SYNTAX_ERROR;
				}
				pat0++;
				patlen--;
			}
			else c2 = '\0';
		}
		if (c=='%' || c=='#') {
			if (!(pat=cl_tmp_const_malloc(patlen+3))) return ECL_MALLOC_ERROR;
			memzcpy(pat+1,pat0,patlen);
			len1 = _gx_str_edit_like(&p1,len1,pat,patlen,c,c2,code_type);
/*
printf("cl_gx_str_edit: len1=%d p1=[%s]\n",len1,p1);
*/
		}
		else if (c=='/' || cmd) {
			if (c == '/') {
				if (!(pat=cl_tmp_const_malloc(patlen*2+3))) return ECL_MALLOC_ERROR;
				patlen = _rep_wildcard(pat,pat0,patlen,cmd,code_type);
			}
			else pat = pat0;
			if ((len1=_gx_str_rep(&p1,len1,pat,patlen,c2,cmd,code_type)) < 0) return len1;
		}
	}
	else {
		p1 = NULL;
		len1 = 0;
	}
	cl_set_parm_char2(pInfoParmW,p1,len1,code_type);
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_replace(pAns,nparm,ppParm)
char **pAns;
int  nparm;
tdtInfoParm **ppParm;
{
	int ret,shift,posa[2],old_len,m,pat_len,i_yen,lena[9],opt,d_len,i,len1,rem;
	int code_type1,code_type2,iM1;
	char *old_str,*pat,*p,c,w1[128],*pa[7],*p0;
	tdtInfoParm *pInfoParm,tInfoParm;

	code_type1 = cl_get_char_code_type(ppParm[0],1);
	iM1 = cl_is_mbyte(ppParm[0],code_type1);
	pa[0] = w1;
	pa[1] = pa[0] + 32;
	shift = _get_text_str_pos(nparm,ppParm,pa,lena,9);
/*
printf("cl_replace: shift=%d lena[0]=%d lena[5]=%d lena[6]=%d lena[7]=%d\n",shift,lena[0],lena[5],lena[6],lena[7]);
*/
	if (nparm < shift+3) {
		return ECL_FEW_PARAMETER;
	}
	code_type2 = cl_get_char_code_type(ppParm[shift+1],1);
	iM1 |= cl_is_mbyte(ppParm[shift+1],code_type2);
	if (iM1 && akxq_code_type_cmp(code_type1,code_type2)) {
		ERROROUT3(FORMAT(648),"cl_replace",code_type1,code_type2);	/* %s: �����R�[�h���قȂ��Ă��܂��B��1=%d ��2=%d */
		return ECL_SCRIPT_ERROR;
	}
	if ((ret=_get_pat_rep(nparm,ppParm,pa,lena,4,shift)) < 0) return ret;
	for (i=0;i<nparm-shift;i++) {
		if (!pa[i]) return -1;
/*
printf("cl_replace: lena[%d]=%d pa[%d]=[%s]\n",i,lena[i],i,pa[i]);
*/
	}
	if (p=pa[3]) {
		opt = 0;
		if (inistr(p,"i")) opt |= 0x01;
		if (inistr(p,"z")) opt |= 0x20;
		if (inistr(p,"k")) opt |= 0x4000;
	}
	else opt = lena[3];

  if (!(opt & 0x4000)) {
	d_len = lena[0] + 1;
	if (lena[1]>0 && lena[2]>lena[1]) {
		d_len = (lena[0]/lena[1]+1)*lena[2] + 1;
	}
	len1 = lena[7] + lena[0];
	d_len += len1 + lena[5];
/*
printf("cl_replace: d_len=%d\n",d_len);
*/
	if (!(p0 = cl_tmp_const_malloc(d_len+3))) return ECL_MALLOC_ERROR;
	p = p0;
	p = cl_set_type_to_string(p,d_len,code_type1);
	if (lena[7]) {
		memcpy(p,pa[5],lena[7]);
		p += lena[7];
	}
	opt |= SET_TYPE_OPT(code_type1);
	ret = akxcreplace_opt2(p,d_len,pa[0],lena[0],pa[1],pa[2],opt);
	if (ret >= 0) {
		d_len = ret;
		rem = lena[5] - len1;
/*
printf("cl_replace: d_len=%d rem=%d len1=%d\n",d_len,rem,len1);
*/
		if (rem > 0) memzcpy(p+d_len,pa[5]+len1,rem);
		ret = 0;
	}
	*pAns = p0;
  }
  else {
	pInfoParm = ppParm[shift+1];
	if ((old_len=parm_to_char_tmp(pInfoParm,&old_str,0)) < 0) return old_len;
	if (!(pat = cl_tmp_const_malloc(old_len+old_len+1))) return ECL_MALLOC_ERROR;
	p = pat;
	pat_len = m = i_yen = 0;
	while (old_len > 0) {
		m = akxqmbsnlen(code_type1,old_str,old_len);
		if (m == 1) {
			if ((c=*old_str)=='%' || c=='_'/* || c=='\\'*/) {
				*p++ = '\\';
				pat_len++;
				i_yen = 1;
			}
			*p++ = c;
		}
		else {
			memcpy(p,old_str,m);
			p += m;
		}
		pat_len += m;
		old_str += m;
		old_len -= m;
	}
	if (i_yen) {
		*p = '\0';
/*
printf("cl_replace: pat_len=%d pat=[%s]\n",pat_len,pat);
*/
		cl_set_parm_char2(&tInfoParm,pat,pat_len,code_type1);
		ppParm[shift+1] = &tInfoParm;
	}
	ret = cl_rep_like(pAns,nparm,ppParm);
	ppParm[shift+1] = pInfoParm;
  }
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_repchar(pAns,nparm,ppParm)
char **pAns;
int  nparm;
tdtInfoParm **ppParm;
{
	int ret,shift,posa[3],old_len,m,pat_len,code_type1,code_type2,dtlen,iM1,iM2;
	char *old_str,*p,c,pat[6];
	tdtInfoParm *pInfo1,*pInfo2,tInfo1,tInfo2;
	ParList2 par2;

	pInfo1 = ppParm[0];
	code_type1 = cl_get_char_code_type(pInfo1,1);
	iM1 = cl_is_mbyte(pInfo1,code_type1);
	shift = _get_parm_str_pos(nparm,ppParm,posa);
	if (nparm < shift+3) {
		return ECL_FEW_PARAMETER;
	}
	pInfo2 = ppParm[shift+1];
	code_type1 = cl_get_char_code_type(pInfo2,1);
	iM2 = cl_is_mbyte(pInfo2,code_type2);
	if ((iM1 | iM2) && akxq_code_type_cmp(code_type1,code_type2)) {
		ERROROUT3(FORMAT(648),"cl_repchar",code_type1,code_type2);	/* %s: �����R�[�h���قȂ��Ă��܂��B��1=%d ��2=%d */
		return ECL_SCRIPT_ERROR;
	}
	ppParm[shift+1] = &tInfo2;
	if ((old_len=parm_to_char_tmp(pInfo2,&old_str,0)) < 0) return old_len;
	while (old_len > 0) {
		m = akxqmbsnlen(code_type1,old_str,old_len);
		p = pat;
		pat_len = m;
		if (m == 1) {
			if ((c=*old_str)=='\\') {
				*p++ = c;
				old_str++;
				old_len--;
				m = akxqmbsnlen(code_type1,old_str,old_len);
				pat_len += m;
			}
		}
		memzcpy(p,old_str,m);
/*
printf("cl_repchar: pat_len=%d pat=[%s]\n",pat_len,pat);
*/
		cl_set_parm_char2(&tInfo2,pat,pat_len,code_type1);
		if ((ret=cl_replace(pAns,nparm,ppParm)) < 0) break;
		if (p = *pAns) {
			dtlen = strlen(p);
			if ((ret=cl_sep_string_with_type(&par2,p,dtlen)) > 0) {
				code_type1 = par2.option;
				p = par2.par;
				dtlen = par2.parlen;
			}
/*
printf("cl_repchar: *pAns=[%s]\n",p);
*/
			cl_set_parm_char2(&tInfo1,p,dtlen,code_type1);
			ppParm[0] = &tInfo1;
			old_str += m;
			old_len -= m;
		}
		else {
			ret = ECL_SYNTAX_ERROR;
			break;
		}
	}
	ppParm[shift+1] = pInfo2;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_repstrs(pAns,nparm,ppParm)
char **pAns;
int  nparm;
tdtInfoParm **ppParm;
{
	int ret,shift,posa[3],i,code_type1,code_type2,dtlen;
	char *p;
	tdtInfoParm tInfo1,*pParm[6];
	ParList2 par2;

	code_type1 = cl_get_char_code_type(ppParm[0],1);
	shift = _get_parm_str_pos(nparm-1,ppParm+1,posa);
/*
printf("cl_repstrs: shift=%d\n",shift);
*/
	if (nparm < shift+4) {
		return ECL_FEW_PARAMETER;
	}
	mem_cpy_addr(pParm,ppParm+1,shift+1);
	pParm[shift+2] = ppParm[nparm-1];
	pParm[shift+3] = ppParm[0];
	for (i=0;i<nparm-(shift+3);i++) {
		pParm[shift+1] = ppParm[shift+2+i];
		if ((ret=cl_replace(pAns,shift+4,pParm)) < 0) break;
		if (p = *pAns) {
			dtlen = strlen(p);
			if ((ret=cl_sep_string_with_type(&par2,p,dtlen)) > 0) {
				code_type1 = par2.option;
				p = par2.par;
				dtlen = par2.parlen;
			}
/*
printf("cl_repstrs: pAns=[%s]\n",p);
*/
			cl_set_parm_char2(&tInfo1,p,dtlen,code_type1);
			pParm[0] = &tInfo1;
		}
		else {
			ret = ECL_SYNTAX_ERROR;
			break;
		}
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_rep_like(pAns,nparm,ppParm)
char **pAns;
int  nparm;
tdtInfoParm **ppParm;
{
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	tdtLike *plike;
	int  iCASE,iG,iTOP,iBTM,pos[6],sp,iONLY,iOpt[6];
	int  i,n,ret,opt,len[9],is,patlen,ll;
	char w1[128],*p1[9],*p,*pat,*plen1,*pp,*plen2,c,c1,c2;
	uchar *pesc,escape;

	*pAns = NULL;
	plike = NULL;
	p1[0] = w1;
	if (ret=_get_line_pat(nparm,ppParm,p1,len,iOpt,&plike,4)) return ret;
/*
printf("cl_rep_like: len[0]=%d p1[0]=[%s] len[4]=%d p1[4]=[%s]\n",len[0],p1[0],len[4],p1[4]);
printf("cl_rep_like: len[1]=%d p1[1]=[%s]\n",len[1],p1[1]);
*/
	if (!len[1]) {
		ll = len[0];
		pp = p1[0];
		goto end;
	}
	pat = p1[4];
	patlen = len[4];
	iG    = iOpt[1];
	iTOP  = iOpt[2];
	iBTM  = iOpt[3];
	iONLY = iOpt[4];
	memset(pos,0,sizeof(pos));
	is = sp = 0;
	mcat.mc_ipos = 0;
	if (!(cl_get_option(18,0) & 0x04) && !iONLY && len[7]>0) {
/*
printf("cl_rep_like: len[7]=%d p1[5]=[%s]\n",len[7],p1[5]);
*/
		if ((ret=akxtmcat(&mcat,p1[5],len[7]))<0) goto err;
	}
	if (patlen == 0) {
		if (iTOP) {
			if ((ret=akxtmcat(&mcat,p1[2],len[2]))<0) goto err;
		}
		if ((ret=akxtmcat(&mcat,p1[0],len[0]))<0) goto err;
		if (iBTM) {
			if ((ret=akxtmcat(&mcat,p1[2],len[2]))<0) goto err;
		}
	}
	else {
#if 1	/* 2022.3.26 */
		if ((ret=akxs_xlike_set_pat(plike,pat,patlen)) < 0) goto err;
#endif
		while (sp < plike->lk_la) {
			ret = akxs_pxlike(plike,pos);
			if (!ret) {
/*
printf("cl_rep_like: is=%d pos=%d %d %d %d\n",is,pos[0],pos[1],pos[2],pos[3]);
*/
				if (iONLY) {
					if ((ret=akxtmcat(&mcat,p1[0]+pos[0],pos[1]))<0) goto err;
				}
				else {
					if ((ret=akxtmcat(&mcat,p1[0]+is,pos[0]-is))<0) goto err;
					if ((ret=akxtmcat(&mcat,p1[2],len[2]))<0) goto err;
				}
				is = pos[0] + pos[1];
				if (iG) sp = pos[2] + pos[3];
				else break;
			}
			else {
				if (ret < 0) goto err;
				break;
			}
		}
		if (!iONLY) {
/*
printf("cl_rep_like: len[5]=%d p1[0]+is=[%s] is=%d\n",len[5],p1[0]+is,is);
*/
			if ((ret=akxtmcat(&mcat,p1[0]+is,len[5]-is))<0) goto err;
		}
	}
	ret = 0;
	ll = mcat.mc_ipos;
	pp = mcat.mc_bufp;
 end:
	if (ll > 0) {
		if (p = cl_tmp_const_malloc(ll+1)) {
			memzcpy(p,pp,ll);
/*
printf("cl_rep_like: ll=%d p=[%s]\n",ll,p);
*/
			*pAns = p;
		}
		else ret = -1;
	}
 err:
/*
printf("cl_rep_like:Exit ret=%d\n",ret);
*/
	akxs_xlike_free(plike);
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_shsbs(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm **ppParm;
{
	tdtInfoParm tInfoParm,*pInfoParm,*pInfo;
	int ret,pos0[2],len1,shift,code_type,code_pat,m,iM1;
	char *pcmd,*pat,c,sep,cmd,*perr,*p1;

	pInfoParm = ppParm[0];
	code_type = cl_get_char_code_type(pInfoParm,1);
	iM1 = cl_is_mbyte(pInfoParm,code_type);
	/* 2022.3.17 */
	if ((shift=_get_text_str_pos(nparm,ppParm,&p1,&len1,1)) < 0) return shift;
	pInfoParm = &tInfoParm;
	cl_set_parm_char2(pInfoParm,p1,len1,code_type);

	cmd = '\0';
	perr = NULL;
	pat = NULL;
	if ((ret=parm_to_char(pInfo=ppParm[shift+1],&pat,NULL)) > 0) {
		code_pat = cl_get_char_code_type(pInfo,1);
		iM1 |= cl_is_mbyte(pInfo,code_pat);
		if (iM1 && akxq_code_type_cmp(code_type,code_pat)) {
			ERROROUT3(FORMAT(648),"cl_shsbs",code_type,code_pat);	/* %s: �����R�[�h���قȂ��Ă��܂��B��1=%d ��2=%d */
			return ECL_SCRIPT_ERROR;
		}
		m = akxqmbsnlen(code_pat,pat,ret);
		if (m == 1) ret = akxtstrim(SET_TYPE_OPT(code_pat),pat,ret,AKX_TRIM_SPACE2);
	}
	if (ret > 0) {
		if (m==1 && ((c=*pat)=='%' || c=='#' || c=='/' || c=='s' || c=='S')) {
			ret = cl_gx_str_edit(pInfoParmW,pInfoParm,pat,ret);
		}
		else {
			if (!perr) perr = pat;
			ERROROUT2(FORMAT(628),"cl_shsbs",perr);	/* %s: �ҏW�w��[%s]������Ă��܂��B*/
			ret = ECL_SYNTAX_ERROR;
		}
	}
	else if (!ret) {
		ERROROUT1(FORMAT(629),"cl_shsbs");	/* %s: �ҏW�w�肪��ł��B*/
		return ECL_SYNTAX_ERROR;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_glip_grep(pInfoParmW,nparm,ppParm,iLIKE)
tdtInfoParm *pInfoParmW;
int  nparm,iLIKE;
tdtInfoParm **ppParm;
{
	static char *pnama[]={"OPT"};
	MCAT mcat;
	tdtInfoParm tInfoParm,*pInfoParm,*pParmW[1];
	int ret,pos0[2],lena[9],shift,len1,optw,opt,iOpt[6],patlen,atr;
	int i,i1,k,len,posa[3],posa1[4],ii,lenw,i_min,i_max,iOPT,max_layer,i_elm;
	char *pcmd,*pat,c,sep,cmd,escape,*pa[9],*p1,*p,*pp;
	tdtLike *plike, **plikea;
	regex_t *preg,**prega;
	char errbuf[256];
	int errcode,flags[2];
	long lVal1;
	tdtIterate_ctl tIter_ctl;
	tdtIterate *pIter;

	cl_null_char(pInfoParmW);
	memset(&mcat,0,sizeof(MCAT));
	mcat.mc_extlen = 256;
	iOPT = opt = 0;
	pParmW[0] = NULL;
	if ((ret=cl_get_pname_info(nparm,ppParm,pParmW,pnama,1)) > 0) {
		pInfoParm = pParmW[0];
		if (pInfoParm->pi_id == ' ') {
			if ((atr=pInfoParm->pi_attr) == DEF_ZOK_CHAR) {
				p1 = NULL;
				if ((ret=parm_to_char(pParmW[0],&p1,NULL)) < 0) return ret;
				opt = _get_opt_replike(p1,ret);
			}
			else /*if ((atr=pInfoParm->pi_attr) == DEF_ZOK_BINA)*/ {
				if ((ret=cl_get_parm_long(pParmW[0],&lVal1,"opt:")) < 0) return ret;
				opt = lVal1;
			}
		}
		iOPT = 1;
/*
printf("cl_glip_grep: opt=%08x\n",opt);
*/
	}
#if 1	/* 2022.10.20 */
	if ((i1=_get_pos_text(nparm,ppParm)) < 0) return i1;
	else if (!i1) {
		ERROROUT2(FORMAT(76),"cl_glip_grep","text");		/* %s: %s������܂���B*/
		return ECL_SCRIPT_ERROR;
	}
	i1--;
#endif
	/* 2022.10.24 */
	max_layer = -1;
	if ((ret=cl_iterate_info_init(&tIter_ctl,NULL,ppParm[i1],max_layer)) < 0) return ret;
	/*
	   �w�肪����΁Astart,len���擾����
	*/
	if ((shift=_get_parm_str_pos(nparm-i1,&ppParm[i1],posa)) < 0) return shift;
/*
printf("cl_glip_grep: shift=%d posa[0]=%d posa[1]=%d len1=%d p1=[%s]\n",shift,posa[0],posa[1],len1,p1);
*/
	/*
	   �w�肪����΁Aoption���擾����
	*/
	if (!iOPT) {
		if (shift < nparm-1) {
			nparm = _get_nparm_opt(nparm,ppParm,&optw);
/*
printf("cl_glip_grep: optw=%08x\n",optw);
*/
			opt = optw;
		}
	}
/*	k = nparm - shift;	*/
	i1 += posa[2];
	k = nparm - i1 + 1;
/*
printf("cl_glip_grep: i1=%d k=%d p1=[%s]\n",i1,k,p1);
*/
	if (iLIKE) {
		/*
		   �p�^�[���̉�͌��ʂ�ۑ�����LIKE�\���̂ւ̃|�C���^����m�ۂ���
		*/
		if (!(plikea = (tdtLike **)cl_tmp_const_malloc(sizeof(tdtLike *)*k))) return ECL_MALLOC_ERROR;
	}
	else {
		/*
		   �p�^�[���̉�͌��ʂ�ۑ�����regex_t�\���̂Ƃ���ւ̃|�C���^����m�ۂ���
		*/
		if (!(prega = (regex_t **)cl_tmp_const_malloc(sizeof(regex_t *)*k))) return ECL_MALLOC_ERROR;
		if (!(preg = (regex_t *)cl_tmp_const_malloc(sizeof(regex_t)*k))) return ECL_MALLOC_ERROR;
		flags[0] = flags[1] = 0;
		flags[0] = REG_EXTENDED;
		if (opt & 0x01) flags[0] |= REG_ICASE;
	}
/*	i1 = shift + 1;	*/
	k = 0;
	/*
	   �p�^�[�������o���A��͌��ʂ�ۑ�����
	*/
	for (i=i1;i<nparm;i++) {
		pInfoParm = ppParm[i];
		if (pInfoParm->pi_id == D_DATA_ID_PNAME) continue;
		if ((patlen=parm_to_char_tmp(pInfoParm,&pat,0)) < 0) return patlen;
		if (iLIKE) {
			mem_set_int(iOpt,0,6);
			escape = '\0';
			ret = _get_edit_rep_pat(pat,patlen,escape,iOpt,pa,lena);
/*
printf("cl_glip_grep: k=%d len1=%d p1=[%s]\n",k,lena[4],pa[4]);
*/
			if (!(plike = akxs_xlike_new(0,opt))) return -1;
			if ((ret=akxs_xlike_set_pat(plike,pa[4],lena[4])) < 0) break;
			plikea[k++] = plike;
		}
		else {
			prega[k++] = preg;
			if (errcode = regcomp(preg,pat,flags[0])) {
				ret = -1;
				goto Err;
			}
/*
printf("cl_glip_grep: regcomp k=%d preg=%08x errcode=%d\n",k,preg,errcode);
*/
			preg++;
		}
	}
	if (iLIKE) {
		/*
		   �Ώۃf�[�^�pLIKE�\���̂��쐬����
		*/
		if (!(plike = akxs_xlike_new(0,opt))) return -1;
	}

#if 1	/* 2022.10.24 */
  i_elm = 1;
  for (;;) {
	if ((ret=cl_iterate_info(&tIter_ctl)) < 0) break;
	pIter = tIter_ctl.itc_pIter;
	if (!pIter->it_pInfo) break;
	p1 = NULL;
	if ((len1=parm_to_char(pIter->it_pInfo,&p1,NULL)) < 0) {
		ret = len1;
		break;
	}
#endif
	p = p1;
	len = len1;
	i_min = posa[0];
	i_max = i_min + posa[1] - 1;
/*
printf("cl_glip_grep: i_min=%d i_max=%d\n",i_min,i_max);
*/
#if 1	/* 2022.10.24 */
	if (opt & 0x200) {
		if (i_elm < i_min) len1 = 0;	/* ���̗v�f�̓X�L�b�v���� */
		else if (i_elm > i_max) break;
		i_elm++;
	}
#endif
	ii = 1;
	while (len1 > 0) {
		len = akxnskipto(p,len1,"\r\n");	/* ���s�R�[�h�܂ł̒���(byte)�����߂� */
/*
printf("cl_glip_grep: len=%d p=[%s]\n",len,p);
*/
		if (len > 0) {
			lenw = len;
			/* �܂��A�s�S�̂��T�[�`�ΏۂƂ��� */
			posa1[0] = 0;
			posa1[1] = len;
			if (opt & 0x100) {
				if (ii < i_min)  lenw = 0;	/* ���̍s�̓X�L�b�v���� */
				else if (ii > i_max) break;
			}
#if 1	/* 2022.10.24 */
			else if (!(opt & 0x200)) {
#else
			else {
#endif
				/* start,len�ɑ΂���Ώۃf�[�^�̃o�C�g�l�����߂� */
				_get_str_pos_posb(p,len,posa,posa1);
/*
printf("cl_glip_grep: posa1=%d %d %d %d\n",posa1[0],posa1[1],posa1[2],posa1[3]);
*/
			}
			if (lenw > 0) {
				p1 = p + posa1[0];
				pp = p1 + posa1[1];
				c = *pp;
				*pp = '\0';		/* ����́Aregexec()�p */
				if (iLIKE) {
					/* �Ώۃf�[�^�̃T�[�`�͈͂�LIKE�p�ɐݒ肷�� */
					if ((ret=akxs_xlike_set_line(plike,p1,posa1[1])) < 0) break;
				}
				/* �p�^�[����͌��ʂ�߂��Ȃ���p�^�[���}�b�`���O�����s���� */
				for (i=0;i<k;i++) {
					if (iLIKE) {
						plike->lk_maskctl = plikea[i]->lk_maskctl;
						ret = akxs_pxlike(plike,NULL);
					}
					else {
						errcode = regexec(prega[i],p1,0,NULL,flags[1]);
						if (errcode && errcode!=REG_NOMATCH) {
							ret = -2;
							goto Err;
						}
/*
printf("cl_glip_grep: regexec i=%d preg=%08x errcode=%d\n",i,preg,errcode);
*/
						ret = errcode;
					}
/*
printf("cl_glip_grep: i=%d ret=%d\n",i,ret);
*/
					if (!ret) {
						*pp = c;	/* ��������Ȃ��ƁA�����Ńf�[�^���؂�� */
						/* �ԋp����s�f�[�^�Ԃɂ́A���s������ */
						if (mcat.mc_ipos > 0) akxtmcats(&mcat,"\n");
						akxtmcat(&mcat,p,len);
						break;
					}
					ret = 0;
				}
				*pp = c;	/* ��������Ȃ��ƁA���s�R�[�h���X�L�b�v�ł����ɖ������[�v */
			}
			p += len;
			len1 -= len;
		}
		if ((len=akxnskipin(p,len1,"\r\n")) > 0) {	/* ���s�R�[�h�̒��������߂� */
/*
printf("cl_glip_grep: CrLf len=%d\n",len);
*/
			p += len;
			len1 -= len;
		}
		ii++;
	}
#if 1	/* 2022.10.24 */
  }
#endif
	if ((len=mcat.mc_ipos) > 0) {
/*
printf("cl_glip_grep: mc_ipos=%d mc_bufp=[%s]\n",len,mcat.mc_bufp);
*/
		/* mcat.mc_bufp�́AFree()����̂ŁAtmp��ɃR�s�[���ĕԋp���� */
		if (p = cl_tmp_const_malloc(len+1)) {
			memzcpy(p,mcat.mc_bufp,len);
			cl_set_parm_char(pInfoParmW,p,len);
		}
		else ret = ECL_MALLOC_ERROR;
	}
	if (p=mcat.mc_bufp) Free(p);
	if (iLIKE) {
		akxs_xlike_free(plike);
		for (i=0;i<k;i++) Free(plikea[i]);
	}
	return ret;
Err:
/*
printf("cl_glip_grep: k=%d i=%d preg=%08x errcode=%d\n",k,i,preg,errcode);
*/
	regerror(errcode,preg,errbuf,sizeof(errbuf));
	ERROROUT1(FORMAT(244),errbuf);	/* REGEX: %s */
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_glip(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm **ppParm;
{
	return cl_glip_grep(pInfoParmW,nparm,ppParm,1);
}

/****************************************/
/*										*/
/****************************************/
int cl_grep(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm **ppParm;
{
	return cl_glip_grep(pInfoParmW,nparm,ppParm,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_in_like(pWork,mflg,nparm,ppParm)
char *pWork;
int  mflg;
int  nparm;
tdtInfoParm **ppParm;
{
/* INLIKE(pos,npos,line,pat,opt,escape)	*/
	tdtInfoParm *pInfoParm,rInfoParm;
	tdtInfoParm ***pTBL;
	tdtArrayIndex tIndex,*pIndex;
	int  *index;
	tdtLike *plike;
	int  iCASE,iG,iTOP,iBTM,iONLY,iOpt[6],iRVS;
	int  iRc,i,len[9],is,sp,patlen,pos[4],ix,maxargs,lenm,len0;
	char w1[128],*p1[9],*pat;

	iRc = 0;
	pInfoParm = ppParm[1];
	if ((i=pInfoParm->pi_dlen)>0) {
		if (iRc = cl_get_parm_bin(pInfoParm,&maxargs,"InLike.maxargs:")) return iRc;
		if (maxargs < 0) {
			/* max_pos(%d)���s���ł��B */
			ERROROUT1(FORMAT(289),maxargs);
			return -1;
		}
	}
	else maxargs = 1;
/*
printf("cl_in_like: maxargs=%d\n",maxargs);
*/
	pIndex = &tIndex;
	if (maxargs) {
		if (iRc=cl_get_ITBL_maxargs_ref(1,ppParm,&pIndex,&pTBL,0,0,0,0)) return iRc;
		index = pIndex->index;
	/*	ix = index[3];	*/
		ix = index[3] + 1;
		if (i > 0) {
			if (maxargs > index[1]/2) {
				/* max_pos(%d)���z��̌�/2(%d)�𒴂��Ă��܂��B�������܂����B */
				ERROROUT2(FORMAT(290),maxargs,index[1]/2);
				maxargs = index[1]/2;
			}
		}
		else maxargs = index[1]/2;
	}
	p1[0] = w1;
	plike = NULL;
	if (iRc=_get_line_pat(nparm-2,&ppParm[2],p1,len,iOpt,&plike,3)) return iRc;
	patlen = len[4];
	pat = p1[4];
	iG = iOpt[1];
	iRVS = iOpt[5] & AKX_LIKE_REVERSE;
/*
printf("cl_in_like: patlen=%d pat=%08x iG=%d iRVS=%02x\n",patlen,pat,iG,iRVS);
*/
	memset(pos,0,sizeof(pos));
	if (patlen == 0) {
		sp = plike->lk_la;
	}
	else {
		if (mflg) lenm = akxqmlen(p1[0],len[0]);
		else lenm = len[0];
#if 1	/* 2022.3.28 */
		if ((iRc=akxs_xlike_set_pat(plike,pat,patlen)) < 0) goto Err;
#endif
		sp = 0;
	}
	is = 0;
	while (sp < plike->lk_la) {
		if (patlen > 0) {
			if (iRc=akxs_pxlike(plike,pos)) {
				if (iRc < 0) goto Err;
				else break;
			}
/*
printf("cl_in_like: is=%d pos=%d %d %d %d\n",is,pos[0],pos[1],pos[2],pos[3]);
*/
		}
		if (is++ < maxargs) {
			if (mflg) {
				if (iRVS) len0 = lenm - (pos[2] + pos[3]) + 1;
				else len0 = pos[2] + 1;
				len[0] = len0;
				len[1] = pos[3];
			}
			else {
				if (iRVS) len0 = lenm - (pos[0] + pos[1]) + 1;
				else len0 = pos[0] + 1;
				len[0] = len0;
				len[1] = pos[1];
			}
			if (!(cl_get_option(18,0) & 0x02) && len[6]>1) len[0] += len[6] - 1;
			for (i=0;i<2;i++,ix++) {
				pInfoParm = cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,'s');
				if (pInfoParm) {
DEBUGOUT_InfoParm(194,"cl_in_like: i=%d ix=%d",pInfoParm,i,ix);
					cl_set_parm_bin(&rInfoParm,len[i]);
					if (iRc=cl_gx_rep_info_set(pInfoParm,&rInfoParm,1)) goto Err;
				}
				else {
					iRc = -1;
					goto Err;
				}
			}
		}
		if (iG) sp = pos[0] + pos[1];
		else break;
	}
	memcpy(pWork,&is,sizeof(int));
	iRc = 0;
 Err:
/*
printf("cl_in_like:Exit iRc=%d\n",iRc);
*/
	akxs_xlike_free(plike);
	return iRc;
}

/****************************************/
/*										*/
/* inba[] : ���͕�����̊e�����̃o�C�g����Ԃ��z��	*/
/****************************************/
int _pat_tozen2(n,inc,outc,inba,exchars)
int  n;
char *inc,*outc,*inba,*exchars;
{
	int  len1,i,byte,out_len,nn[3],tozen;
	char *p1,*p,*pb,c;
	uchar  uc,uc1;
	ushort us,usw;

	len1 = n;
	p1 = inc;
	p  = outc;
	pb = inba;
	out_len = 0;
	while (len1 > 0) {
		byte = akxqkanjilen2(p1,len1);
		tozen = 1;
		if (byte == 1) {
			if ((c=*p1) == '\\') {
			/*	if (outc) *p++ = c;	*/
				p1++;
				len1--;
			/*	out_len++;
				if (inba) *pb++ = 1;	*/
			/*	byte = akxqkanjilen2(p1,len1);	*/
			}
			else if (exchars) {
				if (instrchar(exchars,c) > 0) tozen = 0;
			}
		}
		if (tozen) byte = akxctozen1_type_opt(len1,p1,p,nn,0,0);
		else {
			if (outc) *p = *p1;
			nn[0] = 1;
		}
		if (outc) p += byte;
		p1 += nn[0];
		len1 -= nn[0];
		out_len += byte;
		if (inba) *pb++ = nn[0];
	}
	if (outc) *p = '\0';
	return out_len;
}

/****************************************/
/*										*/
/****************************************/
static int _get_regex_line_pat(nparm,ppParm,p1,len,pos_opt,iOpt,pinba)
int  nparm,len[],pos_opt,iOpt[];
tdtInfoParm **ppParm;
char *p1[],**pinba;
{
	static char *_fn="_get_regex_line_pat";
	int  iRc,patlen,pos0_opt,iCASE,iG,iHAZE,shift,n,opt_len,code_type;
	char *pat,*p,*pp,*patba,*inba;

	code_type = cl_get_char_code_type(ppParm[0],1);
	pos0_opt = pos_opt - 1;
	if ((shift=_get_text_str_pos(nparm,ppParm,p1,len,9)) < 0) return shift;
	if ((iRc=_get_pat_rep(nparm,ppParm,p1,len,pos_opt,shift)) < 0) return iRc;
	if (!len[1]) return 0;
	iCASE = iG = iHAZE = 0;
	if (p = p1[pos0_opt]) {
/*
printf("_get_regex_line_pat: p1[pos0_opt]=[%s]\n",p);
*/
		if (inistr(p,"i")) iCASE = AKX_LIKE_IGN_CASE;
		if (inistr(p,"g")) iG = 1;
#if 1
		opt_len = len[pos0_opt];
/*
printf("_get_regex_line_pat: opt_len=%d\n",opt_len);
*/
		if (akxnskipin(p,opt_len," \tiIgG") < opt_len) {
			ERROROUT2(FORMAT(630),_fn,"{i | g}");	/* %s: %s�ȊO�͎w��ł��܂���B*/
		}
#else
		if (inistr(p,"z")) iHAZE = AKX_LIKE_IGN_HAZE;
		iOpt[2] = iHAZE;
#endif
		iOpt[0] = iCASE;
		iOpt[1] = iG;
	}
	else if ((n=len[pos0_opt]) > 0) {
#if 1
		if (n & ~(AKX_LIKE_IGN_CASE | (D_LINE_PAT_GLOBAL>>8))) {
			ERROROUT2(FORMAT(630),_fn,"{0x01 | 0x04}");	/* %s: %s�ȊO�͎w��ł��܂���B*/
		}
		iG    = n & (D_LINE_PAT_GLOBAL>>8);
		iCASE = n & AKX_LIKE_IGN_CASE;
#else
		iONLY = n & (D_LINE_PAT_ONLY>>8);
		iCASE = n & (AKX_LIKE_IGN_CASE | AKX_LIKE_IGN_HAZE);
		iRVS  = n & AKX_LIKE_REVERSE;
		iLCMP = n & AKX_LIKE_LNGMATCH;
#endif
/*
printf("_get_line_pat: n=%08x iCASE=%d iG=%d iONLY=%d iLCMP=%02x iRVS=%02x\n",n,iCASE,iG,iONLY,iLCMP,iRVS);
*/
	}
#if 0
	if (iHAZE) {
		pat = p1[1];
		patlen = len[1];
#if 1	/* 2022.3.25 */
		if ((akxnskipto(pat,patlen,"(){}")>=patlen)) {
			if (!(p=cl_tmp_const_malloc(patlen*2+3))) return ECL_MALLOC_ERROR;
			len[1] = _rep_wildcard(p,pat,patlen,'s',code_type);
			p1[1] = p;
/*
cl_str_conv_put(&pp,p,len[1]);
printf("_get_regex_line_pat: pat=[%s]\n",pp);
if (pat != pp) Free(pp);
*/
			return shift | 0x10;
		}
#endif
		if (!(pat = cl_tmp_const_malloc(patlen*4+1))) return ECL_MALLOC_ERROR;
		if (!(patba = cl_tmp_const_malloc(patlen))) return ECL_MALLOC_ERROR;
		if ((iRc=_pat_tozen2(patlen,p1[1],pat,patba,".*[]^$!(){}")) < 0) return iRc;
		if (iCASE) {
			if (!(pp = cl_tmp_const_malloc(iRc+1))) return ECL_MALLOC_ERROR;
			if ((iRc=akxcuplwn(0,pp,pat,iRc)) < 0) return iRc;
			pat = pp;
		}
		len[1] = iRc;
		p1[1] = pat;
/*
cl_str_conv_put(&pp,pat,iRc);
printf("_get_regex_line_pat: pat=[%s]\n",pp);
if (pat != pp) Free(pp);
*/
		if (!(p = cl_tmp_const_malloc(len[0]*4+1))) return ECL_MALLOC_ERROR;
		if (!(inba = cl_tmp_const_malloc(len[0]))) return ECL_MALLOC_ERROR;
		if ((iRc=akxctozen2(len[0],p1[0],p,inba)) < 0) return iRc;
		if (iCASE) {
			if (!(pp = cl_tmp_const_malloc(iRc+1))) return ECL_MALLOC_ERROR;
			if ((iRc=akxcuplwn(0,pp,p,iRc)) < 0) return iRc;
			p = pp;
		}
		*pinba = inba;
		p1[0] = p;
		len[0] = iRc;
/*
cl_str_conv_put(&pp,p,iRc);
printf("_get_regex_line_pat: p=[%s]\n",pp);
if (p != pp) Free(pp);
*/
	}
#endif
	return shift;
}

/****************************************/
/*										*/
/****************************************/
int cl_in_regex(pWork,mflg,nparm,ppParm)
char *pWork;
int  mflg;
int  nparm;
tdtInfoParm **ppParm;
{
/* INREGEX(pos,npos,line,pat,opt,escape)	*/
	tdtInfoParm *pInfoParm,rInfoParm,*ppParm2[7];
	tdtInfoParm ***pTBL;
	tdtArrayIndex tIndex,*pIndex;
	int  *index;
	tdtLike *plike;
	int  iCASE,iG,iHAZE,iOpt[6],flags[2],shift;
	int  iRc,i,len[8],k,is,patlen,pos0,pos1,pos2,ix,maxargs,lenm,len0,n,nn,j,pos_opt,pos0_opt;
	int  posm,byte1,byte2;
	char w1[128],*p1[7],*pat,errbuf[256],*p,*patba,*inba,*pp,*p0,*inb;
	regex_t reg;
	regmatch_t pmatch[2];
	tdtInfoParm tInfoParm;

	iRc = 0;
	pInfoParm = ppParm[1];
	if ((i=pInfoParm->pi_dlen)>0) {
		if (iRc = cl_get_parm_bin(pInfoParm,&maxargs,"InRegex.maxargs:")) return iRc;
		if (maxargs < 0) {
			/* max_pos(%d)���s���ł��B */
			ERROROUT1(FORMAT(289),maxargs);
			return -1;
		}
	}
	else maxargs = 1;
/*
printf("cl_in_like: maxargs=%d\n",maxargs);
*/
	is = 0;
	pIndex = &tIndex;
	if (maxargs) {
		if (iRc=cl_get_ITBL_maxargs_ref(1,ppParm,&pIndex,&pTBL,0,0,0,0)) return iRc;
		index = pIndex->index;
	/*	ix = index[3];	*/
		ix = index[3] + 1;
		if (i > 0) {
			if (maxargs > index[1]/2) {
					/* max_pos(%d)���z��̌�/2(%d)�𒴂��Ă��܂��B�������܂����B*/
				ERROROUT2(FORMAT(290),maxargs,index[1]/2);
				maxargs = index[1]/2;
			}
		}
		else maxargs = index[1]/2;
		if (maxargs > MAX_REGEX_MATCH) {
				/* %s: max_pos(%d)�������l(%d)�𒴂��Ă��܂��B�������܂����B*/
			ERROROUT2(FORMAT(205),maxargs,MAX_REGEX_MATCH);
			maxargs = MAX_REGEX_MATCH;
		}
	}
	else goto End;

	p1[0] = w1;
	p1[1] = p1[0] + 32;
	pos_opt = 3;
	if ((shift=_get_regex_line_pat(nparm-2,&ppParm[2],p1,len,pos_opt,iOpt,&inba)) < 0) return shift;
#if 0
	else if (shift & 0x10) {
		cl_set_parm_char(&tInfoParm,p1[1],len[1]);
		nparm = X_MIN(nparm,7);
		mem_cpy_addr(ppParm2,ppParm,nparm);
		ppParm2[(shift & 0x0f)+3] = &tInfoParm;
		return cl_in_like(pWork,mflg,nparm,ppParm2);
	}
#endif
	if (!len[1]) goto End;

	iCASE = iOpt[0];
	iG    = iOpt[1];
	iHAZE = iOpt[2];

	pat = p1[1];
	patlen = len[1];
	if (!iG) maxargs = 1;
	flags[0] = REG_EXTENDED | REG_NEWLINE;
	if (iCASE/* && !iHAZE*/) flags[0] |= REG_ICASE;
	flags[1] = 0;
/*
printf("cl_in_regex: p1[0]=[%s] pat=[%s] maxargs=%d\n",p1[0],pat,maxargs);
*/
	iRc = regcomp(&reg,pat,flags[0]);
	if (iRc) {
		regerror(iRc,&reg,errbuf,sizeof(errbuf));
		ERROROUT1(FORMAT(244),errbuf);	/* REGEX: %s */
		iRc = -1;
	}
	else {
		p0 = p1[0];
		p = p0;
		len[0] = 1;
		len[1] = pos0 = k = 0;
		inb = inba;
		while (k<maxargs) {
			iRc = regexec(&reg,p,2,pmatch,flags[1]);
			if (iRc) {
				if (iRc != REG_NOMATCH) {
					regerror(iRc,&reg,errbuf,sizeof(errbuf));
					ERROROUT1(FORMAT(244),errbuf);	/* REGEX: %s */
					iRc = -1;
				}
				break;
			}
			if ((pos1=pmatch[0].rm_so) < 0) break;
			pos2 = pmatch[0].rm_eo;
			lenm = len0 = pos2 - pos1;
/*
printf("cl_in_regex: k=%d pos1=%d pos2=%d\n",k,pos1,pos2);
*/
#if 0
			if (iHAZE) {
				lenm = akxqmlen(p+pos1,len0);
				posm = akxqmlen(p,pos1);
/*
printf("cl_in_regex: posm=%d lenm=%d\n",posm,lenm);
*/
				byte1 = mem_sum_byte(inb,posm);
				byte2 = mem_sum_byte(inb+posm,lenm);
/*
printf("cl_in_regex: byte1=%d byte2=%d\n",byte1,byte2);
*/
				inb += posm + lenm;
				pos1 = akxqmlen(p0,byte1) + len[0]-1 + len[1];
				lenm = akxqmlen(p0+byte1,byte2);
				p0 += byte1 + byte2;
			}
			else
#endif
			if (mflg) {
				lenm = akxqmlen(p+pos1,len0);
				pos1 = akxqmlen(p,pos1) + len[0]-1 + len[1];
			}
			else pos1 += pos0;
/*
printf("cl_in_regex: pos1=%d lenm=%d\n",pos1,lenm);
*/
			len[0] = pos1 + 1;
			len[1] = lenm;
			if (!(cl_get_option(18,0) & 0x02) && len[6]>1) len[0] += len[6] - 1;
			for (i=0;i<2;i++,ix++) {
				pInfoParm = cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,'s');
				if (pInfoParm) {
DEBUGOUT_InfoParm(194,"cl_in_regex: i=%d ix=%d",pInfoParm,i,ix);
					cl_set_parm_bin(&rInfoParm,len[i]);
					if ((iRc=cl_gx_rep_info_set(pInfoParm,&rInfoParm,1)) < 0) break;
				}
				else {
					iRc = -1;
					break;
				}
			}
			if (iRc < 0) break;
			is++;
			k++;
			p += pos2;
			pos0 = pos2;
		}
	}
	regfree(&reg);
 End:
	memcpy(pWork,&is,sizeof(int));
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
int cl_rep_regex(pAns,nparm,ppParm)
char **pAns;
int  nparm;
tdtInfoParm **ppParm;
{
/* REPREGEX(line,pat,rep,opt,escape)	*/
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	int  iCASE,iG,iHAZE,flags[2],shift,iOpt[3];
	int  iRc,len[7],pos0,pos1,pos2,lenm,n,nn,j,pos_opt,pos0_opt,ll,patlen;
	char w1[128],*p1[7],*pat,errbuf[256],*p,*pp,*inba;
	regex_t reg;
	regmatch_t pmatch[2];
	tdtInfoParm tInfoParm,*ppParm2[6];

	*pAns = NULL;
	iRc = 0;
	p1[0] = w1;
	p1[1] = p1[0] + 32;
	pos_opt = 4;
	if ((shift=_get_regex_line_pat(nparm,ppParm,p1,len,pos_opt,iOpt,&inba)) < 0) return shift;
#if 0
	else if (shift & 0x10) {
		cl_set_parm_char(&tInfoParm,p1[1],len[1]);
		nparm = X_MIN(nparm,6);
		mem_cpy_addr(ppParm2,ppParm,nparm);
		ppParm2[(shift & 0x0f)+1] = &tInfoParm;
		return cl_rep_like(pAns,nparm,ppParm2);
	}
#endif
	if (!len[1]) {
		ll = len[0];
		pp = p1[0];
		goto End;
	}
	iCASE = iOpt[0];
	iG    = iOpt[1];
	iHAZE = iOpt[2];

	pat = p1[1];
	patlen = len[1];
	flags[0] = REG_EXTENDED | REG_NEWLINE;
	if (iCASE/* && !iHAZE*/) flags[0] |= REG_ICASE;
	flags[1] = 0;
/*
printf("cl_rep_regex: p1[0]=[%s] pat=[%s]\n",p1[0],pat);
*/
	iRc = regcomp(&reg,pat,flags[0]);
	if (iRc) {
		regerror(iRc,&reg,errbuf,sizeof(errbuf));
		ERROROUT1(FORMAT(244),errbuf);	/* REGEX: %s */
		iRc = -1;
	}
	else {
/*
printf("cl_rep_regex: len[7]=%d p1[5]=[%s]\n",len[7],p1[5]);
*/
		mcat.mc_ipos = 0;
		if (!(cl_get_option(18,0) & 0x04) && len[7]>0) {
			if ((iRc=akxtmcat(&mcat,p1[5],len[7])) < 0) return iRc;
		}
		p = p1[0];
		lenm = len[0];
		pos0 = 0;
		while (pos0 < lenm) {
			iRc = regexec(&reg,p,2,pmatch,flags[1]);
			if (iRc) {
				if (iRc != REG_NOMATCH) {
					regerror(iRc,&reg,errbuf,sizeof(errbuf));
					ERROROUT1(FORMAT(244),errbuf);	/* REGEX: %s */
					iRc = -1;
				}
				break;
			}
			if ((pos1=pmatch[0].rm_so) < 0) break;
			pos2 = pmatch[0].rm_eo;
/*
printf("cl_rep_regex: pos1=%d pos2=%d\n",pos1,pos2);
*/
			if ((iRc=akxtmcat(&mcat,p,pos1)) < 0) break;
			if ((iRc=akxtmcat(&mcat,p1[2],len[2])) < 0) break;
			p += pos2;
			pos0 = pos2;
			if (!iG) break;
		}
		iRc = akxtmcat(&mcat,p,lenm-pos0);
	}
	regfree(&reg);
	if (iRc >= 0) {
		iRc = 0;
		ll = mcat.mc_ipos;
		pp = mcat.mc_bufp;
	}
 End:
	if (!iRc) {
		if (ll > 0) {
			if (p = cl_tmp_const_malloc(ll+1)) {
				memzcpy(p,pp,ll);
				*pAns = p;
			}
			else iRc = -1;
		}
	}
	return iRc;
}
