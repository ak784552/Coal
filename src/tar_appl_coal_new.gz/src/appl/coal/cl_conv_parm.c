static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �p�����[�^�ϊ�                                         *
*                                                                             *
*      �֐����@�@�@�F�@int cl_conv_parm( pparmList , pInfoParm )              *
*                      (I)prmList	*pparmList                                *
*                      (O)tdtInfoParm	*pInfoParm                            *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern int giOptions[];
extern CLPRTBL *pGLprocTable;
extern CLPRTBL *pCLprocTable;
extern GlobalCt  *pGlobTable;

static long lnull = 0;

/****************************************/
/*										*/
/****************************************/
static int _set_nest_var_name(pparmList, pInfoParm)
parmList   *pparmList;
tdtInfoParm *pInfoParm;
{
	int ret,vnlen;
	char *p,*vname;

	if (pInfoParm->pi_scale & D_DATA_ARRAY_INDEX) {	/* 0x10 */
		if (!(p=(char *)pInfoParm->pi_pos)) return ECL_SYSTEM_ERROR;
/*
printf("_set_nest_var_name: p=[%s] vnlen=%d vname=[%s]\n",
p,pparmList->prmlen,pparmList->prp);
*/
		if ((vnlen=pparmList->prmlen-strlen(p)-1) <= 0) return ECL_SYSTEM_ERROR;
		vname = pparmList->prp;
		if (!(p=cl_tmp_const_malloc(vnlen+Var_NM_MAX*2+1))) {
			ERROROUT("_set_nest_var_name: nest var name area malloc");
			return ECL_SYSTEM_ERROR;
		}
		strnzcpy(p,vname,vnlen);
		pInfoParm->pi_pos = (long)p;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_conv_parm(pparmList, pInfoParm)
parmList   *pparmList;
tdtInfoParm *pInfoParm;
{
	return cl_conv_parm_opt(pparmList, pInfoParm, 0);
}

/****************************************/
/*										*/
/****************************************/
int cl_conv_parm_opt(pparmList, pInfoParm, opti)
parmList   *pparmList;
tdtInfoParm *pInfoParm;
int opti;
{
	int	rc, alclen, opt, ret;
	int ParmNo;
	tdtInfoParm *pInfoParmW;
	ScrPrCT     *pScCT;
	char op,c,*p;
	ParList par_pSize;

	if (!pparmList) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return( ECL_SYSTEM_ERROR );
	}
	if (!pparmList->prp) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return( ECL_SYSTEM_ERROR );
	}
	if (!pInfoParm) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return ECL_SYSTEM_ERROR;
	}

DEBUGOUTL2(194,"--->cl_conv_parm_op: pparmList->prp=[%s] opti=%08x",pparmList->prp,opti);

	memset(pInfoParm,0,sizeof(tdtInfoParm));
	pScCT = cl_search_src_ct();
	opt = opti & D_GX_OPT_STORE;
	if (opt) op = 's';
	else {
		if (opti & D_GX_OPT_NOEROUT_NDEF) op = 'R';
		else op = 'r';
	}
	rc = cl_gx_get_info_parm_opt_psize(pScCT,op,pparmList,&pInfoParmW,opti,&par_pSize);

DEBUGOUT_InfoParm(194,"cl_conv_parm_opt:<---cl_gx_get_info_parm_opt_psize opt=%d rc=%d",
pInfoParmW,opt,rc);

	if (rc) {
		if (rc == ECL_DEFINED_ARRAY) {
			if (!pInfoParmW) return -1;
			if (ret=_set_nest_var_name(pparmList,pInfoParmW)) return ret;
		}
		else return rc;
	}
	if (opt || (opti & D_GX_OPT_SET_ADDR)) {
		/* 2024.9.28 */
		if (pInfoParmW->pi_id != 'S')
			cl_set_storevar(pInfoParm,pInfoParmW,1);
		else
			cl_gx_copy_info(pInfoParm,pInfoParmW);
		if (!(pInfoParm->pi_aux[1] & D_AUX1_POINTER)) {	/* add 2023.5.13 */
			/* 2024.02.23 */
			cl_set_pSize_index(pInfoParm,par_pSize.par,NULL,par_pSize.parlen,pInfoParmW->pi_paux);
		}
	}
	else {
		memcpy(pInfoParm,pInfoParmW,sizeof(tdtInfoParm));
		if ((c=pInfoParmW->pi_id) == 'A' || c == 'R') rc = ECL_DEFINED_ARRAY;
	}
DEBUGOUT_InfoParm(194,"cl_conv_parm_opt:Exit rc=%d",pInfoParm,rc,0);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_chk_vnam_info(opt,pha,name,nl,ppInfo)
char opt,*name;
int nl;
XHASHB *pha;
tdtInfoParm **ppInfo;
{
	char hakey[Var_NM_MAX*2+2];
	uchar aux1;
	int i;
	tdtInfoParm tInfo,*pInfo;

DEBUGOUTL4(194,"cl_gx_chk_vnam_info:Enter opt=%c pha=%08x name=[%s] nl=%d",opt,pha,name,nl);

	if (!pha) return 0;
#ifdef HASH_FIXED_KEYL  /* 2001.2.22 Koba */
	if (nl >= pha->xha_keylen) {
		memcpy(hakey,name,pha->xha_keylen);
	}
	else {
		memset(hakey,' ',pha->xha_keylen);
		memcpy(hakey,name,nl);
	}
	hakey[Var_NM_MAX] = '\0';
/*
ERROROUT3("opt=[%c] name=[%s] nl=%d",opt,name,nl);
*/
#else
	nl = memnzcpy(hakey,name,nl,sizeof(hakey));
#endif

DEBUGOUTL4(194,"cl_gx_chk_vnam_info: pha=%08x opt=%c nl=%d hakey=[%s]",pha,opt,nl,hakey);
/*
printf("cl_gx_chk_vnam_info: pha=%08x opt=%c nl=%d hakey=[%s] i=%d\n",pha,opt,nl,hakey,i);
*/
	pInfo = NULL;
	if (ppInfo) *ppInfo = pInfo;
	pha->xha_xhix = 0;
	/* 2023.4.28 */
	if (toupper(opt) == 'S') {
		if ((i=akxs_xhash2(pha,'R',hakey,&pInfo)) > 0) {
			pInfo->pi_aux[1] |= D_AUX1_HASHED_NAME;
			if (ppInfo) *ppInfo = pInfo;
		}
		else if (!i) {
			pInfo = &tInfo;
			if (cl_get_option(1,0) & 0x01) cl_null_char(pInfo);
			else cl_parm_set0(pInfo);
			if ((i=akxs_xhash2(pha,opt,hakey,pInfo))>0 && ppInfo) {
				if ((i=akxs_xhash2(pha,'R',hakey,&pInfo)) > 0) {
					pInfo->pi_aux[1] |= D_AUX1_HASHED_NAME;
					if (ppInfo) *ppInfo = pInfo;
				}
			}
		}
	}
	else if ((i=akxs_xhash2(pha,opt,hakey,&pInfo)) > 0) {
		pInfo->pi_aux[1] |= D_AUX1_HASHED_NAME;
		if (ppInfo) *ppInfo = pInfo;
	}
	/* 2023.9.20 */
	if (pInfo) {
		if (!pInfo->pi_id) {
			aux1 = pInfo->pi_aux[1];	/* 2025.8.7 add */
			if (cl_get_option(1,0) & 0x01) cl_null_char(pInfo);
			else cl_parm_set0(pInfo);
			pInfo->pi_aux[1] = aux1;	/* 2025.8.7 add */
		}
	}
/*
printf("cl_gx_chk_vnam_info:Exit opt=[%c] i=%d pInfo=%08x\n",opt,i,pInfo);
*/
DEBUGOUTL3(194,"cl_gx_chk_vnam_info:Exit opt=[%c] i=%d pInfo=%08x",opt,i,pInfo);
	return i;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_chk_vnam(opt,pha,name,nl)
char opt,*name;
int nl;
XHASHB *pha;
{
	return cl_gx_chk_vnam_info(opt,pha,name,nl,NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_vnam(pha,ix,ppnam)
XHASHB *pha;
int ix;
char **ppnam;
{
	int i;

	pha->xha_xhix = ix;
	i = akxs_xhash(pha,'P',ppnam);
	return i;
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_gx_setprm_list_g(name,len,opt)
char *name;
int len,opt;
{
	tdtInfoParm InfoParm,*pInfoParm;
	parmList pL;
	char buf[33],*p;

	*buf = '$';
	if (len>31) len = 31;
	memzcpy(buf+1,name,len);
	pL.prp = buf;
	pL.prmlen = len + 1;
	if (cl_conv_sysvar_opt(&pL,&InfoParm,opt)) return NULL;
	if (pInfoParm = (tdtInfoParm *)cl_const_malloc(sizeof(tdtInfoParm))) {
		if (cl_gx_rep_info_set_ign(pInfoParm ,&InfoParm ,0)) {
			pInfoParm = NULL;
		}
	}
	return pInfoParm;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_info_parm_opt(pScCT,opt,pparmList,ppInfoParm,iOpt)
ScrPrCT	  *pScCT;
char opt;
parmList  *pparmList;
tdtInfoParm **ppInfoParm;
int iOpt;
{
	return cl_gx_get_info_parm_opt_psize(pScCT,opt,pparmList,ppInfoParm,iOpt,NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_info_parm_opt_psize(pScCT,opt,pparmList,ppInfoParm,iOpt,ppar_pSize)
ScrPrCT *pScCT;
char opt;
parmList *pparmList;
tdtInfoParm **ppInfoParm;
int iOpt;
ParList *ppar_pSize;
{
	int ParmNo,rc,vnlen,pLlen,iLOCAL,ix,code_type;
	char c,*vname,*pLprp,data_id,*p;
	tdtInfoParm *pInfoParm,***pTBL_vnam;
	char varnam[Var_NM_MAX+1];
	tdtArrayIndex tIndex;
	ProcCT *proc;
	uchar ucLGopt;
	parmList tparmList;

	if (ppar_pSize) {
		ppar_pSize->par = NULL;
		ppar_pSize->parlen = 0;
	}
	if (!ppInfoParm) return -1;
	*ppInfoParm=NULL;
	pInfoParm=NULL;

	pLlen = pparmList->prmlen;
	pLprp = pparmList->prp;
	code_type = GET_TYPE_OPT(pparmList->opt);
	/* 2022.6.11 */
	if (!(rc=cl_skip_scope_mark(pLprp,pLlen,&ix))) ;
	else if (rc > 0) {
		iOpt |= ix;
		tparmList = *pparmList;
		pparmList = &tparmList;
		pLlen -= rc;
		pLprp += rc;
		pparmList->prmlen = pLlen;
		pparmList->prp = pLprp;
	}
	else  return rc;

DEBUGOUTL4(194,"--->cl_gx_get_info_parm_opt_psize: pScCT=%08x opt=%c name=[%s]",
pScCT,opt,pLprp,0);

	LOGBUF(strlen(pLprp)+128);
	if ((ParmNo=cl_gx_get_index_array(pparmList,varnam,&pInfoParm,iOpt)) < 0) {
		if (ParmNo == ECL_DEFINED_ARRAY) *ppInfoParm = pInfoParm;
				/* cl_gx_get_info_parm_opt:%s�̓p�����[�^�Ɍ�肪����܂��B */
		else if (!(iOpt & D_GX_OPT_NOEROUT_NDEF)) ERROROUT1(FORMAT(311),pLprp);
		return ParmNo;
	}

	c = *pLprp;
	if (ParmNo==0 && *varnam &&		/* �ϐ������z�񖼂��ǂ����̃`�F�b�N */
	    (c=='%' || c=='#')) {		/* �z�񖼂́A%,#�t���œo�^����Ă��� */
		ucLGopt = 0;
		rc = 0;
		proc = NULL;
		if (pScCT) proc = cl_search_proc_ct();
		rc = cl_gx_get_parm_no_info(pScCT,proc,pLprp,pLlen,'r',0,&pInfoParm);
DEBUGOUTL5(194,"<---cl_gx_get_info_parm_opt_psize.array: pScCT=%08x proc=%08x ParmNo=%d %s rc=%d",
pScCT,proc,ParmNo,pLprp,rc);
		if (rc > 0){
			/* �z�񖼂Ƃ��ēo�^����Ă��� */
			if (pInfoParm) {

DEBUGOUT_InfoParm(194,"cl_gx_get_info_parm_opt_psize.array: ",pInfoParm,0,0);

			/*	if (iLOCAL) pInfoParm->pi_aux[1] |= D_AUX1_LOCAL_VAR;	*/
				pInfoParm->pi_aux[1] |= D_AUX1_HASHED_NAME | ucLGopt;
				*ppInfoParm = pInfoParm;
				return 0;
			}
		}
		/* 2024.3.29 */
		else {
			ERROROUT1(FORMAT(151),pLprp);	/* �ϐ�(%s)�͖���`�ł��B*/
			return ECL_SCRIPT_ERROR;
		}
	}
	rc = cl_gx_get_all_var_ent_psize(pScCT,opt,pLprp,ppInfoParm,ParmNo,varnam,iOpt,ppar_pSize);
	if (!rc) {
		pInfoParm = *ppInfoParm;
		ix = akxnskipto(pLprp,pLlen,".");
		if (++ix < pLlen) {
			if (pInfoParm->pi_id=='T') {
				memnzcpy(varnam,pLprp+ix,pLlen-ix,sizeof(varnam));
				vnlen = pLlen-ix;
				if (rc=_ex_get_member(&pInfoParm,opt,pLprp+ix,pLlen-ix)) return rc;
				*ppInfoParm = pInfoParm;
			}
			else {
				/* cl_gx_get_info_parm_opt: [%s]�����o�[�͎w��ł��܂���B */
				ERROROUT2(FORMAT(166),"cl_gx_get_info_parm_opt",pLprp);
				rc = ECL_SCRIPT_ERROR;
			}
		}
		if (pInfoParm->pi_id=='R' &&
		    (!pInfoParm->pi_pos || (pInfoParm->pi_pos && !*(char *)pInfoParm->pi_pos))) {
			vnlen = strlen(varnam);
			if (!(p=Malloc(vnlen+1))) {
				ERROROUT1("cl_gx_get_info_parm_opt: Array name[%s] area malloc",varnam);
				return -1;
			}
			strnzcpy(p,varnam,vnlen);
			pInfoParm->pi_pos = (long)p;
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_info_parm(pScCT,opt,pparmList,ppInfoParm)
ScrPrCT	  *pScCT;
char opt;
parmList  *pparmList;
tdtInfoParm **ppInfoParm;
{
	return cl_gx_get_info_parm_opt(pScCT,opt,pparmList,ppInfoParm,0);
}

/****************************************/
/* �@�\ : 								*/
/****************************************/
int cl_gx_get_parm_no_info(pScCT,proc,varnam,vnlen,opt,iOpt,ppInfo)
ScrPrCT	*pScCT;
ProcCT  *proc;
char    *varnam;
int      vnlen;
char     opt;
int      iOpt;
tdtInfoParm **ppInfo;
{
	static char *_fn_="cl_gx_get_parm_no_info";
	int  ParmNo,iNEW_LEX,iSKIP,iCHECK,iLGopt,vlen,iNONE;
	char *vnam,wrk[Pr_NM_MAX+Var_NM_MAX+2],*p;
	tdtInfoParm ***pTBL_vnam,*pInfo;
	ProcCT  *procW;
	ScrPrCT	*pGLScCT;
	XHASHB *pxha;
	tdtInfoParm *pInfoW;

DEBUGOUTL5(190,"--->cl_gx_get_parm_no_info:Enter pScCT=%08x proc=%08x [%s] opt=%c iOpt=%08x",
pScCT,proc,varnam,opt,iOpt);
	iNONE = !(iOpt & D_GX_OPT_SET_SCOPE);
#if 1	/* 2026.5.4 */
	if (ppInfo) *ppInfo = NULL;
	else ppInfo = &pInfoW;
#endif
	if ((iOpt & D_GX_OPT_SET_PRIVATE) || (
		/* 2025.12.23 */
		iNONE && opt=='s' && (pGlobTable->options[9] & 0x01)
	   )) iSKIP = 1;
	else iSKIP = 0;
	if (pScCT) iNEW_LEX = pScCT->sc_pFlag & D_SCRPT_NEW_LEX;
	else iNEW_LEX = 0;
DEBUGOUTL3(190,"%s: iNEW_LEX=%08x iSKIP=%d",_fn_,iNEW_LEX,iSKIP);
	vnlen = akxnskipto(varnam,vnlen,".");
	ParmNo = 0;
	iLGopt= 0;
	/* add 2025.12.19 */
	if (!iSKIP) {
/*
printf("%s: proc=%08x\n",_fn_,proc);
*/
		if ((ParmNo=cl_gx_chk_block_vnam_info(opt,proc,varnam,vnlen,ppInfo,NULL,iOpt)) > 0) {
			iLGopt = D_AUX1_LOCAL_VAR;
			iSKIP = 1;
		}
		else {
			if (ParmNo == ECL_CANT_USE_BLOCK) {
				iOpt &= ~D_GX_OPT_SET_BLOCK;
				iNONE = !(iOpt & D_GX_OPT_SET_SCOPE);
				ParmNo = 0;
			}
		}
	}
/*
if (proc) printf("%s: proc=%08x proc->pha_vnam=%08x\n",_fn_,proc,proc->pha_vnam);
*/
	if (!iSKIP && (iNONE || (iOpt & D_GX_OPT_SET_LOCAL)) &&
	    proc && proc->pha_vnam && iNEW_LEX) {
		if ((ParmNo=cl_gx_chk_scope_info(opt,proc,varnam,vnlen,&procW,ppInfo)) > 0) {
			iLGopt = D_AUX1_LOCAL_VAR;
DEBUGOUTL2(190,"%s: LOCAL ParmNo=%d",_fn_,ParmNo);
		}
		else if (!ParmNo) {
			vlen = cl_mk_static_name(wrk,proc->ProcNM,strlen(proc->ProcNM),varnam,vnlen);
#if 1	/* 2026.5.3 */
			if (pScCT->sc_pFlag2 & D_LEAF_IMPORTMODE)
				pxha = pCLprocTable->imp_pha_vnam;
			else pxha = pScCT->Vary->pha_vnam;
			if ((ParmNo=cl_gx_chk_vnam_info(opt,pxha,wrk,vlen,ppInfo)) > 0) {
#else
			if ((ParmNo=cl_gx_chk_vnam_info(opt,pScCT->Vary->pha_vnam,wrk,vlen,ppInfo)) > 0) {
#endif
				iLGopt = D_AUX1_LOCAL_VAR;
DEBUGOUTL2(190,"%s: LOCAL ParmNo=%d",_fn_,ParmNo);
			}
		}
	}
	if (ParmNo<=0 && pScCT && (iNONE || (iOpt & D_GX_OPT_SET_PRIVATE))) {
		/* 2024.12.22 */

DEBUGOUTL2(190,"%s: sc_pFlag2=%08x",_fn_,pScCT->sc_pFlag2);
		if (pScCT && (pScCT->sc_pFlag2 & D_LEAF_IMPORTMODE))
#if 1	/* 2026.4.13 */
			pxha = pCLprocTable->imp_pha_vnam;
#else
			pxha = pGLprocTable->imp_pha_vnam;
#endif
		else pxha = pScCT->Vary->pha_vnam;
DEBUGOUTL2(190,"%s: SCRIPT pha_vnam=%08x",_fn_,pxha);
/*
printf("%s: SCRIPT pha_vnam=%08x pxha sc_pFlag2=%08x imp_pha_vnam=%08x\n",_fn_,pxha,pScCT->sc_pFlag2,pCLprocTable->imp_pha_vnam);
*/
		if ((ParmNo=cl_gx_chk_vnam_info(opt,pxha,varnam,vnlen,ppInfo)) > 0) {
			iLGopt = D_AUX1_PRIVATE_VAR;
DEBUGOUTL2(190,"%s: SCRIPT ParmNo=%d",_fn_,ParmNo);
		}
	}
	if (ParmNo<=0 && opt=='r' && (iNONE || (iOpt & D_GX_OPT_SET_PUBLIC))) {
		if ((ParmNo=cl_gx_chk_vnam_info(opt,pCLprocTable->pha_vnam,varnam,vnlen,ppInfo)) > 0) {
			iLGopt = D_AUX1_PUBLIC_VAR;
DEBUGOUTL2(190,"%s: PUBLIC ParmNo=%d",_fn_,ParmNo);
		}
	}
	if (ParmNo<=0 && opt=='r' && (iNONE || (iOpt & D_GX_OPT_SET_GLOBAL))) {
		if ((ParmNo=cl_gx_chk_vnam_info(opt,pGLprocTable->pha_vnam,varnam,vnlen,ppInfo)) > 0) {
			iLGopt = D_AUX1_GLOBAL_VAR;
DEBUGOUTL2(190,"%s: GLOBAL ParmNo=%d",_fn_,ParmNo);
		}
	}
	if (ParmNo > 0) {
		if (pInfo = *ppInfo) pInfo->pi_aux[1] |= iLGopt;
	}
	return ParmNo;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_all_var_ent(pScCT,opti,name,ppInfoParm,ParmNo,varnam,iOpt)
ScrPrCT	  *pScCT;
char opti,*name;
tdtInfoParm **ppInfoParm;
int  ParmNo;
char *varnam;
int  iOpt;
{
	return cl_gx_get_all_var_ent_psize(pScCT,opti,name,ppInfoParm,ParmNo,varnam,iOpt,NULL);
}

/****************************************/
/*										*/
/****************************************/
static void _error_opt_undef(_fn_,name,varnam,iOpt,iEROUT_NDEF)
char *_fn_,*name,*varnam;
int iOpt,iEROUT_NDEF;
{
	if (iEROUT_NDEF)
		ERROROUT3(FORMAT(317),_fn_,name,varnam);	/* %s: %s(%s)�͖���`�ł��B */
	else if (!(iOpt & D_GX_OPT_NOHOLD_NDEF))
		ERRORHOLD5(FORMAT(317),_fn_,name,varnam,0,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_all_var_ent_psize(pScCT,opti,name,ppInfoParm,ParmNo,varnam,iOpt,ppar_pSize)
ScrPrCT	  *pScCT;
char opti,*name;
tdtInfoParm **ppInfoParm;
int  ParmNo;
char *varnam;
int  iOpt;
ParList *ppar_pSize;
{
	static char *_fn_="cl_gx_get_all_var_ent_psize";
	int rc, vnlen,*pSize,iEROUT_NDEF,iLOCAL,ix,iLGopt,val,ex_opt1,int_opt;
	char c,opt,optw;
	tdtInfoParm *pInfoParm, ***pTBL_vnam;
	ProcCT  *proc;

	rc = 0;
	if (ppar_pSize) {
		ppar_pSize->par = NULL;
		ppar_pSize->parlen = 0;
	}
	if (!ppInfoParm) return -1;
	*ppInfoParm = NULL;
	pInfoParm = NULL;
	iEROUT_NDEF = !(iOpt & D_GX_OPT_NOEROUT_NDEF);
	if ((opt=opti) == 'R') {
		iEROUT_NDEF = 0;
		iOpt |= D_GX_OPT_NOEROUT_NDEF;
		opt = 'r';
	}
	iLOCAL = iOpt & D_GX_OPT_SET_LOCAL;

DEBUGOUTL5(190,"--->cl_gx_get_all_var_ent_psize: opti=%c pScCT=%08x ParmNo=%d %s(%s)",
opti,pScCT,ParmNo,name,varnam);
DEBUGOUTL4(190,"%s: iOpt=%08x opt=%c iEROUT_NDEF=%d",_fn_,iOpt,opt,iEROUT_NDEF);

	if ((c=name[0])=='$' || (c!='%' && c!='#')) {
		if (ParmNo == 0 && *varnam) {	/* �z��łȂ��ϐ����̃`�F�b�N */
										/* $,%,#�Ȃ��œo�^����Ă��� */
			if (iOpt & (D_GX_OPT_SET_LOCAL | D_GX_OPT_SET_GLOBAL | D_GX_OPT_SET_PUBLIC/* | D_GX_OPT_SET_PRIVATE*/))
				return cl_gx_get_lg_var_ent_psize(pScCT,opti,name,ppInfoParm,varnam,iOpt,ppar_pSize);
			vnlen = strlen(varnam);
			if (cl_chk_sysvar_name(varnam,vnlen)) {
#if 1	/* 2025.8.7 */
				if (opt == 'r') int_opt = 0;
				else int_opt = 1;
				pInfoParm = cl_gx_setprm_list_g(varnam,vnlen,int_opt);
				if (!pInfoParm) {
					if (opt == 'r') _error_opt_undef(_fn_,name,varnam,iOpt,iEROUT_NDEF);
				}
#else
				pInfoParm = cl_gx_setprm_list_g(varnam,vnlen);
#endif
			}
			else {
				ex_opt1 = cl_get_option(1,0);
				if ((ex_opt1 & 0x02) && !(ex_opt1 & 0x10)) opt = 's';	/* 2021.7.16 add */
				iLGopt = 0;
				proc = NULL;
				if (pScCT) proc = cl_search_proc_ct();
/*
printf("cl_gx_get_all_var_ent_psize: proc=%08x\n",proc);
*/
				ParmNo = cl_gx_get_parm_no_info(pScCT,proc,varnam,vnlen,'r',iOpt,ppInfoParm);
DEBUGOUTL2(190,"%s:r ParmNo=%d",_fn_,ParmNo);
				if (ParmNo <= 0) {
					/* 2021.8.4 */
					if (opt == 'r') {
						_error_opt_undef(_fn_,name,varnam,iOpt,iEROUT_NDEF);
						return ECL_NDEFVAR_ERROR;
					}
					ParmNo = cl_gx_get_parm_no_info(pScCT,proc,varnam,vnlen,'s',iOpt,ppInfoParm);
DEBUGOUTL2(190,"%s:s ParmNo=%d",_fn_,ParmNo);
				}
				if (ParmNo <= 0) {
					if (opt == 's')
						/* %s: %s(%s)�̃G���g���p�̋󂫂�����܂���B */
						ERROROUT3(FORMAT(316),_fn_,name,varnam);
					else {
										/* %s: %s(%s)�͖���`�ł��B */
						if (iEROUT_NDEF) ERROROUT3(FORMAT(317),_fn_,name,varnam);
						return ECL_NDEFVAR_ERROR;
					}
					return ECL_SCRIPT_ERROR;
				}
				else {
				/*	pInfoParm = cl_get_var_ent_opt(pTBL_vnam,ParmNo,opt);	*/
					pInfoParm = *ppInfoParm;
/*
printf("cl_gx_get_all_var_ent_psize: opt=[%c] ParmNo=%d pInfoParm=%08x varnam=[%s]\n",opt,ParmNo,pInfoParm,varnam);
*/
					if (!pInfoParm) rc = -2;
					else {
						pInfoParm->pi_aux[1] |= D_AUX1_HASHED_NAME | iLGopt;
					/*	if (opt == 's') pInfoParm->pi_aux[1] |= D_AUX1_OPT_STORE;	*/
						if (ppar_pSize) ppar_pSize->parlen = ParmNo;
					}
				}
			}
		}
		else {
			if (!*varnam &&
			    (iOpt & (D_GX_OPT_SET_LOCAL | D_GX_OPT_SET_PUBLIC | D_GX_OPT_SET_GLOBAL))) {
				/* cl_gx_get_all_var_ent: %s�͎g�p�ł��܂���B */
				ERROROUT2(FORMAT(318),_fn_,name);
				return ECL_SCRIPT_ERROR;
			}
			if (!pScCT) return -1;
			pSize = (int *)pScCT->Vary->pTBL_dolu[0];
			if (ParmNo>0 && ParmNo<=pSize[2]) {
				/* 20240223 */
				pInfoParm = cl_get_var_ent_opt_psize(pScCT->Vary->pTBL_dolu,ParmNo,opt,ppar_pSize);
				if (!pInfoParm) rc = -2;
				else pInfoParm->pi_aux[1] |= D_AUX1_PRIVATE_VAR;
			}
#if 1
			else if (ParmNo == 0) {
				pInfoParm = cl_var_size_parm(pSize);
				pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED | D_AUX1_PRIVATE_VAR;
			}
#else
			else if (opt=='r' && ParmNo==0) {
				pInfoParm = cl_var_size_parm(pSize);
			}
#endif
			else rc = -1;
		}
	}
	else if (c=='%' || c=='#') {
		if (!ParmNo && *varnam) {
			/* cl_gx_get_all_var_ent: %s�͎g�p�ł��܂���B */
			ERROROUT2(FORMAT(318),_fn_,name);
			return (ECL_SCRIPT_ERROR);
		}
		else {
			if (!pScCT) return -1;
			if (c == '%') {
				if (iLOCAL) {
					if (!(proc = cl_search_proc_ct())) return SysError;
					if (pTBL_vnam=proc->pTBL_pasento) pSize = (int *)pTBL_vnam[0];
					else ParmNo = -1;
					iLGopt = D_AUX1_LOCAL_VAR;
				}
				else {
					pTBL_vnam = pScCT->Vary->pTBL_pasento;
					pSize = (int *)pTBL_vnam[0];
					iLGopt = D_AUX1_PRIVATE_VAR;
				}
				if (ParmNo>0 && ParmNo<=pSize[2]) {
					if (iLOCAL && strcmp(proc->ProcNM,"main") && opt=='r' && ParmNo>pSize[7]) rc = -1;
					else pInfoParm = cl_get_var_ent(pTBL_vnam,ParmNo);
				/*	pInfoParm = cl_get_var_ent_opt_psize(pTBL_vnam,ParmNo,'r',ppar_pSize);	*/
				}
				else if (ParmNo == 0) {
					pInfoParm = cl_var_size_parm(pSize);
				}
				else rc = -1;
				if (!rc && pInfoParm) {
					if (!pInfoParm->pi_id) cl_null_parm(pInfoParm);
					/* 2024.7.15 */
					pInfoParm->pi_aux[1] |= iLGopt;
					if (!(pInfoParm->pi_aux[1] & D_AUX1_POINTER)) pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED;
				}
			}
			else if (c=='#') {
				if (ParmNo>0 && ParmNo<=pScCT->Vary->varnam_igeta)
					pInfoParm = cl_get_var_ent_opt_psize(pScCT->Vary->pTBL_igeta,ParmNo,'r',ppar_pSize);
				else if (ParmNo == 0) {
					pInfoParm = cl_var_size_parm(pScCT->Vary->pTBL_igeta[0]);
				}
				else rc = -1;
				if (!rc) pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED | D_AUX1_PRIVATE_VAR;
			}
		}
	}
	else {
		/* %s: %s�͕ϐ��ł͂���܂���B */
		ERROROUT2(FORMAT(319),_fn_,name);
		return ECL_SCRIPT_ERROR;
	}

DEBUGOUT_InfoParm(194,"cl_gx_get_all_var_ent_psize: rc=%d name=%s",pInfoParm,rc,name);

	if (rc) {
		if (rc == -1)
			/* %s: %s�̃C���f�b�N�X(%d)�͔͈͊O�ł��B */
			ERROROUT3(FORMAT(320),_fn_,name,ParmNo);
		else
			/* %s: %s�p��Malloc�G���[�B*/
			ERROROUT2(FORMAT(321),_fn_,name);
		return ECL_SCRIPT_ERROR;
	}
	if (pInfoParm == NULL) {
		return ECL_SCRIPT_ERROR;
	}
	else if (opt == 'r' && pInfoParm->pi_id == '\0') {
		if (pGlobTable->options[0] & 0x01) {
			val = pInfoParm->pi_aux[1];
			cl_null_char(pInfoParm);
			pInfoParm->pi_aux[1] = val;
			rc = 0;
		}
		else {
#if 1	/* 2026.5.16 */
			rc = 0;
#else
			if (iOpt & D_GX_OPT_INFO_MODE) rc = 0;
			else {
								/* %s: %s�̃f�[�^�����ݒ�ł��B */
				if (iEROUT_NDEF) ERROROUT2(FORMAT(127),_fn_,name);
				rc = ECL_NO_DATA_ERROR;
			}
#endif
		}
	}
	/* 2021.3.24 */
	else if (iEROUT_NDEF && ((c=pInfoParm->pi_id)=='A' || c=='R' || c=='T') && pInfoParm->pi_hlen) {
		/* 2021.4.4 */
		if (rc = _check_gid_alive(pInfoParm,_fn_,name,iEROUT_NDEF)) return rc;
	}
	*ppInfoParm = pInfoParm;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _get_lg_var_ent(scope,opti,pxha,varnam,vnlen,iOpt,ppInfo)
char *scope,opti;
XHASHB	*pxha;
char *varnam;
int vnlen,iOpt;
tdtInfoParm **ppInfo;
{
	static char *_fn_="_get_lg_var_ent";
	int iParmNo,iEROUT_NDEF;
	char opt,name[Var_NM_MAX+1];

	iEROUT_NDEF = !(iOpt & D_GX_OPT_NOEROUT_NDEF);
	if (pGlobTable->options[0] & 0x02) opt = 's';
	else opt = opti;
	memnzcpy(name,varnam,vnlen,sizeof(name));
/*
printf("_get_lg_var_ent: opti=%c name=[%s]\n",opti,name);
*/
	if ((iParmNo=cl_gx_chk_vnam_info('r',pxha,varnam,vnlen,ppInfo)) < 0) return iParmNo;
	else if (!iParmNo) {
		/* 2021.8.4 */
		if (opt != 's') {
								/* cl_gx_get_all_var_ent: %s(%s)�͖���`�ł��B */
			if (iEROUT_NDEF) ERROROUT3(FORMAT(317),_fn_,name,varnam);
			else ERRORHOLD5(FORMAT(317),_fn_,name,varnam,0,0);
			return ECL_NDEFVAR_ERROR;
		}
		if (opt == 's') {
			iParmNo = cl_gx_chk_vnam_info(opt,pxha,varnam,vnlen,ppInfo);
			if (iParmNo <= 0) {
						/* _get_lg_var_ent: %s��%s�G���g���p�̋󂫂�����܂���B */
				ERROROUT3(FORMAT(323),_fn_,name,scope);
				iParmNo = ECL_SCRIPT_ERROR;
			}
		}
	}
/*
if (ppInfo) printf("%s: pInfo=%08x\n",_fn_,*ppInfo);
*/
DEBUGOUTL5(190,"%s: scope=[%s] opt=%c name=[%s] iParmNo=%d",_fn_,scope,opt,name,iParmNo);
	return iParmNo;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_lg_var_ent(pScCT,opti,name,ppInfoParm,varnam,iOpt)
ScrPrCT	  *pScCT;
char opti,*name;
tdtInfoParm **ppInfoParm;
char *varnam;
int  iOpt;
{
	return cl_gx_get_lg_var_ent_psize(pScCT,opti,name,ppInfoParm,varnam,iOpt,NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_lg_var_ent_psize(pScCT,opti,name,ppInfoParm,varnam,iOpt,ppar_pSize)
ScrPrCT	  *pScCT;
char opti,*name;
tdtInfoParm **ppInfoParm;
char *varnam;
int  iOpt;
ParList *ppar_pSize;
{
	static char *_fn_="cl_gx_get_lg_var_ent_psize";
	int rc,vnlen,iEROUT_NDEF;
	tdtInfoParm *pInfoParm, ***pTBL_vname,*pInfo,**ppInfo;
	ProcCT  *proc,*procW;
	int  iParmNo,iLGopt;
	XHASHB	*pxha;

DEBUGOUTL5(190,"--->%s: pScCT=%08x opti=[%c] varnam=[%s] iOpt=%08x",_fn_,pScCT,opti,varnam,iOpt);

	iEROUT_NDEF = !(iOpt & D_GX_OPT_NOEROUT_NDEF);
	rc = 0;
	ppInfo = &pInfo;
	vnlen = strlen(varnam);
	vnlen = akxnskipto(varnam,vnlen,".");
	if (pScCT) proc = cl_search_proc_ct();
	if (iOpt & D_GX_OPT_SET_LOCAL) {
		proc = NULL;
		if (pScCT) proc = cl_search_proc_ct();
/*
printf("%s: proc=%08x\n",_fn_,proc);
*/
		/* 2025.12.19 */
		iParmNo = 0;
		if (iOpt & D_GX_OPT_SET_BLOCK) {
/*
printf("%s: proc=%08x\n",_fn_,proc);
*/
			if ((iParmNo=cl_gx_chk_block_vnam_info(opti,proc,varnam,vnlen,ppInfo,NULL,iOpt)) < 0) {
				if (iParmNo == ECL_CANT_USE_BLOCK) {
					iOpt &= ~D_GX_OPT_SET_BLOCK;
					iParmNo = 0;
				}
				else return iParmNo;
			}
		}
		if (!iParmNo) {
			if (proc && proc->pha_vnam) {
				if (opti=='r' && !(pGlobTable->options[0] & 0x02)) {
					if ((iParmNo=cl_gx_chk_scope_info(opti,proc,varnam,vnlen,&procW,ppInfo)) < 0) return iParmNo;
					else if (!iParmNo) {
									/* %s: %s�͖���`�ł��B */
						if (iEROUT_NDEF) ERROROUT2(FORMAT(127),_fn_,strname(varnam,vnlen));
						return ECL_NDEFVAR_ERROR;
					}
				}
				else {
					pxha = proc->pha_vnam;
					if ((iParmNo=_get_lg_var_ent("LOCAL",opti,pxha,varnam,vnlen,iOpt,ppInfo)) < 0) return iParmNo;
				}
				iLGopt = D_AUX1_LOCAL_VAR;
			/* 2025.12.19 */
			}
			else return -1;
		}
	}
	else {
		if (iOpt & D_GX_OPT_SET_GLOBAL) {
			pxha = pGLprocTable->pha_vnam;
			if ((iParmNo=_get_lg_var_ent("GLOBAL",opti,pxha,varnam,vnlen,iOpt,ppInfo)) < 0) return iParmNo;
			iLGopt = D_AUX1_GLOBAL_VAR;
		}
		else if (iOpt & D_GX_OPT_SET_PUBLIC) {
			pxha = pCLprocTable->pha_vnam;
			if ((iParmNo=_get_lg_var_ent("PUBLIC",opti,pxha,varnam,vnlen,iOpt,ppInfo)) < 0) return iParmNo;
			iLGopt = D_AUX1_PUBLIC_VAR;
		}
		else if (pScCT) {
			pxha = pScCT->Vary->pha_vnam;
			if ((iParmNo=_get_lg_var_ent("SCRIPT",opti,pxha,varnam,vnlen,iOpt,ppInfo)) < 0) return iParmNo;
			iLGopt = D_AUX1_PRIVATE_VAR;
		}
		else {
			/* %s: SCRIPT�ϐ�[%s]�͒�`�ł��܂���B */
			ERROROUT2(FORMAT(324),_fn_,varnam);
			return ECL_SCRIPT_ERROR;
		}
	}

DEBUGOUTL2(190,"%s: iParmNo = %d",_fn_,iParmNo);

	pInfoParm = *ppInfo;
	if (!pInfoParm) rc = -2;
	else {
		if (opti=='r' && pInfoParm->pi_id == '\0') {
			if (pGlobTable->options[0] & 0x01) {
				cl_null_char(pInfoParm);
				rc = 0;
			}
			if (iOpt & D_GX_OPT_INFO_MODE) rc = 0;
			else {
				if (iEROUT_NDEF) ERROROUT2(FORMAT(127),_fn_,varnam);
				rc = ECL_NO_DATA_ERROR;
			}
		}
		pInfoParm->pi_aux[1] |= D_AUX1_HASHED_NAME | iLGopt;
		if (ppar_pSize) ppar_pSize->parlen = iParmNo;
	}
/*
printf("%s: pInfoParm=%08x\n",_fn_,pInfoParm);
*/
	if (ppInfoParm) *ppInfoParm = pInfoParm;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_var_ent(pVarIndex,ParmNo)
tdtInfoParm **pVarIndex[];
int ParmNo;
{
	return cl_get_var_ent_opt(pVarIndex,ParmNo,'r');
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_var_ent_opt(pVarIndex,ParmNo,opt)
tdtInfoParm **pVarIndex[];
int ParmNo;
char opt;
{
	ParList par_pSize;

	return cl_get_var_ent_opt_psize(pVarIndex,ParmNo,opt,&par_pSize);
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_var_ent_opt_psize(pVarIndex,ParmNo,opt,ppar_pSize)
tdtInfoParm **pVarIndex[];
int ParmNo;
char opt;
ParList *ppar_pSize;
{
	int ix,iy,i,*pSize,iMAX_VAR_IX,iMAX_VAR_IY,val;
	tdtInfoParm *pDummy, **TBL_var;

	if (!pVarIndex || ParmNo<=0) return NULL;
	pSize = (int *)pVarIndex[0];
	if (ParmNo > pSize[2]) return NULL;
	iMAX_VAR_IX = pSize[0];
	iMAX_VAR_IY = pSize[1];
	pVarIndex++;
/*
printf("cl_get_var_ent_opt_psize: id=%s iMAX_IX=%d iMAX_IY=%d MAX_XY=%d\n",
&pSize[3],iMAX_VAR_IX,iMAX_VAR_IY,pSize[2]);
*/
	ParmNo--;
	ix = ParmNo / iMAX_VAR_IY;
	iy = ParmNo % iMAX_VAR_IY;

DEBUGOUTL4(190,"--->cl_get_var_ent_opt_psize:pVarIndex=%08x ParmNo=%d ix=%d iy=%d",
pVarIndex,ParmNo,ix,iy);
/*
printf("--->cl_get_var_ent_opt_psize:pVarIndex=%08x ParmNo=%d ix=%d iy=%d\n",
pVarIndex,ParmNo,ix,iy);
*/
	if (!(TBL_var = pVarIndex[ix])) {
		if (!(TBL_var=(tdtInfoParm **)Malloc(sizeof(tdtInfoParm *)*iMAX_VAR_IY)))
			return NULL;
/*
printf("cl_get_var_ent_opt_psize:Malloc TBL_var=%08x\n",TBL_var);
*/
		memset(TBL_var,0,sizeof(tdtInfoParm *)*iMAX_VAR_IY);
		pVarIndex[ix++] = TBL_var;
		pSize[5] = X_MAX(ix,pSize[5]);
		if (!(pDummy=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)*iMAX_VAR_IY)))
			return NULL;
/*
printf("cl_get_var_ent_opt_psize:Malloc pDummy=%08x\n",pDummy);
*/
		for(i=0;i<iMAX_VAR_IY;i++) {
			TBL_var[i] = (tdtInfoParm *)parm_set0(pDummy);
			pDummy++;
		}
	}
/*
printf("cl_get_var_ent_opt_psize: TBL_var=%08x\n",TBL_var);
*/
	ParmNo++;
	pSize[6] = ParmNo;
/*
printf("cl_get_var_ent_opt_psize: ParmNo=%d pSize[6]=%d opt=[%c]\n",ParmNo,pSize[6],opt);
*/
	if (opt == 's') {
		cl_set_max_var_ent(pSize,ParmNo);
		if (ppar_pSize) {
			ppar_pSize->par = NULL;
			ppar_pSize->parlen = 0;
		}
	}
	else {
		if (ppar_pSize) {
			ppar_pSize->par = (char *)pSize;
			ppar_pSize->parlen = ParmNo;
		}
	}
/*
printf("cl_get_var_ent_opt_psize:TBL_var[%d]=%08x\n",iy-1,TBL_var[iy-1]);
printf("cl_get_var_ent_opt_psize:TBL_var[%d]=%08x\n",iy,TBL_var[iy]);
*/
	pDummy = TBL_var[iy];
#if 0
if (!akxm_addrchk(pDummy)) {
/*akxaxdump("TBL_var",TBL_var,32);*/
	return NULL;
}
#endif
	if (!pDummy->pi_id) {
		if (cl_get_option(1,0) & 0x01) cl_null_char(pDummy);
		else cl_parm_set0(pDummy);
	}

DEBUGOUT_InfoParm(LVL_GXEXOBJ+1,"cl_get_var_ent_opt_psize:",pDummy,0,0);

	return pDummy;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_max_var_ent(pSize,ParmNo)
int *pSize,ParmNo;
{
	tdtInfoParm *pInfoParm;
	int ret,val;
	char *name;

	name = (char *)&pSize[3];
DEBUGOUTL3(102,"cl_set_max_var_ent: name=[%s] ParmNo=%d pSize[7]=%d",name,ParmNo,pSize[7]);

	if (ParmNo<0 || ParmNo>pSize[7]) {

DEBUGOUTL3(200,"cl_set_max_var_ent: name=[%s] ParmNo=%d pSize[7]=%d",name,ParmNo,pSize[7]);

		if (ParmNo < 0) ParmNo = 0;
		pSize[7] = ParmNo;
		pInfoParm = cl_var_size_parm(pSize);
		cl_set_parm_bin(pInfoParm,ParmNo);
		pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED;
	/*	ret = cl_reflect_size_of_number_array(name,ParmNo);	*/
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
static int _free_info_array(pDummy)
tdtInfoParm *pDummy;
{
	tdtArrayIndex *pIndex;
	char *p;
	uchar sca;

	if (pIndex=(tdtArrayIndex *)pDummy->pi_data) {

DEBUGOUTL2(180,"_free_info_array: pDummy=%08x pi_pi_scale=%02x",pDummy,pDummy->pi_scale);

		if ((sca=pDummy->pi_scale) & D_DATA_INDEX_FREE) cl_free_array_ent(pIndex);
		if (sca & D_DATA_MALLOC) {
			Free(pIndex);
			pDummy->pi_data = NULL;
			pDummy->pi_dlen = 0;
		}
	}
	if (p=(char *)pDummy->pi_pos) {
		if (!(pDummy->pi_alen & D_AULN_NO_AL_LPOS)) Free(p);
		pDummy->pi_pos = 0;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_free_info_parm(pDummy)
tdtInfoParm *pDummy;
{
	tdtArrayIndex *pIndex;
	char c,*p;
	XHASHB *xhp;
	tdtInfoParm *pParm;
	tdtInfoParm *pInfoParm1,*pInfoS;
	tdtRbCtl *pCt;
	tdtDefType *pDeftype;
	int ix,type,i,len,n,rc;
	ProcCT *proc;

DEBUGOUT_InfoParm(250,"--->cl_free_info_parm:",pDummy,0,0);
DEBUGOUTL1(250,"cl_free_info_parm: pDummy->pi_data=%08x",pDummy->pi_data);

  if (pDummy) {
	if (pDummy->pi_id) {
DEBUGOUTL2(250,"cl_free_info_parm: id=[%c] pi_scale=%02x",pDummy->pi_id,pDummy->pi_scale);
		if (pDummy->pi_scale & D_DATA_MALLOC) {
			if ((c=pDummy->pi_id)=='R' || c=='A') {
				_free_info_array(pDummy);
			}
			else if (c=='P' || c=='T') {
				if (c == 'P') {
					if (pDummy->pi_len > 0) {
						ix = akxs_xhasl(pGLprocTable->pha_gid,'D',pDummy->pi_len,0);
/*
printf("cl_free_info_parm: Delete gid=%ld ix=%d\n",pDummy->pi_len,ix);
*/
					}
					type = pDummy->pi_aux[0] & D_AUX0_ZOK_MASK;	/* mod 2026.5.8 "~DEF_ZOK_DATA" */
				}
				else type = D_AUX0_TYPE_STRUCT;
				if (type == D_AUX0_TYPE_STRUCT) {
					if (pDeftype=(tdtDefType *)pDummy->pi_data) {
						if (pDummy->pi_scale & D_DATA_INDEX_FREE)
							cl_free_deftype(c,pDeftype);
						Free(pDeftype);
					}
					if (!(pDummy->pi_alen & D_AULN_NO_AL_LPOS)) {
						if (p=(char *)pDummy->pi_pos) {
							Free(p);
							pDummy->pi_pos = 0;
						}
					}
				}
				else _free_info_array(pDummy);
			}
			else if (c==D_DATA_ID_LIST || c==D_DATA_ID_NARABI) {
				if (pCt=(tdtRbCtl *)pDummy->pi_data) {
				/*	if (pDummy->pi_scale & D_DATA_INDEX_FREE) {	*/
						while (pParm=(tdtInfoParm *)akxs_rb_get_n(pCt)) {
							rc = cl_free_info_parm(pParm);
							if (rc != ECL_NOT_FREE_INFO) {
								if (!pCt->rb_malloc) Free(pParm);
							}
						}
						akxs_rb_free(pCt);
				/*	}
					else Free(pCt);	*/
				}
			}
			/* 2022.9.17 */
			else if (c==D_DATA_ID_INSTANCE || c==D_DATA_ID_CLASS || c==D_DATA_ID_CLMETHOD) {
DEBUGOUTL4(250,"cl_free_info_parm: id=%c pDummy=%08x pi_scale=%02x pi_data=[%s]"
,c,pDummy,pDummy->pi_scale,pDummy->pi_data);
/*
printf("cl_free_info_parm: id=%c pDummy=%08x pi_scale=%02x pi_data=[%s]\n",c,pDummy,pDummy->pi_scale,pDummy->pi_data);
*/
				if (p=pDummy->pi_data) Free(p);
				if (akxm_addrchk(p=(char *)pDummy->pi_hlen)) Free(p);	/* add 2025.8.26 */
				if (proc=(ProcCT *)pDummy->pi_len) {
					if (pDummy->pi_scale & D_DATA_CLEAR_PROC) {
#if 1	/* 2025.8.25 */
						cl_prc_ct_clear(proc);
						memset(proc,0,sizeof(ProcCT));
#else
						cl_prc_clear(proc);
#endif
					}
				/*	if (!(pDummy->pi_scale & D_DATA_COPIED_PROC)) cl_prc_clear(proc);	*/
				/*	else if (!(pDummy->pi_scale & D_DATA_NO_FREE_PROC)) Free(proc);	*/
				}
			}
			else if (c == D_DATA_ID_PNAME) {
				if (pInfoParm1 = (tdtInfoParm *)pDummy->pi_pos) {
					if (pDummy->pi_scale & D_DATA_INDEX_FREE) {
DEBUGOUTL1(198,"cl_free_info_parm: pInfoParm1=%08x",pInfoParm1);
						rc = cl_free_info_parm(pInfoParm1);
						if (rc != ECL_NOT_FREE_INFO) {
DEBUGOUTL1(198,"cl_free_info_parm: Free(pInfoParm1)",0);
							Free(pInfoParm1);
						}
					}
				}
			}
			else if (p=pDummy->pi_data) Free(p);
			pDummy->pi_data = NULL;
		}
		else if (pDummy->pi_alen & D_AULN_PARMINFO2) {
DEBUGOUT_InfoParm(198,"--->cl_free_info_parm:",pDummy,0,0);
			pInfoParm1 = pDummy + 1;
			if (pInfoParm1->pi_scale & D_DATA_MALLOC) {
				len = pInfoParm1->pi_dlen;
				pInfoS = (tdtInfoParm *)pInfoParm1->pi_data;
				n = len/sizeof(tdtInfoParm);
				for (i=0;i<n;i++,pInfoS++) {
					pInfoS->pi_alen &= ~D_AULN_PARMINFO2;
					cl_free_info_parm(pInfoS);
				}
				Free(pInfoParm1->pi_data);
			}
		}
	/*	cl_parm_set0(pDummy);	2023.9.20 */
	}
	/* 2023.9.20 */
	if (cl_get_option(1,0) & 0x01) cl_null_char(pDummy);
	else cl_parm_set0(pDummy);
  }
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_free_var_ent_opt(pVarIndex,reset)
tdtInfoParm **pVarIndex[];
int reset;
{
	int ix,iy;
	tdtInfoParm *pDummy, **TBL_var;
	int *pSize,iMAX_VAR_IX,iMAX_VAR_IY;

DEBUGOUTL1(190,"--->cl_free_var_ent:pVarIndex=%08x",pVarIndex);

	if (!pVarIndex) return -1;
	pSize = (int *)pVarIndex[0];
	iMAX_VAR_IX = pSize[5];
	iMAX_VAR_IY = pSize[1];
	pVarIndex++;

DEBUGOUTL4(190,"cl_free_var_ent: id=%s iMAX_IX=%d iMAX_IY=%d MAX_XY=%d",
&pSize[3],iMAX_VAR_IX,iMAX_VAR_IY,pSize[2]);

	for (ix = 0; ix < iMAX_VAR_IX; ix++) {
		if (TBL_var = pVarIndex[ix]) {
			if (TBL_var[0]) {
				for (iy = 0; iy < iMAX_VAR_IY; iy++) {
					pDummy = TBL_var[iy];
					if (pDummy && pDummy->pi_id) {
						if (reset) parm_set0(pDummy);
						else cl_free_info_parm(pDummy);
					}
				}
				if (!reset) Free(TBL_var[0]);
			}
			if (!reset) {
				Free(TBL_var);
				pVarIndex[ix] = NULL;
			}
		}
	}
	if (reset) {
		pSize[5] = pSize[6] = pSize[7] = 0;
		cl_set_parm_bin(cl_var_size_parm(pSize),0);
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_free_var_ent(pVarIndex)
tdtInfoParm **pVarIndex[];
{
	return cl_free_var_ent_opt(pVarIndex,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_reset_var_ent(pVarIndex)
tdtInfoParm **pVarIndex[];
{
	return cl_free_var_ent_opt(pVarIndex,1);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_chk_scope(opt,proc,varnam,vnlen,pprocW)
char     opt;
ProcCT  *proc;
char    *varnam;
int      vnlen;
ProcCT  **pprocW;
{
	return cl_gx_chk_scope_info(opt,proc,varnam,vnlen,pprocW,NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_chk_scope_info(opt,proc,varnam,vnlen,pprocW,ppInfo)
char     opt;
ProcCT  *proc;
char    *varnam;
int      vnlen;
ProcCT  **pprocW;
tdtInfoParm **ppInfo;
{
	static char *_fn_="cl_gx_chk_scope_info";
	ProcCT	*procW;
	char *path0,*path;
	int ParmNo,len,len0;

DEBUGOUTL3(120,"%s:Enter opt=%c varnam=[%s]",_fn_,opt,strname(varnam,vnlen));

DEBUGOUTL4(120,"%s: proc->pha_vnam=%08x options[7]=%08x path=[%s]",
_fn_,proc->pha_vnam,pGlobTable->options[7],nval1(proc->ProcPath));

	if ((ParmNo=cl_gx_chk_vnam_info(opt,proc->pha_vnam,varnam,vnlen,ppInfo)) > 0) *pprocW = proc;
	else if (!ParmNo && (pGlobTable->options[7] & 0x02) && (path=proc->ProcPath)) {

DEBUGOUTL2(120,"%s: path=[%s]",_fn_,path);

		if (*path == '*') {
			path++;
		}
		if ((len=akxnrskipto(path,strlen(path),".")) <= 0) return 0;
		procW = proc;
		while (procW = procW->prePCT) {
/*
printf("cl_gx_chk_scope_info: procW->ProcPath=%08x\n",procW->ProcPath);
*/
			if (path0 = procW->ProcPath) {
				len0 = strlen(path0);
/*
printf("cl_gx_chk_scope_info: path0=[%s] len0=%d\n",path0,len0);
*/
				if (len0 <= len) {
					if (!memcmp(path,path0,len0)) {
						if ((ParmNo=cl_gx_chk_vnam_info(opt,procW->pha_vnam,varnam,vnlen,ppInfo)) > 0) {
							*pprocW = procW;
/*
printf("cl_gx_chk_scope_info: found ParmNo=%d in path0=[%s] procW=%08x procW->pha_vnam=%08x\n",ParmNo,path0,procW,procW->pha_vnam);
*/
							break;
						}
						else if (ParmNo < 0) return ParmNo;
					}
				}
			}
			else {
				/* cl_gx_chk_scope_info:W: %s�̏�ʂ�ProcPath��NULL��proc������܂��B */
				ERROROUT1(FORMAT(325),path);
			}
		}
	}
DEBUGOUTL2(120,"%s:Exit ParmNo=%d",_fn_,ParmNo);
	return ParmNo;
}

/************************************/
/*	_check_gid_alive				*/
/************************************/
int _check_gid_alive(pInfoParmW,fnam,vnam,iEROUT_NDEF)
tdtInfoParm *pInfoParmW;
char *fnam,*vnam;
int iEROUT_NDEF;
{
	int rc,ix;
	long gid;
	char id,*p;

	rc = 0;
	id = pInfoParmW->pi_id;
	if (gid=pInfoParmW->pi_hlen) {
DEBUGOUTL2(170,"_check_gid_alive: pInfoParmW=%08x gid=%d",pInfoParmW,gid);
		if ((ix=akxs_xhasl(pGLprocTable->pha_gid,'R',gid,0)) <= 0) {
			if (iEROUT_NDEF) {
						/* %s: �ϐ�(%s)��%s�͖����ł�(gid=%d hash ix=%d)�B */
				if (!fnam) fnam = "_check_gid_alive";
				if (!vnam) vnam = (char *)pInfoParmW->pi_pos;
				if (id == 'T') p = FORMAT(154);	/* �\���� */
				else p = FORMAT(150);	/* �z�� */
				ERROROUT5(FORMAT(322),fnam,nvalid(vnam,""),p,gid,ix);
			}
		/*	cl_free_info_parm(pInfoParmW);	*/
			rc = ECL_NDEFVAR_ERROR;
		}
	}
#if 1	/* 2025.11.19 */
	if (id=='A' || id=='R') rc = cl_array_check_valid(pInfoParmW,iEROUT_NDEF);
	else if (id == 'T') rc = cl_struct_check_valid(pInfoParmW,iEROUT_NDEF);
	if (rc < 0) {
		cl_free_info_parm(pInfoParmW);
		rc = ECL_NDEFVAR_ERROR;
	}
#endif
	return rc;
}

/************************************/
/*	cl_mk_static_name				*/
/************************************/
int cl_mk_static_name(wrk,prnam,prlen,varnam,vnlen)
char *wrk,*prnam,*varnam;
int prlen,vnlen;
{
	char *p;

	p = wrk;
	memcpy(p,prnam,prlen);
	p += prlen;
	*(p++) = '.';
	memzcpy(p,varnam,vnlen);
/*
printf("cl_mk_static_name: wrk=[%s]\n",wrk);
*/
	return prlen+vnlen+1;
}

/************************************/
/*	cl_set_pSize_index				*/
/************************************/
int cl_set_pSize_index(pInfoParmW,pSize,index,ParmNo,pParent)
tdtInfoParm *pInfoParmW,*pParent;
int pSize[],index[],ParmNo;
{
	char **ppp,*p1;

DEBUGOUTL5(102,"cl_set_pSize_index: pInfoParmW=%08x pSize=%08x index=%08x ParmNo=%d pParent=%08x",
pInfoParmW,pSize,index,ParmNo,pParent);
	if (index) {
		if (!(ppp=(char **)cl_tmp_const_malloc(sizeof(char *)*2))) return -1;
		ppp[0] = (char *)index;
		ppp[1] = (char *)pParent;	/* �e�̃|�C���^�������Ă��� */
	}
	else ppp = NULL;
	pInfoParmW->pi_len = (long)ppp;
	pInfoParmW->pi_paux = (char *)pSize;
	pInfoParmW->pi_hlen = ParmNo;
	return 0;
}
#if 1	/* 2026.5.5 */
/************************************/
/*	cl_gx_is_block_cida				*/
/************************************/
BlockCB *cl_gx_is_block_cida(proc,cida,num)
ProcCT *proc;
int cida[],num;
#else
/* add 2025.12.20 */
/************************************/
/*	cl_gx_is_block					*/
/************************************/
int cl_gx_is_block(proc)
ProcCT *proc;
#endif
{
	BlockCB *pcrLCB,*ret_pcrLCB;
	int cmd;

	cmd = 0;
	ret_pcrLCB = NULL;
	if (proc) {
		pcrLCB = proc->pcrBlockCB;
		while (pcrLCB) {
/*
printf("cl_gx_is_block: used=%d\n",pcrLCB->iUsed);
*/
			if (pcrLCB->iUsed) {
				cmd = pcrLCB->cid;
#if 1	/* 2026.5.5 */
				if (akxs_iseq(cida,num,cmd) > 0) {
					ret_pcrLCB = pcrLCB;
					break;
				}
#else
				if (cmd==C_LOOP || cmd==C_FOR || cmd==C_DO || cmd==C_SWITCH || cmd==C_IF) break;
#endif
				pcrLCB = pcrLCB->preBlockCB;
				cmd = 0;
			}
			else break;
		}
	}
/*
printf("cl_gx_is_block: cmd=%08x %s\n",cmd,cl_gets_cmd_name(cmd));
*/
#if 1	/* 2026.5.5 */
	return ret_pcrLCB;
#else
	return cmd;
#endif
}
#if 1	/* 2026.5.5 */
/************************************/
/*	cl_gx_is_block					*/
/************************************/
int cl_gx_is_block(proc)
ProcCT *proc;
{
	static int cida[]={C_LOOP,C_FOR,C_DO,C_SWITCH,C_IF,C_TRY,0};
	BlockCB *pcrLCB;
	int cmd;

	if (pcrLCB = cl_gx_is_block_cida(proc,cida,-1)) cmd = pcrLCB->cid;
	else cmd = 0;
	return cmd;
}
#endif
#if 1	/* add 2025.12.19 */
/************************************/
/*	cl_gx_chk_block_vnam_info		*/
/************************************/
int cl_gx_chk_block_vnam_info(opt,proc,varnam,vnlen,ppInfo,ppha_vnam,ex_opt)
ProcCT *proc;
char opt,*varnam;
int vnlen,ex_opt;
tdtInfoParm **ppInfo;
XHASHB **ppha_vnam;
{
	static char *_fn_="cl_gx_chk_block_vnam_info";
	static int block_cida[]={C_LOOP,C_FOR,C_WHILE,C_UNTIL,C_DO,C_TRY,C_IF,C_SWITCH,0};
	static int switch_cida[]={C_LOOP,C_FOR,C_WHILE,C_UNTIL,C_DO,C_TRY,C_SWITCH,0};
	static char varnam_bef[Var_NM_MAX*2+1]={'\0'};
	static ProcCT *proc_bef=NULL;
	static int out_flag=1;
	XHASHB *pha;
	BlockCB *pcrLCB,*pcrLCB_var;
	tdtInfoParm *pInfo;
	int rc,cmd,ParmNo,iBLOCK_VAR,iSET_LBLOCK,iSET_BLOCK,iDEFINE,ex_optw,opt10,num,*w_cida;
	char *form;
/*
printf("%s:Enter opt=[%c] proc=%08x varnam=[%s] vnlen=%d ppha_vnam=%08x ex_opt=%08x\n",
_fn_,opt,proc,varnam,vnlen,ppha_vnam,ex_opt);
*/
DEBUGOUTL5(120,"%s:Enter opt=[%c] varnam=[%s] vnlen=%d ppha_vnam=%08x",
_fn_,opt,varnam,vnlen,ppha_vnam);
DEBUGOUTL3(120,"%s:Enter proc=%08x  ex_opt=%08x",_fn_,proc,ex_opt);

#if 1	/* 2026.5.5 */
	pha = NULL;
	if (ppha_vnam) *ppha_vnam = NULL;
#endif
/*
printf("%s: proc=%08x proc_bef=%08x\n",_fn_,proc,proc_bef);
printf("%s: varnam=[%s] varnam_bef=[%s]\n",_fn_,strname(varnam,vnlen),varnam_bef);
*/
	if (proc!=proc_bef || _memcmplen(varnam,vnlen,varnam_bef,strlen(varnam_bef),0))
		out_flag = 1;
	proc_bef = proc;
	memnzcpy(varnam_bef,varnam,vnlen,Var_NM_MAX*2+1);
	if ((cl_get_option(10,0) & 0x02) || !proc) {
		return 0;
	}
#if 1	/* 2026.5.5 */
	if (!(pcrLCB = proc->pcrBlockCB)) {
		rc = 0;
		if (ex_opt & D_GX_OPT_SET_BLOCK) {
#if 1	/* 2026.5.16 */
			if (cl_get_option(7,0) & 0x10000) {
				form = FORMAT(636);		/* %s: %s�͎w��ł��܂���B*/
				rc = ECL_SCRIPT_ERROR;
			}
			else {
				form = FORMAT(694);		/* %s: (W)%s�͎w��ł��܂���B�X�R�[�v�𖳎����܂��B*/
				rc = ECL_CANT_USE_BLOCK;
			}
			if (out_flag) {
				ERROROUT2(form,_fn_,"block");
				out_flag = 0;
			}
#endif
		}
		return rc;
	}
#endif
#if 1	/* 2026.5.5 */
/*	ex_optw = ex_opt & D_GX_OPT_SET_LBLOCK;	*/
/*
printf("cl_gx_chk_block_vnam_info: opt=[%c] ex_opt=%08x ex_optw=%08x\n",opt,ex_opt,ex_optw);
*/
/*	if (ex_optw == D_GX_OPT_SET_LBLOCK) ;
	else {
		ex_optw = D_GX_OPT_SET_SCOPE & ~D_GX_OPT_SET_BLOCK;	*/
/*
printf("cl_gx_chk_block_vnam_info: ex_opt=%08x ex_optw=%08x\n",ex_opt,ex_optw);
*/
		if (ex_opt & (D_GX_OPT_SET_SCOPE & ~D_GX_OPT_SET_BLOCK)) return 0;
/*	}	*/
#endif
	opt = toupper(opt);
#if 1	/* 2026.5.5 */
	iDEFINE = ex_opt & D_GX_OPT_DEFINE;
	iSET_BLOCK = ex_opt & D_GX_OPT_SET_BLOCK;
/*
	iSET_LBLOCK = ex_opt & D_GX_OPT_SET_LBLOCK;
#if 1
	if (!iSET_BLOCK) opt = 'R';
#else
	if (iSET_LBLOCK != D_GX_OPT_SET_LBLOCK) opt = 'R';
#endif
*/
#else
	ex_opt &= D_GX_OPT_SET_LBLOCK;
	if (ex_opt != D_GX_OPT_SET_LBLOCK) opt = 'R';
#endif
#if 0	/* 2026.5.5 */
	pha = NULL;
	if (ppha_vnam) *ppha_vnam = NULL;
#endif
	cmd = ParmNo = 0;
	/* 2025.12.20 */
	cmd = cl_gx_is_block(proc);
	if (cmd) {
		while (pcrLCB) {
			if (pha=pcrLCB->pha_vnam) {
				if ((ParmNo=cl_gx_chk_vnam_info('r',pha,varnam,vnlen,ppInfo)) > 0) {
					if (ppha_vnam) *ppha_vnam = pha;
					break;
				}
			}
#if 1	/* 2026.5.5 */
			if (opt=='R' && !iSET_BLOCK) pcrLCB = pcrLCB->preBlockCB;
#else
			if (opt=='R' && ex_opt != D_GX_OPT_SET_LBLOCK) pcrLCB = pcrLCB->preBlockCB;
#endif
			else break;
		}
/*
if (opt=='R' || ParmNo>0) printf("cl_gx_chk_block_vnam_info:1 opt=[%c] pcrLCB=%08x pha=%08x\n",opt,pcrLCB,pha);
*/
		if (ParmNo <= 0) {
			pha = NULL;
			/* 2026.5.5 */
			if (/*iDEFINE || */iSET_BLOCK) {
				iBLOCK_VAR = 1;
				pcrLCB = proc->pcrBlockCB;
			}
			else {
				opt10 = cl_get_option(10,0) & (0x04 | 0x08);
				w_cida = block_cida;
				num = 6;
				if (opt10) {
					if (opt10 == (0x04 | 0x08)) num = -1;
					else if (opt10 & 0x04) num = 7;
					else if (opt10 & 0x08) {
						num = 7;
						w_cida = switch_cida;
					}
				}
				if (pcrLCB = cl_gx_is_block_cida(proc,w_cida,num)) {
					iBLOCK_VAR = 2;
				}
				else iBLOCK_VAR = 0;
			}
/*
printf("cl_gx_chk_block_vnam_info: opt=[%c] cmd=%08x ParmNo=%d iBLOCK_VAR=%d\n",opt,cmd,ParmNo,iBLOCK_VAR);
*/
			if ((opt=='S' || ppha_vnam) && iBLOCK_VAR) {
				if (!(pha=pcrLCB->pha_vnam)) {
					pha = akxs_xhash_new2(0,MAX_LVR_IY,0,sizeof(tdtInfoParm));
					pcrLCB->pha_vnam = pha;
					if (ppha_vnam) *ppha_vnam = pha;
				}
/*
printf("cl_gx_chk_block_vnam_info:2 opt=[%c] pcrLCB=%08x pha=%08x\n",opt,pcrLCB,pha);
*/
				if (opt == 'S') {
					ParmNo = cl_gx_chk_vnam_info(opt,pha,varnam,vnlen,ppInfo);
					if (ParmNo > 0) {
						if (ppInfo) {
							if (pInfo = *ppInfo) {
								pInfo->pi_aux[0] |= D_AUX0_BLOCK_VAR;
								pInfo->pi_aux[1] |= D_AUX1_LOCAL_VAR;
							}
						}
					}
				}
			}
		}
	}
/*
printf("cl_gx_chk_block_vnam_info:Exit cmd=%08x ParmNo=%d pha=%08x varnam=[%s] \n",cmd,ParmNo,pha,varnam_bef);
*/
DEBUGOUTL3(120,"cl_gx_chk_block_vnam_info:Exit cmd=%08x ParmNo=%d pha=%08x",cmd,ParmNo,pha);

	return ParmNo;
}

/************************************/
/*	cl_gx_can_use_block				*/
/************************************/
int cl_gx_can_use_block(proc,pInfoParm,pex_opt)
tdtInfoParm *pInfoParm;
ProcCT *proc;
int *pex_opt;
{
	int rc,ex_opt,iBLOCK;
	char *form;
/*
printf("cl_gx_can_use_block:Enter proc=%08x pInfoParm=%08x pex_opt=%08x\n",proc,pInfoParm,pex_opt);
*/
	if (!proc) {
		if (cl_search_scr_ct()) proc = cl_search_proc_ct();
	}
	rc = 0;
	if (proc) {
		if (!(proc->pcrBlockCB)) {
			ex_opt = 0;
			if (pInfoParm) {
/*
printf("cl_gx_can_use_block: pi_aux[0]=%02x\n",pInfoParm->pi_aux[0]);
*/
				iBLOCK = pInfoParm->pi_aux[0] & D_AUX0_BLOCK_VAR;
				pInfoParm->pi_aux[0] &= ~D_AUX0_BLOCK_VAR;
			}
			if (!iBLOCK && pex_opt) {
				ex_opt = *pex_opt;
/*
printf("cl_gx_can_use_block: ex_opt=%08x\n",ex_opt);
*/
				iBLOCK = ex_opt & D_GX_OPT_SET_BLOCK;
				ex_opt &= ~D_GX_OPT_SET_BLOCK;
				*pex_opt = ex_opt;
			}
			else iBLOCK = 1;
			if (iBLOCK) {
				if (cl_get_option(7,0) & 0x10000) {
					form = FORMAT(636);	/* %s: %s�͎w��ł��܂���B*/
					rc = ECL_SCRIPT_ERROR;
				}
				else {
					form = FORMAT(694);		/* %s: (W)%s�͎w��ł��܂���B�X�R�[�v�𖳎����܂��B*/
					rc = ECL_CANT_USE_BLOCK;
				}
				/*	if (!(ex_opt & D_GX_OPT_NOEROUT_NDEF))	*/
					/*	ERROROUT2(form,"cl_gx_can_use_block","block");	*/
			}
		}
	}
	return rc;
}
#endif
