static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/* <clanal.c>                                                       */
/*                                                                  */
/********************************************************************/

#include "colmn.h"

extern int giProgram[];
extern CLPRTBL *pGLprocTable;
extern CLPRTBL *pCLprocTable;

#if 1	/* 2026.10.21 */
/********************************************/
/*	_mn_analz								*/
/********************************************/
static int _mn_analz(lInstanceHandle,cpInstanceData,tpRecvMsg)
long lInstanceHandle;
char *cpInstanceData;
AKAMSGCOM *tpRecvMsg;
{
	AKAMSGCOM    tMsgCom;
	char         *pFilev[2],filename[256],val[2];
	int          iRc,iDisp,iWaitTime;
	qDbToCol *pDTD;		/* ���M�p�P�b�g ���ʕ���   */

#if 0	/* 2026.10.10 */
/*
printf("_mn_analz: tpRecvMsg->msg_clid=%d\n",tpRecvMsg->msg_clid);
*/
		if (tpRecvMsg->msg_clid == AKA_CLASS_SHUT) {
			val[0] = AKA_SHUT_MODE_SHUT;
			aka_shut_control(AKA_SHUT_MODE,val);
			return 0;
		}
#endif
		iDisp = 0;
		memset((char *)&tMsgCom,0,sizeof(AKAMSGCOM));
		tMsgCom.msg_filv = pFilev;
		pFilev[0] = filename;
								/* Packet Check & process flag set */
		iRc = cl_packet_check(lInstanceHandle,cpInstanceData,tpRecvMsg);
		if (iRc == 0) {
			pCLprocTable->WrPacketp = (char *)&tMsgCom;
			iRc = cl_script_main(); /* Script process */
		}
/*
printf("_mn_analz: tMsgCom.cpMsg=%08x MsgCom.msg_disp=%04x iThread=%d tMsgCom.msg_clid=%d\n",
tMsgCom.msg_pmsg,tMsgCom.msg_disp,pCLprocTable->iThread,tMsgCom.msg_clid);
*/
DEBUGOUTL4(150,"_mn_analz: tMsgCom.cpMsg=%08x usDisposition=%04x iThread=%d tMsgCom.msg_clid=%d",
tMsgCom.msg_pmsg,tMsgCom.msg_disp,pCLprocTable->iThread,tMsgCom.msg_clid);

		if (tMsgCom.msg_pmsg) {
			if (pCLprocTable->iThread>0) {
				if (tMsgCom.msg_disp & 0x1000) {
					tMsgCom.msg_disp &= ~0x1000;
					memcpy(&iWaitTime,tMsgCom.msg_pmsg+tMsgCom.msg_mlen,sizeof(int));
					iRc = aka_send_msg_wait_time(lInstanceHandle,&tMsgCom,iWaitTime);
				}
				else {
					pDTD = (qDbToCol *)tMsgCom.msg_pmsg;
/*
printf("_mn_analz: ntohs(pDTD->usCmdNo)=%d\n",ntohs(pDTD->usCmdNo));
*/
					if (ntohs(pDTD->usCmdNo) == 30001) {	/* SLEEP command */
						iRc = aka_set_sleep(lInstanceHandle,1,ntohl(pDTD->lret));
					}
					else {
						tMsgCom.msg_disp = 1;
						iWaitTime = ntohl(pDTD->lret);
						pDTD->lret = 0;
						iRc = aka_send_msg_wait_time(lInstanceHandle,&tMsgCom,iWaitTime);
					}
				}

DEBUGOUTL1(150,"_mn_analz: iRc=%d",iRc);

				if (iRc >= 0) {
					packet_save(cpInstanceData);
					iDisp = 1;
				}
				else {
					ERROROUT1("SendMsg rc=%d",iRc);
				}
			}
			Free(tMsgCom.msg_pmsg);
			tMsgCom.msg_pmsg = NULL;
		}
/*
printf("_mn_analz: tpRecvMsg->msg_clid=%d iDisp=%d\n",tpRecvMsg->msg_clid,iDisp);
*/
DEBUGOUTL1(110,"_mn_analz:Exit iDisp=%d",iDisp);

	return iDisp;
}
#endif
/********************************************/
/*	col_mn_analz							*/
/********************************************/
int col_mn_analz(lInstanceHandle,cpInstanceData,tpRecvMsg)
long lInstanceHandle;
char *cpInstanceData;
AKAMSGCOM *tpRecvMsg;
{
	AKAMSGCOM    tMsgCom;
	char         *pFilev[2], filename[256], val[2],data[128],*argv[2];
	int          iRc, iDisp, init_sc, iWaitTime,len;
	qDbToCol *pDTD;		/* ���M�p�P�b�g ���ʕ���   */
	TrmToSrv  qTTS;
/*
printf("col_mn_analz:Enter lInstanceHandle=%08x tpRecvMsg->msg_disp=%d\n",lInstanceHandle,tpRecvMsg->msg_disp);
*/
DEBUGOUTL3(110,"col_mn_analz:Enter lInstanceHandle=%08x cpInstanceData=%08x tpRecvMsg=%08x",
lInstanceHandle,cpInstanceData,tpRecvMsg);

	iDisp = 0;
	switch (tpRecvMsg->msg_disp) {
	case AKA_REGIST_CLASS:
		/* aka_register_class()�ł��̊֐���o�^�����Ƃ��ɌĂ΂��B */
#if 0
		/* 2026.10.10 */
		if (cpInstanceData) {
/*
printf("col_mn_analz: cpInstanceData=[%s]\n",cpInstanceData);
*/
			if (!strcmp(cpInstanceData,"-i")) {
				/* �v���Z�X�N�����ɁA�R�}���h0x0ffffff0�̃X�N���v�g�����s���� */
				memset((char *)&qTTS,0,sizeof(TrmToSrv));
				qTTS.commandid = htonl(0x0ffffff0);
				memset((char *)&tMsgCom,0,sizeof(AKAMSGCOM));
			/*	tMsgCom.msg_clid = lInstanceHandle & 0x0000ffff;	*/
				tMsgCom.msg_clid = 2;
				tMsgCom.msg_mlen = sizeof(TrmToSrv);
				tMsgCom.msg_pmsg = (char *)&qTTS;
			/* 2026.10.10 */
			}
			else {
				argv[0] = cpInstanceData;
				len = coal_make_pkt_form(1,argv,data,sizeof(data));
				memset((char *)&tMsgCom,0,sizeof(AKAMSGCOM));
				tMsgCom.msg_clid = 2;
				tMsgCom.msg_disp = 1;
				tMsgCom.msg_mlen = len;
				tMsgCom.msg_pmsg = (char *)data;
			}
			if ((iRc = aka_post_msg(0,&tMsgCom)) < 0)
				ERROROUT1("col_mn_analz:AKA_REGIST_CLASS: aka_post_msg ret=%d",iRc);
		}
#endif
		break;
	case 0:
		/* ���v���Z�X����̔��M���b�Z�[�W�̏����B */
		if (tpRecvMsg->msg_pret) {
			/* �ԐM�����ʃv���b�g�t�H�[�����ŃG���[�ɂȂ�Ԃ��ꂽ�B */
			break;
		}
	case 1:
#if 1	/* 2026.10.21 */
		iDisp = _mn_analz(lInstanceHandle,cpInstanceData,tpRecvMsg);
#else
#if 0	/* 2026.10.10 */
/*
printf("col_mn_analz: tpRecvMsg->msg_clid=%d\n",tpRecvMsg->msg_clid);
*/
		if (tpRecvMsg->msg_clid == AKA_CLASS_SHUT) {
			val[0] = AKA_SHUT_MODE_SHUT;
			aka_shut_control(AKA_SHUT_MODE,val);
			return 0;
		}
#endif
		memset((char *)&tMsgCom,0,sizeof(AKAMSGCOM));
		tMsgCom.msg_filv = pFilev;
		pFilev[0] = filename;
								/* Packet Check & process flag set */
		iRc = cl_packet_check(lInstanceHandle,cpInstanceData,tpRecvMsg);
		if (iRc == 0) {
			pCLprocTable->WrPacketp = (char *)&tMsgCom;
			iRc = cl_script_main(); /* Script process */
		}
/*
printf("col_mn_analz: tMsgCom.cpMsg=%08x MsgCom.msg_disp=%04x iThread=%d tMsgCom.msg_clid=%d\n",
tMsgCom.msg_pmsg,tMsgCom.msg_disp,pCLprocTable->iThread,tMsgCom.msg_clid);
*/
DEBUGOUTL4(150,"col_mn_analz: tMsgCom.cpMsg=%08x usDisposition=%04x iThread=%d tMsgCom.msg_clid=%d",
tMsgCom.msg_pmsg,tMsgCom.msg_disp,pCLprocTable->iThread,tMsgCom.msg_clid);

		if (tMsgCom.msg_pmsg) {
			if (pCLprocTable->iThread>0) {
			/*	if (!tMsgCom.msg_clid) tMsgCom.msg_clid = D_CLASS_COL;	*/
				if (tMsgCom.msg_disp & 0x1000) {
					tMsgCom.msg_disp &= ~0x1000;
					memcpy(&iWaitTime,tMsgCom.msg_pmsg+tMsgCom.msg_mlen,sizeof(int));
					iRc = aka_send_msg_wait_time(lInstanceHandle,&tMsgCom,iWaitTime);
				}
				else {
					pDTD = (qDbToCol *)tMsgCom.msg_pmsg;
/*
printf("col_mn_analz: ntohs(pDTD->usCmdNo)=%d\n",ntohs(pDTD->usCmdNo));
*/
					if (ntohs(pDTD->usCmdNo) == 30001) {	/* SLEEP command */
						iRc = aka_set_sleep(lInstanceHandle,1,ntohl(pDTD->lret));
					}
					else {
						tMsgCom.msg_disp = 1;
						iWaitTime = ntohl(pDTD->lret);
						pDTD->lret = 0;
						iRc = aka_send_msg_wait_time(lInstanceHandle,&tMsgCom,iWaitTime);
					}
				}

DEBUGOUTL1(150,"col_mn_analz: iRc=%d",iRc);

				if (iRc >= 0) {
					packet_save(cpInstanceData);
					iDisp = 1;
				}
				else {
					ERROROUT1("SendMsg rc=%d",iRc);
				}
			}
			Free(tMsgCom.msg_pmsg);
			tMsgCom.msg_pmsg = NULL;
		}
#endif
#if 1	/* 2026.10.10 */
/*
printf("col_mn_analz: tpRecvMsg->msg_clid=%d iDisp=%d\n",tpRecvMsg->msg_clid,iDisp);
*/
		if (!iDisp) {
#if 0	/* 2026.10.21 */
			memset((char *)&tMsgCom,0,sizeof(AKAMSGCOM));
			tMsgCom.msg_disp = 1;
			tMsgCom.msg_clid = AKA_CLASS_SHUT;
			if ((iRc = aka_post_msg(0,&tMsgCom)) < 0)
				ERROROUT1("col_mn_analz: aka_post_msg ret=%d",iRc);
#else
			val[0] = AKA_SHUT_MODE_SHUT;
			aka_shut_control(AKA_SHUT_MODE,val);
#endif
		}
#endif
	}

DEBUGOUTL1(110,"col_mn_analz:Exit iDisp=%d",iDisp);

	return iDisp;
}

/********************************************/
/*	col_init_class							*/
/********************************************/
int col_init_class(lInstanceHandle,cpInstanceData,tpRecvMsg)
long lInstanceHandle;
char *cpInstanceData;
AKAMSGCOM *tpRecvMsg;
{
	AKAMSGCOM    tMsgCom;
#if 1	/* 2026.10.21 */
	int iRc,iDisp,len,n;
	char data[512],*argv[128],parm[256];
#else
	char         *pFilev[2], filename[256], val[2],data[128],*argv[2];
	int          iRc, iDisp, init_sc, iWaitTime,len;
	qDbToCol *pDTD;		/* ���M�p�P�b�g ���ʕ���   */
#endif
	TrmToSrv  qTTS;
/*
printf("col_init_class:Enter lInstanceHandle=%08x\n",lInstanceHandle);
*/
DEBUGOUTL3(110,"col_init_class:Enter lInstanceHandle=%08x cpInstanceData=%08x tMsgCom=%08x",
lInstanceHandle,cpInstanceData,tMsgCom);

	iDisp = 0;
	switch (tpRecvMsg->msg_disp) {
	case AKA_REGIST_CLASS:
		/* aka_register_class()�ł��̊֐���o�^�����Ƃ��ɌĂ΂��B */
		/* 2026.10.10 */
		if (cpInstanceData) {
/*
printf("col_init_class: cpInstanceData=[%s]\n",cpInstanceData);
*/
			if (!strcmp(cpInstanceData,"-i")) {
				/* �v���Z�X�N�����ɁA�R�}���h0x0ffffff0�̃X�N���v�g�����s���� */
				memset((char *)&qTTS,0,sizeof(TrmToSrv));
				qTTS.commandid = htonl(0x0ffffff0);
				memset((char *)&tMsgCom,0,sizeof(AKAMSGCOM));
			/*	tMsgCom.msg_clid = lInstanceHandle & 0x0000ffff;	*/
				tMsgCom.msg_clid = 2;
				tMsgCom.msg_mlen = sizeof(TrmToSrv);
				tMsgCom.msg_pmsg = (char *)&qTTS;
			/* 2026.10.10 */
			}
			else {
#if 1	/* 2026.10.21 */
				n = akxtgetargv(cpInstanceData,argv,128,parm,sizeof(parm));
				len = coal_make_pkt_form(n,argv,data,sizeof(data));
#else
				argv[0] = cpInstanceData;
				len = coal_make_pkt_form(1,argv,data,sizeof(data));
#endif
				memset((char *)&tMsgCom,0,sizeof(AKAMSGCOM));
				tMsgCom.msg_clid = 2;
				tMsgCom.msg_disp = 1;
				tMsgCom.msg_mlen = len;
				tMsgCom.msg_pmsg = (char *)data;
			}
			if ((iRc = aka_post_msg(0,&tMsgCom)) < 0)
				ERROROUT1("col_mn_analz:AKA_REGIST_CLASS: aka_post_msg ret=%d",iRc);
#if 1	/* 2026.10.21 */
			else pGLprocTable->ScrSt = 1;
#endif
		}
		break;
	case 0:
		/* ���v���Z�X����̔��M���b�Z�[�W�̏����B */
		if (tpRecvMsg->msg_pret) {
			/* �ԐM�����ʃv���b�g�t�H�[�����ŃG���[�ɂȂ�Ԃ��ꂽ�B */
			break;
		}
	case 1:
		/* 2026.10.21 */
		iDisp = _mn_analz(lInstanceHandle,cpInstanceData,tpRecvMsg);
#if 1	/* 2026.10.21 */
		if (!iDisp) pGLprocTable->ScrSt = 0;
#endif
	}
	return iDisp;
}

/********************************************/
/*	cl_shut_class							*/
/********************************************/
int cl_shut_class(lInstanceHandle,cpInstanceData,tpRecvMsg)
long lInstanceHandle;
char *cpInstanceData;
AKAMSGCOM *tpRecvMsg;
{
	char val[2];

	switch (tpRecvMsg->msg_disp) {
	case AKA_REGIST_CLASS:
		/* aka_registerClass()�ł��̊֐���o�^�����Ƃ��ɌĂ΂��B */
		break;
	case 0:
		/* ���v���Z�X����̔��M���b�Z�[�W�̏����B */
		if (tpRecvMsg->msg_pret) {
			/* �ԐM�����ʃv���b�g�t�H�[�����ŃG���[�ɂȂ�Ԃ��ꂽ�B */
			break;
		}
		/* �R�}���h�̉�͂Ǝ��s */
		val[0] = AKA_SHUT_MODE_SHUT;
		aka_shut_control(AKA_SHUT_MODE,val);
		break;
	default:
		break;
	}
	return 0;
}
