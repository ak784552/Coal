static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************/
/*											*/
/*		���l�f�[�^�̃`�F�b�N				*/
/*											*/
/********************************************/
#include "colmn.h"

int cl_chk_digit(rad, buf, len)
int  rad;
char *buf;
int  len;
{
	int i,n,rad1,iUL;
	char *p=buf;

	len = akxqnumUL(p,len,&iUL);
	rad1 = rad - 1;
	for (i=0;i<len;i++) {
		n = *p++ - '0';
		if (n<0 || n>rad1) return -(i+1);
	}
	return 0;
}

int cl_chk_digit_x(buf, len)
char *buf;
int  len;
{
	int i;
	char c,*p=buf;

	for (i=0;i<len;i++) {
		if (!isdigit(c = *p++)) {
			if ((c>='a' && c<='f') ||
			    (c>= 'A' && c<='F'))
				continue;
			else
				return -1;
		}
	}
	return 0;
}

/********1*********2*********3*********4*********5*********6*****/
/*	-1234[{U[L]|R}]												*/
/*	-1234.567													*/
/*	-1234.567F													*/
/*	-1234.567D													*/
/*	-1234.567[E]+10												*/
/*	-1234.567[D]-10												*/
/*	0x0123456789ABCDEF, 0o01234567, 0b01						*/
/*	opt : AKX_CNVN_OPT_COMMA : �J���}�𖳎�����					*/
/*		  AKX_CNVN_OPT_MSIGN : ��������������					*/
/*		  AKX_CNVN_OPT_DIGIT : 0x,0o,0b�`�����G���[�ɂ��Ȃ�		*/
/*		  AKX_CNVN_OPT_FU_MPA: +123+01 ���̎w���`����MPA�Ƃ���	*/
/*	ret =  2 : int		old=0									*/
/*		=  3 : double	old=1									*/
/*		=  4 : decimal	old=2									*/
/*		=  8 : int ket over										*/
/*		= -1 : buf==NULL or buf_len<0							*/
/*		  -2 : ��												*/
/*		  -3 : �����̂�											*/
/*		  -4 : 0x,0o,0b �`���G���[								*/
/*		  -5 : �����܂��͏����_�����鐔����G���[				*/
/*		  -6 : E,F,D �`���G���[									*/
/*		  -7 : �����d��											*/
/*	iAttr[0] : ret>=0�̂Ƃ��A�f�[�^�^�C�v						*/
/*	iAttr[1] : 0												*/
/*	iAttr[2] : iParm[0] & (AKX_NUM_ULIR | AKX_NUM_CR)			*/
/*				= 0x100000: ���f��								*/
/*				= 0x200000: �L����								*/
/*				= 0x10 : unsigned								*/
/*				= 0x20 : long									*/
/*				= 0x40 : image									*/
/*				= 0x100 : rational								*/
/*	iAttr[3] : �G���[�ʒu										*/
/****************************************************************/
int cl_chk_digit_fopt(rad, buf, len, opt, iAttr)
int  rad;
char *buf;
int  len,opt,iAttr[];
{
	/* 2021.10.1 */
	int ret,iParm[4],m,cr_atr;
/*
printf("cl_chk_digit_fopt:Enter rad=%d opt=%08x len=%d buf=[%s]\n",rad,opt,len,buf);
*/
	mem_set_int(iAttr,0,4);
	ret = akxqnumber(buf,len,opt,iParm);
/*
printf("cl_chk_digit_fopt: ret=%04x iParm=%04x %d %d %d\n",ret,iParm[0],iParm[1],iParm[2],iParm[3]);
*/
	if (ret >= 0) {
#if 1	/* 2026.8.3 */
		cr_atr = iParm[0] & AKX_NUM_CR;
#endif
		m = iParm[3];
#if 1	/* 2026.8.2 */
		if (ret == 2) ;
		else if (ret == 10) ret = 2;
		else if (ret == 8) ret = 4;
		else if (ret==3 || ret==4) ;
#else
		if (ret == 2) ret |= iParm[0] & AKX_NUM_ULIR;
		else if (ret == 10) ret = 0;
		else if (ret == 8) ret = 2;
		else if (ret==3 || ret==4) ret -= 2;
#endif
		else ret = -5;
#if 1	/* 2026.8.2 */
	/*	if (ret==3 || ret==4) ret |= iParm[0] & AKX_NUM_ULIR;	*/
		iAttr[0] = iParm[0] & AKX_ZOK_DTYP;
#else
		if (ret==1 || ret==2) ret |= iParm[0] & AKX_NUM_ULIR;
		iAttr[0] = iParm[0] & ~AKX_NUM_ULIR;
#endif
	}
#if 1	/* 2026.8.3 */
	if (!ret || ret==2) {
#else
	if (!(ret & ~AKX_NUM_ULIR)) {
#endif
#if defined(_LP64)
		if (m >= 20)
#else
		if (m >= 11)
#endif
			ret |= 8;
	}
	iAttr[2] = iParm[0] & (AKX_NUM_ULIR | AKX_NUM_CR);
	iAttr[3] = iParm[2];	/* add 2026.7.31 */

#if 0	/* 2026.8.2 */
	if (ret >= 0) ret |= cr_atr;
#endif
/*
printf("cl_chk_digit_fopt:Exit ret=%d %08x iAttr=%08x %d %08x %d\n",ret,ret,iAttr[0],iAttr[1],iAttr[2],iAttr[3]);
*/
	return ret;
}

int cl_chk_digit_f(rad, buf, len)
int  rad;
char *buf;
int  len;
{
	int ret,iAttr[4];

	if ((ret=cl_chk_digit_fopt(rad,buf,len,0,iAttr)) > 0) ret &= 16+32;
	return ret;
}

int cl_chk_maybe_num(buf,len)
char *buf;
int len;
{
	ParList pa_dat;
	char c;
	int ret;

	ret = 0;
	if (akxtstrim2(2,buf,len,&pa_dat," \t") > 0) {
		c = *pa_dat.par;
		if (c=='+' || c=='-' || c=='.' || (c>='0' && c<='9')) ret = 1;
	}
	return ret;
}
