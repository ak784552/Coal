char version[] ="@(#) ***[V/R=7.6.0 (new)]***";

