static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************************
*																				*
*	�����ړI	�F	��r���Z����												*
*																				*
*	�֐���		�F	int cl_cmpt_comp(pAns , pOprtr , pInfoParm1 , pInfoParm2)	*
*						(O)int	*pAns											*
*						(I)char	*pOprtr											*
*						(I)tdtInfoParm *pInfoParm1								*
*						(I)tdtInfoParm *pInfoParm2								*
*																				*
*	�߂�l		�F	ERROR														*
*					NORMAL														*
*																				*
*	�����T�v	�F																*
*																				*
*********************************************************************************/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;
extern GlobalCt  *pGlobTable;
extern int giOptions[];
/*extern tdtIterate_ctl gtIter_ctl[];*/

static char *Enzan[]={
	"EQ","iEQ","==","=","",
	"NE","iNE","!=","<>","><","",
	"GT","iGT",">","",
	"LT","iLT","<","",
	"GE","iGE",">=","=>","",
	"LE","iLE","<=","=<","",
	"LIKE","iLIKE","",
	"IN","iIN","",
	"INSTR","INiSTR","INrSTR","INirSTR","",
	"REGEX","iREGEX","",
	"SKIP_OPT","",
	NULL};
static unsigned char jg[6][3]={
	{0,1,0},
	{1,0,1},
	{0,0,1},
	{1,0,0},
	{0,1,1},
	{1,1,0}};

/********************************************/
/*											*/
/********************************************/
int cl_get_comp_judge(opr,result)
int opr,result;
{
	int i;

	if (result < 0) i = 0;
	else if (result > 0) i = 2;
	else i = 1;
	return jg[opr][i];
}

/********************************************/
/* opt : 0x01 : �G���[���b�Z�[�W���o�͂���B*/
/*       0x10 : LIKE�ȍ~�����Z�q�Ƃ���B	*/
/* �ԋp : >=0 : ���Z�q����					*/
/*        < 0 : ���Z�q�Ȃ�					*/
/********************************************/
int _get_comp_no(pOprtr,opt)
char *pOprtr;
int opt;
{
	int i,opr;
	opr = akxs_seqr_str(Enzan,-1,pOprtr,0x11);
	if (!(opt & 0x10) && opr>=7) opr = 0;
	if (!opr) {
		if (opt & 0x01) {
			/* cl_cmpt_comp: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"cl_cmpt_comp",pOprtr);
		}
		opr = -1;
	}
	else opr--;
	return opr;
}

/****************************************/
/*	opt : 0x0001 : ignore case			*/
/*	      0x4000 : comp string			*/
/****************************************/
int _memcmplen(p1,len1,p2,len2,opt)
char *p1,*p2;
int  len1,len2,opt;
{
	/* 2024.7.7 */
	return akxmemcmplen(p1,len1,p2,len2,opt);
}

/****************************************/
/*										*/
/****************************************/
static int _comp_array(pAns,pOprtr,pInfoParm1,pInfoParm2,cmp_opt)
long *pAns;
char *pOprtr;
tdtInfoParm	*pInfoParm1;
tdtInfoParm	*pInfoParm2;
int cmp_opt;
{
	tdtInfoParm *ppParm[6],Info,Info1;

	cl_set_parm_char(&Info1,pOprtr,strlen(pOprtr));
	cl_null_parm(&Info);
	ppParm[0] = pInfoParm1;
	/* 2023.12.17 */
	ppParm[1] = pInfoParm2;
	ppParm[2] = &Info;
	ppParm[3] = &Info1;
	return cl_array_ope_opt(pAns,4,ppParm,D_FUC_ARRAY_CMP,cmp_opt);
}

/****************************************/
/*										*/
/****************************************/
static int _comp_range(ppAns,pOprtr,opr,nr,ppParm1,ppParm2)
char **ppAns,*pOprtr;
int opr,nr;
tdtInfoParm *ppParm1[],*ppParm2[];
{
	int ret,i,lVal;
	tdtInfoParm *pInfoParm1,*pInfoParm2;

	ret = 0;
	for (i=0;i<nr;i++) {
		pInfoParm1 = ppParm1[i];
		pInfoParm2 = ppParm2[i];
		pInfoParm1->pi_alen &= ~(D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA);
		pInfoParm2->pi_alen &= ~(D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA);
		pInfoParm1->pi_scale &= ~D_DATA_IMAGE;
		pInfoParm2->pi_scale &= ~D_DATA_IMAGE;
		if ((ret=cl_cmpt_comp(ppAns,pOprtr,pInfoParm1,pInfoParm2,0,NULL)) < 0) break;
		if (nr > 1) {
			memcpy(&lVal,*ppAns,sizeof(long));
/*
printf("_comp_range: i=%d lVal=%d\n",i,lVal);
*/
			if ((!opr && !lVal) || (opr && lVal)) break;
		}
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
static int _comp_range_complex(ppAns,pOprtr,opr,pInfoParm1,pInfoParm2)
char **ppAns,*pOprtr;
int opr;
tdtInfoParm *pInfoParm1,*pInfoParm2;
{
	tdtInfoParm *ppParm1[3],tInfo1[3],*ppParm2[3],tInfo2[3],tComplex1,tComplex2;
	int ret,rc,iCMPLX1,iCMPLX2,iIMAGE1,iIMAGE2,iRANGE1,iRANGE2,iVal[2],nr1,nr2,i,result;
	char *dat1,*dat2,*pStr;
	long *pAns;

	iCMPLX1 = pInfoParm1->pi_alen & D_AULN_COMPLEX_DATA;
	iCMPLX2 = pInfoParm2->pi_alen & D_AULN_COMPLEX_DATA;
	iIMAGE1 = pInfoParm1->pi_scale & D_DATA_IMAGE;
	iIMAGE2 = pInfoParm2->pi_scale & D_DATA_IMAGE;
	iRANGE1 = pInfoParm1->pi_alen & D_AULN_RANGE_DATA;
	iRANGE2 = pInfoParm2->pi_alen & D_AULN_RANGE_DATA;
/*
printf("_comp_range_complex: iCMPLX1=%d iCMPLX2=%d iIMAGE1=%d iIMAGE2=%d\n",
iCMPLX1,iCMPLX2,iIMAGE1,iIMAGE2);
printf("_comp_range_complex: iRANGE1=%d iRANGE2=%d\n",iRANGE1,iRANGE2);
*/
	if (iCMPLX1 || iCMPLX2 || iIMAGE1 || iIMAGE2) {
		if (!iCMPLX1) {
			_set_complex(&tComplex1,pInfoParm1);
			pInfoParm1 = &tComplex1;
			iCMPLX1 = 1;
		}
		if (!iCMPLX2) {
			_set_complex(&tComplex2,pInfoParm2);
			pInfoParm2 = &tComplex2;
			iCMPLX2 = 1;
		}
	}
	ret = 0;
	if ((iCMPLX1 && iCMPLX2) || (iRANGE1 && iRANGE2)) {
		ppParm1[0] = &tInfo1[0];
		ppParm1[1] = &tInfo1[1];
		ppParm1[2] = &tInfo1[2];
		if ((nr1=cl_get_range_info(pInfoParm1,ppParm1,iVal,0)) < 0) return nr1;
		ppParm2[0] = &tInfo2[0];
		ppParm2[1] = &tInfo2[1];
		ppParm2[2] = &tInfo2[2];
		if ((nr2=cl_get_range_info(pInfoParm2,ppParm2,iVal,0)) < 0) return nr2;
	}
	if (iCMPLX1 || iCMPLX2 || iIMAGE1 || iIMAGE2) {
		if ((iCMPLX1 && iCMPLX2) || (iIMAGE1 && iIMAGE2)) {
			if (opr==0 || opr==1) {
				ret = DEF_ZOK_BINA;
				if (!(result = nr1 - nr2)) {
					if (iCMPLX1)
						rc = _comp_range(ppAns,pOprtr,opr,nr1,ppParm1,ppParm2);
					else {
						ppParm1[0] = &tInfo1[0];
						ppParm2[0] = &tInfo2[0];
						cl_gx_copy_info(ppParm1[0],pInfoParm1);
						cl_gx_copy_info(ppParm2[0],pInfoParm2);
						rc = _comp_range(ppAns,pOprtr,opr,1,ppParm1,ppParm2);
					}
					return rc;
				}
			}
			else ret = -1;
		}
		else {
#if 1
			result = 1;
			ret = DEF_ZOK_BINA;
#else
			if (iCMPLX1) dat1 = FORMAT(635);
			else if (iIMAGE1) dat1 = FORMAT(639);
			else dat1 = FORMAT(638);
			if (iCMPLX2) dat2 = FORMAT(635);
			else if (iIMAGE2) dat2 = FORMAT(639);
			else dat2 = FORMAT(638);
			ret = -2;
#endif
		}
	}
	else if (iRANGE1 || iRANGE2) {
		if (iRANGE1 && iRANGE2) {
			if (opr==0 || opr==1) {
				ret = DEF_ZOK_BINA;
				if (nr1==3 && _is_1(ppParm1[2])) nr1 = 2;
				if (nr2==3 && _is_1(ppParm2[2])) nr2 = 2;
				if (!(result = nr1 - nr2))
					return _comp_range(ppAns,pOprtr,opr,nr1,ppParm1,ppParm2);
			}
			else ret = -1;
		}
		else {
			dat1 = FORMAT(597);	/* ��ʕϐ��܂��͒萔 */
			dat2 = FORMAT(134);	/* �͈͎w�� */
			if (iRANGE1) {
				pStr = dat1;
				dat1 =dat2;
				dat2 = pStr;
			}
			ret = -2;
		}
	}
	if (ret == DEF_ZOK_BINA) {
		if (result<0) i = 0;
		else if (result>0) i = 2;
		else i = 1;
		pStr = *ppAns;
		pAns = (long *)pStr;
		*pAns = jg[opr][i];
/*
printf("_comp_range_complex: opr=%d, result=%d\n",opr,result);
*/
	}
	else if (ret < 0) {
		if (ret == -1) {
				/* cl_cmpt_comp: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"_comp_range_complex",pOprtr);
		}
		else {
				/* %s: �f�[�^���(����=%s �E��=%s)�������Ă��܂���B*/
			ERROROUT3(FORMAT(637),"_comp_range_complex",dat1,dat2);
		}
		ret = ECL_SCRIPT_ERROR;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
/* 2025.11.24 */
int cl_cmpt_comp(ppAns,pOprtr,pInfoParm1,pInfoParm2)
char		**ppAns;
char		*pOprtr;
tdtInfoParm	*pInfoParm1;
tdtInfoParm	*pInfoParm2;
{
	return cl_cmpt_comp_opt(ppAns,pOprtr,pInfoParm1,pInfoParm2,0);
}

/****************************************************/
/* cmp_opt : DEF_ZOK_DATA : �f�[�^���[�h�ɂ���B	*/
/****************************************************/
/* 2025.11.24 */
int cl_cmpt_comp_opt(ppAns,pOprtr,pInfoParm1,pInfoParm2,cmp_opt)
char **ppAns,*pOprtr;
tdtInfoParm *pInfoParm1,*pInfoParm2;
int cmp_opt;
{
	static char *_fn_="cl_cmpt_comp_opt";
	int    rc,atr1,atr2,result,len1,len2,like,opt,mflg,flags[2],ex_opt2x01;
	long   Val1z[NMPA_LONG],Val2z[NMPA_LONG],*Val1,*Val2;
	long   Value1,Value2,*pAns;
	ulong  uValue1,uValue2;
	int    ope,parm[6],nparm,iDATA1,iDATA2,iUNSIGNED1,iUNSIGNED2,iERROUT;
	double dVal1,dVal2;
	char   *dat1,*dat2,id1,id2,*pStr,id;
	char   errbuf[256];
	MPA *mpa1,*mpa2,*mpa,ma1z,ma2z,*ma1,*ma2;
	tdtInfoParm **ppParm,*pParm,InfoParmW,*ppParm0[PM_MAX];
	int opr,i;
/*
printf("%s: pOprtr=[%s] cmp_opt=%08x\n",_fn_,pOprtr,cmp_opt);
*/
DEBUGOUT_InfoParm(110,"%s:1: pOprtr=[%s]",pInfoParm1,_fn_,pOprtr);
DEBUGOUT_InfoParm(110,"%s:2:",pInfoParm2,_fn_,0);

	pStr = *ppAns;
	pAns = (long *)pStr;
	*pAns = 0;
	rc = NORMAL;
	id1 = pInfoParm1->pi_id;
	id2 = pInfoParm2->pi_id;
	iERROUT = !(cmp_opt & D_COMP_OPT_NOERROR);
	if (!id1 || !id2) {
		opt = 0;
		if (iERROUT) opt = 1;
		if ((opr=_get_comp_no(pOprtr,opt)) < 0) return ECL_SCRIPT_ERROR;
		result = id1 - id2;
		if (result<0) i = 0;
		else if (result>0) i = 2;
		else i = 1;
		*pAns = jg[opr][i];
		return DEF_ZOK_BINA;
	}

	opr = _get_comp_no(pOprtr,0);
/*
printf("%s: opr=%d id1=[%c] id2=[%c]\n",_fn_,opr,id1,id2);
*/
	atr1 = pInfoParm1->pi_attr;
	atr2 = pInfoParm2->pi_attr;
	len1 = pInfoParm1->pi_dlen;
	len2 = pInfoParm2->pi_dlen;

#if 1	/* 2026.9.15 */
	id = '-';
	if (opr<0 && id1==' ' && strchr(" RALN",id2)) id = ' ';
	else if ((id1==' ' && len1==0) || (id2==' ' && len2==0)) id = ' ';
	else if (strchr("RA",id1) && strchr("RA",id2)) id = 'R';
	else if (id1==' ' && id2==' ') {
		if (atr1==DEF_ZOK_BULK || atr2==DEF_ZOK_BULK) ;
		else id = ' ';
	}
	else if (id1 == id2) id = id1;
#else
	if (opr<0 && id1==' ' && strchr(" RALN",id2)) ;
	/* 2021.11.24 */
	else if ((id1==' ' && len1==0) || (id2==' ' && len2==0)) ;
	else if (strchr("RA",id1) || strchr("RA",id2)) ;
	else if (id1 != id2) {
		/* %s: ���ӂ̃f�[�^�h�c(id1=%c id2=%c)�������Ă��܂���B */
		if (iERROUT) ERROROUT3(FORMAT(241),_fn_,id1,id2);
		return ECL_SCRIPT_ERROR;
	}
#endif
	if (cmp_opt & DEF_ZOK_DATA) {
		iDATA1 = 1;
		iDATA2 = 1;
	}
	else {
		iDATA1 = pInfoParm1->pi_aux[0] & DEF_ZOK_DATA;
		iDATA2 = pInfoParm2->pi_aux[0] & DEF_ZOK_DATA;
	}
	dat1 = pInfoParm1->pi_data;
	dat2 = pInfoParm2->pi_data;
#if 1	/* 2026.9.15 */
/*
printf("%s: id=[%c] id1=[%c] attr1=%d id2=[%c] attr2=%d\n",_fn_,id,id1,atr1,id2,atr2);
*/
  if (id == ' ') {
#else
  if (id1 == ' ') {
#endif
	/* 2025.4.2 */
	if ((pInfoParm1->pi_alen & D_AULN_RATIONAL) || (pInfoParm2->pi_alen & D_AULN_RATIONAL)) {
		if (rc=cl_rational_comp(ppAns,pOprtr,opr,pInfoParm1,pInfoParm2)) return rc;
	}
	if (rc=_comp_range_complex(ppAns,pOprtr,opr,pInfoParm1,pInfoParm2)) return rc;
	iUNSIGNED1 = iUNSIGNED2 = 0;
	if (atr1 == DEF_ZOK_BINA) iUNSIGNED1 = pInfoParm1->pi_scale & D_DATA_UNSIGNED;
	if (atr2 == DEF_ZOK_BINA) iUNSIGNED2 = pInfoParm2->pi_scale & D_DATA_UNSIGNED;
	if (opr >= 0) {
		ex_opt2x01 = cl_get_option(2,0) & 0x01;
		if ((atr1==DEF_ZOK_CHAR && !len1) || (atr2==DEF_ZOK_CHAR && !len2) ||
		    (atr1==atr2) ||
		    ((atr1==DEF_ZOK_BINA || atr1==DEF_ZOK_FLOA || atr1==DEF_ZOK_DECI || atr1==DEF_ZOK_DATE) &&
		     (atr2==DEF_ZOK_BINA || atr2==DEF_ZOK_FLOA || atr2==DEF_ZOK_DECI || atr2==DEF_ZOK_DATE))) {
			;
		}
		else if (!ex_opt2x01 && atr1!=DEF_ZOK_BULK && atr2!=DEF_ZOK_BULK) {
			if (atr1 == 1) {
				pInfoParm1 = &InfoParmW;
				if ((rc=cl_conv_const_n_str(pInfoParm1, dat1, len1)) < 0) return rc;
				atr1 = pInfoParm1->pi_attr;
				len1 = pInfoParm1->pi_dlen;
				dat1 = pInfoParm1->pi_data;
				if (atr1 == DEF_ZOK_BINA) iUNSIGNED1 = pInfoParm1->pi_scale & D_DATA_UNSIGNED;
			}
			else if (atr2 == 1) {
				pInfoParm2 = &InfoParmW;
				if ((rc=cl_conv_const_n_str(pInfoParm2, dat2, len2)) < 0) return rc;
				atr2 = pInfoParm2->pi_attr;
				len2 = pInfoParm2->pi_dlen;
				dat2 = pInfoParm2->pi_data;
				if (atr2 == DEF_ZOK_BINA) iUNSIGNED2 = pInfoParm2->pi_scale & D_DATA_UNSIGNED;
			}
		}
		else {
/*
printf("%s: attr1 = %d, attr2 = %d\n",_fn_,atr1,atr2);
*/
			/* ���ӂ̌^(attr1=%d attr2=%d)�������Ă��܂���B */
			if (iERROUT) ERROROUT3(FORMAT(242),_fn_,atr1,atr2);
			*pAns = 0;
			if (ex_opt2x01) rc = ECL_SCRIPT_ERROR;
			else rc = DEF_ZOK_BINA;
			return rc;
		}
/*
printf("%s: attr1=%d, len1=%d\n",_fn_,atr1,len1);
printf("%s: attr2=%d, len2=%d\n",_fn_,atr2,len2);
*/
		if ((atr1 == DEF_ZOK_BINA || atr1 == DEF_ZOK_FLOA || atr1==DEF_ZOK_DECI) &&
		    (atr2 == DEF_ZOK_BINA || atr2 == DEF_ZOK_FLOA || atr2==DEF_ZOK_DECI)) {
			if (len1==0 || dat1==NULL) {
				if (iERROUT) ERROROUT1(FORMAT(243),FORMAT(248));	/* ���p�����[�^���k���ł��B */
				return ECL_SCRIPT_ERROR;
			}
			if (len2==0 || dat2==NULL) {
				if (iERROUT) ERROROUT1(FORMAT(243),FORMAT(249));	/* ���p�����[�^���k���ł��B */
				return ECL_SCRIPT_ERROR;
			}
			mpa1 = (MPA *)dat1;
			mpa2 = (MPA *)dat2;
			if (atr1 == DEF_ZOK_BINA) {
				Value1 = cl_get_data_long(pInfoParm1);
				uValue1 = Value1;
			}
			else if (atr1 == DEF_ZOK_FLOA)
				memcpy(&dVal1, dat1, sizeof(double));
			if (atr2 == DEF_ZOK_BINA) {
				Value2 = cl_get_data_long(pInfoParm2);
				uValue2 = Value2;
			}
			else if (atr2 == DEF_ZOK_FLOA)
				memcpy(&dVal2, dat2, sizeof(double));
			if (atr1 == DEF_ZOK_FLOA || atr2 == DEF_ZOK_FLOA) {
				if (atr1 == DEF_ZOK_BINA) {
					if (iUNSIGNED1) dVal1 = uValue1;
					else dVal1 = Value1;
				}
				else if (atr1 == DEF_ZOK_DECI) m_dset(&dVal1,mpa1);
				if (atr2 == DEF_ZOK_BINA) {
					if (iUNSIGNED2) dVal2 = uValue2;
					else dVal2 = Value2;
				}
				else if (atr2 == DEF_ZOK_DECI) m_dset(&dVal2,mpa2);
				if (toupper(*pOprtr) == 'M') {
					if (!stricmp(pOprtr,"MAX")) dVal1 = X_MAX(dVal1,dVal2);
					else if (!stricmp(pOprtr,"MIN")) dVal1 = X_MIN(dVal1,dVal2);
					else return -1;
					memcpy(pAns,&dVal1,sizeof(double));
					return DEF_ZOK_FLOA;
				}
				else {
					if (dVal1 == dVal2)
						result = 0;
					else if (dVal1 > dVal2)
						result = 1 ;
					else
						result = -1;
				}
			}
			/* 2023.6.27 */
			else if (atr1==DEF_ZOK_DECI || atr2==DEF_ZOK_DECI ||
			         (atr1==DEF_ZOK_BINA && iUNSIGNED1) || (atr2==DEF_ZOK_BINA && iUNSIGNED2)) {
				Val1 = cl_get_tmpMPA(Val1z);
				Val2 = cl_get_tmpMPA(Val2z);
				if (atr1 == DEF_ZOK_BINA) {
					mpa1 = (MPA *)Val1;
					m_l2mpau(Value1,mpa1,iUNSIGNED1);
				}
				if (atr2 == DEF_ZOK_BINA) {
					mpa2 = (MPA *)Val2;
					m_l2mpau(Value2,mpa2,iUNSIGNED2);
				}
				result = m_cmp(mpa1,mpa2);
				if (toupper(*pOprtr) == 'M') {
					if (!stricmp(pOprtr,"MAX")) mpa = result>0 ? mpa1: mpa2;
					else if (!stricmp(pOprtr,"MIN")) mpa = result<0 ? mpa1: mpa2;
					else return -1;
					memcpy(pAns,mpa,sizeofMPA());
					return DEF_ZOK_DECI;
				}
			}
			/* 2023.6.27 */
			else {
				if (toupper(*pOprtr) == 'M') {
					if (!stricmp(pOprtr,"MAX")) Value1 = X_MAX(Value1,Value2);
					else if (!stricmp(pOprtr,"MIN")) Value1 = X_MIN(Value1,Value2);
					else return -1;
					*pAns = Value1;
					return DEF_ZOK_BINA;
				}
				else {
					if (Value1 == Value2)
						result = 0;
					else if (Value1 > Value2)
						result = 1;
					else
						result = -1;
				}
			}
		}
		else if (atr1==DEF_ZOK_DATE || atr2==DEF_ZOK_DATE) {
			ma1 = (MPA *)cl_get_tmpMPA(&ma1z);
			ma2 = (MPA *)cl_get_tmpMPA(&ma2z);
			if ((rc=cl_get_parm_date(pInfoParm1,ma1,"CMP DATE1")) < 0) return rc;
			if ((rc=cl_get_parm_date(pInfoParm2,ma2,"CMP DATE2")) < 0) return rc;
			/* 2023.4.16 */
			len1 = X_MIN(ma1->len,10);
			len2 = X_MIN(ma2->len,10);
			result = _memcmplen(ma1->num,len1,ma2->num,len2,0);
			if (toupper(*pOprtr) == 'M') {
				if (!stricmp(pOprtr,"MAX")) mpa = result>0 ? ma1: ma2;
				else if (!stricmp(pOprtr,"MIN")) mpa = result<0 ? ma1: ma2;
				else return -1;
				memcpy(pAns,mpa,sizeofMPA());
				return DEF_ZOK_DATE;
			}
		}
		else {	/* CHAR */
			/* 2022.6.4 */
			if (*pOprtr=='i' || *pOprtr=='I') opt = 1;
			else opt = 0;
/*
printf("%s: opt=%d\n",_fn_,opt);
*/
			result = _memcmplen(dat1,len1,dat2,len2,opt | 0x4000);
		}
	}
	else {
/*
printf("%s: op=[%s] len1=%d s1=[%.*s] len2=%d s2=[%.*s]\n",_fn_,pOprtr,
pInfoParm1->pi_dlen,pInfoParm1->pi_dlen,pInfoParm1->pi_data,
pInfoParm2->pi_dlen,pInfoParm2->pi_dlen,pInfoParm2->pi_data);
*/
		/* 2021.8.4 */
		if (stricmp(pOprtr,"IN") && stricmp(pOprtr,"iIN")) {
			if (atr1 != 1) {
				if ((len1=parm_to_char_tmp(pInfoParm1,&dat1,0)) < 0) return len1;
			}
			if (atr2 != 1) {
				if ((len2=parm_to_char_tmp(pInfoParm2,&dat2,0)) < 0) return len2;
			}
		}
		/* 2021.4.23 �֐����Ă΂��悤�ɕύX in cl_gx_bexp() *//* 2021.4.25 ���ɖ߂� */
		mflg = (pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX) ? D_COMP_OPT_NEW_LEX : 0;
		opt = 0;
		if (!stricmp(pOprtr,"LIKE")||(opt=!stricmp(pOprtr,"iLIKE"))) {
			opt |= cmp_opt & D_COMP_OPT_IGN_HZ;
			if (cmp_opt & D_COMP_FUN_REVERCE)  opt |= 0x10;
			if (cmp_opt & D_COMP_OPT_LNGMATCH) opt |= 0x20;
			rc = akxs_xlike(dat1,len1,dat2,len2,opt);
			if (rc < 0) return rc;
			else if (rc > 0) result = 0;	/* unmatch */
			else result = 1;	/* match */
			*pAns = result;
			atr1 = DEF_ZOK_BINA;
		}
		/* 2025.11.24 */
		else if (!stricmp(pOprtr,"INSTR")||(opt=!stricmp(pOprtr,"INiSTR"))) {
/*
printf("%s: opt=%d\n",_fn_,opt);
*/
			*pAns = akxs_in_mem_opt(dat1,len1,dat2,len2,opt+mflg);
			atr1 = DEF_ZOK_BINA;
		}
		else if (!stricmp(pOprtr,"INrSTR")||(opt=!stricmp(pOprtr,"INirSTR"))) {
/*
printf("%s: R opt=%d\n",_fn_,opt);
*/
			*pAns = akxs_in_mem_opt(dat1,len1,dat2,len2,opt+0x10+mflg);	/* 2 -> 0x10 */
			atr1 = DEF_ZOK_BINA;
		}
		else if (!stricmp(pOprtr,"INSTRCHARS")) {
/*
printf("%s: CHARS opt=%d\n",_fn_,opt);
*/
			*pAns = akxs_in_mem_chars(dat1,len1,dat2,mflg);
			atr1 = DEF_ZOK_BINA;
		}
		else if (!stricmp(pOprtr,"REGEX")||(opt=!stricmp(pOprtr,"iREGEX"))) {
			flags[0] = REG_EXTENDED;
			if (opt) flags[0] |= REG_ICASE;
			flags[1] = 0;
			if (*dat1 || !*dat2) {
				rc = akxs_regex(dat2,dat1,0,NULL,flags,sizeof(errbuf),errbuf);
/*
printf("%s: regex rc=%d\n",_fn_,rc);
*/
				if (rc && rc!=REG_NOMATCH) {
					if (iERROUT) ERROROUT1(FORMAT(244),errbuf);	/* REGEX: %s */
					return ECL_SCRIPT_ERROR;
				}
				else rc = rc ? 0 : 1;
			}
			else if (!strcmp(dat2,"()")) rc = 1;
			else rc = 0;
			*pAns = rc;
			atr1 = DEF_ZOK_BINA;
		}
		else if (!stricmp(pOprtr,"SKIP_OPT")) {
			opt = (pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX) ? 0x10 : 0;	/* 0x04 -> 0x10 */
			rc = akx_skip_opt(dat1,len1,dat2,opt|0x08);
			len1 = akxqmlen(dat1,len1);
			if (rc >= len1) rc = 0;
			else rc++;
			*pAns = rc;
			atr1 = DEF_ZOK_BINA;
		}
		else {
			/* %s: ���Z�q(%s)�Ɍ�肪����܂��B */
			if (iERROUT) ERROROUT2(FORMAT(245),_fn_,pOprtr);
			atr1 = ECL_SCRIPT_ERROR;
		}
		return atr1;
	}
  }
#if 1	/* 2026.9.15 */
  else if (id=='L' || id=='N') {
#else
  else if (id1=='L' || id1=='N') {
#endif
		parm[0] = parm[1] = 0;
		parm[2] = -1;
		if ((rc=cl_comp_list(pOprtr,pInfoParm1,pInfoParm2,parm,cmp_opt)) >= 0) {
			*pAns = rc;
			rc = DEF_ZOK_BINA;
		}
		return rc;
  }
#if 1	/* 2026.9.15 */
  else if ((id=='A' || id=='R') && iDATA1 && iDATA2) {
#else
  else if ((id1=='A' || id1=='R') && (id2=='A' || id2=='R') && iDATA1 && iDATA2) {
#endif
		if ((rc=_comp_array(pAns,pOprtr,pInfoParm1,pInfoParm2,cmp_opt)) >= 0)
			 rc = DEF_ZOK_BINA;
		return rc;
  }
  else {
		*pAns = 0;
		if (opr < 0) {
			/* %s: ���Z�q(%s)�Ɍ�肪����܂��B */
			if (iERROUT) ERROROUT2(FORMAT(245),_fn_,pOprtr);
			return ECL_SCRIPT_ERROR;
		}
		if (id1 != id2) {
			/* %s: ���ӂ̃f�[�^�h�c(id1=%c id2=%c)�������Ă��܂���B */
			if (iERROUT) ERROROUT3(FORMAT(241),_fn_,id1,id2);
			if (ex_opt2x01) return ECL_SCRIPT_ERROR;
		}
		else if (atr1 != atr2) {
			/* ���ӂ̌^(attr1=%d attr2=%d)�������Ă��܂���B */
			if (iERROUT) ERROROUT3(FORMAT(242),_fn_,atr1,atr2);
			if (ex_opt2x01) return ECL_SCRIPT_ERROR;
		}
		opt = 0;
/*
printf("%s: attr1=%d, len1=%d dat1=[%s]\n",_fn_,atr1,len1,pInfoParm1->pi_data);
printf("%s: attr2=%d, len2=%d dat2=[%s]\n",_fn_,atr2,len2,pInfoParm2->pi_data);
*/
		result = _memcmplen(dat1,len1,dat2,len2,opt);
		if (!result) {
			if (id1 == 'I') {
				result = pInfoParm1->pi_len - pInfoParm2->pi_len;
			}
		}
  }
	if (result<0) i = 0;
	else if (result>0) i = 2;
	else i = 1;
	*pAns = jg[opr][i];
/*
printf("%s: opr=%d, result=%d\n",_fn_,opr,result);
*/

	return DEF_ZOK_BINA;
}

/****************************************/
/*										*/
/****************************************/
int _get_nparm_opt(nparm,ppParm,popt)
tdtInfoParm **ppParm;
int nparm,*popt;
{
	tdtInfoParm *pInfoParm,tInfoParm;
	int opt;

	opt = 0;
	pInfoParm = ppParm[nparm-1];
	if (pInfoParm->pi_attr == DEF_ZOK_BINA) {
		opt = cl_get_data_int(pInfoParm);
		nparm--;
/*
printf("_get_nparm_opt: nparm=%d opt=%d\n",nparm,opt);
*/
	}
	*popt = opt;
	return nparm;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_comp(ppWork,pOperator,nparm,ppParm,ope)
char **ppWork;
char *pOperator;
tdtInfoParm **ppParm;
int nparm,ope;
{
	tdtInfoParm *pInfoParm,tInfoParm;
	int  i,len1,len2,iRc,pos[2],attr,opt,pos_min,pos_max,lenm,i1,optw;
	char *pWork;
	char ww[64],*pp[2],*pp0,*p,c;
	int  rc,atr1,atr2,iAttr[4],result,iVal,Val1[2];
	long lVal1z[NMPA_LONG],lVal2z[NMPA_LONG],*lVal1,*lVal2;
	long Value1,Value2;
	double  dValue1,dValue2,dVal;
	char    op;
	char    errbuf[256];
	MPA     *mpa1,*mpa2,*mpa,ma1z,ma2z,*ma1,*ma2;
	parmList pList;
	tdtLike *plike;
	ParList3 par3;
/*
printf("cl_func_comp: pOperator=[%s] ope=%d nparm=%d\n",pOperator,ope,nparm);
*/
/*	pGlobTable->error = 0;	del 2023.8.27 �����ł̓N���A���Ȃ� */
	pWork = *ppWork;
	iRc = attr = opt = 0;
	pInfoParm = ppParm[0];
	if (cl_check_data_id(pInfoParm,0x04) < 0) return ECL_SCRIPT_ERROR;	/* 'U'/'\0'*/
	if (ope==D_FUC_IN && pInfoParm->pi_id==' ' && ((atr1=pInfoParm->pi_attr)>=2 && atr1<=4)) {
		iRc = cl_in_number(ppWork,pInfoParm,nparm-1,ppParm+1,0);
		return iRc;
	}
	lVal1 = cl_get_tmpMPA(lVal1z);
	lVal2 = cl_get_tmpMPA(lVal2z);
	switch (ope) {
	case D_FUC_ILIKE:
		opt++;
	case D_FUC_LIKE:
/*
printf("cl_func_comp: opt=%d nparm=%d\n",opt,nparm);
*/
		pp[1] = ww + 32;
		if ((i1=cl_get_str_pos(nparm,ppParm,0,&par3,NULL,"LIKEs")) < 0) return i1;
		pp[0] = par3.par;
		len1 = par3.parlen;
		if (i1 < nparm-1) {
			nparm = _get_nparm_opt(nparm,ppParm,&optw);
			opt |= optw & 0xff;
		}
		/* 2022.3.29 */
		if (!(plike = akxs_xlike_new(0,opt))) return -1;
		if ((iRc=akxs_xlike_set_line(plike,pp[0],len1)) < 0) i1 = nparm;
		for (i=i1;i<nparm;i++) {
			pp[1] = NULL;
			if ((iRc=parm_to_char(ppParm[i],&pp[1],NULL)) < 0) break;
			len2 = iRc;
/*
printf("cl_func_comp: i=%d len2=%d pp[1]=[%s]\n",i,len2,pp[1]);
*/
			if ((iRc=akxs_xlike_set_pat(plike,pp[1],len2)) < 0) break;
			iRc = akxs_pxlike(plike,NULL);
/*
printf("cl_func_comp: i=%d iRc=%d\n",i,iRc);
*/
			if (!iRc) break;
		}
		akxs_xlike_free(plike);
		if (iRc < 0) return iRc;
		iRc = iRc ? 0 : i-i1+1;
		memcpy(pWork,&iRc,sizeof(int));
		iRc = DEF_ZOK_BINA;
		break;
	case D_FUC_INIRSTR:
		opt |= D_COMP_FUN_IGNORE;	/* opt++;*/
	case D_FUC_INRSTR:
		opt |= D_COMP_FUN_REVERCE;	/* opt++;*/
	case D_FUC_INISTR:
	case D_FUC_IIN:
		opt |= D_COMP_FUN_IGNORE;	/* opt++;*/
	case D_FUC_INSTR:
	case D_FUC_IN:
		opt += (pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX) ? D_COMP_OPT_NEW_LEX : 0;
		if (ope==D_FUC_IIN || ope==D_FUC_IN) opt += D_COMP_FUN_IN;
		/* 2021.5.29 */
		iRc = cl_in_string(ppWork,nparm,ppParm,opt);
		break;
	/* 2025.7.3 */
	case D_FUC_INSTRCHARS:
		iRc = cl_in_str_chars(ppWork,nparm,ppParm);
		break;
	/* 2025.3.28 ==> cl_gx_func_bexp() */
	case D_FUC_IREGEX:
		opt++;
	case D_FUC_REGEX:
		Val1[0] = REG_EXTENDED;
		if (opt) Val1[0] |= REG_ICASE;
		Val1[1] = 0;
		pp[1] = &ww[32];
		if ((i1=cl_get_str_pos(nparm,ppParm,0,&par3,NULL,"REGEXs")) < 0) return i1;
		pp[0] = par3.par;
		len1 = par3.parlen;
		if (i1 < nparm-1) {
			nparm = _get_nparm_opt(nparm,ppParm,&optw);
			opt |= optw & 0x01;
		}
		pp0 = strmemk(pp[0],len1,"cl_func_comp");
/*
printf("cl_func_comp: opt=%1d Val1[0]=%02x pp0=[%s] len1=%d\n",opt,Val1[0],pp0,len1);
*/
		for (i=i1;i<nparm;i++) {
			if ((iRc=parm_to_char(ppParm[i],&pp[1],NULL)) < 0) goto Err;
/*
printf("cl_func_comp:                  pp[%d]=[%s]\n",i,pp[1]);
*/
			if (*pp[0] || !*pp[1]) {
				iRc = akxs_regex(pp[1],pp0,0,NULL,Val1,sizeof(errbuf),errbuf);
/*
printf("cl_func_comp: regex iRc=%d\n",iRc);
*/
				if (iRc && iRc!=REG_NOMATCH) {
					ERROROUT1(FORMAT(244),errbuf);	/* REGEX: %s */
					iRc = -1;
					goto Err;
				}
			}
			else if (!strcmp(pp[1],"()")) iRc = 0;
			else iRc = 1;
			if (!iRc) break;
		}
		iRc = iRc ? 0 : i-i1+1;
		memcpy(pWork,&iRc,sizeof(int));
		iRc = DEF_ZOK_BINA;
		break;
	case D_FUC_SKIP_OPT:
		opt = (pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX) ? 0x04 : 0;
		opt |= 0x08;
		pp[1] = ww + 32;
		if ((i1=cl_get_str_pos(nparm,ppParm,0,&par3,pos,"SKIP_OPT")) < 0) return i1;
		pp[0] = par3.par;
		Val1[0] = par3.parlen;
		lenm = par3.parlen2;
		if (nparm <= i1) {
			ERROROUT1(FORMAT(42),"cl_func_comp");	/* %s: �p�����[�^������܂���B*/
			iRc = ECL_SCRIPT_ERROR;
			goto Err;
		}
		if ((iRc=parm_to_char(ppParm[i1],&pp[1],NULL)) < 0) goto Err;
		Val1[1] = iRc;
/*
printf("cl_func_comp: skip_opt: pp[0]=[%s] Val1[0]=%d i1=%d pp[1]=[%s] Val1[1]=%d lenm=%d pos=%d\n",
pp[0],Val1[0],i1,pp[1],Val1[1],lenm,pos[0]);
*/
		i1++;
		if (nparm > i1) {
			pInfoParm = ppParm[i1];
			if (pInfoParm->pi_attr==DEF_ZOK_CHAR) {
				p = pInfoParm->pi_data;
				len1 = pInfoParm->pi_dlen;
				for (i=0;i<len1;i++) {
					c = toupper(*p++);
					if (c=='I') opt |= 0x01;
					else if (c=='R') opt |= 0x02;
					else if (c=='M') opt |= 0x04;
					else if (c=='B') opt &= ~0x04;
					else if (c=='T') opt |= 0x08;
					else if (c=='N') opt &= ~0x08;
				}
			}
			else {
				opt &= 0x04;
				if (iRc=cl_get_parm_bin(pInfoParm,&iVal,"skip_opt")) goto Err;
				opt |= iVal;
			}
/*
printf("cl_func_comp: skip_opt: opt=%08x\n",opt);
*/
		}
		iRc = akx_skip_opt(pp[0],Val1[0],pp[1],opt);
/*
printf("cl_func_comp: skip_opt: iRc=%d lenm=%d pos=%d\n",iRc,lenm,pos[0]);
*/
		pos[0]--;
		if (!(pGlobTable->options[17] & 0x08)) {
			iRc += pos[0];
			lenm += pos[0];
		}
		if (!(opt & 0x02)) {
			if ((opt & 0x08) && (iRc>=lenm)) iRc = 0;
			else iRc++;
		}
		memcpy(pWork,&iRc,sizeof(int));
		iRc = DEF_ZOK_BINA;
		break;
	default:
		/* 2022.6.4 EQ���́A���Z�q�Ƃ��ď������� */
		if (i=_get_comp_no(pOperator,0) >= 0) {
			iRc = cl_cmpt_comp_opt(ppWork,pOperator,pInfoParm,ppParm[1],0);
		}
		else {
			ERROROUT2("pOperator(%s)��ope(%d)���s���ł��B",pOperator,ope);
			iRc = ECL_SCRIPT_ERROR;
		}
/*
printf("cl_func_comp: i=%d\n",i);
*/
	}
 Err:
	return iRc;
}

/********1*********2*********3*********4*********5*********6*****/
/* �@�\ : �E�؂�o�������ʒu�܂��͐؂�o�������������̂Ƃ��́A	*/
/*		    ��������̒l�ɒ�������								*/
/*		  �E�؂�o���������́A�Ώە�����̖����𒴂��Ȃ��悤��	*/
/*		    ��������											*/
/* ���� : len_m : �Ώە�����(������)							*/
/*		  INPUT : pos[]											*/
/*				  pos[0] : �؂�o�������ʒu(�擪��1������)		*/
/*						   ���̂Ƃ��́A��������̈ʒu�ƂȂ�		*/
/*				  pos[1] : �؂�o��������						*/
/*						 �E���̂Ƃ��́A�؂�o�������ʒu���疖��	*/
/*						   �܂ł̕�����������������̂ƂȂ�		*/
/*						   INT_MIN�̂Ƃ��́Apos[1]���ȗ����ꂽ	*/
/*						   ���̂ƌ��Ȃ�							*/
/*						 �E�؂�o�������̖������Ώە�����̖���	*/
/*						   �𒴂���Ƃ��́A�Ώە�����̖����܂�	*/
/*						   �ƂȂ�								*/
/*				  n      : pos[]�̐ݒ萔�An==1�̂Ƃ��̂݁Apos[1]*/
/*						   ���ȗ����ꂽ���ƂɂȂ�				*/
/*				  opt    : 0x01 : �J�n�ʒu�����̂Ƃ��A0�Ƃ���	*/
/*						   0x02 : �����������̂Ƃ��A0�Ƃ���		*/
/*		  OUTPUT : pos[] : ������̒l							*/
/* �ԋp : pos[1]												*/
/****************************************************************/
int mod_pos_len(len_m,pos,n,opt)
int len_m,pos[],n,opt;
{
	int stam,subm,m;

	stam = pos[0];
	subm = pos[1];
/*
printf("mod_pos_len:Enter len_m=%d stam=%d subm=%d n=%d opt=%08x\n",len_m,stam,subm,n,opt);
*/
	/* �؂�o�������ʒu�̒��� */
	if (stam < 0) {
		if (opt & 0x01) stam = 0;
		else stam += len_m + 1;
	}
	/* �؂�o���������̒��� */
	if (n == 1) {
		if (stam>0 && stam<=len_m) subm = len_m - stam + 1;
		else subm = 0;
	}
	else if (subm == INT_MIN) subm = len_m;
	else if (stam>0 && stam<=len_m) {
		if (subm < 0) {
			if (opt & 0x02) subm = 0;
			else subm += len_m - stam + 1;
		}
		if (subm > (m=len_m-stam+1)) subm = m;
	}
/*
printf("mod_pos_len:Exit stam=%d subm=%d\n",stam,subm);
*/
	pos[0] = stam;
	pos[1] = subm;

	return subm;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/*	���� :  iParm		: iParm[0] : �Ώ�1�̔�r�J�n�ʒu				*/
/*						  iParm[1] : �Ώ�2�̔�r�J�n�ʒu				*/
/*						  iParm[2] : ��r��							*/
/*									   < 0 : �Ώۂ̍ő���܂Ŕ�r���� */
/*			cmp_opt		: ��r�I�v�V����								*/
/*							= 0x01 : ��r�Ώۂ̐����܂߂đS�Ă��A		*/
/*									 ��v�����Ƃ��A1��Ԃ�				*/
/*	�ԋp :  cmp_opt��0x01��												*/
/*			=0�̂Ƃ��A��v��											*/
/*			=1�̂Ƃ��A1/0=��v/�s��v									*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_comp_list(pOprtr,pInfoParm1,pInfoParm2,iParm,cmp_opt)
char *pOprtr;
tdtInfoParm	*pInfoParm1;
tdtInfoParm	*pInfoParm2;
int iParm[],cmp_opt;
{
	tdtInfoParm *p1,*p2;
	int i1,i2,ix1,ix2,nm,Ans,rc,nu1,nu2,match,*pAns,ret,cmp_opt2;
	tdtRbCtl *pCt1,*pCt2;
	char *nam;
/*
printf("cl_comp_list:Enter pOprtr=[%s] iParm=%d %d %d cmp_opt=%08x\n",
pOprtr,iParm[0],iParm[1],iParm[2],cmp_opt);
*/
	if ((ix1=iParm[0]) < 0) ix1 = 0;
	if ((ix2=iParm[1]) < 0) ix2 = 0;
	nm  = iParm[2];
	Ans = 0;
	pCt1 = (tdtRbCtl *)pInfoParm1->pi_data;
	pCt2 = (tdtRbCtl *)pInfoParm2->pi_data;
/*
printf("cl_comp_list: pCt1=%08x pCt2=%08x\n",pCt1,pCt2);
*/
#if 0	/* 2026.8.26 */
	/* �z�Q�Ə������`�F�b�N */
/*
printf("cl_comp_list: itc_circ_ref=%08x\n",gtIter_ctl[0].itc_circ_ref);
*/
	if (!gtIter_ctl[0].itc_circ_ref) {
		if (!(gtIter_ctl[0].itc_circ_ref=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215212104;
		if (!(gtIter_ctl[1].itc_circ_ref=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215212104;
	}
#endif
	/* �z�Q�Ƃ��`�F�b�N */
	nam = cl_gx_get_name_from_id(pInfoParm1->pi_id);
#if 1	/* 2026.8.26 */
	if ((ret=cl_gitr_circ_ref_ix(NULL,pCt1,nam,1)) == 1) return 0;
#else
	if ((ret=_iterate_circ_ref(&gtIter_ctl[0],pCt1,nam)) == 1) return 0;
#endif
	else if (ret < 0) return ret;
	nam = cl_gx_get_name_from_id(pInfoParm2->pi_id);
#if 1	/* 2026.8.26 */
	if ((ret=cl_gitr_circ_ref_ix(NULL,pCt2,nam,2)) == 1) return 0;
#else
	if ((ret=_iterate_circ_ref(&gtIter_ctl[1],pCt2,nam)) == 1) return 0;
#endif
	else if (ret < 0) return ret;
	match = 0;
	nu1 = pCt1->rb_used - ix1;
	nu2 = pCt2->rb_used - ix2;
	if (nm >= 0) {
		if (nu1 > nm) nu1 = nm;
		if (nu2 > nm) nu2 = nm;
	}
	nm = nu1;
	if (nu1 > nu2) nm = nu2;
/*
printf("cl_comp_list:nu1=%d nu2=%d nm=%d\n",nu1,nu2,nm);
*/
	if (nu1>0 && nu2>0 && (!(cmp_opt & 0x01) || nu1==nu2)) {
		akxs_rb_read(pCt1,0);
		akxs_rb_read(pCt2,0);
		while (ix1-- > 0) {
			if (!(p1=(tdtInfoParm *)akxs_rb_read(pCt1,1))) break;
		}
		while (ix2-- > 0) {
			if (!(p2=(tdtInfoParm *)akxs_rb_read(pCt2,1))) break;
		}
		cmp_opt2 = cmp_opt | DEF_ZOK_DATA | 0x01;
		while (p1=(tdtInfoParm *)akxs_rb_read(pCt1,1)) {
			if (!(p2 = (tdtInfoParm *)akxs_rb_read(pCt2,1))) break;
			pAns = &Ans;
			if ((rc=cl_cmpt_comp_opt(&pAns,pOprtr,p1,p2,cmp_opt2)) < 0) {
/*
printf("cl_comp_list:rc=%d\n",rc);
*/
				Ans = rc;
				break;
			}
			else if (!Ans) {
/*
printf("cl_comp_list:Ans=%d\n",Ans);
*/
#if 1	/* 2026.8.19 */
				if (cmp_opt & 0x01) break;
#else
				break;
#endif
			}
			else match++;
/*
printf("cl_comp_list:rc=%d Ans=%d match=%d\n",rc,Ans,match);
*/
			if (nm>0 && match>=nm) break;
		}
	}
/*
printf("cl_comp_list: cmp_opt=%08x Ans=%d match=%d\n",cmp_opt,Ans,match);
*/
#if 1	/* 2026.8.19 */
	if (cmp_opt & 0x01) {
		if (nm == match) Ans = 1;
		else Ans = 0;
	}
	else Ans = match;
#else
	if (Ans && (!(cmp_opt & 0x01))) Ans = match;
#endif
	return Ans;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
static int _mk_comp_ans(ppWork,i1,pLay,attr)
char **ppWork;
int i1,attr;
MCAT *pLay;
{
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	int iRc,n,i,ix,ilay;
	long *layer;
	char wrk[30],*p,*pAns,*fmt;

	layer = (long *)pLay->mc_bufp;
	ilay = pLay->mc_ipos - 1;
	ix = layer[ilay];
	if (!ix && !ilay) {
		if (!(pAns=cl_tmp_const_malloc(sizeof(int)))) return ECL_MALLOC_ERROR;
		memcpy(pAns,&i1,sizeof(int));
		iRc = DEF_ZOK_BINA;
/*
printf("_mk_comp_ans: Exit iRc=%d i=%d\n",iRc,i);
*/
	}
	else {
		mcat.mc_ipos = 0;
		sprintf(wrk,"%d",i1);
		akxtmcats(&mcat,wrk);
		for (i=0;i<ilay;i++) {
			sprintf(wrk," %d",layer[i]);
			akxtmcats(&mcat,wrk);
		}
		sprintf(wrk," %d",layer[ilay]-1);
		akxtmcats(&mcat,wrk);
		pAns = mcat.mc_bufp;
		iRc = DEF_ZOK_CHAR;
	}
	*ppWork = pAns;
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_string1(pInfoParm0,pInfoParm,opt)
tdtInfoParm *pInfoParm0,*pInfoParm;
int opt;
{
	int iRc,len2,opt_type;
	char *pp,wrk[12];

	if (pInfoParm->pi_id==' ') {
		pp = wrk;
		if ((iRc=parm_to_char(pInfoParm,&pp,NULL)) >= 0) {
			len2 = iRc;
			opt_type = SET_TYPE_OPT(pInfoParm0->pi_code);
			iRc = akxs_in_mem_opt(pInfoParm0->pi_data,pInfoParm0->pi_dlen,pp,len2,opt|opt_type);
/*
printf("cl_in_string1: iRc=%d\n",iRc);
*/
			if (iRc > 0) {
				if (opt & D_COMP_FUN_IN) {
					/*pInfoParm0->pi_pos = pInfoParm0->pi_len + 1*/;
				}
				else {
					if (iRc < pInfoParm0->pi_hlen) pInfoParm0->pi_hlen = iRc;
					if (iRc > pInfoParm0->pi_pos)  pInfoParm0->pi_pos  = iRc;
				}
			}
		}
	}
	else iRc = ECL_SCRIPT_ERROR;
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_string(ppWork,nparm,ppParm,opt)
char **ppWork;
tdtInfoParm **ppParm;
int nparm,opt;
{
	tdtInfoParm tInfoParm,*pInfoParm;
	int  i,len1,len2,iRc,pos[2],attr,pos_min,pos_max,lenm,i1,optw;
	char *pWork;
	char ww[64],*pp[2],*pp0,*p,c;
	int  rc,atr1,atr2,iAttr[4],result;
	ParList3 par3;

	pInfoParm = ppParm[0];
	pp[1] = ww + 32;
	if ((i1=cl_get_str_pos(nparm,ppParm,0,&par3,pos,"INSTRs")) < 0) return i1;
	pp[0] = par3.par;
	len1 = par3.parlen;
	lenm = par3.parlen2;
	if (i1 < nparm-1) {
		nparm = _get_nparm_opt(nparm,ppParm,&optw);
		opt |= (optw & D_COMP_OPT_IGN_CASE) | (optw & D_COMP_OPT_IGN_HZ);
/*
printf("cl_in_string: i1=%d opt=%08x nparm=%d\n",i1,opt,nparm);
*/
	}
/*
printf("cl_in_string: nparm=%d i1=%d opt=%08x pos=%d lenm=%d\n",nparm,i1,opt,pos[0],lenm);
*/
	pp0 = pp[0];
	/* 2020.12.29 */ /* pp0�������Ƃ��́A�r���ň�v�����ꍇ�A�S�ϊ������ʂɂȂ� */
	pos_min = lenm + 1;
	pos_max = 0;
	memset(*ppWork,0,sizeof(int));
	cl_set_parm_char2(&tInfoParm,pp0,len1,ppParm[0]->pi_code);
	tInfoParm.pi_hlen = pos_min;
	tInfoParm.pi_pos  = pos_max;
/*	tInfoParm.pi_len = i1;	*/
	tInfoParm.pi_paux = (char *)cl_in_string1;
	iRc = cl_in_number_sub(ppWork,&tInfoParm,nparm-i1,ppParm+i1,opt);
/*
printf("cl_in_string: iRc=%d\n",iRc);
*/
	if (iRc>0 && iRc != 1) {
		pos_min = tInfoParm.pi_hlen;
		pos_max = tInfoParm.pi_pos;
/*
printf("cl_in_string: pos_min=%d pos_max=%d\n",pos_min,pos_max);
*/
		if (opt & D_COMP_FUN_IN) {
			pos_min = pos_max;
		}
		else {
			if (opt & D_COMP_FUN_REVERCE) pos_min = pos_max;
			else if (pos_min == lenm+1) pos_min = 0;
			if (!(pGlobTable->options[17] & 0x01) && pos_min) pos_min += pos[0] - 1;
		}
/*
printf("cl_in_string: pos_min=%d\n",pos_min);
*/
		pWork = *ppWork;
		memcpy(pWork,&pos_min,sizeof(int));
		iRc = DEF_ZOK_BINA;
	}
	else if (!iRc) iRc = DEF_ZOK_BINA;
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*	iRc > 0 : ��v�����ԍ�												*/
/*	    = 0 : ��v���Ȃ�����											*/
/*	    < 0 : �G���[													*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_number1(pInfoParm0,pInfoParm,opt)
tdtInfoParm *pInfoParm0,*pInfoParm;
int opt;
{
	static char *msg="cl_in_number1:";
	int iRc,atr0,atr;
	long lValue0,lValue;
	double dValue0,dValue;
	MPA *ma0,maz,*ma;
	char id;

	iRc = 0;
	if (pInfoParm0->pi_id==' ' && pInfoParm->pi_id==' ') {
		if ((atr0=pInfoParm0->pi_attr) == DEF_ZOK_BINA) {
			memcpy((char *)&lValue0,pInfoParm0->pi_data,sizeof(long));
			if ((iRc=cl_get_parm_long(pInfoParm,&lValue,msg)) >= 0) {
				if (lValue0 == lValue) iRc = 1;
			}
		}
		else if (atr0 == DEF_ZOK_FLOA) {
			memcpy((char *)&dValue0,pInfoParm0->pi_data,sizeof(double));
			if ((iRc=cl_get_parm_double(pInfoParm,&dValue,msg)) >= 0) {
				if (dValue0 == dValue) iRc = 1;
			}
		}
		else if (atr0 == DEF_ZOK_DECI) {
			ma0 = (MPA *)pInfoParm0->pi_data;
			ma = (MPA *)cl_get_tmpMPA(&maz);
			if ((iRc=cl_get_parm_dec(pInfoParm,ma,msg)) >= 0) {
				if (!m_cmp(ma0,ma)) iRc = 1;
			}
		}
		else iRc = ECL_SCRIPT_ERROR;
	/*	if (iRc > 0) pInfoParm0->pi_pos = pInfoParm0->pi_len + 1;	*/
	}
	else iRc = ECL_SCRIPT_ERROR;
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_number_sub(ppAns,pInfoParm0,nparm,ppParm,opt)
char **ppAns;
tdtInfoParm *pInfoParm0,**ppParm;
int nparm,opt;
{
	int iRc,i,i1;
	int rc,max_layer;
	char id,**ppWork;
	tdtInfoParm *pInfoParm;
	int (*exfunc)();
	tdtIterate_ctl tIter_ctl;
	tdtIterate *pIter;
	MCAT2 *layer;

	max_layer = -1;
	layer = akxs_layer_new(100,cl_tmp_const_malloc,NULL);
/*
printf("cl_in_number_sub: Enter nparm=%d opt=%08x pAns=[%s]\n",nparm,opt,*ppAns);
*/
	iRc = 0;
	exfunc = (int(*)())pInfoParm0->pi_paux;
	ppWork = ppAns;
	for (i=0;i<nparm;i++) {
		if (pInfoParm = ppParm[i]) {
		/* 2025.11.24 *//* RANGE������̂ŁA���̏��������ł͕s�\�� */
		  if ((rc=cl_iterate_info_init(&tIter_ctl,NULL,pInfoParm,max_layer)) < 0) {
		      iRc = rc;
		      break;
		  }
		/* 2025.11.24 */
		  for (;;) {
			if ((rc=cl_iterate_info(&tIter_ctl)) < 0) {
				iRc = rc;
				break;
			}
			pIter = tIter_ctl.itc_pIter;
			if (!(pInfoParm=pIter->it_pInfo)) break;
			akxs_layer_set(layer,tIter_ctl.itc_layer,pIter->it_ix);
/*
printf("cl_in_number_sub: layer=%d ix=%d pInfoParm=%08x\n",tIter_ctl.itc_layer,pIter->it_ix,pInfoParm);
*/
			/* 2025.11.24 */
			if (cl_check_data_id(pInfoParm,0x04) < 0) return ECL_SCRIPT_ERROR;	/* 'U'/'\0'*/
			if (!cl_is_null_parm(pInfoParm)) {
				i1 = i + 1;
				if ((id=pInfoParm->pi_id) == ' '){
				/*	pInfoParm0->pi_len = i;	*/
					iRc = exfunc(pInfoParm0,pInfoParm,opt);
/*
printf("cl_in_number_sub: i1=%d iRc=%d\n",i1,iRc);
*/
					ppWork = NULL;
					if (iRc > 0) {
						iRc = DEF_ZOK_BINA;
						if (opt & D_COMP_FUN_IN) pInfoParm0->pi_pos = i1;
					}
				}
				else 
					iRc = ECL_SCRIPT_ERROR;
				if (iRc) {
					if (iRc>0 && (opt & D_COMP_FUN_IN) && !(opt & D_COMP_OPT_NOT_SET)) {
						iRc = _mk_comp_ans(ppAns,i1,layer,iRc);
/*
printf("cl_in_number_sub: opt=%d i1=%d pAns=[%s]\n",opt,i1,*ppAns);
*/
					}
					if (opt & D_COMP_FUN_IN) break;
				}
			}
		  }
/*
printf("cl_in_number_sub: id=[%c](%02x) iRc=%d\n",id,id,iRc);
*/
		  if (iRc) break;
		}
	}
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*	iRc > 0 : ��v�����ԍ�												*/
/*	    = 0 : ��v���Ȃ�����											*/
/*	    < 0 : �G���[													*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_number(ppAns,pInfoParm0,nparm,ppParm,opt)
char **ppAns;
tdtInfoParm *pInfoParm0,**ppParm;
int nparm,opt;
{
	tdtInfoParm tInfoParm;
	int iRc;

	memset(*ppAns,0,sizeof(int));
	tInfoParm = *pInfoParm0;
	tInfoParm.pi_paux = (char *)cl_in_number1;
	iRc = cl_in_number_sub(ppAns,&tInfoParm,nparm,ppParm,D_COMP_FUN_IN);
	if (!iRc) iRc = DEF_ZOK_BINA;
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_str_chars(ppWork,nparm,ppParm)
char **ppWork;
int nparm;
tdtInfoParm **ppParm;
{
	int iRc,i1,optw,pos[2];
	char *pWork,*str;
	ParList3 par3;

	pWork = *ppWork;
	memset(pWork,0,sizeof(int));
	if ((i1=cl_get_str_pos(nparm,ppParm,0,&par3,pos,"INSTRCHARS")) < 0) return i1;
	if (i1 < nparm-1) {
		cl_get_parm_bin(ppParm[i1+1],&optw,"INSTRCHARS.OPT");
		optw &= D_COMP_OPT_IGN_CASE | D_COMP_OPT_IGN_HZ | 0x20 | 0x40 | 0x80;
	}
	else if (i1+2 < nparm) {
		ERROROUT2(FORMAT(267),"cl_in_str_chars",nparm);	/* %s: �]���ȃp�����[�^(nparm=%d)������܂��B*/
		return ECL_SCRIPT_ERROR;
	}
	else optw = 0;
	if (pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX) optw |= D_COMP_OPT_NEW_LEX;
/*
printf("cl_in_str_chars: nparm=%d i1=%d optw=%08x\n",nparm,i1,optw);
*/
	if ((iRc=parm_to_char_tmp(ppParm[i1],&str,0)) < 0) return iRc;
	iRc = akxs_in_mem_chars(par3.par,par3.parlen,str,optw);
/*
printf("cl_in_str_chars: iRc=%d\n",iRc);
*/
	if (iRc > 0) {
		memcpy(pWork,&iRc,sizeof(int));
		iRc = DEF_ZOK_BINA;
	}
	else if (!iRc) iRc = DEF_ZOK_BINA;
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
static int to_cOperator(cOperator,ope)
char *cOperator;
int ope;
{
	int rc;

	rc = 0;
	if ((ope==D_FUC_MAX) || (ope==D_FUC_MIN)) strcpy(cOperator,"-");
	else if (ope == D_FUC_SUM) strcpy(cOperator,"+");
	else if (ope == D_FUC_PRODUCT) strcpy(cOperator,"*");
	else rc -1;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _comp_complex(pInfoParm,pInfoParm1,pInfoParm2,ope)
tdtInfoParm *pInfoParm,*pInfoParm1,*pInfoParm2;
int ope;
{
	tdtInfoParm tInfoW,tInfo1,tInfo2,*pInfo1,*pInfo2,*pInfo;
	char cOperator[2];
	int ret,sig;
	long lval,*plval;
	MPA *ma;

	if ((ret=to_cOperator(cOperator,ope)) < 0) return ret;
/*
printf("_comp_complex: cOperator=[%s]\n",cOperator);
*/
	if ((ope==D_FUC_MAX) || (ope==D_FUC_MIN)) {
		ret = cl_cmpt_complex(&tInfo1,"ABS",pInfoParm1,pInfoParm1);
		if (ret >= 0) ret = cl_cmpt_complex(&tInfo2,"ABS",pInfoParm2,pInfoParm2);
		plval = &lval;
 		if (ret >= 0) ret = cl_cmpt_comp(&plval,">",&tInfo1,&tInfo2);
		if (ret >= 0) {
			sig = lval;
 /*
printf("_comp_complex:1 sig=%d\n",sig);
*/
			if (ope == D_FUC_MIN) sig = 1 - sig;
/*
printf("_comp_complex:2 sig=%d\n",sig);
*/
			if (sig) pInfo = pInfoParm2;
			else pInfo = pInfoParm1;
			cl_gx_copy_info2(pInfoParm,pInfo);
		}
	}
	else {
		ret=cl_cmpt_complex(pInfoParm,cOperator,pInfoParm1,pInfoParm2);
	}
/*
printf("_comp_complex:Exit ret=%d\n",ret);
*/
	return ret;
}

/****************************************/
/*										*/
/****************************************/
static int _comp_rational(pInfoParm,pInfoParm1,pInfoParm2,ope)
tdtInfoParm *pInfoParm,*pInfoParm1,*pInfoParm2;
int ope;
{
	tdtInfoParm tInfoW,tInfo,*pInfo1,*pInfo2,*pInfo;
	char cOperator[2];
	int ret,sig;
	MPA *ma;

	if ((ret=to_cOperator(cOperator,ope)) < 0) return ret;

	if ((ret=cl_cmpt_math_rational(&tInfoW,cOperator,pInfoParm1,pInfoParm2)) >= 0) {
		if ((ope==D_FUC_MAX) || (ope==D_FUC_MIN)) {
			if ((ret=cl_rational_to_real(&tInfo,&tInfoW)) < 0) return ret;
			ma = (MPA *)tInfo.pi_data;
			sig = ma->sign;
/*
printf("_comp_rational:1 sig=%d\n",sig);
*/
			if (ope == D_FUC_MIN) sig = 1 - sig;
/*
printf("_comp_rational:2 sig=%d\n",sig);
*/
			if (sig) pInfo = pInfoParm2;
			else pInfo = pInfoParm1;
			cl_gx_copy_info2(pInfoParm,pInfo);
		}
		else cl_gx_copy_info2(pInfoParm,&tInfoW);
	}
/*
printf("_comp_rational:Exit ret=%d\n",ret);
*/
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_comp_info(pInfoParm,pInfoParm1,pInfoParm2,ope)
tdtInfoParm *pInfoParm,*pInfoParm1,*pInfoParm2;
int ope;
{
	int ret,rc,attr1,attr2,opt,len1,len2,attr,iUNSIG1,iUNSIG2,over_or_under;
	char *p1,*p2,copt;
	MPA *mpa1,*mpa2,ma1z,ma2z,*ma1,*ma2,*mpaW;
	double dVal1,dVal2;
	long lVal1,lVal2,lVal3,lma1z[NMPA_LONG_PRE1],lma2z[NMPA_LONG_PRE1],*Val1,*Val2;
	ulong ulVal1,ulVal2,ulVal3;
	tdtInfoParm tInfoParm1,tInfoParm2,*pInfoParm3;

DEBUGOUT_InfoParm(198,"cl_comp_info:1 ope=%d",pInfoParm1,ope,0);
DEBUGOUT_InfoParm(198,"cl_comp_info:2 ope=%d",pInfoParm2,ope,0);
/*
printf("cl_comp_info: pi_data=%08x ope=%d\n",pInfoParm->pi_data,ope);
*/
	/* 2025.3.26 */
	if ((pInfoParm1->pi_alen & D_AULN_RATIONAL) || (pInfoParm2->pi_alen & D_AULN_RATIONAL))
		return _comp_rational(pInfoParm,pInfoParm1,pInfoParm2,ope);
#if 1	/* 2026.8.3 */
	if ((pInfoParm1->pi_alen & D_AULN_COMPLEX_DATA) || (pInfoParm2->pi_alen & D_AULN_COMPLEX_DATA) ||
	    (pInfoParm1->pi_scale & D_DATA_IMAGE) || (pInfoParm2->pi_scale & D_DATA_IMAGE))
		return _comp_complex(pInfoParm,pInfoParm1,pInfoParm2,ope);
#endif
	iUNSIG1 = iUNSIG2 = ret = 0;
	attr1 = pInfoParm1->pi_attr;
	attr2 = pInfoParm2->pi_attr;
/*
printf("cl_comp_info:Enter attr1=%d attr2=%d\n",attr1,attr2);
*/
	if ((((attr1==DEF_ZOK_DATE && attr2==DEF_ZOK_DATE) ||
	      (attr1==DEF_ZOK_BULK && attr2==DEF_ZOK_BULK) ||
	      (attr1==DEF_ZOK_CHAR && attr2==DEF_ZOK_DATE) ||
	      (attr1==DEF_ZOK_DATE && attr2==DEF_ZOK_CHAR)) && (ope==D_FUC_MAX || ope==D_FUC_MIN)) ||
	    (attr1==DEF_ZOK_CHAR && attr2==DEF_ZOK_CHAR)) {
		opt = 0;
		if (attr1==DEF_ZOK_DATE || attr2==DEF_ZOK_DATE) {
			if (attr1==DEF_ZOK_CHAR || attr2==DEF_ZOK_CHAR) {
				if (attr1 == DEF_ZOK_CHAR) pInfoParm3 = pInfoParm1;
				else pInfoParm3 = pInfoParm2;
				if ((ret=cl_func_to_date(&tInfoParm1,1,&pInfoParm3)) < 0) {
							/*%s: ���t������[%s]������Ă��܂��Bret=%d */
					ERROROUT3(FORMAT(622),"cl_comp_info",pInfoParm3->pi_data,ret);
					return ECL_SCRIPT_ERROR;
				}
				if (attr1 == DEF_ZOK_CHAR) {
					pInfoParm1 = &tInfoParm1;
					attr1 = pInfoParm1->pi_attr;
				}
				else {
					pInfoParm2 = &tInfoParm1;
					attr2 = pInfoParm2->pi_attr;
				}
			}
			if (attr1 == DEF_ZOK_DATE) {
				mpa1 = (MPA *)pInfoParm1->pi_data;
				p1   = mpa1->num;
				len1 = mpa1->len;
			}
			if (attr2 == DEF_ZOK_DATE) {
				mpa2 = (MPA *)pInfoParm2->pi_data;
				p2   = mpa2->num;
				len2 = mpa2->len;
			}
		}
		else {
			p1   = pInfoParm1->pi_data;
			len1 = pInfoParm1->pi_dlen;
			p2   = pInfoParm2->pi_data;
			len2 = pInfoParm2->pi_dlen;
			if (attr1 == DEF_ZOK_CHAR) {
				if (ope==D_FUC_SUM || ope==D_FUC_PRODUCT) {
/*
printf("cl_comp_info: ope=%d\n",ope);
printf("cl_comp_info: len1=%d p1=[%s]\n",len1,p1);
if (attr2 == DEF_ZOK_CHAR)
printf("cl_comp_info: len2=%d p2=[%s]\n",len2,p2);
*/
					rc = cl_conv_const_n_str(&tInfoParm1,p1,len1);
					if (!rc) rc = cl_conv_const_n_str(&tInfoParm2,p2,len2);
					if (!rc) rc = cl_comp_info(pInfoParm,&tInfoParm1,&tInfoParm2,ope);
/*
printf("cl_comp_info:Exit2 pInfoParm->pi_attr=%d rc=%d\n",pInfoParm->pi_attr,rc);
*/
					return rc;
				}
				else opt = 0x4000;
			}
		}
/*
printf("cl_comp_info: len1=%d p1=%08x\n",len1,p1);
*/
		rc = _memcmplen(p1,len1,p2,len2,opt);
		if (((ope==D_FUC_MAX) && (rc<0)) || ((ope==D_FUC_MIN) && (rc>0)))
			pInfoParm1 = pInfoParm2;
		*pInfoParm = *pInfoParm1;
	}
	else if (attr1>=1 && attr1<=4 && attr2>=1 && attr2<=4) {
	/*	rc = 0;	*/
		/* 2023.6.24 */
		Val1 = cl_get_tmpMPA_pre1(lma1z);
		Val2 = cl_get_tmpMPA_pre1(lma2z);
		if ((attr1=cl_conv_upper2(NULL,NULL,Val1,Val2,pInfoParm1,pInfoParm2,0)) < 0) return attr1;
		attr2 = attr1;
		mpa1 = (MPA *)Val1;
		mpa2 = (MPA *)Val2;
			if (attr1 == DEF_ZOK_BINA) {
				/* 2023.6.24 */
				ulVal1 = lVal1 = Val1[0];
				ulVal2 = lVal2 = Val2[0];
				iUNSIG1 = Val1[1];
				iUNSIG2 = Val2[1];
				over_or_under = 0;
				if (iUNSIG1 | iUNSIG2) {
					if (ope==D_FUC_SUM || ope==D_FUC_PRODUCT) {
						if (ope == D_FUC_SUM) {
							ulVal3 = ulVal1 + ulVal2;
							ulVal1 = cl_chk_over_flow_ulong_add(ulVal3,ulVal1,ulVal2,"Add",&over_or_under,mpa1);
						}
						else {
							ulVal3 = ulVal1 * ulVal2;
							ulVal1 = cl_chk_over_flow_ulong_mult(ulVal3,ulVal1,ulVal2,"Mult",&over_or_under,mpa1);
						}
						if (over_or_under) {
							/* 2023.6.11 */
							cl_set_parm_mpa2(pInfoParm,mpa1,'V');
							return 0;
						}
					}
					else if (ope == D_FUC_MAX)
						ulVal1 = X_MAX(ulVal1,ulVal2);
					else
						ulVal1 = X_MIN(ulVal1,ulVal2);
					lVal1 = ulVal1;
				}
				else {
					if (ope==D_FUC_SUM || ope==D_FUC_PRODUCT) {
						if (ope == D_FUC_SUM) {
							lVal3 = lVal1 + lVal2;
							lVal1 = cl_chk_over_flow_long_add(lVal3,lVal1,lVal2,"Add",&over_or_under,mpa1);
						}
						else if (ope == D_FUC_PRODUCT) {
							lVal3 = lVal1 * lVal2;
							lVal1 = cl_chk_over_flow_long_mult(lVal3,lVal1,lVal2,"Mult",&over_or_under,mpa1);
						}
						if (over_or_under) {
/*
printf("cl_comp_info: over_or_under=%d\n",over_or_under);
*/
							cl_set_parm_mpa2(pInfoParm,mpa1,'P');
DEBUGOUT_InfoParm(198,"cl_comp_info:",pInfoParm,0,0);
							return 0;
						}
					}
					else {
						rc = lVal1 - lVal2;
						if (ope == D_FUC_MIN) rc = -rc;
						if (rc < 0) lVal1 = lVal2;
					}
				}
				cl_set_parm_long(pInfoParm,lVal1);
				if (iUNSIG1 | iUNSIG2) pInfoParm->pi_scale |= D_DATA_UNSIGNED;
			}
			else if (attr1 == DEF_ZOK_FLOA) {
				/* 2023.6.24 */
				memcpy(&dVal1,Val1,sizeof(double));
				memcpy(&dVal2,Val2,sizeof(double));
				if (ope == D_FUC_SUM) dVal1 += dVal2;
				else if (ope == D_FUC_PRODUCT) dVal1 *= dVal2;
				else {
					if (dVal1 < dVal2) rc = -1;
					else rc = 1;
					if (ope == D_FUC_MIN) rc = -rc;
					if (rc < 0) dVal1 = dVal2;
				}
				cl_set_parm_double(pInfoParm,dVal1);
			}
			else if (attr1 == DEF_ZOK_DECI) {
				if (ope == D_FUC_SUM) rc = m_add1(mpa1,mpa2);
				else if (ope == D_FUC_PRODUCT) rc = m_mul1(mpa1,mpa2);
				else {
					rc = m_cmp(mpa1,mpa2);
					if (ope == D_FUC_MIN) rc = -rc;
					if (rc < 0) mpa1 = mpa2;
				}
				/* 2025.2.28 */
/*
printf("cl_comp_info: pInfoParm->pi_attr=%d\n",pInfoParm->pi_attr);
*/
				if (pInfoParm->pi_attr == DEF_ZOK_DECI) copt = 'V';
				else copt = ' ';
				cl_set_parm_mpa2(pInfoParm,mpa1,copt);
			}
	}
	else {
				/* �p�����[�^�̌^(attr1=%d attr2=%d)�������Ă��܂���B*/
		ERROROUT3(FORMAT(242),"cl_comp_info",attr1,attr2);
		ret = ECL_SCRIPT_ERROR;
	}
/*
printf("cl_comp_info:Exit pInfoParm->pi_attr=%d ret=%d\n",pInfoParm->pi_attr,ret);
*/
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_agg_sub(pInfoParmW,nparm,ppParm,ope,pInfoParm0)
tdtInfoParm *pInfoParmW,**ppParm,*pInfoParm0;
int nparm,ope;
{
	static char *_fn_="cl_func_agg_sub";
	tdtInfoParm *pInfoParm,*pInfoParm1,*pInfoParm2,tInfoParm,tInfoParm1,***pTBL1;
	tdtArrayIndex tIndex1;
	char id,wk[2],*pWork,*p;
	int  i,k,ret,iParm[4],ix1,nm1,len1,attr,attr1,sizeofnmp,nrat;
	long lSum,lma1z[NMPA_LONG_PRE1*2],lma2z[NMPA_LONG_PRE1*2];
	ushort alen;
	tdtRbCtl *pCt;
	int max_layer;
	tdtIterate_ctl tIter_ctl;
	tdtIterate *pIter;
	MPA *mpa1,*mpa2;

	max_layer = -1;

/*	pGlobTable->error = 0;	del 2023.8.27 �����ł̓N���A���Ȃ� */
	ret = 0;
	lSum = pInfoParmW->pi_len;
/*
printf("cl_func_agg_sub:Enter ope=%d nparm=%d lSum=%d\n",ope,nparm,lSum);
*/
	nrat = 1;
	pInfoParm = &tInfoParm;
	/* 2023.6.11 */
	sizeofnmp = sizeofMPA();
	/* 2025.3.27 */
	mpa1 = (MPA *)cl_get_tmpMPA3(lma1z,NMPA_LONG_PRE1,2);
	mpa2 = (MPA *)cl_get_tmpMPA3(lma2z,NMPA_LONG_PRE1,2);
/*
printf("cl_func_agg_sub: mpa1=%08x mpa2=%08x\n",mpa1,mpa2);
*/
	m_cpy(mpa1,m_get_i(0),0);
	m_cpy(mpa2,mpa1,0);
	p = (char *)mpa1;
	m_cpy((MPA *)(p+sizeofnmp),mpa1,0);
/*
akxaxdump("mpa1",p,sizeofnmp+sizeofnmp);
*/
	p = (char *)mpa2;
	m_cpy((MPA *)(p+sizeofnmp),mpa1,0);
/*
akxaxdump("mpa2",p,sizeofnmp+sizeofnmp);
*/
	cl_set_parm_mpa2(pInfoParm,mpa1,'P');
	pInfoParm1 = &tInfoParm1;
#if 0	/**/
	if (ope==D_FUC_SUM || ope==D_FUC_AVG || ope==D_FUC_PRODUCT) {
		cl_set_parm_bin(pInfoParm1,0);
	/*	if (!lSum) lSum++;	*/
	}
	else
#endif
	cl_parm_set0(pInfoParm1);
	for (i=0;i<nparm;i++) {
		pInfoParm2 = ppParm[i];
		if (cl_is_undef_parm(pInfoParm2) || cl_is_null_parm(pInfoParm2)) continue;

		if ((ret=cl_iterate_info_init(&tIter_ctl,NULL,pInfoParm2,max_layer)) < 0) break;
		for (;;) {
			if ((ret=cl_iterate_info(&tIter_ctl)) < 0) break;
			pIter = tIter_ctl.itc_pIter;
			if (!(pInfoParm2=pIter->it_pInfo)) break;
/*
DEBUGOUT_InfoParm(198,"cl_func_agg_sub:pInfoParm1",pInfoParm1,0,0);
DEBUGOUT_InfoParm(198,"cl_func_agg_sub:pInfoParm2",pInfoParm2,0,0);
*/
			alen = pInfoParm2->pi_alen;
			if ((alen & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA | D_AULN_RATIONAL)) == D_AULN_RANGE_DATA) {
				ERROROUT2(FORMAT(636),_fn_,FORMAT(134));	/* %s: %s�͎w��ł��܂���B*//*�͈͎w�� */
				return ECL_SCRIPT_ERROR;
			}
			if (cl_is_undef_parm(pInfoParm1) || cl_is_null_parm(pInfoParm1)) {
				cl_set_parm_mpa2(pInfoParm1,mpa2,'P');
				cl_gx_copy_info2_opt(pInfoParm1,pInfoParm2,4);
				lSum++;
			}
			else if (!cl_is_undef_parm(pInfoParm2) && !cl_is_null_parm(pInfoParm2)) {
				attr1 = pInfoParm1->pi_attr;
				if ((ret=cl_comp_info(pInfoParm,pInfoParm1,pInfoParm2,ope)) < 0) break;
				/* 2023.6.11 */
/*
printf("cl_func_agg_sub: pInfoParm->pi_attr=%d pInfoParm1->pi_attr=%d\n",pInfoParm->pi_attr,pInfoParm1->pi_attr);
printf("cl_func_agg_sub: pInfoParm->pi_data=%08x pInfoParm1->pi_data=%08x\n",pInfoParm->pi_data,pInfoParm1->pi_data);
*/
#if 1	/* 2026.8.4 */
				cl_set_parm_mpa2(pInfoParm1,mpa2,'P');
				cl_gx_copy_info2_opt(pInfoParm1,pInfoParm,4);
				pInfoParm->pi_data = (char *)mpa1;
DEBUGOUT_InfoParm(198,"cl_func_agg_sub: pInfoParm1=",pInfoParm1,0,0);
#else
				if (pInfoParm->pi_attr==DEF_ZOK_DECI) {
					if (pInfoParm->pi_alen & D_AULN_RANGE_DATA) nrat = 2;
#if 1	/* 2026.7.26 */
					if (attr1 != DEF_ZOK_DECI) {
#else
					if (attr1 == DEF_ZOK_BINA) {
#endif
						memcpy(mpa2,pInfoParm->pi_data,sizeofnmp*nrat);
						cl_set_parm_mpa2(pInfoParm1,mpa2,'P');
						cl_set_parm_mpa2(pInfoParm,mpa1,'P');
					}
					else {
						memcpy(mpa2,mpa1,sizeofnmp*nrat);
#if 0	/* 2026.7.26 */
						cl_set_parm_mpa2(pInfoParm1,mpa2,'P');
#else
						pInfoParm1->pi_data = (char *)mpa2;
#endif
					}
				}
				else cl_gx_copy_info2(pInfoParm1,pInfoParm);
#endif
				lSum++;
			}
		}
		if (ret < 0) break;
	}
/*
printf("cl_func_agg_sub: lSum=%d ret=%d\n",lSum,ret);
*/
	if (ret >= 0) {
#if 1	/* 2026.7.26 */
		if (!cl_is_undef_parm(pInfoParm1) && !cl_is_null_parm(pInfoParm1)) {
			if (ope==D_FUC_SUM || ope==D_FUC_AVG || ope==D_FUC_PRODUCT) {
				if (pInfoParm1->pi_id==' ' && ((attr1=pInfoParm1->pi_attr)<2 || attr1>4)) {
					pInfoParm = &tInfoParm;
					cl_set_parm_bin(pInfoParm,0);
					if ((ret=cl_conv_upper(pInfoParm1,pInfoParm,0)) < 0) return ret;
				}
			}
		}
#endif
DEBUGOUT_InfoParm(198,"cl_func_agg_sub:2 pInfoParm1=",pInfoParm1,0,0);
		cl_gx_copy_info(pInfoParmW,pInfoParm1);
		pInfoParmW->pi_scale &= ~D_DATA_MALLOC;
		pInfoParmW->pi_len = lSum;
		attr = pInfoParmW->pi_attr;
		len1 = pInfoParmW->pi_dlen;
/*
printf("cl_func_agg_sub: attr=%d len1=%d\n",attr,len1);
*/
		if (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK || attr==DEF_ZOK_DATE || attr==DEF_ZOK_DECI) {
			if (pInfoParm->pi_attr==DEF_ZOK_DECI) {
				if (pInfoParm->pi_alen & D_AULN_RANGE_DATA) len1 += len1;
			}
			if (!(pWork=cl_tmp_const_malloc(len1+1))) return ECL_MALLOC_ERROR;
/*
printf("cl_func_agg_sub: pWork=%08x\n",pWork);
*/
			memzcpy(pWork,pInfoParm1->pi_data,len1);
		/*	if (attr == DEF_ZOK_CHAR) *(pWork+len1) = '\0';	*/
			pInfoParmW->pi_data = pWork;
		}
		ret = 0;
	}
/*
printf("cl_func_agg_sub:Exit lSum=%d ret=%d\n",lSum,ret);
*/
DEBUGOUT_InfoParm(198,"cl_func_agg_sub:Exit ret=%d",pInfoParmW,ret,0);
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_agg(pInfoParmW0,nparm,ppParm,ope0)
tdtInfoParm *pInfoParmW0,**ppParm;
int nparm,ope0;
{
	int ret,ope,attr;
	long lSum,lVal1,lVal2;
	double dVal1,dVal2;
	MPA ma1z,ma2z,*mpa1,*ma1,*ma2;
	tdtInfoParm *pInfoParmW,tInfo,tInfoW;
/*
printf("cl_func_agg:Enter pInfoParmW=%08x nparm=%d ope0=%08x\n",pInfoParmW,nparm,ope0);
*/
	ret = 0;
	pInfoParmW = pInfoParmW0;
	if ((ope=ope0) == D_FUC_AVG) ope = D_FUC_SUM;
#if 1	/* 2026.7.26 */
	cl_null_value(pInfoParmW);
#else
	cl_null_char(pInfoParmW);
#endif
	pInfoParmW->pi_len = 0;
	ret = cl_func_agg_sub(pInfoParmW,nparm,ppParm,ope,NULL);
	if (!ret) {
DEBUGOUT_InfoParm(198,"cl_func_agg: ret=%d",pInfoParmW,ret,0);
		if (cl_is_undef_parm(pInfoParmW0) || cl_is_null_parm(pInfoParmW0)) {
			ERROROUT1(FORMAT(372),"cl_func_agg");	/* %s: �f�[�^����0�ł��B*/
		/*	if (ope0 == D_FUC_SUM) cl_set_parm_long(pInfoParmW,0);
			else */
#if 1	/* 2026.7.26 */
			cl_null_value(pInfoParmW);
#else
			cl_null_char(pInfoParmW);
#endif
		}
		else if (ope0 == D_FUC_AVG) {
			lSum = pInfoParmW->pi_len;
			attr = pInfoParmW->pi_attr;
			/* 2025.3.26 */
			if (pInfoParmW->pi_alen & D_AULN_RATIONAL) {
				cl_set_parm_long(&tInfo,lSum);
				if ((ret=cl_cmpt_math_rational(&tInfoW,"/",pInfoParmW,&tInfo)) >= 0) {
					cl_gx_copy_info2(pInfoParmW,&tInfoW);
					ret = pInfoParmW0->pi_attr;
				}
				return ret;
			}
			if (attr == DEF_ZOK_FLOA) {
				cl_get_parm_double(pInfoParmW,&dVal1,"1");
				cl_set_parm_double(pInfoParmW,dVal1/lSum);
			}
			else if (attr==DEF_ZOK_BINA || attr==DEF_ZOK_DECI) {
				mpa1 = (MPA *)cl_get_tmpMPA(&ma1z);
				if (!(ret=cl_get_parm_dec(pInfoParmW,mpa1,"1"))) {
					ma2 = (MPA *)cl_get_tmpMPA(&ma2z);
					m_l2mpa(lSum,ma2);
					m_div1(mpa1,ma2);
					cl_set_parm_mpa(pInfoParmW,mpa1);
				}
				else if (ret > 0) ret = ECL_SCRIPT_ERROR;
			}
			else ret = -1;
		}
	}
	if (!ret) ret = pInfoParmW0->pi_attr;
	return ret;
}

/************************************************/
/*	cmp_opt : 0x0001 : Ignore case				*/
/*			  0x0002 : Ignore Hankaku/Zenkaku	*/
/*			  0x0800 : LIKE						*/
/************************************************/
int cl_eq_compare(pInfoParm1,pInfoParm2,cmp_opt)
tdtInfoParm *pInfoParm1,*pInfoParm2;
int cmp_opt;
{
	int rc,opt,atr1,atr2;
	long *pAns,result;
	char *p,Oprtr[6],*pOprtr,id1;
/*
printf("cl_eq_compare:Enter cmp_opt=%08x\n",cmp_opt);
*/
	if (cmp_opt & D_COMP_OPT_LIKE) {
		p ="iLIKE";
		cmp_opt |= D_COMP_OPT_CNV_TYPE;
	}
	else p = "iEQ";
	strcpy(Oprtr,p);
	pOprtr = Oprtr;
	if (!(cmp_opt & D_COMP_OPT_IGN_CASE)) pOprtr++;
/*
printf("cl_eq_compare: cmp_opt=%08x pOprtr=[%s]\n",cmp_opt,pOprtr);
*/
	pAns = &result;
	if ((id1=pInfoParm1->pi_id) != pInfoParm1->pi_id) rc = 1;
	else {
		opt = 0;
		if (id1 == ' ') {
			atr1 = pInfoParm1->pi_attr;
			atr2 = pInfoParm2->pi_attr;
			if (atr1 != atr2) cmp_opt |= D_COMP_OPT_CNV_TYPE;
			if (cmp_opt & D_COMP_OPT_CNV_TYPE) {
				rc = cl_cmpt_comp_opt(&pAns,pOprtr,pInfoParm1,pInfoParm2,cmp_opt);
/*
printf("cl_eq_compare: rc=%d result=%d\n",rc,result);
*/
				if (rc > 0) rc = !result;
				else if (rc <= 0) rc = 1;
				return rc;
			}
			else {
				if (atr1 == DEF_ZOK_CHAR) {
					if (cmp_opt & D_COMP_OPT_IGN_CASE) opt = 1;
					if (cmp_opt & D_COMP_OPT_IGN_HZ) opt |= D_COMP_OPT_IGN_HZ | 0x4000;
				}
			}

		}
/*
printf("cl_eq_compare: opt=%08x\n",opt);
*/
		rc = akxmemcmplen(pInfoParm1->pi_data,pInfoParm1->pi_dlen,pInfoParm2->pi_data,pInfoParm2->pi_dlen,opt);
		if (rc) rc = 1;
		else rc = 0;
	}
	return rc;
}
