static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �z�񏈗�                                               *
*                                                                             *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

extern CLPRTBL  *pGLprocTable;
extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];

/****************************************/
/*										*/
/****************************************/
int cl_array_check_valid(pInfoParm,iEROUT_NDEF)
tdtInfoParm *pInfoParm;
int iEROUT_NDEF;
{
	static char *_fn_ = "cl_array_check_valid";
	int rc,iINVALID,ix;
	tdtInfoParm *pInfo;
	tdtArrayIndex *pIndex,*pIndex0;
	char *name,id,id0,*p;

	rc = 0;
	if (((id=pInfoParm->pi_id)=='A' || id=='R') &&
		pInfoParm->pi_dlen == sizeof(tdtArrayIndex)) {
DEBUGOUT_InfoParm(194,"cl_array_check_valid: pInfoParm=",pInfoParm,0,0);
		pIndex  = (tdtArrayIndex *)pInfoParm->pi_data;	/* �����A�q�����m��Ȃ� */
		if ((pInfo=(tdtInfoParm *)pInfoParm->pi_paux) && pInfo!=pInfoParm) {
DEBUGOUT_InfoParm(194,"cl_array_check_valid: pInfo=",pInfo,0,0);
			/* pInfo���葱�����̒��Œ�`���ꂽ�z��̂Ƃ��́A���^�[���������_�ŁA
			   pInfo����0�N���A����Ă��邽�߁ApIndex0��NULL�ɂȂ��Ă��� */
			pIndex0 = (tdtArrayIndex *)pInfo->pi_data;
			if (pIndex0 != pIndex) {	/* �e�̉\�� */
				iINVALID = 0;
				id0 = pInfo->pi_id;
				if (id != id0) iINVALID = 1;	/* pInfo����0�N���A����Ă���Ƃ��́A�����ň��������� */
				else {
					if ((ix=akxs_xhasl(pGLprocTable->pha_gid,'R',pInfo->pi_hlen,0)) <= 0) iINVALID = 2;
					else if (pIndex0) {
						if (pIndex0->pVarIndex != pIndex->pVarIndex) iINVALID = 3;
					}
/*
printf("cl_array_check_valid: ix=%d pi_hlen=%d\n",ix,pInfo->pi_hlen);
*/
				}
				if (iINVALID) {
/*
printf("cl_array_check_valid: iINVALID=%d\n",iINVALID);
*/
					if (iEROUT_NDEF) {
						if (!(name=(char *)pInfoParm->pi_pos)) name = AKX_NULL_PRINT;
						p = FORMAT(150);	/* �z�� */
						if (iINVALID == 3)
								/* %s: �R�s�[��%s[%s]�̃f�[�^�悪�Ē�`���ꂽ���ߖ{%s�͖����ł��B*/
							ERROROUT4(FORMAT(659),_fn_,p,name,p);
						else
								/* %s: �R�s�[����%s[%s]�������ł��B(%d) */
							ERROROUT4(FORMAT(231),_fn_,p,name,iINVALID);
					}
					rc = ECL_SCRIPT_ERROR;
				}
			}
		}
	}
	return rc;
}

/********************************************/
/*	ppIndex : ppIndex<>NULL�̂Ƃ��ȉ���Ԃ�	*/
/*			   rc = 0 : �q��pIndex			*/
/*			   rc = 1 : �e��pIndex			*/
/*	opt = 0 : �e�����߂Ȃ�					*/
/*		<>0 : �e�����߂�					*/
/*	rc = 0: �e�����߂Ȃ��Ƃ����A�e���Ȃ�	*/
/*		 1: �e������						*/
/********************************************/
int cl_get_array_index_opt(pInfoParm,ppIndex,opt)
tdtInfoParm *pInfoParm;
tdtArrayIndex **ppIndex;
int opt;
{
	char id;
	int  rc;
	tdtInfoParm *pInfo;
	tdtArrayIndex *pIndex,*pIndex0;

	if (!pInfoParm) return -1;
DEBUGOUT_InfoParm(194,"cl_get_array_index_opt:Enter pInfoParm=",pInfoParm,0,0);
/*
printf("cl_get_array_index_opt:Enter pInfoParm=%08x id=[%c] opt=%08x\n",pInfoParm,pInfoParm->pi_id,opt);
*/
	rc = 0;
	if (ppIndex) *ppIndex = NULL;
	if (((id=pInfoParm->pi_id)=='A' || id=='R') &&
		pInfoParm->pi_dlen == sizeof(tdtArrayIndex)) {
		pIndex  = (tdtArrayIndex *)pInfoParm->pi_data;	/* �����A�q�����m��Ȃ� */
		if (opt) {
			if ((pInfo=(tdtInfoParm *)pInfoParm->pi_paux) && pInfo!=pInfoParm) {
				if (pIndex0 = (tdtArrayIndex *)pInfo->pi_data) {		/* �e�̉\�� */
					/* InfoParm���P���ɃR�s�[���ꂽ�����ł��ApInfo!=pInfoParm�ƂȂ�A*/
					/* �e����ƂȂ��Ă��܂��̂ŁApIndex���قȂ�ApIndex->pVarIndex�� */
					/* �����Ƃ��̂݁ApInfoParm�� �������ꂽ�q�ł���A�e����Ƃ������ƂɂȂ� */
					if (pIndex0!=pIndex && pIndex0->pVarIndex==pIndex->pVarIndex) {
						pIndex = pIndex0;	/* �e */
						rc = 1;
/*
printf("cl_get_array_index_opt: rc=%d\n",rc);
*/
DEBUGOUT_InfoParm(194,"cl_get_array_index_opt: parent rc=%d pInfo=",pInfo,rc,0);
					}
				}
/*
printf("cl_get_array_index_opt: parent pInfo=%08x rc=%d\n",pInfo,rc);
*/
			}
		}
		if (ppIndex) *ppIndex = pIndex;
	}
	else rc = ECL_SYSTEM_ERROR;
/*
printf("cl_get_array_index_opt: rc=%d\n",rc);
*/
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_array_index(pInfoParm,ppIndex)
tdtInfoParm *pInfoParm;
tdtArrayIndex **ppIndex;
{
	return cl_get_array_index_opt(pInfoParm,ppIndex,0);
}

/************************************/
/*									*/
/************************************/
int cl_get_array_psize(pInfoParm,pcn,ppSize,ppTBL)
tdtInfoParm *pInfoParm;
char *pcn;
int **ppSize;
tdtInfoParm ****ppTBL;
{
	int opt;
	char cn,*name;

	cn = '\0';
	opt = 0;
	if (pInfoParm->pi_aux[1] & D_AUX1_LOCAL_VAR) opt = D_GX_OPT_SET_LOCAL;
	if (pInfoParm->pi_id == 'A') {
		name = (char *)pInfoParm->pi_pos;
/*
printf("cl_get_array_psize: name=[%s]\n",name);
*/
		cn = *name;
		if (cn!='%' && cn!='#') cn = '$';
	}
	if (pcn) *pcn = cn;
	return cl_def_get_psize(cn,NULL,NULL,opt,ppSize,ppTBL);
}

/****************************************/
/*										*/
/****************************************/
int cl_update_map_array_max(pInfoParm)
tdtInfoParm *pInfoParm;
{
	int rc,*pSize,*index,m;
	char cn,id;
	tdtArrayIndex *pIndex,*pIndex0;

	rc = 0;
	if ((id=pInfoParm->pi_id) == 'A') {
		if ((rc=cl_get_array_psize(pInfoParm,&cn,&pSize,NULL)) >= 0) {
			rc = 0;
			if (cn=='$' || cn=='%') {
				pIndex = (tdtArrayIndex *)pInfoParm->pi_data;
				index = pIndex->index;
				/* 2023.12.20 */
			/*	if ((m=pSize[7]-index[3]+1) > index[2]) index[2] = m;	*/
				if ((m=pSize[7]-index[3]) > index[2]) index[2] = m;
/*
printf("cl_update_map_array_max: index[2]=%d\n",index[2]);
*/
				if (index[2] < 0) index[2] = 0;
			}
			return 0;
		}
	}
	if (id=='A' || id=='R') rc = cl_update_parent_array_max(pInfoParm,NULL);
	return rc;
}

/********1*********2*********3*********4*********5*********6*****/
/* �@�\ : �q�܂��͐e�̔z���pInfoParm��n���āA�q��index[2]��	*/
/*		  �e��index[2]�ɔ��f����								*/
/* ���� : pInfoParm : �q�̂Ƃ� : pInfoParm��index��e�ɔ��f����	*/
/*								 index�͎g�p���Ȃ�				*/
/*					  �e�̂Ƃ� : index�𔽉f����				*/
/*		  index		: �q�̍X�V��̏��							*/
/*					  pInfoParm���q�̂Ƃ��́ANULL�ł悢			*/
/*		  opt		: 0x01 : �q���������Ȃ��Ă��X�V����			*/
/****************************************************************/
int cl_update_parent_array_max_opt(pInfoParm,index,opt)
tdtInfoParm *pInfoParm;
int *index,opt;
{
	int rc,m0,m,i2;
	tdtArrayIndex *pIndex,*pIndex0;
/*
printf("cl_update_parent_array_max:Enter pInfoParm=%08x index=%08x\n",pInfoParm,index);
*/
	if ((rc=cl_get_array_index_opt(pInfoParm,&pIndex0,1)) >= 0) {
		if (rc > 0) {
			/* pInfoParm�́A�q�Ȃ̂ŁAindex�́ApInfoParm���g�� */
			pIndex = (tdtArrayIndex *)pInfoParm->pi_data;
			index = pIndex->index;
		}
		if (index) {
		/*	m = index[2] + index[3] - 1;	*/	/* �q */
			m = index[2] + index[3];	/* �q */
/*
printf("cl_update_parent_array_max:child  index=%08x index[2]=%d index[3]=%d m=%d\n",index,index[2],index[3],m);
*/
			if (pIndex0) {
				index = pIndex0->index;
			/*	m0 = index[2] + index[3] - 1;	*/	/* �e */
				m0 = index[2] + index[3];	/* �e */
/*
printf("cl_update_parent_array_max:parent index=%08x index[2]=%d index[3]=%d m0=%d\n",index,index[2],index[3],m0);
*/
			/*	i2 = m - index[3] + 1;	*/
				i2 = m - index[3];
				if (m > m0) index[2] = i2;
				else if ((opt & 0x01) && m<m0) index[2] = i2;
/*
printf("cl_update_parent_array_max:parent index[2]=%d\n",index[2]);
*/
			}
			rc = 0;
		}
		else rc = -1;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_update_parent_array_max(pInfoParm,index)
tdtInfoParm *pInfoParm;
int *index;
{
	return cl_update_parent_array_max_opt(pInfoParm,index,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_get_array_index_tbl(pInfoParm,pIndex,ppTBL,pMsg)
tdtInfoParm *pInfoParm;
tdtArrayIndex *pIndex;
tdtInfoParm ****ppTBL;
char *pMsg;
{
	int iRc;
	/* 2021.6.14 */
	tdtArrayIndex *pIndexW,**ppIndex;

	if (pIndex) {
		pIndexW = pIndex;
		ppIndex = &pIndexW;
	}
	else ppIndex = NULL;
	if (!(iRc=cl_get_array_index_tbl_ref(pInfoParm,ppIndex,ppTBL,pMsg))) {
		if (pIndex && pIndexW!=pIndex) memcpy(pIndex,pIndexW,sizeof(tdtArrayIndex));
	}
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7*/
/*  �@�\: ���l(�����ԍ��z��̃C���f�b�N�X)�܂��͔z�񖼂̔z�����Ԃ�*/
/*	�����F	pInfoParm : �z���� or Mapp Index						  */
/*						A�̂Ƃ��́Aindex[2]���X�V����B				  */
/*			ppIndex : = NULL�̂Ƃ��ApInfo�͕Ԃ��Ȃ��B				  */
/*					  <>NULL�̂Ƃ��A*ppIndex �ɂ́A&tIndex ���A		  */
/*					    �ݒ肳��Ă��邱��							  */
/*					  *ppIndex �ɂ́AA or R �̂Ƃ��A				  */
/*						�z���pIndex���Ԃ����B					  */
/*					  A,R �ȊO�̂Ƃ��́A�n���ꂽ*ppIndex�Ɉȉ�������  */
/*						index[1]:Mapp Index����z��̍ő�v�f�܂ł̐� */
/*						index[3]:Mapp Index							  */
/*			ppTBL	: <>NULL�̂Ƃ��A								  */
/*						Mapp Index���̔z���ւ̃|�C���^���Ԃ�		  */
/*			pMsg	: �Ăь����̃R�����g							  */
/*					  = NULL�̂Ƃ��́A���ʂŌĂ΂��֐����ɂȂ�	  */
/**********************************************************************/
int cl_get_array_index_tbl_ref(pInfoParm,ppIndex,ppTBL,pMsg)
tdtInfoParm *pInfoParm;
tdtArrayIndex **ppIndex;
tdtInfoParm ****ppTBL;
char *pMsg;
{
	static char *_fn_ = "cl_get_array_index_tbl_ref";
	ScrPrCT	*pScCT;
	ProcCT  *proc;
	int *index;
	tdtInfoParm ***pTBL,*pInfo;
	tdtArrayIndex *pIndex,tIndex;
	int iRc,*pSize,m,tSize[4],opt,iSET,offset,m2;
	char c,*name,cn,cmd;
/*
printf("cl_get_array_index_tbl_ref:Enter pMsg=[%s]\n",pMsg);
*/
DEBUGOUT_InfoParm(191,"cl_get_array_index_tbl_ref:Enter: ",pInfoParm,0,0);
DEBUGOUTL4(191,"%s:Enter: ppIndex=%08x ppTBL=%08x pMsg=[%s]",_fn_,ppIndex,ppTBL,pMsg);

	iRc = 0;
	cn = '\0';
	pTBL = NULL;
	pSize = NULL;
	if (ppTBL) *ppTBL = pTBL;
	/* 2021.6.14 */
	pIndex = NULL;
	if (ppIndex) {
		pIndex = *ppIndex;
		/* 2024.6.3 */
	}
	if (pIndex) {
		if (pInfoParm->pi_data != (char *)pIndex) memset(pIndex,0,sizeof(tdtArrayIndex));
	}
	else {
		pIndex = &tIndex;
		memset(pIndex,0,sizeof(tdtArrayIndex));
	}
	if ((c=pInfoParm->pi_id) != 'R') {
		/* 2021.6.14 */
		if ((iRc=cl_get_array_psize(pInfoParm,&cn,&pSize,&pTBL)) < 0) return iRc;
		if (ppTBL) *ppTBL = pTBL;
	}
	else if (c == 'R') {
		/* 2023.5.10 */
		if (iRc = cl_array_check_valid(pInfoParm,1)) return iRc;
		pSize = tSize;
	}
	index = pIndex->index;
/*
printf("cl_get_array_index_tbl_ref:1 pIndex=%08x Index=%08x\n",pIndex,index);
*/
DEBUGOUTL5(191,"cl_get_array_index_tbl_ref:1 index = %d %d %d %d %d",
index[0],index[1],index[2],index[3],index[4]);

	if (c == 'A' || c == 'R') {
		if (iRc = cl_get_array_index(pInfoParm,&pIndex)) return iRc;
		if (ppIndex) *ppIndex = pIndex;
		index = pIndex->index;
/*
printf("cl_get_array_index_tbl_ref:2 pIndex=%08x Index=%08x index[2]=%d\n",pIndex,index,index[2]);
*/
	}
	else {
		if (iRc = cl_get_parm_bin(pInfoParm,index+3,pMsg)) return iRc;
		index[3]--;
	/*	index[1] = pSize[2] - (index[3] - 1);	*/
		index[1] = pSize[2] - index[3];
		index[0] = 1;
		index[2] = pSize[7] - index[3];
		index[4] = index[1];
		index[5] = 1;
		if (index[2] < 0) index[2] = 0;	/* add 2026.1.26 */
	}

DEBUGOUTL5(191,"cl_get_array_index_tbl_ref:2 index = %d %d %d %d %d",
index[0],index[1],index[2],index[3],index[4]);

/*	if ((c=='R' && !pIndex->xhp && index[3]<=0) ||	*/	/* 2025.9.24 <0 ==> <=0 *//* 2025927 add !pIndex->xhp */
/*	    (c!='R' && (index[3]<=0 || index[3]>pSize[2]))) {	*/
	if ((c=='R' && !pIndex->xhp && index[3]<0) ||	/* 2025.9.24 <0 ==> <=0 *//* 2025927 add !pIndex->xhp */
	    (c!='R' && (index[3]<0 || index[3]>pSize[2]))) {
		ERROROUT1(FORMAT(232),index[3]);	/* �C���f�b�N�X�̏����l(%d)���s���ł��B */
		return -1;
	}
	/* $()�́ApSize�����Đݒ肵�Ă���̂ŁA$n���ł̕ύX�́A���f����Ă���B */
	/* mappedarray �̂Ƃ��́Amap ����pSize[7]�������̔z��T�C�Y��菬���������甽�f����B*/
	if (c!='R' && pSize && (cn=='$' || cn=='%' || cn=='#')) {

DEBUGOUTL3(191,"cl_get_array_index_tbl_ref:2 pSize[5].. = %d %d %d",pSize[5],pSize[6],pSize[7]);
/*
printf("cl_get_array_index_tbl_ref: cn=[%c] pSize[7]=%d index=%d %d %d %d %d %d\n",
cn,pSize[7],index[0],index[1],index[2],index[3],index[4],index[5]);
*/
		/* 2025.9.16 */
		if ((m=pSize[7]) > 0) {
		/*	offset = index[3] - 1;	*/
			offset = index[3];
			m2 = m - offset;
			if (pMsg) cmd = *pMsg;
			else cmd = '!';
			iSET = 0;
			if (cmd == '>') {
				if (m2 > index[2]) iSET= 1;
			}
			else if (cmd == '<') {
				if (m2 < index[2]) iSET= 1;
			}
			else iSET= 1;
			if (iSET) {
				index[2] = m2;
			}
			else {
				if (m2 < index[1]) index[1] = m2;
			}
			if (index[2] > index[1]) index[2] = index[1];
		}
/*
printf("cl_get_array_index_tbl_ref:reflect index[1]=%d index[2]=%d\n",index[1],index[2]);
*/
DEBUGOUTL5(191,"cl_get_array_index_tbl_ref:3 index = %d %d %d %d %d",
index[0],index[1],index[2],index[3],index[4]);
	}
	else if (c == 'R') {
		iRc = cl_adust_infoR(pInfoParm,pIndex);
		if (iRc > 0) iRc = 0;
	}
/*
printf("cl_get_array_index_tbl_ref: index=%d %d %d %d %d %d\n",
index[0],index[1],index[2],index[3],index[4],index[5]);
*/
/*
printf("cl_get_array_index_tbl_ref:Exit iRc=%d\n",iRc);
*/
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
int cl_check_use_mapped_array(pInfoParm)
tdtInfoParm *pInfoParm;
{
	char *name,c;

	if (pInfoParm->pi_id == 'A') {
		name = (char *)pInfoParm->pi_pos;
/*
printf("cl_check_use_mapped_array: name=[%s]\n",name);
*/
		if ((c=*name)=='%' || c=='#') {
			ERROROUT1(FORMAT(233),name);	/* �w��ł��Ȃ��z��(%s)�ł��B */
			return -1;
		}
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_check_use_hash_array(pInfoParmArray,pIndex)
tdtInfoParm *pInfoParmArray;
tdtArrayIndex *pIndex;
{
	if (pIndex->xhp ||
	    (pInfoParmArray->pi_id=='R' && (pIndex->index[2] < 0))) {
		/* cl_check_use_hash_array: can't use hash array[%s]!! */
		ERROROUT1(FORMAT(234),(char *)pInfoParmArray->pi_pos);
		return -1;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,opt)
tdtArrayIndex *pIndex;
tdtInfoParm ***pTBL;
int  ix;
char opt;
{
	static char *_fn_ = "cl_get_array_and_var_ent_opt";
	int iRc,attr,attr0,iParm[4],*index,ix1;
	tdtInfoParm *pInfoParm,rInfoParm;

DEBUGOUTL5(194,"%s:Enter: pIndex=%08x pTBL=%08x ix=%d opt=%c",_fn_,pIndex,pTBL,ix,opt);

	pInfoParm = NULL;
	if (pTBL)
		pInfoParm = cl_get_var_ent_opt(pTBL,ix,opt);
	else if (pIndex) {
		attr = pIndex->uAttr[0];
		index = pIndex->index;
DEBUGOUTL3(194,"%s: attr=%d index[1]=%d",_fn_,attr,index[1]);
	/*	if (attr && ix<=index[1]+index[3]-1) {	*/
		if (attr && ix>0 && ix<=index[1]+index[3]) {
			attr0 = 0;
			if ((attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK) && !pIndex->size) {
				attr0 = attr;
				attr = DEF_ZOK_VARI;

DEBUGOUTL4(194,"%s: ix=%d opt=%c attr0=%d",_fn_,ix,opt,attr0);

			}
			/* 2021.11.23 */
			else if (attr & 0x10) {
				attr0 = attr;
				attr = DEF_ZOK_VARI;
			}
			if (attr == DEF_ZOK_VARI) {
				pInfoParm = cl_get_array_ent_opt(pIndex->pVarIndex,ix,opt);
				if (pInfoParm) {
DEBUGOUT_InfoParm(194,"%s: attr0=%d",pInfoParm,_fn_,attr0);
					if (attr0 && !(pInfoParm->pi_aux[0] & ~DEF_ZOK_DATA)) {
						iParm[0] = attr0;
						iParm[1] = 0;
						cl_set_parm_init(pInfoParm,iParm,0x01);
					}
				}
			}
			else {
				if (!cl_get_array_val_opt(&rInfoParm,pIndex,ix,'s'))
					pInfoParm = (tdtInfoParm *)rInfoParm.pi_pos;
					/* 2022.8.26 */
					if (opt == 's') pInfoParm->pi_data = rInfoParm.pi_paux;
			}
			if (pInfoParm && opt=='s') {
				index = pIndex->index;

DEBUGOUTL3(194,"%s: index=%08x ix=%d",_fn_,index,ix);
DEBUGOUTL5(194,"%s: index=%d %d %d %d",_fn_,index[0],index[1],index[2],index[3]);

			/*	ix1 = ix - index[3] + 1;	*/
				ix1 = ix - index[3];
				if (index[2] < ix1) index[2] = ix1;
/*
printf("%s: opt=%c index=%08x ix=%d ix1=%d index[2]=%d\n",_fn_,opt,index,ix,ix1,index[2]);
*/
				/* 2026.1.27 *//* ����pInfoParm�́A�v�f�Ȃ̂ŁA���̏����͂���Ȃ� */
				/* 2023.12.18 */
				/* �z�񂪃}�b�v����Ă���Ƃ��́A���̔z��̍ő�ݒ�ʒu���X�V���� */
			}
		}
	}

	return pInfoParm;
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_array_and_var_ent(pIndex,pTBL,ix)
tdtArrayIndex *pIndex;
tdtInfoParm ***pTBL;
int  ix;
{
	return cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,'s');
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_conv_index(pInfoParm,pIndex)
tdtInfoParm *pInfoParm;
tdtArrayIndex *pIndex;
{
	tdtArrayIndex tIndex;
	int  attr,i,ji_1,mx,iSTART,iIXPOS,f,m1,m2,opt15;
	int  n,*index,*index_info,nn,iRANGE,ndim,nn1,nn2;
	char c,*varnam;

	if (!pInfoParm || !pIndex) return ECL_SYSTEM_ERROR;
	c = pInfoParm->pi_id;
	n = pInfoParm->pi_dlen;
/*
printf("cl_gx_conv_index: pInfoParm->pi_id=%c len=%d\n",c,n);
*/
	if ((n == sizeof(tdtArrayIndex)) && ((c == 'A') || (c == 'R'))) {
		if (!pInfoParm->pi_data) return ECL_SYSTEM_ERROR;
		memcpy(&tIndex,pInfoParm->pi_data,n);
		pIndex->pVarIndex = tIndex.pVarIndex;
		pIndex->size = tIndex.size;
		memcpy(pIndex->uAttr,tIndex.uAttr,sizeof(pIndex->uAttr));
		pIndex->xhp = tIndex.xhp;
	}
	else return ECL_SYSTEM_ERROR;

	index = tIndex.index;

DEBUGOUTL5(191,"cl_gx_conv_index: index[0]..[4] = %d %d %d %d %d",
index[0],index[1],index[2],index[3],index[4]);
DEBUGOUTL5(191,"cl_gx_conv_index: index[5]..[9] = %d %d %d %d %d",
index[5],index[6],index[7],index[8],index[9]);

	index_info = pIndex->index;	/* �w�肳�ꂽ�e�����̃C���f�b�N�X */

	if (!(varnam=(char *)pInfoParm->pi_pos)) varnam = AKX_NULL_PRINT;
	/* 2025.9.29 */
	index_info[3] = tIndex.uaux2;
	return cl_gx_conv_index2(index,index_info,varnam);
}

/********************************************************/
/*	index      : �z��̎�����`							*/
/*	index_info : ���߂����ʒu  �ȉ���ݒ肷��			*/
/*				(index���R�s�[���A�ȉ���ݒ肵�Ă��ǂ�)	*/
/*				 index_info[0]  : ������				*/
/*				 index_info[3]  : �I�v�V����			*/
/*				 index_info[4]  : 1�����̃C���f�b�N�X	*/
/*				 index_info[5]  : 2�����̃C���f�b�N�X	*/
/*					...									*/
/********************************************************/
int cl_gx_conv_index2(index,index_info,varnam)
int *index,*index_info;
char *varnam;
{
	static char *_fn_ = "cl_gx_conv_index2";
	int  attr,i,ji_1,mx,iSTART,iIXPOS,f,m1,m2,opt15,range_bit,range_ret;
	int  n,nn,iRANGE,ndim,nn1,nn2;

DEBUGOUTL5(191,"cl_gx_conv_index2: index_info[0]..[4] = %d %d %d %d %d",
index_info[0],index_info[1],index_info[2],index_info[3],index_info[4]);
DEBUGOUTL5(191,"cl_gx_conv_index2: index_info[5]..[9] = %d %d %d %d %d",
index_info[5],index_info[6],index_info[7],index_info[8],index_info[9]);

	ndim = index[0];
	ji_1 = X_MIN(index_info[0],ndim);
	opt15 = cl_get_option(15,0);
	/* 2025.9.29 */
	range_bit = 1;
	range_ret = index_info[3];
	iSTART = opt15 & 0x01;
	iIXPOS = !(opt15 & 0x02);	/* 2025.9.27 add ! FORTRAN�`�����f�t�H���g�ɂ��� */
	mx = ji_1;
/*
	if (!(varnam=(char *)pInfoParm->pi_pos)) varnam = AKX_NULL_PRINT;
*/
	if (!varnam) varnam = AKX_NULL_PRINT;
	n = 0;
	for (i=1;i<=ndim;i++) {
		if (i <= ji_1) {
			n = index_info[i+3];
			nn = index[i+3];
			if (nn <= 0) {
				/* cl_gx_conv_index2:[%s]�̃C���f�b�N�X�T�C�Y��0�ł��Bi=%d index=%d (def=None) */
				ERROROUT3(FORMAT(235),varnam,i,n);
				return ECL_SCRIPT_ERROR;
			}
			m1 = index[i+ndim+3];
			/* 2025.9.29 */
			if (!(range_ret & range_bit) && !m1) m1 = iSTART;
			range_bit <<= 1;
			m2 = m1 + nn - 1;
			if (n<m1 || n>m2) {
				/* cl_gx_conv_index2:[%s]�̃C���f�b�N�X���͈͊O�ł��Bi=%d index=%d (def=%d..%d) */
				ERROROUT5(FORMAT(236),varnam,i,n,m1,m2);
				return ECL_SCRIPT_ERROR;
			}
		}
		else if (index[i+3] > 1) mx = i;
	}
/*
printf("cl_gx_conv_index2: mx=%d ji_1=%d\n",mx,ji_1);
*/
	if (ji_1 > 0) {
		if (iIXPOS) {
			n = index_info[mx+3];
			/* 2025.9.29 */
			range_bit = 1;
			m1 = index[mx+ndim+3];
			if (!(range_ret & range_bit) && !m1) m1 = iSTART;
			range_bit <<= 1;
			n -= m1;
			for (i=1;i<mx;i++) {
				nn = index_info[mx-i+3];
				/* 2025.9.29 */
				m1 = index[mx-i+ndim+3];
				if (!(range_ret & range_bit) && !m1) m1 = iSTART;
				range_bit <<= 1;
				nn -= m1;
/*
printf("cl_gx_conv_index2: i=%d n=%d nn=%d f=%x\n",i,n,nn,f);
*/
				n = n*index[mx-i+3] + nn;
			}
		}
		else {
			n = index_info[4];
			/* 2025.9.29 */
			range_bit = 1;
			m1 = index[1+ndim+3];
			if (!(range_ret & range_bit) && !m1) m1 = iSTART;
			range_bit <<= 1;
			n -= index[1+ndim+3];
			for (i=2;i<=mx;i++) {
/*
printf("cl_gx_conv_index2: i=%d n=%d\n",i,n);
*/
				nn = index_info[i+3];
				/* 2025.9.29 */
				m1 = index[i+ndim+3];
				if (!(range_ret & range_bit) && !m1) m1 = iSTART;
				range_bit <<= 1;
				nn -= index[i+ndim+3];
				n = n*index[i+3] + nn;
			}
		}
	}
/*
printf("cl_gx_conv_index2: n=%d index[3]=%d\n",n,index[3]);
*/
	/* 2023.12.22 */
/*	i = n + index[3];	*/
	i = n + index[3] + 1;
	m1 = 0;
	m2 = index[1] - 1;
	if (n<m1 || n>m2) {
		/* cl_gx_conv_index2:[%s]�̃C���f�b�N�X���͈͊O�ł��Bn=%d index=%d (def=%d..%d) */
		ERROROUT5(FORMAT(236),varnam,0,n,m1,m2);
		i = ECL_SCRIPT_ERROR;
	}
	return i;
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_array_ent_opt(pVarIndex,iParmNo,opt)
tdtInfoParm *pVarIndex[];
int iParmNo;
char opt;
{
	tdtInfoParm *pDummy;

	if (!pVarIndex || iParmNo <= 0) return NULL;

	if (!(pDummy = pVarIndex[--iParmNo])) {
		if (opt == 's' || (pGlobTable->options[0] & 0x01)) {
			if (pDummy=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm))) {
				memset(pDummy,0,sizeof(tdtInfoParm));
				pVarIndex[iParmNo] = pDummy;
				if (pGlobTable->options[0] & 0x01) cl_null_char(pDummy);
			}
		}
	}
	return pDummy;
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_array_ent(pVarIndex,iParmNo)
tdtInfoParm *pVarIndex[];
int iParmNo;
{
	return cl_get_array_ent_opt(pVarIndex,iParmNo,'s');
}

/****************************************/
/*										*/
/****************************************/
int cl_free_array_ent(pIndex)
tdtArrayIndex *pIndex;
{
	tdtInfoParm *cpDat,**pVarIndex,**p,*pDummy;
	int *index;
	int i,n,ix,k,maxreg,attr,iMAX;
	XHASHB *xhp;
/*
printf("cl_free_array_ent: pIndex=%08x\n",pIndex);
*/
	if ((xhp=(XHASHB *)pIndex->xhp)) {
		/* 2025.12.31 */
		if ((n=akxs_xhash(xhp,'T',NULL)) > 0) {
			iMAX = xhp->xha_xhix;
DEBUGOUTL3(180,"cl_free_array_ent: xhp=%08x used=%d iMAX=%d",xhp,n,iMAX);
			k = 0;
			for (;;) {
				k = akxs_xhash_next_i(iMAX,xhp,k);
				if (k == AKX_HASH_NEXT_BREAK) break;
				xhp->xha_xhix = k;
					/* 2026.1.30 */
				ix = akxs_xhash2(xhp,'k',NULL,&pDummy);
				if (ix > 0) {
					if (pDummy) cl_free_info_parm(pDummy);
				}
			}
		}
		akxs_xhash_free(xhp);
		pIndex->xhp = NULL;
		if (pVarIndex = pIndex->pVarIndex) {
			if (!(pIndex->uAttr[1] & D_ATR1_NO_MALLOC)) Free(pVarIndex);
			pIndex->pVarIndex = NULL;
		}
	}
	else if (pVarIndex = pIndex->pVarIndex) {
/*
printf("cl_free_array_ent: pVarIndex=%08x\n",pVarIndex);
*/
		if (((attr=pIndex->uAttr[0])==DEF_ZOK_VARI) ||
		    ((attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK) && !pIndex->size)) {
			index = pIndex->index;
			n = index[1];
DEBUGOUTL2(180,"cl_free_array_ent: pVarIndex=%08x n=%d",pVarIndex,n);
			for (i=0,p=pVarIndex;i<n;i++,p++) {
				if (pDummy = *p) {
					cl_free_info_parm(pDummy);
					Free(pDummy);
				}
			}
		}

DEBUGOUTL1(180,"cl_free_array_ent: pIndex->uAttr[1]=%08x",pIndex->uAttr[1]);

		if (!(pIndex->uAttr[1] & D_ATR1_NO_MALLOC)) Free(pVarIndex);
		pIndex->pVarIndex = NULL;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_array_val_opt(pInfoParmW,pIndex,iParmNo,opt)
tdtInfoParm *pInfoParmW;
tdtArrayIndex *pIndex;
int iParmNo;
char opt;
{
	tdtInfoParm *pInfoParm, *pParm;
	char *p,*pp,*ps;
	uchar uSCALE;
	int *pi,val,attr,len,size,*index,iCOMPLEX,iRATIONAL,iRANGE;
	double *pd;

	if (!pIndex || !pInfoParmW) return -1;	/* 2025.9.8 add !pInfoParmW */
	if (iParmNo <= 0) return -1;	/* add 2025.10.22 */
	attr = pIndex->uAttr[0];
	size = pIndex->size;
DEBUGOUTL2(194,"cl_get_array_val_opt: attr=%d size=%d",attr,size);
	if (!attr) {
		/* cl_get_array_val_opt: can't use hash arrray!! */
		ERROROUT(FORMAT(237));
		return ECL_SCRIPT_ERROR;
	}
	p = (char *)pIndex->pVarIndex;
	iParmNo--;
/*
printf("cl_get_array_val_opt: iParmNo=%d pIndex->uaux1=%04x p=%08x\n",iParmNo,pIndex->uaux1,p);
*/
	/* 2025.4.15 */
	if (iRANGE=(pIndex->uaux1 & D_AULN_RANGE_DATA)) iParmNo += iParmNo;
	/* 2023.5.16 */
	if (attr == 2) {
		uSCALE = pIndex->uAttr[3];
	}
	else uSCALE = 0;
	if (opt == 's') {
		if (!(pInfoParm=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))))
			return ECL_SYSTEM_ERROR;
		pParm = pInfoParm;
	}
	else pParm = pInfoParmW;	/* 2025.9.8 del if */

	if (attr == DEF_ZOK_BINA) {
		pp = (char *)&((int *)p)[iParmNo];
		pi = (int *)pp;
		cl_set_parm_bin(pParm,*pi);
/*
printf("cl_get_array_val_opt:BINA iParmNo=%d pp=%08x *pi=%d\n",iParmNo,pp,*pi);
*/
		/* 2025.4.15 */
		if (iRANGE) pParm->pi_hlen = *(pi+1);
	}
	else if (attr == DEF_ZOK_FLOA) {
		pp = (char *)&((double *)p)[iParmNo];
		pd = (double *)pp;
		cl_set_parm_double(pParm,*pd);
/*
printf("cl_get_array_val_opt:FLOA iParmNo=%d pp=%08x *pd=%e\n",iParmNo,pp,*pd);
*/
		/* 2025.4.15 */
		if (iRANGE) {
			pParm->pi_scale &= ~D_DATA_LPOSDATA;
			pParm->pi_data = pp;
		}
	}
	else if (attr == DEF_ZOK_DECI) {
		/* 2021.10.11 */
		pp = p + iParmNo*sizeofMPA();
		memset(pParm,0,sizeof(tdtInfoParm));
		pParm->pi_id = ' ';
		pParm->pi_attr = DEF_ZOK_DECI;
		pParm->pi_dlen = sizeofMPA();
		pParm->pi_data = pp;
		pParm->pi_hlen = pIndex->uAttr[2];	/* precision */
		pParm->pi_pos = pIndex->uAttr[3];	/* scale */
	}
	else if (attr == DEF_ZOK_CHAR) {
		pp = p + iParmNo*(size+1);
		*(pp+size) = '\0';
		cl_set_parm_char(pParm,pp,strlen(pp));
	}
	else if (attr == DEF_ZOK_DATE) {
		/* 2021.10.11 */
		pp = p + iParmNo*sizeofMPA();
		cl_set_parm_date(pParm,(MPA *)pp);
	}
	else if (attr == DEF_ZOK_BULK) {
		pp = p + iParmNo*(size+sizeof(int));
		memcpy(&len,pp+size,sizeof(int));
		cl_set_parm_char(pParm,pp,len);
		pParm->pi_attr = attr;
	}
	pParm->pi_alen = pIndex->uaux1 & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA | D_AULN_RATIONAL);
	pParm->pi_scale |= uSCALE;
DEBUGOUTL2(194,"cl_get_array_val_opt: p=%08x pp=%08x",p,pp);
DEBUGOUT_InfoParm(194,"cl_get_array_val_opt: iParm-1=%d opt=%c",pParm,iParmNo,opt);
/*
printf("cl_get_array_val_opt: opt=%c attr=%d pp=%08x scale=%02x\n",opt,attr,pp,uSCALE);
*/
	if (opt == 's') {
		pInfoParm->pi_aux[0] = attr;
		pInfoParm->pi_len = size;
		pInfoParm->pi_paux = pp;
		cl_set_parm_long(pInfoParmW,(long)pInfoParm);
		pInfoParmW->pi_id  = 'S';
		/* 2022.8.26 */
	/*	pInfoParmW->pi_paux = ps;	*/
/*
printf("cl_get_array_val_opt: iParmNo=%d scale=%02x\n",iParmNo,*ps);
*/
DEBUGOUT_InfoParm(194,"cl_get_array_val_opt: ",pInfoParmW,0,0);
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_array_get_info_parm(ppParmI,pIndex1,pTBL1,ix1,opt)
tdtInfoParm **ppParmI;
tdtArrayIndex *pIndex1;
tdtInfoParm ***pTBL1;
int ix1;
char opt;
{
	XHASHB *xhp1;
	tdtInfoParm *pParmI;
	int iRc;
	char *cpKey,*cpDat;

	if (ix1 <= 0) return -1;

	iRc = 0;
	pParmI = NULL;
	xhp1 = pIndex1->xhp;
DEBUGOUTL1(194,"cl_array_get_info_parm: xhp1=%08x",xhp1);
	if (xhp1) {
		xhp1->xha_xhix = ix1;
		/* 2026.1.30 */
		if ((iRc=akxs_xhash2(xhp1,'P',&cpKey,&pParmI)) > 0) {
			xhp1->xha_hashb->ha_key = cpKey;
/*
printf("cl_array_get_info_parm: ix1=%d key=[%s] pParm=%08x\n",ix1,cpKey,pParmI);
*/
		}
	}
	else {
		pParmI = cl_get_array_and_var_ent_opt(pIndex1,pTBL1,ix1,opt);
		iRc = 1;
	}
	*ppParmI = pParmI;
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_array_info(pInfoParm,pIndex,ppTBL,iParm)
tdtInfoParm *pInfoParm;
tdtArrayIndex *pIndex;
tdtInfoParm ****ppTBL;
int iParm[];
{
	tdtArrayIndex *pIndexW;
	int iRc;

	pIndexW = pIndex;
	if (!(iRc=cl_get_array_info_ref(pInfoParm,&pIndexW,ppTBL,iParm))) {
		if (pIndexW != pIndex) memcpy(pIndex,pIndexW,sizeof(tdtArrayIndex));
	}
	return iRc;
}

/********1*********2*********3*********4*********5*******/
/*	�����F	ppIndex : *ppIndex �ɂ́A&tIndex ���A		*/
/*					    �ݒ肳��Ă��邱��				*/
/*					  *ppIndex �ɂ́AA or R �̂Ƃ��A	*/
/*						�z���pIndex���Ԃ����B		*/
/*		�ʏ�z��:										*/
/*			iParm[1] : �ő�v�f��						*/
/*			iParm[2] : off_set (�z��̊J�n�ʒu(�擪��1))*/
/*			iParm[3] : �ݒ�ςݗv�f�̐擪����̍ő�ʒu(�擪��1)*/
/*														*/
/*			iParm[2]�`iParm[3]��*�w��ŏo�͂����z���ParmNo�ł͈̔͂ƂȂ� */
/*			iParm[3]-iParm[2]+1���o�͂�����			*/
/*		HASH�z��:										*/
/*			iParm[1] : �ő�v�f��						*/
/*			iParm[2] : 1								*/
/*			iParm[3] : �ݒ�ςݗv�f��					*/
/********************************************************/
int cl_get_array_info_ref(pInfoParm,ppIndex,ppTBL,iParm)
tdtInfoParm *pInfoParm;
tdtArrayIndex **ppIndex;
tdtInfoParm ****ppTBL;
int iParm[];
{
	static char *_fn_ = "cl_get_array_info_ref";
	int iRc,ix0,*index,offset;
	XHASHB *xhp;
	tdtArrayIndex *pIndex;

	mem_set_int(iParm,0,4);
	pIndex = *ppIndex;
/*
printf("%s:1 pIndex=%08x Index=%08x\n",_fn_,pIndex,pIndex->index);
*/
	if (pInfoParm->pi_data != (char *)pIndex) memset(pIndex,0,sizeof(tdtArrayIndex));
	if (iRc=cl_get_array_index_tbl_ref(pInfoParm,ppIndex,ppTBL,"cl_get_array_info_ref:")) return iRc;
	if (pIndex = *ppIndex) {
/*
printf("%s:2 pIndex=%08x Index=%08x\n",_fn_,pIndex,pIndex->index);
*/
		if (pInfoParm->pi_id=='R' && (xhp=pIndex->xhp)) {
			iParm[1] = akxs_xhash2(xhp,'M',NULL,NULL);	/* �ő�v�f�� */
			iParm[2] = 1;								/* Hash Index�̊J�n�ԍ� */
		/*	iParm[2] = 0;	*/							/* Hash Index�̊J�n�ԍ� */
			iParm[3] = akxs_xhash2(xhp,'U',NULL,NULL);	/* �ݒ�ςݗv�f�� */
		}
		else {
			index = pIndex->index;
/*
printf("%s: index=%08x index[0]..[3] =%d %d %d %d\n",_fn_,index,index[0],index[1],index[2],index[3]);
*/
			iParm[1] = index[1];	/* �ő�v�f�� */
		/*	iParm[2] = index[3];	*/	/* off_set (�z��̊J�n�ʒu(�擪��1))*/
			iParm[2] = index[3] + 1;	/* off_set (�z��̊J�n�ʒu(�擪��1))*/
			/* 2023.12.18 */
		/*	offset = index[3] - 1;	*/
			offset = index[3];
			/* 2023.2.10 */
			iParm[3] = X_MIN(index[2],index[1]) + offset;	/* �ݒ�ςݗv�f�̐擪����̍ő�ʒu(�擪��1), <0 HASH 2020.4.30 */
			/* iParm[2]�`iParm[3]��*�w��ŏo�͂����z���ParmNo�ł͈̔͂ƂȂ� */

DEBUGOUTL5(194,"%s: iParm[0]..[3] =%d %d %d %d",_fn_,iParm[0],iParm[1],iParm[2],iParm[3]);

		}
/*
printf("%s: iParm[0]..[3] =%d %d %d %d\n",_fn_,iParm[0],iParm[1],iParm[2],iParm[3]);
*/
	}
	return 0;
}

/****************************************/
/*	�Ώۂ́A$()�����܂ވ�ʔz��		*/
/****************************************/
int cl_get_mapped_array(pInfoParmW,pInfoParm1,pOperator,pInfoParm2)
char *pOperator;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
tdtInfoParm *pInfoParmW;
{
	static char *_fn_="cl_get_mapped_array";
	tdtInfoParm *pInfoParmA,*pInfoParm,*pparm[MAX_ARRAY_DIM],*pInfo;
	tdtArrayIndex *pIndex;
	char c,id1,id2,id,*p,id0;
	int rc,*index,n,i,m,nr,iUNSIGN,nparm,index0[4],offset,iSTART,dim;
	long ix;
	ulong uix;
	tdtRbCtl *pCt,*pCtI;

	if ((c=*pOperator)!='+' && c!='-') {
		/* %s: ���Z(%s)�͎g�p�ł��܂���B */
		ERROROUT2(FORMAT(238),_fn_,pOperator);
		return ECL_SCRIPT_ERROR;
	}
	/* 2023.2.8 */
	if ((id1=pInfoParm1->pi_id)=='A' || id1=='R') {
		pInfoParmA = pInfoParm1;
		pInfoParm  = pInfoParm2;
		id0 = id1;	/* add 2025.9.15 */
	}
	else if ((id2=pInfoParm2->pi_id)=='A' || id2=='R') {
		/* 2025.9.22 */
		if (c == '-') {
			ERROROUT2(FORMAT(48),_fn_,ECL_SCRIPT_ERROR);	/* %s: ��������Ă��܂�(rc=%d)�B*/
			return ECL_SCRIPT_ERROR;
		}
		pInfoParmA = pInfoParm2;
		pInfoParm  = pInfoParm1;
		id0 = id2;	/* add 2025.9.15 */
	}
	else {
		return -1;
	}
	if ((id=pInfoParm->pi_id)==' ') {
		nparm = 1;
	}
	else if (id=='N' || id=='L') {
		pCtI = (tdtRbCtl *)pInfoParm->pi_data;
		akxs_rb_read(pCtI,0);
		nparm = 0;
		while (pInfo=(tdtInfoParm *)akxs_rb_read(pCtI,1)) {
			pparm[nparm++] = pInfo;
		}
		if (!nparm) {
			ERROROUT2(FORMAT(76),_fn_,"map index ");	/* %s: %s������܂���B*/
			return ECL_SCRIPT_ERROR;
		}
		else if (nparm == 1) {
			pInfoParm = pparm[0];
		}
	}
	else {
		return -1;
	}
	pIndex = (tdtArrayIndex *)pInfoParmA->pi_data;
	if (pIndex->xhp) {
		/* %s: �A�z�z��(%s)�͎w��ł��܂���B */
		ERROROUT2(FORMAT(239),_fn_,pInfoParmA->pi_pos);
		return ECL_SCRIPT_ERROR;
	}
	if (rc=cl_gx_rep_info_set_ign(pInfoParmW,pInfoParmA,1)) return rc;
	pIndex = (tdtArrayIndex *)pInfoParmW->pi_data;
	pIndex->uAttr[1] = D_ATR1_NO_MALLOC;
	index = pIndex->index;
	mem_cpy_int(index0,index,4);
/*
printf("cl_get_mapped_array: nparm=%d index=%d %d %d %d %d %d\n",
nparm,index[0],index[1],index[2],index[3],index[4],index[5]);
*/
	/* 2025.9.15 */
	iSTART = 0;
	if (nparm > 1) {
		if ((rc=_set_index2(0,nparm,NULL,0,index,_fn_,pparm)) < 0) return rc;
/*
dim=index[0];
for (i=0;i<dim*2+4;i++) printf("index[%i]=%d\n",i,index[i]);
*/
/*
printf("cl_get_mapped_array: index =%d %d %d %d\n",index[0], index[1], index[2], index[3]);
printf("cl_get_mapped_array: index0=%d %d %d %d\n",index0[0],index0[1],index0[2],index0[3]);
*/
		if (c == '-') index[3] = -index[3];	/* add 2025.9.30 */
		/* 2023.12.22 */
	/*	offset = index0[3] - 1;	*/
		offset = index0[3];
		m = index0[1] + offset;
		index[3] += offset - iSTART;	/* 2025.9.15 add "- iSTART" */
	/*	offset = index[3] - 1;	*/
		offset = index[3];
		index[2] -= offset;		/* add 2025.9.12 */
	/*	if ((id0=='R' && index[3]<0) || (id0=='A' && index[3]<=0)) {	*/
		/* 2025.9.24 */
	/*	if (offset<=0 || offset>m) {	*/
		if (offset<0 || offset>=m) {
			/* %s: map�ʒu(%d)���͈͊O�ł��B(%d..%d) */
			ERROROUT4(FORMAT(240),_fn_,offset,iSTART,m-1+iSTART);
			return ECL_SCRIPT_ERROR;
		}
		else if (m < index[1]+offset) {
			m -= offset;
			index[0] = 1;
			index[1] = m;
			index[4] = m;
			index[5] = 0;
					/* %s: �w�肵���z��̗v�f�������̔z��̗v�f���𒴂������߁A1�����ɂ��܂��B*/
			ERROROUT3(FORMAT(665),_fn_,index[1]-offset,m);
		}
		/* 2025.9.15 *//* 2025.9.18 1==>0 FORTRAN�`���̐ݒ�́A_set_index2()�̒��ł���Ă���B
		   �܂��A�}�b�v�z��ł́A$()���ł�index[5]��1�̐ݒ�́A�����p���Ȃ� */
		if (index[2] > index[1]) index[2] = index[1];	/* add 2025.9.12 */
	}
	else {
		if (pInfoParm->pi_alen & D_AULN_RANGE_DATA) {
			/* %s: �� %d ���� �}�b�v�C���f�b�N�X�ɔ͈͎w��[%s]�́A�w��ł��܂���B */
			cl_get_range_str(pInfoParm,&p);
			if (!p) p = "";
			ERROROUT3(FORMAT(420),_fn_,1,p);
			return ECL_SCRIPT_ERROR;
		}
		if (rc=cl_get_parm_bin(pInfoParm,&ix,FORMAT(163))) return rc;	/* ���� */
		iUNSIGN = pInfoParm1->pi_scale & D_DATA_UNSIGNED;
		ix -= iSTART;	/* add 2025.9.15 */
		uix = ix;
		if (!iUNSIGN && c=='-') ix = -ix;	/* add 2021.3.29 */
		n = index[1];
/*
printf("cl_get_mapped_array: iSTART=%d ix=%d n=%d index=%d %d %d %d %d %d\n",
iSTART,ix,n,index[0],index[1],index[2],index[3],index[4],index[5]);
*/
		/* 2021.3.29 */
		if (iUNSIGN) {
			if (c == '+') i = index[3] + uix;
			else i = index[3] - uix;
		}
		else i = index[3] + ix;
	/*	if (i<=0 || i>n) {	*/
		if (i<0 || i>=n) {
			/* %s: map�ʒu(%d)���͈͊O�ł��B(%d..%d) */
			ERROROUT4(FORMAT(240),_fn_,ix,iSTART,n-1+iSTART);
			return ECL_SCRIPT_ERROR;
		}
		/* 2021.3.29 */
		index[3] = i;
	/*	index[3] = i - 1;	*/
		nr = n - ix;
		index[0] = 1;
		index[1] = nr;
		index[2] -= ix;
		if (index[2] <0 ) index[2] = 0;
		index[4] = nr;
		/* 2023.10.6 */
	/*	if (!iSTART) {	*/
			if (cl_get_option(15,0) & 0x01) m = 1;
			else m = 0;
	/*	}
		else m = iSTART;	*/
		index[5] = m;
	}
/*
printf("cl_get_mapped_array: ix=%d nr=%d index=%d %d %d %d %d %d\n",
ix,nr,index[0],index[1],index[2],index[3],index[4],index[5]);
*/

DEBUGOUT_InfoParm(170,"cl_get_mapped_array: ",pInfoParmW,0,0);
/*
printf("cl_get_mapped_array:Exit index=%d %d %d %d %d %d\n",
index[0],index[1],index[2],index[3],index[4],index[5]);
*/
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_array_map(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int nparm;
tdtInfoParm *ppParm[];
{
	static char *_fn_="cl_array_map";
	tdtInfoParm *pInfoParmA;
	tdtArrayIndex *pIndex;
	char c,id1,id2;
	int rc,ix,*index,n,i,ind[MAX_ARRAY_DIM+1],f,iRANGE,iSTART,ndim,i1,i2,k;

	pInfoParmA = ppParm[0];
	if ((id1=pInfoParmA->pi_id)!='A' && id1!='R') {
		/* %s: ��P�������z��ł͂���܂���Bid=[%c] */
		ERROROUT2(FORMAT(246),_fn_,id1);
		return ECL_SCRIPT_ERROR;
	}
	pIndex = (tdtArrayIndex *)pInfoParmA->pi_data;
	if (pIndex->xhp) {
		/* %s: �A�z�z��(%s)�͎w��ł��܂���B */
		ERROROUT2(FORMAT(239),_fn_,pInfoParmA->pi_pos);
		return ECL_SCRIPT_ERROR;
	}
	if (nparm==2 && ((id1=ppParm[1]->pi_id)=='L' || id1=='N')) {
		return cl_get_mapped_array(pInfoParmW,ppParm[0],"+",ppParm[1]);
	}
	if (rc=cl_func_index(&ix,nparm,ppParm)) return rc;
/*
printf("cl_array_map: ix=%d\n",ix);
*/
	/* 2023.12.23 */
	index = pIndex->index;
	ndim = index[0];
	nparm = X_MIN(nparm-1,ndim);
	for (i=1;i<=nparm;i++) {
		if (rc=cl_get_parm_bin(ppParm[i],&ind[i],"index")) return rc;
/*
printf("cl_array_map: ind[%d]=%d\n",i,ind[i]);
*/
	}
	if (rc=cl_gx_rep_info_set_ign(pInfoParmW,pInfoParmA,1)) return rc;
	pIndex = (tdtArrayIndex *)pInfoParmW->pi_data;
	index = pIndex->index;
	n = index[1];
/*
printf("cl_array_map: index=");
for (i=0;i<ndim*2+4;i++) printf("%d ",index[i]);
printf("ix=%d\n",ix);
*/
	/* 2025.12.25 */
	iSTART = 0;
	n--;
	i = ix - iSTART;
	if (i<0 || i>=n) {
		/* %s: map�ʒu(%d)���͈͊O�ł��B(def=%d..%d) */
		ERROROUT4(FORMAT(240),_fn_,ix,iSTART,n);
		return ECL_SCRIPT_ERROR;
	}
	index[3] += i;
/*	index[3] += i - 1;	*//* 2025.12.25 */
	/* 2023.10.6 */
	i1 = 4;
	i2 = i1 + ndim;
	n = 1;
	for (i=1;i<=nparm;i++,i1++,i2++) {
		index[i1] -= ind[i] - index[i2];
		if (index[i1] <= 0) {
			/* %s: map�ʒu(i=%d %d)���͈͊O�ł��B */
			ERROROUT3(FORMAT(247),_fn_,i,ind[i]);
			return ECL_SCRIPT_ERROR;
		}
		n *= index[i1];
/*
printf("cl_array_map: index[%d]=%d n=%d\n",i1,index[i1],n);
*/
	}
	for (;i<=ndim;i++,i1++) {
		n *= index[i1];
/*
printf("              index[%d]=%d n=%d\n",i1,index[i1],n);
*/
	}
	index[1] = n;
	/* 2023.12.24 */
/*	index[2] = index[2] - index[3] + 1;	*/
	index[2] = index[2] - index[3];
	if (index[2] < 0) index[2] = 0;
/*	index[0] = i;	del 2021.5.5 */
/*
printf("cl_array_map: index=");
for (i=0;i<ndim*2+4;i++) printf("%d ",index[i]);
printf("\n");
*/
DEBUGOUT_InfoParm(170,"cl_get_mapped_array: ",pInfoParmW,0,0);

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_range_int(pInfoParm,range)
tdtInfoParm *pInfoParm;
tdtRangeInt *range;
{
	tdtInfoParm tInfoParm[3],*ppParm[3];
	int i,rc,iVal[2],*index;

	for (i=0;i<3;i++) ppParm[i] = &tInfoParm[i];
	if ((rc=cl_get_range_info(pInfoParm,ppParm,iVal,1)) >= 0) {
		range->ri_interval = iVal[1];
		range->ri_num = iVal[0];
		index = (int *)range;
		for (i=0;i<2;i++) {
			if ((rc=cl_get_parm_bin(ppParm[i],&index[i],"cl_get_range_int: ")) < 0) break;
/*
printf("cl_get_range_int: index[%d]=%d\n",i,index[i]);
*/
			rc = 0;
		}
/*
printf("cl_get_range_int: ri_start=%d ri_end=%d\n",range->ri_start,range->ri_end);
*/
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _get_ParmNo_array(range,ndim,idim,index,index_info,varnam,mcat)
tdtRangeInt range[];
int ndim,idim,*index,*index_info;
char *varnam;
MCAT *mcat;
{
	int i,i1,i2,nm,intval,rc,k;
/*
printf("_get_ParmNo_array:Enter ndim=%d idim=%d varnam=[%s]\n",ndim,idim,varnam);
*/
	rc = 0;
	for (i=idim;i<ndim;i++) {
		if (range[i].ri_num > 1) {
			i1 = range[i].ri_start;
			i2 = range[i].ri_end;
			intval = range[i].ri_interval;
			/* 2025.9.10 */
			for (k=i1;;k+=intval) {
				if (intval > 0) {
					if (k > i2) break;
				}
				else {
					if (k < i2) break;
				}
/*
printf("_get_ParmNo_array: i=%d k=%d\n",i,k);
*/
				range[i].ri_start = k;
				range[i].ri_end = 0;
				range[i].ri_num = 1;
				if ((rc=_get_ParmNo_array(range,ndim,i,index,index_info,varnam,mcat)) < 0) break;
			}
		}
		else {
			index_info[i+4] = range[i].ri_start;
			if (i == ndim-1) {
				if ((rc=cl_gx_conv_index2(index,index_info,varnam)) < 0) break;
/*
printf("_get_ParmNo_array: i=%d ParmNo=%d\n",i,rc);
*/
				akxtmcat(mcat,&rc,sizeof(int));
				rc = 0;
			}
		}
	}
/*
printf("_get_ParmNo_array:Exit rc=%d\n",rc);
*/
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_def_array_tmp_opt(ppInfoParm,nm,pInfoParmW,opt)
tdtInfoParm **ppInfoParm,*pInfoParmW;
int nm,opt;
{
	tdtInfoParm *pInfoParm,**ppParm;
	tdtArrayIndex *pIndexW;
	char *pp,hakey[Var_NM_MAX*2+2];
	int rc,len,*indexW,hakey_len;
	ProcCT *proc;
	ScrPrCT *scr;
	XHASHB *pha;
/*
printf("cl_def_array_tmp:Enter nm=%d pInfoParmW=%08x opt=%08x\n",nm,pInfoParmW,opt);
*/
	if (!ppInfoParm || nm<=0) return -1;

	len = sizeof(tdtArrayIndex);
	if (!(pp = Malloc(len))) return ECL_MALLOC_ERROR;
	memset(pp,0,len);
	sprintf(hakey,"$$tmp_array%08x",pp);
	hakey_len = strlen(hakey);
	if (proc = cl_search_proc_ct()) {
		pha = proc->pha_vnam;
	}
	else if(scr = cl_search_scr_ct()) pha = scr->Vary->pha_vnam;
	else return -1;
/*
printf("cl_def_array_tmp: pha=%08x hakey=[%s]\n",pha,hakey);
*/
	if ((rc=cl_gx_chk_vnam_info('s',pha,hakey,hakey_len,&pInfoParm)) < 1) return -1;
	if (pInfoParmW) {
		*pInfoParm = *pInfoParmW;
		cl_set_parm_long(pInfoParmW,pInfoParm);
		pInfoParmW->pi_id = 'S';
	}
	pInfoParm->pi_id = 'R';
	pInfoParm->pi_scale = D_DATA_MALLOC | D_DATA_INDEX_FREE;
	pInfoParm->pi_attr = DEF_ZOK_BULK;
	pInfoParm->pi_dlen = sizeof(tdtArrayIndex);
	pInfoParm->pi_alen |= D_AULN_NO_AL_LPOS;
	pInfoParm->pi_data = pp;
	pInfoParm->pi_pos  = (long)Strdup(hakey);
	pInfoParm->pi_hlen = _get_gid(NULL,NULL,0);
	pInfoParm->pi_paux = (char *)pInfoParm;
	pIndexW = (tdtArrayIndex *)pp;
	pIndexW->uAttr[0] = DEF_ZOK_VARI;
	pIndexW->uAttr[1] = sizeof(tdtInfoParm *);
	pIndexW->size = sizeof(tdtInfoParm *);
	indexW = pIndexW->index;
	indexW[0] = 1;
	indexW[1] = nm;
	indexW[2] = nm;
/*	indexW[3] = 1;	*/
	indexW[3] = 0;
	indexW[4] = nm;
	if (opt & 0x01) {
		pIndexW->size = sizeof(tdtInfoParm);
		indexW[2] = -1;
		/* 2026.1.30 */
		if (!(pIndexW->xhp=akxs_xhash_new2(0,nm,0,sizeof(tdtInfoParm)))) return -9;
/*
printf("cl_def_array_tmp: xhp=%08x\n",pIndexW->xhp);
*/
	}
	else {
		len = nm*(sizeof(tdtInfoParm *));
		if (!(ppParm = (tdtInfoParm **)Malloc(len))) return ECL_MALLOC_ERROR;
		memset(ppParm,0,len);
		pIndexW->pVarIndex = ppParm;
	}
	*ppInfoParm = pInfoParm;

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_def_array_tmp(ppInfoParm,nm,pInfoParmW)
tdtInfoParm **ppInfoParm,*pInfoParmW;
int nm;
{
	return cl_def_array_tmp_opt(ppInfoParm,nm,pInfoParmW,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_get_array_range(pInfoParmW,pIndex,pTBL,range,varnam,opti)
tdtInfoParm *pInfoParmW;
tdtArrayIndex *pIndex;
tdtInfoParm ***pTBL;
tdtRangeInt *range;
char *varnam;
int opti;
{
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	tdtInfoParm *pParmI,*pInfoParm1,*pInfoParm,**ppParm;
	tdtArrayIndex *pIndexW;
	char *p,*pp,*p0,hakey[Var_NM_MAX*2+2];
	int rc,i,nm,*index,ndim,ParmNo,index_info[MAX_ARRAY_DIM+4],len,*indexW,hakey_len;
	ProcCT *proc;
	ScrPrCT *scr;
	XHASHB *pha;
/*
printf("cl_get_array_range:Enter pIndex=%08x pTBL=%08x range==%08x varnam=[%s] opti=%08x\n",pIndex,pTBL,range,varnam,opti);
*/
	if (!pInfoParmW || !pIndex || !range) return -1;
	mcat.mc_ipos = 0;
	index = pIndex->index;
	ndim = index[0];
	mem_set_int(index_info,0,4+ndim*2);
	index_info[0] = ndim;
	/* 2025.9.29 */
	index_info[3] = pIndex->uaux2;
	if ((rc=_get_ParmNo_array(range,ndim,0,index,index_info,varnam,&mcat)) < 0) return rc;
	rc = 0;
	if ((nm=mcat.mc_ipos) > 0) {
		nm /= sizeof(int);
		p = mcat.mc_bufp;
		/* 2025.9.11 */
		if ((rc=cl_def_array_tmp(&pInfoParm,nm,pInfoParmW)) < 0) {
			return rc;
		}
		else {
			pIndexW = (tdtArrayIndex *)pInfoParm->pi_data;
			ppParm = pIndexW->pVarIndex;
			/* 2025.6.22 */
			for (i=0;i<nm;i++,p+=sizeof(int)) {
				memcpy(&ParmNo,p,sizeof(int));

DEBUGOUTL1(194,"cl_get_array_range: ParmNo=%d",ParmNo);
/*
printf("cl_get_array_range: ParmNo=%d\n",ParmNo);
*/
				if (ParmNo > 0) {
					if ((rc=cl_array_get_info_parm(&pParmI,pIndex,pTBL,ParmNo,'r')) < 0) break;
DEBUGOUT_InfoParm(170,"cl_get_array_range: i=%d",pParmI,i,0);
					/* 2025.6.22 */
					if (!(pp = Malloc(sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
					cl_gx_rep_info_set_ign(pp,pParmI,0);
					ppParm[i] = (tdtInfoParm *)pp;
					rc = 0;
				}
				else {
					rc = ParmNo;
					if (!rc) rc = -12;
					break;
				}
				/* 2025.6.22 */
			}
DEBUGOUT_InfoParm(170,"cl_get_array_range: ",pInfoParmW,0,0);
		}
	}
/*
printf("cl_get_array_range:Exit rc=%d\n",rc);
*/
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_max_array_index(pIndex,ix0,nm)
tdtArrayIndex *pIndex;
int ix0,nm;
{
	int *index;
/*
printf("cl_set_max_array_index:Enter ix0=%d nm=%d\n",ix0,nm);
*/
	index = pIndex->index;
/*
printf("cl_set_max_array_index: index = %d %d %d %d %d\n",
index[0],index[1],index[2],index[3],index[4]);
*/
	nm += ix0;
	/* 2023.12.20 */
	if (index[2] < nm) index[2] = nm;
/*
printf("cl_set_max_array_index:Exit index[2]=%d\n",index[2]);
*/
	return nm;
}
