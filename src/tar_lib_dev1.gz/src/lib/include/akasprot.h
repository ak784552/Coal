/*static    char    sccsid[]="%Z% %M% %I% %D% %T%";*/
/*********************************************************/
/*                                                       */
/*     akaaprot.h                                        */
/*                                                       */
/*              coded by A.Kobayashi 2010.10.11          */
/*                                                       */
/*********************************************************/
#ifndef _AKASPROT_H
#define _AKASPROT_H

/*akacomm.c */
int aka_get_msec(/*ptval*/);
int aka_register_timer(/*cpTimerName,pFuncName,iWaitTime,cpParm*/);
int aka_cancel_timer(/*iTimerId*/);
int aka_timer_proc();
int aka_wake_up_timer(/*opt,obj,event*/);
int aka_start_timer(/*opt,obj*/);
int aka_stop_timer(/*opt,obj*/);
int aka_timer_min_wait();
int aka_get_my_apsys_id();
int aka_get_min_wait_time(/*iWaitTime*/);
tdtRWQ_TIME_OUT *aka_rwque_time_out_new(/*iQueMax,parm*/ /* ,_rwque_time_out_timer */);
int aka_rwqtset_parm(/*parm*/);
int aka_update_qremain_flg();
int aka_rwque_timer_ctl();
int aka_rwque_remain(/*iRW*/);
int aka_rwque_get_akb_time_out(/*parm*/);
int  aka_shut_control(/*iAttribute,cpValue*/);
int aka_set_ver_date(/*ver,date*/);
int aka_get_ver_date(/*cpVerDate,iVerDateLen*/);
int aka_set_msg_time_out(/*iTimeOut*/);
int aka_set_up_msg_time_out(/*cpProcName*/);
int aka_get_msec_l(/*ptval*/);
int aka_cha_rb_regist_timer(/*iTimerId*/);

/* akaclass.c */
int aka_statistics_count(/*i,iLen*/);
int aka_sys_password_class(/*lInstanceHandle,cpInstanceData,tpRecvMsg*/);
int aka_sys_password_check(/*usProcId*/);

/*akasys.c */
int aka_initialize(/*iSd,iProcNumber,iMaxThreadTotal,
                  pRbRCtl,pRbWCtl,pRbWWCtl,RbWCtlPA,RbPriCtlPA,
                  ReadQuePA,WriteQuePA,iQueMax,pDataQueUsed,
                  pCommandClass,pHPToEntry,iQueAkbUsed*/);
int aka_sys_reply_msg_delay(/*lInstanceHandle,tpReplyMsg,iWaitTime,cpWaitName*/);
int aka_sys_reply_msg(/*lInstanceHandle,tpReplyMsg*/);
int aka_del_reply_wait(/*usProcId,sCommand*/);
int aka_set_wait(/*lInstanceHandle,tpWaitMsg,iWaitTime,cpWaitName*/);
int aka_sys_rwque_time_out_new(/*parm_dummy,_close_sd_func,pData*/);
int aka_get_msg(/*iWaitTime,akbPacketRead,akbPacketWrite*/);
int aka_put_msg(/*iRetry,akbPacketWrite*/);

/*akasys2.c */
int aka_registerClass(/*pFuncName,iClassId,iInstanceDataSize,iMaxThread,iOption*/);
int aka_registerClass2(/*pFuncName,iClassId,iInstanceDataSize,iMaxThread,iOption,
                     cpClassName*/);
int aka_registerClass3(/*pFuncName,iClassId,iInstanceDataSize,iMaxThread,iOption,
                     cpClassName,cpUserArea*/);
int aka_instance_buf_free(/*tpIns*/);
void aka_wait_packet_free(/*tpWait*/);
int aka_instance_init(/*iOpt, tpIns, iInstanceDataSize*/);
int aka_conv_inst_hndl2(/*lInstanceHandle, tpInstHndl, iOpt*/);
int aka_conv_inst_hndl(/*lInstanceHandle, tpInstHndl*/);
int aka_expand_tables(/*iAdd*/);
int aka_init_zero(/*iSd*/);

/*akasys3.c */
tdtCLASS_CTL *aka_srch_class2(/*iClassId,opt*/);
tdtCLASS_CTL *aka_srch_class(/*iClassId*/);
int aka_dispatch(/*pNew*/);

#endif	/* _AKASPROT_H */
