/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akbprot.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.6.18						*/
/*																		*/
/************************************************************************/
#ifndef _AKBPROT_H
#define _AKBPROT_H

/************************************************
 �֐��錾
 *************************************************/
/* akbbyname.c */
int akb_gs_akb_name2(/*cpBlock,cpName,cpArg,size*/);
int akb_gs_akb_name(/*cpBlock,cpName,cpArg*/);
int akbgetakbservname(/*cpProcName,service*/);
char *akb_akb_home(/*iReSet*/);
char *akb_akb_home_add(/*cpFile*/);
int akb_gs_akb_stpl(/*cpBlock,cpName,argv,maxargv*/);
int akb_gs_akb_stpli(/*cpBlock,colm,cpName,argv,maxargv*/);
int akb_gs_akb_stplix(/*cpBlock,colm,cpName,argv,maxargv,opt*/);
char *akb_get_proc_name(/*iPid,cpProcName*/);
char *akb_akb_ini(/*iReSet*/);
int akb_get_proc_id(/*cpProcName*/);
int akb_get_proc_name2(/*iPid,cpProcName*/);
int akb_get_proc_name3(/*iPid,cpDefalt,cppProcName*/);
int akb_get_apsys_id(/*cpAPSysName,parm*/);
int akb_gs_akb_stpl_func(/*namv,sep,order,argv,maxargv,pFunc,user_area*/);
int akb_gs_stpl_open(/*mfile,section*/);
int akb_gs_stpl_fetch(/*mfile,argv,maxargc,opt*/);

/* akbconnect.c */
int akb_get_host_addr(/*Hostname,ulpaddr_h*/);
int akb_get_port_no_proto(/*Service,Type*/);
int akb_get_port_no(/*Service*/);
int akb_connect_sub2(/*host_addr_h,port_no_h,iRetry,iSleep,iLinger*/);
int akb_connect2(/*cpHost,cpService,iRetry,iSleep,iLinger*/);
int akb_connect_sub(/*host_addr_h,port_no_h,iRetry,iLingerSleep*/);
int akb_connect(/*cpHost,cpService,iRetry,iLingerSleep*/);
int akb_get_connect_port();
UINT4 akb_get_connect_addr();
int akb_accept2(/*iSd0, time_out, iLinger*/);
int akb_accept(/*iSd0, time_out*/);
int akb_get_accept_sock_addr(/*psa,len*/);
int akb_get_accept_sock_parm(/*n,parm*/);
int akb_set_so_linger(/*iSd,onoff,time*/);

/* akbdump.c */
void akb_dump2(/*dump_file, flag, pHead, para, opt*/);
void akb_dump(/*dump_file, flag, pHead, para*/);

/*akb_cre_pack.c */
int akb_create_pk_data(/*applid,tpHead,tpSendMsgCom,cppPacket*/);
int akb_set_recv_msg(/*pPacket,tpRcMsg,cppFilev,cppToFree*/);

/* akb_make_socket.c */
int akba_make_socket_func(/*cpProcName,defaultService,iRetry,socketFunc*/);
int akba_make_socket(/*cpProcName,defaultService,iRetry*/);
int akb_make_socket(/*service,iRetry*/);
int akb_make_socket_sleep_func(/*service,iRetry,iSleep,socketFunc*/);
int akb_make_socket_sleep(/*service,iRetry,iSleep*/);
int akb_service_proto(/*Service,argv*/);
int akb_host_service_proto(/*String,argv*/);
int akb_get_make_sock_addr(/*psa,len*/);
int akb_get_make_sock_parm(/*n,parm*/);
int akb_host_service_proto_linger(/*String,argv*/);
int akb_service_proto_linger(/*Service,argv*/);
int akb_service_linger(/*Service,argv*/);

extern void akb_crt_err_packet();
extern void akb_crt_err_packet();
extern void akbLogPrint();
extern void akb_log_set_proc_name();
extern char *akb_log_get_proc_name();
extern char *akbMalloc();
extern char *akbRealloc();
extern void akbFree();
int akb_error_out(/*file,line,msg*/);
extern int akb_error_out_level();
extern int akb_print_out_level();
extern int akb_debug_out_level();
extern pSD_PACKET_TABLE akb_make_xpacket();
extern pSD_PACKET_TABLE akb_xto_fpacket();
extern pSD_PACKET_TABLE akbs_make_xpacket();
extern pSD_PACKET_TABLE akbs_xto_fpacket();
extern char *akb_akb_home();
extern char *akb_akb_home_add();
extern char *akb_get_proc_name();
extern char *akb_log_buf();
extern char *akb_log_set_file_name();
extern char *akb_log_file_path();
extern char *akb_log_time();
int akb_log_free();
extern int  akb_create_pk_data();
extern char *akb_akb_inf();
extern char *akb_prom_name();
extern char *akb_netm_name();
int akb_exchg_indicate(/*pPacket*/);

/* akblib.c */
int akb_get_inf_max_indirf(/*buf,len*/);
int akbreadline(/*buf ,size , fp*/);
char *akb_packet_new(/*iLen*/);
void akb_crt_err_packetB(/*pPacket,iErrorCode*/);
void akb_crt_err_packet(/*pPacket,iErrorCode*/);
int akb_is_packet(/*pH*/);
int akb_is_packetB(/*pHead*/);
int akb_sck_to_indir_f(/*applid,pHead,iSd,ppPacket*/);
int akb_mem_to_indir_f(/*applid,pHead,pMem,ppPacket*/);
int akb_to_indir_f(/*applid,pHead,iSd,pMem,ppPacket*/);
int akb_from_indir_f(/*pcInHead,pcInBody,ppPacket*/);
int akbi_from_indir_f(/*pNew*/);
pSD_PACKET_TABLE akb_make_xpacket(/*pNew*/);
int akbi_make_indir_f(/*pNew,applid*/);
pSD_PACKET_TABLE akb_xto_fpacket(/*pNew,cpProc*/);
int akb_is_right_head(/*pHd*/);
int akb_set_rb_pack_err_cd(/*iCh,pPacket,pRbCtl,iErrorCode*/);
int akb_set_rb_err_packet(/*iCh,pPacket,pRbCtl*/);
int akb_get_term_base(/*pid*/);
char *akbmalloc(/* size, file, line */);
int akb_get_head_from_a(/*PH,PHA*/);
int akb_set_head_to_a(/*PH,PHA*/);
pSD_PACKET_TABLE akb_packet_tbl_new(/*len*/);
int akb_packet_tbl_free(/*pNew*/);
int akb_exchg_indicate(/*pPacket*/);
int akb_is_set_priority(/*pNew*/);
int akb_set_rb_priority(/*pNew, pRbWCtl, pRbPriCtl*/);
int akb_set_akb_opt_or(/*pPacket,opt*/);

/* akblog.c */
int akb_log_free();
int akb_flog_out_level_pri_main(/*log_no,level,file,line,pri,fp,format,a1,a2,a3,a4,a5*/);
int akb_log_out_level_pri_main(/*log_no,level,file,line,pri,format,a1,a2,a3,a4,a5*/);
int akb_flog_out_level_main(/*log_no,level,file,line,fp,format,a1,a2,a3,a4,a5*/);
int akb_log_out_level_main(/*log_no,level,file,line,format,a1,a2,a3,a4,a5*/);
int akb_log_out_main(/*log_no,file,line,format,a1,a2,a3,a4,a5*/);
int akb_error_out_level_pri(/*level,file,line,pri,format,a1,a2,a3,a4,a5*/);
int akb_ferror_out_level(/*level,file,line,fp,format,a1,a2,a3,a4,a5*/);
int akb_error_out_level(/*level,file,line,format,a1,a2,a3,a4,a5*/);
int akb_error_out_m(/*file,line,format,a1,a2,a3,a4,a5*/);
int akb_error_out(/*file,line,msg*/);
int akb_fprint_out_level(/*level,file,line,fp,format,a1,a2,a3,a4,a5*/);
int akb_print_out_level(/*level,file,line,format,a1,a2,a3,a4,a5*/);
int akb_print_out(/*format,a1,a2,a3,a4,a5*/);
int akb_fdebug_out_level(/*level,file,line,fp,format,a1,a2,a3,a4,a5*/);
int akb_debug_out_level(/*level,file,line,format,a1,a2,a3,a4,a5*/);
int akb_debug_out_m(/*file,line,format,a1,a2,a3,a4,a5*/);
int akb_debug_input(/*file,line,msg,x,pi*/);
int akb_log_out(/*msg*/);
char *akb_log_buf(/*len*/);
int akb_log_buf_len(/*opt*/);
int akb_log_flg(/*i,f*/);
int akb_log_set_up_name(/*cpProcName*/);
int akb_log_level(/*i,level*/);
char *akb_log_set_dir();
int akb_log_set_parm2(/*argc,argv,nParm,iParm*/);
int akb_log_src_file(int argc,char *argv[]);
int akb_log_size(/*i,n,parm*/);
int akb_log_out_check(/*log_no,level,file,line*/);
int akb_trace_flg(/*i,f*/);
char *akb_trace_set_file_name(/*cpFile*/);
int akb_trace_check(/*ucTrace,iRW,sCmd*/);
int akb_trace(/*ucTrace,fname,iRW,cpPacket*/);
int akb_trace_log_out(/*iRW,cpPacket,logflg,file,line,format,a1,a2,a3,a4,a5*/);
int akb_trace_out(/*iRW,cpPacket*/);
int akbfixdmp(/*file,msg,dat,len*/);
int akb_log_clear(/*log_no,option*/);
int akb_log_setup_clear(/*log_no,option*/);
int akb_log_set_func_statistics_count(/*func*/);
int akb_log_statistics_count(/*i,len*/);
char *akb_log_file_path(/*log_no,option*/);
int akb_log_file_path_free_all();
char *akb_log_set_log_name(/*log_no,name*/);
tdtLOG_CTL *akb_log_get_ctl(/*log_no*/);
int akb_log_set_command_parm(/*opt_c,parm_string*/);
int akb_log_grp_priority(/*i,flg,pri*/);
int akb_log_priority(/*i,pri*/);
int akb_get_log_no(/*name*/);
char *akb_get_log_name(/*int log_no*/);
int akb_log_level_check(/*log_no,level*/);
int akb_prdbg_out_l5(/*level,file,line,fmt,a1,a2,a3,a4,a5*/);
int akb_errdbg_out_l5(/*level,file,line,fmt,a1,a2,a3,a4,a5*/);
int akb_anydbg_out_l5(/*level,i_LOG_NO_PRINT,file,line,fmt,a1,a2,a3,a4,a5*/);

extern void akb_fd_set();
extern void akb_fd_clr();
extern int  akb_fd_isset();
extern void akb_fd_zero();
int  akb_fd_setsize();
int  akb_set_fd_setsize(/*size*/);
extern pSD_PACKET_TABLE akb_packet_tbl_new();
extern int  akb_detach();
extern tdtVCH_HEAD *akb_vch_head_new(/*int iChNum, int opt*/);
extern tdtVCH *akb_vch_new(/*int iVchNum*/);
extern tdtRWQ_TIME_OUT *akb_rwque_time_out_new();
extern int  akb_rwqttimer(/*int iTimerId, char *cpTimerName, char *cpParm, struct timeval *tptime*/);
extern char *akb_str_error(/*int err_no*/);
extern char *akb_log_set_log_name(/*int log_no, char *name*/);
extern tdtLOG_CTL *akb_log_get_ctl(/*int log_no*/);
extern char *akb_get_log_name(/*int log_no*/);
extern tdtRW_QUE *akb_rwque_new(/*int iMaxQue, int iOpt*/);
extern char *akb_packet_new(/* int iLen*/);
extern char *akb_get_str_addr4(/*struct in_addr in*/);
extern char *akb_akb_help_dir(/* int iReSet*/);
extern tdtRW_QUE *akb_wqset_getp_q(/*iNotPA,WriteQue,iQTbl*/);

/* akbrwque.c */
int akb_cha_rb_regist_timer(pTC,iTimerId);
int akb_cha_rb_timer(iTimerId, cpTimerName, cpParm, tptime);
int akb_set_cha_rb_flg_timer(flg);
int akb_set_cha_rb_flg(flg);
int akb_get_cha_rb_flg();
tdtRW_QUE *akb_rwque_new(iQueMax,iOpt);
int akb_rwque_init(p,iOpt);
int akb_init_que(iQueMax,QueTbl);
int akb_free_que(iQueMax,QueTbl);
int  akb_read_que(iCh, pReadQue, pRbRCtl);
int  akb_read_que_w(iCh, pReadQue, pRbRCtl, pRbWCtl);
int akb_head_check(iCh,pReadQue);
int akb_head_check2(iCh,pReadQue,not_recovery);
int akb_write_que(pWriteQue);
int akb_wqset_err_reply(name,pSdNext,pRbWWCtl,pRbRCtl,iRetCode);
tdtRW_QUE *akb_wqset_getp_q(iNotPA,WriteQue,iQTbl);
int akb_wqset_make_xf(pWriteQue,pSdNext);
int akb_wqset_r2(iNotPA,WriteQue,iQueMax,pRbWCtl,pRbWWCtl,pRbRCtl);
int akb_wqset_r(WriteQue,pRbWCtl,pRbWWCtl,pRbRCtl);
int akb_wqset(WriteQue,pRbWCtl,pRbWWCtl);
int akb_wqset_par(WriteQue,pRbWCtl,pRbWWCtl,pRbRCtl);
int akb_qscheck_paopt(iQueMax,QueTbl,iOption);
int akb_qscheck_pa(iQueMax,QueTbl);
int akb_qscount_pa(iQueMax,QueTbl);
int akb_qscheck_opt(iQueMax,QueTbl,iOption);
int akb_qscheck(iQueMax,QueTbl);
int akb_qscount(iQueMax,QueTbl);
int akb_clear_rwque(pQueTbl,iSd);
int akb_set_write_que(pWriteQue,pSdNext);
int akb_set_que_out_time(pQ,tp);
int akb_set_rwque_pa(QueTbl,iQueMax,pQue);
int akb_need_reply(pRcv,pRbRCtl,pRbWCtl);
int akb_set_need_reply(pQ);
int akb_re_set_need_reply(pNew,WriteQue);
int akb_re_set_need_reply_pa(pNew,WriteQuePA);
int akb_set_cha_rb(iQueMax,pRbWCtl,RbWCtlPA,RbPriCtlPA);
int akb_wqset_rcha_rbi(ptt,pWriteQue,pRbWCtl,pRbRCtl,pRbWCtlPA,pRbPriCtlPA);
int akb_wqset_rcha_rb(iUChain,offset,WriteQue,
                    pRbWCtl,pRbRCtl,RbWCtlPA,RbPriCtlPA);
int akb_wqch_rb_set_r(WriteQue,pRbWCtl,pRbWWCtl,pRbRCtl,RbWCtlPA,RbPriCtlPA);
int akb_wqset_rext(iUChain,offset,WriteQue,pRbWCtl,pRbWWCtl,pRbRCtl,
                  RbWCtlPA,RbPriCtlPA);
int akb_wqch_rb_set(WriteQue,pRbWCtl,pRbWWCtl,RbWCtlPA,RbPriCtlPA);
int akb_ch_rb_packet_free(pRb);
int akb_ch_rb_free(RbWCtlPA,iMax,iTbl,iOpt);
int akb_wqch_rb_free(RbWCtlPA,RbPriCtlPA,iMax,iTbl,iOpt);
int akb_wqch_rb_saved_check(WriteQue,RbWCtlPA,RbPriCtlPA,iMax,iTbl);

/* akbselect.c */
int akb_set_nwselect(/*i*/);
int akb_get_nwselect();
int akb_set_wqsuspend(/*i*/);
int akb_get_wqsuspend();
int akb_set_rb_wused(/*i*/);
int akb_get_rb_wused(/*i*/);
int akb_nwselect_increment();
int akb_nwselect_wait_time(/*ptval*/);
int akb_get_select_wait_time(/*iWaitTime,pRbRCtl,pRbWCtl,ptval*/);

/* akbsub.c */
int akb_connect_prom_host(/*iRetry,iSleep,cpHost*/);
int akb_connect_prom(/*iRetry,iSleep*/);

/* akbtimeout.c */
int akb_set_com_time_out(/*proc*/);
int akb_set_sys_com_time_out(/*proc,opt*/);
int akb_set_time_out(int num);
int akb_get_time_out();
int akb_set_time_out_set(/*timeset,n*/);
int akb_get_time_outi(int i);
int akb_get_time_out_set(/*timeset,n*/);
void akb_sock_time_out();
void sock_time();
void akb_broken_pipe();
int akb_set_signal_msg(/*fmt,a1,a2,a3,a4,a5*/);

#endif	/* _AKBPROT_H */
