//

define type struct z
	int a
	,char(5) b
	,dec(10,2) c
;

var y as z = 1,'ABCDE',123.45;
def z w[2] = [2,'X',23.5,10,'Y',99.9];
def aa[2] = [10,20];

proc main;

//	z = 1;
	zz = z;
	print z;
	print zz;
	zz n = 1;
	print n *n;
//	y = 1;
	yy = y;
	yy.b = 'XYZ';
	print y *y;
	print yy *yy;
	yy = *y;
	yy.b = '12345678';
	print y *y;
	print yy *yy;
//	yy = 1;
//	print y *y;
	print f('XYZ');
	print xp *xp;
	print f('KJHG');
	print f('UP');

	print w *w;
	ww = w;
	ww[1].b = 'ZZ';
	print *ww *w;

	xx = *w;
	xx[1].b = 'AA';
	print *xx *w;

	print aa *aa;
	bb = aa;
	bb[1] = 100;
	print *bb *aa;
	cc = *aa;
	cc[1] = 200;
	print *cc *aa;

	return ERROR;
end proc;

func f(w);
	var x as z = 10,w,-21.5;
	print x *x;
	private xp = x;
	return x;
end func;
