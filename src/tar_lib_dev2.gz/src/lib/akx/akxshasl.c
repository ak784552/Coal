#ifndef HASL2
static    char    sccsid[]="%Z% %M% %I% %E% %U%";
#endif
/************************************************/
/*												*/
/*	akxshasl.c									*/
/*												*/
/*		  coded by A.Kobayashi 2003/06/13		*/
/*												*/
/*	error code : -185150101 �` -185159999		*/
/************************************************/
#ifndef HASL2
#include "akxcommon.h"
#endif

#define DEBUGP(x)
#define DEBUGPX(x)

static int  max_count=0;

static int _haslf();
static int _haslu();
int akxshaslr(/*hp,key*/);

#define _SET_UP(opt,maxreg,next) \
	iUSHORT = opt & AKX_HASX_OPT_USE_USHORT;\
	if (iUSHORT) {\
		usen = (ushort *)next;\
		uscol = usen + maxreg;\
		usul = uscol + AKX_HASX_COL_SIZE;\
		usfn = usul  + AKX_HASX_UL_SIZE;\
		*uscol = 0;\
		i = usen[ih-1];\
	}\
	else {\
		en = next;\
		col = en + maxreg;\
		ul = col + AKX_HASX_COL_SIZE;\
		fn = ul  + AKX_HASX_UL_SIZE;\
		*col = 0;\
		i = en[ih-1];\
	}

/* 01 -185150101 */
/************************************/
/*	01								*/
/************************************/
int akxshasli(hp)
HASHB *hp;
{
	int i,j,mx,m1,*np,*col,*fn,*ufl,len;
	int  opt,iUSE_ULIST,iNDEL;
	ushort *usnp,*uscol,*usfn,*usufl;
	char c,*s;

	if (!hp) return -1;
	i = 0;
	if ((mx=hp->ha_maxreg)<=0) i-=4;
	if ((m1=hp->ha_prereg)<=0) i-=8;
	if (m1>=mx) i-=16;
	if (!hp->ha_reg) i-=32;
	if (!(np=hp->ha_next)) i -=64;

	if (i>=0) {
		opt = hp->ha_id[1] & 0xff;
		memset(hp->ha_reg,0,mx*sizeof(tdtHaslCell));
		hp->ha_aux = m1;
DEBUGP(printf("hasli: aux=%d\n",hp->ha_aux);)
		iUSE_ULIST = !(opt & AKX_HASX_OPT_NOT_ULIST);
		iNDEL = opt & AKX_HASX_OPT_NOT_DELETE;
		len = mx + AKX_HASX_COL_SIZE + AKX_HASX_UL_SIZE;
		if (opt & AKX_HASX_OPT_USE_USHORT) {
			usnp = (ushort *)np;
			memset(usnp,0,len*sizeof(short));
			uscol = usnp + mx;
			usfn = uscol + AKX_HASX_COL_SIZE + AKX_HASX_UL_SIZE;
			s = (char *)(uscol+3);
			s[0] = 'S';
			if (iNDEL) {
				*usfn = 1;
				s[1] = 'N';
			}
			else {
				for (j=0;j<mx;j++) usfn[j] = j + 1;
				usfn[mx] = 0;
				if (iUSE_ULIST) {
					usufl = usfn + mx + 1;
					memset(usufl,0,(mx+1)*sizeof(short));	/* 2026.4.30 mx-->mx+1 */
				}
				s[1] = 'D';
			}
		}
		else {
			memset(np,0,len*sizeof(int));
			col = np + mx;
			fn = col + AKX_HASX_COL_SIZE + AKX_HASX_UL_SIZE;
			s = (char *)(col+3);
			s[0] = 'I';
			if (iNDEL) {
				*fn = 1;
				s[1] = 'N';
			}
			else {
				for (j=0;j<mx;j++) fn[j]=j+1;
				fn[mx] = 0;
				if (iUSE_ULIST) {
					ufl = fn + mx + 1;
					memset(ufl,0,(mx+1)*sizeof(int));	/* 2026.4.30 mx-->mx+1 */
				}
				s[1] = 'D';
			}
		}
/*
printf("akxshasli: s=%c %c opt=%02x mx=%d\n",s[0],s[1],opt & 0xff,mx);
*/
	}
	return i;
}

/************************************/
/*	02								*/
/************************************/
static int _haslf(hp,key)
HASHB *hp;
#ifdef HASL2
ulong key[];
#else
long key;
#endif
{
	int i;
	ulong hey[2];

	if (!hp) return -1;
#ifdef HASL2
	if (!key) return -1224;
	if (!(key[0] & 0xff000000)) hey[0] = X_HTONL(key[0]);
	else hey[0] = key[0];
	if (!(key[1] & 0xff000000)) hey[1] = X_HTONL(key[1]);
	else hey[1] = key[1];
	i=(hey[0]+hey[1])%hp->ha_prereg+1;
DEBUGP(printf("_haslf: hey=%08x %08x ih=%d\n",hey[0],hey[1],i);)
#else
	if (!(key & 0xff000000)) key = X_HTONL(key);
	i=(ulong)key%hp->ha_prereg+1;
DEBUGP(printf("_haslf: key=%08x ih=%d\n",key,i);)
#endif
	return i;
}

/************************************/
/*	03								*/
/************************************/
static int _haslf_ih(hp,key)
HASHB *hp;
#ifdef HASL2
ulong key[];
#else
long key;
#endif
{
	int ih;

	if (!hp) return -1;
#ifdef HASL2
	if (!key) return -1224;
	if ((ih=hp->ha_hix)<=0) {
		ih=_haslf(hp,key);
#else
	if ((ih=hp->ha_hix)<=0) {
		ih=_haslf(hp,key);
#endif
	}
	else if (ih > hp->ha_prereg) return -1225;
	return ih;
}

/************************************/
/*	04								*/
/************************************/
static int _cmpkey(ce,key)
tdtHaslCell *ce;
#ifdef HASL2
ulong key[];
#else
long key;
#endif
{
#ifdef HASL2
	if ((ce->hc_akey[0]==key[0]) && (ce->hc_akey[1]==key[1]))
#else
	if (ce->hc_hkey==key)
#endif
		return 0;
	else
		return 1;
}
/* 05 */
/********1*********2*********3*********4*********5*******/
/* ���� : hp	: HASHB									*/
/*				  hp->ha_key : argv[]					*/
/*					argv[1]:data�ւ̃|�C���^��ݒ肷��B*/
/*							���̒l���ۑ������B		*/
/*		  key	: �L�[�l								*/
/* �ԋp : >0 :key�o�^�ʒu								*/
/*		  =0 :�o�^�G���A�Ȃ�							*/
/*		  <0 :�G���[									*/
/********************************************************/
int akxshasls(hp,key)
HASHB *hp;
#ifdef HASL2
ulong key[];
#else
long key;
#endif
{
	int ih,iu0,maxreg,*en,*col,*ul,*fn,*ufl;
	int i,k,i_start,*data,opt,iNDEL,rc,iUSHORT;
	ushort usu0,*usen,*uscol,*usul,*usfn,*usufl;
	tdtHaslCell *cell,*ce;
	char c,**argv;

	if ((ih=_haslf_ih(hp,key)) <= 0) return ih;

	cell=(tdtHaslCell *)hp->ha_reg-1;
	if (argv=(char **)hp->ha_key) data=(int *)argv[1];
	else data=NULL;
	maxreg = hp->ha_maxreg;
	opt = hp->ha_id[1];
	_SET_UP(opt,maxreg,hp->ha_next)
/*
printf("hasls: key=%08x ih=%d i=%d\n",key,ih,i);
*/
	i_start = i;
	if (i) {
  L10:
		ce=&cell[i];
		if (!_cmpkey(ce,key)) {
			ce->hc_datp=data;
			akxs_set_col_max(iUSHORT,col,uscol);
			return i;
		}
/*
printf("hasls: next[%d]=%d\n",i,ce->hc_next);
*/
		if ((k=ce->hc_next) > 0) {
			i = k;
			if (iUSHORT) (*uscol)++;
			else (*col)++;
			goto L10;
		}
	}
	else i = ih;
	akxs_set_col_max(iUSHORT,col,uscol);

#if 1	/* 2026.1.19 */
	if (iUSHORT) {
/*
printf("hasls:1 usfn[0]=%d\n",usfn[0]);
*/
		if (!(k = usfn[0])) return 0;
		usufl = usfn + maxreg + 1;
		if ((rc=akxs_set_ul_ufl_short(opt,k,maxreg,usul,usfn,usufl)) < 0) return rc;
/*
printf("hasls:2 usfn[0]=%d\n",usfn[0]);
*/
	}
	else {
/*
printf("hasls:1 fn[0]=%d\n",fn[0]);
*/
		if (!(k = fn[0])) return 0;
		ufl = fn + maxreg + 1;
		if ((rc=akxs_set_ul_ufl(opt,k,maxreg,ul,fn,ufl)) < 0) return rc;
/*
printf("hasls:2 fn[0]=%d\n",fn[0]);
*/
	}
/*
printf("hasls: i=%d k=%d i_start=%d\n",i,k,i_start);
*/
	if (i_start) {
		ce=&cell[i];
		ce->hc_next = k;
	}
	else {
		if (iUSHORT) usen[i-1] = k;
		else en[i-1] = k;
	}
	ce=&cell[k];
	ce->hc_next = 0;
	ce->hc_flag = 1;
#else
	opt = hp->ha_id[1];
	iNDEL = opt & AKX_HASX_OPT_NOT_DELETE;
	if (iNDEL) {
		if (k >= maxreg) fn[0] = 0;
		else fn[0] = k + 1;
	}
	else fn[0] = fn[k];
	if (i_start) {
		ce=&cell[i];
		ce->hc_next = k;
	}
	else en[i-1] = k;
	ce=&cell[k];
	ce->hc_next = 0;
	ce->hc_flag = 1;
#if 1	/* 2025.12.31 */
	ul[1]++;
	if (!(opt & AKX_HASX_OPT_NOT_ULIST)) {
		iu0 = ul[0];
		ul[0] = k;
		fn[k] = iu0;
#if 1	/* 2026.1.18 */
		ufl = fn + maxreg + 1;
		ufl[iu0] = k;
		ufl[k] = 0;
#endif
/*
printf("akxshasls: k=%d iu0=%d ul[0]=%d ul[1]=%d\n",k,iu0,ul[0],ul[1]);
*/
	}
#endif
#endif
#ifdef HASL2
	ce->hc_akey[0]=key[0];
	ce->hc_akey[1]=key[1];
#else
	ce->hc_hkey=key;
#endif
	ce->hc_datp=data;
	return k;
}

/* 06 */
/********1*********2*********3*********4*********5*******/
/* ���� : hp	: HASHB									*/
/*				  hp->ha_key : argv[]					*/
/*					argv[1]:�ۑ����ꂽ�l��Ԃ��B		*/
/*		  key	: �L�[�l								*/
/* �ԋp : >0 :key�o�^�ʒu								*/
/*		  =0 :�o�^�Ȃ�									*/
/*		  <0 :�G���[									*/
/********************************************************/
int akxshaslr(hp,key)
HASHB *hp;
#ifdef HASL2
ulong key[];
#else
long key;
#endif
{
	int i,ih,iUSHORT,*en,*col,*ul,*fn,*ufl;
	ushort usu0,*usen,*uscol,*usul,*usfn,*usufl;
	tdtHaslCell *cell,*ce;
	char **argv;

	if ((ih=_haslf_ih(hp,key)) <= 0) return ih;

	cell=(tdtHaslCell *)hp->ha_reg-1;
	_SET_UP(hp->ha_id[1],hp->ha_maxreg,hp->ha_next)
	if (i) {
  L10:
		ce=&cell[i];
		if (!_cmpkey(ce,key)) {
			if (argv=(char **)hp->ha_key) {
				argv[1]=(char *)ce->hc_datp;
/*
printf("akxshaslr: argv=%08x argv[1]=%08x\n",argv,argv[1]);
*/
			}
			akxs_set_col_max(iUSHORT,col,uscol);
			return i;
		}
		else if ((i=ce->hc_next)>0) {
			if (iUSHORT) (*uscol)++;
			else (*col)++;
			goto L10;
		}
	}
	akxs_set_col_max(iUSHORT,col,uscol);
	return 0;
}

/* 07 */
/********1*********2*********3*********4*********5*******/
/* ���� : hp	: HASHB									*/
/*				  hp->ha_key : argv[]					*/
/*					argv[1]:�ۑ����ꂽ�l��Ԃ��B		*/
/*		  key	: �L�[�l								*/
/* �ԋp : >0 :key�o�^�ʒu								*/
/*		  =0 :�o�^�Ȃ�									*/
/*		  <0 :�G���[									*/
/********************************************************/
int akxshasld(hp,key)
HASHB *hp;
#ifdef HASL2
ulong key[];
#else
long key;
#endif
{
	int i,ih,opt,iUSHORT,iUSE_ULIST,maxreg,isp;
	int *en,*col,*ul,*fn,*ufl;
	ushort usu0,*usen,*uscol,*usul,*usfn,*usufl;
	tdtHaslCell *cell,*ce,*cek;
	char c,**argv;

	if (hp->ha_id[1] & AKX_HASX_OPT_NOT_DELETE) return -185150701;

	if ((ih=_haslf_ih(hp,key)) <= 0) return ih;

	cell=(tdtHaslCell *)hp->ha_reg-1;
	maxreg = hp->ha_maxreg;
	opt = hp->ha_id[1];
	_SET_UP(opt,maxreg,hp->ha_next)
	cek = NULL;
	if (!i) return 0;

  L10:
/*
printf("akxshasld: i=%d\n",i);
*/
	ce = &cell[i];
	if (_cmpkey(ce,key)) {
		cek = ce;
/*
printf("akxshasld: ce->hc_next=%d\n",ce->hc_next);
*/
		if ((i=ce->hc_next)>0) {
			goto L10;
		}
		return 0;
	}
	if (cek) cek->hc_next = ce->hc_next;
	else {
		if (iUSHORT) usen[ih-1] = ce->hc_next;
		else en[ih-1] = ce->hc_next;
	}
#if 1	/* 2025.12.31 */
	iUSE_ULIST = !(opt & AKX_HASX_OPT_NOT_ULIST);
/*
printf("akxshasld: iUSE_ULIST=%d\n",iUSE_ULIST);
*/
	if (iUSHORT) {
		if (iUSE_ULIST) {
			usufl = usfn + maxreg + 1;
			akxs_del_ul_short(i,usul,usfn,usufl);
		}
		usul[1]--;
		isp = usfn[0];
		usfn[i] = isp;
		usfn[0] = i;
	}
	else {
		if (iUSE_ULIST) {
			ufl = fn + maxreg + 1;
/*
printf("akxshasld: ul[0]=%d ul[1]=%d ul[2]=%d\n",ul[0],ul[1],ul[2]);
*/
			akxs_del_ul(i,ul,fn,ufl);
/*
printf("akxshasld: ul[0]=%d ul[1]=%d ul[2]=%d\n",ul[0],ul[1],ul[2]);
*/
		}
#if 1	/* 2025.12.29 */
		ul[1]--;
#endif
		isp = fn[0];
		fn[i] = isp;
		fn[0] = i;
/*
printf("akxshasld: i=%d fn[i]=%d fn[0]=%d\n",i,fn[i],fn[0]);
*/
	}
#endif
	ce->hc_next = 0;
	ce->hc_flag = 0;
	if (argv=(char **)hp->ha_key) argv[1]=(char *)ce->hc_datp;
	return i;
}

/********1*********2*********3*********4*********5*******/
/* ���� : IN  : hp		: HASHB							*/
/*						  hp->ha_hix : ���ׂ�L�[�ʒu	*/
/*						  hp->ha_key : argv[]			*/
/*#ifdef HASL2											*/
/*							argv[0]:�L�[�l��Ԃ��|�C���^*/
/*									long*2�̃G���A���K�v*/
/*#endif												*/
/*			  : keyp	: �L�[�l��Ԃ��|�C���^�B		*/
/*		  OUT : 		  hp->ha_key : argv[]			*/
/*							argv[0]:�L�[�l��Ԃ��B		*/
/*							argv[1]:�ۑ����ꂽ�l��Ԃ��B*/
/* �ԋp : >0 :key�o�^�ʒu								*/
/*		  =0 :�o�^�Ȃ�									*/
/*		  <0 :�G���[									*/
/********************************************************/
#ifdef HASL2
int akxshasl2k(hp,key)
HASHB *hp;
ulong key[];
#else
int akxshaslk(hp,keyp)
HASHB *hp;
long *keyp;
#endif
{
	int i;
	tdtHaslCell *ce;
	char **argv;
	long *p;

	if (!hp) return -1;
	i=hp->ha_hix;
	if (i<=0 || i>hp->ha_maxreg) return -1225;
	ce=&((tdtHaslCell *)hp->ha_reg)[i]-1;
	if (ce->hc_flag) {
#ifdef HASL2
		if (key) {
			key[0]=ce->hc_akey[0];
			key[1]=ce->hc_akey[1];
		}
#else
		if (keyp) *keyp=ce->hc_hkey;
#endif
		if (argv=(char **)hp->ha_key) {
#ifdef HASL2
			if (p=(long *)argv[0]) {
				p[0]=ce->hc_akey[0];
				p[1]=ce->hc_akey[1];
			}
#else
			argv[0]=(char *)ce->hc_hkey;
#endif
			argv[1]=(char *)ce->hc_datp;
		}
		return i;
	}
	return 0;
}

/********1*********2*********3*********4*********5*******/
/* ���� : hp	: HASHB									*/
/*				  hp->ha_hix : ���ׂ�L�[�ʒu			*/
/*				  hp->ha_key : argv[]					*/
/*					argv[0]:�L�[�l�ւ̃|�C���^��Ԃ��B	*/
/*					argv[1]:�ۑ����ꂽ�l��Ԃ��B		*/
/*		  key	: �L�[�l��Ԃ��B						*/
/* �ԋp : >0 :key�o�^�ʒu								*/
/*		  =0 :�o�^�Ȃ�									*/
/*		  <0 :�G���[									*/
/********************************************************/
int akxshaslp(hp)
HASHB *hp;
{
	int i,rc;
	tdtHaslCell *ce;
	char **argv;

	if (!hp) return -1;
	rc=0;
	i=hp->ha_hix;
	if (i<=0 || i>hp->ha_maxreg) return -1225;
	ce=&((tdtHaslCell *)hp->ha_reg)[i]-1;
	if (ce->hc_flag) {
		if (argv=(char **)hp->ha_key) {
#ifdef HASL2
			argv[0]=(char *)ce->hc_akey;
#else
			argv[0]=(char *)&ce->hc_hkey;
#endif
			argv[1]=(char *)ce->hc_datp;
		}
		rc=i;
	}
	hp->ha_hix = 0;
	return rc;
}

/********1*********2*********3*********4*********5*******/
/* ���� : hp	: HASHB									*/
/* �ԋp : >=0 :�o�^��									*/
/*		   <0 :�G���[									*/
/********************************************************/
static int _haslu(hp,iRESET_TOP)
HASHB *hp;
int iRESET_TOP;
{
	int x,i,max,n,*ul,opt,iUSE_ULIST,*fn,*ufl;
	ushort *usul,*usfn,*usufl;
	char *key;

	if (!hp) return -1;
	x = max = hp->ha_maxreg;
#if 1	/* 2025.12.31 */
	opt = hp->ha_id[1];
	iUSE_ULIST = !(opt & AKX_HASX_OPT_NOT_ULIST);
	if (opt & AKX_HASX_OPT_USE_USHORT) {
		usul = (ushort *)hp->ha_next + max + AKX_HASX_COL_SIZE;
		n = usul[1];
		if (iUSE_ULIST && iRESET_TOP) {
#if 1	/* 2026.4.30 */
			usfn  = usul  + AKX_HASX_UL_SIZE;
			usufl = usfn  + max + 1;
			usul[2] = usufl[0];
#else
			usul[2] = usul[0];
#endif
		}

	}
	else {
		ul = hp->ha_next + max + AKX_HASX_COL_SIZE;
		n = ul[1];
		if (iUSE_ULIST && iRESET_TOP) {
#if 1	/* 2026.4.30 */
			fn  = ul  + AKX_HASX_UL_SIZE;
			ufl = fn  + max + 1;
			ul[2] = ufl[0];
#else
			ul[2] = ul[0];
#endif
		}
/*
printf("akxshaslu: iRESET_TOP=%d ul[0]=%d ul[1]=%d ul[2]=%d\n",iRESET_TOP,ul[0],ul[1],ul[2]);
*/
	}
	if (iUSE_ULIST) {
		x = 0;
		if (max < n*2) x = -max;
	}
	/* x=max �̂Ƃ��́A_hashn()�͎g���Ȃ� */
	/* x<=0  �̂Ƃ��́A_hashn()���g���� */
	/* x=-max�̂Ƃ��́A'P'or'K'�ɂ��o�^�ς݃L�[�擾�́A_hashn()���g��Ȃ��������� */
	hp->ha_aux = x;
#else
	key = hp->ha_key;
	x = hp->ha_hix;
	hp->ha_key = NULL;
	n = 0;
	for (i=1;i<=max;i++) {
		hp->ha_hix = i;
#ifdef HASL2
		if (akxshasl2k(hp,NULL) > 0) n++;
#else
		if (akxshaslk(hp,NULL) > 0) n++;
#endif
	}
	hp->ha_hix = x;
	hp->ha_key = key;
#endif
	return n;
}

/************************************/
/*									*/
/************************************/
int akxshaslu(hp)
HASHB *hp;
{
	return _haslu(hp,0);
}

/************************************/
/*									*/
/************************************/
int akxshaslt(hp)
HASHB *hp;
{
	return _haslu(hp,1);
}

/********1*********2*********3*********4*********5*******/
/* ���� : hp	: HASHB									*/
/*				  hp->ha_hix= 0: ���O��'S','R','D'		*/
/*								 ���s���̏Փː�			*/
/*				  hp->ha_hix<>0: �O����s������̗ݐ�	*/
/*								 �Փː��B���A�O�ɗݐς�	*/
/*								 0�ɂ���				*/
/* �ԋp : >=0 :�Փː�									*/
/*		   <0 :�G���[									*/
/********************************************************/
int akxshaslc(hp)
HASHB *hp;
{
	int x,i,max,n,*col;
	ushort *uscol;
	char *key;

	if (!hp) return -1;
	x = hp->ha_hix;
	max = hp->ha_maxreg;
	if (hp->ha_id[1] & AKX_HASX_OPT_USE_USHORT) {
		uscol = (ushort *)hp->ha_next + max;
		if (x) {
			uscol++;
			n = *uscol;
			*uscol = 0;
		}
		else n = *uscol;
	}
	else {
		col = hp->ha_next + max;
		if (x) {
			col++;
			n = *col;
			*col = 0;
		}
		else n = *col;
	}
	return n;
}

/************************************/
/*									*/
/************************************/
int akxshasln(hp)
HASHB *hp;
{
	int max,i,*ul,*fn,opt,*ufl;
	ushort *usen,*usul,*usfn,*usufl;

	max = hp->ha_maxreg;
	opt = hp->ha_id[1];
	if ((opt & AKX_HASX_OPT_NOT_DELETE) || (opt & AKX_HASX_OPT_NOT_ULIST)) i = 0;
	else {
		if (opt & AKX_HASX_OPT_USE_USHORT) {
			usen = (ushort *)hp->ha_next;
			usul = usen + max + AKX_HASX_COL_SIZE;
			usfn = usul + AKX_HASX_UL_SIZE;
			i = usul[2];
#if 1	/* 2026.4.30 */
			usufl = usfn  + max + 1;
			usul[2] = usufl[i];
#else
			usul[2] = usfn[i];
#endif
		}
		else {
			ul = hp->ha_next + max + AKX_HASX_COL_SIZE;
			fn = ul + AKX_HASX_UL_SIZE;
			i = ul[2];
#if 1	/* 2026.4.30 */
			ufl = fn  + max + 1;
			ul[2] = ufl[i];
#else
			ul[2] = fn[i];
#endif
		}
	}
	return i;
}

/************************************/
/*									*/
/************************************/
HASHB *akxs_hasl_new2(sKeyLen,lMaxReg,lPreReg,iOpt)
short sKeyLen;
int  lMaxReg,lPreReg;
int   iOpt;
{
	HASHB *tph;
	int l,pre,opt,len,size;
	char c;
/*
printf("akxs_hasl_new2: sKeyLen=%d lMaxReg=%d lPreReg=%d iOpt=%08x\n",sKeyLen,lMaxReg,lPreReg,iOpt);
*/
#if 0
	if (/*sKeyLen<=0 || */lMaxReg<2 || lPreReg<0 ||
	    (lPreReg>0 && lMaxReg<=lPreReg))  {
#else
	if (lMaxReg<2 || lPreReg<0) {
#endif
		errno = -1201;
		return NULL;
	}
	if (lPreReg > 0) {
		if (lMaxReg<=lPreReg) {
			errno = -1202;
			return NULL;
		}
	}
	if (!(l=lPreReg)) {
		pre = 0;
		if ((l=akxs_hasx_pre_reg(lMaxReg,pre)) < 1) {
			errno = -1203;
			return NULL;
		}
DEBUGP(printf("HaslNew mso=%d\n",l);)
	}
	if (!(tph=(HASHB *)Malloc(sizeof(HASHB)))) {
		errno = -1204;
		return NULL;
	}
	memset(tph,0,sizeof(HASHB));
/*	tph->ha_id[0] = 'H';	*/
#ifdef HASL2
	tph->ha_id[0] = '2';
#else
	tph->ha_id[0] = 'L';
#endif
	c = iOpt & ~AKX_HASX_OPT_USE_USHORT;
	if (iOpt & AKX_HASX_OPT_NOT_DELETE) c |= AKX_HASX_OPT_NOT_ULIST;
	if (lMaxReg <= USHRT_MAX) {
		c |= AKX_HASX_OPT_USE_USHORT;
		size = sizeof(short);
	}
	else size = sizeof(int);
	tph->ha_id[1] = c;
	tph->ha_keylen = sKeyLen;
	tph->ha_maxreg = lMaxReg;
	tph->ha_prereg = l;
	tph->ha_hix    = 0;
	if (!(tph->ha_reg=Malloc(lMaxReg*sizeof(tdtHaslCell)))) {
		akxs_hasl_free(tph);
		errno = -1205;
		return NULL;
	}
	len = lMaxReg + AKX_HASX_COL_SIZE + AKX_HASX_UL_SIZE + 2;	/* 2026.4.30 1-->2 */
	if (!(c & AKX_HASX_OPT_NOT_DELETE)) len += lMaxReg;
	if (!(c & AKX_HASX_OPT_NOT_ULIST)) len += lMaxReg;
	if (!(tph->ha_next=(int *)Malloc(len*size))) {
		akxs_hasl_free(tph);
		errno = -1206;
		return NULL;
	}
	if (errno=akxshasli(tph)) {
		akxs_hasl_free(tph);
		return NULL;
	}
	return tph;
}

/************************************/
/*									*/
/************************************/
int akxs_hasl_free(tph)
HASHB *tph;
{
	if (tph) {
		if (tph->ha_reg) Free(tph->ha_reg);
		Free(tph);
	}
	return 0;
}

/************************************/
/*									*/
/************************************/
int akxshasl(func,hp)
char func;
HASHB *hp;
{
	char cmd,**argv;
	int i,iRESET_TOP;
#ifdef HASL2
	ulong key[2];
#else
	long key;
#endif

	if (!hp) return -1;
	if (!(argv=(char **)hp->ha_key))  return -1224;

	switch (cmd=akxcupper(func)) {
	  case 'R':
	  case 'S':
	  case 'D':
	  case 'F':
#ifdef HASL2
			key[0]=((long *)argv[0])[0];
			key[1]=((long *)argv[0])[1];
#else
			memcpy(&key,&argv[0],sizeof(long));
#endif
			break;
	  default:
#ifdef HASL2
			key[0] = -1;
			key[1] = -1;
#else
	  		key = -1;
#endif
	}
	iRESET_TOP = 0;
	switch (cmd) {
	  case 'R':
			i=akxshaslr(hp,key);
			break;
	  case 'S':
			i=akxshasls(hp,key);
			break;
	  case 'D':
			i=akxshasld(hp,key);
			break;
	  case 'I':
			i=akxshasli(hp);
			break;
	  case 'K':
#ifdef HASL2
			i=akxshasl2k(hp,key);
		/*	((long *)argv[0])[0]=key[0];
			((long *)argv[0])[1]=key[1];	*/
#else
			i=akxshaslk(hp,&key);
		/*	argv[0]=(char *)key;	*/
#endif
			break;
	  case 'P':
			i=akxshaslp(hp);
			break;
	  case 'T':
	  		iRESET_TOP = 1;
	  case 'U':
			i=_haslu(hp,iRESET_TOP);
			break;
	  case 'C':
			i=akxshaslc(hp);
			break;
	  case 'N':
			i=akxshasln(hp);
			break;
	  case 'F':
			i=_haslf(hp,key);
			break;
	  default:
			i=-2;
	}
	return i;
}

/************************************/
/*									*/
/************************************/
HASHB *akxs_hasl_new(sKeyLen,lMaxReg,lPreReg)
short sKeyLen;
int  lMaxReg,lPreReg;
{
	return akxs_hasl_new2(sKeyLen,lMaxReg,lPreReg,0);
}

/************************************/
/*									*/
/************************************/
static int _xhasl_chk(tpxhashb,cCmd,lH,ippDat)
tdtRbChain *tpxhashb;
char cCmd;
long lH;
char *ippDat[];
{
	int ret;
	tdtRbChain *tpcurr;
	int i,offset,next,ix,max;
	char *argv[2];
	HASHB *tph;

	ret = 0;
	i = lH;
	offset = 0;
	tpcurr = tpxhashb;
	tph = (HASHB *)tpcurr->rbc_buf;
	max = tph->ha_maxreg;
	while (tpcurr) {
		next = offset + max;
		if (next >= i) {
			if (tph=(HASHB *)tpcurr->rbc_buf) {
				tph->ha_hix = ix = i - offset;
				tph->ha_key = (char *)argv;
				ret = akxshaslp(tph);
/*
printf("_xhasl_chk: i=%d ix=%d ret=%d\n",i,ix,ret);
*/
				if (ret > 0) {
					if (ippDat) {
#if 1	/* 2022.9.21 */
						ippDat[0] = argv[0];
						ippDat[1] = argv[1];
#else
						*ippDat = argv[1];
#endif
					}
					return i;
				}
			}
			break;
		}
		tpcurr = tpcurr->rbc_next;
		offset = next;
	}
	return ret;
}

/************************************/
/*									*/
/************************************/
static int _xhasl_max(tpxhashb)
tdtRbChain *tpxhashb;
{
	tdtRbChain *tpcurr;
	int max,count;
	HASHB *tph;

	count = 0;
	tpcurr = tpxhashb;
	tph = (HASHB *)tpcurr->rbc_buf;
	max = tph->ha_maxreg;
	while (tpcurr) {
		count += max;
		tpcurr = tpcurr->rbc_next;
	}
/*
printf("_xhasl_max: count=%d\n",count);
*/
	return count;
}

/********1*********2*********3*********4*********5*******/
/* ���� : tpxhashb: tdtRbChain							*/
/*					key= NULL: ���O��'S','R','D'���s����*/
/*							   �Փː�					*/
/*					key<>NULL: �O����s������̗ݐ�		*/
/*							   �Փː��B���A�O�ɗݐς�	*/
/*							   0�ɂ���					*/
/* �ԋp : >=0 :�Փː�									*/
/*		   <0 :�G���[									*/
/********************************************************/
static int _xhasl_col(tpxhashb,key)
tdtRbChain *tpxhashb;
#ifdef HASL2
ulong key[];
#else
long key;
#endif
{
	tdtRbChain *tpcurr;
	int ret,count,x;
	HASHB *tph;

	x = count = 0;
	tpcurr = tpxhashb;
	if (key) x = 1;
	while (tpcurr) {
		if (tph = (HASHB *)tpcurr->rbc_buf) {
			tph->ha_hix = x;
			ret = akxshaslc(tph);
			if (ret > 0) count += ret;
		}
		tpcurr = tpcurr->rbc_next;
	}
/*
printf("_xhasl_col: count=%d\n",count);
*/
	return count;
}

/********1*********2*********3*********4*********5*******/
/*	cCmnd = 'S'											*/
/*			ippDat[0]:data�ւ̃|�C���^��ݒ肷��B		*/
/*					  data�������l�̂Ƃ��́A�l��ݒ肵�Ă��ǂ� */
/*	cCmnd = 'R'											*/
/*			ippDat[0]:'S'�Őݒ肵���l���Ԃ�B			*/
/*	cCmnd = 'D'											*/
/*			ippDat[0]:'S'�Őݒ肵���l���Ԃ�B			*/
/*	cCmnd = 'K','P'										*/
/*			ippDat[0]:key�ւ̃|�C���^���Ԃ�B			*/
/*			ippDat[1]:'S'�Őݒ肵���l���Ԃ�B			*/
/********************************************************/
int akxs_xhasl(tpxhashb,cCmnd,key,ippDat)
tdtRbChain *tpxhashb;
char cCmnd;
#ifdef HASL2
ulong key[];
#else
long key;
#endif
char *ippDat[];
{
	tdtRbChain *tpcurr,*tpnext;
	int l,i,offset;
	HASHB *tph;
	char cCmd,c,*argv[2],*dummy;
/*
printf("akxs_xhasl: tpxhashb=%08x cCmnd=%c key=%d ippDat=%08x\n",
tpxhashb,cCmnd,key,ippDat);
*/
	if (!tpxhashb) return -1;
	dummy = NULL;
	if (!ippDat) ippDat = &dummy;
	cCmd = akxcupper(cCmnd);
	if (cCmd=='P' || cCmd=='K')
#ifdef HASL2
		return _xhasl_chk(tpxhashb,cCmd,key[0],ippDat);
#else
		return _xhasl_chk(tpxhashb,cCmd,key,ippDat);
#endif
	else if (cCmd=='M') return _xhasl_max(tpxhashb);
	else if (cCmd=='C') return _xhasl_col(tpxhashb,key);
	l = 0;
	offset = 0;
	tpnext = tpxhashb;
	while (tpnext) {
		tpcurr = tpnext;
		tph = (HASHB *)tpcurr->rbc_buf;
		tph->ha_hix = 0;
		tph->ha_key = (char *)argv;
		if (cCmd == 'R') {
			i = akxshaslr(tph,key);
			if (i > 0) ippDat[0] = argv[1];
		}
		else if (cCmd == 'S') {
			argv[1] = ippDat[0];
			i = akxshasls(tph,key);
		}
		else if (cCmd == 'D') {
			i = akxshasld(tph,key);
			if (i > 0) ippDat[0] = argv[1];
		}
		if (i) {
			if (i>0) i += offset;
			return i;
		}
		tpnext = tpcurr->rbc_next;
		offset += tph->ha_maxreg;
	}
/*
printf("akxs_xhasl:(%08x)->xha_xhnext=NULL\n",tpcurr);
*/
	if (cCmd=='R' || cCmd=='D') return i;
	c = tph->ha_id[0];
	if (!(tpnext=akxs_xhasl_new(tph->ha_keylen,tph->ha_maxreg,tph->ha_prereg,0))) return -76;
	tph = (HASHB *)tpnext->rbc_buf;
	tph->ha_id[0] = c;
	tpcurr->rbc_next = tpnext;
	if ((i=akxs_xhasl(tpnext,cCmd,key,ippDat)) > 0) i += offset;
	return i;
}

/************************************/
/*									*/
/************************************/
tdtRbChain *akxs_xhasl_new(sKeyLen,lMaxReg,lPreReg,iOpt)
short sKeyLen;
int  lMaxReg,lPreReg,iOpt;
{
	tdtRbChain *p;

	if (!(p=(tdtRbChain *)Malloc(sizeof(tdtRbChain)))) {
		errno = -1303;
		return NULL;
	}
	p->rbc_buf = (char *)akxs_hasl_new2(sKeyLen,lMaxReg,lPreReg,iOpt);
	p->rbc_next = NULL;
	return p;
}

/************************************/
/*									*/
/************************************/
int akxs_xhasl_free(tpxhashb)
tdtRbChain *tpxhashb;
{
	tdtRbChain *p;
	HASHB *tph;

	if (p=tpxhashb) {
		akxs_xhasl_free(p->rbc_next);
		if (tph=(HASHB *)p->rbc_buf) akxs_hasl_free(tph);
		Free(p);
	}
	return 0;
}

/************************************/
/*									*/
/************************************/
#define _HASL_LIST \
	ce = cell;\
	printf(" i  en  fn ufl flag     hkey next   data\n");\
	for (i=0;i<maxreg;i++,ce++) {\
		enx = en[i];\
		if (iNDEL) {\
			if (i) fnx = 0;\
			else fnx = fn[0];\
		}\
		else fnx = fn[i];\
		if (iUSE_ULIST) uflx = ufl[i];\
		else uflx = 0;\
		printf("%2d %3d %3d %3d %4d %08x %4d %6d\n",\
		       i,enx,fnx,uflx,ce->hc_flag,ce->hc_hkey,ce->hc_next,ce->hc_datp);\
	}\
	fnx = fn[i];\
	uflx = ufl[i];\
	printf("%3d         %3d %3d\n",i,fnx,uflx);

static void _hasl_list(maxreg,iNDEL,iUSE_ULIST,cell,en,col,ul,fn,ufl)
int maxreg,iNDEL,iUSE_ULIST;
tdtHaslCell *cell;
int *en,*col,*ul,*fn,*ufl;
{
	int i,enx,fnx,uflx;
	tdtHaslCell *ce;

	akxs_hasx_list_col_ul(col,ul);
	_HASL_LIST
	return;
}

/************************************/
/*									*/
/************************************/
static void _hasl_list_short(maxreg,iNDEL,iUSE_ULIST,cell,en,col,ul,fn,ufl)
int maxreg,iNDEL,iUSE_ULIST;
tdtHaslCell *cell;
ushort *en,*col,*ul,*fn,*ufl;
{
	int i,enx,fnx,uflx;
	tdtHaslCell *ce;

	akxs_hasx_list_col_ul_short(col,ul);
	_HASL_LIST
	return;
}

/************************************/
/*									*/
/************************************/
void akxs_hasl_list(ha,opt2)
HASHB *ha;
int opt2;
{
	int n,i,ret,opt,enx,fnx,uflx;
	int *en,*np,*ul,*fn,*ufl,*col;
	ushort *usen,*usul,*usfn,*usufl,*uscol;
	char *p;
	tdtHaslCell *cell,*ce;
	int maxreg,iMAX,iUSHORT,iUSE_ULIST,iNDEL;

	if (!opt2) opt2 = -1;
	if (opt2 & 0x01) {
		akxs_hasx_list_ha(ha);
	}
	maxreg = ha->ha_maxreg;
	cell = (tdtHaslCell *)ha->ha_reg;
	opt = ha->ha_id[1] & 0xff;
	iUSHORT = opt & AKX_HASX_OPT_USE_USHORT;
	if (iUSHORT) {
		usen = (ushort *)ha->ha_next;
		uscol = usen + maxreg;
		p = (char *)(uscol+3);
	}
	else {
		en = ha->ha_next;
		col = en + maxreg;
		p = (char *)(col+3);
	}
	if (opt2 & 0x01)  printf("col[3]=%c %c opt=%02x\n",p[0],p[1],opt & 0xff);
	if (opt2 & 0x02) {
		iNDEL = opt & AKX_HASX_OPT_NOT_DELETE;
		iUSE_ULIST = !(opt & AKX_HASX_OPT_NOT_ULIST);
		if (iUSHORT) {
			usul = uscol + AKX_HASX_COL_SIZE;
			usfn = usul  + AKX_HASX_UL_SIZE;
			usufl = usfn  + maxreg + 1;
			_hasl_list_short(maxreg,iNDEL,iUSE_ULIST,cell,usen,uscol,usul,usfn,usufl);
		}
		else {
			ul = col + AKX_HASX_COL_SIZE;
			fn = ul  + AKX_HASX_UL_SIZE;
			ufl = fn  + maxreg + 1;
			_hasl_list(maxreg,iNDEL,iUSE_ULIST,cell,en,col,ul,fn,ufl);
		}
	}
	return;
}
