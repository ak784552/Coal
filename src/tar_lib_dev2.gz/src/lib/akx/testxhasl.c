static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testxhasl.c libakx_no_iconv.a -o testxhasl
*/
#include "akxcommon.h"

int main()
{
	int n,i,ret,opt,*en,*col,*ul,*fn;
	long key;
	char cmd[20],buf[128],c,*argv[2];
	XHASHB *ha;
	tdtHaslCell *cell,*ce;
	int max,pre,iMAX,iUSHORT;
	ushort *usen,*usnp,*usul,*usfn,*usufl;

	printf("Enter option(0/1/2) ==>");
	gets(cmd);
	opt=atoi(cmd);
	printf("Enter MaxReg ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter PreReg ==>");
	gets(cmd);
	pre=atoi(cmd);
	ha = akxs_xhasl_new(4,max,pre,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	ha->ha_key = (char *)argv;
	cell = (tdtHaslCell *)ha->ha_reg;
	iUSHORT = ha->ha_id[1] & AKX_HASX_OPT_USE_USHORT;
	for(;;) {
		ha->ha_hix = 0;
		printf("Enter command(e/p/s/r/d/k/l/u) ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			printf(" col=%d %d\n",col[0],col[1]);
			printf("  ul=%d %d %d  fn[0]=%d\n",ul[0],ul[1],ul[2],fn[0]);
			ce = cell;
			printf(" i flag   hkey next   data   fn\n");
			for (i=0;i<max;i++,ce++) {
				printf("%2d %4d %6d %4d %6d %4d\n",
				       i,ce->hc_flag,ce->hc_hkey,ce->hc_next,ce->hc_datp,fn[i+1]);
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key ==>");
			gets(buf);
		/*	key = atoi(buf);	*/
			if (ret=akxcgcvn(buf,strlen(buf),&key)) break;
			if (c == 's') {
				printf("Enter data ==>");
				gets(buf);
				if (*buf=='\'') argv[1] = (char *)buf[1];
				else {
				/*	ha->ha_nextp = (int *)atoi(buf);	*/
					if (ret=akxcgcvn(buf,strlen(buf),&argv[1])) break;
				}
				ret = akxshasls(ha,key);
			}
			else if (c == 'r') ret = akxshaslr(ha,key);
			else ret = akxshasld(ha,key);
			printf("ret=%d\n",ret);
			if (ret > 0) printf("data=%d\n",argv[1]);
			break;
		case 'k':
		case 'p':
#if 1	/* 2026.1.9 */
			if ((ret=akxshasl('t',ha)) <= 0) {
				printf("no registed.\n");
				break;
			}
			iMAX = ha->ha_aux;
printf("iMAX=%d\n",iMAX);
			printf(" i index hkey\n");
			i = 1;
			for (;;) {
				if (iMAX) {
					if (i > iMAX) break;
				}
				else {
					i = akxshasl('n',ha);
printf("i=%d\n",i);
					if (i <= 0) break;
				}
				ha->ha_hix = i;
#else
			for (i=0;i<max;i++) {
				ha->ha_hix = i + 1;
#endif
				if (c == 'k') {
					ret=akxshaslk(ha,&key);
				}
				else {
					ret=akxshaslp(ha);
					key = *(long *)argv[0];
				}
				if (ret > 0) printf("i=%d ret=%d key=%d data=%d\n",
				                    i,ret,key,argv[1]);
			}
			break;
		case 'u':
			if ((ret=akxshaslu(ha))>=0) {
				printf("used=%d\n",ret);
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
