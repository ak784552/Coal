static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testhasl.c libakx_no_iconv.a -o testhasl
*/
#include "akxcommon.h"

int main()
{
	int n,i,ret,opt,enx,fnx,uflx;
	int *en,*np,*ul,*fn,*ufl,*col;
	ushort *usen,*usul,*usfn,*usufl,*uscol;
	long key;
	char cmd[20],buf[128],c,*argv[2],*p;
	HASHB *ha;
	tdtHaslCell *cell,*ce;
	int max,pre,iMAX,iUSHORT,iUSE_ULIST,iNDEL;

	for (i=0;i<3;i++) {
		printf("Enter option (gcvn) ==>");
		gets(cmd);
		ret = akxcgcvn(cmd,strlen(cmd),&opt);
		if (ret) printf("gcvn error ret=%d\n",ret);
		else break;
	}
	printf("Enter MaxReg ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter PreReg ==>");
	gets(cmd);
	pre=atoi(cmd);
	ha = akxs_hasl_new2(4,max,pre,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	ha->ha_key = (char *)argv;
	cell = (tdtHaslCell *)ha->ha_reg;
	opt = ha->ha_id[1] & 0xff;
	iUSHORT = opt & AKX_HASX_OPT_USE_USHORT;
/*	iUSE_ULIST = !(opt & AKX_HASX_OPT_NOT_ULIST);	*/
	iUSE_ULIST = 0;
	iNDEL = opt & AKX_HASX_OPT_NOT_DELETE;
	if (iUSHORT) {
		usen = (ushort *)ha->ha_next;
		uscol = usen + ha->ha_maxreg;
		usul = uscol + AKX_HASX_COL_SIZE;
		usfn = usul  + AKX_HASX_UL_SIZE;
		usufl = usfn  + max + 1;
		p = (char *)(uscol+3);
	}
	else {
		en = ha->ha_next;
		col = en + ha->ha_maxreg;
		ul = col + AKX_HASX_COL_SIZE;
		fn = ul  + AKX_HASX_UL_SIZE;
		ufl = fn  + max + 1;
		p = (char *)(col+3);
	}
	printf("col[3]=%c %c opt=%02x\n",p[0],p[1],opt & 0xff);
	for(;;) {
		ha->ha_hix = 0;
		printf("Enter command(e/p/s/r/d/k/l/u) ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			if (iUSHORT) {
				printf("uscol=%3d %3d\n",uscol[0],uscol[1]);
				printf("usul =%3d %3d %3d\n",usul[0],usul[1],usul[2]);
			}
			else {
				printf("col=%3d %3d\n",col[0],col[1]);
				printf("ul =%3d %3d %3d\n",ul[0],ul[1],ul[2]);
			}
			ce = cell;
			printf(" i  en  fn ufl flag   hkey next   data\n");
			for (i=0;i<max;i++,ce++) {
				if (iUSHORT) {
					enx = usen[i];
					if (iNDEL) {
						if (i) fnx = 0;
						else fnx = usfn[0];
					}
					else fnx = usfn[i];
					if (iUSE_ULIST) uflx = usufl[i];
					else uflx = 0;
				}
				else {
					enx = en[i];
					if (iNDEL) {
						if (i) fnx = 0;
						else fnx = fn[0];
					}
					else fnx = fn[i];
					if (iUSE_ULIST) uflx = ufl[i];
					else uflx = 0;
				}
				printf("%2d %3d %3d %3d %4d %6d %4d %6d\n",
				       i,enx,fnx,uflx,ce->hc_flag,ce->hc_hkey,ce->hc_next,ce->hc_datp);
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key ==>");
			gets(buf);
		/*	key = atoi(buf);	*/
			if (ret=akxcgcvn (buf,strlen(buf),&key)) break;
			if (c == 's') {
				printf("Enter data ==>");
				gets(buf);
				if (*buf=='\'') argv[1] = (char *)buf[1];
				else {
				/*	ha->ha_nextp = (int *)atoi(buf);	*/
					if (ret=akxcgcvn(buf,strlen(buf),&argv[1])) break;
				}
				ret = akxshasls(ha,key);
			}
			else if (c == 'r') ret = akxshaslr(ha,key);
			else ret = akxshasld(ha,key);
			printf("ret=%d\n",ret);
			if (ret > 0) printf("data=%d\n",argv[1]);
			break;
		case 'k':
		case 'p':
			if ((ret=akxshaslt(ha)) <= 0) {
				printf("no registed.\n");
				break;
			}
			iMAX = ha->ha_aux;
			printf("iMAX=%d\n",iMAX);
			i = 1;
			for (;;i++) {
				if (iMAX) {
					if (i > iMAX) break;
				}
				else {
					i = akxshasln(ha);
					if (i <= 0) break;
				}
				ha->ha_hix = i;
				if (c == 'k') {
					ret=akxshaslk(ha,&key);
				}
				else {
					ret=akxshaslp(ha);
					key = *(long *)argv[0];
				}
				if (ret > 0) printf("i=%d ret=%d key=%d data=%d\n",
				                    i,ret,key,argv[1]);
			}
			break;
		case 'u':
			if ((ret=akxshaslu(ha))>=0) {
				printf("used=%d\n",ret);
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
