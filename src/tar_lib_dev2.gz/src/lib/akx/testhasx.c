static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
    cc -g -DLINUX -I../include testhasx.c libakx_no_iconv.a -o testhasx
*/
#include "akxcommon.h"
int main()
{
	int n,i,klen,lklen,ret,opt,ii,iUSHORT,iUSE_ULIST,iNDEL;
	char key[128],cmd[20],*p,*rp,**rpp,buf[128],*kp,c,*pp;
	HASHB *ha;
	tdtHaslCell *cell,*ce;
	int ex,nx,max,pre,used,iMAX,fnx,uflx,sqnx;
	int      *en,  *np,  *col,  *ul,  *fn,  *ufl,  *sqn;
	ushort *usen,*usnp,*uscol,*usul,*usfn,*usufl,*ussqn;

	printf("Enter option(0/1/2) ==>");
	gets(cmd);
	opt=atoi(cmd);
	printf("Enter MaxReg ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter PreReg ==>");
	gets(cmd);
	pre=atoi(cmd);
	printf("Enter key length ==>");
	gets(cmd);
	klen=atoi(cmd);
	ha = akxs_hasx_new2(klen,max,pre,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	opt = ha->ha_id[1] & 0xff;
	iUSHORT = opt & AKX_HASX_OPT_USE_USHORT;
	iUSE_ULIST = !(opt & AKX_HASX_OPT_NOT_ULIST);
	iNDEL = opt & AKX_HASX_OPT_NOT_DELETE;
	for(;;) {
		ha->ha_key = key;
		ha->ha_hix = 0;
		printf("Enter command(e/l/s/r/d/k/p/u) ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			if (ha->ha_id[0]=='L') {
				cell = (tdtHaslCell *)ha->ha_reg;
				ce = cell;
				printf(" i flag     hkey next     data\n");
				for (i=0;i<max;i++,ce++) {
					printf("%2d %4d %08x %4d %08x\n",
					       i,ce->hc_flag,ce->hc_hkey,ce->hc_next,ce->hc_datp);
				}
			}
			else {
				akxshasx('T',ha);
				rp = ha->ha_reg;
				rpp = (char **)rp;
				p = rp + (max+1)*sizeof(char *);
				en = ha->ha_next;
				if (iUSHORT) {
					usen  = (ushort *)en;
					usnp  = usen + max;
					uscol = usnp + max;
					pp = (char *)(uscol+3);
				}
				else {
					np  = en + max;
					col = np + max;
					pp = (char *)(col+3);
				}
				printf("col[3]=%c %c opt=%02x\n",pp[0],pp[1],opt & 0xff);
				if (iUSHORT) {
					usul  = usnp  + max + AKX_HASX_COL_SIZE;
					usfn  = usul + AKX_HASX_UL_SIZE;
					ussqn = usfn  + max + 1;
					usufl = ussqn + max + 1;
					printf("usul=%3d %3d %3d usfn=%d\n",usul[0],usul[1],usul[2],usfn[0]);
				}
				else {
					ul  = np  + max + AKX_HASX_COL_SIZE;
					fn  = ul + AKX_HASX_UL_SIZE;
					sqn = fn   + max + 1;
					ufl = sqn  + max + 1;
					printf("ul=%3d %3d %3d fn=%d\n",ul[0],ul[1],ul[2],fn[0]);
				}
				printf("  i  en  np  sqn fn ufl f key\n");
				for (i=0;i<max;i++) {
					if (en) {
						if (iUSHORT) {
							ex = usen[i];
							nx = usnp[i];
							fnx = usfn[i];
							uflx = usufl[i];
							sqnx = ussqn[i];
						}
						else {
							ex = en[i];
							nx = np[i];
							fnx = fn[i];
							uflx = ufl[i];
							sqnx = sqn[i];
						}
					}
					else {
						ex = nx = -1;
					}
					printf("%3d %3d %3d %3d %3d %3d ",i,ex,nx,sqnx,fnx,uflx);
					ii = i + 1;
					if (klen>0) {
						memcpy(buf,rp,klen+1);
						buf[klen+1]='\0';
						printf("%x [%s]\n",*buf,buf+1);
						rp+=klen+1;
					}
					else if (klen<0) {
						if (kp=rpp[ii]) {
							memcpy(&lklen,kp,4);
							memcpy(buf,kp+4,lklen);
							buf[lklen]='\0';
						}
						else strcpy(buf,"(null)");
						printf("%x [%s]\n",*p++,buf);
					}
					else {
						if (!(kp=rpp[ii])) {
							strcpy(buf,"(null)");
							kp=buf;
						}
						printf("%x [%s]\n",*p++,kp);
					}
				}
				if (iUSHORT) {
					fnx = usfn[i];
					uflx = usufl[i];
					sqnx = ussqn[i];
				}
				else {
					fnx = fn[i];
					uflx = ufl[i];
					sqnx = sqn[i];
				}
				printf("%3d         %3d %3d %3d\n",i,sqnx,fnx,uflx);
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key ==>");
			gets(buf);
			if (klen>0) {
				memset(key,0,klen);
				strcpy(key,buf);
			}
			else if (klen<0) {
				lklen=strlen(buf);
				memcpy(key,&lklen,4);
				memcpy(key+4,buf,lklen);
			}
			else {
				strcpy(key,buf);
			}
			printf("ret=%d coll=%d\n",akxshasx(*cmd,ha),akxshasx('C',ha));
			break;
		case 'k':
		case 'p':
			if ((used=akxshasx('t',ha)) <= 0) {
				printf("no registed.\n");
				break;
			}
			printf(" i index hkey\n");
			iMAX = ha->ha_aux;
			i = 1;
			for (;;) {
				if (iMAX) {
					if (i > iMAX) break;
				}
				else {
					i = akxshasx('n',ha);
					if (i <= 0) break;
				}
				ha->ha_hix = i;
				if ((ret=akxshasx(c,ha))>0) {
					if (c == 'k') kp = key;
					else kp = ha->ha_key;
					if (klen>0) {
						strnzcpy(buf,kp,klen);
					}
					else if (klen<0) {
						memcpy(&lklen,kp,4);
						strnzcpy(buf,kp+4,lklen);
					}
					else strcpy(buf,kp);
				}
				else strcpy(buf,"(null)");
				printf("%2d %4d [%s]\n",i,ret,buf);
				i++;
			}
			break;
		case 'u':
			if ((ret=akxshasx(c,ha))>=0) {
				printf("used=%d\n",ret);
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
