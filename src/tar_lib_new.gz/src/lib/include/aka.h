/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/********************************************************/
/*														*/
/*		aka.h											*/
/*														*/
/*			coded by A.Kobayashi 2010.8.10				*/
/*														*/
/*********************************************************/
#ifndef _AKA_H
#define _AKA_H

#include "akaconst.h"
#include "akastruct.h"
#include "akaprot.h"

typedef tdtMsgCom	AKAMSGCOM;

#endif	/* _AKA_H */
