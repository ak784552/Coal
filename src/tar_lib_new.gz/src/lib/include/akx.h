/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akx.h															*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.5.28						*/
/*																		*/
/************************************************************************/
#ifndef _AKX_H
#define _AKX_H

#include "akxmemtool.h"
#include "akxlib.h"
#include "akxlog.h"

#endif	/* _AKX_H */
