/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akunix.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.5.28						*/
/*																		*/
/************************************************************************/
#ifndef _AKUNIX_H
#define _AKUNIX_H

/*  */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#if defined(SUNOS) || defined(SUNOS5) || defined(AIX)
#include <jctype.h>
#endif
#include <string.h>
#include <regex.h>
#include <malloc.h>
#include <memory.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#ifdef AIX
#include <sys/select.h>
#endif
#include <sys/socket.h>
/*
#include <sys/socketvar.h>
*/
#include <sys/un.h>
#ifdef LINUX
#include <sys/dirent.h>
#include <dirent.h>
#else
#ifndef SUNOS5
#include <sys/dir.h>
#endif
#endif
#include <sys/file.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/resource.h>
#include <syslog.h>

#if defined(SUNOS) || defined(SUNOS5) || defined(LINUX) || defined(HPUX)
typedef unsigned char uchar;
#endif
#if defined(SUNOS) || defined(LINUX) || defined(HPUX)
typedef unsigned long ulong;
#endif

#ifndef SHRT_MIN
#define CHAR_MIN    (-128)
#define CHAR_MAX    127
#define UCHAR_MAX   255
#define SHRT_MIN    (-32768)    /* min value of a "short int" */
#define SHRT_MAX    32767       /* max value of a "short int" */
#define USHRT_MAX   65535       /* max of "unsigned short int" */
#define INT_MIN     (-2147483647-1) /* min value of an "int" */
#define INT_MAX     2147483647  /* max value of an "int" */
#define UINT_MAX    4294967295U /* max value of an "unsigned int" */
#if defined(_LP64)
#define LONG_MIN    (-9223372036854775807L-1L)
                    /* min value of a "long int" */
#define LONG_MAX    9223372036854775807L
                    /* max value of a "long int" */
#define ULONG_MAX   18446744073709551615UL
                    /* max of "unsigned long int" */
#else /* _ILP32 */
#define LONG_MIN    (-2147483647L-1L)
                    /* min value of a "long int" */
#define LONG_MAX    2147483647L		/* max value of a "long int" */
#define ULONG_MAX   4294967295UL	/* max of "unsigned long int" */
#endif /* _LP64 */
#endif
/*
	short                  32,767
	long            2,147,483,647
	float              16,777,215
	double  9,007,199,254,740,991
*/

typedef          int INT4;
typedef unsigned int UINT4;

#ifndef LONG_BIT_CNT
#if defined(_LP64)
#define LONG_BIT_CNT  64
#else
#define LONG_BIT_CNT  32
#endif
#endif

#endif	/* _AKUNIX_H */
