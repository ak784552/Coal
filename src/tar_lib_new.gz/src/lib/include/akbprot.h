/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akbprot.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.6.18						*/
/*																		*/
/************************************************************************/
#ifndef _AKBPROT_H
#define _AKBPROT_H

/************************************************
 �֐��錾
 *************************************************/
/* akbconnect.c */
int akb_get_host_addr(/*Hostname,ulpaddr_h*/);

/* akbdump.c */
void akb_dump2(/*dump_file, flag, pHead, para, opt*/);
void akb_dump(/*dump_file, flag, pHead, para*/);

/* akb_make_socket.c */
int akba_make_socket_func(/*cpProcName,defaultService,iRetry,socketFunc*/);
int akba_make_socket(/*cpProcName,defaultService,iRetry*/);
int akb_make_socket(/*service,iRetry*/);
int akb_make_socket_sleep_func(/*service,iRetry,iSleep,socketFunc*/);
int akb_make_socket_sleep(/*service,iRetry,iSleep*/);
int akb_service_proto(/*Service,argv*/);
int akb_host_service_proto(/*String,argv*/);
int akb_get_make_sock_addr(/*psa,len*/);
int akb_get_make_sock_parm(/*n,parm*/);
int akb_host_service_proto_linger(/*String,argv*/);
int akb_service_proto_linger(/*Service,argv*/);
int akb_service_linger(/*Service,argv*/);

extern void akb_crt_err_packet();
extern void akb_crt_err_packet();
extern void akbLogPrint();
extern void akb_log_set_proc_name();
extern char *akb_log_get_proc_name();
extern char *akbMalloc();
extern char *akbRealloc();
extern void akbFree();
extern pSdPacketTable akbMakeXpacket();
extern pSdPacketTable akbXtoFpacket();
extern pSdPacketTable akbsMakeXpacket();
extern pSdPacketTable akbsXtoFpacket();
extern void sock_time();
extern void akbSockTimeOut();
extern void akbBrokenPipe();
extern int  akbSetComTimeOut();
extern int  akbGetTimeOut();
extern int  akbSetTimeOut();
extern char *akb_akb_home();
extern char *akb_akb_home_add();
extern char *akb_get_proc_name();
extern char *akb_log_buf();
extern char *akb_log_set_file_name();
extern char *akb_log_file_path();
extern char *akb_log_time();
int akb_log_free();
extern int  akb_create_pk_data();
extern char *akb_akb_ini();
extern char *akb_prom_name();
extern char *akb_netm_name();
int akb_exchg_indicate(/*pPacket*/);

/* akblog.c */
int akb_log_free();
int akb_flog_out_level_pri_main(/*log_no,level,file,line,pri,fp,format,a1,a2,a3,a4,a5*/);
int akb_log_out_level_pri_main(/*log_no,level,file,line,pri,format,a1,a2,a3,a4,a5*/);
int akb_flog_out_level_main(/*log_no,level,file,line,fp,format,a1,a2,a3,a4,a5*/);
int akb_log_out_level_main(/*log_no,level,file,line,format,a1,a2,a3,a4,a5*/);
int akb_log_out_main(/*log_no,file,line,format,a1,a2,a3,a4,a5*/);
int akb_error_out_level_pri(/*level,file,line,pri,format,a1,a2,a3,a4,a5*/);
int akb_ferror_out_level(/*level,file,line,fp,format,a1,a2,a3,a4,a5*/);
int akb_error_out_level(/*level,file,line,format,a1,a2,a3,a4,a5*/);
int akb_error_out_m(/*file,line,format,a1,a2,a3,a4,a5*/);
int akb_error_out(/*file,line,msg*/);
int akb_fprint_out_level(/*level,file,line,fp,format,a1,a2,a3,a4,a5*/);
int akb_print_out_level(/*level,file,line,format,a1,a2,a3,a4,a5*/);
int akb_fdebug_out_level(/*level,file,line,fp,format,a1,a2,a3,a4,a5*/);
int akb_debug_out_level(/*level,file,line,format,a1,a2,a3,a4,a5*/);
int akb_log_buf_len(/*opt*/);
int akb_log_flg(/*i,f*/);
int akb_log_set_up_name(/*cpProcName*/);
int akb_log_level(/*i,level*/);
char *akb_log_set_dir();
int akb_log_set_parm2(/*argc,argv,nParm,iParm*/);
int akb_log_src_file(int argc,char *argv[]);
int akb_log_size(/*i,n,parm*/);
int akb_log_out_check(/*log_no,level,file,line*/);
int akb_trace_flg(/*i,f*/);
char *akb_trace_set_file_name(/*cpFile*/);
int akb_trace_check(/*ucTrace,iRW,sCmd*/);
int akb_trace(/*ucTrace,fname,iRW,cpPacket*/);
int akb_trace_log_out(/*iRW,cpPacket,logflg,file,line,format,a1,a2,a3,a4,a5*/);
int akb_trace_out(/*iRW,cpPacket*/);
int akbfixdmp(/*file,msg,dat,len*/);
int akb_log_clear(/*log_no,option*/);
int akb_log_setup_clear(/*log_no,option*/);
int akb_log_set_func_statistics_count(/*func*/);
int akb_log_statistics_count(/*i,len*/);
char *akb_log_file_path(/*log_no,option*/);
int akb_log_file_path_free_all();
char *akb_log_set_log_name(/*log_no,name*/);
tdtLogCtl *akb_log_get_ctl(/*log_no*/);
int akb_log_set_command_parm(/*opt_c,parm_string*/);
int akb_log_grp_priority(/*i,flg,pri*/);
int akb_log_priority(/*i,pri*/);
int akb_get_log_no(/*name*/);
char *akb_get_log_name(/*int log_no*/);
int akb_log_level_check(/*log_no,level*/);
int akb_prdbg_out_l5(/*level,file,line,fmt,a1,a2,a3,a4,a5*/);
int akb_errdbg_out_l5(/*level,file,line,fmt,a1,a2,a3,a4,a5*/);
int akb_anydbg_out_l5(/*level,i_LOG_NO_PRINT,file,line,fmt,a1,a2,a3,a4,a5*/);

extern void akb_fd_set();
extern void akb_fd_clr();
extern int  akb_fd_isset();
extern void akb_fd_zero();
int  akb_fd_setsize();
int  akb_set_fd_setsize(/*size*/);
extern pSdPacketTable akb_packet_tbl_new();
extern int  akb_detach();
extern char *akb_str_error(/*int err_no*/);
extern char *akb_log_set_log_name(/*int log_no, char *name*/);
extern tdtLogCtl *akb_log_get_ctl(/*int log_no*/);
extern char *akb_packet_new(/* int iLen*/);
extern char *akb_get_str_addr4(/*struct in_addr in*/);
extern char *akb_akb_help_dir(/* int iReSet*/);

/* akbname.c */
int akb_gs_akb_stpli(/*cpBlock,colm,cpName,argv,maxargv*/);
int akb_gs_akb_stplix(/*cpBlock,colm,cpName,argv,maxargv,opt*/);
int akb_gs_akb_stpl(/*cpBlock,cpName,argv,maxargv*/);
int akb_gs_akb_name(/*cpBlock,cpName,cpArg*/);
int akb_gs_akb_stpl_func(/*namv,sep,order,argv,maxargv,pFunc,user_area*/);
int akb_gs_stpl_open(/*mfile,section*/);
int akb_gs_stpl_fetch(/*mfile,argv,maxargc,opt*/);

#endif	/* _AKBPROT_H */
