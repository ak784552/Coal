/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akaprot.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.6.18						*/
/*																		*/
/************************************************************************/
#ifndef _AKAPROT_H
#define _AKAPROT_H

/* akainitregist.c */
int aka_initialize();
int aka_register_class(/*pFuncName,iClassId,iInstanceDataSize,iMaxThread,iOption,
                     cpClassName,cpUserArea*/);
int aka_set_ver_date(/*ver,date*/);
int aka_instance_init(/*iOpt, tpIns, iInstanceDataSize*/);
int aka_set_nofree(/*iSet,level*/);

/* akamsgloop.c */
int aka_get_msg(/*iWaitTime*/);
int aka_dispatch_msg();
void aka_terminate();

/* akasendmsg.c */
int aka_send_msg(/*lInstanceHandle,tpSendMsg*/);
int aka_post_msg(/*lInstanceHandle,tpSendMsg*/);
int aka_send_msg_wait_time(/*lInstanceHandle,tpSendMsg,iWaitTime*/);
int aka_recv_msg(/*lInstanceHandle,tpInst,iWaitTime,iOptions*/);
int aka_post_msg_wait_time(/*lInstanceHandle,tpPostMsgCom,iWaitTime*/);
int aka_set_sleep(/*lInstanceHandle,iDisposition,iSleepTime*/);
int aka_set_inst_comment(/*lInstanceHandle, cpText*/);
int aka_get_inst_comment(/*lInstanceHandle, cppText*/);

/* akacommon.c */
int aka_get_msec(/*ptval*/);
int aka_get_ver_date(/*cpVerDate,iVerDateLen*/);
int aka_shut_control(/*iAttribute,cpValue*/);

#endif	/* _AKAPROT_H */
