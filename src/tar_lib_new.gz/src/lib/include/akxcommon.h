/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akxcommon.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.5.28						*/
/*																		*/
/************************************************************************/
#ifndef _AKXCOMMON_H
#define _AKXCOMMON_H

#include "akunix.h"
#include "akx.h"

#endif	/* _AKXCOMMON_H */
