/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akberror.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.6.30						*/
/*																		*/
/************************************************************************/
#ifndef _AKBERROR_H
#define _AKBERROR_H

/*  */
/*****************************/
/*  ���ʊ�Ղ̃G���[�R�[�h   */
/*****************************/
#define C_ERR_PROC_BASE    -10000
#define C_ERR_TERM_BASE    -20000
#define C_ERR_NETM_BASE    -30000

#define C_ERR_PROC_OFFSET	 -1000
#define C_ERR_TERM_OFFSET	-11000
#define C_ERR_NETM_OFFSET	-21000

#define D_ERR_PACKET_ID     -9001 /* �p�P�b�g�̂h�c���s�� */
#define D_ERR_NO_PROCESS    -9002
#define D_ERR_NO_NETM       -9003
#define D_ERR_NO_PROM       -9004
#define D_ERR_TIMEOUT       -9005
#define D_ERR_AKO_NOREPLY   -9006
#define D_ERR_FILERCV       -9007
#define D_ERR_LESS_DATA     -9008

#define D_ERR_UNKNOWN_CMD   -9010
#define D_ERR_UNKNOWN_CLASS -9011
#define D_ERR_SHUT_MODE     -9012
#define D_ERR_RCO_NOREPLY   -9013
#define D_ERR_PARAMETER     -9014
#define D_ERR_MAKE_PACKET   -9015
#define D_ERR_FORM_CHANGE   -9016
#define D_ERR_UNDEF_CMDEXEC -9018
#define D_ERR_NO_PASSWORD	-9019
#define D_ERR_REPLY_WAIT     9020
#define D_ERR_RCO_RECVPROC  -9021

#define D_ERR_SOCKET_CLOSED -9088
#define D_ERR_PROM_READ     -9089
#define D_ERR_SET_PACKET    -9091
#define D_ERR_PACKET         D_ERR_PACKET_ID
#define D_ERR_PACKET_FORM   -9092
#define D_ERR_ERRPACKET     -9093
#define D_ERR_READ_DATA     -9094
#define D_ERR_READ_HEAD     -9095
#define D_ERR_HEAD_READ      D_ERR_READ_HEAD
#define D_ERR_READ_SOCKET   -9096
#define D_ERR_WRITE_SOCKET  -9097
#define D_ERR_MAKE_SOCKET   -9098
#define D_ERR_MEM_ALLOC     -9099

#define D_ERR_MSG_TIMEOUT   -9106 /* �ۑ��p�P�b�g�̃^�C���A�E�g�G���[ */
#define D_ERR_SHUT_WAKEUP    9107

#define PACKET_TIMEOUT_ERROR   D_ERR_MSG_TIMEOUT
#define PACKET_ID_ERROR        D_ERR_PACKET_ID

#define ERRMSG_PACKET_ID	"Invalid packet id"
#define ERRMSG_PID_INVALID  "Invalid pid"
#define ERRMSG_PID_REGISTED "already registed"
#define ERRMSG_NO_ENTRY     "No entry"
#define ERRMSG_ENTRY_USED   "Entry used"
#define ERRMSG_PID_EXECUTED "Excuted pid"
#define ERRMSG_PID_NOT_FOUND "Pid not found"
#define ERRMSG_NO_PASSWORD	 "Enter password"
#define ERRMSG_UNKNOWN_CMD   "Unknown command"
#define ERRMSG_UNKNOWN_CLASS "Unknown class"
#define ERRMSG_NO_SYSTEM_PID "No system PID"
#define ERRMSG_NO_PROCESS    "No Process"
#define ERRMSG_NOT_RECVPROC		"Can't recv command from you"
#define ERRMSG_MEM_ALLOC		"Memory allocate error"
#define ERRMSG_FORM_CHANGE		"Packet form change error"
#define ERRMSG_SOCKET_CLOSED	"Socket closed"
#define ERRMSG_SHUT_MODE		"Shut mode now"
#define ERRMSG_SHUT_WAKEUP	"Shut wakeup"
#define ERRMSG_MSG_TIMEOUT	"Message timeout"
#define ERRMSG_NO_NETM		"No Netm"

#endif	/* _AKBERROR_H */
