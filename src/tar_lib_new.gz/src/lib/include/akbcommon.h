/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akbcommon.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.6.18						*/
/*																		*/
/************************************************************************/
#ifndef _AKBCOMMON_H
#define _AKBCOMMON_H

#include "akxcommon.h"
#include "akb.h"

#endif	/* _AKBCOMMON_H */
