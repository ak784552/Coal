#include <stdio.h>
#define FILE "test.inf"
#define BLOCK1 "PROCESS"
#define BLOCK2 "SERVICE"
#define NAME  "cpPrMain"
#define LEN   128
#define MAXARGC   10
main()
{
	char *argv[MAXARGC], parm[LEN];
	int n,i;

	n = akxa_gs_stpl(FILE,NULL,NAME,argv,MAXARGC,parm,LEN);
	printf("(null) %s %d\n",NAME,n);
	for (i=0;i<n;i++) printf("%d %s\n",i,argv[i]);

	n = akxa_gs_stpl(FILE,"",NAME,argv,MAXARGC,parm,LEN);
	printf("%s %s %d\n","",NAME,n);
	for (i=0;i<n;i++) printf("%d %s\n",i,argv[i]);

	n = akxa_gs_stpl(FILE,BLOCK1,NAME,argv,MAXARGC,parm,LEN);
	printf("%s %s %d\n",BLOCK1,NAME,n);
	for (i=0;i<n;i++) printf("%d %s\n",i,argv[i]);

	n = akxa_gs_stpl(FILE,BLOCK2,NAME,argv,MAXARGC,parm,LEN);
	printf("%s %s %d\n",BLOCK2,NAME,n);
	for (i=0;i<n;i++) printf("%d %s\n",i,argv[i]);
}
