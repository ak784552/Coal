/*		mpa.c		Multiple-Precision Arithmetic	*/
/*
	cc -g -DLINUX -I../include testmpacmp.c akxcom.a -o testmpacmp
*/
#include	"akxcommon.h"

int main(void)
{
	MPA v, w, x, y, z, zz, x3;
	int k;
	int i = 0;
	time_t now;
	double d;
	char buf[40];

	printf("0,0=%d\n", m_cmp(m_pset_a(&x,"0"),m_pset_a(&y,"0")));
	printf("0,1=%d\n", m_cmp(m_pset_a(&x,"0"),m_pset_a(&y,"1")));
	printf("1,0=%d\n", m_cmp(m_pset_a(&x,"1"),m_pset_a(&y,"0")));
	printf("0,-1=%d\n", m_cmp(m_pset_a(&x,"0"),m_pset_a(&y,"-1")));
	printf("-1,0=%d\n", m_cmp(m_pset_a(&x,"-1"),m_pset_a(&y,"0")));
	printf("1,2=%d\n", m_cmp(m_pset_a(&x,"1"),m_pset_a(&y,"2")));
	printf("2,1=%d\n", m_cmp(m_pset_a(&x,"2"),m_pset_a(&y,"1")));
	printf("-1,2=%d\n", m_cmp(m_pset_a(&x,"-1"),m_pset_a(&y,"2")));
	printf("2,-1=%d\n", m_cmp(m_pset_a(&x,"2"),m_pset_a(&y,"-1")));
	printf("-1,-2=%d\n", m_cmp(m_pset_a(&x,"-1"),m_pset_a(&y,"-2")));
	printf("-2,-1=%d\n", m_cmp(m_pset_a(&x,"-2"),m_pset_a(&y,"-1")));
	printf("0.1,10.0=%d\n", m_cmp(m_pset_a(&x,"0.1"),m_pset_a(&y,"10.0")));
	printf("10.0,0.1=%d\n", m_cmp(m_pset_a(&x,"10.0"),m_pset_a(&y,"0.1")));
	printf("1234,1233=%d\n", m_cmp(m_pset_a(&x,"1234"),m_pset_a(&y,"1233")));
	printf("1233,1234=%d\n", m_cmp(m_pset_a(&x,"1233"),m_pset_a(&y,"1234")));
	return 0;
}
