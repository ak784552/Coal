static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
    cc -g -DLINUX -I../include testhasx.c libakx_no_iconv.a -o testhasx
*/
#include "akxcommon.h"
int main()
{
	int max,pre,opt,i,klen,lklen,ret,iMAX;
	char key[128],cmd[20],*p,buf[128],*kp,c;
	HASHB *ha;

	for (i=0;i<3;i++) {
		printf("Enter option (gcvn) ==>");
		gets(cmd);
		ret = akxcgcvn(cmd,strlen(cmd),&opt);
		if (ret) printf("gcvn error ret=%d\n",ret);
		else break;
	}
	printf("Enter MaxReg ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter PreReg ==>");
	gets(cmd);
	pre=atoi(cmd);
	printf("Enter key length ==>");
	gets(cmd);
	klen=atoi(cmd);
	ha = akxs_hasx_new2(klen,max,pre,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	akxs_hasx_list(ha,1);

	for(;;) {
		ha->ha_key = key;
		ha->ha_hix = 0;
		printf("Enter command(e/l/s/r/d/k/p/u) ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			if (ha->ha_id[0]=='L') {
				akxs_hasl_list(ha,3);
			}
			else {
				akxs_hasx_list(ha,3);
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key ==>");
			gets(buf);
			if (klen>0) {
				memset(key,0,klen);
				strcpy(key,buf);
			}
			else if (klen<0) {
				lklen=strlen(buf);
				memcpy(key,&lklen,4);
				memcpy(key+4,buf,lklen);
			}
			else {
				strcpy(key,buf);
			}
			printf("ret=%d coll=%d\n",akxshasx(*cmd,ha),akxshasx('C',ha));
			break;
		case 'k':
		case 'p':
			if (akxshasx('t',ha) <= 0) {
				printf("no registed.\n");
				break;
			}
			printf(" i index hkey\n");
			iMAX = ha->ha_aux;
			i = 1;
			for (;;) {
				if (iMAX) {
					if (i > iMAX) break;
				}
				else {
					i = akxshasx('n',ha);
					if (i <= 0) break;
				}
				ha->ha_hix = i;
				if ((ret=akxshasx(c,ha))>0) {
					if (c == 'k') kp = key;
					else kp = ha->ha_key;
					if (klen>0) {
						strnzcpy(buf,kp,klen);
					}
					else if (klen<0) {
						memcpy(&lklen,kp,4);
						strnzcpy(buf,kp+4,lklen);
					}
					else strcpy(buf,kp);
				}
				else strcpy(buf,"(null)");
				printf("%2d %4d [%s]\n",i,ret,buf);
				i++;
			}
			break;
		case 'u':
			if ((ret=akxshasx(c,ha))>=0) {
				printf("used=%d\n",ret);
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
