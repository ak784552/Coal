static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
    cc -g -DLINUX -I../include testhasx.c libakx_no_iconv.a -o testhasx
*/
#include "akxcommon.h"
int main()
{
	int n,i,klen,lklen,ret,opt,ii;
	char key[128],cmd[20],*p,*rp,**rpp,buf[128],*kp,c;
	HASHB *ha;
	tdtHaslCell *cell,*ce;
	int *en,*np,ex,nx,max,pre,iUSHORT;
	ushort *usen,*usnp;

	printf("Enter option(0/1/2) ==>");
	gets(cmd);
	opt=atoi(cmd);
	printf("Enter MaxReg ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter PreReg ==>");
	gets(cmd);
	pre=atoi(cmd);
	printf("Enter key length ==>");
	gets(cmd);
	klen=atoi(cmd);
	ha = akxs_hasx_new2(klen,max,pre,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	iUSHORT = ha->ha_id[1] & AKX_HASX_OPT_USE_USHORT;
	for(;;) {
		ha->ha_key = key;
		ha->ha_hix = 0;
		printf("Enter command(e/l/s/r/d/k/p) ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			if (ha->ha_id[0]=='L') {
				cell = (tdtHaslCell *)ha->ha_reg;
				ce = cell;
				printf(" i flag     hkey next     data\n");
				for (i=0;i<max;i++,ce++) {
					printf("%2d %4d %08x %4d %08x\n",
					       i,ce->hc_flag,ce->hc_hkey,ce->hc_next,ce->hc_datp);
				}
			}
			else {
				rp = ha->ha_reg;
				rpp = (char **)rp;
				p = rp + (ha->ha_maxreg+1)*sizeof(char *);
				en = ha->ha_next;
				np = en + ha->ha_maxreg;
				usen = (ushort *)en;
				usnp = usen + ha->ha_maxreg;
				for (i=0;i<max;i++) {
					if (en) {
						if (iUSHORT) {
							ex = usen[i];
							nx = usnp[i];
						}
						else {
							ex = en[i];
							nx = np[i];
						}
					}
					else {
						ex = nx = -1;
					}
					printf("%3d %3d %3d ",i,ex,nx);
					ii = i + 1;
					if (klen>0) {
						memcpy(buf,rp,klen+1);
						buf[klen+1]='\0';
						printf("%x [%s]\n",*buf,buf+1);
						rp+=klen+1;
					}
					else if (klen<0) {
						if (kp=rpp[ii]) {
							memcpy(&lklen,kp,4);
							memcpy(buf,kp+4,lklen);
							buf[lklen]='\0';
						}
						else strcpy(buf,"(null)");
						printf("%x [%s]\n",*p++,buf);
					}
					else {
						if (!(kp=rpp[ii])) {
							strcpy(buf,"(null)");
							kp=buf;
						}
						printf("%x [%s]\n",*p++,kp);
					}
				}
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key ==>");
			gets(buf);
			if (klen>0) {
				memset(key,0,klen);
				strcpy(key,buf);
			}
			else if (klen<0) {
				lklen=strlen(buf);
				memcpy(key,&lklen,4);
				memcpy(key+4,buf,lklen);
			}
			else {
				strcpy(key,buf);
			}
			printf("ret=%d coll=%d\n",akxshasx(*cmd,ha),akxshasx('C',ha));
			break;
		case 'k':
		case 'p':
			printf(" i index hkey\n");
			for (i=0;i<max;i++) {
				ha->ha_hix = i + 1;
				if ((ret=akxshasx(*cmd,ha))>0) {
					if (c == 'k') kp = key;
					else kp = ha->ha_key;
					if (klen>0) {
						strnzcpy(buf,kp,klen);
					}
					else if (klen<0) {
						memcpy(&lklen,kp,4);
						strnzcpy(buf,kp+4,lklen);
					}
					else strcpy(buf,kp);
				}
				else strcpy(buf,"(null)");
				printf("%2d %4d [%s]\n",i,ret,buf);
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
