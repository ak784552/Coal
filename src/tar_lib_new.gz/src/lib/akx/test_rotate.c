static char sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_rotate.c libakx_no_iconv.a -o test_rotate
*/
#include "akxcommon.h"
static char *text="ABCDEFGHIJKLMNOPQRSTUVWXYZ1234";
static int  intd[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
int main()
{
	int ret,nset,m,intw[20],i;
	char buf[256];
/*
	nset = 10;
	m = 3;
	strcpy(buf,text);
	ret = mem_rotate(buf,nset,m);
	printf("%s\n",buf);

	strcpy(buf,text);
	ret = mem_rotate(buf,nset,1);
	printf("%s\n",buf);
*/
	mem_cpy_int(intw,intd,20);
	ret = mem_rotate_int_cell(intw,7,20,1);
	for (i=0;i<20;i++) printf("%d ",intw[i]);
	puts("");

	mem_cpy_int(intw,intd,20);
	ret = mem_rotate_int_cell(intw,13,20,1);
	for (i=0;i<20;i++) printf("%d ",intw[i]);
	puts("");

	mem_cpy_int(intw,intd,20);
	ret = mem_rotate_int_cell(intw,-7,20,1);
	for (i=0;i<20;i++) printf("%d ",intw[i]);
	puts("");

	mem_cpy_int(intw,intd,20);
	ret = mem_rotate_int_cell(intw,0,20,1);
	for (i=0;i<20;i++) printf("%d ",intw[i]);
	puts("");

	exit(0);
}
