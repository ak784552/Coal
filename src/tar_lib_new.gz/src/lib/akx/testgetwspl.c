static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DAIX -I../include testgetwspl.c akxcom.a -o testgetwspl
*/
#include "akxcommon.h"
main()
{
	char buf[256],wd[256];
	int n,opt,len,wlen;
	SSPL_S sspl;

	printf("Enter MAXLEN(<=255)==>");
	gets(buf);
	len=atoi(buf);
	printf("Enter WDMAXCHECK(<=256)==>");
	gets(buf);
	sspl.wdmax=atoi(buf);
	printf("Enter OPT(0,1:#,2:=,3)==>");
	gets(buf);
	opt=atoi(buf);
	sspl.wd = wd;
	for (;;) {
		printf("Enter==>");
		gets(buf);
		sspl.sp = 0;
		*wd = '\0';
		if ((wlen=len)<=0) wlen=strlen(buf);
		while((n=akxtgetwnspl(buf, wlen, &sspl, opt))>=0) {
			printf("pos=%d n=%d wd=%s attr=%08x\n",sspl.sp,n,wd,*(int *)sspl.attr);
			*wd = '\0';
		}
	}
}
