static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DSUNOS -I../include test2vsep.c akxcom.a -o test2vsep
	cc -g -DLINUX -I../include test2vsep.c akxcom.a -o test2vsep
*/
#include "akxcommon.h"
main()
{
	char buf[256],parm[256],*argv[2],sep;
	int n,opt,parmlen;

	parmlen = sizeof(parm);
	printf("parm len(%d) ==>",parmlen);
	gets(buf);
	parmlen = atoi(buf);
	printf("sep==>");
	gets(buf);
	sep = *buf;
	for (;;) {
		printf("Enter==>");
		gets(buf);
		n = akxtget2vsep(buf,argv,parm,parmlen,sep,opt);
		printf("n=%d argv0=[%s] argv1=[%s]\n",n,argv[0],argv[1]);
	}
}
