static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DSUNOS -I../include testque.c akxcom.a -o testque
*/
#include "akxcommon.h"

int main()
{
	tdtQueCtl *pQueCtl;
	char *cp;
	int rc,i;

	pQueCtl = akxs_que_init(0,0);
	printf("set 1:rc=%d\n",akxs_que_put(pQueCtl,QUE_PUT,1));
	printf("set 2:rc=%d\n",akxs_que_put(pQueCtl,QUE_PUT,2));
	printf("set 3:rc=%d\n",akxs_que_put(pQueCtl,QUE_PUT,3));
	printf("set 4:rc=%d\n",akxs_que_put(pQueCtl,QUE_PUT,4));

	rc=akxs_que_move(pQueCtl,QUE_TOP_PREV,NULL);
	printf("MOVE_TOPP:rc=%d\n",rc);
	for (i=1;;i++) {
		rc=akxs_que_peek(pQueCtl,QUE_NEXT,&cp);
		printf("PEEK_NEXT %d:rc=%d cp=%08x\n",i,rc,cp);
		if (rc<1) break;
	}
	rc=akxs_que_peek(pQueCtl,QUE_NEXT,&cp);
	printf("PEEK_NEXT %d:rc=%d cp=%08x\n",i,rc,cp);

	rc=akxs_que_move(pQueCtl,QUE_BOT_NEXT,NULL);
	printf("MOVE_BOTN:rc=%d\n",rc);
	for (i=1;;i++) {
		rc=akxs_que_peek(pQueCtl,QUE_PREV,&cp);
		printf("PEEK_PREV %d:rc=%d cp=%08x\n",i,rc,cp);
		if (rc<1) break;
	}
	rc=akxs_que_peek(pQueCtl,QUE_PREV,&cp);
	printf("PEEK_PREV %d:rc=%d cp=%08x\n",i,rc,cp);

	for (i=1;;i++) {
		rc=akxs_que_get(pQueCtl,QUE_GET,&cp);
		printf("get %d:rc=%d cp=%08x\n",i,rc,cp);
		if (rc<1) break;
	}

	rc=akxs_que_free(pQueCtl);
	printf("Free:rc=%d\n",rc);

	exit(0);
}
