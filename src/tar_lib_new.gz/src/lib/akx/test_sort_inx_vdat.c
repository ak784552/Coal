static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include test_sort_inx_vdat.c libakx_no_iconv.a -o test_sort_inx_vdat
*/
#include <akxcommon.h>

int main()
{
	char *dat0[]={"service-8","set2","project4","open9","internet1","pack0","status-3","consulting6","lock5","version7"};
	char *vdat0[]={"cd-8","action2","flg4","data9","level1","file0","partner-3","vendor6","test5","order7"};
	int inx[]={-8,2,4,9,1,0,-3,6,5,7};
	int i,opt;
	char *p,*dat[10],*vdat[10],buf[80];

	printf("Enter option : ");
	gets(buf);
	akxcgcvn(buf,strlen(buf),&opt);
	mem_cpy_addr(dat,dat0,10);
	mem_cpy_addr(vdat,vdat0,10);
	akxstrsort_inx_vdat(dat,10,inx,vdat,opt);
	for (i=0;i<10;i++) {
		printf("i=%d dat=[%s]\n",i,dat[i]);
	}
	for (i=0;i<10;i++) {
		printf("i=%d inx=%d\n",i,inx[i]);
	}
	for (i=0;i<10;i++) {
		printf("i=%d vdat=[%s]\n",i,vdat[i]);
	}
}
