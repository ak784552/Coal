static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_memtool.c libakx_no_iconv.a -o test_memtool
*/
#include "akxcommon.h"
main()
{
	char *p;
	int ret;

	Meminit("memtool.ctl");
	p = Malloc(1);
	p = Malloc(48);
	p = Malloc(100);
	ret=Nofree(0);
	printf("ret=%d\n",ret);
}
