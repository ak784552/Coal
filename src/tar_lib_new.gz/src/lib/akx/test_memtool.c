static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_memtool.c libakx_no_iconv.a -o test_memtool
*/
#include "akxcommon.h"
int main()
{
	char *p,*mem[20];
	int ret,i;

	Meminit("memtool.ctl");
	for (i=0;i<15;i++) {
		mem[i] = Malloc(i+1);
	}
	Free(mem[9]);
/*
	for (i=0;i<15;i++) {
		Free(mem[i]);
	}
*/
/*
	p = Malloc(1);
	p = Malloc(48);
	p = Malloc(100);
*/
	ret=Nofree(0);
	printf("ret=%d\n",ret);
}
