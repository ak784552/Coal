static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testhasl.c libakx_no_iconv.a -o testhasl
*/
#include "akxcommon.h"

int main()
{
	int n,i,ret,opt;
	long key;
	char cmd[20],buf[128],c,*argv[2];
	HASHB *ha;
	tdtHaslCell *cell,*ce;
	int max,pre;

	printf("Enter option(0/1/2) ==>");
	gets(cmd);
	opt=atoi(cmd);
	printf("Enter MaxReg ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter PreReg ==>");
	gets(cmd);
	pre=atoi(cmd);
	ha = akxs_hasl_new2(4,max,pre,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	ha->ha_key = (char *)argv;
	cell = (tdtHaslCell *)ha->ha_reg;
	for(;;) {
		ha->ha_hix = 0;
		printf("Enter command(e/p/s/r/d/k/l) ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			ce = cell;
			printf(" i flag   hkey next   data\n");
			for (i=0;i<max;i++,ce++) {
				printf("%2d %4d %6d %4d %6d\n",
				       i,ce->hc_flag,ce->hc_hkey,ce->hc_next,ce->hc_datp);
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key ==>");
			gets(buf);
		/*	key = atoi(buf);	*/
			if (ret=akxcgcvn (buf,strlen(buf),&key)) break;
			if (c == 's') {
				printf("Enter data ==>");
				gets(buf);
				if (*buf=='\'') argv[1] = (char *)buf[1];
				else {
				/*	ha->ha_nextp = (int *)atoi(buf);	*/
					if (ret=akxcgcvn(buf,strlen(buf),&argv[1])) break;
				}
				ret = akxshasls(ha,key);
			}
			else if (c == 'r') ret = akxshaslr(ha,key);
			else ret = akxshasld(ha,key);
			printf("ret=%d\n",ret);
			if (ret > 0) printf("data=%d\n",argv[1]);
			break;
		case 'k':
		case 'p':
			for (i=0;i<max;i++) {
				ha->ha_hix = i + 1;
				if (c == 'k') {
					ret=akxshaslk(ha,&key);
				}
				else {
					ret=akxshaslp(ha);
					key = *(long *)argv[0];
				}
				if (ret > 0) printf("i=%d ret=%d key=%d data=%d\n",
				                    i,ret,key,argv[1]);
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
