static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testhasl.c libakx_no_iconv.a -o testhasl
*/
#include "akxcommon.h"

int main()
{
	int max,pre,i,ret,opt,iMAX;
	long key;
	char cmd[20],buf[128],c,*argv[2];
	HASHB *ha;

	for (i=0;i<3;i++) {
		printf("Enter option (gcvn) ==>");
		gets(cmd);
		ret = akxcgcvn(cmd,strlen(cmd),&opt);
		if (ret) printf("gcvn error ret=%d\n",ret);
		else break;
	}
	printf("Enter MaxReg ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter PreReg ==>");
	gets(cmd);
	pre=atoi(cmd);
	ha = akxs_hasl_new2(4,max,pre,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	ha->ha_key = (char *)argv;

	akxs_hasl_list(ha,1);

	for(;;) {
		ha->ha_hix = 0;
		printf("Enter command(e/p/s/r/d/k/l/u) ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			akxs_hasl_list(ha,2);
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key ==>");
			gets(buf);
			if (ret=akxcgcvn (buf,strlen(buf),&key)) break;
			if (c == 's') {
				printf("Enter data ==>");
				gets(buf);
				if (*buf=='\'') argv[1] = (char *)buf[1];
				else {
					if (ret=akxcgcvn(buf,strlen(buf),&argv[1])) break;
				}
				ret = akxshasls(ha,key);
			}
			else if (c == 'r') ret = akxshaslr(ha,key);
			else ret = akxshasld(ha,key);
			printf("ret=%d\n",ret);
			if (ret > 0) printf("data=%d\n",argv[1]);
			break;
		case 'k':
		case 'p':
			if ((ret=akxshaslt(ha)) <= 0) {
				printf("no registed.\n");
				break;
			}
			iMAX = ha->ha_aux;
			printf("iMAX=%d\n",iMAX);
			i = 1;
			for (;;i++) {
				if (iMAX) {
					if (i > iMAX) break;
				}
				else {
					i = akxshasln(ha);
					if (i <= 0) break;
				}
				ha->ha_hix = i;
				if (c == 'k') {
					ret=akxshaslk(ha,&key);
				}
				else {
					ret=akxshaslp(ha);
					key = *(long *)argv[0];
				}
				if (ret > 0) printf("i=%d ret=%d key=%d data=%d\n",
				                    i,ret,key,argv[1]);
			}
			break;
		case 'u':
			if ((ret=akxshaslu(ha))>=0) {
				printf("used=%d\n",ret);
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
