static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testhasl.c libakx_no_iconv.a -o testhasl
*/
#include "akxcommon.h"

int main()
{
	int n,i,ret,opt;
	int *en,*np,*ul,*fn,*ufl,fnx,uflx,*col;
	long key;
	char cmd[20],buf[128],c,*argv[2],*p;
	HASHB *ha;
	tdtHaslCell *cell,*ce;
	int max,pre,iMAX;

	printf("Enter option(0/1/2) ==>");
	gets(cmd);
	opt=atoi(cmd);
	printf("Enter MaxReg ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter PreReg ==>");
	gets(cmd);
	pre=atoi(cmd);
	ha = akxs_hasl_new2(4,max,pre,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	ha->ha_key = (char *)argv;
	cell = (tdtHaslCell *)ha->ha_reg;
	en = ha->ha_next;
	col = en + max;
	ul  = col + AKX_HASX_COL_SIZE;
	fn  = ul  + AKX_HASX_UL_SIZE;
	ufl = fn  + max + 1;
	p = (char *)(col+3);
	printf("col[3]=%c %c\n",p[0],p[1]);
	for(;;) {
		ha->ha_hix = 0;
		printf("Enter command(e/p/s/r/d/k/l/u) ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			printf("ul=%3d %3d %3d\n",ul[0],ul[1],ul[2]);
			ce = cell;
			printf(" i  en  fn ufl flag   hkey next   data\n");
			for (i=0;i<max;i++,ce++) {
				printf("%2d %3d %3d %3d %4d %6d %4d %6d\n",
				       i,en[i],fn[i],ufl[i],ce->hc_flag,ce->hc_hkey,ce->hc_next,ce->hc_datp);
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key ==>");
			gets(buf);
		/*	key = atoi(buf);	*/
			if (ret=akxcgcvn (buf,strlen(buf),&key)) break;
			if (c == 's') {
				printf("Enter data ==>");
				gets(buf);
				if (*buf=='\'') argv[1] = (char *)buf[1];
				else {
				/*	ha->ha_nextp = (int *)atoi(buf);	*/
					if (ret=akxcgcvn(buf,strlen(buf),&argv[1])) break;
				}
				ret = akxshasls(ha,key);
			}
			else if (c == 'r') ret = akxshaslr(ha,key);
			else ret = akxshasld(ha,key);
			printf("ret=%d\n",ret);
			if (ret > 0) printf("data=%d\n",argv[1]);
			break;
		case 'k':
		case 'p':
			if ((ret=akxshaslt(ha)) <= 0) {
				printf("no registed.\n");
				break;
			}
			iMAX = ha->ha_aux;
			printf("iMAX=%d\n",iMAX);
			i = 1;
			for (;;) {
				if (iMAX) {
					if (i > iMAX) break;
				}
				else {
					i = akxshasln(ha);
					if (i <= 0) break;
				}
				ha->ha_hix = i;
				if (c == 'k') {
					ret=akxshaslk(ha,&key);
				}
				else {
					ret=akxshaslp(ha);
					key = *(long *)argv[0];
				}
				if (ret > 0) printf("i=%d ret=%d key=%d data=%d\n",
				                    i,ret,key,argv[1]);
			}
			break;
		case 'u':
			if ((ret=akxshaslu(ha))>=0) {
				printf("used=%d\n",ret);
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
