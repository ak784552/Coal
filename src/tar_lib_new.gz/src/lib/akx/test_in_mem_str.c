static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_in_mem_str.c libakx_no_iconv.a -o test_in_mem_str
*/
#include "akxcommon.h"
int main()
{
	int n,i,rc,ltar,lstr,code_type,opt;
	char buf[256],str[20];

	code_type = akxt_get_code_type();
	printf("Enter opt: ");
	gets(buf);
	akxcgcvl(buf,strlen(buf),&opt);
	strcpy(buf,"abcあ和eホghijkウｱｼﾞXyZ");
	ltar = strlen(buf);
	printf("opt=%08x ltar=%d buf=[%s]\n",opt,ltar,buf);

	strcpy(str,"cあ");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_opt(buf,ltar,str,lstr,opt));

	strcpy(str,"ホgh");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_opt(buf,ltar,str,lstr,opt));

	strcpy(str,"Cあ");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_opt(buf,ltar,str,lstr,opt));

	strcpy(str,"Ｃあ");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_opt(buf,ltar,str,lstr,opt));

	strcpy(str,"ｱジx");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_opt(buf,ltar,str,lstr,opt));

	exit(0);
}
