#include <stdio.h>
main()
{
	char path[256],delm[256];
	int n,pos,max;

	printf("Enter delm==>");
	gets(delm);
	for (;;) {
		printf("Ente path ==>");
		gets(path);
		printf("last name=%s\n",akxt_get_last_name(delm,path));
	}
}
