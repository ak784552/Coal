static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testlist.c akxcom.a -o testlist
*/
#include "akxcommon.h"
main()
{
	tdtRbCtl *pRbCtl;
	char c,buf[128],*p;
	int n,ret,cmd,opt;

	pRbCtl = akxs_list_new(0,0);
	for(;;) {
		printf("Enter End/Set n/SetT n/Get/GetN/Peak/PeakN/srCh n/Read cmd:");
		gets(buf);
		if ((c=*buf) == 'E') break;
		else if (c == 'S') {
			if (buf[1]=='T') {
				n = atoi(buf+2);
				ret = akxs_list_set_t(pRbCtl,n);
				printf("SetT ret=%d n=%d\n",ret,n);
			}
			else {
				n = atoi(buf+1);
				ret = akxs_list_set(pRbCtl,n);
				printf("Set ret=%d n=%d\n",ret,n);
			}
		}
		else if (c == 'G') {
			if (buf[1]=='N') {
				ret = akxs_list_get_n(pRbCtl,&n);
				printf("GetN ret=%d n=%d\n",ret,n);
			}
			else {
				ret = akxs_list_get(pRbCtl,&n);
				printf("Get ret=%d n=%d\n",ret,n);
			}
		}
		else if (c == 'P') {
			if (buf[1]=='N') {
				ret = akxs_list_peek_n(pRbCtl,&n);
				printf("PeekN ret=%d n=%d\n",ret,n);
			}
			else {
				ret = akxs_list_peek(pRbCtl,&n);
				printf("Peek ret=%d n=%d\n",ret,n);
			}
		}
		else if (c == 'C') {
			n = atoi(buf+1);
			printf("Enter opt :");
			gets(buf);
			opt = atoi(buf);
			ret = akxs_list_srch(pRbCtl,n,NULL,opt);
			printf("Srch ret=%d n=%d\n",ret,n);
		}
		else if (c == 'R') {
			cmd = atoi(buf+1);
			ret = akxs_list_read(pRbCtl,cmd,&n);
			printf("Read ret=%d n=%d\n",ret,n);
		}
		sub1(pRbCtl); sub2(pRbCtl);
	}
	ret = akxs_list_free(pRbCtl,0);
}

sub1(pCt)
tdtRbCtl *pCt;
{
	printf("pCt->rb_num = %d\n",pCt->rb_num);
	printf("pCt->rb_used = %d\n",pCt->rb_used);
	printf("pCt->rb_pos = %d\n",pCt->rb_pos);
	printf("pCt->rb_raddr = %08x\n",pCt->rb_raddr);
	printf("pCt->rb_waddr = %08x\n",pCt->rb_waddr);
	printf("pCt->rb_wpriv = %08x\n",pCt->rb_wpriv);
	printf("pCt->rb_cur   = %08x\n",pCt->rb_cur);
}

sub2(pCt)
tdtRbCtl *pCt;
{
	tdtRbChain *pr;

	pr = pCt->rb_raddr;
	while (pr) {
		printf("self = %08x, cpBuff = %08x, next = %08x\n",
		       pr,pr->rbc_buf,pr->rbc_next);
		pr = pr->rbc_next;
	}
}
