#include <stdio.h>
int main()
{
	int a;
#if 0
/*
#if 1
#endif
*/
	a = 1;

	printf("aaa\
#if n\
#endif\
z\n);
#endif
}
