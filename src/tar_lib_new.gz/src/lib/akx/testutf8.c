static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testutf8.c libakx_no_iconv.a -o testutf8
*/
#include "akxcommon.h"
main(argc,argv)
int argc;
char *argv[];
{
	int len,ucs4;
	ushort  sjis;
	uchar   utf8c[5],inc[256],outc[1024],type_s,type_d,buf[20];
	tdtGeneralData tg_s,tg_d;

	if (argc > 1) {
		akxc_set_sj_utf8(argv[1]);
	}
/*
	sjis = 'A';
	len = akxc_sjto_utf8(sjis,utf8c);
	utf8c[len] = '\0';
	printf("sjis=%04x utf8c=[%s]\n",sjis,utf8c);
*/
	strcpy(inc," +-09AZaz�@��#���A�@\\~");
	len = akxcstou8(strlen(inc), inc, outc);
	akxaxdump("sjis",inc,strlen(inc));
	akxaxdump("utf8",outc,len);
	len = akxcu8tos(len, outc, inc);
	akxaxdump("sjis",inc,strlen(inc));
/*
	len = akxcu8tos(len, outc, inc);
	akxaxdump("sjis",inc,strlen(inc));
*/
/*
	printf("moji\tS-JIS\tUCS2\tUCS4\n");
	while ((len = akxa_get_line(inc,sizeof(inc), stdin, 0x03)) >= 0) {
		if (len==1 || len==2) {
			if (len == 1) sjis = inc[0];
			else sjis = inc[0]<<8 | inc[1] ;
			len = akxc_sjto_utf8(sjis,outc,&ucs4);
			printf("%s\t%04x\t%04x\t%08x\n",inc,sjis,ucs4,ucs4);
		}
	}
*/
	type_s = akxt_get_lang_type("LANG",0,buf,sizeof(buf));
	printf("LANG: %s type=%d\n",buf,type_s);
	type_d = akxt_get_lang_type("NLS_LANG",0,buf,sizeof(buf));
	printf("NLS_LANG: %s type=%d\n",buf,type_d);

	type_s = akxt_get_lang_type("LANG",0,buf,sizeof(buf));
	printf("LANG: %s type=%d\n",buf,type_s);
	type_d = akxt_get_lang_type("NLS_LANG",0,buf,sizeof(buf));
	printf("NLS_LANG: %s type=%d\n",buf,type_d);

	tg_s.gd_id = ' ';
	tg_s.gd_attr = 0;
	tg_s.gd_scale = 0;
	tg_s.gd_code = type_s;
	tg_s.gd_dlen = strlen(inc);
	tg_s.gd_data = inc;

	tg_d.gd_id = ' ';
	tg_d.gd_code = type_d;
	tg_d.gd_data = NULL;

	len = akxt_code_trans(&tg_s,&tg_d);
	printf("len=%d tg_d=[%s]\n",len,tg_d.gd_data);
	if (tg_d.gd_data) {
		akxaxdump("tg_d",tg_d.gd_data,len);

		tg_d.gd_attr = 0;
		tg_d.gd_scale = 0;
		tg_s.gd_id = ' ';
		tg_s.gd_code = type_s;
		tg_s.gd_data = NULL;
		len = akxt_code_trans(&tg_d,&tg_s);
		printf("len=%d tg_s=[%s]\n",len,tg_s.gd_data);
		if (tg_s.gd_data) {
			akxaxdump("tg_s",tg_s.gd_data,len);
		}
	}
}
