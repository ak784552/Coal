static char sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_reverse_cell.c libakx_no_iconv.a -o test_reverse_cell
*/
#include "akxcommon.h"
static char *text="ABCDEFGHIJKLMNOPQRSTUVWXYZ1234";
static int  intd[]={1,2,3,4,5,6,7,8,9,10};
int main()
{
	int ret,nset,m,intw[10],i;
	char buf[256];

	nset = 10;
	m = 3;
	strcpy(buf,text);
	ret = mem_reverse_byte_cell(buf,nset,m);
	printf("%s\n",buf);

	strcpy(buf,text);
	ret = mem_reverse_byte_cell(buf,nset,1);
	printf("%s\n",buf);

	mem_cpy_int(intw,intd,10);
	ret = mem_reverse_int_cell(intw,5,2);
	for (i=0;i<10;i++) printf("%d ",intw[i]);
	puts("");

	exit(0);
}
