static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DSUNOS -I../include testnaplsql.c ../xcom/akxcom.a -o testnaplsql
*/
#include <stdio.h>
main()
{
	char file[256],where[256],*argv[10],parm[256];
	int n,i,opt;

	printf("Enter case opt==>");
	gets(file);
	opt=atoi(file);
	printf("Enter file==>");
	gets(file);
	for (;;) {
		printf("Enter where==>");
		gets(where);
		n = akxanaplsqlx(file,where,argv,10,parm,sizeof(parm),opt);
		printf("ret=%d\n",n);
		for (i=0;i<n;i++) printf("argv[%d]=[%s]\n",i,argv[i]);
	}
}
