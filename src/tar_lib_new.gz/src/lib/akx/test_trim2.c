static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_trim2.c libakx.a -o testTrim2
*/
#include "akxcommon.h"
main()
{
	char buf[256],wd[256],pat[256];
	int n,opt,len,ret;
	ParList pa_dat;

	for (;;) {
		printf("Enter opt==>");
		gets(buf);
		opt=atoi(buf);
		if (opt < 0) break;
		printf("Enter string==>");
		gets(buf);
		printf("buf=[%s] strlen(buf)=%d\n",buf,strlen(buf));
		printf("Enter len==>");
		gets(wd);
		len = atoi(wd);
		printf("Enter pat==>");
		gets(pat);
		ret = akxtstrim2(opt,buf,len,&pa_dat,pat);
		printf("ret=%d par=[%s] parlen=%d\n",ret,pa_dat.par,pa_dat.parlen);
		printf(" buf=[%s] strlen(buf)=%d\n",buf,strlen(buf));
	}
}
