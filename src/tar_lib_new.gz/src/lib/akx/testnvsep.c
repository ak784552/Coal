static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testnvsep.c akxcom.a -o testnvsep
*/
#include "akxcommon.h"
main()
{
	char buf[256],*argv[100],sep[100],*p;
	int n,opt,i,len,l,maxargc;

	printf("maxargc ==>");
	gets(buf);
	maxargc = atoi(buf);
	printf("sep ==>");
	gets(sep);
	for (;;) {
		printf("Enter==>");
		gets(buf);
		len = strlen(buf);
		n = akxtgetnvsep(buf,argv,maxargc,sep,opt);
		printf("n=%d\n",n);
		if (n >= 0) {
			for (i=0;i<maxargc;i++)
				printf("i=%d argv=[%s]\n",i,argv[i]);
			p = buf;
			i = 0;
			while (i < len) {
				printf("pos=%d p=[%s]\n",i,p);
				l = strlen(p);
				printf("  l=%d\n",l);
				p += l + 1;
				i += l + 1;
			}
		}
	}
}
