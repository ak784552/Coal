/****************************************/
/*										*/
/****************************************/
#define D_STRMEMI_SIZE	256
#define D_MAX_STRMEMI	20
#define D_MAX_STRMEM_KEYL	36	/* �I�[ null���܂� */

char *strmemi(s,len,i)
char *s;
int  len,i;
{
#if 1
	static char wrk[D_STRMEMI_SIZE*D_MAX_STRMEMI];
	static char *p1[D_MAX_STRMEMI]={NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};
	char *p;

	if (i < 0) i = 0;
	else if (i >= D_MAX_STRMEMI) i = D_MAX_STRMEMI - 1;
	if ((len=akxmemwork(len,&p,&p1[i],wrk+D_STRMEMI_SIZE*i,D_STRMEMI_SIZE)) >= 0) {
		memzcpy(p,s,len);
	}
	return p;
#else
	static int Init=0,max_strmem=D_MAX_STRMEMI;
	static char mema[D_STRMEMI_SIZE*D_MAX_STRMEMI];
	static char *p0[D_MAX_STRMEMI],**p1=NULL,*mema1=NULL;
	char *p,**pp,*pmema;
	int len1,len2,incr,len3,len4;
/*
printf("strmemi:Enter: s=%08x len=%d i=%d\n",s,len,i);
*/
	if (!Init) {
		Init = 1;
		mem_set_addr(p1,NULL,D_MAX_STRMEMI);
	}
	if (i < 0) i = 0;
	else if (i >= max_strmem) {
		incr = i - max_strmem + 10;
		len1 = max_strmem + incr;
		len2=akxmemwork(len1,&pp,&p1,p0,sizeof(char *)*D_MAX_STRMEMI);
/*
printf("strmemi: len1=%d len2=%d pp=%08x p1=%08x\n",len1,len2,pp,p1);
*/
		if (len1 == len2) {
			memset(pp+max_strmem*sizeof(char *),0,sizeof(char *)*incr);
			len3 = (max_strmem + incr)*D_STRMEMI_SIZE;
			len4=akxmemwork(len3,&pmema,&mema1,mema,D_STRMEMI_SIZE*D_MAX_STRMEMI);
/*
printf("strmemi: len3=%d len4=%d max_strmem=%d pmema=%08x mema1=%08x\n",len3,len4,max_strmem,pmema,mema1);
*/
			if (len1 == len2) max_strmem = len1;
		}
		if (max_strmem != len1) i = 0;
		return strmemi(s,len,i);
	}
	if (!(pp=p1)) pp = p0;
	if (!(pmema=mema1)) pmema = mema;
	if ((len=akxmemwork(len,&p,&pp[i],pmema+D_STRMEMI_SIZE*i,D_STRMEMI_SIZE)) >= 0) {
		if (s) memzcpy(p,s,len);
/*
printf("strmemi: p=%08x len=%d\n",p,len);
*/
	}
	else {
		p = mema + D_STRMEMI_SIZE*i;
		if (s) memnzcpy(p,s,len,D_STRMEMI_SIZE);
	}
	return p;
#endif
}
/****************************************/
/*										*/
/****************************************/
char *strmemk(s,len,key)
char *s,*key;
int  len;
{
#if 0	/* 2024.9.16 */
	static int Init=0;
	static XHASHB *xha;
	static char wrk[256];
	long ih;
	int opt;
	char *p;
/*
printf("strmemk:Enter: s=%08x len=%d key=[%s]\n",s,len,key);
*/
	if (!Init) {
		Init = 1;
		opt = AKX_HASX_OPT_USE_MALLOC | AKX_HASX_OPT_NO_DAT_CP;
		xha = akxs_xhashm_new2(0,D_MAX_STRMEMI,0,0,opt,NULL,NULL);
/*
printf("strmemk: xha=%08x\n",xha);
if (xha) printf("strmemk: maxreg=%d prereg=%d option=%08x\n",xha->xha_maxreg,xha->xha_prereg,xha->xha_option);
*/
	}
	p = NULL;
	ih = -1;
	if (xha) {
		if ((ih=akxs_xhash2(xha,'S',key,&len)) > 0) {
			ih = akxs_xhash2(xha,'R',key,&p);
		}
	}
	if (p) memzcpy(p,s,len);
	else {
		p = wrk;
		strnzcpy(p,s,sizeof(wrk)-1);
	}
/*
printf("strmemk:Exit ih=%d p=%08x [%s]\n",ih,p,p);
*/
	return p;
#else
#if 1	/* 2024.9.15 */
	typedef struct {
		char key[D_MAX_STRMEM_KEYL];
		int memlen;
		char *mem;
	} tdtKey;
	static char wrk[256];
	static int Init=0,max_strmem,Used;
	static tdtKey *keys;
	tdtKey *pk;
	char *p;
	int i,ii,memlen,keys_len;
/*
printf("strmemk:Enter: s=%08x len=%d key=[%s]\n",s,len,key);
*/
	if (!Init) {
		Init = 1;
		Used = 0;
		max_strmem = D_MAX_STRMEMI;
		keys_len = D_MAX_STRMEMI*sizeof(tdtKey);
		keys = (tdtKey *)Malloc(keys_len);
		memset(keys,0,keys_len);
	}
	pk = keys;
	ii = 0;
	for (i=0;i<Used;i++,pk++) {
		if (!strncmp(pk->key,key,D_MAX_STRMEM_KEYL-1)) {
			ii = i + 1;
			break;
		}
	}
/*
printf("strmemk: Used=%d ii=%d pk=%08x\n",Used,ii,pk);
*/
	if (ii) {
		if (pk->memlen < len) {
			if (p = Realloc(pk->mem,len+1)) {
				pk->mem = p;
				pk->memlen = len;
			}
			else {
				p = wrk;
				if (len >= sizeof(wrk)) len--;
			}
		}
		else p = pk->mem;
	}
	else {
		if (Used >= max_strmem) {
			keys_len = sizeof(tdtKey)*(max_strmem+10);
			if (pk = (tdtKey *)Malloc(keys_len)) {
				Free(keys);
				memcpy(pk,keys,max_strmem*sizeof(tdtKey));
				memset(pk+max_strmem,0,sizeof(tdtKey)*10);
				keys = pk;
				max_strmem += 10;
/*
printf("strmemk: max_strmem=%d keys=%08x\n",max_strmem,keys);
*/
				return strmemk(s,len,key);
			}
			else {
				p = wrk;
				if (len >= sizeof(wrk)) len--;
			}
		}
		else {
			strnzcpy(pk->key,key,D_MAX_STRMEM_KEYL-1);
			if (p = Malloc(len+1)) {
				pk->mem = p;
				pk->memlen = len;
				Used++;
/*
printf("strmemk: Used=%d pk=%08x\n",Used,pk);
*/
			}
			else {
				p = wrk;
				if (len >= sizeof(wrk)) len--;
			}
		}
	}
	memzcpy(p,s,len);
	return p;
#else
	static int Init=0,Used=0,max_strmem=D_MAX_STRMEMI;
	static char keys[D_MAX_STRMEM_KEYL*D_MAX_STRMEMI],*p0=NULL;
	char *p,*p00;
	int i,ii,memlen,max_strmem0;
/*
printf("strmemk:Enter: s=%08x len=%d key=[%s]\n",s,len,key);
*/
	if (!(p = p0)) p = keys;
	ii = 0;
	for (i=0;i<Used;i++) {
		if (!strncmp(p,key,D_MAX_STRMEM_KEYL-1)) {
			ii = i + 1;
			break;
		}
		p += D_MAX_STRMEM_KEYL;
	}
/*
printf("strmemk: Used=%d ii=%d p=%08x\n",Used,ii,p);
*/
	if (!ii) {
		if (Used < max_strmem) {
			strnzcpy(p,key,D_MAX_STRMEM_KEYL-1);
			ii = ++Used;
		}
		else {
			p00 = p0;
			max_strmem0 = max_strmem;
			max_strmem = D_MAX_STRMEM_KEYL*(Used+10);
			memlen = akxmemwork(max_strmem,&p,&p0,keys,D_MAX_STRMEM_KEYL*D_MAX_STRMEMI);
/*
printf("strmemk: memlen=%d max_strmem=%d p=%08x p0=%08x\n",memlen,max_strmem,p,p0);
*/
			if (memlen == max_strmem) {
				if (!p00) memcpy(p0,keys,D_MAX_STRMEM_KEYL*D_MAX_STRMEMI);
				return strmemk(s,len,key);
			}
			else {
				max_strmem = max_strmem0;
				ii = 0;
			}
		}
	}
	p = strmemi(s,len,ii);
	return p;
#endif
#endif
}

/****************************************/
/*										*/
/****************************************/
char *strmem(s,len,key)
char *s,*key;
int  len;
{
#if 1
	return strmemk(s,len,"strmem");
/*	return strmemi(s,len,0);	*/
#else
	static char wrk[D_STRMEMI_SIZE],*p0=NULL;
	char *p;

	if ((len=akxmemwork(len,&p,&p0,wrk,sizeof(wrk))) >= 0) {
		if (s) memzcpy(p,s,len);
	}
	else {
		p = wrk;
		if (s) memnzcpy(p,s,len,sizeof(wrk));
	/*}*/
	return p;
#endif
}
