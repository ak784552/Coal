static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testdatebas.c libakx_no_iconv.a -o testdatebas
*/
#include "akxcommon.h"
int main()
{
	char ymd[64];
	int ymda[6],ymda2[6],ret,i;
	char dlma[4];
	int hmsa[3],nymd,nymda[11];
	char *kymda[11],*mymda[11],*ymdhns,*ymd_form,buf[128];

	akxt_set_code_type(CD_TYPE_SJIS);

	strcpy(ymd,"2022/08/02 21:18:00");
	ret = axConvDate(ymd,ymda,6,dlma,3);
	printf("ret=%d ymd=[%s] dlma=[%s]\n",ret,ymd,dlma);
	for (i=0;i<6;i++) printf("ymda[%d]=%d\n",i,ymda[i]);
	mem_cpy_int(ymda2,ymda,6);
	printf("axDateToChar=[%s]\n",axDateToChar(buf,sizeof(buf),ymda,6,"/:"));
	printf("axAddToDate(H,5)=%d\n",axAddToDate(ymda,6,"H",5,NULL));
	printf("axDateToChar=[%s]\n",axDateToChar(buf,sizeof(buf),ymda,6,"/:"));
	printf("axSetDatePart(MI,65)=%d\n",axSetDatePart(ymda2,6,"MI",65,NULL));
	printf("axDateToChar=[%s]\n",axDateToChar(buf,sizeof(buf),ymda2,6,"/:"));
	printf("axDateDiff(MI)=%f\n",axDateDiff("MI",ymda,ymda2));

	ymd_form = "����yyyy�Nmm��dd�� hh��mi��ss�b";
	nymd = anal_date_format(ymd_form,10,nymda,kymda,mymda,buf,sizeof(buf));
	printf("nymd=%d\n",nymd);
	for (i=0;i<=nymd;i++) {
		printf("i=%d nymda=%d kymda=[%s] mymda=[%s]\n",i,nymda[i],kymda[i],mymda[i]);
	}

	ymdhns = "����2022�N8��5�� 0��1��32�b";
	printf("axToDate()=%d\n",axToDate(ymda,ymdhns,ymd_form));
	for (i=0;i<6;i++) printf("ymda[%d]=%d\n",i,ymda[i]);

	printf("axDateTimeToChar()=[%s]\n",axDateTimeToChar(buf,sizeof(buf),ymda,ymd_form));

	return 0;
}
