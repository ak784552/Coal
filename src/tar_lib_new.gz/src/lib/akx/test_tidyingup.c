static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_tidyingup.c libakx_no_u8src.a -o test_tidyingup
*/
#include "akxcommon.h"
int main()
{
	char buf[256];
	int ret;

	for (;;) {
		printf("Enter number==>");
		gets(buf);
		if (!stricmp(buf,"/EOF")) break;
		ret = akxtidyngup(buf,strlen(buf));
		printf("ret=%d buf=[%s]\n",ret,buf);
	}
	exit(0);
}
