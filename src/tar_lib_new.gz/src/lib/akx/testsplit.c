static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testsplit.c libakx_no_iconv.a -o testsplit
*/
#include "akxcommon.h"
#define MAXARGC	10
int main()
{
	char buf[256],parm[256],*argv[MAXARGC],*p,sep[33],msg[256],c;
	int i,n,opt,parmlen,maxargv,len;

/*	strcpy(sep,",");	*/
	strcpy(sep,"");
	opt=0;
	maxargv=10;
	strcpy(msg,"  |2|  ＸA  , 4 ' 5 '");
/*	strcpy(msg,"test_XML.cl  ''  test2.xml");	*/
/*	strcpy(msg,"HEBON|WIDE/PROPER");	*/
	printf("maxargv=%d\n",maxargv);
	printf("text=[%s]\n",msg);
	printf("sep=[%s]\n",sep);
	printf("opt=%08x\n",opt);

	for (;;) {
		printf("command (End/Maxargv/Option/Sep/Text/なし(実行) ==>");
		gets(buf);
		if ((c=toupper(*buf))=='E') break;
		else if (c=='M') {
			printf("maxargv ==>");
			gets(buf);
			maxargv = atoi(buf);
			if (maxargv < 0) maxargv = -maxargv;
			if (maxargv > MAXARGC) maxargv = MAXARGC;
		}
		else if (c=='S') {
			printf("sep==>");
			gets(buf);
			strcpy(sep,buf);
			printf("sep=[%s]\n",sep);
		}
		else if (c=='O') {
			printf("opt==>");
			gets(buf);
			n=akxcgcvn(buf,strlen(buf),&opt);
			printf("ret=%d opt=%08x\n",n,opt);
		}
		else if (c=='T') {
			printf("Text==>");
			gets(msg);
			printf("text=[%s]\n",msg);
		}
		else if (c=='\0') {
			len=strlen(msg);
			parmlen=len+maxargv+1;
			n=akxtnsplit(msg,len,argv,maxargv,parm,parmlen,sep,strlen(sep),opt);
			printf("n=%d\n",n);
			if (n >= 0) {
				n=X_MAX(n,maxargv);
				for (i=0;i<n;i++) {
					printf("i=%d argv=[%s]\n",i,argv[i]);
				}
			}
		}
	}
}
