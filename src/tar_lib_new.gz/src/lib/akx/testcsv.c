static    char    sccsid[]="@(#) testgetnapl.c 1.1 04/08/02 14:44:41";
/*
	cc -g -DAIX -I../include testcsv.c akxcom.a -o testcsv
*/
#include "akxcommon.h"
main()
{
	char buf[256],parm[256],*argv[10];
	int i,n,opt,parmlen,argl[10];

	for (;;) {
		printf("Enter==>");
		gets(buf);
		n=akxtcsvgavl(buf,strlen(buf),argv,argl,10,parm,256);
		printf("n=%d\n",n);
		if (n >= 0) {
			for (i=0;i<n;i++) {
				printf("i=%d argv=[%s] argl=%d\n",i,argv[i],argl[i]);
			}
		}
	}
}
