/*
	cc -finput-charset=CP932 test_kanji.c
*/
#include <stdio.h>
main ()
{
	printf("[%s]\n","���");
}
