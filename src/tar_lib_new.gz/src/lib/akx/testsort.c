static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testsort.c libakx_no_iconv.a -o testsort
*/
#include <akxcommon.h>
int main()
{
	static MCAT2 *mcat;
	static char *jisho_hebon[] =
	{"cd      ","action  ","flg     ","data    ","level   "
	,"file    ","partner ","vendor  ","test    ","order   "};
	static int lena[] = {8,2,4,9,1,0,3,6,5,7};
	int n,i;
	char cmd[20],*p;
	char buf[128];
	int  rc,klen;
	char key[128],c;
	HASHB *pha;

	mcat = akxs_mseq_new(sizeof(int)*2,100,NULL,NULL);
	printf("max=%d\n",mcat->mc_ipos);
	for (i=0;i<10;i++) akxs_mseq_s(mcat,jisho_hebon[i]);
	p = mcat->mc_bufp;
	for (i=0;i<10;i++,p+=8) {
		memzcpy(buf,p,8);
		printf("i=%d buf=[%s]\n",i,buf);
	}
	p = mcat->mc_bufp;
	akxnmstrsort_opt(p,10,8,0);
	for (i=0;i<10;i++,p+=8) {
		memzcpy(buf,p,8);
		printf("i=%d buf=[%s]\n",i,buf);
	}
	p = mcat->mc_bufp;
	akxnmstrsort_opt(p,10,8,1);
	for (i=0;i<10;i++,p+=8) {
		memzcpy(buf,p,8);
		printf("i=%d buf=[%s]\n",i,buf);
	}
	akxnmstrsort_opt(lena,10,4,1);
	for (i=0;i<10;i++,p+=8) {
		printf("i=%d lena=%d\n",i,lena[i]);
	}
	exit(0);
}
