static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************/
/*											*/
/*	  coded by A.Kobayashi 2010.05.10		*/
/*											*/
/********************************************/
#include "akxcommon.h"

static char *gsep=" \t,;()[]{}<>='\"!^*/";

/********1*********2*********3*********4*********5***/
/*	len   : <0 : Free & Init						*/
/*			pp0=NULL or *pp0=NULL : Free���Ȃ�		*/
/*	pp1   : �������̃|�C���^��Ԃ��A�h���X			*/
/*			=NULL : �G���[							*/
/*	pp0   : �m�ۂ����������̃|�C���^��Ԃ��A�h���X	*/
/*			������g����Realloc����					*/
/*			pp0=NULL : Malloc�̂�					*/
/*	work  : len<w_len�̂Ƃ��Awork���g���A�������A	*/
/*			pp0<>NULL,*pp0<>NULL�̂Ƃ��́AMRealloc	*/
/*			work=NULL or w_len<=0 �̂Ƃ��́A		*/
/*			MRealloc�̂�							*/
/*	w_len : work�̃o�C�g��							*/
/****************************************************/
int akxmemwork(len,pp1,pp0,work,w_len)
int  len;
char **pp0,**pp1,*work;
int  w_len;
{
	char *p,*mem,*p0;
	int im;

#if 1	/* 2025.12.15 */
	if (!pp1) return -1;
	if (len < 0) {
		if (pp0) {
			if (p0 = *pp0) Free(p0);
			*pp0 = NULL;
		}
		*pp1 = NULL;
		return 0;
	}
#else
	if (!pp1 || len<0) return -1;
#endif
	im = 1;
	mem = work;
#if 1	/* 2025.12.15 */
	if (work && w_len>0) {
		if (len < w_len) {
			im = 0;
			if (pp0) {
				if (*pp0) im = 1;
			}
		}
	}
#else
	if (work && len<w_len) im = 0;
#endif
	if (im) {
		if (pp0) {
			p0 = *pp0;
			if (p = MRealloc(p0,len+1)) {
				mem = *pp0 = p;
			}
		}
		else p = NULL;
		if (!p) {
			if (work) len = w_len - 1;
			else len = -1;
		}
	}
#if 1	/* 2025.12.15 */
	else if (len >= w_len) {
		mem = NULL;
		len = -1;
	}
#endif
	*pp1 = mem;

	return len;
}

/****************************************/
/*										*/
/****************************************/
#define D_STRMEMI_SIZE	128
#define D_MAX_STRMEMI	20
#define D_MAX_STRMEM_KEYL	36	/* �I�[ null���܂� */

char *strmemi(s,len,i)
char *s;
int  len,i;
{
	static int Init=0;
	static char wrk[D_STRMEMI_SIZE*D_MAX_STRMEMI];
	static char *p1[D_MAX_STRMEMI];
	char *p;

	if (!Init) {
		Init = 1;
		mem_set_addr(p1,NULL,D_MAX_STRMEMI);
	}
	if (i < 0) i = 0;
	else if (i >= D_MAX_STRMEMI) i = D_MAX_STRMEMI - 1;
	if ((len=akxmemwork(len,&p,&p1[i],wrk+D_STRMEMI_SIZE*i,D_STRMEMI_SIZE)) >= 0) {
		memzcpy(p,s,len);
	}
	return p;
}
/****************************************/
/*										*/
/****************************************/
char *strmemk(s,len,key)
char *s,*key;
int  len;
{
#if 0	/* 2024.9.16 */
	static int Init=0;
	static XHASHB *xha;
	static char wrk[256];
	long ih;
	int opt;
	char *p;
/*
printf("strmemk:Enter: s=%08x len=%d key=[%s]\n",s,len,key);
*/
	if (!Init) {
		Init = 1;
		opt = AKX_HASX_OPT_USE_MALLOC | AKX_HASX_OPT_NO_DAT_CP;
		xha = akxs_xhashm_new2(0,D_MAX_STRMEMI,0,0,opt,NULL,NULL);
/*
printf("strmemk: xha=%08x\n",xha);
if (xha) printf("strmemk: maxreg=%d prereg=%d option=%08x\n",xha->xha_maxreg,xha->xha_prereg,xha->xha_option);
*/
	}
	p = NULL;
	ih = -1;
	if (xha) {
		if ((ih=akxs_xhash2(xha,'S',key,&len)) > 0) {
			ih = akxs_xhash2(xha,'R',key,&p);
		}
	}
	if (p) memzcpy(p,s,len);
	else {
		p = wrk;
		strnzcpy(p,s,sizeof(wrk)-1);
	}
/*
printf("strmemk:Exit ih=%d p=%08x [%s]\n",ih,p,p);
*/
	return p;
#else
	static int Init=0,Used=0;
	static char keys[D_MAX_STRMEM_KEYL*D_MAX_STRMEMI];
	char *p;
	int i,ii;
/*
printf("strmemk:Enter: s=%08x len=%d key=[%s]\n",s,len,key);
*/
	p = keys;
	ii = 0;
	for (i=0;i<Used;i++) {
		if (!strncmp(p,key,D_MAX_STRMEM_KEYL-1)) {
			ii = i + 1;
			break;
		}
		p += D_MAX_STRMEM_KEYL;
	}
/*
printf("strmemk: Used=%d ii=%d p=%08x\n",Used,ii,p);
*/
	if (!ii) {
		if (Used < D_MAX_STRMEMI) {
			strnzcpy(p,key,D_MAX_STRMEM_KEYL-1);
			ii = ++Used;
		}
		else {
			ii = 0;
		}
	}
	p = strmemi(s,len,ii);
/*
printf("strmemk: s=%08x len=%d key=[%s] Used=%d ii=%d p=%08x\n",s,len,key,Used,ii,p);
*/
/*
printf("strmemk: Used=%d ii=%d p=%08x\n",Used,ii,p);
printf("strmemk: p=[%s]\n",p);
*/
	return p;
#endif
}

/****************************************/
/*										*/
/****************************************/
char *strmem(s,len)
char *s;
int  len;
{
#if 1
	return strmemk(s,len,"strmem");
/*	return strmemi(s,len,0);	*/
#else
	static char wrk[D_STRMEMI_SIZE],*p0=NULL;
	char *p;

	if ((len=akxmemwork(len,&p,&p0,wrk,sizeof(wrk))) >= 0) {
		if (s) memzcpy(p,s,len);
	}
	else {
		p = wrk;
		if (s) memnzcpy(p,s,len,sizeof(wrk));
	}
	return p;
#endif
}

/****************************************/
/*										*/
/****************************************/
char *memaddv0(argc,argv,argl,pp0)
int   argc;
char *argv[];
int   argl[];
char **pp0;
{
	char *p,*p0,*pp,*pM;
	int  alen,blen;
	int i,len,same;

	if (!pp0) return NULL;
/*
printf("memadd0: alen=%d a=[%s] blen=%d b=[%s]\n",alen,a,blen,b);
*/
	p0 = *pp0;
	len = 1;
	same = 0;
	for (i=0;i<argc;i++) {
		len += argl[i];
		if (!argv[i]) same = 1;
	}
	if (!p0 || same) {
		if (!(pM=Malloc(len))) return NULL;
	}
	else {
		if (!(pM=Realloc(p0,len))) return NULL;
		p0 = NULL;
	}
	pp = pM;
	for (i=0;i<argc;i++) {
		if (p=argv[i]) {
			memcpy(pp,p,len=argl[i]);
			pp += len;
		}
	}
	*pp = '\0';
	if (p0) Free(p0);
/*
printf("memaddv0:%s\n",p);
*/
	*pp0 = pM;
	return pM;
}

/****************************************/
/*										*/
/****************************************/
char *memaddv(argc,argv,argl)
int   argc;
char *argv[];
int   argl[];
{
	static char *p0=NULL;

	return memaddv0(argc,argv,argl,&p0);
}
/****************************************/
/*										*/
/****************************************/
char *memadd0(a,alen,b,blen,pp0)
char *a,*b,**pp0;
int  alen,blen;
{
	char *argv[2];
	int   argl[2];

	argv[0] = a;
	argv[1] = b;
	argl[0] = alen;
	argl[1] = blen;
	return memaddv0(2,argv,argl,pp0);
}
/****************************************/
/*										*/
/****************************************/
char *memadd(a,alen,b,blen)
char *a,*b;
int  alen,blen;
{
	static char *p0=NULL;

	return memadd0(a,alen,b,blen,&p0);
}

/****************************************/
/*										*/
/****************************************/
char *straddv(argc,argv)
int   argc;
char *argv[];
{
	static int *argl=NULL;
	int i;
	char *p;

	if (argc<=0 || !argv) return NULL;
	if (!(argl=(int *)MRealloc(argl,argc*sizeof(int)))) return NULL;
	memset(argl,0,argc*sizeof(int));
	for (i=0;i<argc;i++) {
		if (p=argv[i]) argl[i] = strlen(p);
	}
	return memaddv(argc,argv,argl);
}

/****************************************/
/*										*/
/****************************************/
char *stradd5(a,b,c,d,e)
char *a,*b,*c,*d,*e;
{
	char *argv[5];

	argv[0] = a;
	argv[1] = b;
	argv[2] = c;
	argv[3] = d;
	argv[4] = e;
	return straddv(5,argv);
}

/****************************************/
/*										*/
/****************************************/
char *stradd(a,b)
char *a,*b;
{
	if (!a) return b;
	if (!*a) return b;
	if (!b) return a;
	if (!*b) return a;
	return stradd5(a,b,NULL,NULL,NULL);
}

/****************************************/
/*										*/
/****************************************/
int akxstrnlen(s,len)
char *s;
int len;
{
	int i;
	char *p=s;

	for (i=0;i<len;i++) if (!*p++) break;

	return i;
}

/****************************************/
/*										*/
/****************************************/
char akxcupper(cc)
char cc;
{
	char c;

	if ((c=cc)>='a' && c<='z') c &= ~0x20;
	return c;
}

/****************************************/
/*										*/
/****************************************/
int akxqupper(cc)
char cc;
{
	char c;
	int ret;

	if ((c=cc)>='A' && c<='Z') ret = 1;
	else ret = 0;
	return ret;
}
#if 1	/* 2025.7.7 */
/********************************************************/
/*														*/
/********************************************************/
static int _in_mem_char(target,ltar,str,lstr,ma,opt)
char *target,*str;
int  ltar,lstr,ma[],opt;
{
	char *pt,*ps,u2[5],u1[5],*ptp;
	int  i,opt01,rc,ret,bstr,len,opt_type,code_type,byt1;

	if ((pt=target) && (ps=str)) {
		if (!ltar || !lstr) return 0;
/*
printf("_in_mem_char:Enter ltar=%d lstr=%d opt=%08x\n",ltar,lstr,opt);
printf("_in_mem_char: pt=[%s]\n",pt);
printf("              ps=[%s]\n",ps);
*/
		opt01 = opt & 0x01;	/* ignore case */
		opt_type = opt & CD_TYPE_OPT_MASK;
		code_type = GET_TYPE_OPT(opt);
		bstr = akxqmbsnlen(code_type,ps,lstr);
		if (ma) ma[0] = bstr;
		if (opt01) {
			akxcuppern(u2,ps,bstr);
			ps = u2;
		}
/*
printf("_in_mem_char: bstr=%d\n",bstr);
*/
		rc = 0;
		len = ltar;
		i = 1;
		while (len >= bstr) {
			ptp = pt;
			byt1 = akxqmbsnlen(code_type,ptp,len);
/*
printf("_in_mem_char: byt1=%d\n",byt1);
*/
			if (opt01) {
				akxcuppern(u1,ptp,byt1);
				ptp = u1;
/*
printf("_in_mem_char:upper ptp=[%s]\n",ptp);
*/
			}
			ret = akxmemcmplen(ptp,byt1,ps,bstr,0);
/*
printf("_in_mem_char: akxmemcmplen ret=%d\n",ret);
*/
			if (!ret) {
				rc = i;
				break;
			}
			len -= byt1;
			i  += byt1;
			pt += byt1;
		}
	}
	else rc = -1;
/*
printf("_in_mem_char:Exit rc=%d\n",rc);
*/
	return rc;
}
#endif
/****************************************************************************/
/* ���� : akxtgwnsl															*/
/* �@�\ : �����񂩂�w�肳�ꂽ��؂蕶���ŋ�؂��ă��[�h�����o��    		*/
/*        �X�y�[�X�ƃ^�u�ȊO�̋�؂蕶�����I�v�V�����ɂ����o��    		*/
/*         --------------+----------------------*--------------------- 		*/
/*          " "�̈���    | opt & 0x200=0        | opt & 0x200<>0       		*/
/*         --------------+----------------------*--------------------- 		*/
/*          sep�� " ���� | "x" �����[�h�Ƃ���   | " �����[�h�Ƃ���     		*/
/*          sep�T�[�`��  | " �͋�؂�           | " �͋�؂�           		*/
/*         --------------+----------------------*--------------------- 		*/
/*          sep�� " �Ȃ� | "x" �����[�h�Ƃ��Ȃ� | " �����[�h�Ƃ��Ȃ�   		*/
/*          sep�T�[�`��  | "x" ���΂�         | " "���`�F�b�N���Ȃ�  		*/
/*         --------------+----------------------*--------------------- 		*/
/* ���� : buf	: ������ւ̃|�C���^�B										*/
/*				  �I�[�́ANULL�A'\n'�܂���'\r'���A�����񒷂܂�				*/
/*				  �I�v�V�����ɂ��A'\'�̌��͋�؂蕶���̑ΏۂɂȂ�Ȃ�	*/
/*		  len	: �����񒷁i�o�C�g�j�B										*/
/*		  sspl	: ���[�h���o���\���̂ւ̃|�C���^							*/
/*				  sp: �T�[�`�J�n�ʒu�A�擪�͂O�o�C�g�ځB					*/
/*				  wd: ���[�h�i�[�G���A�ւ̃|�C���^�B���[�h���i�[����		*/
/*					  �I�v�V�����ł��ANULL�̂Ƃ��́A�i�[���Ȃ��B			*/
/*				  wdmax: > 0 : ���[�h�i�[�ő咷(�o�C�g)						*/
/*						 = 0 : d�Ƀ��[�h�̐擪�A�h���X��Ԃ�				*/
/*						 < 0 : �������`�F�b�N�����Ɋi�[����					*/
/*				  attr[0]:���[�h���										*/
/*							=1 : ������ or ������							*/
/*							=5 : 'xxxx'										*/
/*							=6 : "xxxx"										*/
/*							=0x80 or asc : ��؂蕶��						*/
/*									 asc:��؂蕶���̔��p�R�[�h				*/
/*										 ���p�łȂ��Ƃ��́A0x7F				*/
/*				  attr[1]:�Q�o�C�g�����L��t���O�B1/0=����^�Ȃ�			*/
/*				  attr[2]:�s���S�k�Q�d�l���p���̂Ƃ��A0x01					*/
/*						  ���[�h�i�[���ɃI�[�o�[�t���[������A0x02��OR����	*/
/*				  attr[3]:[�Q�d]���p�����ɘA������[�Q�d]���p������̂Ƃ��A1 */
/*				  code: �����R�[�h = 0 : �V�X�e���̕����R�[�h				*/
/*		  sep	: ��؂蕶����BNULL�̂Ƃ��́Agsep���g����				*/
/*		  opt	: �I�v�V����												*/
/* 0x01 = 0/1 : ��s�X�y�[�X�ƃ^�u���X�L�b�v���Ȃ� / �X�L�b�v����			*/
/* 0x02 = 0/1 : �Q�d���p���A���p�����͂����Ȃ�(�s���S�G���[����) / �͂���	*/
/* 0x04 = 0/1 : �Q�d���p���A���p���̒��̘A������Q�̂������P�ɂ��Ȃ�	*/
/*              / �P�ɂ���												*/
/* 0x08 = 0/1 : �Q�d���p���A���p���̏��������� / ���������Ȃ�				*/
/* 0x10 = 0/1 : ��؂蕶���ȊO�������܂ŃX�L�b�v���Ȃ� / ��L����������	*/
/* 0x20 = 0/1 : ���g�p�Bsspl->wdmax���g�p����								*/
/*      wdmax= 0:ssp->wd�Ƀ��[�h���i�[�����A���[�h�̐擪�A�h���X������	*/
/*      wdmax<>0:ssp->wd�Ƀ��[�h���i�[���� (wdmax<0:�������`�F�b�N���Ȃ�)	*/
/* 0x40 = 0/1 : '\n'�܂���'\r'���I�[�Ƃ��� / �I�[�Ƃ��Ȃ�					*/
/*				(=1 �́A���p�����̂Ƃ��̂ݗL��)								*/
/* 0x80  = 1 : '\'���G�X�P�[�v�����Ƃ���B���p���̒��ȊO��'\'�͍폜����B	*/
/* 0x100 = 1 : ���p���̏��������Ȃ�											*/
/* 0x200 = 1 : �Q�d���p���̏��������Ȃ�										*/
/* 0x400 = 1 : ��؂蕶�������p�̏ꍇ�A�啶������������ʂ��Ȃ��B			*/
/* 0x800 = 1 : '`'�����p���Ƃ���											*/
/* 0x1000 = 1 : ���p���Ŏn�܂�Ȃ����[�h���̈��p������؂�Ƃ��Ȃ�			*/
/* �ԋp : >=0 and attr[0]<>0 : ���[�h����									*/
/*		   =0 and attr[0]==0 �܂���											*/
/*		  < 0 : �I�[ (sspl->sp>=len �̂Ƃ��A								*/
/*					  sspl->sp>len �̂Ƃ��́Asspl->sp=len �ƂȂ�)			*/
/****************************************************************************/
int akxtgwnsl(buf, len, sspl, sep, opt)
char *buf, *sep;
SSPL_S *sspl;
int len, opt;
{
	static char *sepw=NULL;
	int	opt_0,opt_1,opt_2,opt_3,opt_4,opt_5,opt_6,opt_8,opt_9,opt_80,opt_400,opt_800;
	int i, l, pos, nsep, lmax, m,splen,in_opt,nsepw,ma[2];
	char *s, ch, *w, quat, *psep, cs, sep_buf[64];
	uchar pattr[4],code_type;

	if (!buf || !sspl) return -2;
	if (!sep) sep = gsep;

	if (sspl->sp < 0) sspl->sp = 0;
	pos = sspl->sp;
/*
printf("akxtgwnsl:Enter len=%d pos=%d buf=[%s]\n",len,pos,strmem(buf,len));
*/
	w = sspl->wd;
	lmax = sspl->wdmax;
	pattr[1] = 0;
	sspl->attr[0] = 0;
	sspl->attr[1] = 0;
	sspl->attr[2] = 0;
	sspl->attr[3] = 0;
	opt_2 = opt & 0x04;
	if (lmax && w) opt_5 = 1;
	else {
		opt_2 = 0;
		opt_5 = 0;
	}
	if (opt_5) *w = '\0';
	else sspl->wd = "";

#if 0	/* 2024.9.9 */
	if (pos >= len) {
		if (pos > len) sspl->sp = len;
		return -1;
#else
	if (pos > len) {
/*
printf("akxtgwnsl:Exit2 pos=%d w=[%s]\n",pos,sspl->wd);
*/
		return -1;
	}
	else if (pos == len) {
		sspl->sp++;
/*
printf("akxtgwnsl:Exit1 pos=%d w=[%s]\n",sspl->sp,sspl->wd);
*/
		return 0;
#endif
	}

	nsep = strlen(sep);
	s = buf + pos;
	pattr[1] = 0;
	opt_0 = opt & 0x01;
	opt_1 = opt & 0x02;
	opt_3 = !(opt & 0x08);
	opt_4 = opt & 0x10;
	opt_6 = !(opt & 0x40);
	opt_8 = !(opt & (0x100 | 0x08));
	opt_9 = !(opt & (0x200 | 0x08));
	opt_80 = opt & 0x80;
	if (opt_400 = opt & 0x400) in_opt = 1;
	else in_opt = 0;
	opt_800 = opt & 0x800;
	if (opt & 0x08) opt_800 = 0;
	l = 0;

	if ((code_type=sspl->code) == CD_TYPE_SYSTEM) code_type = akxt_get_code_type();
	in_opt |= SET_TYPE_OPT(code_type);
/*
printf("akxtgwnsl: code_type=%d\n",code_type);
*/
	/* ��؂蕶���ȊO�������܂ŃX�L�b�v���� */
	if (opt_4) {
#if 1	/* 2021.4.20 */
		while((pos<len)&&((ch=*s)!='\0')) {
			if (opt_6 && ((ch=='\n')||(ch=='\r'))) break;
#if 1	/* 2025.7.7 */
			i = _in_mem_char(sep,nsep,s,len-pos,ma,in_opt);
			m = ma[0];
			if (i <= 0) {
#else
			m = akxqmbsnlen(code_type,s,len-pos);
			if (akxs_in_mem_opt(sep,nsep,s,m,in_opt) <= 0) {
#endif
				l = m;
				break;
			}
			s += m;
			pos += m;
		}
/*
printf("akxtgwnsl:opt_4: pos=%d l=%d\n",pos,l);
*/
#else
		while((pos<len)&&((ch=*s++)!='\0')) {
			if (opt_6 && ((ch=='\n')||(ch=='\r'))) break;
			for (i=0,psep=sep;i<nsep;i++) {
				cs = *psep++;
				if (opt_400) {
					ch = akxcupper(ch);
					cs = akxcupper(cs);
				}
				if (ch == cs) break;
			}
			if (i>=nsep) {
				l = 1;
				break;
			}
			pos++;
		}
#endif
		if (!ch) pos = len;	/* add 2023.3.4 NULL���������ꂽ��len�ɒB�������Ƃɂ��� */
		sspl->sp = pos;
		if (opt_5) *w = '\0';
		else sspl->wd = s;
/*
printf("akxtgwnsl:Exit3 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
		return l;
	}
	/* ��s�X�y�[�X�ƃ^�u���X�L�b�v���� */
	if (opt_0) {
#if 1	/* 2020.3.9 */
		while (pos<len && (ch=*s)) {
			if ((m=akxqmbsnlen(code_type,s,len-pos)) > 1) break;
			else if ((ch=*s)=='\\' && opt_80) {
				pos++;
				s++;
				if (pos < len) {
					if (!(m=akxqmbsnlen(code_type,s,len-pos))) m = 1;
					pos += m;
					s += m;
				}
			}
			else if (((ch=*s)==' ')||(ch=='\t')||
			         (!opt_6 && ((ch=='\n')||(ch=='\r')))) {
				pos++;
				s++;
			}
			else break;
#else
		while((pos<len)&&(((ch=*s)==' ')||(ch=='\t')||
		                  (!opt_6 && ((ch=='\n')||(ch=='\r'))))) {
			pos++;
			s++;
#endif
/*
printf("akxtgwnsl:1 pos=%d c=[%c]\n",pos,*s);
*/
		}
/*
printf("akxtgwnsl:2 pos=%d c=[%c]\n",pos,*s);
*/
		if (!ch) pos = len;	/* add 2023.3.4 NULL���������ꂽ��len�ɒB�������Ƃɂ��� */
		if (pos >= len) {
			sspl->sp = pos;
			if (opt_5) *w = '\0';
			else sspl->wd = s;
/*
printf("akxtgwnsl:Exit4 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
			return 0;
		}
	}
#if 1	/* 2025.7.29 */
	sepw = sep;
	nsepw = nsep;
	if (opt & 0x1000) {
		if (nsep < sizeof(sep_buf)) sepw = sep_buf;
		else sepw = MRealloc(sepw,nsep+1);
		if (sepw) {
			nsepw = 0;
			for (i=0;i<nsep;i++) {
				if ((ch=sep[i])=='\'' || ch=='"') ;
				else sepw[nsepw++] = ch;
			}
			sepw[nsepw] = '\0';
		}
		else {
			sepw = sep;
			nsepw = nsep;
		}
	}
#endif
	if (!opt_5) sspl->wd = s;
	ch = *s;
#if 1	/* 2023.3.4 */
	if (!ch) {
		pos = len;	/* add 2023.3.4 NULL���������ꂽ��len�ɒB�������Ƃɂ��� */
		sspl->sp = pos;
		if (opt_5) *w = '\0';
		return 0;
	}
#endif
	l = 0;
	m = akxqmbsnlen(code_type,s,len-pos);
/*	if (opt_3 && (pos<len) && (ch=='"' || ch=='\'')) {	*/
#if 1	/* 2020.3.9 */
  if (m == 1) {
	if (pos<len && ch=='\\' && opt_80) {	/* �G�X�P�[�v�����̏��� */
/*
printf("akxtgwnsl:4 pos=%d ch=[%c]\n",pos,ch);
*/
		pos++;
		s++;
		if (pos < len) {
#if 1
			if (!(m=akxqismbs(code_type,s))) m = 1;
			l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
			pos += m;
			s += m;
#else
			ch = *s;
			l = akxwdmax_chk(&w,pattr,lmax,l,ch);
			pos++;
			s++;
#endif
			ch = *s;
		}
	}
	else
#endif
	if ((pos<len) && ((ch=='"' && opt_9) || (ch=='\'' && opt_8) || (ch=='`' && opt_800))) {	/* ���p������ */
/*
printf("akxtgwnsl:5 pos=%d c=[%c]\n",pos,ch);
*/
		if (opt_1 && !opt_5) sspl->wd++;
		if (ch=='"') sspl->attr[0] = 6;
		else if (ch=='\'') sspl->attr[0] = 5;
		else if (ch=='`') sspl->attr[0] = 7;
		quat=ch;
		pos++;
		s++;
		if (!opt_1) {
			l = akxwdmax_chk(&w,pattr,lmax,l,ch);
		}
		while((pos<len)&&((ch=*s)!='\0')) {
/*
printf("akxtgwnsl:3 pos=%d c=[%c]\n",pos,ch);
*/
			if (opt_6 && ((ch=='\n')||(ch=='\r'))) break;
			if (m=akxqismbs(code_type,s)) {
				l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
				pos += m;
				s += m;
				sspl->attr[1] = 1;
			}
#if 1	/* 2020.3.9 */
			else if (ch=='\\' && opt_80) {
/*
printf("akxtgwnsl:5 pos=%d ch=[%c]\n",pos,ch);
*/
#if 1	/* add 2020.10.10 */
				l = akxwdmax_chk(&w,pattr,lmax,l,ch);
#endif
				pos++;
				s++;
				ch = *s;
				if (pos < len) {
					if (!(m=akxqismbs(code_type,s))) m = 1;
					l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
					pos += m;
					s += m;
				}
			}
#endif
			else {
				pos++;
				s++;
				if (ch == quat) {
					if ((pos >= len) || (*s != quat)) {
						if (!opt_1) {
							l = akxwdmax_chk(&w,pattr,lmax,l,ch);
						}
						if (opt_5) *w = '\0';
						sspl->sp = pos;
						if (pattr[1]) sspl->attr[2] = 0x02;
/*
printf("akxtgwnsl:Exit5 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
						return l;
					}
					else {
						sspl->attr[3] = 1;
						if (!opt_2) {
							l = akxwdmax_chk(&w,pattr,lmax,l,ch);
						}
						l = akxwdmax_chk(&w,pattr,lmax,l,quat);
						pos++;
						s++;
					}
				}
				else {
					l = akxwdmax_chk(&w,pattr,lmax,l,ch);
				}
			}
		}
		if (opt_5) *w = '\0';
		sspl->sp = pos;
		if (!opt_1) sspl->attr[2] = 1;
		if (pattr[1]) sspl->attr[2] |= 0x02;
/*
printf("akxtgwnsl:Exit6 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
		return l;
	}
  }
	/* ��؂蕶���̏��� */
#if 1	/* 2021.4.20 */
#if 1	/* 2025.7.7 */
	if (_in_mem_char(sep,nsep,s,len-pos,ma,in_opt)>0
#else
	m = akxqmbsnlen(code_type,s,len-pos);
	if (akxs_in_mem_opt(sep,nsep,s,m,in_opt)>0
#endif
	    || (ch=='`' && opt_800)) {
		m = ma[0];
		l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
		if (opt_5) *w = '\0';
		pos += m;
		sspl->sp = pos;
		if (m > 1) ch = 0x7f;
		sspl->attr[0] = ch | 0x80;
		if (pattr[1]) sspl->attr[2] = 0x02;
/*
printf("akxtgwnsl:Exit7 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
		return l;
	}
#else
	for (i=0,psep=sep;i<nsep;i++) {
		cs = *psep++;
		if (opt_400) {
			ch = akxcupper(ch);
			cs = akxcupper(cs);
		}
		if (ch==cs) {
			l = akxwdmax_chk(&w,pattr,lmax,l,ch);
			if (opt_5) *w = '\0';
			pos++;
			sspl->sp = pos;
			sspl->attr[0] = ch | 0x80;
			if (pattr[1]) sspl->attr[2] = 0x02;
/*
printf("akxtgwnsl:Exit7 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
			return l;
		}
	}
#endif
	while ((pos<len)&&((ch=*s)!='\0')) {
/*
printf("akxtgwnsl: pos=%d ch=[%c]\n",pos,ch);
*/
		if (opt_6 && ((ch=='\n')||(ch=='\r'))) break;
#if 0	/* 2021.4.20 */
		if ((pos+1<len) && (m=akxqismbs(code_type,s))) {
			l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
			pos += m;
			s += m;
			sspl->attr[1] = 1;
		}
		else {
#endif
/*
m = akxqismbs1(code_type,*s);
printf("akxtgwnsl:5.5 m=%d\n",m);
*/
			if ((pos+1==len) && akxqismbs1(code_type,*s)) {
				pos++;
				break;
			}
			if ((pos<len) && ch=='\\' && opt_80) {
/*
printf("akxtgwnsl:6 pos=%d ch=[%c]\n",pos,ch);
*/
				pos++;
				s++;
#if 1	/* 2021.4.20 */
				m = akxqmbsnlen(code_type,s,len-pos);
				if (pos < len) {
					l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
					pos += m;
					s += m;
				}
#else
				ch = *s;
				if (pos < len) {
					l = akxwdmax_chk(&w,pattr,lmax,l,ch);
					pos++;
					s++;
				}
#endif
			}
			else {
				/* ��؂蕶���̏��� */
#if 1	/* 2021.4.20 */
#if 1	/* 2025.7.7 */
#if 1	/* 2025.7.29 */
				if (_in_mem_char(sepw,nsepw,s,len-pos,ma,in_opt)>0
#else
				if (_in_mem_char(sep,nsep,s,len-pos,ma,in_opt)>0
#endif
#else
				m = akxqmbsnlen(code_type,s,len-pos);
				if (akxs_in_mem_opt(sep,nsep,s,m,in_opt)>0
#endif
				    || (ch=='`' && opt_800)) {
#if 1
					break;
#else
					if (opt_5) *w = '\0';
					sspl->sp = pos;
					sspl->attr[0] = 1;
					if (pattr[1]) sspl->attr[2] = 0x02;
/*
printf("akxtgwnsl:Exit8 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
					return l;
#endif
				}
				m = ma[0];
/*
printf("akxtgwnsl:7 lmax=%d l=%d s=[%s] m=%d\n",lmax,l,s,m);
*/
				l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
/*
printf("akxtgwnsl:akxwdmax_chkm pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
				pos += m;
				s += m;
#else
				for (i=0,psep=sep;i<nsep;i++) {
					if (ch==*psep++) {
						if (opt_5) *w = '\0';
						sspl->sp = pos;
						sspl->attr[0] = 1;
						if (pattr[1]) sspl->attr[2] = 0x02;
/*
printf("akxtgwnsl:Exit8 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
						return l;
					}
				}
				l = akxwdmax_chk(&w,pattr,lmax,l,ch);
				pos++;
				s++;
#endif
			}
#if 0	/* 2021.4.20 */
		}
#endif
	}
	if (opt_5) *w = '\0';
	sspl->sp = pos;
	if (l>0) sspl->attr[0] = 1;
	if (pattr[1]) sspl->attr[2] = 0x02;
/*
printf("akxtgwnsl:Exit pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
	return l;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtgwns(buf, len, ssp, sep, opt)
char *buf, *sep;
SSP_S *ssp;
int len, opt;
{
	SSPL_S sspl;
	int ret;

	memcpy(&sspl,ssp,sizeof(SSP_S));
	if (opt & 0x20) sspl.wdmax = 0;
	else sspl.wdmax = -1;
	sspl.code = 0;
	ret = akxtgwnsl(buf,len,&sspl, sep, opt);
	memcpy(ssp,&sspl,sizeof(SSP_S));
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtgwse(buf, ssp, sep, opt)
char *buf, *sep;
SSP_S *ssp;
int opt;
{
	return akxtgwns(buf,INT_MAX,ssp,sep,opt);
}

/********************************************************/
/*														*/
/********************************************************/
int akxtgwsp(buf, ssp)
char *buf;
SSP_S *ssp;
{
	return akxtgwse(buf,ssp,gsep,0x01);
}

/********************************************************/
/*														*/
/********************************************************/
int akxtpknsl(s, slen, ssp, sep, opt)
char *s, *sep;
SSPL_S *ssp;
int slen, opt;
{
	int pos,len;

	if (!ssp) return -1;
	pos = ssp->sp;
	len = akxtgwnsl(s,slen,ssp,sep,opt);
	ssp->sp = pos;
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtpkns(s, slen, ssp, sep, opt)
char *s, *sep;
SSP_S *ssp;
int slen, opt;
{
	int pos,len;

	if (!ssp) return -1;
	pos = ssp->sp;
	len = akxtgwns(s,slen,ssp,sep,opt);
	ssp->sp = pos;
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int akxcctox(puc,len,pux)
uchar *puc,*pux;
int len;
{
	int sw,m,n;
	uchar *pucw,*puxw,uc;

	if (!(pucw=puc) || !(puxw=pux)) return -1;
	n = len;
	m=sw=0;
	while (n--) {
		uc = *pucw++;
 		if   ((uc>='0') && (uc<='9')) uc -= '0';
		else if ((uc>='A') && (uc<='F')) uc -= 'A' - 10;
		else if ((uc>='a') && (uc<='f')) uc -= 'a' - 10;
		else uc = 0;
		if (sw) {
			*puxw |= uc;
			sw=0;
			puxw++;
		}
		else {
			*puxw = uc<<4;
			sw=1;
			m++;
		}
	}
	return m;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtsrepc(s,cs,cd)
char *s,cs,cd;
{
	int n=0;
	char c;

	while (c=*s) {
		if (c == cs) {
			n++;
			*s = cd;
		}
		s++;
	}
	return n;
}

/********************************************************/
/*														*/
/********************************************************/
char *akxt_get_last_name(delm,path)
char *delm, *path;
{
	int len, i;
	char *name, *p;

	if (!path) return NULL;
	if (!delm) return path;
	if (!(*delm)) return path;

	len = strlen(name=path);
	i = akxnrskipto(name,len,delm);
	if (i >= 0) name += i;
	return name;
}

/********************************************************/
/*														*/
/********************************************************/
int akxcxtoc(s,len,d)
char *s, *d;
int len;
{
	int i;
	uchar ucH, ucL;

	for (i=0;i<len;i++) {
		ucH = *s >> 4 & 0x0F;
		ucL  = *s++ & 0x0F;
		if (ucH >= 10) *d++ = (ucH-10) + 'a';
		else *d++ = ucH + '0';
		if (ucL >= 10) *d++ = (ucL-10) + 'a';
		else *d++ = ucL + '0';
	}
	return len*2;
}

/********1*********2*********3*********4*********5*********6**********7**/
/* ���� : akxcxtocn														*/
/* �@�\ : �\�[�X�f�[�^���o�C�g�P�ʂ�16�i�\���ɕϊ�����B				*/
/*		  interval0<>0 �̂Ƃ��́A���̊Ԋu�ŃX�y�[�X������B���̂Ƃ��A */
/*		  �Ō�̃X�y�[�X�͏o�͂��Ȃ��B									*/
/* ���� : IN    s        : �\�[�X�f�[�^									*/
/*				len      : �\�[�X�f�[�^�̃o�C�g��						*/
/*				d        : �o�͈�										*/
/*				mlen     : �o�͈�̃o�C�g��(�I�[��null���܂�)			*/
/*				interval0: �X�y�[�X�o�͊Ԋu(�\�[�X�f�[�^�ł̃o�C�g��)	*/
/*							=0 : len�������							*/
/*							<0 : �o�͊Ԋu�����S�ă[���̂Ƃ��A'Z'���o��	*/
/* �ԋp : �ϊ��o�C�g��(�I�[��null���܂܂Ȃ�)							*/
/************************************************************************/
int akxcxtocn(s,len,d,mlen,interval0)
char *s, *d;
int len,mlen,interval0;
{
	int i,m,n,interval,interval1;
	char c,*p;

	n = 0;
	if ((interval1=interval0) < 0) interval1 = -interval1;
	interval = interval1;
	if (!interval) interval = len;
	if (interval > len) interval = len;
/*
printf("akxcxtocn:Enter: len=%d mlen=%d interval0=%d interva=%d\n",len,mlen,interval0,interval);
*/
	mlen--;
	while (len > 0) {
		if (mlen < 2) break;
		if (len < interval) interval = len;
		if (mlen/2 < interval) interval = mlen/2;
/*
printf("akxcxtocn: mlen=%d interval=%d\n",mlen,interval);
*/
		c = ' ';
		if (interval0<0 && interval==interval1) {
			c = '\0';
			p = s;
			for (i=0;i<interval;i++) c |= *p++;
		}
		if (!c && interval>1) {
		/*	*d = '0';
			*(d+1) = '*';
			m = 2;	*/
			*d = 'Z';
			m = 1;
		}
		else m = akxcxtoc(s,interval,d);
		len -= interval;
		s += interval;
		d += m;
		*d++ = ' ';
		m++;
		n += m;
		mlen -= m;
	}
	if (n>0 && *(d-1)==' ') {
		d--;
		n--;
	}
	*d = '\0';
	return n;
}

/********************************************************/
/*														*/
/********************************************************/
char *akxt_add_dir2(cpDir,cpFile,cppPath)
char *cpDir,*cpFile,**cppPath;
{
	char *cpPath;
	char *p;
	int len;

	if (!cpDir) return cpFile;
	if (!(*cpDir)) return cpFile;
	if (!cpFile || !*cpFile) return cpDir;
	if (*cpFile == '/') return cpFile;
	if (!cppPath) return NULL;

	cpPath = *cppPath;
	len = strlen(cpDir) + strlen(cpFile) + 2 + 8;
	if (cpPath) {
		if (!(cpPath=Realloc(cpPath,len))) return NULL;
	}
	else {
		if (!(cpPath=Malloc(len))) return NULL;
	}
	strcpy(cpPath,cpDir);
	p = cpPath + strlen(cpPath);
	if (*(p-1) != '/') *p++ = '/';
	strcpy(p,cpFile);
	*cppPath = cpPath;
	return cpPath;
}

/********************************************************/
/*														*/
/********************************************************/
int akxt_set_bits(ipBits,iMask,iSet)
int *ipBits,iMask,iSet;
{
	int b,m,i;

	b = *ipBits;
	m = iMask;
	if (i=iSet) {
		if (i < 0) b &= ~m;
		else if (i == 1) b |= m;
		else b = m;
		*ipBits = b;
	}
	return b & m;
}
/****************************************/
/*	Get General-Purpose Data			*/
/*		coded by A.Kobayashi 2003.11.19	*/
/****************************************/
int akxt_get_gep_data(klen,p,kpp,plalen)
int  klen;
char *p,**kpp;
int  *plalen;
{
	int  lalen;
	INT4 lklen;

	if (!p) return -1;
	if (klen>0) lalen=lklen=klen;
	else if (klen<0) {
		memcpy(&lklen,p,sizeof(INT4));
		if (lklen<0) return -2;
		p += sizeof(INT4);
		lalen=lklen+sizeof(INT4);
	}
	else {
		lklen=strlen(p);
		lalen=lklen+1;
	}
	if (kpp) *kpp = p;
	if (plalen) *plalen = lalen;
	return lklen;
}

/****************************************/
/*	Cmp General-Purpose Data			*/
/*	klen  : >0 : �Œ蒷					*/
/*			=0 : string					*/
/*			<0 : len+key				*/
/*	kp    : ��r��L�[�A�h���X			*/
/*	lklen : ��r��L�[��				*/
/*	p     : ��r���L�[�A�h���X			*/
/*			�`����klen�ɂ��			*/
/*	opt   : 0x01 : ignore case			*/
/*		coded by A.Kobayashi 2003.11.25	*/
/****************************************/
int akxt_cmp_gep_data_opt(klen,kp,lklen,p,opt)
int  klen,lklen,opt;
char *kp,*p;
{
	INT4 ldlen;
	int  s,iCASE;

	if (!kp || !p) return -256;
	iCASE = opt & 0x01;
	if (klen>0) {
		if (iCASE) s = akxmemicmp(kp,p,lklen);
		else s = memcmp(kp,p,lklen);
	}
	else {
		if (klen<0) {
			memcpy(&ldlen,p,sizeof(INT4));
			if (ldlen<0) return -257;
			if (!(s=ldlen-lklen)) {
				if (iCASE) s = akxmemicmp(kp,p,lklen);
				else s = memcmp(kp,p+sizeof(INT4),lklen);
			}
		}
		else {
			if (iCASE) s = akxstricmp(kp,p);
			else s = strcmp(kp,p);
		}
	}
	return s;
}

/********************************************/
/*											*/
/********************************************/
int akxt_cmp_gep_data(klen,kp,lklen,p)
int  klen,lklen;
char *kp,*p;
{
	return akxt_cmp_gep_data_opt(klen,kp,lklen,p,0);
}

/********************************************/
/*											*/
/********************************************/
tdtConvMsgHead *akxc_conv_msg_new(mesg)
tdtMessages mesg[];
{
	tdtConvMsgHead *p;

	if (p=(tdtConvMsgHead *)Malloc(sizeof(tdtConvMsgHead))) {
		p->cmh_try      = 1;
		p->cmh_langmax  = -1;
		p->cmh_no_max   = 0;
		p->cmh_messages = mesg;
		p->cmh_index    = NULL;
		p->cmh_xhp      = NULL;
		akxc_conv_msg(p,1,0);
	}
	return p;
}

/********************************************/
/*											*/
/********************************************/
char *akxc_conv_msg(cmh,no,lang)
tdtConvMsgHead *cmh;
int no,lang;
{
	tdtRbChain *xhp;
	tdtMessages *mesg,*me,**index;
	int  langmax,no_max,i,k,ix,reg_max;
	char *p;

	if (!cmh) return NULL;
	if (!(mesg=cmh->cmh_messages)) return NULL;
	me = &mesg[0];
	if (no <= 0) return (char *)me->mm_msg;

	xhp   = cmh->cmh_xhp;
	index = cmh->cmh_index;
	p = "";
	if (cmh->cmh_try && !xhp && !index) {
		cmh->cmh_try = 0;
		for (k=0;k<3;k++) {
			if (!me->mm_msg[k] || !*me->mm_msg[k]) break;
		}
		cmh->cmh_langmax = k - 1;
		no_max = k = 0;
		reg_max = me->mm_msgno;
		me++;
		for (;(i=me->mm_msgno)>=0;me++) {
			k++;
			if (i > no_max) no_max = i;
		}
		cmh->cmh_no_max = no_max;
/*
printf("akxc_conv_msg: langmax=%d msg_count=%d no_max=%d\n",cmh->cmh_langmax,k,no_max);
*/
		if (k > no_max/2) {
			if (index = (tdtMessages **)Malloc(sizeof(tdtMessages *)*no_max)) {
				memset(index,0,sizeof(tdtMessages *)*no_max);
				for (me=&mesg[1];(i=me->mm_msgno)>=0;me++) {
					index[i-1] = me;
				}
			}
		}
		if (!index && k>100) {
			if (reg_max <= 0) reg_max = k;
			if (xhp=akxs_xhasl_new(sizeof(int),reg_max,0,0)) {
				for (me=&mesg[1];(i=me->mm_msgno)>=0;me++) {
					if (akxs_xhasl(xhp,'S',i,&me) <= 0) {
						akxs_xhasl_free(xhp);
						xhp = NULL;
						break;
					}
				}
			}
		}
		cmh->cmh_xhp   = xhp;
		cmh->cmh_index = index;
/*
printf("akxc_conv_msg: xhp=%08x index=%08x\n",xhp,index);
*/
	}
	langmax = cmh->cmh_langmax;
	no_max  = cmh->cmh_no_max;
	ix = 0;
	if ((lang>=0 && lang<=langmax) && no<=no_max) {
		if (index) {
			if (me = index[no-1]) ix = no;
		}
		else if (xhp) {
			ix = akxs_xhasl(xhp,'R',no,&me);
		}
		else {
			for (me=&mesg[1];(i=me->mm_msgno)>=0;me++) {
				if (i == no) {
					ix = i;
					break;
				}
			}
		}
		if (ix > 0) {
			p = me->mm_msg[lang];
			if (!p || !*p) {
#if 1	/* 2025.12.27 */
				if (lang > 0) lang = 0;
				else lang = 1;
				for (k=lang;k<=langmax;k++) {
#else
				for (k=lang+1;k<=langmax;k++) {
#endif
					if ((p=me->mm_msg[k]) && *p) break;
				}
			}
		}
	}
/*
printf("akxc_conv_msg: no=%d ix=%d\n",no,ix);
*/
	return p;
}

/********************************************/
/*											*/
/********************************************/
int akx_get_gen_int_data(p)
tdtGeneralData *p;
{
	int len,i=0;
	short s;
	char *pd;

	if (p && (pd=p->gd_data)) {
		if (len == 4) memcpy(&i,pd,sizeof(INT4));
		else if ((len=p->gd_dlen) == 2) {
			memcpy(&s,pd,sizeof(short));
			i = s;
		}
		else i = *(uchar *)pd;
	}
	return i;
}

/********************************************/
/*											*/
/********************************************/
void printtx(msg,p,len)
char *msg,*p;
int len;
{
	int i;

	printf("%s:",msg);
	printf(" len=%d text=[",len);
	for (i=0;i<len;i++) printf("%c",*p++);
	printf("]\n");
}

#define _MEM_SET \
	if (a = a0) {\
		ret = n;\
		while (n-- > 0) *a++ = val;\
	}\
	else ret = -1;\
	return ret;

/********************************************/
/*											*/
/********************************************/
int mem_set_int(a0,val,n)
int *a0,n,val;
{
	int ret,*a;

	_MEM_SET
	return ret;
}

/********************************************/
/*											*/
/********************************************/
int mem_set_long(a0,val,n)
long *a0,val;
int n;
{
	int ret;
	long *a;

#if defined(_LP64)
	_MEM_SET
#else
	return mem_set_int(a0,val,n);
#endif
}

/********************************************/
/*											*/
/********************************************/
int mem_set_double(a0,val,n)
double *a0,val;
int n;
{
	int ret;
	double *a;

	_MEM_SET
	return ret;
}

/********************************************/
/*											*/
/********************************************/
int mem_set_addr(a0,val,n)
char *a0[],*val;
int n;
{
	int ret;
	char **a;

	_MEM_SET
}

#define _MEM_CPY \
	if (d = d0) {\
		ret = n;\
		if (n>0 && (s=s0)) {\
			while (n-- > 0) *d++ = *s++;\
		}\
	}\
	else ret = -1;\
	return ret;

/********************************************/
/*											*/
/********************************************/
int mem_cpy_int(d0,s0,n)
int *d0,*s0,n;
{
	int ret,*d,*s;

	_MEM_CPY
}

/********************************************/
/*											*/
/********************************************/
int mem_cpy_long(d0,s0,n)
long *d0,*s0;
int n;
{
	int ret;
	long *d,*s;

#if defined(_LP64)
	_MEM_CPY
#else
	return mem_cpy_int(d0,s0,n);
#endif
}

/********************************************/
/*											*/
/********************************************/
int mem_cpy_double(d0,s0,n)
double *d0,*s0;
int n;
{
	int ret;
	double *d,*s;

	_MEM_CPY
}

/********************************************/
/*											*/
/********************************************/
int mem_cpy_addr(d0,s0,n)
char *d0[],*s0[];
int n;
{
	int ret;
	char **d,**s;

	_MEM_CPY
}

#define _MEM_RCPY \
	if (!d0) ret = -1;\
	else {\
		ret = n;\
		if (n>0 && s0) {\
			d = d0 + n -1;\
			s = s0 + n -1;\
			while (n-- > 0) *d-- = *s--;\
		}\
	}\
	return ret;

/********************************************/
/*											*/
/********************************************/
int mem_rcpy_int(d0,s0,n)
int *d0,*s0,n;
{
	int ret,*d,*s;

	_MEM_RCPY
}

/********************************************/
/*											*/
/********************************************/
int mem_rcpy_long(d0,s0,n)
long *d0,*s0;
int n;
{
	int ret;
	long *d,*s;

#if defined(_LP64)
	_MEM_RCPY
#else
	return mem_rcpy_int(d0,s0,n);
#endif
}

/********************************************/
/*											*/
/********************************************/
int mem_rcpy_double(d0,s0,n)
double *d0,*s0;
int n;
{
	int ret;
	double *d,*s;

	_MEM_RCPY
}

/********************************************/
/*											*/
/********************************************/
int mem_rcpy_addr(d0,s0,n)
char *d0[],*s0[];
int n;
{
	int ret;
	char **d,**s;

	_MEM_RCPY
}

#define _MEM_SUM \
	ret = 0;\
	if (s = s0) {\
		while (n-- > 0) ret += *s++;\
	}\
	return ret;

/********************************************/
/*											*/
/********************************************/
int mem_sum_byte(s0,n)
uchar *s0;
int n;
{
	int ret;
	uchar *s;

	_MEM_SUM
}

/********************************************/
/*											*/
/********************************************/
int mem_sum_int(s0,n)
int *s0,n;
{
	int ret,*s;

	_MEM_SUM
}

/********************************************/
/*											*/
/********************************************/
long mem_sum_long(s0,n)
long *s0;
int n;
{
	long ret,*s;

#if defined(_LP64)
	_MEM_SUM
#else
	return mem_sum_int(s0,n);
#endif
}

/********************************************/
/*											*/
/********************************************/
double mem_sum_double(s0,n)
double *s0;
int n;
{
	double ret,*s;

	_MEM_SUM
}

/********************************************/
/*											*/
/********************************************/
int mem_cpy_int_byte(di0,sb0,n)
int di0[];
uchar sb0[];
int n;
{
	int ret,*di;
	uchar *sb;

	if (di = di0) {
		ret = n;
		if (n>0 && (sb=sb0)) {
			while (n-- > 0) *di++ = *sb++;
		}
	}
	else ret = -1;
	return ret;
}

#define _MEM_REVERSE \
	if (s = s0) {\
		ret = 0;\
		sj = s + n - 1;\
		for (i=0,j=n-1;i<j;i++,j--) {\
			c = *s;\
			*s++ = *sj;\
			*sj-- = c;\
		}\
	}\
	else ret = -1;\
	return ret;

/********************************************/
/*											*/
/********************************************/
int mem_reverse_byte(s0,n)
uchar *s0;
int n;
{
	int i,j,ret;
	uchar c,*s,*sj;

	_MEM_REVERSE
}

/********************************************/
/*											*/
/********************************************/
int mem_reverse_int(s0,n)
int *s0;
int n;
{
	int c,i,j,ret;
	int *s,*sj;

	_MEM_REVERSE
}

/********************************************/
/*											*/
/********************************************/
int mem_reverse_long(s0,n)
long *s0;
int n;
{
	int i,j,ret;
	long c,*s,*sj;

#if defined(_LP64)
	_MEM_REVERSE
#else
	return mem_reverse_int(s0,n);
#endif
}

/********************************************/
/*											*/
/********************************************/
int mem_reverse_double(s0,n)
double *s0;
int n;
{
	int i,j,ret;
	double c,*s,*sj;

	_MEM_REVERSE
}

/********************************************/
/*											*/
/********************************************/
int mem_reverse_addr(s0,n)
char *s0[];
int n;
{
	int i,j,ret;
	char *c,**s,**sj;

	_MEM_REVERSE
}

#define _MEM_REVERSE_CELL \
	if (s=s0) {\
		ret = 0;\
		sj = s + (nset - 1)*m;\
		for (i=0,j=nset-1;i<j;i++,j--) {\
			ce = s;\
			cej = sj;\
			for (k=0;k<m;k++) {\
				c = *ce;\
				*ce++ = *cej;\
				*cej++ = c;\
			}\
			s += m;\
			sj -= m;\
		}\
	}\
	else ret = -1;\
	return ret;

/********************************************/
/*											*/
/********************************************/
int mem_reverse_byte_cell(s0,nset,m)
uchar *s0;
int nset,m;
{
	int i,j,k,ret;
	uchar c,*s,*sj,*ce,*cej;

	if (m > 1) {
		_MEM_REVERSE_CELL
	}
	else {
		return mem_reverse_byte(s0,nset);
	}
}

/********************************************/
/*											*/
/********************************************/
int mem_reverse_int_cell(s0,nset,m)
int *s0;
int nset,m;
{
	int i,j,k,ret;
	int c,*s,*sj,*ce,*cej;

	if (m > 1) {
		_MEM_REVERSE_CELL
	}
	else {
		return mem_reverse_int(s0,nset);
	}
}

/********************************************/
/*											*/
/********************************************/
int mem_reverse_long_cell(s0,nset,m)
long *s0;
int nset,m;
{
	int i,j,k,ret;
	long c,*s,*sj,*ce,*cej;

#if defined(_LP64)
	if (m > 1) {
		_MEM_REVERSE_CELL
	}
	else {
		return mem_reverse_long(s0,nset);
	}
#else
	if (m > 1) {
		return mem_reverse_int_cell(s0,nset,m);
	}
	else {
		return mem_reverse_int(s0,nset);
	}
#endif
}

/********************************************/
/*											*/
/********************************************/
int mem_reverse_double_cell(s0,nset,m)
double *s0;
int nset,m;
{
	int i,j,k,ret;
	double c,*s,*sj,*ce,*cej;

	if (m > 1) {
		_MEM_REVERSE_CELL
	}
	else {
		return mem_reverse_double(s0,nset);
	}
}

/********************************************/
/*											*/
/********************************************/
int mem_reverse_addr_cell(s0,nset,m)
char *s0[];
int nset,m;
{
	int i,j,k,ret;
	char *c,**s,**sj,**ce,**cej;

	if (m > 1) {
		_MEM_REVERSE_CELL
	}
	else {
		return mem_reverse_addr(s0,nset);
	}
}

#define _MEM_ROTATE_CELL(mem_cpy_int,mem_rcpy_int) \
	if (mcell <= 0) return 0;\
	ix *= mcell;\
	n *= mcell;\
	if (X_ABS(ix) >= n) ret = 0;\
	else if (s = s0) {\
		if (ix < 0) ix = n + ix;\
		m = 10;\
		if (m > ix) m = ix;\
		d = s;\
		if (ix <= n/2) {\
			for (i=0;i<ix;i+=m) {\
				if (i+m > ix) m = ix - i;\
				s = d + m;\
				mem_cpy_int(w,d,m);\
				mem_cpy_int(d,s,n-m);\
				mem_cpy_int(d+n-m,w,m);\
			}\
		}\
		else {\
			ix = n - ix;\
			for (i=0;i<ix;i+=m) {\
				if (i+m > ix) m = ix - i;\
				s = d + m;\
				mem_cpy_int(w,d+n-m,m);\
				mem_rcpy_int(s,d,n-m);\
				mem_cpy_int(d,w,m);\
			}\
		}\
	}\
	else ret = -1;\
	return ret;

/********************************************/
/*											*/
/********************************************/
int mem_rotate_byte_cell(s0,ix,n,mcell)
uchar s0[];
int ix,n,mcell;
{
	int i,m,ret,k;
	uchar c,*s,*d,w[10];

	_MEM_ROTATE_CELL(memcpy,memrcpy)
}

/********************************************/
/*											*/
/********************************************/
int mem_rotate_int_cell(s0,ix,n,mcell)
int s0[];
int ix,n,mcell;
{
	int i,m,ret,k;
	int c,*s,*d,w[10];

	_MEM_ROTATE_CELL(mem_cpy_int,mem_rcpy_int)
}

/********************************************/
/*											*/
/********************************************/
int mem_rotate_long_cell(s0,ix,n,mcell)
long s0[];
int ix,n,mcell;
{
	int i,m,ret,k;
	long c,*s,*d,w[10];

	_MEM_ROTATE_CELL(mem_cpy_long,mem_rcpy_long)
}

/********************************************/
/*											*/
/********************************************/
int mem_rotate_double_cell(s0,ix,n,mcell)
double s0[];
int ix,n,mcell;
{
	int i,m,ret,k;
	double c,*s,*d,w[10];

	_MEM_ROTATE_CELL(mem_cpy_double,mem_rcpy_double)
}

/********************************************/
/*											*/
/********************************************/
int mem_rotate_addr_cell(s0,ix,n,mcell)
char *s0[];
int ix,n,mcell;
{
	int i,m,ret,k;
	char *c,**s,**d,*w[10];

	_MEM_ROTATE_CELL(mem_cpy_addr,mem_rcpy_addr)
}

/********************************************************/
/*														*/
/*							0x01 : ����			*/
/*							0x02 : �p��			*/
/*							0x04 : �L��			*/
/*							0x08 : ���p�J�i			*/
/*							0x10 : ���p			*/
/*							0x20 : �S�p			*/
/*							0x40 : ���l(+-.0-9,EDF)			*/
/*							0x80 : ���O(�擪 A-Z,�S�p,���p�J�i)	*/
/*							0x100: - ����				*/
/*							0x200: . ����				*/
/********************************************************/
int akxq_char_kind(s,s_len,opt)
char *s;
int  s_len,opt;
{
	int i,opt4,ret,m,n;
	int x1,x2,x4,x8,x10,x20,x40,x80,x100,x200;
	char c,w[4];

	opt4 = opt & 0x04;
	x1=x2=x4=x8=x10=x20=x100=x200=0;
	x40=0x40;
	x80=0x80;
	i = 0;
	while (i < s_len) {
		m = n = akxqkanjilen2(s,s_len);
		if (m == 1) {
			x10 = 0x10;
		}
		else if (akxqis_hankaku_kana(s,m)) {
			x8 = 8;
		}
		else {
			x20 = 0x20;
			if (opt4) {
				m = akxctohan(m,s,w);
				if (m == 1) c = *w;
				else if (akxqis_hankaku_kana(w,m)) x8 = 8;
			}
			else x40 = 0;
		}
		if (m == 1) {
			c = akxcupper(c);
			if (c>='0' && c<='9') {
				x1 = 1;
				if (!i) x80 = 0;
			}
			else if (c>='A' && c<='Z') {
				x2 = 2;
				if (!(c=='D' || c=='E' || c=='F')) x40 = 0;
			}
			else if (c>=161 && c<=223) {
				x8 = 8;
			}
			else {
				x4 = 4;
				if (c == '.') {
					x200 = 0x200;
				}
				else if (c == '+') {
					x80 = 0;
				}
				else if (c == '-') {
					x100 = 0x100;
				}
				else if (c == '_') {
					x40 = 0;
				}
				else {
					x80 = x40 = 0;
				}
			}
		}
		i += n;
		s += n;
	}
	ret = x1 *+ x2 + x4 + x8 + x10 + x20 + x40 + x80;
	if (opt4) ret += x100 + x200;
	return ret;
}

/********************************************/
/*											*/
/********************************************/
char *nval1x(p)
char *p;
{
	static char buf[16];

	if (!p) p = "NULL";
	else {
		sprintf(buf,"%08x",p);
		p = buf;
	}
	return p;
}

/********************************************/
/*											*/
/********************************************/
char *nval1(p)
char *p;
{
	if (!p) p = "(null)";
	return p;
}

/********************************************/
/*											*/
/********************************************/
char *nval(p,p1)
char *p,*p1;
{
	if (!p) {
		p = p1;
		p = nval1(p);
	}
	return p;
}

/********************************************/
/*											*/
/********************************************/
char *nvalid(p,p1)
char *p,*p1;
{
	if (!akxm_addrchk(p)) {
		p = p1;
		if (!akxm_addrchk(p)) p = "(invalid)";
	}
	return p;
}

/********************************************/
/*											*/
/********************************************/
int is_kuuhaku(c)
char c;
{
	int ret;

	if (c==' ' || c=='\t' || c=='\n') ret = 1;
	else ret = 0;
	return ret;
}

/********************************************/
/*											*/
/********************************************/
int mem_cmp_int(p1,p2,n)
int *p1,*p2;
int  n;
{
	int i,d;

	if (!p1 && !p2) d = 0;
	else if (!p1) d = -1;
	else if (!p2) d = 1;
	else {
		d = 0;
		while (n-- > 0) {
			d = *p1++ - *p2++;
			if (d) break;
		}
	}
	return d;
}

/********************************************/
/*											*/
/********************************************/
int mem_cmp_int_n(p1,n1,p2,n2)
int *p1,*p2,n1,n2;
{
	int d;

	if (!p1 && !p2) d = 0;
	else if (!p1) d = -1;
	else if (!p2) d = 1;
	else {
		if (!n1 && !n2) d = 0;
		else if(n1 < n2) {
			if (!(d = mem_cmp_int(p1,p2,n1))) d = -1;
		}
		else if(n1 > n2) {
			if (!(d = mem_cmp_int(p1,p2,n2))) d = 1;
		}
		else
			d = mem_cmp_int(p1,p2,n1);
	}
	return d;
}

#if defined(_LP64)
/********************************************/
/*											*/
/********************************************/
long x_htonll(x)
long x;
{
	char w[8],*p,*ww,*pp;
	int i;

	pp = p = (char *)&x;
	ww = w + 7;
	for (i=0;i<8;i++) *ww-- = *pp++;
	memcpy(p,w,8);
	return x;
}
long x_ntohll(x)
long x;
{
	return x_htonll(x);
}
#endif
  
/********1*********2*********3*********4*********5*********6*********7***/
/* �@�\ : �Ώە��������؂蕶���񒆂̕����ŕ�������					*/
/*		  �擪����؂蕶���̂Ƃ��́Aargv[0]�ɂ́Anull�������ݒ肳���B	*/
/* ���� : IN    : buf      : �Ώە�����									*/
/*				  buf_len  : �Ώە�����o�C�g��							*/
/*				  sep	   : ��؂蕶����								*/
/*							 NULL�܂���sel_len<=0�̂Ƃ��́A" \t"�ƂȂ�B*/
/*				  sep_len  : ��؂蕶����o�C�g��						*/
/*				  parm	   : �������镶������i�[����̈�			�A	*/
/*							 �ő�ŁAbuf_len+(maxargs+1)�o�C�g���K�v	*/
/*				  parm_len : �������镶������i�[����̈�̃o�C�g���A	*/
/*							 �I�[��null�������܂ށB						*/
/*							 �������ꂽ�����񂪎c��̒����𒴂���Ƃ�	*/
/*							 �́A���̑O�܂ł̕��𐔂ƂȂ�B				*/
/*				  opt	   : �I�v�V����									*/
/* 0x01 : ��؂蕶���̑啶������������ʂ��Ȃ��B						*/
/* 0x02 : �O��̃X�y�[�X�ƃ^�u���폜����B								*/
/*			��؂蕶�����X�y�[�X�܂��̓^�u�̂Ƃ��́A��؂�ꂽ�������	*/
/*			�O��ɂ́A�X�y�[�X�܂��̓^�u�͓���Ȃ��̂ŁA���̃I�v�V������*/
/*			ON/OFF�Ō��ʂ͕ς��Ȃ��B									*/
/* 0x04 : =0:max_argv����؂�񐔂ƌ��Ȃ��A�ő�max_argv+1�ɕ�������B	*/
/*		  =1:�ő�max_argv�ɕ�������B									*/
/* 0x08 : =0:��؂蕶���̂ǂꂩ���A������Ƃ��́A1�̋�؂蕶���ƌ��Ȃ�*/
/* 0x10 : sep==NULL��sep_len<=0�̂Ƃ��ɁA�J���}����؂蕶���ɉ�����B	*/
/*		  OUT   : argv[]   : �������ꂽ������̔z��						*/
/*						   : ����<maxargs�̂Ƃ��́Amaxargs�܂�		*/
/*							 null�������ݒ肳���B						*/
/* 0x20 : =0:��؂蕶���ɔ��p�X�y�[�X�܂��̓^�u�������Ă��A�擪��		*/
/*			 ������ǂݔ�΂��B										*/
/* 0x40 : (2�d)���p������������											*/
/* 0x80 : �O���(2�d)���p�����O�� + �����̘A������2��(2�d)���p����	*/
/*		  1�ɂ���B0x40�������ŗ��Ă�B								*/
/* �ԋp : ����														*/
/************************************************************************/
int akxtnsplit(buf,buf_len,argv,maxargv,parm,parm_len,sep,sep_len,opt)
char *buf,*argv[],*parm,*sep;
int buf_len,maxargv,parm_len,sep_len,opt;
{
	static char wrk[128],*p0=NULL;
	char *p,*pm,*pp,ssep[4],*gsep,gssep[6];
	int len,pmlen,splen,m,n,pos,opt02,opt04,opt08,opt20,mlen;
	int gw_opt,in_opt,code_type,iSETW,ma[2];
	SSPL_S sspl;

	if (!(p=buf) || !argv || !(pm=parm)) return -1;
/*
printf("akxtnsplit: buf_len=%d buf=[%s] sep_len=%d sep=[%s]\n",buf_len,buf,sep_len,sep);
printf("akxtnsplit: parm_len=%d opt=%08x\n",parm_len,opt);
*/
	if ((len=buf_len)<=0 || maxargv<=0 || (pmlen=parm_len)<=0) return 0;
	opt02 = opt & 0x02;
	opt04 = opt & 0x04;
	opt08 = opt & 0x08;
	opt20 = opt & 0x20;
	code_type = opt & 0x7f000000;
	in_opt = opt & 0x01;
	if (opt & 0x01) gw_opt = 0x400;
	else gw_opt = 0;
#if 1	/* 2025.11.25 */
	if (opt & 0x80) {
		gw_opt |= 0x06;	/* �O��̈��p��(2�d���p��)���O�� + �����̘A������2�̈��p��(2�d���p��)��1�ɂ��� */
		opt |= 0x40;
	}
	if (!(opt & 0x40)) gw_opt |= 0x08;
#else
	if (opt & 0x40) {
		if (opt & 0x80) gw_opt |= 0x06;	/* �O��̈��p��(2�d���p��)���O�� + �����̘A������2�̈��p��(2�d���p��)��1�ɂ��� */
	}
	else gw_opt |= 0x08;
#endif
	if (!sep || (splen=sep_len)<=0) {
		sep = ssep;
		memcpy(sep," \t",3);
		if (opt & 0x10) memcpy(sep+2,",",2);
		splen = strlen(sep);
		gsep = gssep;
		strcpy(gsep,sep);
	/*	strcat(gsep,"'\"");	*/
	}
	else {
		len = sep_len + 3;
		if ((n=akxmemwork(len,&gsep,&p0,wrk,sizeof(wrk))) <= 0) {
			n = sizeof(wrk);
		}
		if (n < len) {
			memnzcpy(gsep,sep,sep_len,n);
		}
		else {
			memzcpy(gsep,sep,sep_len);
		/*	strcat(gsep,"'\"");	*/
		}
/*
printf("akxtnsplit: n=%d gsep=[%s]\n",n,gsep);
*/
	}
	memset(&sspl,0,sizeof(SSPL_S));
	in_opt |= code_type;
	code_type >>= 24;
	sspl.code = code_type;
	n = 0;
	len = buf_len;
	pp = pm;
	*pp = '\0';
	if (!(opt & 0x20)) iSETW = 1;
	else iSETW = 0;
/*
printf("akxtnsplit: in_opt=%08x splen=%d sep=[%s]\n",in_opt,splen,sep);
*/
	while (len > 0) {
		/*  */
/*
printf("akxtnsplit: len=%d p=[%s]\n",len,p);
*/
		if (!opt08)
			pos = akxn_skip_opt(p,len,sep,splen,in_opt);
		else if (len > 0) {
#if 1	/* 2025.10.3 */
			if (_in_mem_char(sep,splen,p,len,ma,in_opt) <= 0) pos = 0;
			else pos = ma[0];
#else
			pos = akxqmbsnlen(code_type,p,len);
			if (akxs_in_mem_opt(sep,splen,p,pos,in_opt) <= 0) pos = 0;
#endif
		}
		else pos = 0;
/*
printf("akxtnsplit: pos=%d\n",pos);
*/
		if (pos > 0) {
			if (!iSETW) {
				*pm = '\0';
				argv[n++] = pm;
/*
printf("akxtnsplit: n=%d\n",n);
*/
				pm++;
				pmlen--;
			}
			p += pos;
			len -= pos;
			iSETW = 0;
/*
printf("akxtnsplit:1: iSETW=%d pos=%d len=%d pmlen=%d\n",iSETW,pos,len,pmlen);
*/
			if (n >= maxargv) break;
		}
		else {
		/*  */
			sspl.sp = 0;
			sspl.wd = pm;
			sspl.wdmax = pmlen - 1;
			pos = akxtgwnsl(p,len,&sspl,gsep,gw_opt);
/*
printf("akxtnsplit:2: pos=%d pm=[%s]\n",pos,pm);
*/
			if (pmlen <= pos) break;
		/*	memzcpy(pm,p,pos);	*/
			mlen = pos;
			if (opt02 && sspl.attr[0]!=5 && sspl.attr[0]!=6) mlen = akxttrim(0,pm,pos);
			argv[n++] = pm;
			if (!opt04 && n>=maxargv) break;
			p += sspl.sp;
			len -= sspl.sp;
			mlen++;
			pm += mlen;
			pmlen -= mlen;
			iSETW = 1;
/*
printf("akxtnsplit:2: iSETW=%d pos=%d len=%d n=%d pmlen=%d\n",iSETW,pos,len,n,pmlen);
*/
		}
		pp = pm - 1;
	}
	if (!opt04 && pmlen>0) {
		mlen = memnzcpy(pm,p,len,pmlen);
		if (opt02) akxttrim(0,pm,mlen);
		if (*pm) argv[n++] = pm;
	}
	m = n;
	while (n < maxargv) argv[n++] = pp;
	return m;
}

/********1*********2*********3*********4*********5*********6*********/
/* �@�\ : �Œ蒷�v�f��̔�r�֐�									*/
/* ���� : c_arg   : �t�����										*/
/*					c_arg[0] : opt									*/
/*						opt : 0x01 : = 0 / 1 : ���� / �~��			*/
/*							  0x02 : = 0 / 1 : ���� / �����L���l��	*/
/*												��r����			*/
/*									���l�̂Ƃ��́A�L�[���Ō^�����܂�*/
/*										<= 1   : char				*/
/*										 = 2   : short				*/
/*										<= 4   : int				*/
/*										���̑� : long				*/
/*					c_arg[1] : mlen �v�f�� (�o�C�g)					*/
/*					c_arg[2] : �L�[�̈ʒu (�擪��0)					*/
/*					c_arg[3] : �L�[�� (�o�C�g)						*/
/*		  a       : ��r�̍��ӗv�f�̐擪�A�h���X					*/
/*		  b       : ��r�̉E�ӗv�f�̐擪�A�h���X					*/
/* �ԋp : ��r����													*/
/*			> 0 : ���ӗv�f > �E�ӗv�f								*/
/*			= 0 : ���ӗv�f = �E�ӗv�f								*/
/*			< 0 : ���ӗv�f < �E�ӗv�f								*/
/********************************************************************/
static int _cmp_qsort_r(c_arg,a,b)
char *c_arg,*a,*b;
{
	int *arg,mlen,opt,dif,klen;
	short sa,sb;
	long la,lb;
	char ca,cb;
/*
printf("_cmp_qsort_r: a=%08x b=%08x c_arg=%08x\n",a,b,c_arg);
*/
	arg = (int *)c_arg;
	opt  = arg[0];
	mlen = arg[1];
	klen = arg[3];
	a += arg[2];
	b += arg[2];
/*
printf("_cmp_qsort_r: mlen=%d opt=%d\n",mlen,opt);
*/
	if (opt & 0x02) {
		if (klen <= sizeof(char))
			dif = *a - *b;
		else if (klen <= sizeof(short))
			dif = *(short *)a - *(short *)b;
		else if (klen <= sizeof(int))
			dif = *(int *)a - *(int *)b;
		else
			dif = *(long *)a - *(long *)b;
	}
	else {
		dif = memcmp(a,b,klen);
	}
	if (opt & 0x01) dif = -dif;
/*
printf("_cmp_qsort_r: dif=%d\n",dif);
*/
	return dif;
}

/********1*********2*********3*********4*********5*******/
/* �@�\ : �Œ蒷�v�f��������^�~���Ƀ\�[�g����			*/
/* ���� : sel_str : �\�[�g�Ώۗ̈�						*/
/*		  max_sel : �v�f��								*/
/*		  mlen    : �v�f�̒���(�o�C�g)					*/
/*		  posa    : �L�[�̈ʒu NULL�̂Ƃ��́A���ׂ�		*/
/*					posa[0] : �J�n�ʒu (�擪��0)		*/
/*					posa[1] : ����(�o�C�g)				*/
/*		  opt     : �I�v�V���� _cmp_qsort_r()���Q��		*/
/* �ԋp : = 0 : ����									*/
/*		  < 0 : �G���[									*/
/********************************************************/
int akxnmstrsort2(sel_str,max_sel,mlen,posa,opt)
char *sel_str;
int max_sel,mlen,posa[],opt;
{
	char max_c,c,*p,*p_max_c,*p_c,wrk[256],*p_i;
	char w1[256],w2[256];
	int i,j,max_i,dif,arg[4];
/*
printf("akxnstrsort_opt: sort : opt=%d max_sel=%d sel_str=[%s]\n",opt,max_sel,sel_str);
*/
	if (!(p=sel_str) || (mlen>sizeof(wrk))) return -1;
	if (max_sel<=0 || mlen<=0) return 0;
#if 1
	arg[0] = opt;
	arg[1] = mlen;
	if (posa) {
		arg[2] = posa[0];
		arg[3] = posa[1];
	}
	else {
		arg[2] = 0;
		arg[3] = mlen;
	}
/*	akxqsort_r(sel_str,max_sel,mlen,_cmp_qsort_r,arg);	*/
	qsort_r(sel_str,max_sel,mlen,arg,_cmp_qsort_r);
#else
	p = sel_str;
	p_i = p;
	for (i=0;i<max_sel-1;i++,p_i+=mlen) {
		p_max_c = p_i;
	/*	max_c = sel_str[i];	*/
		max_i = i;
		p_c = p_i + mlen;
		for (j=i+1;j<max_sel;j++,p_c+=mlen) {
		/*	c = sel_str[j];
			if ((!opt && c<max_c) || (opt && c>max_c)) {
				max_c = c;
				max_i = j;
			}*/
			dif = memcmp(p_c,p_max_c,mlen);
			memzcpy(w1,p_c,mlen);
			memzcpy(w2,p_max_c,mlen);
/*
printf("i=%d j=%d dif=%d p_c=[%s] p_max_c=[%s]\n",i,j,dif,w1,w2);
*/
			if (opt) dif = -dif;
			if (dif < 0) {
				p_max_c = p_c;
				max_i = j;
			}
		}
		if (max_i != i) {
		/*	c = sel_str[i];
			sel_str[i] = max_c;
			sel_str[max_i] = c;	*/
			memcpy(wrk,p_i,mlen);
			memcpy(p_i,p_max_c,mlen);
			memcpy(p_max_c,wrk,mlen);
		}
	}
/*
printf("akxnstrsort_opt: sort : sel_str=[%s]\n",sel_str);
*/
#endif
	return 0;
}

int akxnmstrsort_opt(sel_str,max_sel,mlen,opt)
char *sel_str;
int max_sel,mlen,opt;
{
	return akxnmstrsort2(sel_str,max_sel,mlen,NULL,opt);
}

/********************************************************/
/*	������������^�~���Ƀ\�[�g����						*/
/*		opt : =0 / <>1 : ���� / �~��					*/
/********************************************************/
int akxnstrsort_opt(sel_str,max_sel,opt)
char *sel_str;
int max_sel,opt;
{
	return  akxnmstrsort_opt(sel_str,max_sel,1,opt);
}

/********************************************************/
/*	����������ւ���֐�								*/
/********************************************************/
void akxtswap_mem(a,b,size)
char *a,*b;
int size;
{
	char tmp;

	while (size--) {
		tmp = *b;
		*b = *a;
		*a = tmp;
		a++;
		b++;
	}
}

/********************************************************/
/*														*/
/********************************************************/
static void _swap(a,b,size)
char *a,*b;
int size;
{
	akxtswap_mem(a,b,size);
}

/********************************************************/
/*	�N�C�b�N�\�[�g���s���֐�							*/
/********************************************************/
static void QuickSort_r(dat,iSta,iEnd,size,_compar,arg)
char *dat;
int iSta,iEnd,size;
int (*_compar)();
char *arg;
{
	int iBaseNum,iCnt,i,ii;
	char strBaseVal[256],*p_i,*p_cnt,*p_sta;
/*
printf("QuickSort_r: iSta=%d iEnd=%d size=%d\n",iSta,iEnd,size);
*/
	if (iSta >= iEnd) return;
	iBaseNum = (iSta + iEnd) / 2;
	memcpy(strBaseVal,dat+iBaseNum*size,size);
	memcpy(dat+iBaseNum*size,dat+iSta*size,size);
	iCnt = iSta;
	p_sta = p_cnt = dat + iSta*size;
	p_i = p_sta + size;
	for (i = iSta + 1;i<=iEnd;i++) {
/*
printf("QuickSort_r: i=%d\n",i);
*/
		if (_compar(p_i,strBaseVal,arg) < 0) {
			iCnt++;
			p_cnt += size;
			_swap(p_cnt,p_i,size);
		}
		p_i += size;
	}
	memcpy(p_sta,p_cnt,size);
	memcpy(p_cnt,strBaseVal,size);
	QuickSort_r(dat,iSta,iCnt-1,size,_compar,arg);
	QuickSort_r(dat,iCnt+1,iEnd,size,_compar,arg);
	return;
}

/********************************************************/
/*														*/
/********************************************************/
void akxqsort_r(a,nmenb,size,_compar,arg)
char *a;
int nmenb,size;
int (*_compar)();
char *arg;
{
	QuickSort_r(a,0,nmenb-1,size,_compar,arg);
	return;
}

/********************************************************/
/*														*/
/********************************************************/
static int _compar_inx_vdat(a,b,c_arg)
char *a,*b,*c_arg;
{
	char **ca,**cb,*aa,*bb;
	int  opt,dif,ia,ib,*arg;

	arg = (int *)c_arg;
	opt = arg[0];
	a += sizeof(int);
	b += sizeof(int);
	if (opt & 0x08) {
		ia = *(int *)a;
		ib = *(int *)b;
/*
printf("_compar_inx_vdat: ia=%d ib=%d\n",ia,ib);
*/
		dif = ia - ib;
	}
	else {
		aa = *(char **)a;
		bb = *(char **)b;
/*
printf("_compar_inx_vdat: aa=[%s] bb=[%s]\n",aa,bb);
*/
		dif = strcmp(aa,bb);
	}
	return dif;
}

/********************************************************/
/*														*/
/********************************************************/
static void _set_of_index(s,nDat,size,dat0,mlen)
char *s,*dat0;
int nDat,size,mlen;
{
	char *p,*pp,*dat;
	int i,index;

	p = s;
	dat = dat0;
	for (i=0;i<nDat;i++) {
		memcpy(&index,p,sizeof(int));
/*
printf("_set_of_index: index=%d\n",index);
*/
		pp = p + sizeof(int);
		memcpy(pp,dat+index*mlen,mlen);
		p += size;
	}
	p = s;
	dat = dat0;
	for (i=0;i<nDat;i++) {
		pp = p + sizeof(int);
		memcpy(dat,pp,mlen);
		p += size;
		dat += mlen;
	}
}

/********1*********2*********3*********4*********5*********6*********/
/*  ���� : str_sort_inx_vdat										*/
/*  �@�\ : ������z��\�[�g����(�C���f�b�N�X�A���̑��f�[�^�t��)		*/
/*  ���� : IN	  : dat0()    : string data array					*/
/*					nDat      : number of dat()						/*
/*					inx0()    : index array of data					/*
/*					vdat()    : variant data array					*/
/*					Opt       : �I�v�V����							*/
/*								0x01 = 0 : ����						*/
/*									 = 1 : �~��						*/
/*								0x02 = 1 : inx���\�[�g�ΏۂƂ���	*/
/*								0x04 = 1 : vdat���\�[�g�ΏۂƂ���	*/
/*								0x08 = 0 : dat()���\�[�g�L�[�Ƃ���	*/
/*									 = 1 : inx()���\�[�g�L�[�Ƃ���	*/
/*		   OUT	  : dat()											*/
/*					inx()											*/
/*					vdat()											*/
/*  �쐬 : 2016/04/06 Akito Kobayashi								*/
/*  �X�V : 2018/06/25 Akito Kobayashi Add opt=0x08					*/
/*	�X�V : 2023/04/04 Akito Kobayashi use akxqsort_r()				*/
/********************************************************************/
int akxstrsort_inx_vdat(dat0,nDat,inx0,vdat,iOpt)
char *dat0[],*vdat[];
int nDat,inx0[],iOpt;
{
#if 1
	char *s,*p,**dat,*pp;
	int i,size,arg[2],index,*inx;

	if (iOpt & 0x08) size = sizeof(int)*2;
	else size = sizeof(char *) + sizeof(int);
	if(!(s = Malloc(nDat*size))) return -1;
	p = s;
	index = 0;
	dat = dat0;
	inx = inx0;
	for (i=0;i<nDat;i++) {
		memcpy(p,&index,sizeof(int));
		p += sizeof(int);
		index++;
		if (iOpt & 0x08) {
			memcpy(p,inx,sizeof(int));
			p += sizeof(int);
			inx++;
		}
		else {
			memcpy(p,dat,sizeof(char *));
			p += sizeof(char *);
			dat++;
		}
	}

	arg[0] = iOpt;
	arg[1] = size;
	akxqsort_r(s,nDat,size,_compar_inx_vdat,arg);

	p = s;
	dat = dat0;
	inx = inx0;
	for (i=0;i<nDat;i++) {
		memcpy(&index,p,sizeof(int));
/*
printf("akxstrsort_inx_vdat: index=%d\n",index);
*/
		pp = p + sizeof(int);
		if (iOpt & 0x08) {
			memcpy(inx,pp,sizeof(int));
			inx++;
		}
		else {
			memcpy(dat,pp,sizeof(char *));
			dat++;
		}
		p += size;
	}
	if ((iOpt & 0x02) && !(iOpt & 0x08)) {
		_set_of_index(s,nDat,size,inx0,sizeof(int));
	}
	if (iOpt & 0x04) {
		_set_of_index(s,nDat,size,vdat,sizeof(char *));
	}
	if (iOpt & 0x08) {
		_set_of_index(s,nDat,size,dat0,sizeof(char *));
	}
	Free(s);
#else
	int opt1,opt2,opt4,opt8,k,i,j,max_dat,min_i,min_inx,inx_j;
	char *min_vdat,*dat_j,*min_dat;

	opt1 = iOpt & 0x1;
	opt2 = iOpt & 0x2;
	opt4 = iOpt & 0x4;
	opt8 = iOpt & 0x8;
	if (opt8) opt2 = 0x2;
	max_dat = nDat;
	for (i=0;i<max_dat-1;i++) {
		min_i = i;
		min_dat = dat[i];
		if (opt2) min_inx = inx[i];
		if (opt4) min_vdat = vdat[i];
		for (j=i+1;j<max_dat;j++) {
			k = 0;
			if (!opt8) {
				dat_j = dat[j];
				if ((!opt1 && dat_j<min_dat) || (opt1 && dat_j>min_dat)) k = 1;
			}
			else {
				inx_j = inx[j];
				if ((!opt1 && inx_j<min_inx) || (opt1 && inx_j>min_inx)) k = 1;
			}
			if (k) {
				min_i = j;
				min_dat = dat[j];
				if (opt2) min_inx = inx[j];
				if (opt4) min_vdat = vdat[j];
			}
		}
		if (min_i > i) {
			dat[min_i] = dat[i];
			dat[i] = min_dat;
			if (opt2) {
				inx[min_i] = inx[i];
				inx[i] = min_inx;
			}
			if (opt4) {
				vdat[min_i] = vdat[i];
				vdat[i] = min_vdat;
			}
		}
	}
#endif
	return 0;
}

/********1*********2*********3*********4*********5*********6*****/
/* �@�\ : �T�[�`bit�z��̎w��͈͂ɂ���l�ƈ�v����ʒu��Ԃ�	*/
/* ���� : bits : �T�[�`bit�z��									*/
/*		  i1   : �����r�b�g�ʒu									*/
/*		  i2   : ����r�b�g�ʒu									*/
/*		  bit  : �����Ώ�(i1�`i2�r�b�g�ڂ̂ǂ�����ӏ��݂̂�ON)	*/
/*				 0x00000001 : 1�Ԗ�								*/
/* �ԋp : > 0 : �r�b�g�ʒu										*/
/*		  = 0 : ��v����r�b�g�Ȃ�(ON�̃r�b�g�̐���1�łȂ�)	*/
/****************************************************************/
static int _get_bit_num_hlf(bits,i1,i2,bit)
long bits[],bit;
int i1,i2;
{
	int i,im;
	long bitm;
/*
printf("_get_bit_num_hlf:Enter bit=%08x i1=%d i2=%d\n",bit,i1,i2);
*/
	i = 0;
	im = (i2 + i1)/2;
	if (im <= 0) {
		if (bits[i2] & bit) i = i2;
	}
	else {
		bitm = bits[im];
		if (bit & bitm) i = im;
		else if (bit < bitm)
			i = _get_bit_num_hlf(bits,i1,im-1,bit);
		else
			i = _get_bit_num_hlf(bits,im+1,i2,bit);
	}
/*
printf("_get_bit_num_hlf:Exit i=%d\n",i);
*/
	return i;
}

/********1*********2*********3*********4*********5*********6*****/
/* �@�\ : bit32�z��̐擪�A�h���X��Ԃ�							*/
/* �ԋp : bit32�z��̐擪�A�h���X								*/
/****************************************************************/
long *get_bit32_array()
{
	static long bits[33]={0,1,2,4,8,0x10,0x20,0x40,0x80,0x100,0x200,0x400,0x800
	,0x1000,0x2000,0x4000,0x8000,0x10000,0x20000,0x40000,0x80000
	,0x100000,0x200000,0x400000,0x800000,0x1000000,0x2000000,0x4000000,0x8000000
	,0x10000000,0x20000000,0x40000000,0x80000000};

	return bits;
}

/********1*********2*********3*********4*********5*********6*****/
/* �@�\ : ���ʂ��琔���ĉ��Ԗڂ̃r�b�g��ON����Ԃ�				*/
/* ���� : bit : �����Ώ�(1�`32�r�b�g�ڂ̂ǂ�����ӏ��݂̂�ON)	*/
/*				0x00000001 : 1�Ԗ�								*/
/* �ԋp : > 0 : �r�b�g�ʒu										*/
/*		  = 0 : ��v����r�b�g�Ȃ�(ON�̃r�b�g�̐���1�łȂ�)	*/
/****************************************************************/
int get_bit_number(bit)
long bit;
{
	int i,im;
	long *bits,bitm;

	bits = get_bit32_array();
	if (!bit) i = 0;
	else if (bit == bits[32]) i = 32;
	else if (bit == bits[1]) i = 1;
	else {
		im = 16;
		bitm = bits[im];
		if (bit == bitm) i = im;
		else if (bit < bitm)
			i = _get_bit_num_hlf(bits,2,im-1,bit);
		else
			i = _get_bit_num_hlf(bits,im+1,31,bit);
	}
	return i;
}

/************************************/
/*									*/
/************************************/
void akx_abort()
{
	char *x=NULL;

	*x = 0;
}
