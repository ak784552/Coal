static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testqnumber.c libakx_no_u8src.a -o testqnumber
*/
#include "akxcommon.h"
int main()
{
	char expbuf[256];
	int ret,num,iParm[4];
	double dVal;

	for (;;) {
		printf("Enter number==>");
		gets(expbuf);
		if (!stricmp(expbuf,"/EOF")) break;
		ret = akxqnumber(expbuf,strlen(expbuf),0,iParm);
		printf("ret=%d iParm=%d %d %d %d\n",ret,iParm[0],iParm[1],iParm[2],iParm[3]);
	}
	exit(0);
}
