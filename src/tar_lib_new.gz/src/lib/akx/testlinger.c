static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
 cc -g -DLINUX -I../include testlinger.c cpfcom.a ../xcom/akxcom.a -o testlinger
*/
#include "cpfcommon.h"
main()
{
	int n,i,m;
	char buf[256],*argv[4],*p;

	for (;;) {
		printf("cpfServiceProtoLinger()     ==> 1\n");
		printf("cpfHostServiceProtoLinger() ==> 2\n");
		printf("Exit                        ==> else\n");
		gets(buf);
		i = atoi(buf);
		if (i == 1) {
			for (;;) {
				printf("Enter Service(service/type%%linger):");
				gets(buf);
				if (buf[0] == ';') break;
				n = cpfServiceProtoLinger(buf,argv);
				printf("n=%d\n",n);
				for (i=0;i<3;i++) printf("argv[%d]=[%s]\n",i,argv[i]);
			}
		}
		else if (i == 2) {
			for (;;) {
				printf("Enter HostService(host:service/type%%linger):");
				gets(buf);
				if (buf[0] == ';') break;
				n = cpfHostServiceProtoLinger(buf,argv);
				printf("n=%d\n",n);
				for (i=0;i<4;i++) {
					if (!(p=argv[i])) p = "(null)";
					printf("argv[%d]=[%s]\n",i,p);
				}
			}
		}
		else break;
	}
}
