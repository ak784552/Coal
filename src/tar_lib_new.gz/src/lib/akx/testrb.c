static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DSUNOS -I../include testrb.c akxcom.a -o testrb
*/
#include "akxcommon.h"
main()
{
	tdtRbCtl *pRbCtl;
	char c,buf[128],*p;
	int n;

	pRbCtl = akxs_rb_init(0,0);
	for(;;) {
		printf("Enter End/SetN n/SetT n/Get/GetN/Read cmd:");
		gets(buf);
		if ((c=*buf) == 'E') break;
		else if (c == 'S') {
			n = atoi(buf+2);
			if (buf[1] == 'N') akxs_rb_set_n(pRbCtl,n);
			else akxs_rb_set_t(pRbCtl,n);
			printf("Set n=%d\n",n);
		}
		else if (c == 'G') {
			if (buf[1] == 'N') p = akxs_rb_get_n(pRbCtl);
			else p = akxs_rb_get(pRbCtl);
			printf("Get p=%08x\n",p);
		}
		else if (c == 'R') {
			n = atoi(buf+1);
			p = akxs_rb_read(pRbCtl,n);
			printf("Read p=%08x\n",p);
		}
		sub1(pRbCtl); sub2(pRbCtl);
	}
}

sub1(pCt)
tdtRbCtl *pCt;
{
	printf("pCt->rb_num = %d\n",pCt->rb_num);
	printf("pCt->rb_used = %d\n",pCt->rb_used);
	printf("pCt->rb_pos = %d\n",pCt->rb_pos);
	printf("pCt->rb_raddr = %08x\n",pCt->rb_raddr);
	printf("pCt->rb_waddr = %08x\n",pCt->rb_waddr);
	printf("pCt->rb_wpriv = %08x\n",pCt->rb_wpriv);
	printf("pCt->rb_cur   = %08x\n",pCt->rb_cur);
}

sub2(pCt)
tdtRbCtl *pCt;
{
	tdtRbChain *pw, *pn, *pp;

	pw = pCt->rb_raddr;
	for (;;) {
		printf("self = %08x, cpBuff = %08x, next = %08x\n",pw,pw->rbc_buf,pw->rbc_next);
		pw = pw->rbc_next;
		if (pw == pCt->rb_raddr) break;
	}
}
