#include <stdio.h>
int main()
{
	double a,b;
	a=b=107.39;
	printf("a/b %f\n",a/b);
	exit(0);
}
