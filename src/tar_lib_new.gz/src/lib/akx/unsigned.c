#include <stdio.h>
#include "akxcommon.h"
/*
	cc -DLINUX -I../include unsigned.c
*/
main()
{
	int i,i1,i2;
	uint ui,ui1,ui2;
	long L;
	ulong uL;
	short s;
	ushort us;

	i1 = -10;
	i2 = -2;
	printf("i1=%d i2=%d i1/i2=%d\n",i1,i2,i1/i2);

	ui1 = -10;
	ui2 = -2;
	printf("%%u: ui1=%u ui2=%u ui1/ui2=%u\n",ui1,ui2,ui1/ui2);
	printf("%%d: ui1=%d ui2=%d ui1/ui2=%d\n",ui1,ui2,ui1/ui2);

	printf("%%u: i1/ui2=%u\n",i1/ui2);
	printf("%%d: i1/ui2=%d\n",i1/ui2);

	printf("%%u: ui1/i2=%u\n",ui1/i2);
	printf("%%d: ui1/i2=%d\n",ui1/i2);

	i1 = -10;
	i2 = 2;
	printf("i1=%d i2=%d i1/i2=%d\n",i1,i2,i1/i2);

	ui1 = -10;
	ui2 = 2;
	printf("%%u: ui1=%u ui2=%u ui1/ui2=%u\n",ui1,ui2,ui1/ui2);
	printf("%%d: ui1=%d ui2=%d ui1/ui2=%d\n",ui1,ui2,ui1/ui2);

	printf("%%u: i1/ui2=%u\n",i1/ui2);
	printf("%%d: i1/ui2=%d\n",i1/ui2);

	printf("%%u: ui1/i2=%u\n",ui1/i2);
	printf("%%d: ui1/i2=%d\n",ui1/i2);

	printf("%%u: X_MAX(ui1,i2)=%u\n",X_MAX(ui1,i2));
	printf("%%d: X_MAX(ui1,i2)=%d\n",X_MAX(ui1,i2));

	printf("%%u: X_MAX(i1,ui2)=%u\n",X_MAX(i1,ui2));
	printf("%%d: X_MAX(i1,ui2)=%d\n",X_MAX(i1,ui2));
	
	ui = i;
	printf("ui=%u\n",ui);

	printf("ui / (-10)=%u -10=%u\n",ui / (-10),-10);
	i = ui;
	printf("i=%d\n",i);

	i = 2147483647;
	ui = 2147483647;
	printf("i+ui=%d\n",i+ui);

	s = 32767;
	us = 32767;
	printf("s+us=%d\n",s+us);

	ui = 3;
	ui1 = 5;
	ui2 = ui - ui1;
	printf("ui2=%u ui2=%d\n",ui2,ui2);
	ui = 0;
	ui--;
	printf("ui=%u\n",ui);
}
