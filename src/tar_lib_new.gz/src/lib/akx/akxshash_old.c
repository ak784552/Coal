static char sccsid[]="%Z% %M% %I% %E% %U%";
/************************************************/
/*												*/
/*	akxshash.c									*/
/*												*/
/*		  coded by A.Kobayashi 2010/5/20		*/
/*												*/
/*	error code : -185140101 �` -185149999		*/
/************************************************/
#include "akxcommon.h"

#define DEBUGP(x)

#define MULTI	AKX_HASX_MULTIPLIER2
static int lMULTIPLIER =MULTI;
static int lMULTIPLIER2=MULTI*MULTI;
static int lMULTIPLIER3=MULTI*MULTI*MULTI;
static int lMULTIPLIER4=MULTI*MULTI*MULTI*MULTI;

static int _hashr();
static int _hashs();
static int _hashd();
static int _hashi();
static int _hashk();
static int _hashp();
static int _hashu();
static int _hashf();
static int _hashfunc();

/* -1,-2 */
#define _SETUP(kpp,plalen,aux_klen) {	\
	ret = 0; \
	i = hp->ha_hix;	\
	kp = hp->ha_key;	\
	if (!i && !kp) ret = -1;	\
	rp = hp->ha_reg;	\
	en = hp->ha_next;	\
	np = en + hp->ha_maxreg;	\
	fn = np + hp->ha_maxreg;	\
	klen = hp->ha_keylen;	\
	if (klen > 0) len1 = klen + 1;	\
	else {	\
		rpp  = (char **)rp;	\
		used = rp + (hp->ha_maxreg+1)*sizeof(char *);	\
	}	\
	if (kp) {	\
		lklen = _getkey(klen,kp,kpp,plalen,aux_klen);	\
		if (lklen < 0) return lklen;	\
		if (iCASE) kp = _dupcasekey(kp,lklen);	\
	}	\
	if (i > 0) {	\
		if (kp && i>hp->ha_prereg) ret = -2;	\
	}	\
	else i=_hashf(kp,lklen,hp->ha_prereg);	\
	hp->ha_aux = i;	\
}

/* 01 -185140101 */
int akxshasxn(func,hp,aux_klen)
char func;
HASHB *hp;
int aux_klen;
{
	int i,ilen,opt,imaxlen,iCASE;
	uchar *hkey,*kp,cmd,c,cc;
	ulong ulkey[2];
	char *argv[2];

	if (!hp) return -185140101;

	cmd = akxcupper(func);
	if ((c=hp->ha_id[1])=='L' || c=='2') {
		if (cmd == 'I') {
			if (c == 'L') i = akxshasl(func,hp);
			else i = akxshasl2(func,hp);
		}
		else {
			kp = (uchar *)hp->ha_key;
			if (cmd!='P' && !kp) return -185140102;
			hp->ha_key = (char *)argv;
			hkey = (uchar *)ulkey;
			argv[0] = hkey;
			argv[1] = 0;
			ilen = hp->ha_keylen;
			if (cmd=='K' || cmd=='P') ;
			else {
				if (c == 'L') imaxlen = sizeof(long);
				else imaxlen = sizeof(long)*2;
				if (ilen == imaxlen) memcpy(hkey,kp,imaxlen);
				else {
					ulkey[0] = ulkey[1]=0;
					memcpy(hkey,kp,ilen);
				}
				if (c == 'L') argv[0] = (char *)ulkey[0];
			}
			if (c == 'L') i = akxshasl(func,hp);
			else i = akxshasl2(func,hp);

			hp->ha_key = (char *)kp;
			if (cmd == 'K') {
				if (c == 'L') memcpy(kp,&argv[0],ilen);
				else memcpy(kp,hkey,ilen);
			}
			else if (cmd == 'P') hp->ha_key = argv[0];
		}
		return i;
	}

	cc = hp->ha_id[0];
	c = toupper(cc);
	if (c == AKX_HASX_ID_NO_NEXT) opt = AKX_HASX_OPT_NO_NEXT;
	else opt = 0;
	if (c == cc) iCASE = 0;
	else iCASE = 1;

	switch (akxcupper(func)) {
		case 'R':
			i = _hashr(hp,aux_klen,iCASE);
			break;
		case 'S':
			i = _hashs(hp,aux_klen,opt,iCASE);
			break;
		case 'D':
			i = _hashd(hp,aux_klen,iCASE);
			break;
		case 'I':
			opt = hp->ha_aux;
			i = _hashi(hp,opt);
			break;
		case 'K':
			i = _hashk(hp);
			break;
		case 'P':
			i = _hashp(hp);
			break;
		case 'U':
			i = _hashu(hp);
			break;
		case 'F':
			i = _hashfunc(hp,aux_klen,iCASE);
			break;
		default:
			i = -185140103;
	}
	return i;
}

int akxshasx(func,hp)
char func;
HASHB *hp;
{
	akxshasxn(func,hp,0);
}

/* 02 -185140201 */
static int _hashi(hp,opt)
HASHB *hp;
int   opt;
{
	int i,j,mx,m1,*np;
	int klen,len1,aux;
	char *rp,**rpp;

	i = 0;
	if ((mx=hp->ha_maxreg)<=0) i -= 4;
	if ((m1=hp->ha_prereg)<=0) i -= 8;
	if (m1 >= mx) i -= 16;
	if (!(rp=hp->ha_reg))  i -= 32;
	if (!(np=hp->ha_next)) i -= 64;

	if (i >= 0) {
		klen = hp->ha_keylen;
		if (klen > 0) {
			len1 = klen + 1;
			for (j=0;j<mx;j++) {
				*rp = 0;
				rp += len1;
			}
		}
		else {
			memset(rp,0,(mx+1)*(sizeof(int)+1));
			if (!((aux=hp->ha_aux) & (AKX_HASX_OPT_USE_MALLOC | AKX_HASX_OPT_TMP_MALLOC))) {
				rpp = (char **)rp;
				if (aux & AKX_HASX_OPT_RESET_MEM) akxm_cct_reset((tdtCONSTCT *)rpp[0]);
				else rpp[0] = (char *)akxm_cct_mem_new(mx*32);
			}
		}
		memset(np,0,mx*sizeof(int)*2);
		np += mx*2;
		for (j=0;j<mx;j++) np[j] = j + 1;
		np[mx] = 0;
	}
	return i;
}

/* 03 -185140301 */
static int _getkey(klen,p,kpp,plalen,aux_klen)
int klen,*plalen,aux_klen;
char *p,**kpp;
{
	int ret,lalen;

	if (!klen && aux_klen>0) {
		if (kpp) *kpp = p;
		if (plalen) *plalen = aux_klen + 1;
		ret = aux_klen;
	}
	else {
		ret = akxt_get_gep_data(klen,p,kpp,plalen);
		if (ret == -1) ret = -1031;
		else if (ret == -2) ret = -1026;
	}
	return ret;
}

/* 04 -185140401 */
static int _cmpkey(klen,kp,lklen,p,aux_klen)
int klen,lklen,aux_klen;
char *kp,*p;
{
	int ret;
	if (!kp) return 0;
	if (!klen && aux_klen>0) {
		ret = strncmp(kp,p,aux_klen);
/*
printf("_cmpkey: ret=%d klen=%d kp=[%s] lklen=%d p=[%s] aux_klen=%d\n",
ret,klen,strmem(kp,aux_klen),lklen,p,aux_klen);
*/
	}
	else {
		ret = akxt_cmp_gep_data(klen,kp,lklen,p);
		if (ret == -256) ret = -1032;
		else if (ret == -257) ret = -1027;
	}
	return ret;
}

/* 05 -185140501 */
static int _setkey(klen,kp,lklen,lalen,rp,used,i,m_alloc,pConstCt)
int klen,lklen,lalen,i;
char *kp,*rp,*used;
char *(*m_alloc)();
tdtCONSTCT *pConstCt;
{
	char *p,**rpp;

	if (!kp) return i;
	if (klen > 0) {
		p = rp + (i-1)*(klen+1);
		*p = 1;
		memcpy(p+1,kp,klen);
	}
	else {
		p = used + i - 1;
		*p = 1;
		rpp=(char **)rp;
		if (m_alloc) {
			p = akxm_malloc_constct(m_alloc,pConstCt,lalen);
		}
		else if (rpp[0]) {
			p = akxm_cct_malloc(rpp[0],lalen);
		}
		else {
			p = rpp[i];
			if (p) p = Realloc(p,lalen);
			else p = Malloc(lalen);
		}
		if (!p) return -1028;
		rpp[i] = p;
		if (klen < 0) {
			memcpy(p,&lklen,sizeof(int));
			memcpy(p+sizeof(int),kp,lklen);
		}
		else memcpy(p,kp,lalen);
	}
	return i;
}

/* 06 -185140601 */
static char *_dupcasekey(kp,lklen)
char *kp;
int lklen;
{
#if 1	/* 2022.6.4 */
	static char wrk[256],*p0=NULL;
	char *case_key;
	int wrk_len;

	wrk_len = sizeof(wrk);
	if ((lklen=akxmemwork(lklen,&case_key,&p0,wrk,wrk_len)) < 0) {
		case_key = wrk;
		wrk_len--;
		lklen = X_MIN(lklen,wrk_len);
	}
#else
	static char *case_key=NULL;
	static int  case_key_len=0;

	if (case_key) {
		if (lklen > case_key_len) {
			case_key = Realloc(case_key,lklen+1);
			case_key_len = lklen;
		}
	}
	else {
		case_key = Malloc(lklen+1);
		case_key_len = lklen;
	}
#endif
	akxcuppern(case_key,kp,lklen);
	*(case_key+lklen) = '\0';
	return case_key;
}

/* 07 -185140701 */
static int _hashs(hp,aux_klen,opt,iCASE)
HASHB *hp;
int   aux_klen,opt,iCASE;
{
	int i,*np,k,ih,*en,*fn,ret;
	char *p,*kp,*rp,**rpp,*used,f;
	int len1,klen;
	int ldlen,lklen,lalen;
	tdtAllocCtl *pAC;
	char *(*m_alloc)();
	tdtCONSTCT *pConstCt;

	_SETUP(&kp,&lalen,aux_klen)
	if (ret < 0) return -185140750+ret;

	ih = i;
DEBUGP(printf("hashs: ih=%d key=[%s]\n",ih,hp->ha_key);)

	if (i=en[ih-1]) {
  L10:
DEBUGP(printf("hashs: i=%d\n",i);)
		if (klen>0) p = rp + (i-1)*len1 + 1;
		else p = rpp[i];
		if (!_cmpkey(klen,kp,lklen,p,aux_klen)) return i;
		if (opt & AKX_HASX_OPT_NO_NEXT) return 0;
		if ((k=np[i-1]) > 0) {
			i = k;
			goto L10;
		}
		en = np;
	}
	else i = ih;

	if (!(k = fn[0])) return 0;
DEBUGP(printf("hashs: k=%d\n",k);)
	fn[0] = fn[k];
	en[i-1] = k;
	np[k-1] = 0;
	if (hp->ha_id[1] == 'M') {
		pAC = (tdtAllocCtl *)rpp[0];
		m_alloc  = pAC->ac_malloc;
		pConstCt = pAC->ac_constct;
	}
	else {
		m_alloc  = NULL;
		pConstCt = NULL;
	}
	_setkey(klen,kp,lklen,lalen,rp,used,k,m_alloc,pConstCt);
	return k;
}

/* 08 */
static int _hashr(hp,aux_klen,iCASE)
HASHB *hp;
int aux_klen,iCASE;
{
	int i,*np,k,ih,*en,*fn,ret;
	char *p,*kp,*rp,**rpp,*used,f;
	int len1,klen;
	int ldlen,lklen;
	int count,i_start;

	_SETUP(&kp,NULL,aux_klen)
	if (ret < 0) return -185140850+ret;

	ih = i;
	if (i=en[ih-1]) {
  L10:
		if (klen > 0) p = rp + (i-1)*len1 + 1;
		else p = rpp[i];
		if (!_cmpkey(klen,kp,lklen,p,aux_klen)) return i;
		if ((i=np[i-1]) > 0) goto L10;
	}
	return 0;
}

/* 09 */
static int _hashd(hp,aux_klen,iCASE)
HASHB *hp;
int aux_klen,iCASE;
{
	int i,*np,k,ih,*en,*fn,ret;
	char *p,*kp,*rp,**rpp,*used,f;
	int len1,klen;
	int ldlen,lklen,s;
	int nsp[10],isp;

	_SETUP(&kp,NULL,aux_klen)
	if (ret < 0) return -185140950+ret;

	k = 0;
	ih = i;

	if (!(i=en[ih-1])) return 0;
  L10:
	if (klen>0) p = rp + (i-1)*len1 + 1;
	else p = rpp[i];
	if (_cmpkey(klen,kp,lklen,p,aux_klen)) {
		k = i;
		if ((i=np[i-1])>0) goto L10;
		return 0;
	}
	if (k) np[k-1] = np[i-1];
	else  en[ih-1] = np[i-1];
	isp = fn[0];
	fn[i] = isp;
	fn[0] = i;
	np[i-1] = 0;
	if (klen > 0) p = rp + (i-1)*len1;
	else {
		p = used + i - 1;
		rpp[i] = NULL;
	}
	*p = 0;
	return i;
}

/* 10 -185141001 */
static int _hashp(hp)
HASHB *hp;
{
	int i;
	char *p,*pk,**rpp;
	int len1,klen;

	if ((i=hp->ha_hix) <= 0 || i>hp->ha_maxreg) return -185141001;
	if ((klen=hp->ha_keylen) > 0) {
		len1 = klen + 1;
		p = hp->ha_reg+(i-1)*len1;
		pk = p + 1;
	}
	else {
		rpp = (char **)hp->ha_reg;
	/*	pk = rpp[i-1];	*/
		pk = rpp[i];
		p = hp->ha_reg + (hp->ha_maxreg+1)*sizeof(char *) + i - 1;
	}
	if (*p == 1) hp->ha_key = pk;
	else i = 0;
	hp->ha_hix = 0;
	return i;
}

/* 11 -185141101 */
static int _hashk(hp)
HASHB *hp;
{
	int i,klen;
	char *p,*pk;

	p = hp->ha_key;
	if ((i = _hashp(hp)) > 0) {
		pk = hp->ha_key;
		if (hp->ha_key = p) {
			klen = hp->ha_keylen;
			if (!klen) {
				strcpy(p,pk);
			}
			else {
				if (klen < 0) {
					memcpy(&klen,pk,sizeof(int));
					if (klen < 0) return -185141101;
					klen += sizeof(int);
				}
				memcpy(p,pk,klen);
			}
		}
	}
	return i;
}

/* 12 */
static int _hashu(hp)
HASHB *hp;
{
	int x,i,max,n;
	char *p;

	p = hp->ha_key;
	x = hp->ha_hix;
	max = hp->ha_maxreg;
	n = 0;
	for (i=1;i<=max;i++) {
		hp->ha_hix = i;
		if (_hashp(hp) > 0) n++;
	}
	hp->ha_key = p;
	hp->ha_hix = x;
	return n;
}

/* 13 */
static int _hashf(kp,lklen,mso)
uchar *kp;
int lklen,mso;
{
	int i,k,klen,len,mult=lMULTIPLIER;
	uchar  uc,*p;
	uint  uk;

	klen = lklen;
	p = kp;
	if (klen >= 4) {
		k = *p++;
		for (i=1;i<klen;i++) {
			k = k*mult + *p++;
		}
	}
	else {
		if (klen == 1) {
			k = *p;
		}
		else if (klen == 2) {
			k = *p++;
			k = k*mult + *p;
		}
		else if (klen == 3) {
			k = *p++;
			k = k*mult + *p++;
			k = k*mult + *p;
		}
		else return 1;
	}
	uk = k;
	return uk%mso + 1;
}

/* 14 -185141401 */
static int _hashfunc(hp,aux_klen,iCASE)
HASHB *hp;
int aux_klen,iCASE;
{
	int i;
	char *kp,*kkp;
	int klen,lklen;

	if (!(kp = hp->ha_key)) return -185141401;
	lklen = _getkey(hp->ha_keylen,kp,&kkp,NULL,aux_klen);
	if (lklen < 0) return lklen;
	if (iCASE) kkp = _dupcasekey(kkp,lklen);
	i = _hashf(kkp,lklen,hp->ha_prereg);
	hp->ha_aux = i;
	return i;
}

/* 15 */
int akxs_hasx_pre_reg(lMaxReg,pre)
int lMaxReg,pre;
{
	int i,iMAX_SOSU,*sosu;
	int max,l,mso,m,ll,m1;

	max = lMaxReg;
	if ((mso=pre) >= 0) {
		if (mso<=0 || mso>1000) mso = 997;	/*731;*/
		if (mso==1000) l = max;
		else l = (max * mso)/1000;
	}
	else {
		if ((l = -pre) > max) l = max;
	}
	if (l > 3) {
		if (!(l & 0x01)) {
			if (l+1 < max) l++;
			else if (l > 1) l--;
		}
DEBUGP(printf("akxs_hasx_pre_reg: max=%d pre=%d\n",max,l);)
		iMAX_SOSU = akxg_sosu_tbl(&sosu);
		if (l > sosu[iMAX_SOSU-1]) {
			for (ll=l;ll<max;ll+=2) {
				if (akxg_sosu_chk(ll)) return ll;
			}
			for (ll=l-2;ll>7;ll-=2) {
				if (akxg_sosu_chk(ll)) return ll;
			}
		}
		else if (l > 7) {
			m1 = sosu[iMAX_SOSU-1];
			for (i=iMAX_SOSU-1;i>=0;i--) {
				if ((m=sosu[i])<=max && m<=l) {
					if (m1 > max) m1 = m;
					return m1;
				}
				m1 = m;
			}
		}
	}
	return l;
}

/* 16 -185141601 */
/********1*********2*********3*********4*********5*********7*/
/* ���� : iOpt    : �I�v�V����								*/
/*					0x01 : ignore case						*/
/*					0x02 : ignore ���p/�{�p					*/
/*					0x08 : not use akxm_cct_malloc()		*/
/*						   m_alloc<>NULL �̂Ƃ��́Aoff����	*/
/* �ԋp : �n�b�V���\����									*/
/*		  ha_id[0] = 'H' ignore case  �̂Ƃ��́A'h'			*/
/*		  ha_id[1] = 'X' m_alloc<>NULL�̂Ƃ��́A'M'			*/
/************************************************************/
HASHB *akxs_hasxm_new2(sKeyLen,lMaxReg,lPreReg,iOpt,m_alloc,pConstCt)
short sKeyLen;
int   lMaxReg,lPreReg,iOpt;
char    *(*m_alloc)();
tdtCONSTCT *pConstCt;
{
	HASHB *tph;
	int l,pre;
	int  iCASE;
	char c,**rpp;
	tdtAllocCtl *pAC;

	if (!(iCASE = iOpt & AKX_HASX_OPT_CASE_KEY)) {
		/* long�܂���long*2�����̃L�[���̂Ƃ��́A�s�������N���A����K�v������B
		   �����ŁA�L�[�����n�b�V���\���̂ɕۑ����Ă����Aakxshasx()����akxshasl()
		   �܂���akxshasl2()���ĂԑO�ɕs�������N���A���鎞�ɗ��p����B*/
		if (sKeyLen>0 && sKeyLen<=sizeof(long))
			return akxs_hasl_new2(sKeyLen,lMaxReg,lPreReg,iOpt);
		/*	return akxs_hasl_new2(sizeof(long),lMaxReg,lPreReg,iOpt);	*/
		else if (sKeyLen>sizeof(long) && sKeyLen<=sizeof(long)*2)
			return akxs_hasl2_new2(sKeyLen,lMaxReg,lPreReg,iOpt);
		/*	return akxs_hasl2_new2(sizeof(long)*2,lMaxReg,lPreReg,iOpt);	*/
	}
/*	if (lMaxReg<2 || lPreReg<0 || (lPreReg>0 && lMaxReg<=lPreReg)) {	*/
	if (lMaxReg<2 || lPreReg<0) {
		errno = -185141601;
		return NULL;
	}
	if (lPreReg > 0) {
		if (lMaxReg <= lPreReg) {
			errno = -185141602;
			return NULL;
		}
	}
	if (!(l=lPreReg)) {
		pre = 0;
		if ((l=akxs_hasx_pre_reg(lMaxReg,pre)) < 1) {
			errno = -185141603;
			return NULL;
		}
DEBUGP(printf("akxs_hasx_new2: l=%d\n",l);)
	}

	if (!(tph=(HASHB *)akxm_malloc_constct(m_alloc,pConstCt,sizeof(HASHB)))) {
		errno = -185141604;
		return NULL;
	}
	memset(tph,0,sizeof(HASHB));
	c = 'H';
	if (iOpt & AKX_HASX_OPT_NO_NEXT) c = AKX_HASX_ID_NO_NEXT;
	if (iCASE) c = tolower(c);
	tph->ha_id[0] = c;
/*
printf("akxs_hasx_new: id=%c\n",c);
*/
	c = 'X';
	if (m_alloc) {
		c = 'M';
		iOpt &= AKX_HASX_OPT_USE_MALLOC;
		iOpt |= AKX_HASX_OPT_TMP_MALLOC;
	}
	tph->ha_id[1] = c;
	tph->ha_keylen = sKeyLen;
	tph->ha_maxreg = lMaxReg;
	tph->ha_prereg = l;
	tph->ha_aux    = iOpt;
	tph->ha_hix    = 0;

	if (sKeyLen > 0) l = lMaxReg*(sKeyLen+1);
	else l = (lMaxReg+1)*(sizeof(char *)+1);
	if (!(tph->ha_reg=akxm_malloc_constct(m_alloc,pConstCt,l))) {
		akxs_hasx_free(tph);
		errno = -185141605;
		return NULL;
	}
	memset(tph->ha_reg,0,l);

	l = lMaxReg*sizeof(int);
	if (!(tph->ha_next=(int *)akxm_malloc_constct(m_alloc,pConstCt,l*3+sizeof(int)))) {
		akxs_hasx_free(tph);
		errno = -185141606;
		return NULL;
	}
	if (errno=akxshasx('i',tph)) {
		akxs_hasx_free(tph);
		return NULL;
	}
	/* (iOpt & AKX_HASX_OPT_USE_MALLOC)==0 && (iOpt & AKX_HASX_OPT_TMP_MALLOC)==0 �̂Ƃ��́A
	    ��L�ŁArpp[0]�́Aakxm_cct_mem_new()�ŁA�ݒ肳��Ă��� */
	if (m_alloc) {
		if (!(pAC = (tdtAllocCtl *)akxm_malloc_constct(m_alloc,pConstCt,sizeof(tdtAllocCtl)))) {
			errno = -185141607;
			akxs_hasx_free(tph);
			return NULL;
		}
		pAC->ac_malloc = m_alloc;
		pAC->ac_constct = pConstCt;
		rpp = (char **)tph->ha_reg;
		rpp[0] = (char *)pAC;
	}
	/* rpp[0] ==NULL : key��Malloc()����Bklen��key�̕ۑ��`�����ς��B
	   m_alloc==NULL : rpp[0] : akxm_cct_mem_new()�ŁA�ݒ肳��Ă���B
	   m_alloc<>NULL : rpp[0] : pAC�ɂȂ��Ă���B */
	return tph;
}

/* 17 */
HASHB *akxs_hasx_new2(sKeyLen,lMaxReg,lPreReg,iOpt)
short sKeyLen;
int   lMaxReg,lPreReg,iOpt;
{
	return akxs_hasxm_new2(sKeyLen,lMaxReg,lPreReg,iOpt,NULL,NULL);
}

/* 18 */
HASHB *akxs_hasx_new(sKeyLen,lMaxReg,lPreReg)
short sKeyLen;
int  lMaxReg,lPreReg;
{
	return akxs_hasx_new2(sKeyLen,lMaxReg,lPreReg,0);
}

/* 19 */
/*************************************/
/* m_alloc==NULL�̂Ƃ��̂݁A���s���� */
/*************************************/
int akxs_free_reg(maxreg,datlen,reg)
int maxreg,datlen;
char *reg;
{
	int i;
	char **rpp,*p;

	if (reg) {
		if (datlen <= 0) {
			rpp = (char **)reg;
			if (rpp[0]) {
				akxm_cct_mem_free((tdtCONSTCT *)rpp[0]);
			}
			else {
				rpp++;
				for (i=0;i<maxreg;i++) {
					if (p=*rpp++) Free(p);
				}
			}
		}
		Free(reg);
	}
	return 0;
}

/* 20 */
int akxs_hasx_free(tph)
HASHB *tph;
{
	int i;
	char **rpp,*p;

	if (tph) {
		if (tph->ha_id[1] == 'L') akxs_hasl_free(tph);
		else if (tph->ha_id[1] != 'M') {
			if (tph->ha_reg) {
				akxs_free_reg(tph->ha_maxreg,tph->ha_keylen,tph->ha_reg);
			}
			if (tph->ha_next) Free(tph->ha_next);
			Free(tph);
		}
	}
	return 0;
}

/* 21 -185142101 */
int akxs_hasx_func(kp,lklen,mso,iCASE)
uchar *kp;
int lklen;
int mso,iCASE;
{
	if (!kp || !mso) return -185142101;
	if (iCASE) kp = _dupcasekey(kp,lklen);
	return _hashf(kp,lklen,mso);
}

/* 22 */
int akxs_hasx_set_mult(mult)
int mult;
{
	int l=lMULTIPLIER;

	if (mult>0) lMULTIPLIER = mult;
	else if (mult<0) lMULTIPLIER=AKX_HASX_MULTIPLIER2;
	lMULTIPLIER2 = mult * mult;
	lMULTIPLIER3 = lMULTIPLIER2 * mult;
	lMULTIPLIER4 = lMULTIPLIER3 * mult;
	return l;
}

/* 23 */
int akxs_hasx_get_key(p,klen,kpp,plalen)
char *p,**kpp;
int  klen,*plalen;
{
	return _getkey(klen,p,kpp,plalen,0);
}

static int _xhashf();
static int _xhash_chk();
static int _xhash_used();
static int _xhash_max();

/* 41 */
/********1*********2*********3*********4*********5*********7*/
/* ���� : iDatLen : �ۑ�����f�[�^�̒���					*/
/*					> 0 : �Œ蒷							*/
/*					= 0 : string							*/
/*					=-1 : �擪�Ƀf�[�^��������				*/
/*					=-2 : �f�[�^��ۑ����Ȃ�				*/
/*		  iOpt    : �I�v�V����								*/
/*					0x01 : ignore case						*/
/*					0x02 : ignore ���p/�{�p					*/
/*					0x08 : not use akxm_cct_malloc()		*/
/*						   m_alloc<>NULL �̂Ƃ��́Aoff����	*/
/************************************************************/
XHASHB *akxs_xhashm_new2(sKeyLen,lMaxReg,lPreReg,lDatLen,iOpt,m_alloc,pConstCt)
short sKeyLen;
int  lMaxReg,lPreReg,lDatLen,iOpt;
char    *(*m_alloc)();
tdtCONSTCT *pConstCt;
{
	XHASHB *p;
	int l;
	char c;
/*
printf("akxs_xhashm_new2: sKeyLen=%d lMaxReg=%d lPreReg=%d lDatLen=%d iOpt=%08x\n",
sKeyLen,lMaxReg,lPreReg,lDatLen,iOpt);
*/
	if (lMaxReg<2 || lPreReg<0 ||
	    (lPreReg>0 && lMaxReg<=lPreReg)) {
		errno = -1301;
		return NULL;
	}
	if (!(l=lPreReg)) {
		if ((l = akxs_hasx_pre_reg(lMaxReg,0)) < 1) {
			errno = -1302;
			return NULL;
		}
	}
	p = (XHASHB *)akxm_malloc_constct(m_alloc,pConstCt,sizeof(XHASHB));
	if (!p) {
		errno = -1303;
		return NULL;
	}

	if (m_alloc) {
		iOpt &= ~AKX_HASX_OPT_USE_MALLOC;
		iOpt |= AKX_HASX_OPT_TMP_MALLOC;
	}

	c = 'H';
	if (iOpt & AKX_HASX_OPT_CASE_KEY) c = toupper(c);
	p->xha_id[0] = c;

	if (sKeyLen>0 && sKeyLen<=sizeof(long)) c = 'L';
	else if (sKeyLen>sizeof(long) && sKeyLen<=sizeof(long)*2) c = '2';
	else c = 'X';
	p->xha_id[1] = c;
	p->xha_keylen = sKeyLen;
	p->xha_maxreg = lMaxReg;
	p->xha_prereg = l;
	p->xha_datlen = lDatLen;
	p->xha_option = iOpt;
	p->xha_xhix   = 0;
	p->xha_hashb  = NULL;
	p->xha_xhnext = NULL;
	p->xha_datreg = NULL;
	p->xha_malloc = m_alloc;
	p->xha_constct= pConstCt;
	return p;
}

XHASHB *akxs_xhash_new2(sKeyLen,lMaxReg,lPreReg,lDatLen)
short sKeyLen;
int  lMaxReg,lPreReg,lDatLen;
{
	return akxs_xhashm_new2(sKeyLen,lMaxReg,lPreReg,lDatLen,0,NULL,NULL);
}

XHASHB *akxs_xhash_new(sKeyLen,lMaxReg,lPreReg)
short sKeyLen;
int  lMaxReg,lPreReg;
{
	return akxs_xhash_new2(sKeyLen,lMaxReg,lPreReg,-2);
}

XHASHB *akxs_xhash_init(sKeyLen,lMaxReg,lPreReg)
short sKeyLen;
int  lMaxReg,lPreReg;
{
	return akxs_xhash_new(sKeyLen,lMaxReg,lPreReg);
}

int akxs_xhash_free(tpxhashb)
XHASHB *tpxhashb;
{
	HASHB *tph;
	char *p;

/*
printf("akxs_xhash_free:tpxhashb=%08x\n",tpxhashb);
*/
	if (tpxhashb) {
		if (tph=tpxhashb->xha_hashb) {
			akxs_hasx_free(tph);
		}
		if (!tpxhashb->xha_malloc && (p=tpxhashb->xha_datreg)) {
			akxs_free_reg(tpxhashb->xha_maxreg,tpxhashb->xha_datlen,p);
		}
		akxs_xhash_free(tpxhashb->xha_xhnext);
		Free(tpxhashb);
	}
	return 0;
}

int akxs_xhashn2(tpxhashb,cCmnd,cpKey,aux_klen,cppDat)
XHASHB *tpxhashb;
char cCmnd, *cpKey;	/* 'P' or 'p' �̂Ƃ��́A				*/
					/* �n�b�V�������̃L�[��̐擪�A�h���X��	*/
					/* ����|�C���^�̃A�h���X��ݒ肷��	*/
int  aux_klen;
char **cppDat;		/* cCmnd='S'or's'�̂Ƃ��́A(char *)�Ɠǂݑւ��� */
					/* ���̂Ƃ��́A�ۑ�����f�[�^��̐擪�A�h���X��ݒ肷��	*/
					/* cCmnd='R'or'r' or 'D' or 'd' or�A		*/
					/* 'P' or 'p' or 'K' or 'k' �̂Ƃ���		*/
					/* �n�b�V�������̃f�[�^��̐擪�A�h���X��	*/
					/* ����|�C���^�̃A�h���X��ݒ肷��		*/
{
	XHASHB *tpcur,*tpnext;
	int l,i,offset,len;
	HASHB *tph,ha;
	int ret,opt;
	char cCmd,c,cc;
/*
printf("akxs_xhash: tpxhashb=%08x cCmnd=%c cpKey=%08x cppDat=%08x\n",
tpxhashb,cCmnd,cpKey,cppDat);
*/
	if (!tpxhashb) return -1;
	cCmd = akxcupper(cCmnd);
	switch (cCmd) {
		case 'R':
		case 'D':
/*
printf("akxs_xhash: cpKey=[%s]\n",cpKey);
*/
			if (cppDat) *cppDat = NULL;	/* add 2023.1.6 */
		case 'S':
			if (tpxhashb->xha_xhix) return _xhash_chk(tpxhashb,cCmd,cpKey,aux_klen,cppDat);
			break;
		case 'K':
		case 'P':
			return _xhash_chk(tpxhashb,cCmd,cpKey,aux_klen,cppDat);
		case 'U':
			return _xhash_used(tpxhashb);
		case 'M':
			return _xhash_max(tpxhashb);
		case 'F':
			if (!(tph=tpxhashb->xha_hashb)) {
				len = tpxhashb->xha_keylen;
#if 1
				tph = &ha;
				tph->ha_id[0] = tpxhashb->xha_id[0];
				tph->ha_id[1] = tpxhashb->xha_id[1];
#else
				if (len>0 && len<=sizeof(long)) c = 'L';
				else if (len>sizeof(long) && len<=sizeof(long)*2) c = '2';
				else c = 'X';
				tph = &ha;
				tph->ha_id[0]  = 'H';
				tph->ha_id[1]  = c;
#endif
				tph->ha_keylen = len;
				tph->ha_maxreg = tpxhashb->xha_maxreg;
				tph->ha_prereg = tpxhashb->xha_prereg;
			}
			tph->ha_key = cpKey;
			tph->ha_hix = 0;
			return akxshasxn(cCmd,tph,aux_klen);
		default:
			return -72;
	}
	if (!cpKey) return -73;
	l = 0;
	offset = 0;
	tpnext = tpxhashb;
	while (tpnext) {
		tpcur = tpnext;
		if (!(tph=tpcur->xha_hashb)) {
/*
printf("akxs_xhash:(%08x)->xha_hashb=NULL\n",tpcur);
*/
			if (cCmd == 'R' || cCmd == 'D') return 0;
#if 1	/* 2021.9.16 */
			if (!(tpcur->xha_option & AKX_HASX_OPT_CASE_KEY)) {
				cc = tpcur->xha_id[0];
				c = toupper(cc);
				if (c != cc) tpcur->xha_option |= AKX_HASX_OPT_CASE_KEY;
			}
			if (tph=akxs_hasxm_new2(tpcur->xha_keylen,tpcur->xha_maxreg,tpcur->xha_prereg,
			                        tpcur->xha_option,tpcur->xha_malloc,tpcur->xha_constct))
#else
			cc = tpcur->xha_id[0];
			c = toupper(cc);
			opt = tpcur->xha_option;
			if (c != cc) opt |= AKX_HASX_OPT_CASE_KEY;
			if (tph=akxs_hasxm_new2(tpcur->xha_keylen,tpcur->xha_maxreg,
			                     tpcur->xha_prereg,opt,tpcur->xha_malloc,tpcur->xha_constct))
#endif
				tpcur->xha_hashb = tph;
			else return errno;
/*
printf("akxs_xhash:len=%d maxreg=%d mso=%d\n",tph->ha_keylen,tph->ha_maxreg,tph->ha_prereg);
*/
		}
		tph->ha_key = cpKey;
#if 0
		if (!l) {
			if (!(l=tpcur->xha_xhix))
				l = akxshasx('f',tph);
/*
printf("akxs_xhash:l=%d\n",l);
*/
		}
		tph->ha_hix = l;
#else
		tph->ha_hix = 0;
#endif
	/********
		if (cCmd=='S' && cppDat && tpcur->xha_datlen == -2 && tph->ha_id[1]=='L')
			tph->ha_next = (char *)cppDat;
	*********/
		if (i=akxshasxn(cCmd,tph,aux_klen)) {
			if (i>0) {
				if ((ret=akxs_dreg_proc(tpcur,cCmd,i,cppDat))<0) return ret;
				i += offset;
			}
			return i;
		}
		tpnext = tpcur->xha_xhnext;
		offset += tpcur->xha_maxreg;
	}
/*
printf("akxs_xhash:(%08x)->xha_xhnext=NULL\n",tpcur);
*/
	if (cCmd == 'R' || cCmd == 'D') return i;
	if (!(tpnext=(XHASHB *)akxm_malloc_constct(tpcur->xha_malloc,tpcur->xha_constct,sizeof(XHASHB)))) return -76;
	tpcur->xha_xhnext = tpnext;
	memcpy(tpnext,tpcur,sizeof(XHASHB));
	tpnext->xha_xhix = l;
	tpnext->xha_hashb = NULL;
	tpnext->xha_xhnext = NULL;
	tpnext->xha_datreg = NULL;
	if ((i = akxs_xhashn2(tpnext,cCmd,cpKey,aux_klen,cppDat))>0) i += offset;
	tpnext->xha_xhix = 0;
	return i;
}

int akxs_xhash2(tpxhashb,cCmnd,cpKey,cppDat)
XHASHB *tpxhashb;
char cCmnd, *cpKey;
char **cppDat;
{
	return akxs_xhashn2(tpxhashb,cCmnd,cpKey,0,cppDat);
}

int akxs_xhashn(tpxhashb,cCmd,cpKey,aux_len)
XHASHB *tpxhashb;
char cCmd, *cpKey;
int  aux_len;
{
	return akxs_xhashn2(tpxhashb,cCmd,cpKey,aux_len,NULL);
}

int akxs_xhash(tpxhashb,cCmd,cpKey)
XHASHB *tpxhashb;
char cCmd, *cpKey;
{
	return akxs_xhashn2(tpxhashb,cCmd,cpKey,0,NULL);
}

int akxs_dreg_proc(tpX,cCmd,i,cppDat)
XHASHB *tpX;
int   i;
char   cCmd,**cppDat;
{
	HASHB *tph;
	char *cpDat,**drg,*p,*dp;
	int  dlen,len,alen,mx;
	char *(*m_alloc)();
	tdtCONSTCT *pConstCt;
/*
printf("akxs_dreg_proc: tpX=0x%08x,cCmd=[%c],i=%d,cppDat=0x%08x\n",tpX,cCmd,i,cppDat);
*/
	if (!cppDat) return 0;
	if ((dlen=tpX->xha_datlen) < -2) return 0;
	else if (dlen == -2) {
	/*********
		tph = tpX->xha_hashb;
		if (tph->ha_id[1]=='L' && (cCmd=='R' || cCmd=='D'))
			*cppDat = (char *)tph->ha_next;
	*********/
		return 0;
	}
	p = tpX->xha_datreg;
/*
printf("akxs_dreg_proc: dlen=%d,p=0x%08x\n",dlen,p);
*/
	if (dlen > 0) alen = ((dlen+sizeof(int))/sizeof(int))*sizeof(int);
	if (cCmd == 'R' || cCmd == 'D') {
		if (p) {
			if (dlen > 0) cpDat = p + alen*(i-1);
			else {
				drg = (char **)p;
				cpDat = drg[i];
			}
		}
		else cpDat = NULL;
		*cppDat = cpDat;
/*
printf("akxs_dreg_proc: cpDat=[%s]\n",cpDat);
*/
	}
	else if (cCmd == 'S') {
		m_alloc  = tpX->xha_malloc;
		pConstCt = tpX->xha_constct;
		cpDat = (char *)cppDat;
		if (!p) {
			mx = tpX->xha_maxreg;
			if (dlen > 0) len = alen*mx;
			else len = sizeof(char **)*(mx+1);
			if (!(p=akxm_malloc_constct(m_alloc,pConstCt,len))) return -77;
			tpX->xha_datreg = p;
/*
printf("akxs_dreg_proc: dlen=%d,p=0x%08x\n",dlen,p);
*/
			if (dlen <= 0) {
				memset(p,0,sizeof(char **)*(mx+1));
				if (!(tpX->xha_option & (AKX_HASX_OPT_USE_MALLOC | AKX_HASX_OPT_TMP_MALLOC))) {
					drg = (char **)p;
					drg[0] = (char *)akxm_cct_mem_new(mx*32);
				}
			}
		}
		if (dlen > 0) {
			dp = p + alen*(i-1);
			memcpy(dp,cpDat,dlen);
			*(dp+dlen) = '\0';
		}
		else {
			drg = (char **)p;
		/*	if (dp=drg[i-1]) Free(dp);	*/
			if (dlen < 0) {
				memcpy(&len,cpDat,sizeof(int));
				len += sizeof(int);
			}
			else len = strlen(cpDat);
			alen = len + 1;
			if (tpX->xha_option & AKX_HASX_OPT_TMP_MALLOC)
				dp = akxm_malloc_constct(m_alloc,pConstCt,alen);
			else if (drg[0])
				dp = akxm_cct_malloc(drg[0],alen);
			else
				dp = Malloc(alen);
			if (!dp) return -78;
			memcpy(dp,cpDat,len);
			*(dp+len) = '\0';
			drg[i] = dp;
/*
printf("akxs_dreg_proc: dp=[%s]\n",dp);
*/
		}
	}
	return 0;
}

static int _xhashf(kp,len,mso,aux_klen,iCASE)
uchar *kp;
short len;
int mso,aux_klen,iCASE;
{
	uchar uc,*p=kp;
	int lklen;

	if (!kp) return -35;
	if (len > 0) lklen = len;
	else if (len < 0) {
		memcpy(&lklen,p,sizeof(int));
		if (lklen < 0) return -32;
		p += sizeof(int);
	}
	else if (aux_klen > 0) lklen = aux_klen;
	else
		lklen = strlen((char *)p);
	return akxs_hasx_func(p,lklen,mso,iCASE);
}

static int _xhash_chk(tpxhashb,cCmd,cpKey,aux_klen,cppDat)
XHASHB *tpxhashb;
char cCmd, *cpKey,**cppDat;
int  aux_klen;
{
	XHASHB *tpcur;
	int i,offset,max,next,ix;
	HASHB *tph;
	int ret;
	char cCmdw;

	ret = -1029;
	i = tpxhashb->xha_xhix;
	tpxhashb->xha_xhix = 0;
	offset = 0;
	tpcur = tpxhashb;
	max = tpcur->xha_maxreg;
	while (tpcur) {
		next = offset + max;
		if (next >= i) {
			ret = 0;
			if (tph=tpcur->xha_hashb) {
				tph->ha_hix = ix = i - offset;
				if (cCmd != 'P') tph->ha_key = cpKey;
				else if (cCmd=='S' && cppDat && tpcur->xha_datlen==-2 && tph->ha_id[1]=='L')
					tph->ha_next = (int *)cppDat;
				ret = akxshasxn(cCmd,tph,aux_klen);
				tph->ha_hix = 0;
/*
printf("_xhash_chk: cmd=%c i=%d ix=%d ret=%d\n",cCmd,i,ix,ret);
*/
				if (ret > 0) {
					if ((cCmdw=cCmd)=='P' || cCmdw=='K') cCmdw = 'R';
					if ((ret=akxs_dreg_proc(tpcur,cCmdw,ix,cppDat))<0) return ret;
					if ((cCmd == 'P') && cpKey) *(char **)cpKey = tph->ha_key;
					return i;
				}
			}
			break;
		}
		tpcur = tpcur->xha_xhnext;
		offset = next;
	}
	return ret;
}

static int _xhash_used(tpxhashb)
XHASHB *tpxhashb;
{
	XHASHB *tpcur;
	int ret,count;
	HASHB *tph;

	count = 0;
	tpcur = tpxhashb;
	while (tpcur) {
		tpcur->xha_xhix = 0;
		if (tph=tpcur->xha_hashb) {
			ret = akxshasx('U',tph);
		/*	tpcur->xha_xhix = ret;	*/
			if (ret > 0) count += ret;
		}
		tpcur = tpcur->xha_xhnext;
	}
	return count;
}

static int _xhash_max(tpxhashb)
XHASHB *tpxhashb;
{
	XHASHB *tpcur;
	int ret,m;
	HASHB *tph;

	m = 0;
	tpcur = tpxhashb;
	while (tpcur) {
		m += tpcur->xha_maxreg;
		tpcur = tpcur->xha_xhnext;
	}
	return m;
}


int akxs_xhash_reset(tpxhashb)
XHASHB *tpxhashb;
{
	HASHB *tph;
	int i;
	char **rpp,*p;

/*
printf("akxs_xhash_reset:tpxhashb=%08x\n",tpxhashb);
*/
	if (tpxhashb) {
		if (tph=tpxhashb->xha_hashb) {
			tph->ha_aux = AKX_HASX_OPT_RESET_MEM;
			akxshasx('I',tph);
		}
		if (p=tpxhashb->xha_datreg) {
			if (tpxhashb->xha_datlen <= 0) {
				rpp = (char **)p;
				if (rpp[0]) akxm_cct_reset((tdtCONSTCT *)rpp[0]);
			}
		}
		akxs_xhash_reset(tpxhashb->xha_xhnext);
	}
	return 0;
}

static int _srami(hp)
HASHB *hp;
{
	int i=0;

	if (hp->ha_maxreg <= 0) i-=4;
	if (!hp->ha_reg) i -= 8;

	if (i >= 0) {
		memset(hp->ha_reg,0,hp->ha_maxreg);
	}

	return i;
}

static int _sramf_sub(c,opt)
char c;
int opt;
{
	int i;
/*
printf("_sramf_sub:Enter: c=[%c] opt=%d\n",c,opt);
*/
	i = 0;
	if (!c) i = 0;
	else if (c == '_') i = 1;
	else if (c>='A' && c<='Z') i = c - 'A' + 2;
	else if (opt >= 1) {
		if (c>='a' && c<='z') i = c - 'a' + 27 + 1;
		else if (opt >= 2) {
			if (c>='0' && c<='9') i = c - '0' + 27 + 26 + 1;
		}
	}
/*
printf("_sramf_sub:Exit: i=%d\n",i);
*/
	return i;
}

static int _sramf(hp)
HASHB *hp;
{
	int i,j,klen,opt,opt1;
	char *kp;

	if ((i=hp->ha_hix) > 0) {
		if (i > hp->ha_maxreg) i = -1;
/*
printf("_sramf:Exit: i=%d\n",i);
*/
	}
	else {
		opt1 = opt = hp->ha_aux;
		if (opt1 == 2) opt1 = 1;
		kp = hp->ha_key;
		if ((klen=hp->ha_keylen) > 2) klen = 2;
		i = _sramf_sub(*kp,opt1);
		if (i>0 && klen==2) {
			j = _sramf_sub(*(kp+1),opt);
			if (j > 0) i = i*hp->ha_prereg + j;
		}
/*
printf("_sramf:Exit: i=%d key=[%s]\n",i,kp);
*/
	}
	return i;
}

int akxs_sram(func,hp)
char func;
HASHB *hp;
{
	int i;
	char c,*p;
/*
printf("akxs_sram:Enter: func=[%c]\n",func);
*/
	if (!hp) i = -1;
	else if (func=='i' || func=='I') i = _srami(hp);
	else if ((i=_sramf(hp)) > 0) {
		p = hp->ha_reg + (i-1);
		if (func=='r' || func=='R') {
			if (!*p) i = 0;
		}
		else if (func=='s' || func=='S') *p = '1';
		else if (func=='d' || func=='D') *p = '\0';
		else i = -2;
	}
/*
printf("akxs_sram:Exit: i=%d\n",i);
*/
	return i;
}

HASHB *akxs_sram_new(sKeyLen,opt)
short sKeyLen;
int opt;
{
	HASHB *tph;
	int lMaxReg,pre;
	char c1,c2,key[3];
/*
printf("akxs_sram_new:Enter: sKeyLen=%d opt=%d\n",sKeyLen,opt);
*/
	if (sKeyLen <= 0) return NULL;
	else if (sKeyLen > 2) sKeyLen = 2;
	if (!(tph=(HASHB *)Malloc(sizeof(HASHB)))) return NULL;
	memset(tph,0,sizeof(HASHB));
	tph->ha_id[0] = 'R';
	tph->ha_id[1] = 'A';
	if (opt <= 0) {
		opt = 0;
		c1 = c2 = 'Z';
		pre = 27;
	}
	else if (opt == 1) {
		c1 = c2 = 'z';
		pre = 27 + 26;
	}
	else {
		opt = 2;
		c1 = 'z';
		c2 = '9';
		pre = 27 + 26 + 10;
	}
	key[0] = c1;
	key[1] = c2;
	key[2] = '\0';
	tph->ha_keylen = sKeyLen;
	tph->ha_key = key;
	tph->ha_aux = opt;
	tph->ha_prereg = pre;
	tph->ha_maxreg = lMaxReg = _sramf(tph);
/*
printf("akxs_sram_new: key=[%s] lMaxReg=%d\n",key,lMaxReg);
*/
	if (!(tph->ha_reg=Malloc(lMaxReg))) {
		Free(tph);
		return NULL;
	}
	if (akxs_sram('i',tph)) {
		akxs_sram_free(tph);
		return NULL;
	}
	return tph;
}

int akxs_sram_free(tph)
HASHB *tph;
{
	if (tph) {
		if (tph->ha_reg) Free(tph->ha_reg);
		Free(tph);
	}
	return 0;
}
