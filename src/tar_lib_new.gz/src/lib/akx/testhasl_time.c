/*
	cc -DLINUX -I../include testhasl_time.c akxcom.a -o testhasl_time
*/
#include "prmn.h"
#define PR(x)

pProcessTable pProcessTbl;
int giD_DAEMON_MAX;
int lglDaemonSize;

int cpPrProcIdToEntry(iProcId)
int iProcId;
{
	pProcessTable pPrT;
	int i,max=lglDaemonSize;

	if (iProcId) {
#if 1
		pPrT = &pProcessTbl[0];
		for (i=0;i<max ;i++,pPrT++) {
			if (iProcId == pPrT->usPrId ) return i;
		}
#else
		for (i=0;i<lglDaemonSize ;i++,pPrT++) {
			if (iProcId == pProcessTbl[i].usPrId ) return i;
		}
#endif
	}
	return -1;
}

main()
{
	HASHB *ha,*hax,*hal2;
	int i,j,k,iProcId,max,ix,t1,t2,t3;
	char buf[100];
	tdtTimerCtlHead *pTC;
	struct timeval tval1,tval2,tvalf,tvalh,tvalx,tvall2;
	long key[2];

	pTC = akxe_timer_new();

/*	giD_DAEMON_MAX = 10000;	*/
	printf("max=");
	gets(buf);
	giD_DAEMON_MAX = atoi(buf);
	ha = akxs_hasl_new(4,giD_DAEMON_MAX,0);
	hal2 = akxs_hasl2_new(8,giD_DAEMON_MAX,0);
	hax = akxs_hasx_new(5,giD_DAEMON_MAX,0);
	hax->ha_keylen = 4;
	akxshasx('i',hax);
	pProcessTbl = (pProcessTable)Malloc(sizeof(qProcessTable)*giD_DAEMON_MAX);
	memset(pProcessTbl,0,sizeof(qProcessTable)*giD_DAEMON_MAX);
/*
	printf("array size=");
	gets(buf);
	lglDaemonSize = atoi(buf);
*/
	lglDaemonSize = giD_DAEMON_MAX;
	hax->ha_key = (char *)&iProcId;
	for (i=0;i<lglDaemonSize ;i++) {
		iProcId = 1000 + i;
		pProcessTbl[i].usPrId = iProcId;
		ix=akxshasls(ha,iProcId);
		PR(printf("i=%d ix=%d\n",i,ix);)
		ix=akxshasx('S',hax);
		key[0] = iProcId;
		key[1] = 0;
		ix=akxshasl2s(hal2,key);
	}

	printf("\n count        for         hasl         hasx         hasl2\n");
	for (j=1;j<giD_DAEMON_MAX;) {
		akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			iProcId = 1000 + i;
			ix=cpPrProcIdToEntry(iProcId);
			PR(printf("i=%d ix=%d\n",i,ix);)
		}
		akxe_getm_sec(pTC,&tval2);
/*
		printf("--for  %10d.%06d %10d.%06d\n",tval1.tv_sec,tval1.tv_usec,tval2.tv_sec,tval2.tv_usec);
*/
		t1 = akxe_timer_sub(&tvalf,&tval2,&tval1);

		akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			iProcId = 1000 + i;
			ix=akxshaslr(ha,iProcId);
			PR(printf("i=%d ix=%d\n",i,ix);)
		}
		akxe_getm_sec(pTC,&tval2);
/*
		printf("--hasl %10d.%06d %10d.%06d\n",tval1.tv_sec,tval1.tv_usec,tval2.tv_sec,tval2.tv_usec);
*/
		t2 = akxe_timer_sub(&tvalh,&tval2,&tval1);

		akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			iProcId = 1000 + i;
			ix=akxshasx('R',hax);
			PR(printf("i=%d ix=%d\n",i,ix);)
		}
		akxe_getm_sec(pTC,&tval2);
		t3 = akxe_timer_sub(&tvalx,&tval2,&tval1);

		akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			iProcId = 1000 + i;
			key[0] = iProcId;
			ix=akxshasl2r(hal2,key);
			PR(printf("i=%d ix=%d\n",i,ix);)
		}
		akxe_getm_sec(pTC,&tval2);
		t3 = akxe_timer_sub(&tvall2,&tval2,&tval1);

		printf("%6d %5d.%06d %5d.%06d %5d.%06d %5d.%06d\n",
		j,tvalf.tv_sec,tvalf.tv_usec,tvalh.tv_sec,tvalh.tv_usec,
		tvalx.tv_sec,tvalx.tv_usec,
		tvall2.tv_sec,tvall2.tv_usec);

		j *= 2;
	}
}
