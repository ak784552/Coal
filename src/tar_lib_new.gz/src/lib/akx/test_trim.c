static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_trim.c libakx_no_u8src.a -o test_trim
*/
#include "akxcommon.h"
main()
{
	char *argv[5],s[256];
	int len;

	argv[0] = &dVal;
	argv[1] = (char *)100;
	argv[2] = "abc";
	len = akxa_log_fsnprintf_argv(NULL,s,sizeof(s),"d=%d i=%d s=[%s]\n",3,argv);
	printf("len=%d s=[%s]\n",len,s);
	exit(0);
}
