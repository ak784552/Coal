#include <stdio.h>
main()
{
	int a[10];

	printf("sizeof(a[10])=%d\n",sizeof(a));
	printf("sizeof(ushort)=%d\n",sizeof(ushort));
	printf("sizeof(unsigned short)=%d\n",sizeof(unsigned short));
}
