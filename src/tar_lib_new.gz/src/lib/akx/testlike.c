static char sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testlike.c libakx_no_iconv.a -o testlike
*/
#include "akxcommon.h"

int main()
{
	char buf[256],pat[256];
	int opt,ret,pos[4];

	printf("Enter case option ==>");
	gets(buf);
	opt = atoi(buf);
	printf("Enter text ==>");
	gets(buf);
	for (;;) {
		printf("Enter pattern ==>");
		if (!gets(pat)) break;
		ret = akxs_xlike_pos(buf,strlen(buf),pat,strlen(pat),opt,pos);
		printf("ret=%d pos=%d %d %d %d\n",ret,pos[0],pos[1],pos[2],pos[3]);
	}
}
