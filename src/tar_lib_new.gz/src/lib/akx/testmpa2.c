/*		mpa.c		Multiple-Precision Arithmetic	*/
/*
	cc -g -DLINUX -I../include testmpa2.c libakx.a -o testmpa2
*/
#include	"akxcommon.h"

int main(void)
{
	MPA v;
	char buf[128],wrk[128];
	int len;

	for (;;) {
		printf("Enter number: ");
		gets(buf);
		m_set_a(&v,buf);
		m_print("v = ", &v, 1);
		len=m_mpa2an(&v,wrk,sizeof(wrk),6);
		printf("len=%d wrk=[%s]\n",len,wrk);
	}
	return 0;
}
