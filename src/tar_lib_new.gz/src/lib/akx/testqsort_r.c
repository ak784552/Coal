static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testqsort_r.c libakx_no_iconv.a -o testqsort_r
*/
#include <akxcommon.h>

static int _cmp_akxqsort_r(a,b,c_arg)
char *a,*b,*c_arg;
{
	int *arg,mlen,opt,dif;
	short sa,sb;
	long la,lb;
	char ca,cb;

printf("_cmp_qsort_r: a=%08x b=%08x c_arg=%08x\n",a,b,c_arg);

	arg = (int *)c_arg;
	opt  = arg[0];
	mlen = arg[1];

printf("_cmp_qsort_r: mlen=%d opt=%d\n",mlen,opt);

	if (opt & 0x02) {
		if (mlen <= sizeof(char))
			dif = *a - *b;
		else if (mlen <= sizeof(short))
			dif = *(short *)a - *(short *)b;
		else if (mlen <= sizeof(int))
			dif = *(int *)a - *(int *)b;
		else
			dif = *(long *)a - *(long *)b;
	}
	else {
		dif = memcmp(a,b,mlen);
	}
	if (opt & 0x01) dif = -dif;
printf("_cmp_qsort_r: dif=%d\n",dif);
	return dif;
}

static int _cmp_qsort_r(c_arg,a,b)
char *a,*b,*c_arg;
{
	return _cmp_akxqsort_r(a,b,c_arg);
}

static char *jisho =
	"cd      action  flg     data    level   file    partner vendor  test    order   xxxxxxxx";

int main()
{
	static int lena[] = {-8,2,4,9,1,0,-3,6,5,7};
	int n,i,arg[2];
	char buf[10],*p,wrk[256];

	strcpy(wrk,jisho);
	arg[0] = 0x03;
	arg[1] = sizeof(int);
/*	akxqsort_r(lena,10,sizeof(int),_cmp_akxqsort_r,arg);	*/
	qsort_r(lena,10,sizeof(int),arg,_cmp_qsort_r);
	for (i=0;i<10;i++) {
		printf("i=%d lena=%d\n",i,lena[i]);
	}

	p = jisho;
	for (i=0;i<10;i++,p+=8) {
		memcpy(buf,p,8);
		*(buf+8) = '\0';
		printf("i=%d buf=[%s]\n",i,buf);
	}
printf("jisho=%08x\n",jisho);
	p = jisho;
	arg[0] = 0x00;
	arg[1] = 8;
/*	akxqsort_r(wrk,10,8,_cmp_akxqsort_r,arg);	*/
	qsort_r(wrk,10,8,arg,_cmp_qsort_r);
printf("jisho=%08x\n",jisho);
	for (i=0;i<10;i++,p+=8) {
		memcpy(buf,p,8);
		*(buf+8) = '\0';
		printf("i=%d buf=[%s]\n",i,buf);
	}
	exit(0);
}
