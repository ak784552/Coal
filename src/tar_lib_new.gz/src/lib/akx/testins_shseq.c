static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testins_shseq.c libakx.a -o testins_shseq
*/
#include <akxcommon.h>
main()
{
	int n,i;
	short a[20];

	for (i=0;i<20;i++) a[i] = i+1;
/*	n = akxs_ins_iseq(a,5,10,100);	*/
	n = akxs_ins_shseq_array(a,4,10,a,11,6,1);
	for (i=0;i<20;i++) printf("a[%2d] = %2d\n",i,a[i]);
	printf("n=%d\n",n);
	exit(0);
}
