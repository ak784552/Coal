static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testhanzen.c ../xcom/akxcom.a -o testhanzen
*/
#include "akxcommon.h"
main(argc,argv)
int argc;
char *argv[];
{
	int len;
	char han[256],zen[512];

	printf("Enter string:");
	gets(han);
	len = akxctozen(strlen(han),han,zen);
	printf("tozen: len=%d [%s]\n",len,zen);
	len = akxctohan(strlen(han),han,zen);
	printf("tohan: len=%d [%s]\n",len,han);
}
