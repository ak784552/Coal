static char sccsid[]="%Z% %M% %I% %E% %U%";
/*
    cc -g -DLINUX -I../include testxhash.c libakx.a -o testxhash
*/
#include "akxcommon.h"

int n,i,klen,lklen,dlen,ret,max,opt;
char key[128],cmd[20],*p,*rp,**rpp,buf[128],*kp,dat[128],*datp,c;
XHASHB *xha,*xhan;

main()
{

	printf("Enter opt(0/1/2) ==>");
	gets(cmd);
	opt=atoi(cmd);
	printf("Enter max ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter key length ==>");
	gets(cmd);
	klen=atoi(cmd);
	printf("Enter data length ==>");
	gets(cmd);
	dlen=atoi(cmd);
	if (dlen >= -1) sub2();
	else sub1();
}

int _ha_list(ha)
HASHB *ha;
{
	int n,i,lklen,ret;
	char key[128],cmd[20],*p,*rp,**rpp,buf[128],*kp,c;
	tdtHaslCell *cell,*ce;

printf("_ha_list: ha=%08x\n",ha);
	if (ha) {
			if (ha->ha_id[1]=='L') {
				cell = (tdtHaslCell *)ha->ha_reg;
				ce = cell;
				printf(" i flag     hkey next     data\n");
				for (i=0;i<max;i++,ce++) {
					printf("%2d %4d %08x %4d %08x\n",
					       i,ce->flag,ce->hkey,ce->next,ce->datp);
				}
			}
			else {
				rp = ha->ha_reg;
				rpp = (char **)rp;
				p = rp + (ha->ha_maxreg+1)*sizeof(char *);
				for (i=0;i<max;i++) {
					printf("%3d %3d ",i,ha->ha_next[i]);
					if (klen>0) {
						memcpy(buf,rp,klen+1);
						buf[klen+1]='\0';
						printf("%x [%s]\n",*buf,buf+1);
						rp+=klen+1;
					}
					else if (klen<0) {
						if (kp=rpp[i+1]) {
							memcpy(&lklen,kp,4);
							memcpy(buf,kp+4,lklen);
							buf[lklen]='\0';
						}
						else strcpy(buf,"(null)");
						printf("%x [%s]\n",*p++,buf);
					}
					else {
						if (!(kp=rpp[i+1])) {
							strcpy(buf,"(null)");
							kp=buf;
						}
						printf("%x [%s]\n",*p++,kp);
					}
				}
			}
	}
	return 0;
}

int sub1()
{
	char c;

	xha = akxs_xhash_new(klen,max,0);
	if (!xha) exit(1);
	c=xha->xha_id[0];
	if ((opt & 0x03)== 2) {
		c='N';
		xha->xha_prereg=akxs_hasx_pre_reg(max,997);
	}
	else if (!(opt & 0x01)) c='X';
	if (opt & 0x04) c=tolower(c);
	xha->xha_id[0]=c;
	for(;;) {
		xha->xha_xhix = 0;
		printf("Enter command ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			xhan = xha;
			while (xhan) {
				_ha_list(xhan->xha_hashb);
				xhan = xhan->xha_xhnext;
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key ==>");
			gets(buf);
			if (klen>0) {
				memset(key,0,klen);
				strcpy(key,buf);
			}
			else if (klen<0) {
				lklen=strlen(buf);
				memcpy(key,&lklen,4);
				memcpy(key+4,buf,lklen);
			}
			else {
				strcpy(key,buf);
			}
			printf("ret=%d\n",akxs_xhash(xha,c,key));
			break;
		case 'k':
		case 'p':
			printf("Enter no ==>");
			gets(buf);
			i = atoi(buf);
			xha->xha_xhix = i;
			if (c == 'k') {
				kp = key;
				ret=akxs_xhash(xha,c,kp);
			}
			else ret=akxs_xhash(xha,c,&kp);
			if (ret > 0) {
				if (klen>0) {
					strnzcpy(buf,kp,klen);
				}
				else if (klen<0) {
					memcpy(&lklen,kp,4);
					strnzcpy(buf,kp+4,lklen);
				}
				else strcpy(buf,kp);
			}
			else strcpy(buf,"(null)");
			printf("%2d %4d [%s]\n",i,ret,buf);
			break;
		case 'm':
			printf("total maxreg=%d\n",akxs_xhash(xha,c,NULL));
			break;
		case 'u':
			printf("used entry=%d\n",akxs_xhash2(xha,c,NULL,NULL));
			break;
		case 'e':
			exit(0);
		default:
			printf("Enter e/l/s/r/d/p/k/m/u\n");
		}
	}
}

int sub2()
{
	xha = akxs_xhash_new2(klen,max,0,dlen);
	if (!xha) exit(1);
	c=xha->xha_id[0];
	if ((opt & 0x03)== 2) {
		c='N';
		xha->xha_prereg=akxs_hasx_pre_reg(max,997);
	}
	else if (!(opt & 0x01)) c='X';
	if (opt & 0x04) c=tolower(c);
	xha->xha_id[0]=c;
	for(;;) {
		xha->xha_xhix = 0;
		printf("Enter command ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			xhan = xha;
			while (xhan) {
				_ha_list(xhan->xha_hashb);
				xhan = xhan->xha_xhnext;
			}
			break;
		case 's':
		case 'r':
		case 'd':
		case 'S':
		case 'R':
		case 'D':
			if (c=='s' || c=='r' ||c=='d') {
				printf("Enter key ==>");
				gets(buf);
				if (klen>0) {
					memset(key,0,klen);
					strcpy(key,buf);
				}
				else if (klen<0) {
					lklen=strlen(buf);
					memcpy(key,&lklen,4);
					memcpy(key+4,buf,lklen);
				}
				else {
					strcpy(key,buf);
				}
				kp = key;
			}
			else {
				printf("Enter no ==>");
				gets(buf);
				i = atoi(buf);
				xha->xha_xhix = i;
				kp = NULL;
			}
			rpp = &datp;
			if (c=='s' || c=='S') {
				printf("Enter dat ==>");
				gets(dat+4);
				if (dlen < 0) {
					n = strlen(dat+4);
					memcpy(dat,&n,4);
					datp = dat;
				}
				else datp = dat+4;
				rpp = (char **)datp;
			}
			printf("ret=%d\n",akxs_xhash2(xha,c,kp,rpp));
			if (c=='r' || c=='d' || c=='R' || c=='D') {
				if (dlen < 0) {
					memcpy(&n,datp,4);
					printf("n=%d dat=[%s]\n",n,datp+4);
				}
				else printf("dat=[%s]\n",datp);
			}
			break;
		case 'k':
		case 'p':
			printf("Enter no ==>");
			gets(buf);
			i = atoi(buf);
			xha->xha_xhix = i;
			if (c == 'k') {
				kp = key;
				ret=akxs_xhash2(xha,c,kp,&datp);
			}
			else ret=akxs_xhash2(xha,c,&kp,&datp);
			if (ret > 0) {
				if (klen>0) {
					strnzcpy(buf,kp,klen);
				}
				else if (klen<0) {
					memcpy(&lklen,kp,4);
					strnzcpy(buf,kp+4,lklen);
				}
				else strcpy(buf,kp);
			}
			else strcpy(buf,"(null)");
			printf("%2d %4d [%s]\n",i,ret,buf);
			if (datp) {
				if (dlen < 0) {
					memcpy(&n,datp,4);
					printf("n=%d dat=[%s]\n",n,datp+4);
				}
				else printf("dat=[%s]\n",datp);
			}
			else printf("dat=(null)\n");
			break;
		case 'm':
			printf("total maxreg=%d\n",akxs_xhash2(xha,c,NULL,NULL));
			break;
		case 'u':
			printf("used entry=%d\n",akxs_xhash2(xha,c,NULL,NULL));
			break;
		case 'e':
			exit(0);
		default:
			printf("Enter e/l/s/r/d/S/R/D/p/k/m/u\n");
		}
	}
}
