static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testcacheXHas.c akxcom.a -o testcacheXHas
*/
#define CACHE_XHAS
#include "akxcommon.h"

int _print_data(pCt)
tdtCacheCtl *pCt;
{
	int *p;
	char *pKey,*pCmp1,*pData;

	if (!(pKey  = pCt->ca_key))  pKey  = "(null)";
	if (!(pCmp1 = pCt->ca_cmp1)) pCmp1 = "(null)";
	if (!(pData = pCt->ca_data)) pData = "(null)";
	printf("cpCKey = [%s]\ncpCCmp1 = [%s]\n",pKey, pCmp1);
	if (p = (int *)pCt->ca_cmp2) 
		printf("cpCCmp2 = %d %d %d %d\n",p[0],p[1],p[2],p[3]);
	else printf("cpCCmp2 = (null)\n");
	printf("cpCData = [%s]\niCCmpNext = %d\niCChkTime = %d\n",
	       pData, pCt->ca_cmpnext, pCt->ca_chktime);
	return 0;
}

int main()
{
	tdtCacheCtlHead *pCH;
	tdtCacheCtl qCt;
	char buf[128];
	int  rc,i;
	char key[128],cmd[20],c;

	printf("Enter cache max : ");
	gets(buf);
	pCH = akxs_cache_newXHas(atoi(buf));
	if (!pCH) exit(1);
	printf("Enter cache no auto extend (y or n): ");
	gets(buf);
	pCH->ch_opt |= AKX_CACHE_DATASAVE | AKX_CACHE_IGNCHKERR;
	if (*buf == 'y') pCH->ch_opt |= AKX_CACHE_NOAUTOEXT;
	pCH->ch_cshlen = 0;
	pCH->ch_interval = 10;
	for(;;) {
		memset(&qCt,0,sizeof(tdtCacheCtl));
		printf("Enter command (end/check/set/delete/list/get) ==>");
		gets(cmd);
		c = *cmd;
		if (c == 'e') break;
		else if (c == 'l') {
			for (i=0;i<pCH->ch_imax;i++) {
				rc=akxs_cache_getXHas(pCH,i+1,&qCt);
				printf("Get rc = %d\n",rc);
				if (rc >= 0) _print_data(&qCt);
			}
		}
		else if (c == 'g') {
			printf("Enter No ==>");
			gets(key);
			rc=akxs_cache_getXHas(pCH,atoi(key),&qCt);
			printf("Get rc = %d\n",rc);
			if (rc >= 0) _print_data(&qCt);
		}
		else if (c == 'c' || c == 's' || c == 'd') {
			printf("Enter key ==>");
			gets(key);
			switch (c) {
			case 'c':
				rc = akxs_cache_chkXHas(pCH,key,&qCt);
				printf("Chk rc = %d\n",rc);
				if (rc >= 0) _print_data(&qCt);
				break;
			case 's':
				printf("Enter data ==>");
				gets(buf);
				qCt.ca_key  = key;
				qCt.ca_cmp1 = "aaaa";
				qCt.ca_data = buf;
				printf("Set rc = %d\n",rc=akxs_cache_setXHas(pCH,&qCt));
				if (rc > 0) {
					rc=akxs_cache_getXHas(pCH,rc,&qCt);
					printf("Get rc = %d\n",rc);
					if (rc >= 0) _print_data(&qCt);
					if (pCH->ch_prls) {
						printf("*** release ***\n");
						_print_data(pCH->ch_prls);
					}
				}
				break;
			case 'd':
				printf("Del rc = %d\n",akxs_cache_delXHas(pCH,key));
				break;
			}
			printf("Max   = %d\n",pCH->ch_imax);
			printf("MaxEnt= %d\n",pCH->ch_smax);
			printf("Entry = %d\n",pCH->ch_entry);
		}
	}
	rc=akxscache_freeXHas(pCH);
	printf("Free:rc = %d\n",rc);

	exit(0);
}
