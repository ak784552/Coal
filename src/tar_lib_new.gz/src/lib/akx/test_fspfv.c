static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_fspfv.c libakx_no_u8src.a -o test_fspfv
*/
#include "akxcommon.h"
int main()
{
	char *argv[5],*s;
	int len;
	double dVal;

	dVal = 123.456;
	argv[0] = (char *)&dVal;
	argv[1] = (char *)100;
	argv[2] = "abc";
	s = akxa_fsprintfv(NULL,"d=%f %% i=%d s=[%s]\n",3,argv);
	printf("s=[%s]\n",s);
	exit(0);
}
