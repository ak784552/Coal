static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testcvl.c libakx.a -o testcvl
*/
#include "akxcommon.h"
main()
{
	char expbuf[256];
	int ret,num,rad;
	long Val;

	printf("sizeof(long)=%d\n",sizeof(long));
	printf("Enter rad (2..16)==>");
	gets(expbuf);
	rad = atoi(expbuf);
	if (rad<2 || rad>16) return -1;
	for (;;) {
		printf("Enter ==>");
		gets(expbuf);
		if (!stricmp(expbuf,"/EOF")) break;
		ret = akxccvl(rad,expbuf,strlen(expbuf),&Val);
		printf("ret=%d Val=%d\n",ret,Val);
	}
	return 0;
}
