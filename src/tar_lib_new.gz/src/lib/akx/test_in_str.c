static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testInStr.c akxcom.a -o testInStr
*/
#include "akxcommon.h"
main()
{
	char buf[256],wd[256],*p;
	int n,opt,len,ret;

	printf("Enter source text ==>");
	gets(buf);
	for (;;) {
		printf("Enter opt ==>");
		gets(wd);
		opt=atoi(wd);
		printf("Enter search string ==>");
		gets(wd);
		printf("akxs_in_str_opt: ret=%d\n",akxs_in_str_opt(buf,wd,opt));
		printf("instr: ret=%d\n",instr(buf,wd));
		printf("inistr: ret=%d\n",inistr(buf,wd));
		p = stristr(buf,wd);
		if (p) printf("stristr: ret=[%s]\n",p);
		else printf("stristr: ret=NULL\n");
		p = strstr(buf,wd);
		if (p) printf("strstr: ret=[%s]\n",p);
		else printf("strstr: ret=NULL\n");
	}
}
