static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testskipto.c akxcom.a -o testskipto
*/
#include "akxcommon.h"
main()
{
	char s1[256],s2[256];
	int len,ret,opt;

	printf("Enter opt(0/1) ==>");
	gets(s1);
	opt = atoi(s1);
/*
	strcpy(s1,"�i");
	strcpy(s2,"�I");
*/
	for (;;) {
		printf("Enter s1 ==>");
		gets(s1);
		for (;;) {
			printf("Enter s2(chr) ==>");
			gets(s2);
			printf("akxnskipto: ret=%d\n",akxnskipto(s1,strlen(s1),s2));
		}
	}
}
