static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
    cc -g -DLINUX -I../include testlogfout.c  akxcom.a -o testlogfout
*/
#include "akxcommon.h"
main()
{
	char data[11];

	strcpy(data,"1234567890");
	XLOGFOUT("xdebug_log",data,strlen(data));

}
