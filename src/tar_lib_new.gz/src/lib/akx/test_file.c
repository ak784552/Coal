static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_file.c libakx_no_u8src.a -o test_file
*/
#include "akxcommon.h"
main()
{
	M_FILE *fp,*fp2;
	int ret;
	char name[64],mode[10];
/*
	fp = m_fopen("www","w");
	printf("m_fd=%d m_fp=%08x m_flag=%08x m_name=[%s]\n",fp->m_fd,fp->m_fp,fp->m_flag,fp->m_name);
	fp2 = m_fopen("wwww","rb");
	printf("m_fd=%d m_fp=%08x m_flag=%08x m_name=[%s]\n",fp2->m_fd,fp2->m_fp,fp2->m_flag,fp2->m_name);
	ret = m_fclose(fp2);
	printf("ret=%d\n",ret);
	ret = m_fclose(fp);
	printf("ret=%d\n",ret);
*/
	for (;;) {
		printf("Enter name:");
		gets(name);
		if (*name == '/') break;
		printf("Enter mode:");
		gets(mode);
		fp2 = m_fopen(name,mode);
		if (fp2) {
			printf("m_fd=%d m_fp=%08x m_flag=%08x m_name=[%s]\n",fp2->m_fd,fp2->m_fp,fp2->m_flag,fp2->m_name);
			ret = m_fclose(fp2);
			printf("ret=%d\n",ret);
		}
		else {
			printf("Error!! errno=%d\n",errno);
		}
	}
}
