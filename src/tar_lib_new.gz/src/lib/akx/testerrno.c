static char sccsid[]="%Z% %M% %I% %E% %U%";
/*
    cc -g -DLINUX -I../include testerrno.c -o testerrno
*/
#include "akxcommon.h"

main()
{
	errno = -113;
	printf("errno=%d\n",errno);
}
