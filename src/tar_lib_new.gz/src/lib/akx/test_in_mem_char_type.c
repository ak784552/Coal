static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include test_in_mem_char_type.c libakx_no_iconv.a -o test_in_mem_char_type
*/
#include <akxcommon.h>
int main()
{
	int n,i,rc,ltar,lstr,code_type;
	char buf[256],str[20];

	code_type = akxt_get_code_type();
	strcpy(buf,"abcあ和eホghijkｱ");
	ltar = strlen(buf);
	printf("ltar=%d bud=[%s]\n",ltar,buf);
/*
	for (;;) {
		printf("enter char :");
		gets(str);
		strcpy(str,"あ");
		if (!*str) break;
		lstr = strlen(str);
		printf("rc=%d\n",akxs_in_mem_type(buf,ltar,str,lstr,code_type));
	}
*/
	strcpy(str,"e");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_type(buf,ltar,str,lstr,code_type));

	strcpy(str,"あ");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_type(buf,ltar,str,lstr,code_type));

	strcpy(str,"ｱ");
	lstr = strlen(str);
	printf("lstr=%d str=[%s]\n",lstr,str);
	printf("rc=%d\n",akxs_in_mem_type(buf,ltar,str,lstr,code_type));
	exit(0);
}
