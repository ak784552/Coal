static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_strmemk.c libakx_no_u8src.a -o test_strmemk
*/
#include "akxcommon.h"
int main()
{
	char *p1,*p2,*p3,*p4;
	int len;

	p1 = strmem("ABCDEF",3);
	p2 = strmemk("XYZ1234",4,"abcd");
	p3 = strmemk("987543345",5,"xyz");
	p4 = strmemk("sevsladewi",6,"sderg");
	printf("p1=[%s]\n",p1);
	printf("p2=[%s]\n",p2);
	printf("p3=[%s]\n",p3);
	printf("p4=[%s]\n",p4);
	p1 = strmem("bbaDEF",5);
	p2 = strmemk("xyz1234",6,"abcd");
	p3 = strmemk("345675443",6,"xyz");
	p4 = strmemk("lkjhgfsthaa",7,"sderg");
	printf("p1=[%s]\n",p1);
	printf("p2=[%s]\n",p2);
	printf("p3=[%s]\n",p3);
	printf("p4=[%s]\n",p4);
	exit(0);
}
