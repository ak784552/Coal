static char sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -I../include testfwrite.c  -o testfwrite
*/
#include <stdio.h>

int main(int argc,char *argv[])
{
	char line[256];
	int n,max,opt,ret;
	FILE *fpr,*fpw;

	fpw = fopen(argv[1],"w");
	if (fpw) {
		ret=fwrite("test\n",5,1,fpw);
		fclose(fpw);
	}
	else printf("file [%s] open error!!\n",argv[1]);
	return 0;
}
