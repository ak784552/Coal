#include <windows.h>
#include <winuser.h>

int main(){
	int i;

/*
        MessageBox(NULL,"Hello,world!!","",0);
*/
	for (i=0;i<10;i++) Beep(262,1000);
        return 0;
}
